import { z as e } from "zod";
import { randomIntAt as t } from "@bgparty/sdk/engine/prng";
import { Fragment as n, useEffect as r, useId as i, useLayoutEffect as a, useMemo as o, useRef as s, useState as c } from "react";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { useWakeLock as d } from "@bgparty/sdk/use-wake-lock";
import { BottomSheet as f } from "@bgparty/sdk/bottom-sheet";
import { IconBot as p, IconCheck as m, IconExpand as h, IconInfo as ee, IconLog as g, IconRecenter as _, IconRotate as te, IconZoomIn as ne, IconZoomOut as re } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as v } from "@bgparty/sdk/player-colors";
import { GameScreen as ie } from "@bgparty/sdk/ui/game-screen";
import { seatName as ae } from "@bgparty/sdk/ui/player-strip";
import { DeltaNumber as oe } from "@bgparty/sdk/fx/delta-number";
import { Fragment as y, jsx as b, jsxs as x } from "react/jsx-runtime";
import { ConfirmButton as se } from "@bgparty/sdk/confirm-button";
import { OptionCheckbox as ce, OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/arknova/meta.ts
var w = {
	id: "arknova",
	tier: "alpha",
	mechanics: [
		"engine-building",
		"tile-placement",
		"worker-placement"
	],
	interactionTags: [],
	nameKey: "games.arknova.name",
	descKey: "games.arknova.desc",
	rulesKey: "games.arknova.rules",
	icon: "🦒",
	iconImg: "games/arknova.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [2],
	accent: "#31834a",
	releasedAt: "2026-10-29T03:17:54+08:00",
	search: {
		py: "fang zhou dong wu yuan",
		init: "fzdwy"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://capstone-games.com/cdn/shop/files/Ark-Nova-Rulebook.pdf?v=15269496103518830006" }
}, le = [
	"animals",
	"build",
	"cards",
	"association",
	"sponsors"
], T = [
	"africa",
	"americas",
	"asia",
	"australia",
	"europe"
], E = [
	"bird",
	"herbivore",
	"predator",
	"primate",
	"reptile",
	"seaAnimal"
], D = e.string().regex(/^\d{3}$/), ue = e.enum([
	"A",
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8"
]), O = e.enum(le), de = e.enum([
	"standard1",
	"standard2",
	"standard3",
	"standard4",
	"standard5",
	"kiosk",
	"pavilion",
	"petting",
	"aviary",
	"reptile",
	"aquariumSmall",
	"aquariumLarge",
	"unique"
]), fe = e.tuple([e.int(), e.int()]).readonly(), k = e.string().regex(/^(animals|build|cards|association|sponsors):[1-4]$/), pe = e.object({
	marine: e.boolean().default(!0),
	maps: e.enum([
		"A",
		"0",
		"advanced"
	]).default("A")
}).prefault({}), me = e.discriminatedUnion("type", [
	e.object({
		type: e.literal("choose"),
		revision: e.int().nonnegative(),
		id: e.string().max(60)
	}).strict(),
	e.object({
		type: e.literal("map"),
		map: ue
	}).strict(),
	e.object({
		type: e.literal("draft"),
		card: k
	}).strict(),
	e.object({
		type: e.literal("variants"),
		cards: e.array(k).length(2)
	}).strict(),
	e.object({
		type: e.literal("hand"),
		cards: e.array(D).length(4)
	}).strict()
]), he = e.object({
	id: e.int().nonnegative(),
	kind: de,
	cells: e.array(fe),
	occupied: e.boolean(),
	used: e.int().nonnegative(),
	extra: e.int().nonnegative(),
	card: D.nullable()
}), ge = e.object({
	kind: O,
	variant: e.int().min(0).max(4),
	upgraded: e.boolean(),
	multiplier: e.int().nonnegative(),
	venom: e.boolean(),
	constriction: e.boolean()
}), _e = e.object({
	rid: e.string(),
	map: ue,
	money: e.int().nonnegative(),
	appeal: e.int().min(0).max(113),
	conservation: e.int().min(0).max(41),
	reputation: e.int().min(1).max(15),
	x: e.int().min(0).max(5),
	workers: e.int().min(1).max(4),
	workersUsed: e.record(e.string(), e.int().nonnegative()),
	actions: e.array(ge).length(5),
	buildings: e.array(he),
	animals: e.array(D),
	sponsors: e.array(D),
	partners: e.array(e.string()),
	universities: e.array(e.string()),
	bonuses: e.array(e.int().nonnegative()),
	extraTags: e.array(e.string()),
	cardTokens: e.record(e.string(), e.int().nonnegative()),
	pouched: e.record(e.string(), e.int().nonnegative()),
	handCount: e.int().nonnegative(),
	finalCount: e.int().nonnegative(),
	finals: e.array(D),
	assignment: e.enum(["small", "large"]).nullable(),
	donations: e.int().nonnegative(),
	ready: e.boolean()
}), ve = e.object({
	id: e.string(),
	key: e.string(),
	params: e.record(e.string(), e.union([e.string(), e.number()])).optional(),
	card: D.optional(),
	cells: e.array(fe).optional(),
	building: de.optional(),
	action: O.optional(),
	value: e.number().optional(),
	score: e.number()
}), ye = e.object({
	config: pe,
	revision: e.int().nonnegative(),
	phase: e.enum([
		"map",
		"draft",
		"setup",
		"play",
		"break",
		"final",
		"done"
	]),
	players: e.array(_e).min(2).max(4),
	turn: e.string(),
	actor: e.string().nullable(),
	turnNumber: e.int().positive(),
	breakNumber: e.int().nonnegative(),
	breakProgress: e.int().nonnegative(),
	breakLength: e.int().positive(),
	market: e.array(D.nullable()).length(6),
	marks: e.record(D, e.string()),
	deckCount: e.int().nonnegative(),
	discardCount: e.int().nonnegative(),
	projects: e.array(e.object({
		card: D,
		base: e.boolean(),
		owner: e.string().nullable(),
		slots: e.array(e.string().nullable()).length(3)
	})),
	partnerSupply: e.array(e.string()),
	universitySupply: e.array(e.string()),
	marineUniversities: e.array(e.string()),
	donations: e.int().nonnegative(),
	rewards: e.record(e.string(), e.array(e.string())),
	finalTurns: e.int().nonnegative().nullable(),
	endBy: e.string().nullable(),
	activity: e.object({
		rid: e.string(),
		action: O,
		strength: e.int(),
		remaining: e.int()
	}).nullable(),
	journal: e.array(e.object({
		key: e.string(),
		rid: e.string(),
		card: D.optional(),
		n: e.number().optional()
	})),
	finalBreakdown: e.record(e.string(), e.array(e.object({
		card: D,
		appeal: e.int(),
		conservation: e.int()
	})))
}), be = e.object({
	hand: e.array(D),
	finals: e.array(D),
	maps: e.array(ue),
	draft: e.array(k),
	draftKept: e.array(k),
	draftRound: e.int().min(0).max(2),
	draftSelected: k.nullable(),
	choices: e.array(ve),
	prompt: e.string()
});
//#endregion
//#region src/games/arknova/state.ts
function A(e, t, n = 1, r = "", i = "") {
	return {
		rid: e,
		op: t,
		n,
		arg: r,
		source: i
	};
}
function j(e, t) {
	let n = e.players.find((e) => e.rid === t);
	if (!n) throw Error("Unknown Ark Nova player");
	return n;
}
function M(e) {
	return [...e.frames].reverse().find((e) => e.kind === "action");
}
function N(e, t, n = 0, r = {}) {
	return {
		id: "",
		key: e,
		effects: t,
		score: n,
		...r
	};
}
//#endregion
//#region src/games/arknova/catalog.ts
var P = {
	101: {
		id: "101",
		kind: "project",
		nameKey: "games.arknova.cards.c101.name",
		descriptionKey: "games.arknova.cards.c101.description",
		marine: !1,
		type: "base",
		tag: "all-animals",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 3,
				conservation: 2,
				reputation: 0
			}
		]
	},
	102: {
		id: "102",
		kind: "project",
		nameKey: "games.arknova.cards.c102.name",
		descriptionKey: "games.arknova.cards.c102.description",
		marine: !1,
		type: "base",
		tag: "all-continents",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 3,
				conservation: 2,
				reputation: 0
			}
		]
	},
	103: {
		id: "103",
		kind: "project",
		nameKey: "games.arknova.cards.c103.name",
		descriptionKey: "games.arknova.cards.c103.description",
		marine: !1,
		type: "base",
		tag: "africa",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	104: {
		id: "104",
		kind: "project",
		nameKey: "games.arknova.cards.c104.name",
		descriptionKey: "games.arknova.cards.c104.description",
		marine: !1,
		type: "base",
		tag: "americas",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	105: {
		id: "105",
		kind: "project",
		nameKey: "games.arknova.cards.c105.name",
		descriptionKey: "games.arknova.cards.c105.description",
		marine: !1,
		type: "base",
		tag: "australia",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	106: {
		id: "106",
		kind: "project",
		nameKey: "games.arknova.cards.c106.name",
		descriptionKey: "games.arknova.cards.c106.description",
		marine: !1,
		type: "base",
		tag: "asia",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	107: {
		id: "107",
		kind: "project",
		nameKey: "games.arknova.cards.c107.name",
		descriptionKey: "games.arknova.cards.c107.description",
		marine: !1,
		type: "base",
		tag: "europe",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	108: {
		id: "108",
		kind: "project",
		nameKey: "games.arknova.cards.c108.name",
		descriptionKey: "games.arknova.cards.c108.description",
		marine: !1,
		type: "base",
		tag: "primate",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	109: {
		id: "109",
		kind: "project",
		nameKey: "games.arknova.cards.c109.name",
		descriptionKey: "games.arknova.cards.c109.description",
		marine: !1,
		type: "base",
		tag: "reptile",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	110: {
		id: "110",
		kind: "project",
		nameKey: "games.arknova.cards.c110.name",
		descriptionKey: "games.arknova.cards.c110.description",
		marine: !1,
		type: "base",
		tag: "predator",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	111: {
		id: "111",
		kind: "project",
		nameKey: "games.arknova.cards.c111.name",
		descriptionKey: "games.arknova.cards.c111.description",
		marine: !1,
		type: "base",
		tag: "herbivore",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	112: {
		id: "112",
		kind: "project",
		nameKey: "games.arknova.cards.c112.name",
		descriptionKey: "games.arknova.cards.c112.description",
		marine: !1,
		type: "base",
		tag: "bird",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	113: {
		id: "113",
		kind: "project",
		nameKey: "games.arknova.cards.c113.name",
		descriptionKey: "games.arknova.cards.c113.description",
		marine: !1,
		type: "release",
		tag: "europe",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	114: {
		id: "114",
		kind: "project",
		nameKey: "games.arknova.cards.c114.name",
		descriptionKey: "games.arknova.cards.c114.description",
		marine: !1,
		type: "release",
		tag: "americas",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	115: {
		id: "115",
		kind: "project",
		nameKey: "games.arknova.cards.c115.name",
		descriptionKey: "games.arknova.cards.c115.description",
		marine: !1,
		type: "release",
		tag: "asia",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	116: {
		id: "116",
		kind: "project",
		nameKey: "games.arknova.cards.c116.name",
		descriptionKey: "games.arknova.cards.c116.description",
		marine: !1,
		type: "release",
		tag: "africa",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	117: {
		id: "117",
		kind: "project",
		nameKey: "games.arknova.cards.c117.name",
		descriptionKey: "games.arknova.cards.c117.description",
		marine: !1,
		type: "release",
		tag: "australia",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	118: {
		id: "118",
		kind: "project",
		nameKey: "games.arknova.cards.c118.name",
		descriptionKey: "games.arknova.cards.c118.description",
		marine: !1,
		type: "release",
		tag: "predator",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	119: {
		id: "119",
		kind: "project",
		nameKey: "games.arknova.cards.c119.name",
		descriptionKey: "games.arknova.cards.c119.description",
		marine: !1,
		type: "release",
		tag: "bird",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	120: {
		id: "120",
		kind: "project",
		nameKey: "games.arknova.cards.c120.name",
		descriptionKey: "games.arknova.cards.c120.description",
		marine: !1,
		type: "release",
		tag: "herbivore",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	121: {
		id: "121",
		kind: "project",
		nameKey: "games.arknova.cards.c121.name",
		descriptionKey: "games.arknova.cards.c121.description",
		marine: !1,
		type: "release",
		tag: "reptile",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	122: {
		id: "122",
		kind: "project",
		nameKey: "games.arknova.cards.c122.name",
		descriptionKey: "games.arknova.cards.c122.description",
		marine: !1,
		type: "release",
		tag: "primate",
		slots: [
			{
				requirement: 0,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 0,
				conservation: 3,
				reputation: 0
			}
		]
	},
	123: {
		id: "123",
		kind: "project",
		nameKey: "games.arknova.cards.c123.name",
		descriptionKey: "games.arknova.cards.c123.description",
		marine: !1,
		type: "breed",
		tag: "bird",
		slots: [
			{
				requirement: 0,
				conservation: 2,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 1,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 2,
				reputation: 0
			}
		]
	},
	124: {
		id: "124",
		kind: "project",
		nameKey: "games.arknova.cards.c124.name",
		descriptionKey: "games.arknova.cards.c124.description",
		marine: !1,
		type: "breed",
		tag: "predator",
		slots: [
			{
				requirement: 0,
				conservation: 2,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 1,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 2,
				reputation: 0
			}
		]
	},
	125: {
		id: "125",
		kind: "project",
		nameKey: "games.arknova.cards.c125.name",
		descriptionKey: "games.arknova.cards.c125.description",
		marine: !1,
		type: "breed",
		tag: "reptile",
		slots: [
			{
				requirement: 0,
				conservation: 2,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 1,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 2,
				reputation: 0
			}
		]
	},
	126: {
		id: "126",
		kind: "project",
		nameKey: "games.arknova.cards.c126.name",
		descriptionKey: "games.arknova.cards.c126.description",
		marine: !1,
		type: "breed",
		tag: "herbivore",
		slots: [
			{
				requirement: 0,
				conservation: 2,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 1,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 2,
				reputation: 0
			}
		]
	},
	127: {
		id: "127",
		kind: "project",
		nameKey: "games.arknova.cards.c127.name",
		descriptionKey: "games.arknova.cards.c127.description",
		marine: !1,
		type: "breed",
		tag: "primate",
		slots: [
			{
				requirement: 0,
				conservation: 2,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 1,
				reputation: 2
			},
			{
				requirement: 0,
				conservation: 2,
				reputation: 0
			}
		]
	},
	128: {
		id: "128",
		kind: "project",
		nameKey: "games.arknova.cards.c128.name",
		descriptionKey: "games.arknova.cards.c128.description",
		marine: !1,
		type: "normal",
		tag: "water",
		slots: [
			{
				requirement: 5,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	129: {
		id: "129",
		kind: "project",
		nameKey: "games.arknova.cards.c129.name",
		descriptionKey: "games.arknova.cards.c129.description",
		marine: !1,
		type: "normal",
		tag: "rock",
		slots: [
			{
				requirement: 5,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	130: {
		id: "130",
		kind: "project",
		nameKey: "games.arknova.cards.c130.name",
		descriptionKey: "games.arknova.cards.c130.description",
		marine: !1,
		type: "normal",
		tag: "animal-size-2",
		slots: [
			{
				requirement: 8,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 5,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	131: {
		id: "131",
		kind: "project",
		nameKey: "games.arknova.cards.c131.name",
		descriptionKey: "games.arknova.cards.c131.description",
		marine: !1,
		type: "normal",
		tag: "animal-size-4",
		slots: [
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 3,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	132: {
		id: "132",
		kind: "project",
		nameKey: "games.arknova.cards.c132.name",
		descriptionKey: "games.arknova.cards.c132.description",
		marine: !1,
		type: "normal",
		tag: "science",
		slots: [
			{
				requirement: 5,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 3,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	133: {
		id: "133",
		kind: "project",
		nameKey: "games.arknova.cards.c133.name",
		descriptionKey: "games.arknova.cards.c133.description",
		marine: !0,
		type: "base",
		tag: "seaAnimal",
		slots: [
			{
				requirement: 5,
				conservation: 5,
				reputation: 0
			},
			{
				requirement: 4,
				conservation: 4,
				reputation: 0
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0
			}
		]
	},
	134: {
		id: "134",
		kind: "project",
		nameKey: "games.arknova.cards.c134.name",
		descriptionKey: "games.arknova.cards.c134.description",
		marine: !0,
		type: "management",
		tag: "predator",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "hunterPredators"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	135: {
		id: "135",
		kind: "project",
		nameKey: "games.arknova.cards.c135.name",
		descriptionKey: "games.arknova.cards.c135.description",
		marine: !0,
		type: "management",
		tag: "bird",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "posturing"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	136: {
		id: "136",
		kind: "project",
		nameKey: "games.arknova.cards.c136.name",
		descriptionKey: "games.arknova.cards.c136.description",
		marine: !0,
		type: "management",
		tag: "reptile",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "sunbathing2"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	137: {
		id: "137",
		kind: "project",
		nameKey: "games.arknova.cards.c137.name",
		descriptionKey: "games.arknova.cards.c137.description",
		marine: !0,
		type: "management",
		tag: "herbivore",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "xtoken2"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	138: {
		id: "138",
		kind: "project",
		nameKey: "games.arknova.cards.c138.name",
		descriptionKey: "games.arknova.cards.c138.description",
		marine: !0,
		type: "management",
		tag: "seaAnimal",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "reef"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	139: {
		id: "139",
		kind: "project",
		nameKey: "games.arknova.cards.c139.name",
		descriptionKey: "games.arknova.cards.c139.description",
		marine: !0,
		type: "management",
		tag: "primate",
		slots: [
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "clever"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "scienceReputation"
			},
			{
				requirement: 2,
				conservation: 2,
				reputation: 0,
				effect: "searchCategory"
			}
		]
	},
	201: {
		id: "201",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c201.name",
		descriptionKey: "games.arknova.cards.c201.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	202: {
		id: "202",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c202.name",
		descriptionKey: "games.arknova.cards.c202.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["science"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	203: {
		id: "203",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c203.name",
		descriptionKey: "games.arknova.cards.c203.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	204: {
		id: "204",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c204.name",
		descriptionKey: "games.arknova.cards.c204.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [
			"science",
			"science",
			"science",
			"science"
		],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	205: {
		id: "205",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c205.name",
		descriptionKey: "games.arknova.cards.c205.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [
			"science",
			"science",
			"science"
		],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 2,
		conservation: 1
	},
	206: {
		id: "206",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c206.name",
		descriptionKey: "games.arknova.cards.c206.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [
			"science",
			"science",
			"science",
			"science"
		],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	207: {
		id: "207",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c207.name",
		descriptionKey: "games.arknova.cards.c207.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII", "appeal"],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	208: {
		id: "208",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c208.name",
		descriptionKey: "games.arknova.cards.c208.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	209: {
		id: "209",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c209.name",
		descriptionKey: "games.arknova.cards.c209.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	210: {
		id: "210",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c210.name",
		descriptionKey: "games.arknova.cards.c210.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["americas"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	211: {
		id: "211",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c211.name",
		descriptionKey: "games.arknova.cards.c211.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["europe"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	212: {
		id: "212",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c212.name",
		descriptionKey: "games.arknova.cards.c212.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["australia"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	213: {
		id: "213",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c213.name",
		descriptionKey: "games.arknova.cards.c213.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["asia"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	214: {
		id: "214",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c214.name",
		descriptionKey: "games.arknova.cards.c214.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["africa"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	215: {
		id: "215",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c215.name",
		descriptionKey: "games.arknova.cards.c215.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo", "Partner Zoo"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	216: {
		id: "216",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c216.name",
		descriptionKey: "games.arknova.cards.c216.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	217: {
		id: "217",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c217.name",
		descriptionKey: "games.arknova.cards.c217.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	218: {
		id: "218",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c218.name",
		descriptionKey: "games.arknova.cards.c218.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["science", "science"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	219: {
		id: "219",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c219.name",
		descriptionKey: "games.arknova.cards.c219.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: ["science"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	220: {
		id: "220",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c220.name",
		descriptionKey: "games.arknova.cards.c220.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	221: {
		id: "221",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c221.name",
		descriptionKey: "games.arknova.cards.c221.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["science"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	222: {
		id: "222",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c222.name",
		descriptionKey: "games.arknova.cards.c222.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	223: {
		id: "223",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c223.name",
		descriptionKey: "games.arknova.cards.c223.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science", "science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	224: {
		id: "224",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c224.name",
		descriptionKey: "games.arknova.cards.c224.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	225: {
		id: "225",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c225.name",
		descriptionKey: "games.arknova.cards.c225.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	226: {
		id: "226",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c226.name",
		descriptionKey: "games.arknova.cards.c226.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 2,
		conservation: 0
	},
	227: {
		id: "227",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c227.name",
		descriptionKey: "games.arknova.cards.c227.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 0,
		water: 0,
		requirements: ["reputation"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	228: {
		id: "228",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c228.name",
		descriptionKey: "games.arknova.cards.c228.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["reputation"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	229: {
		id: "229",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c229.name",
		descriptionKey: "games.arknova.cards.c229.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	230: {
		id: "230",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c230.name",
		descriptionKey: "games.arknova.cards.c230.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	231: {
		id: "231",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c231.name",
		descriptionKey: "games.arknova.cards.c231.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["primate"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	232: {
		id: "232",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c232.name",
		descriptionKey: "games.arknova.cards.c232.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["reptile"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	233: {
		id: "233",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c233.name",
		descriptionKey: "games.arknova.cards.c233.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["bird"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	234: {
		id: "234",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c234.name",
		descriptionKey: "games.arknova.cards.c234.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["predator"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	235: {
		id: "235",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c235.name",
		descriptionKey: "games.arknova.cards.c235.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["herbivore"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	236: {
		id: "236",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c236.name",
		descriptionKey: "games.arknova.cards.c236.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	237: {
		id: "237",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c237.name",
		descriptionKey: "games.arknova.cards.c237.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["reptile"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	238: {
		id: "238",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c238.name",
		descriptionKey: "games.arknova.cards.c238.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	239: {
		id: "239",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c239.name",
		descriptionKey: "games.arknova.cards.c239.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	240: {
		id: "240",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c240.name",
		descriptionKey: "games.arknova.cards.c240.description",
		marine: !1,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	241: {
		id: "241",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c241.name",
		descriptionKey: "games.arknova.cards.c241.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["water"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	242: {
		id: "242",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c242.name",
		descriptionKey: "games.arknova.cards.c242.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["rock"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	243: {
		id: "243",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c243.name",
		descriptionKey: "games.arknova.cards.c243.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 1,
		water: 0,
		requirements: ["reputation"],
		tags: ["herbivore"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	244: {
		id: "244",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c244.name",
		descriptionKey: "games.arknova.cards.c244.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 1,
		requirements: ["reputation"],
		tags: ["bird"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	245: {
		id: "245",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c245.name",
		descriptionKey: "games.arknova.cards.c245.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 2,
		requirements: ["reputation"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	246: {
		id: "246",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c246.name",
		descriptionKey: "games.arknova.cards.c246.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 2,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	247: {
		id: "247",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c247.name",
		descriptionKey: "games.arknova.cards.c247.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["primate"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	248: {
		id: "248",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c248.name",
		descriptionKey: "games.arknova.cards.c248.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	249: {
		id: "249",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c249.name",
		descriptionKey: "games.arknova.cards.c249.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	250: {
		id: "250",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c250.name",
		descriptionKey: "games.arknova.cards.c250.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	251: {
		id: "251",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c251.name",
		descriptionKey: "games.arknova.cards.c251.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["bear", "predator"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	252: {
		id: "252",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c252.name",
		descriptionKey: "games.arknova.cards.c252.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["predator"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	253: {
		id: "253",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c253.name",
		descriptionKey: "games.arknova.cards.c253.description",
		marine: !1,
		wave: !1,
		strength: 6,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	254: {
		id: "254",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c254.name",
		descriptionKey: "games.arknova.cards.c254.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 1,
		conservation: 1
	},
	255: {
		id: "255",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c255.name",
		descriptionKey: "games.arknova.cards.c255.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 1,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	256: {
		id: "256",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c256.name",
		descriptionKey: "games.arknova.cards.c256.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 1,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	257: {
		id: "257",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c257.name",
		descriptionKey: "games.arknova.cards.c257.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	258: {
		id: "258",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c258.name",
		descriptionKey: "games.arknova.cards.c258.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: ["bird"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	259: {
		id: "259",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c259.name",
		descriptionKey: "games.arknova.cards.c259.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: ["reptile"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	260: {
		id: "260",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c260.name",
		descriptionKey: "games.arknova.cards.c260.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: ["herbivore"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	261: {
		id: "261",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c261.name",
		descriptionKey: "games.arknova.cards.c261.description",
		marine: !1,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 1,
		reputation: 0,
		conservation: 1
	},
	262: {
		id: "262",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c262.name",
		descriptionKey: "games.arknova.cards.c262.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	263: {
		id: "263",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c263.name",
		descriptionKey: "games.arknova.cards.c263.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII", "reputation"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	264: {
		id: "264",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c264.name",
		descriptionKey: "games.arknova.cards.c264.description",
		marine: !1,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: ["primate"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	265: {
		id: "265",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c265.name",
		descriptionKey: "games.arknova.cards.c265.description",
		marine: !0,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["kiosk"],
		tags: [],
		person: !1,
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	266: {
		id: "266",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c266.name",
		descriptionKey: "games.arknova.cards.c266.description",
		marine: !0,
		wave: !0,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	267: {
		id: "267",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c267.name",
		descriptionKey: "games.arknova.cards.c267.description",
		marine: !0,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["appeal"],
		tags: ["predator"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	268: {
		id: "268",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c268.name",
		descriptionKey: "games.arknova.cards.c268.description",
		marine: !0,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["europe"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	269: {
		id: "269",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c269.name",
		descriptionKey: "games.arknova.cards.c269.description",
		marine: !0,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["australia"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	270: {
		id: "270",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c270.name",
		descriptionKey: "games.arknova.cards.c270.description",
		marine: !0,
		wave: !0,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science", "seaAnimal"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	271: {
		id: "271",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c271.name",
		descriptionKey: "games.arknova.cards.c271.description",
		marine: !0,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	272: {
		id: "272",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c272.name",
		descriptionKey: "games.arknova.cards.c272.description",
		marine: !0,
		wave: !1,
		strength: 5,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	273: {
		id: "273",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c273.name",
		descriptionKey: "games.arknova.cards.c273.description",
		marine: !0,
		wave: !1,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	274: {
		id: "274",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c274.name",
		descriptionKey: "games.arknova.cards.c274.description",
		marine: !0,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 1,
		reputation: 0,
		conservation: 0
	},
	275: {
		id: "275",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c275.name",
		descriptionKey: "games.arknova.cards.c275.description",
		marine: !0,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: ["reputation"],
		tags: ["pet"],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	276: {
		id: "276",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c276.name",
		descriptionKey: "games.arknova.cards.c276.description",
		marine: !0,
		wave: !1,
		strength: 6,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !0,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	277: {
		id: "277",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c277.name",
		descriptionKey: "games.arknova.cards.c277.description",
		marine: !0,
		wave: !0,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [
			"science",
			"science",
			"seaAnimal"
		],
		tags: ["science"],
		person: !1,
		appeal: 0,
		reputation: 3,
		conservation: 0
	},
	278: {
		id: "278",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c278.name",
		descriptionKey: "games.arknova.cards.c278.description",
		marine: !0,
		wave: !1,
		strength: 6,
		rock: 1,
		water: 1,
		requirements: [
			"sponsorsII",
			"americas",
			"reputation"
		],
		tags: [
			"seaAnimal",
			"herbivore",
			"primate"
		],
		person: !1,
		appeal: 4,
		reputation: 1,
		conservation: 2
	},
	279: {
		id: "279",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c279.name",
		descriptionKey: "games.arknova.cards.c279.description",
		marine: !0,
		wave: !0,
		strength: 4,
		rock: 0,
		water: 0,
		requirements: ["sponsorsII"],
		tags: [],
		person: !1,
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	280: {
		id: "280",
		kind: "sponsor",
		nameKey: "games.arknova.cards.c280.name",
		descriptionKey: "games.arknova.cards.c280.description",
		marine: !0,
		wave: !1,
		strength: 3,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [],
		person: !1,
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	401: {
		id: "401",
		kind: "animal",
		nameKey: "games.arknova.cards.c401.name",
		descriptionKey: "games.arknova.cards.c401.description",
		marine: !1,
		size: 5,
		price: 17,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"predator",
			"predator",
			"africa"
		],
		abilities: [{
			ability: "SPRINT",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	402: {
		id: "402",
		kind: "animal",
		nameKey: "games.arknova.cards.c402.name",
		descriptionKey: "games.arknova.cards.c402.description",
		marine: !1,
		size: 4,
		price: 16,
		rock: 0,
		water: 0,
		requirements: [
			"predator",
			"predator",
			"predator"
		],
		tags: ["predator", "africa"],
		abilities: [{
			ability: "PACK",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	403: {
		id: "403",
		kind: "animal",
		nameKey: "games.arknova.cards.c403.name",
		descriptionKey: "games.arknova.cards.c403.description",
		marine: !1,
		size: 3,
		price: 20,
		rock: 1,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["predator", "africa"],
		abilities: [{
			ability: "HUNTER",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 1
	},
	404: {
		id: "404",
		kind: "animal",
		nameKey: "games.arknova.cards.c404.name",
		descriptionKey: "games.arknova.cards.c404.description",
		marine: !1,
		size: 2,
		price: 9,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "africa"],
		abilities: [{
			ability: "HUNTER",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	405: {
		id: "405",
		kind: "animal",
		nameKey: "games.arknova.cards.c405.name",
		descriptionKey: "games.arknova.cards.c405.description",
		marine: !1,
		size: 1,
		price: 8,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "africa"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	406: {
		id: "406",
		kind: "animal",
		nameKey: "games.arknova.cards.c406.name",
		descriptionKey: "games.arknova.cards.c406.description",
		marine: !1,
		size: 5,
		price: 30,
		rock: 0,
		water: 0,
		requirements: [
			"asia",
			"asia",
			"asia"
		],
		tags: ["predator", "asia"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 10,
		reputation: 1,
		conservation: 2
	},
	407: {
		id: "407",
		kind: "animal",
		nameKey: "games.arknova.cards.c407.name",
		descriptionKey: "games.arknova.cards.c407.description",
		marine: !1,
		size: 4,
		price: 26,
		rock: 0,
		water: 2,
		requirements: ["science", "science"],
		tags: ["predator", "asia"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 1,
		conservation: 2
	},
	408: {
		id: "408",
		kind: "animal",
		nameKey: "games.arknova.cards.c408.name",
		descriptionKey: "games.arknova.cards.c408.description",
		marine: !1,
		size: 3,
		price: 14,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"predator",
			"bear",
			"asia"
		],
		abilities: [{
			ability: "BOOST_ASSOCIATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	409: {
		id: "409",
		kind: "animal",
		nameKey: "games.arknova.cards.c409.name",
		descriptionKey: "games.arknova.cards.c409.description",
		marine: !1,
		size: 2,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: [
			"predator",
			"bear",
			"asia"
		],
		abilities: [{
			ability: "ACTION_ASSOCIATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	410: {
		id: "410",
		kind: "animal",
		nameKey: "games.arknova.cards.c410.name",
		descriptionKey: "games.arknova.cards.c410.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "asia"],
		abilities: [{
			ability: "HUNTER",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	411: {
		id: "411",
		kind: "animal",
		nameKey: "games.arknova.cards.c411.name",
		descriptionKey: "games.arknova.cards.c411.description",
		marine: !1,
		size: 5,
		price: 22,
		rock: 0,
		water: 0,
		requirements: [
			"predator",
			"predator",
			"animalsII"
		],
		tags: [
			"predator",
			"bear",
			"americas"
		],
		abilities: [{
			ability: "INVENTIVE_BEAR",
			value: ""
		}, {
			ability: "FULL_THROATED",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	412: {
		id: "412",
		kind: "animal",
		nameKey: "games.arknova.cards.c412.name",
		descriptionKey: "games.arknova.cards.c412.description",
		marine: !1,
		size: 4,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["americas"],
		tags: ["predator", "americas"],
		abilities: [{
			ability: "HUNTER",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	413: {
		id: "413",
		kind: "animal",
		nameKey: "games.arknova.cards.c413.name",
		descriptionKey: "games.arknova.cards.c413.description",
		marine: !1,
		size: 3,
		price: 10,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["predator", "americas"],
		abilities: [{
			ability: "JUMPING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	414: {
		id: "414",
		kind: "animal",
		nameKey: "games.arknova.cards.c414.name",
		descriptionKey: "games.arknova.cards.c414.description",
		marine: !1,
		size: 2,
		price: 11,
		rock: 1,
		water: 0,
		requirements: [],
		tags: [
			"predator",
			"bear",
			"americas"
		],
		abilities: [{
			ability: "INVENTIVE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	415: {
		id: "415",
		kind: "animal",
		nameKey: "games.arknova.cards.c415.name",
		descriptionKey: "games.arknova.cards.c415.description",
		marine: !1,
		size: 1,
		price: 11,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"predator",
			"bear",
			"americas"
		],
		abilities: [{
			ability: "BOOST_ASSOCIATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	416: {
		id: "416",
		kind: "animal",
		nameKey: "games.arknova.cards.c416.name",
		descriptionKey: "games.arknova.cards.c416.description",
		marine: !1,
		size: 5,
		price: 20,
		rock: 0,
		water: 1,
		requirements: ["bear", "animalsII"],
		tags: [
			"predator",
			"bear",
			"europe"
		],
		abilities: [{
			ability: "MULTIPLIER_ASSOCIATION",
			value: ""
		}, {
			ability: "FULL_THROATED",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	417: {
		id: "417",
		kind: "animal",
		nameKey: "games.arknova.cards.c417.name",
		descriptionKey: "games.arknova.cards.c417.description",
		marine: !1,
		size: 4,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "europe"],
		abilities: [{
			ability: "PACK",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	418: {
		id: "418",
		kind: "animal",
		nameKey: "games.arknova.cards.c418.name",
		descriptionKey: "games.arknova.cards.c418.description",
		marine: !1,
		size: 3,
		price: 11,
		rock: 0,
		water: 0,
		requirements: ["europe", "europe"],
		tags: ["predator", "europe"],
		abilities: [{
			ability: "ICONIC_ANIMAL",
			value: "Europe"
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	419: {
		id: "419",
		kind: "animal",
		nameKey: "games.arknova.cards.c419.name",
		descriptionKey: "games.arknova.cards.c419.description",
		marine: !1,
		size: 2,
		price: 5,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "europe"],
		abilities: [{
			ability: "BOOST_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	420: {
		id: "420",
		kind: "animal",
		nameKey: "games.arknova.cards.c420.name",
		descriptionKey: "games.arknova.cards.c420.description",
		marine: !1,
		size: 1,
		price: 4,
		rock: 0,
		water: 0,
		requirements: ["europe"],
		tags: ["predator", "europe"],
		abilities: [{
			ability: "HUNTER",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	421: {
		id: "421",
		kind: "animal",
		nameKey: "games.arknova.cards.c421.name",
		descriptionKey: "games.arknova.cards.c421.description",
		marine: !1,
		size: 5,
		price: 17,
		rock: 1,
		water: 1,
		requirements: ["animalsII"],
		tags: ["predator", "australia"],
		abilities: [{
			ability: "FULL_THROATED",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	422: {
		id: "422",
		kind: "animal",
		nameKey: "games.arknova.cards.c422.name",
		descriptionKey: "games.arknova.cards.c422.description",
		marine: !1,
		size: 4,
		price: 18,
		rock: 0,
		water: 1,
		requirements: ["Partner Zoo"],
		tags: ["predator", "australia"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 1
	},
	423: {
		id: "423",
		kind: "animal",
		nameKey: "games.arknova.cards.c423.name",
		descriptionKey: "games.arknova.cards.c423.description",
		marine: !1,
		size: 3,
		price: 17,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["predator", "australia"],
		abilities: [{
			ability: "PACK",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	424: {
		id: "424",
		kind: "animal",
		nameKey: "games.arknova.cards.c424.name",
		descriptionKey: "games.arknova.cards.c424.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["predator", "australia"],
		abilities: [{
			ability: "PACK",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	425: {
		id: "425",
		kind: "animal",
		nameKey: "games.arknova.cards.c425.name",
		descriptionKey: "games.arknova.cards.c425.description",
		marine: !1,
		size: 1,
		price: 11,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["predator", "australia"],
		abilities: [{
			ability: "POUCH",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 1,
		conservation: 0
	},
	426: {
		id: "426",
		kind: "animal",
		nameKey: "games.arknova.cards.c426.name",
		descriptionKey: "games.arknova.cards.c426.description",
		marine: !1,
		size: 5,
		price: 36,
		rock: 0,
		water: 0,
		requirements: ["animalsII"],
		tags: [
			"herbivore",
			"africa",
			"africa"
		],
		abilities: [{
			ability: "RESISTANCE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 10,
		reputation: 1,
		conservation: 0
	},
	427: {
		id: "427",
		kind: "animal",
		nameKey: "games.arknova.cards.c427.name",
		descriptionKey: "games.arknova.cards.c427.description",
		marine: !1,
		size: 4,
		price: 24,
		rock: 1,
		water: 0,
		requirements: ["science"],
		tags: ["herbivore", "africa"],
		abilities: [{
			ability: "ASSERTION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	428: {
		id: "428",
		kind: "animal",
		nameKey: "games.arknova.cards.c428.name",
		descriptionKey: "games.arknova.cards.c428.description",
		marine: !1,
		size: 3,
		price: 16,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "africa"],
		abilities: [{
			ability: "BOOST_SPONSORS",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	429: {
		id: "429",
		kind: "animal",
		nameKey: "games.arknova.cards.c429.name",
		descriptionKey: "games.arknova.cards.c429.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [
			"africa",
			"africa",
			"africa"
		],
		tags: ["herbivore", "africa"],
		abilities: [{
			ability: "BOOST_SPONSORS",
			value: ""
		}, {
			ability: "FLOCK_ANIMAL",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 1,
		conservation: 0
	},
	430: {
		id: "430",
		kind: "animal",
		nameKey: "games.arknova.cards.c430.name",
		descriptionKey: "games.arknova.cards.c430.description",
		marine: !1,
		size: 2,
		price: 15,
		rock: 0,
		water: 1,
		requirements: ["Partner Zoo"],
		tags: ["herbivore", "africa"],
		abilities: [{
			ability: "ACTION_SPONSORS",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	431: {
		id: "431",
		kind: "animal",
		nameKey: "games.arknova.cards.c431.name",
		descriptionKey: "games.arknova.cards.c431.description",
		marine: !1,
		size: 5,
		price: 33,
		rock: 0,
		water: 1,
		requirements: ["animalsII"],
		tags: [
			"herbivore",
			"asia",
			"asia"
		],
		abilities: [{
			ability: "RESISTANCE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 0,
		conservation: 1
	},
	432: {
		id: "432",
		kind: "animal",
		nameKey: "games.arknova.cards.c432.name",
		descriptionKey: "games.arknova.cards.c432.description",
		marine: !1,
		size: 4,
		price: 25,
		rock: 0,
		water: 0,
		requirements: ["animalsII"],
		tags: ["herbivore", "asia"],
		abilities: [{
			ability: "ASSERTION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	433: {
		id: "433",
		kind: "animal",
		nameKey: "games.arknova.cards.c433.name",
		descriptionKey: "games.arknova.cards.c433.description",
		marine: !1,
		size: 3,
		price: 27,
		rock: 0,
		water: 0,
		requirements: [
			"herbivore",
			"bear",
			"Partner Zoo"
		],
		tags: [
			"herbivore",
			"bear",
			"asia"
		],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 10,
		reputation: 1,
		conservation: 2
	},
	434: {
		id: "434",
		kind: "animal",
		nameKey: "games.arknova.cards.c434.name",
		descriptionKey: "games.arknova.cards.c434.description",
		marine: !1,
		size: 2,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["science", "science"],
		tags: [
			"herbivore",
			"bear",
			"asia"
		],
		abilities: [{
			ability: "MULTIPLIER_SPONSORS",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	435: {
		id: "435",
		kind: "animal",
		nameKey: "games.arknova.cards.c435.name",
		descriptionKey: "games.arknova.cards.c435.description",
		marine: !1,
		size: 2,
		price: 17,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "asia"],
		abilities: [{
			ability: "DIGGING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 1,
		conservation: 0
	},
	436: {
		id: "436",
		kind: "animal",
		nameKey: "games.arknova.cards.c436.name",
		descriptionKey: "games.arknova.cards.c436.description",
		marine: !1,
		size: 5,
		price: 18,
		rock: 0,
		water: 0,
		requirements: [
			"americas",
			"americas",
			"americas"
		],
		tags: [
			"herbivore",
			"americas",
			"americas"
		],
		abilities: [{
			ability: "ICONIC_ANIMAL",
			value: "Americas"
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	437: {
		id: "437",
		kind: "animal",
		nameKey: "games.arknova.cards.c437.name",
		descriptionKey: "games.arknova.cards.c437.description",
		marine: !1,
		size: 4,
		price: 13,
		rock: 0,
		water: 0,
		requirements: ["americas"],
		tags: ["herbivore", "americas"],
		abilities: [{
			ability: "SPONSOR_MAGNET",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	438: {
		id: "438",
		kind: "animal",
		nameKey: "games.arknova.cards.c438.name",
		descriptionKey: "games.arknova.cards.c438.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "americas"],
		abilities: [{
			ability: "FLOCK_ANIMAL",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	439: {
		id: "439",
		kind: "animal",
		nameKey: "games.arknova.cards.c439.name",
		descriptionKey: "games.arknova.cards.c439.description",
		marine: !1,
		size: 2,
		price: 10,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "americas"],
		abilities: [{
			ability: "FLOCK_ANIMAL",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	440: {
		id: "440",
		kind: "animal",
		nameKey: "games.arknova.cards.c440.name",
		descriptionKey: "games.arknova.cards.c440.description",
		marine: !1,
		size: 2,
		price: 15,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["herbivore", "americas"],
		abilities: [{
			ability: "DIGGING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 1
	},
	441: {
		id: "441",
		kind: "animal",
		nameKey: "games.arknova.cards.c441.name",
		descriptionKey: "games.arknova.cards.c441.description",
		marine: !1,
		size: 5,
		price: 19,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: [
			"herbivore",
			"europe",
			"europe"
		],
		abilities: [{
			ability: "SPONSOR_MAGNET",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	442: {
		id: "442",
		kind: "animal",
		nameKey: "games.arknova.cards.c442.name",
		descriptionKey: "games.arknova.cards.c442.description",
		marine: !1,
		size: 4,
		price: 19,
		rock: 0,
		water: 0,
		requirements: ["herbivore", "herbivore"],
		tags: ["herbivore", "europe"],
		abilities: [{
			ability: "MULTIPLIER_SPONSORS",
			value: ""
		}, {
			ability: "FLOCK_ANIMAL",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	443: {
		id: "443",
		kind: "animal",
		nameKey: "games.arknova.cards.c443.name",
		descriptionKey: "games.arknova.cards.c443.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "europe"],
		abilities: [{
			ability: "FLOCK_ANIMAL",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	444: {
		id: "444",
		kind: "animal",
		nameKey: "games.arknova.cards.c444.name",
		descriptionKey: "games.arknova.cards.c444.description",
		marine: !1,
		size: 2,
		price: 10,
		rock: 2,
		water: 0,
		requirements: [],
		tags: ["herbivore", "europe"],
		abilities: [{
			ability: "JUMPING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	445: {
		id: "445",
		kind: "animal",
		nameKey: "games.arknova.cards.c445.name",
		descriptionKey: "games.arknova.cards.c445.description",
		marine: !1,
		size: 1,
		price: 8,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "europe"],
		abilities: [{
			ability: "DIGGING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	446: {
		id: "446",
		kind: "animal",
		nameKey: "games.arknova.cards.c446.name",
		descriptionKey: "games.arknova.cards.c446.description",
		marine: !1,
		size: 5,
		price: 25,
		rock: 0,
		water: 2,
		requirements: ["animalsII"],
		tags: [
			"herbivore",
			"australia",
			"australia"
		],
		abilities: [{
			ability: "DIGGING",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 1
	},
	447: {
		id: "447",
		kind: "animal",
		nameKey: "games.arknova.cards.c447.name",
		descriptionKey: "games.arknova.cards.c447.description",
		marine: !1,
		size: 4,
		price: 23,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "australia"],
		abilities: [{
			ability: "POUCH",
			value: 2
		}, {
			ability: "FLOCK_ANIMAL",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	448: {
		id: "448",
		kind: "animal",
		nameKey: "games.arknova.cards.c448.name",
		descriptionKey: "games.arknova.cards.c448.description",
		marine: !1,
		size: 3,
		price: 21,
		rock: 1,
		water: 0,
		requirements: ["australia"],
		tags: [
			"herbivore",
			"bear",
			"australia"
		],
		abilities: [{
			ability: "POUCH",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 1,
		conservation: 0
	},
	449: {
		id: "449",
		kind: "animal",
		nameKey: "games.arknova.cards.c449.name",
		descriptionKey: "games.arknova.cards.c449.description",
		marine: !1,
		size: 2,
		price: 10,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["herbivore", "australia"],
		abilities: [{
			ability: "VENOM",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	450: {
		id: "450",
		kind: "animal",
		nameKey: "games.arknova.cards.c450.name",
		descriptionKey: "games.arknova.cards.c450.description",
		marine: !1,
		size: 2,
		price: 9,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["herbivore", "australia"],
		abilities: [{
			ability: "POUCH",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	451: {
		id: "451",
		kind: "animal",
		nameKey: "games.arknova.cards.c451.name",
		descriptionKey: "games.arknova.cards.c451.description",
		marine: !1,
		size: 5,
		price: 32,
		rock: 1,
		water: 0,
		requirements: [
			"primate",
			"primate",
			"animalsII"
		],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "DOMINANCE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 10,
		reputation: 0,
		conservation: 2
	},
	452: {
		id: "452",
		kind: "animal",
		nameKey: "games.arknova.cards.c452.name",
		descriptionKey: "games.arknova.cards.c452.description",
		marine: !1,
		size: 1,
		price: 10,
		rock: 0,
		water: 0,
		requirements: ["africa", "africa"],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "ICONIC_ANIMAL",
			value: "africa"
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 1,
		reputation: 0,
		conservation: 0
	},
	453: {
		id: "453",
		kind: "animal",
		nameKey: "games.arknova.cards.c453.name",
		descriptionKey: "games.arknova.cards.c453.description",
		marine: !1,
		size: 4,
		price: 20,
		rock: 0,
		water: 0,
		requirements: ["africa"],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "ACTION_CARDS",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	454: {
		id: "454",
		kind: "animal",
		nameKey: "games.arknova.cards.c454.name",
		descriptionKey: "games.arknova.cards.c454.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	455: {
		id: "455",
		kind: "animal",
		nameKey: "games.arknova.cards.c455.name",
		descriptionKey: "games.arknova.cards.c455.description",
		marine: !1,
		size: 3,
		price: 13,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	456: {
		id: "456",
		kind: "animal",
		nameKey: "games.arknova.cards.c456.name",
		descriptionKey: "games.arknova.cards.c456.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "PILFERING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	457: {
		id: "457",
		kind: "animal",
		nameKey: "games.arknova.cards.c457.name",
		descriptionKey: "games.arknova.cards.c457.description",
		marine: !1,
		size: 5,
		price: 28,
		rock: 0,
		water: 0,
		requirements: [
			"primate",
			"primate",
			"primate"
		],
		tags: [
			"primate",
			"primate",
			"africa"
		],
		abilities: [{
			ability: "MULTIPLIER_CARD",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 9,
		reputation: 0,
		conservation: 2
	},
	458: {
		id: "458",
		kind: "animal",
		nameKey: "games.arknova.cards.c458.name",
		descriptionKey: "games.arknova.cards.c458.description",
		marine: !1,
		size: 3,
		price: 18,
		rock: 0,
		water: 1,
		requirements: ["asia"],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "PILFERING_2",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	459: {
		id: "459",
		kind: "animal",
		nameKey: "games.arknova.cards.c459.name",
		descriptionKey: "games.arknova.cards.c459.description",
		marine: !1,
		size: 4,
		price: 17,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "INVENTIVE_PRIMARY",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 1,
		conservation: 0
	},
	460: {
		id: "460",
		kind: "animal",
		nameKey: "games.arknova.cards.c460.name",
		descriptionKey: "games.arknova.cards.c460.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	461: {
		id: "461",
		kind: "animal",
		nameKey: "games.arknova.cards.c461.name",
		descriptionKey: "games.arknova.cards.c461.description",
		marine: !1,
		size: 1,
		price: 14,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "JUMPING",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 2,
		conservation: 0
	},
	462: {
		id: "462",
		kind: "animal",
		nameKey: "games.arknova.cards.c462.name",
		descriptionKey: "games.arknova.cards.c462.description",
		marine: !1,
		size: 3,
		price: 13,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "JUMPING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	463: {
		id: "463",
		kind: "animal",
		nameKey: "games.arknova.cards.c463.name",
		descriptionKey: "games.arknova.cards.c463.description",
		marine: !1,
		size: 2,
		price: 11,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "PILFERING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	464: {
		id: "464",
		kind: "animal",
		nameKey: "games.arknova.cards.c464.name",
		descriptionKey: "games.arknova.cards.c464.description",
		marine: !1,
		size: 4,
		price: 17,
		rock: 0,
		water: 0,
		requirements: ["primate"],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "INVENTIVE_PRIMARY",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 1
	},
	465: {
		id: "465",
		kind: "animal",
		nameKey: "games.arknova.cards.c465.name",
		descriptionKey: "games.arknova.cards.c465.description",
		marine: !1,
		size: 1,
		price: 10,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	466: {
		id: "466",
		kind: "animal",
		nameKey: "games.arknova.cards.c466.name",
		descriptionKey: "games.arknova.cards.c466.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "BOOST_CARD",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	467: {
		id: "467",
		kind: "animal",
		nameKey: "games.arknova.cards.c467.name",
		descriptionKey: "games.arknova.cards.c467.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	468: {
		id: "468",
		kind: "animal",
		nameKey: "games.arknova.cards.c468.name",
		descriptionKey: "games.arknova.cards.c468.description",
		marine: !1,
		size: 1,
		price: 15,
		rock: 0,
		water: 0,
		requirements: ["science", "science"],
		tags: ["primate", "americas"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 1,
		conservation: 1
	},
	469: {
		id: "469",
		kind: "animal",
		nameKey: "games.arknova.cards.c469.name",
		descriptionKey: "games.arknova.cards.c469.description",
		marine: !1,
		size: 5,
		price: 13,
		rock: 0,
		water: 1,
		requirements: [
			"reptile",
			"reptile",
			"reptile"
		],
		tags: ["reptile", "africa"],
		abilities: [{
			ability: "SNAPPING_2",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 3
		}],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	470: {
		id: "470",
		kind: "animal",
		nameKey: "games.arknova.cards.c470.name",
		descriptionKey: "games.arknova.cards.c470.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: ["africa", "reptile"],
		tags: ["reptile", "africa"],
		abilities: [{
			ability: "VENOM",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	471: {
		id: "471",
		kind: "animal",
		nameKey: "games.arknova.cards.c471.name",
		descriptionKey: "games.arknova.cards.c471.description",
		marine: !1,
		size: 3,
		price: 22,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["reptile", "africa"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 1
	},
	472: {
		id: "472",
		kind: "animal",
		nameKey: "games.arknova.cards.c472.name",
		descriptionKey: "games.arknova.cards.c472.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["reptile", "africa"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	473: {
		id: "473",
		kind: "animal",
		nameKey: "games.arknova.cards.c473.name",
		descriptionKey: "games.arknova.cards.c473.description",
		marine: !1,
		size: 1,
		price: 9,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["reptile", "africa"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	474: {
		id: "474",
		kind: "animal",
		nameKey: "games.arknova.cards.c474.name",
		descriptionKey: "games.arknova.cards.c474.description",
		marine: !1,
		size: 2,
		price: 14,
		rock: 0,
		water: 0,
		requirements: ["reptile", "reptile"],
		tags: ["reptile", "asia"],
		abilities: [{
			ability: "CONSTRICTION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	475: {
		id: "475",
		kind: "animal",
		nameKey: "games.arknova.cards.c475.name",
		descriptionKey: "games.arknova.cards.c475.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: [
			"science",
			"science",
			"animalsII"
		],
		tags: ["reptile", "asia"],
		abilities: [{
			ability: "HYPNOSIS",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	476: {
		id: "476",
		kind: "animal",
		nameKey: "games.arknova.cards.c476.name",
		descriptionKey: "games.arknova.cards.c476.description",
		marine: !1,
		size: 3,
		price: 14,
		rock: 0,
		water: 0,
		requirements: ["asia", "asia"],
		tags: ["reptile", "asia"],
		abilities: [{
			ability: "ICONIC_ANIMAL",
			value: "asia"
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	477: {
		id: "477",
		kind: "animal",
		nameKey: "games.arknova.cards.c477.name",
		descriptionKey: "games.arknova.cards.c477.description",
		marine: !1,
		size: 1,
		price: 14,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["reptile", "asia"],
		abilities: [{
			ability: "SNAPPING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	478: {
		id: "478",
		kind: "animal",
		nameKey: "games.arknova.cards.c478.name",
		descriptionKey: "games.arknova.cards.c478.description",
		marine: !1,
		size: 1,
		price: 8,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "asia"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	479: {
		id: "479",
		kind: "animal",
		nameKey: "games.arknova.cards.c479.name",
		descriptionKey: "games.arknova.cards.c479.description",
		marine: !1,
		size: 4,
		price: 18,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "americas"],
		abilities: [{
			ability: "SNAPPING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	480: {
		id: "480",
		kind: "animal",
		nameKey: "games.arknova.cards.c480.name",
		descriptionKey: "games.arknova.cards.c480.description",
		marine: !1,
		size: 4,
		price: 16,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "americas"],
		abilities: [{
			ability: "SNAPPING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	481: {
		id: "481",
		kind: "animal",
		nameKey: "games.arknova.cards.c481.name",
		descriptionKey: "games.arknova.cards.c481.description",
		marine: !1,
		size: 3,
		price: 30,
		rock: 0,
		water: 0,
		requirements: [
			"americas",
			"americas",
			"animalsII"
		],
		tags: ["reptile", "americas"],
		abilities: [{
			ability: "SUN_BATHING",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 8,
		reputation: 1,
		conservation: 2
	},
	482: {
		id: "482",
		kind: "animal",
		nameKey: "games.arknova.cards.c482.name",
		descriptionKey: "games.arknova.cards.c482.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["reptile", "americas"],
		abilities: [{
			ability: "CONSTRICTION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	483: {
		id: "483",
		kind: "animal",
		nameKey: "games.arknova.cards.c483.name",
		descriptionKey: "games.arknova.cards.c483.description",
		marine: !1,
		size: 2,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["science", "science"],
		tags: ["reptile", "americas"],
		abilities: [{
			ability: "CONSTRICTION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	484: {
		id: "484",
		kind: "animal",
		nameKey: "games.arknova.cards.c484.name",
		descriptionKey: "games.arknova.cards.c484.description",
		marine: !1,
		size: 1,
		price: 9,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "europe"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	485: {
		id: "485",
		kind: "animal",
		nameKey: "games.arknova.cards.c485.name",
		descriptionKey: "games.arknova.cards.c485.description",
		marine: !1,
		size: 1,
		price: 10,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["reptile", "europe"],
		abilities: [{
			ability: "HYPNOSIS",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	486: {
		id: "486",
		kind: "animal",
		nameKey: "games.arknova.cards.c486.name",
		descriptionKey: "games.arknova.cards.c486.description",
		marine: !1,
		size: 1,
		price: 4,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["reptile", "europe"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	487: {
		id: "487",
		kind: "animal",
		nameKey: "games.arknova.cards.c487.name",
		descriptionKey: "games.arknova.cards.c487.description",
		marine: !1,
		size: 1,
		price: 8,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "europe"],
		abilities: [{
			ability: "CLEVER",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	488: {
		id: "488",
		kind: "animal",
		nameKey: "games.arknova.cards.c488.name",
		descriptionKey: "games.arknova.cards.c488.description",
		marine: !1,
		size: 1,
		price: 4,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["reptile", "europe"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	489: {
		id: "489",
		kind: "animal",
		nameKey: "games.arknova.cards.c489.name",
		descriptionKey: "games.arknova.cards.c489.description",
		marine: !1,
		size: 5,
		price: 23,
		rock: 0,
		water: 1,
		requirements: ["Partner Zoo"],
		tags: [
			"reptile",
			"reptile",
			"australia"
		],
		abilities: [{
			ability: "SNAPPING_2",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 3
		}],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	490: {
		id: "490",
		kind: "animal",
		nameKey: "games.arknova.cards.c490.name",
		descriptionKey: "games.arknova.cards.c490.description",
		marine: !1,
		size: 3,
		price: 15,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["reptile", "australia"],
		abilities: [{
			ability: "SCAVENGING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	491: {
		id: "491",
		kind: "animal",
		nameKey: "games.arknova.cards.c491.name",
		descriptionKey: "games.arknova.cards.c491.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["reptile", "australia"],
		abilities: [{
			ability: "SPRINT",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	492: {
		id: "492",
		kind: "animal",
		nameKey: "games.arknova.cards.c492.name",
		descriptionKey: "games.arknova.cards.c492.description",
		marine: !1,
		size: 2,
		price: 10,
		rock: 1,
		water: 0,
		requirements: ["australia", "science"],
		tags: ["reptile", "australia"],
		abilities: [{
			ability: "VENOM",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	493: {
		id: "493",
		kind: "animal",
		nameKey: "games.arknova.cards.c493.name",
		descriptionKey: "games.arknova.cards.c493.description",
		marine: !1,
		size: 1,
		price: 6,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["reptile", "australia"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "reptile",
			capacity: 0
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	494: {
		id: "494",
		kind: "animal",
		nameKey: "games.arknova.cards.c494.name",
		descriptionKey: "games.arknova.cards.c494.description",
		marine: !1,
		size: 5,
		price: 20,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "africa"],
		abilities: [{
			ability: "SPRINT",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 4
		}],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	495: {
		id: "495",
		kind: "animal",
		nameKey: "games.arknova.cards.c495.name",
		descriptionKey: "games.arknova.cards.c495.description",
		marine: !1,
		size: 4,
		price: 14,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "africa"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 1
	},
	496: {
		id: "496",
		kind: "animal",
		nameKey: "games.arknova.cards.c496.name",
		descriptionKey: "games.arknova.cards.c496.description",
		marine: !1,
		size: 3,
		price: 10,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "africa"],
		abilities: [{
			ability: "SCAVENGING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	497: {
		id: "497",
		kind: "animal",
		nameKey: "games.arknova.cards.c497.name",
		descriptionKey: "games.arknova.cards.c497.description",
		marine: !1,
		size: 2,
		price: 15,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["bird", "africa"],
		abilities: [{
			ability: "POSTURING",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	498: {
		id: "498",
		kind: "animal",
		nameKey: "games.arknova.cards.c498.name",
		descriptionKey: "games.arknova.cards.c498.description",
		marine: !1,
		size: 1,
		price: 9,
		rock: 0,
		water: 0,
		requirements: ["science", "science"],
		tags: ["bird", "africa"],
		abilities: [],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 3,
		reputation: 0,
		conservation: 1
	},
	499: {
		id: "499",
		kind: "animal",
		nameKey: "games.arknova.cards.c499.name",
		descriptionKey: "games.arknova.cards.c499.description",
		marine: !1,
		size: 5,
		price: 16,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "asia"],
		abilities: [{
			ability: "SCAVENGING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	500: {
		id: "500",
		kind: "animal",
		nameKey: "games.arknova.cards.c500.name",
		descriptionKey: "games.arknova.cards.c500.description",
		marine: !1,
		size: 4,
		price: 20,
		rock: 1,
		water: 0,
		requirements: ["science"],
		tags: ["bird", "asia"],
		abilities: [{
			ability: "SCAVENGING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 5,
		reputation: 1,
		conservation: 1
	},
	501: {
		id: "501",
		kind: "animal",
		nameKey: "games.arknova.cards.c501.name",
		descriptionKey: "games.arknova.cards.c501.description",
		marine: !1,
		size: 3,
		price: 18,
		rock: 0,
		water: 0,
		requirements: ["asia"],
		tags: ["bird", "asia"],
		abilities: [{
			ability: "POSTURING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	502: {
		id: "502",
		kind: "animal",
		nameKey: "games.arknova.cards.c502.name",
		descriptionKey: "games.arknova.cards.c502.description",
		marine: !1,
		size: 2,
		price: 13,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "asia"],
		abilities: [{
			ability: "BOOST_BUILDING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	503: {
		id: "503",
		kind: "animal",
		nameKey: "games.arknova.cards.c503.name",
		descriptionKey: "games.arknova.cards.c503.description",
		marine: !1,
		size: 1,
		price: 11,
		rock: 0,
		water: 0,
		requirements: ["bird", "bird"],
		tags: ["bird", "asia"],
		abilities: [{
			ability: "PERCEPTION_4",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 1,
		conservation: 0
	},
	504: {
		id: "504",
		kind: "animal",
		nameKey: "games.arknova.cards.c504.name",
		descriptionKey: "games.arknova.cards.c504.description",
		marine: !1,
		size: 5,
		price: 17,
		rock: 1,
		water: 0,
		requirements: ["bird"],
		tags: ["bird", "americas"],
		abilities: [{
			ability: "SCAVENGING",
			value: 4
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 7,
		reputation: 1,
		conservation: 0
	},
	505: {
		id: "505",
		kind: "animal",
		nameKey: "games.arknova.cards.c505.name",
		descriptionKey: "games.arknova.cards.c505.description",
		marine: !1,
		size: 4,
		price: 23,
		rock: 0,
		water: 1,
		requirements: ["animalsII"],
		tags: ["bird", "americas"],
		abilities: [{
			ability: "DETERMINATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	506: {
		id: "506",
		kind: "animal",
		nameKey: "games.arknova.cards.c506.name",
		descriptionKey: "games.arknova.cards.c506.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [
			"bird",
			"bird",
			"bird"
		],
		tags: ["bird", "americas"],
		abilities: [{
			ability: "SCAVENGING",
			value: 5
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 9,
		reputation: 0,
		conservation: 0
	},
	507: {
		id: "507",
		kind: "animal",
		nameKey: "games.arknova.cards.c507.name",
		descriptionKey: "games.arknova.cards.c507.description",
		marine: !1,
		size: 2,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "americas"],
		abilities: [{
			ability: "SPRINT",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	508: {
		id: "508",
		kind: "animal",
		nameKey: "games.arknova.cards.c508.name",
		descriptionKey: "games.arknova.cards.c508.description",
		marine: !1,
		size: 1,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["bird", "americas"],
		abilities: [{
			ability: "POSTURING",
			value: 3
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	509: {
		id: "509",
		kind: "animal",
		nameKey: "games.arknova.cards.c509.name",
		descriptionKey: "games.arknova.cards.c509.description",
		marine: !1,
		size: 5,
		price: 20,
		rock: 1,
		water: 0,
		requirements: ["animalsII"],
		tags: ["bird", "europe"],
		abilities: [{
			ability: "DETERMINATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	510: {
		id: "510",
		kind: "animal",
		nameKey: "games.arknova.cards.c510.name",
		descriptionKey: "games.arknova.cards.c510.description",
		marine: !1,
		size: 4,
		price: 9,
		rock: 0,
		water: 0,
		requirements: ["europe"],
		tags: ["bird", "europe"],
		abilities: [{
			ability: "MULTIPLIER_BUILDING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	511: {
		id: "511",
		kind: "animal",
		nameKey: "games.arknova.cards.c511.name",
		descriptionKey: "games.arknova.cards.c511.description",
		marine: !1,
		size: 3,
		price: 16,
		rock: 0,
		water: 1,
		requirements: [],
		tags: ["bird", "europe"],
		abilities: [{
			ability: "POSTURING",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	512: {
		id: "512",
		kind: "animal",
		nameKey: "games.arknova.cards.c512.name",
		descriptionKey: "games.arknova.cards.c512.description",
		marine: !1,
		size: 2,
		price: 10,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["bird", "europe"],
		abilities: [{
			ability: "PERCEPTION_4",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	513: {
		id: "513",
		kind: "animal",
		nameKey: "games.arknova.cards.c513.name",
		descriptionKey: "games.arknova.cards.c513.description",
		marine: !1,
		size: 1,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "europe"],
		abilities: [{
			ability: "PERCEPTION_4",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	514: {
		id: "514",
		kind: "animal",
		nameKey: "games.arknova.cards.c514.name",
		descriptionKey: "games.arknova.cards.c514.description",
		marine: !1,
		size: 5,
		price: 22,
		rock: 0,
		water: 0,
		requirements: ["australia", "australia"],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "PEACOCKING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	515: {
		id: "515",
		kind: "animal",
		nameKey: "games.arknova.cards.c515.name",
		descriptionKey: "games.arknova.cards.c515.description",
		marine: !1,
		size: 4,
		price: 13,
		rock: 0,
		water: 2,
		requirements: [],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "ACTION_BUILDING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	516: {
		id: "516",
		kind: "animal",
		nameKey: "games.arknova.cards.c516.name",
		descriptionKey: "games.arknova.cards.c516.description",
		marine: !1,
		size: 3,
		price: 12,
		rock: 0,
		water: 0,
		requirements: ["Partner Zoo"],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "MULTIPLIER_BUILDING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	517: {
		id: "517",
		kind: "animal",
		nameKey: "games.arknova.cards.c517.name",
		descriptionKey: "games.arknova.cards.c517.description",
		marine: !1,
		size: 2,
		price: 9,
		rock: 0,
		water: 0,
		requirements: ["australia"],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "ICONIC_ANIMAL",
			value: "australia"
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	518: {
		id: "518",
		kind: "animal",
		nameKey: "games.arknova.cards.c518.name",
		descriptionKey: "games.arknova.cards.c518.description",
		marine: !1,
		size: 1,
		price: 15,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "POSTURING",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	519: {
		id: "519",
		kind: "animal",
		nameKey: "games.arknova.cards.c519.name",
		descriptionKey: "games.arknova.cards.c519.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	520: {
		id: "520",
		kind: "animal",
		nameKey: "games.arknova.cards.c520.name",
		descriptionKey: "games.arknova.cards.c520.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	521: {
		id: "521",
		kind: "animal",
		nameKey: "games.arknova.cards.c521.name",
		descriptionKey: "games.arknova.cards.c521.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 1,
		conservation: 0
	},
	522: {
		id: "522",
		kind: "animal",
		nameKey: "games.arknova.cards.c522.name",
		descriptionKey: "games.arknova.cards.c522.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "INVENTIVE",
			value: ""
		}, {
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	523: {
		id: "523",
		kind: "animal",
		nameKey: "games.arknova.cards.c523.name",
		descriptionKey: "games.arknova.cards.c523.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	524: {
		id: "524",
		kind: "animal",
		nameKey: "games.arknova.cards.c524.name",
		descriptionKey: "games.arknova.cards.c524.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "DIGGING",
			value: 1
		}, {
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	525: {
		id: "525",
		kind: "animal",
		nameKey: "games.arknova.cards.c525.name",
		descriptionKey: "games.arknova.cards.c525.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	526: {
		id: "526",
		kind: "animal",
		nameKey: "games.arknova.cards.c526.name",
		descriptionKey: "games.arknova.cards.c526.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	527: {
		id: "527",
		kind: "animal",
		nameKey: "games.arknova.cards.c527.name",
		descriptionKey: "games.arknova.cards.c527.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	528: {
		id: "528",
		kind: "animal",
		nameKey: "games.arknova.cards.c528.name",
		descriptionKey: "games.arknova.cards.c528.description",
		marine: !1,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "POUCH",
			value: 1
		}, {
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	529: {
		id: "529",
		kind: "animal",
		nameKey: "games.arknova.cards.c529.name",
		descriptionKey: "games.arknova.cards.c529.description",
		marine: !0,
		size: 1,
		price: 6,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "australia"],
		abilities: [],
		reef: [{
			ability: "MARK",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	530: {
		id: "530",
		kind: "animal",
		nameKey: "games.arknova.cards.c530.name",
		descriptionKey: "games.arknova.cards.c530.description",
		marine: !0,
		size: 1,
		price: 10,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "australia"],
		abilities: [],
		reef: [{
			ability: "APPEAL",
			value: 2
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	531: {
		id: "531",
		kind: "animal",
		nameKey: "games.arknova.cards.c531.name",
		descriptionKey: "games.arknova.cards.c531.description",
		marine: !0,
		size: 1,
		price: 9,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "asia"],
		abilities: [],
		reef: [{
			ability: "TRADE",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	532: {
		id: "532",
		kind: "animal",
		nameKey: "games.arknova.cards.c532.name",
		descriptionKey: "games.arknova.cards.c532.description",
		marine: !0,
		size: 1,
		price: 4,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal"],
		abilities: [{
			ability: "SEA_ANIMAL_MAGNET",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 0
		}],
		appeal: 1,
		reputation: 0,
		conservation: 0
	},
	533: {
		id: "533",
		kind: "animal",
		nameKey: "games.arknova.cards.c533.name",
		descriptionKey: "games.arknova.cards.c533.description",
		marine: !0,
		size: 2,
		price: 11,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "australia"],
		abilities: [],
		reef: [{
			ability: "POSTURING",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	534: {
		id: "534",
		kind: "animal",
		nameKey: "games.arknova.cards.c534.name",
		descriptionKey: "games.arknova.cards.c534.description",
		marine: !0,
		size: 2,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "australia"],
		abilities: [{
			ability: "VENOM",
			value: 1
		}],
		reef: [{
			ability: "REEF_MONEY",
			value: 3
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	535: {
		id: "535",
		kind: "animal",
		nameKey: "games.arknova.cards.c535.name",
		descriptionKey: "games.arknova.cards.c535.description",
		marine: !0,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "americas"],
		abilities: [{
			ability: "SYMBIOSIS",
			value: ""
		}],
		reef: [{
			ability: "HELPFUL",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	536: {
		id: "536",
		kind: "animal",
		nameKey: "games.arknova.cards.c536.name",
		descriptionKey: "games.arknova.cards.c536.description",
		marine: !0,
		size: 2,
		price: 9,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "africa"],
		abilities: [],
		reef: [{
			ability: "BOOST_SPONSORS",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 4,
		reputation: 0,
		conservation: 0
	},
	537: {
		id: "537",
		kind: "animal",
		nameKey: "games.arknova.cards.c537.name",
		descriptionKey: "games.arknova.cards.c537.description",
		marine: !0,
		size: 2,
		price: 14,
		rock: 0,
		water: 0,
		requirements: ["university"],
		tags: ["seaAnimal", "africa"],
		abilities: [{
			ability: "CONSTRICTION",
			value: ""
		}],
		reef: [{
			ability: "TAKE_CARD_IN_RANGE",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	538: {
		id: "538",
		kind: "animal",
		nameKey: "games.arknova.cards.c538.name",
		descriptionKey: "games.arknova.cards.c538.description",
		marine: !0,
		size: 2,
		price: 16,
		rock: 0,
		water: 0,
		requirements: ["science"],
		tags: ["seaAnimal", "asia"],
		abilities: [{
			ability: "VENOM",
			value: 1
		}],
		reef: [{
			ability: "INVENTIVE",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	539: {
		id: "539",
		kind: "animal",
		nameKey: "games.arknova.cards.c539.name",
		descriptionKey: "games.arknova.cards.c539.description",
		marine: !0,
		size: 1,
		price: 12,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "americas"],
		abilities: [],
		reef: [{
			ability: "CLEVER",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	540: {
		id: "540",
		kind: "animal",
		nameKey: "games.arknova.cards.c540.name",
		descriptionKey: "games.arknova.cards.c540.description",
		marine: !0,
		size: 2,
		price: 15,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "asia"],
		abilities: [{
			ability: "VENOM",
			value: 1
		}],
		reef: [{
			ability: "REPUTATION",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 2
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	541: {
		id: "541",
		kind: "animal",
		nameKey: "games.arknova.cards.c541.name",
		descriptionKey: "games.arknova.cards.c541.description",
		marine: !0,
		size: 2,
		price: 16,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "asia"],
		abilities: [],
		reef: [{
			ability: "DIGGING",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	542: {
		id: "542",
		kind: "animal",
		nameKey: "games.arknova.cards.c542.name",
		descriptionKey: "games.arknova.cards.c542.description",
		marine: !0,
		size: 3,
		price: 22,
		rock: 0,
		water: 0,
		requirements: ["university"],
		tags: ["seaAnimal", "africa"],
		abilities: [],
		reef: [{
			ability: "EXTRA_SHIFT",
			value: ""
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 1
	},
	543: {
		id: "543",
		kind: "animal",
		nameKey: "games.arknova.cards.c543.name",
		descriptionKey: "games.arknova.cards.c543.description",
		marine: !0,
		size: 5,
		price: 23,
		rock: 0,
		water: 0,
		requirements: ["animalsII"],
		tags: ["seaAnimal", "asia"],
		abilities: [{
			ability: "GLIDE",
			value: 3
		}],
		reef: [{
			ability: "CONSERVATION_POINT",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 4
		}],
		appeal: 8,
		reputation: 1,
		conservation: 0
	},
	544: {
		id: "544",
		kind: "animal",
		nameKey: "games.arknova.cards.c544.name",
		descriptionKey: "games.arknova.cards.c544.description",
		marine: !0,
		size: 4,
		price: 20,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"seaAnimal",
			"predator",
			"americas"
		],
		abilities: [],
		reef: [{
			ability: "SHARK_ATTACK",
			value: 1
		}],
		reefDweller: !0,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 3
		}],
		appeal: 5,
		reputation: 1,
		conservation: 0
	},
	545: {
		id: "545",
		kind: "animal",
		nameKey: "games.arknova.cards.c545.name",
		descriptionKey: "games.arknova.cards.c545.description",
		marine: !0,
		size: 4,
		price: 21,
		rock: 0,
		water: 0,
		requirements: ["seaAnimal"],
		tags: [
			"seaAnimal",
			"seaAnimal",
			"africa"
		],
		abilities: [{
			ability: "CUT_DOWN",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 3
		}],
		appeal: 9,
		reputation: 0,
		conservation: 1
	},
	546: {
		id: "546",
		kind: "animal",
		nameKey: "games.arknova.cards.c546.name",
		descriptionKey: "games.arknova.cards.c546.description",
		marine: !0,
		size: 5,
		price: 32,
		rock: 1,
		water: 0,
		requirements: ["animalsII"],
		tags: [
			"seaAnimal",
			"predator",
			"australia"
		],
		abilities: [{
			ability: "SHARK_ATTACK",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 4
		}],
		appeal: 8,
		reputation: 0,
		conservation: 1
	},
	547: {
		id: "547",
		kind: "animal",
		nameKey: "games.arknova.cards.c547.name",
		descriptionKey: "games.arknova.cards.c547.description",
		marine: !0,
		size: 1,
		price: 8,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "europe"],
		abilities: [{
			ability: "SYMBIOSIS",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 0
		}],
		appeal: 3,
		reputation: 0,
		conservation: 0
	},
	548: {
		id: "548",
		kind: "animal",
		nameKey: "games.arknova.cards.c548.name",
		descriptionKey: "games.arknova.cards.c548.description",
		marine: !0,
		size: 1,
		price: 7,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["seaAnimal", "europe"],
		abilities: [{
			ability: "CAMOUFLAGE",
			value: ""
		}, {
			ability: "POUCH",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 2,
		reputation: 0,
		conservation: 0
	},
	549: {
		id: "549",
		kind: "animal",
		nameKey: "games.arknova.cards.c549.name",
		descriptionKey: "games.arknova.cards.c549.description",
		marine: !0,
		size: 3,
		price: 9,
		rock: 1,
		water: 0,
		requirements: ["science"],
		tags: ["seaAnimal", "europe"],
		abilities: [{
			ability: "CAMOUFLAGE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 2
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	550: {
		id: "550",
		kind: "animal",
		nameKey: "games.arknova.cards.c550.name",
		descriptionKey: "games.arknova.cards.c550.description",
		marine: !0,
		size: 3,
		price: 10,
		rock: 0,
		water: 0,
		requirements: ["reputation_3"],
		tags: ["seaAnimal", "europe"],
		abilities: [{
			ability: "GLIDE",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	551: {
		id: "551",
		kind: "animal",
		nameKey: "games.arknova.cards.c551.name",
		descriptionKey: "games.arknova.cards.c551.description",
		marine: !0,
		size: 4,
		price: 23,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"seaAnimal",
			"reptile",
			"europe"
		],
		abilities: [{
			ability: "SCUBA_DIVE",
			value: ""
		}, {
			ability: "MARKETING",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 3
		}, {
			kind: "reptile",
			capacity: 3
		}],
		appeal: 8,
		reputation: 0,
		conservation: 0
	},
	552: {
		id: "552",
		kind: "animal",
		nameKey: "games.arknova.cards.c552.name",
		descriptionKey: "games.arknova.cards.c552.description",
		marine: !0,
		size: 3,
		price: 17,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"seaAnimal",
			"reptile",
			"americas"
		],
		abilities: [{
			ability: "SCUBA_DIVE",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 2
		}, {
			kind: "reptile",
			capacity: 2
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	553: {
		id: "553",
		kind: "animal",
		nameKey: "games.arknova.cards.c553.name",
		descriptionKey: "games.arknova.cards.c553.description",
		marine: !0,
		size: 1,
		price: 15,
		rock: 0,
		water: 0,
		requirements: [],
		tags: [
			"seaAnimal",
			"herbivore",
			"americas"
		],
		abilities: [{
			ability: "ADAPT",
			value: 1
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !1,
		special: [{
			kind: "aquarium",
			capacity: 1
		}],
		appeal: 5,
		reputation: 0,
		conservation: 0
	},
	554: {
		id: "554",
		kind: "animal",
		nameKey: "games.arknova.cards.c554.name",
		descriptionKey: "games.arknova.cards.c554.description",
		marine: !0,
		size: 3,
		price: 18,
		rock: 1,
		water: 1,
		requirements: ["animalsII"],
		tags: [
			"seaAnimal",
			"bird",
			"africa"
		],
		abilities: [{
			ability: "ADAPT",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !0,
		standard: !0,
		special: [{
			kind: "aquarium",
			capacity: 2
		}],
		appeal: 6,
		reputation: 1,
		conservation: 0
	},
	555: {
		id: "555",
		kind: "animal",
		nameKey: "games.arknova.cards.c555.name",
		descriptionKey: "games.arknova.cards.c555.description",
		marine: !0,
		size: 3,
		price: 18,
		rock: 1,
		water: 0,
		requirements: ["science"],
		tags: ["primate", "asia"],
		abilities: [{
			ability: "PILFERING_1",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 1
	},
	556: {
		id: "556",
		kind: "animal",
		nameKey: "games.arknova.cards.c556.name",
		descriptionKey: "games.arknova.cards.c556.description",
		marine: !0,
		size: 3,
		price: 15,
		rock: 1,
		water: 0,
		requirements: [],
		tags: [
			"bear",
			"predator",
			"europe"
		],
		abilities: [{
			ability: "BOOST_ASSOCIATION",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 5,
		reputation: 1,
		conservation: 0
	},
	557: {
		id: "557",
		kind: "animal",
		nameKey: "games.arknova.cards.c557.name",
		descriptionKey: "games.arknova.cards.c557.description",
		marine: !0,
		size: 1,
		price: 7,
		rock: 0,
		water: 0,
		requirements: [],
		tags: ["pet"],
		abilities: [{
			ability: "PETTING_ZOO_ANIMAL",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !1,
		special: [{
			kind: "petting",
			capacity: 1
		}],
		appeal: 0,
		reputation: 0,
		conservation: 0
	},
	558: {
		id: "558",
		kind: "animal",
		nameKey: "games.arknova.cards.c558.name",
		descriptionKey: "games.arknova.cards.c558.description",
		marine: !0,
		size: 4,
		price: 16,
		rock: 1,
		water: 0,
		requirements: ["university"],
		tags: ["primate", "americas"],
		abilities: [{
			ability: "MONKEY_GANG",
			value: ""
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 6,
		reputation: 0,
		conservation: 1
	},
	559: {
		id: "559",
		kind: "animal",
		nameKey: "games.arknova.cards.c559.name",
		descriptionKey: "games.arknova.cards.c559.description",
		marine: !0,
		size: 3,
		price: 17,
		rock: 1,
		water: 0,
		requirements: [],
		tags: ["primate", "africa"],
		abilities: [{
			ability: "MONKEY_GANG",
			value: ""
		}, {
			ability: "JUMPING",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [],
		appeal: 7,
		reputation: 0,
		conservation: 0
	},
	560: {
		id: "560",
		kind: "animal",
		nameKey: "games.arknova.cards.c560.name",
		descriptionKey: "games.arknova.cards.c560.description",
		marine: !0,
		size: 3,
		price: 12,
		rock: 1,
		water: 1,
		requirements: [],
		tags: ["bird", "australia"],
		abilities: [{
			ability: "HUNTER",
			value: 2
		}],
		reef: [],
		reefDweller: !1,
		wave: !1,
		standard: !0,
		special: [{
			kind: "aviary",
			capacity: 1
		}],
		appeal: 6,
		reputation: 0,
		conservation: 0
	},
	"001": {
		id: "001",
		kind: "final",
		nameKey: "games.arknova.cards.c001.name",
		descriptionKey: "games.arknova.cards.c001.description",
		marine: !1,
		thresholds: [
			1,
			2,
			3,
			4
		],
		baseThresholds: [
			1,
			2,
			4,
			5
		]
	},
	"002": {
		id: "002",
		kind: "final",
		nameKey: "games.arknova.cards.c002.name",
		descriptionKey: "games.arknova.cards.c002.description",
		marine: !1,
		thresholds: [
			3,
			6,
			8,
			10
		],
		baseThresholds: [
			3,
			6,
			8,
			10
		]
	},
	"003": {
		id: "003",
		kind: "final",
		nameKey: "games.arknova.cards.c003.name",
		descriptionKey: "games.arknova.cards.c003.description",
		marine: !1,
		thresholds: [
			3,
			4,
			5,
			7
		],
		baseThresholds: [
			3,
			4,
			5,
			6
		]
	},
	"004": {
		id: "004",
		kind: "final",
		nameKey: "games.arknova.cards.c004.name",
		descriptionKey: "games.arknova.cards.c004.description",
		marine: !1,
		thresholds: [],
		baseThresholds: []
	},
	"005": {
		id: "005",
		kind: "final",
		nameKey: "games.arknova.cards.c005.name",
		descriptionKey: "games.arknova.cards.c005.description",
		marine: !1,
		thresholds: [
			2,
			3,
			4,
			5
		],
		baseThresholds: [
			3,
			4,
			5,
			6
		]
	},
	"006": {
		id: "006",
		kind: "final",
		nameKey: "games.arknova.cards.c006.name",
		descriptionKey: "games.arknova.cards.c006.description",
		marine: !1,
		thresholds: [
			6,
			12,
			18,
			24
		],
		baseThresholds: [
			6,
			12,
			18,
			24
		]
	},
	"007": {
		id: "007",
		kind: "final",
		nameKey: "games.arknova.cards.c007.name",
		descriptionKey: "games.arknova.cards.c007.description",
		marine: !1,
		thresholds: [
			6,
			9,
			12,
			15
		],
		baseThresholds: [
			6,
			9,
			12,
			15
		]
	},
	"008": {
		id: "008",
		kind: "final",
		nameKey: "games.arknova.cards.c008.name",
		descriptionKey: "games.arknova.cards.c008.description",
		marine: !1,
		thresholds: [
			3,
			5,
			7,
			9
		],
		baseThresholds: [
			3,
			6,
			8,
			10
		]
	},
	"009": {
		id: "009",
		kind: "final",
		nameKey: "games.arknova.cards.c009.name",
		descriptionKey: "games.arknova.cards.c009.description",
		marine: !1,
		thresholds: [],
		baseThresholds: []
	},
	"010": {
		id: "010",
		kind: "final",
		nameKey: "games.arknova.cards.c010.name",
		descriptionKey: "games.arknova.cards.c010.description",
		marine: !1,
		thresholds: [
			1,
			3,
			5,
			6
		],
		baseThresholds: [
			1,
			3,
			5,
			7
		]
	},
	"011": {
		id: "011",
		kind: "final",
		nameKey: "games.arknova.cards.c011.name",
		descriptionKey: "games.arknova.cards.c011.description",
		marine: !1,
		thresholds: [
			2,
			4,
			6,
			7
		],
		baseThresholds: [
			2,
			4,
			6,
			8
		]
	},
	"012": {
		id: "012",
		kind: "final",
		nameKey: "games.arknova.cards.c012.name",
		descriptionKey: "games.arknova.cards.c012.description",
		marine: !0,
		thresholds: [
			4,
			6,
			7,
			8
		],
		baseThresholds: [
			4,
			6,
			7,
			8
		]
	},
	"013": {
		id: "013",
		kind: "final",
		nameKey: "games.arknova.cards.c013.name",
		descriptionKey: "games.arknova.cards.c013.description",
		marine: !0,
		thresholds: [
			3,
			4,
			5,
			6
		],
		baseThresholds: [
			3,
			4,
			5,
			6
		]
	},
	"014": {
		id: "014",
		kind: "final",
		nameKey: "games.arknova.cards.c014.name",
		descriptionKey: "games.arknova.cards.c014.description",
		marine: !0,
		thresholds: [
			3,
			4,
			5,
			6
		],
		baseThresholds: [
			3,
			4,
			5,
			6
		]
	},
	"015": {
		id: "015",
		kind: "final",
		nameKey: "games.arknova.cards.c015.name",
		descriptionKey: "games.arknova.cards.c015.description",
		marine: !0,
		thresholds: [
			2,
			3,
			4,
			5
		],
		baseThresholds: [
			2,
			3,
			4,
			5
		]
	},
	"016": {
		id: "016",
		kind: "final",
		nameKey: "games.arknova.cards.c016.name",
		descriptionKey: "games.arknova.cards.c016.description",
		marine: !0,
		thresholds: [
			4,
			7,
			10,
			12
		],
		baseThresholds: [
			4,
			7,
			10,
			12
		]
	},
	"017": {
		id: "017",
		kind: "final",
		nameKey: "games.arknova.cards.c017.name",
		descriptionKey: "games.arknova.cards.c017.description",
		marine: !0,
		thresholds: [],
		baseThresholds: []
	}
}, F = {
	0: {
		id: "0",
		nameKey: "games.arknova.maps.m0.name",
		descriptionKey: "games.arknova.maps.m0.description",
		cells: [
			{
				at: [0, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation2"
			},
			{
				at: [0, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [2, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "money10"
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [5, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [5, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation2"
			},
			{
				at: [7, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [8, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {},
		partnerBonuses: [
			[],
			["upgrade"],
			["worker"],
			["conservation2"]
		],
		universityBonuses: [
			[],
			["upgrade"],
			["conservation2"]
		],
		lastWorkerBonus: ["conservation2"],
		tokens: [
			{
				effects: ["card"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["conservation1"],
				income: !0
			},
			{
				effects: ["worker"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	1: {
		id: "1",
		nameKey: "games.arknova.maps.m1.name",
		descriptionKey: "games.arknova.maps.m1.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [1, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [6, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			}
		],
		sites: { observation_tower: [[1, 2]] },
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation2"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation1"]
		],
		lastWorkerBonus: [],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["sponsorMoney"],
				income: !0
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	2: {
		id: "2",
		nameKey: "games.arknova.maps.m2.name",
		descriptionKey: "games.arknova.maps.m2.description",
		cells: [
			{
				at: [0, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "partner"
			},
			{
				at: [1, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: "sponsorMoney"
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [4, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			}
		],
		sites: {
			outdoor_area: [[5, 1]],
			partner_zoo_bonus: [[1, 0]],
			xtoken_at_bonus: [[1, 5]]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			[]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation2"]
		],
		lastWorkerBonus: ["conservation1"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["conservation1"],
				income: !1
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	3: {
		id: "3",
		nameKey: "games.arknova.maps.m3.name",
		descriptionKey: "games.arknova.maps.m3.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: "money2"
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: "money2"
			},
			{
				at: [1, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: "money2"
			},
			{
				at: [2, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "money2"
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [4, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [7, -4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "sponsorMoney"
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {
			silver_lake: [
				[2, 0],
				[2, 1],
				[1, 2],
				[2, 2]
			],
			build2_with_money2: [
				[2, -1],
				[1, 0],
				[1, 1]
			],
			xtoken_at_bonus: [[7, -3]]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation1"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation2"]
		],
		lastWorkerBonus: [],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["upgrade"],
				income: !1
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	4: {
		id: "4",
		nameKey: "games.arknova.maps.m4.name",
		descriptionKey: "games.arknova.maps.m4.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [1, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [3, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [3, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "multiplier"
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			}
		],
		sites: {
			commercial_harbor: [],
			harbor_connecting_building_space: [[0, 5]]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation1"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation1"]
		],
		lastWorkerBonus: ["conservation1"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["university1"],
				income: !1
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	5: {
		id: "5",
		nameKey: "games.arknova.maps.m5.name",
		descriptionKey: "games.arknova.maps.m5.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [1, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [1, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "sponsorMoney"
			},
			{
				at: [2, 3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [4, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [6, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {
			park_restaurant: [[4, 0]],
			restaurant_adjacent_spaces: [
				[4, -1],
				[4, 1],
				[3, 0],
				[3, 1],
				[5, -1],
				[5, 0]
			]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation2"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			[]
		],
		lastWorkerBonus: ["conservation1"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["specialEnclosure"],
				income: !1
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	6: {
		id: "6",
		nameKey: "games.arknova.maps.m6.name",
		descriptionKey: "games.arknova.maps.m6.description",
		cells: [
			{
				at: [0, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [2, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "university"
			},
			{
				at: [7, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {
			research_institute: [],
			institute_connecting_building_space: [[0, 5]]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation1"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			[]
		],
		lastWorkerBonus: ["conservation2"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["clever2"],
				income: !0
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	7: {
		id: "7",
		nameKey: "games.arknova.maps.m7.name",
		descriptionKey: "games.arknova.maps.m7.description",
		cells: [
			{
				at: [0, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "kiosk"
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [1, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [3, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "sponsorMoney"
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [4, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "kiosk"
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "kiosk"
			},
			{
				at: [5, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [7, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [8, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [8, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {
			ice_cream_parlors: [
				[1, 0],
				[5, -1],
				[5, 2]
			],
			kiosk_bonus: [
				[1, 0],
				[5, -1],
				[5, 2]
			]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			[]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation1"]
		],
		lastWorkerBonus: ["conservation2"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["pouch2"],
				income: !0
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	8: {
		id: "8",
		nameKey: "games.arknova.maps.m8.name",
		descriptionKey: "games.arknova.maps.m8.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "clever"
			},
			{
				at: [0, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [1, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 3],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [6, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation1"
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			}
		],
		sites: {
			hollywood_h: [
				[1, 4],
				[4, 3],
				[6, 1]
			],
			H: [
				[1, 4],
				[4, 3],
				[6, 1]
			]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation1"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation1"]
		],
		lastWorkerBonus: ["conservation1"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["partner1"],
				income: !1
			},
			{
				effects: ["worker1"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: []
	},
	A: {
		id: "A",
		nameKey: "games.arknova.maps.mA.name",
		descriptionKey: "games.arknova.maps.mA.description",
		cells: [
			{
				at: [0, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation2"
			},
			{
				at: [0, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [0, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [0, 5],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 4],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [1, 5],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, -1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 0],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [2, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [2, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [2, 4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -2],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: "money5"
			},
			{
				at: [3, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [3, 4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -2],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [4, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [4, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "xtoken"
			},
			{
				at: [5, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, -1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, 1],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [5, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: "card"
			},
			{
				at: [5, 3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 0],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 1],
				terrain: "rock",
				upgraded: !1,
				bonus: null
			},
			{
				at: [6, 2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -3],
				terrain: "plain",
				upgraded: !1,
				bonus: "worker1"
			},
			{
				at: [7, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [7, 1],
				terrain: "plain",
				upgraded: !1,
				bonus: "reputation2"
			},
			{
				at: [7, 2],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			},
			{
				at: [8, -4],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -3],
				terrain: "water",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, -2],
				terrain: "plain",
				upgraded: !1,
				bonus: "money10"
			},
			{
				at: [8, -1],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 0],
				terrain: "plain",
				upgraded: !1,
				bonus: null
			},
			{
				at: [8, 1],
				terrain: "plain",
				upgraded: !0,
				bonus: null
			}
		],
		sites: {
			prebuilt_enclosure_size3: [
				[0, 4],
				[0, 5],
				[1, 4]
			],
			prebuilt_kiosk: [[0, 3]]
		},
		partnerBonuses: [
			[],
			["upgrade1"],
			["worker1"],
			["conservation2"]
		],
		universityBonuses: [
			[],
			["upgrade1"],
			["conservation2"]
		],
		lastWorkerBonus: ["conservation2"],
		tokens: [
			{
				effects: ["card1"],
				income: !0
			},
			{
				effects: ["enclosure2"],
				income: !0
			},
			{
				effects: ["money5"],
				income: !0
			},
			{
				effects: ["conservation1"],
				income: !0
			},
			{
				effects: ["reputation2"],
				income: !1
			},
			{
				effects: ["money12"],
				income: !1
			},
			{
				effects: ["xtoken3"],
				income: !1
			}
		],
		prebuilt: [{
			kind: "kiosk",
			cells: [[0, 3]]
		}, {
			kind: "standard3",
			cells: [
				[0, 4],
				[0, 5],
				[1, 4]
			]
		}]
	}
}, xe = {
	2: 9,
	3: 12,
	4: 15
}, I = [
	[1, 1],
	[1, 0],
	[2, 1],
	[2, 0],
	[3, 1]
], Se = [
	[1, 0],
	[2, 1],
	[2, 0],
	[3, 1],
	[4, 1]
], Ce = [
	[0, 5],
	[1, 6],
	[2, 7],
	[3, 8],
	[4, 9],
	[5, 10],
	[7, 11],
	[9, 12],
	[11, 13],
	[13, 14],
	[15, 15],
	[17, 16],
	[20, 17],
	[23, 18],
	[26, 19],
	[29, 20],
	[32, 21],
	[36, 22],
	[40, 23],
	[44, 24],
	[48, 25],
	[52, 26],
	[56, 27],
	[61, 28],
	[66, 29],
	[71, 30],
	[76, 31],
	[81, 32],
	[86, 33],
	[91, 34],
	[96, 35],
	[102, 36],
	[108, 37]
];
function we(e) {
	return Ce.reduce((t, [n, r]) => e >= n ? r : t, 5);
}
function Te(e) {
	let t = Math.max(0, Math.min(41, e));
	return t <= 10 ? 114 - 2 * t : 124 - 3 * t;
}
function Ee(e, t) {
	return e - Te(t);
}
function De(e) {
	return e <= 1 ? 1 : e <= 3 ? 2 : e <= 6 ? 3 : e <= 9 ? 4 : e <= 12 ? 5 : 6;
}
var Oe = {
	5: "upgrade",
	8: "worker",
	10: "card",
	11: "conservation1",
	12: "xtoken",
	13: "card",
	14: "conservation1",
	15: "xtoken"
};
function ke(e, t) {
	return (e === 2 ? [
		2,
		5,
		7,
		10
	] : [
		2,
		5,
		5,
		7,
		7,
		10,
		10
	])[t] ?? 12;
}
//#endregion
//#region src/games/arknova/hex.ts
var Ae = [
	[0, -1],
	[1, -1],
	[1, 0],
	[0, 1],
	[-1, 1],
	[-1, 0]
], L = ([e, t]) => `${e},${t}`, je = (e, t) => e[0] === t[0] && e[1] === t[1], Me = ([e, t]) => Ae.map(([n, r]) => [e + n, t + r]), Ne = (e, t) => (Math.abs(e[0] - t[0]) + Math.abs(e[1] - t[1]) + Math.abs(e[0] - t[0] + e[1] - t[1])) / 2, Pe = {
	standard1: [[0, 0]],
	standard2: [[0, 0], [1, 0]],
	standard3: [
		[0, 0],
		[1, 0],
		[0, 1]
	],
	standard4: [
		[0, 0],
		[1, -1],
		[1, 0],
		[2, -1]
	],
	standard5: [
		[0, 0],
		[1, -1],
		[1, 0],
		[2, -1],
		[2, 0]
	],
	kiosk: [[0, 0]],
	pavilion: [[0, 0]],
	petting: [
		[0, 0],
		[1, -1],
		[2, -1]
	],
	reptile: [
		[0, 0],
		[-1, 0],
		[-1, 1],
		[1, -1],
		[1, 0]
	],
	aviary: [
		[0, 0],
		[-1, 0],
		[1, -1],
		[-1, 1],
		[0, 1]
	],
	aquariumSmall: [[0, 0], [1, 0]],
	aquariumLarge: [
		[0, 0],
		[0, 1],
		[0, 2],
		[0, 3],
		[-1, 2]
	]
};
function Fe(e) {
	let [t, n] = [...e].sort(([e, t], [n, r]) => e - n || t - r)[0];
	return e.map(([e, r]) => [e - t, r - n]).sort(([e, t], [n, r]) => e - n || t - r);
}
function Ie(e, t = !0) {
	let n = /* @__PURE__ */ new Map();
	for (let r = 0; r < (t ? 2 : 1); r++) {
		let t = e.map(([e, t]) => r ? [e, -e - t] : [e, t]);
		for (let e = 0; e < 6; e++) {
			let e = Fe(t);
			n.set(e.map(L).join(";"), e), t = t.map(([e, t]) => [-t, e + t]);
		}
	}
	return [...n.values()];
}
function Le(e) {
	return new Map(e.cells.map((e) => [L(e.at), e]));
}
function Re(e, t) {
	let n = Le(e);
	return n.has(L(t)) && Me(t).some((e) => !n.has(L(e)));
}
function R(e) {
	let t = new Set(e.map(L)), n = /* @__PURE__ */ new Map();
	for (let r of e) for (let e of Me(r)) t.has(L(e)) || n.set(L(e), e);
	return [...n.values()];
}
function z(e, t, n, r) {
	let i = new Set(t.filter((e) => e.card !== "279").flatMap((e) => e.cells.map(L))), a = Le(e), o = R(n).filter((e) => a.get(L(e))?.terrain === r && !i.has(L(e))).length;
	return r === "water" && t.some((e) => e.card === "279" && e.cells.every((e) => n.some((t) => je(t, e)))) ? Math.max(1, o) : o;
}
function ze(e, t, n, r, i) {
	let a = Le(e), o = new Set(t.flatMap((e) => e.cells.map(L)));
	if (new Set(r.map(L)).size !== r.length || r.some((e) => !a.has(L(e)) || o.has(L(e))) || r.some((e) => a.get(L(e)).upgraded && !i.upgraded)) return !1;
	let s = r.filter((e) => a.get(L(e)).terrain !== "plain");
	if (i.waterOnly) {
		if (r.some((e) => a.get(L(e)).terrain !== "water")) return !1;
	} else if (!i.anyTerrain && s.length > (i.terrainAllowance ?? 0)) return !1;
	let c = r.filter((t) => Re(e, t)).length;
	return !(c < (i.border ?? 0) || !i.detached && (t.length ? !R(r).some((e) => o.has(L(e))) : !c) || n === "kiosk" && t.some((e) => e.kind === "kiosk" && e.cells.some((e) => r.some((t) => Ne(e, t) < 3))) || !i.anyTerrain && (z(e, t, r, "rock") < (i.rock ?? 0) || z(e, t, r, "water") < (i.water ?? 0)));
}
function Be(e, t, n, r, i) {
	let a = i ?? (n === "unique" ? [] : Pe[n]);
	if (!a.length) return [];
	let o = /* @__PURE__ */ new Map();
	for (let i of Ie(a, n !== "unique")) for (let { at: [a, s] } of e.cells) {
		let c = i.map(([e, t]) => [a + e, s + t]);
		ze(e, t, n, c, r) && o.set(c.map(L).sort().join(";"), c);
	}
	return [...o.values()];
}
function Ve(e, t) {
	let n = new Set(R(t.cells).map(L));
	return e.filter((e) => e.id !== t.id && e.cells.some((e) => n.has(L(e))));
}
function He(e) {
	return e.filter((e) => e.kind === "kiosk").reduce((t, n) => t + Ve(e, n).filter((e) => e.kind !== "kiosk" && (!e.kind.startsWith("standard") || e.occupied)).length, 0);
}
function Ue(e, t) {
	let n = new Set(t.flatMap((e) => e.cells.map(L))), r = new Map(e.cells.filter((e) => e.terrain === "plain" && !n.has(L(e.at))).map((e) => [L(e.at), e.at])), i = [];
	for (; r.size;) {
		let e = r.values().next().value, t = [e];
		r.delete(L(e));
		for (let e = 0; e < t.length; e++) for (let n of Me(t[e])) r.delete(L(n)) && t.push(n);
		i.push(t.length);
	}
	return i;
}
function We(e, t, n) {
	let r = new Set(t.flatMap((e) => e.cells.map(L))), i = new Set(t.filter((e) => e.card !== "279").flatMap((e) => e.cells.map(L))), a = 0, o = 0;
	for (let t of e.cells) t.terrain === n && !i.has(L(t.at)) && (Me(t.at).some((e) => r.has(L(e))) ? a++ : o++);
	return {
		connected: a,
		isolated: o
	};
}
//#endregion
//#region src/games/arknova/mechanics.ts
function Ge(e) {
	let t = P[e];
	if (!t || t.kind === "final") throw Error("Unknown zoo card");
	return t;
}
function B(e) {
	let t = P[e];
	if (!t || t.kind !== "animal") throw Error("Unknown animal card");
	return t;
}
var V = (e) => e.size <= 2 || e.tags.includes("pet"), Ke = (e) => e.size >= 4, H = (e, t) => e.sponsors.includes(t), qe = (e, t) => e.actions.some((e) => e.kind === t && e.upgraded), Je = (e) => (e.universities.includes("hand") ? 5 : 3) + (e.cardTokens.handLimit ?? 0);
function U(e) {
	let t = {}, n = (e, n = 1) => {
		t[e] = (t[e] ?? 0) + n;
	};
	for (let t of [...e.animals, ...e.sponsors]) {
		let e = Ge(t);
		if (e.kind !== "project") {
			for (let t of e.tags) n(t);
			e.id !== "279" && !e.tags.includes("water") && n("water", e.water), e.tags.includes("rock") || n("rock", e.rock);
		}
	}
	for (let t of e.partners) n(t);
	for (let t of e.universities) t === "science2" && n("science", 2), t === "science_rep" && n("science"), t.startsWith("animal:") && (n("science"), n(t.slice(7)));
	for (let t of e.extraTags) n(t);
	for (let t of e.buildings) (t.kind === "aquariumSmall" || t.kind === "aquariumLarge") && n("water");
	return t;
}
function Ye(e, t, n) {
	let r = U(t);
	return n === "all-animals" ? E.filter((t) => (r[t] ?? 0) > 0 && (e.config.marine || t !== "seaAnimal")).length : n === "all-continents" ? T.filter((e) => (r[e] ?? 0) > 0).length : n === "animal-size-2" ? t.animals.filter((e) => V(B(e))).length : n === "animal-size-4" ? t.animals.filter((e) => Ke(B(e))).length : r[n] ?? 0;
}
function Xe(e, t) {
	if (!t.kind.startsWith("standard")) return t.kind === "petting" ? 3 : t.kind === "aquariumSmall" || t.kind === "unique" && t.card === "279" ? 2 : 5;
	let n = Number(t.kind.slice(-1)) + t.extra, r = F[e.map].sites.outdoor_area ?? [], i = R(t.cells).some((e) => r.some((t) => L(e) === L(t)));
	return n + (e.map === "2" && i ? 2 : 0) + (H(e, "272") && t.kind === "standard3" && t.cells.some((t) => Re(F[e.map], t)) ? 2 : 0);
}
function Ze(e, t) {
	let n = [], r = (n) => H(e, "219") || z(F[e.map], e.buildings, n.cells, "water") >= t.water && z(F[e.map], e.buildings, n.cells, "rock") >= t.rock;
	if (t.standard) for (let i of e.buildings) i.kind.startsWith("standard") && !i.occupied && Xe(e, i) >= t.size && r(i) && n.push({
		key: `standard:${i.id}`,
		allocations: [{
			building: i.id,
			markers: 0
		}]
	});
	t.abilities.some((e) => e.ability === "FLOCK_ANIMAL") && e.animals.some((e) => B(e).tags.includes("herbivore") && B(e).size >= t.size) && n.push({
		key: "flock",
		allocations: []
	});
	for (let i of t.special) if (i.kind === "aquarium") {
		let t = e.buildings.filter((e) => (e.kind === "aquariumSmall" || e.kind === "aquariumLarge" || e.card === "279") && r(e)), a = (r, i, o) => {
			if (r === t.length) {
				i === 0 && o.length && n.push({
					key: `aquarium:${o.map((e) => `${e.building}=${e.markers}`).join(",")}`,
					allocations: o
				});
				return;
			}
			let s = t[r], c = Xe(e, s) - s.used;
			for (let e = 0; e <= Math.min(i, c); e++) a(r + 1, i - e, e ? [...o, {
				building: s.id,
				markers: e
			}] : o);
		};
		if (i.capacity === 0) for (let e of t) n.push({
			key: `aquarium:${e.id}=0`,
			allocations: [{
				building: e.id,
				markers: 0
			}]
		});
		else a(0, i.capacity, []);
	} else for (let t of e.buildings) t.kind === i.kind && Xe(e, t) - t.used >= i.capacity && r(t) && n.push({
		key: `special:${t.id}`,
		allocations: [{
			building: t.id,
			markers: i.capacity
		}]
	});
	return n;
}
function Qe(e, t, n, r = 0) {
	let i = n.tags.reduce((e, n) => e + t.partners.filter((e) => e === n).length * 3, 0);
	V(n) && H(t, "229") && (i += 3), Ke(n) && H(t, "230") && (i += 4);
	let a = M(e);
	return a?.action === "animals" && a.variant === 3 && !a.upgraded && !a.played.length && (i += 2), Math.max(0, n.price - i) + r;
}
function $e(e, t, n) {
	if (n.kind === "project") return 0;
	let r = U(t), i = {};
	for (let e of n.requirements) i[e] = (i[e] ?? 0) + 1;
	let a = 0;
	for (let [o, s] of Object.entries(i)) {
		let i = r[o] ?? 0;
		if (o === "Partner Zoo" && (i = n.kind === "animal" ? t.partners.filter((e) => n.tags.includes(e)).length : t.partners.length), (o === "university" || o === "University") && (i = t.universities.length), o === "animalsII" || o === "sponsorsII") {
			let n = o === "animalsII" ? "animals" : "sponsors", r = M(e);
			i = Number(r?.action === n && r.rid === t.rid ? r.upgraded : qe(t, n));
		}
		if (o === "reputation" || o === "reputation_3") {
			let e = [
				"227",
				"263",
				"275",
				"278"
			].includes(n.id) ? 6 : 3;
			i = +(t.reputation >= e);
		}
		o === "appeal" && (i = +(t.appeal <= 25)), o === "kiosk" && (i = t.buildings.filter((e) => e.kind === "kiosk").length), a += Math.max(0, s - i);
	}
	return a;
}
function et(e, t, n) {
	let r = +(t.camouflage > 0);
	t.ignoredConditions > 0 && (r += t.ignoredConditions), H(t, "263") && Ke(n) && r++, t.map === "6" && t.buildings.some((e) => e.cells.some((e) => L(e) === "0,5")) && r++;
	let i = M(e);
	return i?.action === "animals" && i.variant === 1 && i.strength >= (i.upgraded ? 3 : 5) && i.played.length === 0 && r++, r;
}
function tt(e, t, n, r = 0) {
	return t.assignment === "small" && Ke(n) || t.assignment === "large" && V(n) ? !1 : t.money >= Qe(e, t, n, r) && $e(e, t, n) <= et(e, t, n) && Ze(t, n).length > 0;
}
function nt(e, t) {
	for (let n of t.special) {
		let t = e.buildings.filter((e) => n.kind === "aquarium" ? e.kind === "aquariumSmall" || e.kind === "aquariumLarge" || e.card === "279" : e.kind === n.kind);
		if (t.length && t.reduce((e, t) => e + t.used, 0) >= n.capacity) {
			let e = n.capacity;
			for (let n of t) {
				let t = Math.min(e, n.used);
				n.used -= t, e -= t;
			}
			return !0;
		}
	}
	let n = e.buildings.filter((n) => n.kind.startsWith("standard") && n.occupied && Xe(e, n) >= t.size).sort((t, n) => Xe(e, t) - Xe(e, n) || t.id - n.id), r = n.find((n) => H(e, "219") || z(F[e.map], e.buildings, n.cells, "rock") >= t.rock && z(F[e.map], e.buildings, n.cells, "water") >= t.water) ?? n[0];
	return r && (r.occupied = !1), !!r;
}
function rt(e, t = !1) {
	let n = F[e.map], r = new Set(e.buildings.flatMap((e) => e.cells.map(L)));
	return n.cells.filter((e) => e.terrain === "plain" && (!t || Re(n, e.at))).every((e) => r.has(L(e.at)));
}
function it(e, t, n) {
	let r = P[n];
	if (!r || r.kind !== "final") return 0;
	let i = U(t), a = 0;
	switch (n) {
		case "001":
			a = t.animals.filter((e) => Ke(B(e))).length;
			break;
		case "002":
			a = t.animals.filter((e) => V(B(e))).length;
			break;
		case "003":
			a = i.science ?? 0;
			break;
		case "004": return Number(We(F[t.map], t.buildings, "water").isolated === 0) + Number(We(F[t.map], t.buildings, "rock").isolated === 0) + Number(rt(t, !0)) + Number(rt(t));
		case "005":
			a = t.bonuses.length;
			break;
		case "006":
			a = Ue(F[t.map], t.buildings).reduce((e, t) => e + t, 0);
			break;
		case "007":
			a = t.reputation;
			break;
		case "008":
			a = t.sponsors.length;
			break;
		case "009": {
			let n = e.players[(e.players.indexOf(t) + e.players.length - 1) % e.players.length], r = U(n);
			return Math.min(4, E.filter((e) => (i[e] ?? 0) > (r[e] ?? 0)).length);
		}
		case "010":
			a = i.rock ?? 0;
			break;
		case "011":
			a = i.water ?? 0;
			break;
		case "012":
			a = new Set(t.buildings.map((e) => Ie(e.cells).map((e) => e.map(L).join(";")).sort()[0])).size;
			break;
		case "013":
		case "014": {
			let r = e.projects.filter((e) => (e.base || n === "014" && [
				"108",
				"109",
				"110",
				"111",
				"112",
				"133"
			].includes(e.card)) && e.slots.includes(t.rid)).map((e) => P[e.card]).filter((e) => e.kind === "project").map((e) => e.tag);
			a = Math.max(0, ...(n === "013" ? T : E).filter((e) => !r.includes(e)).map((e) => i[e] ?? 0));
			break;
		}
		case "015":
			a = Math.min(t.buildings.filter((e) => e.kind === "kiosk").length, t.buildings.filter((e) => e.kind === "pavilion").length);
			break;
		case "016":
			a = [...t.animals, ...t.sponsors].reduce((e, t) => {
				let n = Ge(t);
				return e + (n.kind === "project" ? 0 : n.requirements.length);
			}, 0);
			break;
		case "017": {
			let n = e.players[(e.players.indexOf(t) + e.players.length - 1) % e.players.length], r = U(n);
			return Math.min(4, T.filter((e) => (i[e] ?? 0) + t.partners.filter((t) => t === e).length > (r[e] ?? 0)).length);
		}
	}
	return (e.config.marine ? r.thresholds : r.baseThresholds).reduce((e, t, n) => a >= t ? n + 1 : e, 0);
}
function at(e) {
	let t = new Set(e.buildings.flatMap((e) => e.cells.map(L)));
	return F[e.map].cells.filter((n) => n.terrain === "plain" && Re(F[e.map], n.at) && !t.has(L(n.at)) && Me(n.at).some((e) => t.has(L(e)))).length;
}
function ot(e, t) {
	return e.players.reduce((e, n) => e + (U(n)[t] ?? 0), 0);
}
//#endregion
//#region src/games/arknova/flow.ts
var st = [
	"money10",
	"xtoken3",
	"reputation2",
	"university",
	"partner",
	"enclosure3",
	"cards3",
	"multiplier",
	"sponsorMoney"
], ct = [
	"ignoreConditions",
	"extraShift",
	"wildcard",
	"posturing3",
	"adapt3",
	"snapHandLimit"
];
function W(e, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = t(e.seed, e.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function lt(e, n) {
	if (!n.length) return;
	let r = t(e.seed, e.cursor++, n.length);
	return n.splice(r, 1)[0];
}
function ut(e) {
	return !e.deck.length && e.discard.length && (e.deck = W(e, e.discard), e.discard = []), e.deck.shift() ?? null;
}
function dt(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		let n = ut(e);
		if (n === null) break;
		t.hand.push(n), r.push(n);
	}
	return r;
}
function ft(e, t, n = !1) {
	let r = e.market[t];
	if (!r) return null;
	e.market[t] = null;
	let i = e.marks[r];
	if (i) {
		delete e.marks[r];
		let t = j(e, i);
		n ? t.hand.push(r) : t.money += 2;
	} else n && e.discard.push(r);
	return r;
}
function pt(e, t = !1) {
	let n = 0, r = () => {
		for (e.market = [...e.market.filter((e) => e !== null)]; e.market.length < 6;) e.market.push(null);
	};
	r();
	let i = () => {
		for (let r = 0; r < 6; r++) if (e.market[r] === null) {
			let i = ut(e);
			if (!i) break;
			e.market[r] = i;
			let a = P[i];
			!t && e.config.marine && (a.kind === "animal" || a.kind === "sponsor") && a.wave && n++;
		}
	};
	for (i(); n > 0;) {
		let t = n;
		n = 0;
		for (let n = 0; n < t; n++) ft(e, 0, !0), r();
		r(), i();
	}
}
function mt(e, t, n, r) {
	!e.deck.length && e.discard.length && (e.deck = W(e, e.discard), e.discard = []);
	let i = [], a = null;
	for (; e.deck.length;) {
		let r = e.deck.shift();
		if (n(r)) {
			a = r, t.hand.push(r);
			break;
		}
		i.push(r);
	}
	return r ? e.deck.push(...i) : e.discard.push(...i), a;
}
function G(e, t, n = !1) {
	if (!t.length) return;
	if (n) {
		e.frames.push({
			kind: "effects",
			rid: t[0].rid,
			effects: t,
			ordered: !0
		});
		return;
	}
	let r = [...new Set(t.map((e) => e.rid))];
	for (let n of r.reverse()) e.frames.push({
		kind: "effects",
		rid: n,
		effects: t.filter((e) => e.rid === n)
	});
}
function ht(e, t) {
	let n = [...e.frames].reverse().find((e) => e.kind === "action");
	n ? n.after.push(t) : G(e, [t]);
}
function K(e, t) {
	e.appeal = Math.max(0, Math.min(113, e.appeal + t));
}
function gt(e, t) {
	e.x = Math.max(0, Math.min(5, e.x + t));
}
function _t(e, t, n, r = !1) {
	let i = t.conservation;
	if (t.conservation = Math.max(0, Math.min(41, t.conservation + n)), r) return;
	let a = [];
	i < 2 && t.conservation >= 2 && a.push(A(t.rid, "upgradeOrWorker"));
	for (let e of [5, 8]) i < e && t.conservation >= e && a.push(A(t.rid, "trackReward", 1, String(e)));
	if (!e.finalDiscardTriggered && t.conservation >= 10) {
		e.finalDiscardTriggered = !0, e.finalDiscardPending = e.players.map((e) => e.rid);
		for (let t of e.players) a.push(A(t.rid, "discardFinal", 1));
	}
	G(e, a);
}
function vt(e, t, n) {
	let r = [];
	for (let i = 0; i < n; i++) {
		if (t.reputation >= 15) {
			e.config.marine && e.rewards.reputation.length ? r.push(A(t.rid, "trackReward", 1, "reputation")) : K(t, 1);
			continue;
		}
		if (t.reputation >= 9 && !qe(t, "cards")) continue;
		t.reputation++;
		let n = Oe[t.reputation];
		n && r.push(A(t.rid, "bonus", 1, n));
	}
	G(e, r);
}
function yt(e, t) {
	t.workers >= 4 || (t.workers++, t.workers === 4 && G(e, F[t.map].lastWorkerBonus.map((e) => A(t.rid, "bonus", 1, e))));
}
function bt(e, t, n) {
	let r = xe[e.players.length];
	e.breakProgress >= r || (e.breakProgress = Math.min(r, e.breakProgress + n), e.breakProgress === r && (gt(t, 1), e.breakBy = t.rid));
}
function xt(e, t, n) {
	let r = e.actions.findIndex((e) => e.kind === t), [i] = e.actions.splice(r, 1);
	n === 1 ? e.actions.unshift(i) : e.actions.push(i);
}
function St(e, t, n, r) {
	return {
		rid: e,
		map: n,
		money: 25,
		appeal: t,
		conservation: 0,
		reputation: 1,
		x: 0,
		workers: 1,
		workersUsed: {},
		actions: r.map((e) => ({
			kind: e,
			variant: 0,
			upgraded: !1,
			multiplier: 0,
			venom: !1,
			constriction: !1
		})),
		buildings: F[n].prebuilt.map((e, t) => ({
			id: t,
			kind: e.kind,
			cells: e.cells.map(([e, t]) => [e, t]),
			occupied: !1,
			used: 0,
			extra: 0,
			card: null
		})),
		animals: [],
		sponsors: [],
		partners: [],
		universities: [],
		bonuses: [],
		extraTags: [],
		cardTokens: {},
		pouched: {},
		pouchedCards: {},
		hand: [],
		finals: [],
		assignment: null,
		donations: 0,
		harborUsed: !1,
		fullCoverAwarded: !1,
		ignoredConditions: 0,
		camouflage: 0,
		removedVenom: !1,
		setupReady: !1
	};
}
function Ct(e, t, n) {
	if (t.length < 2 || t.length > 4 || new Set(t).size !== t.length) throw Error("Ark Nova requires 2–4 distinct players");
	let r = {
		config: e,
		seed: n,
		cursor: 0,
		revision: 0,
		phase: e.maps === "advanced" ? "map" : e.marine ? "draft" : "setup",
		players: [],
		turn: 0,
		turnNumber: 1,
		breakNumber: 0,
		breakProgress: 0,
		breakBy: null,
		breakStage: 0,
		breakPlayer: 0,
		market: [],
		marks: {},
		deck: [],
		discard: [],
		finalDeck: [],
		baseReserve: [],
		projects: [],
		partnerSupply: [...T],
		universitySupply: [
			"hand",
			"science2",
			"science_rep",
			...e.marine ? ["animal"] : []
		],
		marineUniversities: e.marine ? [
			"bird",
			"herbivore",
			"predator",
			"primate",
			"reptile",
			"seaAnimal"
		] : [],
		donations: 0,
		rewards: {
			5: [],
			8: [],
			reputation: []
		},
		frames: [],
		finalDiscardTriggered: !1,
		finalDiscardPending: [],
		endBy: null,
		finalTurns: null,
		mapChoices: {},
		draftHands: {},
		draftKept: {},
		draftSelected: {},
		draftReserve: [],
		draftRound: 0,
		journal: [],
		finalBreakdown: {},
		turnStart: null,
		reconstruction: null
	}, i = W(r, [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8"
	]);
	for (let n = 0; n < t.length; n++) {
		let a = t[n], o = W(r, le.filter((e) => e !== "animals")), s = e.maps === "advanced" ? i[n * 2] : e.maps;
		r.players.push(St(a, n, s, ["animals", ...o])), r.mapChoices[a] = e.maps === "advanced" ? i.slice(n * 2, n * 2 + 2) : [s];
	}
	let a = Object.values(P).filter((t) => e.marine || !t.marine);
	r.deck = W(r, a.filter((e) => e.kind !== "final" && (e.kind !== "project" || e.type !== "base")).map((e) => e.id)), r.finalDeck = W(r, a.filter((e) => e.kind === "final").map((e) => e.id));
	let o = W(r, a.filter((e) => e.kind === "project" && e.type === "base").map((e) => e.id)), s = t.length === 4 ? 4 : 3;
	r.projects = o.splice(0, s).map((e, n) => ({
		card: e,
		base: !0,
		owner: null,
		slots: [
			0,
			1,
			2
		].map((e) => t.length === 2 && e === n ? "blocked" : null)
	})), r.baseReserve = o;
	let c = W(r, [...st, ...e.marine ? ct : []]);
	r.rewards[5] = c.splice(0, 2), r.rewards[8] = c.splice(0, 2), e.marine && (r.rewards.reputation = c.splice(0, 1)), pt(r, !0);
	for (let e of r.players) dt(r, e, 8), e.finals = r.finalDeck.splice(0, 2);
	if (e.marine) {
		let e = W(r, le.flatMap((e) => [
			1,
			2,
			3,
			4
		].map((t) => `${e}:${t}`)));
		for (let n of t) r.draftHands[n] = e.splice(0, 3), r.draftKept[n] = [];
		r.draftReserve = e;
	}
	return r;
}
function wt(e, t, n) {
	let r = j(e, t);
	if (e.phase !== "map" || r.setupReady || !e.mapChoices[t].includes(n)) return !1;
	if (r.map = n, r.buildings = F[n].prebuilt.map((e, t) => ({
		id: t,
		kind: e.kind,
		cells: e.cells.map(([e, t]) => [e, t]),
		occupied: !1,
		used: 0,
		extra: 0,
		card: null
	})), r.setupReady = !0, e.players.every((e) => e.setupReady)) {
		for (let t of e.players) t.setupReady = !1;
		e.phase = e.config.marine ? "draft" : "setup";
	}
	return !0;
}
function Tt(e, t, n) {
	if (e.phase !== "draft" || e.draftRound >= 2 || e.draftSelected[t] || !e.draftHands[t].includes(n)) return !1;
	if (e.draftSelected[t] = n, Object.keys(e.draftSelected).length === e.players.length) {
		let t = {};
		for (let n = 0; n < e.players.length; n++) {
			let r = e.players[n], i = e.draftSelected[r.rid];
			e.draftKept[r.rid].push(i), t[e.players[(n + 1) % e.players.length].rid] = e.draftHands[r.rid].filter((e) => e !== i);
		}
		if (e.draftSelected = {}, e.draftRound++, e.draftHands = t, e.draftRound === 2) for (let t of e.players) {
			e.draftKept[t.rid].push(...e.draftHands[t.rid]);
			let n = e.draftKept[t.rid];
			if (new Set(n.map((e) => e.split(":")[0])).size === 1) {
				let t = e.draftReserve.findIndex((e) => e.split(":")[0] !== n[0].split(":")[0]);
				if (t < 0) throw Error("No distinct draft replacement");
				n.push(...e.draftReserve.splice(t, 1));
			}
		}
	}
	return !0;
}
function Et(e, t, n) {
	let r = j(e, t), i = e.draftKept[t];
	if (e.phase !== "draft" || e.draftRound !== 2 || r.setupReady || n.length !== 2 || new Set(n.map((e) => e.split(":")[0])).size !== 2 || n.some((e) => !i.includes(e)) || i.length === 4 && !n.includes(i[3])) return !1;
	for (let e of n) {
		let [t, n] = e.split(":");
		r.actions.find((e) => e.kind === t).variant = Number(n);
	}
	if (r.setupReady = !0, e.players.every((e) => e.setupReady)) {
		for (let t of e.players) t.setupReady = !1;
		e.phase = "setup";
	}
	return !0;
}
function Dt(e, t, n) {
	let r = j(e, t);
	return e.phase !== "setup" || r.setupReady || n.length !== 4 || new Set(n).size !== 4 || n.some((e) => !r.hand.includes(e)) ? !1 : (e.discard.push(...r.hand.filter((e) => !n.includes(e))), r.hand = r.hand.filter((e) => n.includes(e)), r.setupReady = !0, e.players.every((e) => e.setupReady) && (e.phase = "play"), !0);
}
function Ot(e, t, n, r, i) {
	let a = [], o = (e, n = 1, r = "") => a.push(A(t.rid, e, n, r, i)), s = (e) => n.filter((t) => t === e).length;
	for (let t of e.players) {
		let e = (e, n) => {
			n > 0 && a.push(A(t.rid, e, n, "", i));
		};
		H(t, "208") && e("money", 2 * s("science"));
		for (let [n, r] of [
			["236", "primate"],
			["237", "reptile"],
			["238", "bird"],
			["239", "predator"],
			["240", "herbivore"],
			["266", "seaAnimal"]
		]) H(t, n) && e("money", 3 * s(r));
		H(t, "251") && e("appeal", 2 * s("bear")), H(t, "275") && e("money", 2 * s("pet"));
	}
	H(t, "202") && s("science") && o("reputation", s("science")), H(t, "204") && s("science") && o("conservation", s("science"));
	for (let [n, r, i, o] of [
		[
			"210",
			"americas",
			"freeBuild",
			"kiosk"
		],
		[
			"211",
			"europe",
			"freeBuild",
			"standard1"
		],
		[
			"212",
			"australia",
			"POUCH",
			""
		],
		[
			"213",
			"asia",
			"freeBuild",
			"pavilion"
		],
		[
			"214",
			"africa",
			"CLEVER",
			""
		],
		[
			"243",
			"herbivore",
			"appeal",
			""
		],
		[
			"244",
			"bird",
			"appeal",
			""
		],
		[
			"245",
			"water",
			"appeal",
			""
		],
		[
			"246",
			"rock",
			"appeal",
			""
		],
		[
			"247",
			"primate",
			"appeal",
			""
		],
		[
			"248",
			"primate",
			"x",
			""
		],
		[
			"249",
			"bird",
			"PERCEPTION_2",
			""
		],
		[
			"250",
			"reptile",
			"SUN_BATHING",
			""
		],
		[
			"252",
			"predator",
			"HUNTER",
			""
		],
		[
			"253",
			"herbivore",
			"okapi",
			""
		],
		[
			"268",
			"europe",
			"MARK",
			""
		],
		[
			"269",
			"australia",
			"enlarge",
			""
		],
		[
			"270",
			"seaAnimal",
			"expedition",
			""
		]
	]) if (H(t, n)) for (let c = 0; c < s(r); c++) {
		let r = i === "appeal" || i === "SUN_BATHING" ? 2 : i === "HUNTER" ? U(t).predator ?? 0 : 1, s = A(t.rid, i, r, o, n);
		i === "CLEVER" || i === "MARK" ? ht(e, s) : a.push(s);
	}
	if (H(t, "262")) for (let e of [...new Set(n)]) [...E, ...T].includes(e) && !(r[e] > 0) && (o("money", 2), o("appeal", 1));
	return a;
}
//#endregion
//#region src/games/arknova/buildings.ts
var kt = {
	243: [
		[0, 0],
		[1, -1],
		[2, -1]
	],
	244: [
		[0, 0],
		[-1, 0],
		[1, -1],
		[1, 0]
	],
	245: [
		[0, 0],
		[-1, 1],
		[1, 0],
		[1, 1]
	],
	246: [
		[0, 0],
		[1, -1],
		[2, -2],
		[3, -3]
	],
	247: [
		[0, 0],
		[-1, 0],
		[1, 0],
		[0, 1]
	],
	248: [
		[0, 0],
		[-1, 0],
		[-2, 1],
		[1, 0]
	],
	249: [
		[0, 0],
		[-1, 0],
		[1, 0]
	],
	250: [
		[0, 0],
		[-1, 0],
		[1, -1],
		[0, 1]
	],
	251: [
		[0, 0],
		[-1, 1],
		[1, 0],
		[2, -1]
	],
	252: [
		[0, 0],
		[-1, 0],
		[1, -1],
		[2, -2]
	],
	253: [
		[0, 0],
		[-1, 1],
		[-2, 1],
		[1, 0]
	],
	254: [
		[0, 0],
		[-1, 0],
		[1, -1]
	],
	255: [[0, 0], [1, 0]],
	256: [[0, 0], [1, 0]],
	257: [[0, 0], [1, 0]],
	271: [
		[0, 0],
		[0, 1],
		[1, -1],
		[2, -1],
		[3, -2]
	],
	274: [[0, 0]],
	278: [
		[0, 0],
		[1, 0],
		[2, -1],
		[2, 0],
		[3, -2]
	],
	279: [[0, 0], [1, 0]]
};
function At(e, t, n = "", r = { upgraded: qe(e, "build") }) {
	return {
		...r,
		anyTerrain: H(e, "219") || r.anyTerrain,
		...t === "aquariumSmall" || t === "aquariumLarge" ? { water: 1 } : {},
		...n === "254" ? { border: 2 } : {},
		...n === "257" ? {
			border: 2,
			detached: !0
		} : {},
		...n === "279" ? { waterOnly: !0 } : {}
	};
}
function jt(e, t, n, r) {
	return n === "unique" ? !0 : [
		"petting",
		"aviary",
		"reptile",
		"aquariumSmall",
		"aquariumLarge"
	].includes(n) && t.buildings.some((e) => e.kind === n) || (n === "aquariumSmall" || n === "aquariumLarge") && !e.config.marine ? !1 : !["aviary", "reptile"].includes(n) || (r ?? qe(t, "build"));
}
function Mt(e, t, n, r = "", i, a) {
	return jt(e, t, n, a) ? Be(F[t.map], t.buildings, n, At(t, n, r, i), n === "unique" ? kt[r] : void 0).length > 0 : !1;
}
function Nt(e, t, n, r = "", i = 0, a = !0, o = [], s) {
	return {
		kind: "place",
		rid: t,
		building: n,
		source: r,
		cost: i,
		optional: a,
		effects: o,
		rules: At(j(e, t), n, r, s),
		moving: null,
		...n === "unique" ? { shape: kt[r] } : {}
	};
}
function Pt(e, t) {
	let n = F[e.map].sites[t] ?? [], r = new Set(e.buildings.flatMap((e) => e.cells.map(L)));
	return n.length > 0 && n.every((e) => r.has(L(e)));
}
function Ft(e, t, n) {
	let r = t.rules.terrainAllowance && !t.rules.upgraded && !t.rules.anyTerrain && n.some((t) => F[e.map].cells.find((e) => L(e.at) === L(t))?.terrain !== "plain") ? 2 : 0;
	return t.cost + r;
}
function It(e, t, n = "") {
	let r = F[e.map], i = [], a = (t, r = 1, a = "") => i.push(A(e.rid, t, r, a, n));
	if (!H(e, "280")) {
		for (let i of r.cells.filter((e) => e.bonus && t.some((t) => L(t) === L(e.at)))) {
			for (let e = 0; e < (n === "271" ? 2 : 1); e++) a("bonus", 1, i.bonus);
			H(e, "221") && Re(r, i.at) && a("placementBonus");
		}
		if (e.map === "8") for (let e of r.sites.hollywood_h ?? []) t.some((t) => L(t) === L(e)) && a("searchSponsor");
		rt(e) && !e.fullCoverAwarded && (e.fullCoverAwarded = !0, a("appeal", 7));
	}
	for (let [n, i] of [["241", "water"], ["242", "rock"]]) H(e, n) && a("money", t.filter((t) => z(r, e.buildings, [t], i) > 0).length);
	return i;
}
function Lt(e, t, n) {
	let r = j(e, t.rid), i = F[r.map], a = U(r);
	if (t.moving !== null) {
		let i = e.reconstruction.buildings.find((e) => e.id === t.moving);
		r.buildings.push({
			...i,
			cells: n
		}), G(e, t.effects);
		return;
	}
	r.money -= Ft(r, t, n);
	let o = {
		id: Math.max(-1, ...r.buildings.map((e) => e.id)) + 1,
		kind: t.building,
		cells: n,
		occupied: !1,
		used: 0,
		extra: 0,
		card: t.building === "unique" ? t.source : null
	};
	r.buildings.push(o);
	let s = It(r, n, t.source), c = (e, n = 1, i = "") => s.push(A(r.rid, e, n, i, t.source));
	o.kind === "pavilion" && (c("appeal"), H(r, "276") && !r.cardTokens.gardener && (r.cardTokens.gardener = 1, c("x"))), (o.kind === "aquariumSmall" || o.kind === "aquariumLarge") && s.push(...Ot(e, r, ["water"], a, t.source));
	let l = M(e);
	l?.action === "build" && l.variant === 4 && t.rules.terrainAllowance && !H(r, "219") && n.some((e) => i.cells.find((t) => L(e) === L(t.at))?.terrain !== "plain") && (l.extraUsed = !0, l.upgraded && c("money", 2)), e.journal.push({
		key: "games.arknova.logBuild",
		rid: r.rid
	}), ([
		"aviary",
		"reptile",
		"aquariumSmall",
		"aquariumLarge"
	].includes(o.kind) || o.card === "279") && s.push(A(r.rid, "relocate", o.id)), G(e, [...s, ...t.effects]);
}
function Rt(e, t, n) {
	let r = new Set(R(t).map(L));
	return (F[e.map].sites[n] ?? []).some((e) => r.has(L(e)));
}
var zt = Object.keys(Pe);
//#endregion
//#region src/games/arknova/sponsors.ts
function Bt(e, t) {
	return Math.max(0, t.strength - (e.map === "8" && Pt(e, "hollywood_h") ? 1 : 0));
}
function Vt(e, t, n, r = 0) {
	return t.money < r || $e(e, t, n) > 0 ? !1 : !kt[n.id] || Mt(e, t, "unique", n.id, {
		upgraded: t.actions.some((e) => e.kind === "build" && e.upgraded),
		rock: n.rock,
		water: n.water
	});
}
function Ht(e, t, n, r) {
	let i = [], a = (e, r = 1, a = "") => i.push(A(t.rid, e, r, a, n.id)), o = U(t), s = (e) => o[e] ?? 0;
	switch (n.appeal && a("appeal", n.appeal), n.reputation && a("reputation", n.reputation), n.conservation && a("conservation", n.conservation), kt[n.id] && a("unique", 1, n.id), n.id) {
		case "201":
			a("takeRange");
			break;
		case "203":
			a("money", t.universities.length >= 3 ? 10 : t.universities.length === 2 ? 5 : t.universities.length === 1 ? 2 : 0);
			break;
		case "204":
			a("money", 2 * s("science"));
			break;
		case "206":
			a("appeal", 2 * t.bonuses.length);
			break;
		case "207":
		case "222": {
			let r = n.id === "207" ? Math.floor([...E, ...T].filter((e) => s(e) > 0).length / 2) : Math.min(3, s("science"));
			a("conservation", r);
			for (let a of e.players) a.rid !== t.rid && i.push(A(a.rid, "money", 2 * r, "", n.id));
			break;
		}
		case "208":
			a("appeal", s("science"));
			break;
		case "209":
		case "224":
		case "225":
			a("x");
			break;
		case "210":
		case "211":
		case "212":
		case "213":
		case "214":
			a("appeal", s({
				210: "americas",
				211: "europe",
				212: "australia",
				213: "asia",
				214: "africa"
			}[n.id]));
			break;
		case "215":
		case "218":
			t.cardTokens[n.id] = 2;
			break;
		case "216":
			a("worker");
			break;
		case "219":
			a("money", 2 * (s("rock") + s("water")));
			break;
		case "220":
			a("money", 3);
			break;
		case "227":
			a("assignment");
			break;
		case "228":
			a("money", 2 * t.animals.filter((e) => V(B(e))).length);
			break;
		case "229":
			a("appeal", t.animals.filter((e) => V(B(e))).length);
			break;
		case "230":
			a("appeal", 2 * t.animals.filter((e) => Ke(B(e))).length);
			break;
		case "231":
		case "232":
		case "233":
		case "234":
		case "235":
			a("appeal", s({
				231: "primate",
				232: "reptile",
				233: "bird",
				234: "predator",
				235: "herbivore"
			}[n.id]));
			break;
		case "241":
			a("appeal", s("water"));
			break;
		case "242":
			a("appeal", 3 * Math.floor(s("rock") / 2));
			break;
		case "253":
			t.cardTokens[n.id] = 3;
			break;
		case "254":
			a("takeRange");
			break;
		case "258":
		case "259": {
			let e = n.id === "258" ? "water" : "rock", r = We(F[t.map], t.buildings, e);
			a("appeal", r.connected), a("conservation", Math.floor(r.isolated / 2));
			break;
		}
		case "260":
			a("appeal", at(t)), a("conservation", Ue(F[t.map], t.buildings).reduce((e, t) => e + Math.floor(t / 6), 0));
			break;
		case "262":
			a("money", 2 * [...E, ...T].filter((e) => s(e) > 0).length);
			break;
		case "263":
			a("freeBuild", 1, "standard5");
			break;
		case "264": {
			let e = new Set(t.buildings.flatMap((e) => e.cells.map(L))), n = new Set(R(t.buildings.flatMap((e) => e.cells)).map(L)), r = F[t.map].cells.filter((t) => t.bonus && !e.has(L(t.at)));
			a("appeal", r.filter((e) => n.has(L(e.at))).length), a("conservation", Math.floor(r.filter((e) => !n.has(L(e.at))).length / 2));
			break;
		}
		case "265":
			a("freeBuild", 1, "kiosk");
			break;
		case "267": {
			let e = t.buildings.filter((e) => e.kind === "kiosk" || e.kind === "pavilion").length;
			a("appeal", e >= 7 ? 5 : e >= 4 ? 3 : +(e >= 1));
			break;
		}
		case "268":
			a("money", s("europe") >= 5 ? 10 : s("europe") >= 3 ? 5 : s("europe") >= 1 ? 2 : 0);
			break;
		case "272":
			a("freeBuild", 1, "standard3");
			break;
		case "273":
			a("donation");
			break;
		case "275":
			a("discardPet");
			break;
		case "276":
			a("gardener");
			break;
		case "280": a("reconstruct");
	}
	let c = [
		...n.tags,
		...n.id === "279" ? [] : Array(n.water).fill("water"),
		...Array(n.rock).fill("rock")
	];
	return i.push(...Ot(e, t, c, r, n.id)), i;
}
function Ut(e, t, n, r) {
	let i = B(n), a = [], o = (e, r = 1, i = "") => a.push(A(t.rid, e, r, i, n));
	o("appeal", i.appeal), i.reputation && o("reputation", i.reputation), i.conservation && o("conservation", i.conservation);
	for (let r of i.abilities) {
		let i = A(t.rid, r.ability, typeof r.value == "number" ? r.value : 1, typeof r.value == "string" ? r.value : "", n);
		/^(BOOST_|ACTION_|CLEVER$|MARK$|DETERMINATION$|HYPNOSIS$)/.test(i.op) && i.op !== "HYPNOSIS" ? ht(e, i) : a.push(i);
	}
	if (i.reefDweller) for (let n of t.animals) for (let r of B(n).reef) {
		let i = A(t.rid, r.ability, typeof r.value == "number" ? r.value : 1, typeof r.value == "string" ? r.value : "", n);
		i.op === "MARK" || i.op === "CLEVER" ? ht(e, i) : a.push(i);
	}
	return a.push(...Ot(e, t, [
		...i.tags,
		...Array(i.water).fill("water"),
		...Array(i.rock).fill("rock")
	], r, n)), t.assignment === "small" && V(i) && o("appeal", 2), t.assignment === "large" && Ke(i) && o("appeal", 4), a;
}
function Wt(e, t) {
	let n = [], r = U(t), i = (e, r, i = 1) => n.push(A(t.rid, r, i, "", e));
	for (let n of t.sponsors) {
		n === "201" && i(n, "takeRange"), n === "206" && i(n, "conservation"), n === "209" && i(n, "x"), n === "220" && i(n, "money", 3), n === "274" && i(n, "appeal");
		let a = {
			231: "primate",
			232: "reptile",
			233: "bird",
			234: "predator",
			235: "herbivore"
		}[n];
		if (a) {
			let e = r[a] ?? 0;
			i(n, "money", e >= 5 ? 9 : e >= 3 ? 6 : e >= 1 ? 3 : 0);
		}
		if (n === "265" && i(n, "money", e.players.filter((e) => e.rid !== t.rid).reduce((e, t) => e + t.buildings.filter((e) => e.kind === "kiosk").length, 0)), n === "257") {
			let e = t.buildings.find((e) => e.card === n);
			e && i(n, "money", 2 * Ve(t.buildings, e).filter((e) => !e.kind.startsWith("standard") || e.occupied).length);
		}
	}
	if (t.map === "5") {
		let e = F[t.map].sites.park_restaurant ?? [], n = new Set(R(e).map(L));
		i("map5", "money", t.buildings.flatMap((e) => e.cells).filter((e) => n.has(L(e))).length);
	}
	t.map === "7" && Pt(t, "ice_cream_parlors") && i("map7", "money", t.buildings.filter((e) => e.kind === "kiosk").length);
	for (let e of t.bonuses) if (F[t.map].tokens[e].income) for (let r of F[t.map].tokens[e].effects) n.push(A(t.rid, "bonus", 1, r, `map${t.map}`));
	return n;
}
function Gt(e, t, n) {
	let r = 0, i = 0, a = U(t), o = (e) => a[e] ?? 0, s = Ye(e, t, "all-animals"), c = Ye(e, t, "all-continents");
	switch (n) {
		case "201":
			i = o("science") >= 6 ? 2 : +(o("science") >= 3);
			break;
		case "203":
		case "209":
			i = Number(t.universities.length === 3);
			break;
		case "208":
		case "261":
			i = Number(s >= 5);
			break;
		case "210":
		case "265":
			i = Number(t.buildings.filter((e) => e.kind === "kiosk").length >= 5);
			break;
		case "211":
			i = Number(t.buildings.filter((e) => e.kind === "standard1" && e.occupied).length >= 5);
			break;
		case "214":
			r = t.x;
			break;
		case "215":
		case "218":
			i = Number(t.bonuses.length >= 5);
			break;
		case "216":
		case "220":
			i = Number(t.reputation >= 9);
			break;
		case "217":
		case "257":
		case "280":
			r = rt(t) ? 5 : 0;
			break;
		case "219":
			r = 2 * Math.min(3, o("water"), o("rock"));
			break;
		case "221":
		case "272":
			i = Number(rt(t, !0));
			break;
		case "225":
		case "226":
			i = Number(c === 5);
			break;
		case "241":
			i = Number(We(F[t.map], t.buildings, "water").isolated === 0);
			break;
		case "242":
			i = Number(We(F[t.map], t.buildings, "rock").isolated === 0);
			break;
		case "243":
		case "244":
		case "245":
		case "246":
		case "247":
			i = Number(o({
				243: "herbivore",
				244: "bird",
				245: "water",
				246: "rock",
				247: "primate"
			}[n]) >= 6);
			break;
		case "251":
			i = o("bear") >= 6 ? 2 : +(o("bear") >= 3);
			break;
		case "267": {
			let e = new Set(t.buildings.flatMap((e) => e.cells.map(L))), n = F[t.map];
			i = Math.min(3, t.buildings.filter((t) => t.kind === "kiosk" && R(t.cells).filter((t) => n.cells.some((e) => e.terrain === "plain" && L(e.at) === L(t)) && !e.has(L(t))).length >= 3).length);
			break;
		}
		case "268":
			i = Number(t.donations >= 3);
			break;
		case "269":
			r = Math.min(5, Object.values(t.pouched).reduce((e, t) => e + t, 0));
			break;
		case "271": {
			let e = new Set(t.buildings.flatMap((e) => e.cells.map(L)));
			i = Number(F[t.map].cells.filter((e) => e.bonus).every((t) => e.has(L(t.at))));
			break;
		}
		case "279": {
			let e = t.buildings.find((e) => e.card === n), i = e ? Ve(t.buildings, e).filter((e) => e.kind === "aquariumSmall" || e.kind === "aquariumLarge").length : 0;
			r = i >= 2 ? 5 : i === 1 ? 3 : 0;
			break;
		}
	}
	return {
		appeal: r,
		conservation: i
	};
}
function Kt(e) {
	let t = P[e];
	if (t.kind !== "sponsor") throw Error("Expected sponsor card");
	return t;
}
function qt(e, t) {
	let n = e.buildings.find((e) => e.id === t);
	return e.map === "1" && n && Rt(e, n.cells, "observation_tower") ? 2 : 0;
}
//#endregion
//#region src/games/arknova/projects.ts
function Jt(e) {
	let t = P[e];
	if (t.kind !== "project") throw Error("Expected conservation project");
	return t;
}
function Yt(e, t, n) {
	return e.animals.filter((e) => {
		let r = B(e);
		return r.tags.includes(t) && (n === 0 ? Ke(r) : n === 1 ? r.size === 3 : V(r));
	});
}
function Xt(e, t, n, r = 0) {
	let i = Jt(n), a = e.projects.find((e) => e.card === n), o = !a;
	if (t.bonuses.length >= F[t.map].tokens.length || t.money < r || a?.slots.includes(t.rid) && !(i.type === "release" && H(t, "224"))) return [];
	let s = [];
	for (let c = 0; c < 3; c++) {
		if (a?.slots[c]) continue;
		let l = i.slots[c].requirement, u = a?.base ? ["", ...[
			"215",
			"218",
			"wildcard"
		].filter((e) => (t.cardTokens[e] ?? 0) > 0)] : [""];
		for (let a of u) {
			let u = Ye(e, t, i.tag) + +!!a, d = i.type === "release" ? Yt(t, i.tag, c) : [""], f = i.type === "breed" && t.animals.some((e) => {
				let n = B(e);
				return n.tags.includes(i.tag) && t.partners.some((e) => n.tags.includes(e));
			});
			if (!(i.type !== "release" && (i.type === "breed" ? !f : u < l))) {
				for (let e of d) for (let l = 0; l < F[t.map].tokens.length; l++) if (!t.bonuses.includes(l)) {
					let u = JSON.stringify({
						id: n,
						slot: c,
						bonus: l,
						wildcard: a,
						animal: e,
						marketCost: r,
						isNew: o
					}), d = F[t.map].tokens[l];
					s.push(N("games.arknova.support", [A(t.rid, "supportProject", 1, u, n)], i.slots[c].conservation * 5 + d.effects.length, {
						card: n,
						value: c + 1,
						params: {
							n: c + 1,
							bonus: l + 1,
							reward: d.effects.join("|"),
							income: Number(d.income),
							wildcard: a,
							animal: e,
							conservation: i.slots[c].conservation,
							reputation: i.slots[c].reputation,
							slotEffect: i.slots[c].effect ?? "",
							firstEffect: o && i.type === "management" ? Zt(i, !0) : ""
						}
					}));
				}
			}
		}
	}
	return s;
}
var Zt = (e, t, n = 0) => t ? e.id === "138" ? "reputation1" : e.slots[0].effect ?? "" : e.slots[n].effect ?? "", Qt = {
	animals: "games.arknova.animals",
	build: "games.arknova.build",
	cards: "games.arknova.cardsAction",
	association: "games.arknova.association",
	sponsors: "games.arknova.sponsors"
}, $t = {
	standard1: "games.arknova.buildings.standard1",
	standard2: "games.arknova.buildings.standard2",
	standard3: "games.arknova.buildings.standard3",
	standard4: "games.arknova.buildings.standard4",
	standard5: "games.arknova.buildings.standard5",
	kiosk: "games.arknova.buildings.kiosk",
	pavilion: "games.arknova.buildings.pavilion",
	petting: "games.arknova.buildings.petting",
	aviary: "games.arknova.buildings.aviary",
	reptile: "games.arknova.buildings.reptile",
	aquariumSmall: "games.arknova.buildings.aquariumSmall",
	aquariumLarge: "games.arknova.buildings.aquariumLarge",
	unique: "games.arknova.buildings.unique"
};
function en(e, t, n = "any", r = t.rid, i = 5, a = !0) {
	let o = [], s = j(e, r).actions;
	for (let e = 0; e < Math.min(i, s.length); e++) {
		let i = s[e];
		if (n !== "any" && i.kind !== n) continue;
		let c = e + 1 - (i.constriction ? 2 : 0);
		for (let e = 0; e <= t.x; e++) if (c + e > 0) for (let n = 0; n <= (r === t.rid ? i.multiplier : 0); n++) {
			let a = JSON.stringify({
				kind: i.kind,
				owner: r,
				x: e,
				m: n,
				base: c,
				asX: !1
			});
			o.push(N("games.arknova.action", [A(t.rid, "startAction", 1, a)], c + e - e * .7, {
				action: i.kind,
				value: c + e,
				params: {
					n: c + e,
					x: e,
					m: n
				}
			}));
		}
		if (a && t.x < 5) for (let e = 0; e <= Math.min(4 - t.x, r === t.rid ? i.multiplier : 0); e++) o.push(N("games.arknova.gainX", [A(t.rid, "startAction", 1, JSON.stringify({
			kind: i.kind,
			owner: r,
			x: 0,
			m: e,
			base: c,
			asX: !0
		}))], 1, {
			action: i.kind,
			params: { m: e }
		}));
	}
	return o.filter((n) => {
		if (n.key === "games.arknova.gainX") return !0;
		let r = structuredClone(e);
		return tn(r, t.rid, n.effects[0].arg, !0), dn(r, M(r)).length > 0;
	});
}
function tn(e, t, n, r = !1) {
	let i = JSON.parse(n), a = j(e, t), o = j(e, i.owner).actions.find((e) => e.kind === i.kind);
	!r && !e.turnStart && e.phase === "play" && (e.turnStart = JSON.stringify(e), G(e, [A(t, "finishTurn")], !0)), a.x -= i.x, o.venom &&= (a.removedVenom = !0, !1), o.multiplier -= i.m;
	let s = i.base + i.x, c = {
		kind: "action",
		rid: t,
		owner: i.owner,
		action: i.kind,
		upgraded: o.upgraded,
		variant: o.variant,
		strength: s,
		baseStrength: i.base,
		repeatMode: i.asX ? "x" : "action",
		remaining: 0,
		spent: 0,
		performed: 0,
		built: [],
		played: [],
		tasks: [],
		extraUsed: !1,
		donation: !1,
		bonusUsed: !1,
		moneyAtStart: a.money,
		after: [],
		repeats: i.m,
		mode: "main"
	};
	e.frames.push(c), nn(e, c);
}
function nn(e, t) {
	let n = j(e, t.rid);
	if (t.remaining = t.strength, t.repeatMode === "x") {
		t.performed = 1, G(e, [A(n.rid, "x")]);
		return;
	}
	t.action === "animals" && (t.remaining = !t.upgraded && t.strength < 2 ? 0 : t.strength >= (t.upgraded ? 3 : 5) ? 2 : 1, t.upgraded && t.strength >= 5 && (vt(e, n, 1), t.performed++), t.variant === 2 && t.after.push(A(n.rid, "animalHunter", t.upgraded ? 6 : 4)), t.variant === 4 && t.after.push(A(n.rid, "MARK"))), t.action === "build" && t.variant === 3 && t.remaining++, t.action === "sponsors" && t.upgraded && t.remaining++, t.action === "cards" && (t.variant === 2 && G(e, [A(n.rid, "DIGGING", t.upgraded ? 2 : 1)]), t.variant === 4 && t.after.push(A(n.rid, "cleverPaid", t.upgraded ? 0 : 2)));
}
function rn(e, t) {
	let n = M(e);
	return Math.max(0, ke(e.players.length, e.donations) - (H(t, "273") ? U(t).science ?? 0 : 0) - (n?.action === "association" && n.variant === 3 && n.upgraded ? t.x : 0));
}
function an(e, t, n) {
	let r = [];
	for (let i of zt) {
		let a = Pe[i].length, o = (!n.built.length || n.upgraded) && a <= n.remaining && (!n.built.includes(i) || n.variant === 3 && n.upgraded && i.startsWith("standard")), s = H(t, "217") && !n.tasks.includes("engineer") && n.built.includes(i) && (i.startsWith("standard") || i === "kiosk" || i === "pavilion"), c = n.variant === (i === "pavilion" ? 1 : i === "kiosk" ? 2 : -1) && !n.tasks.includes("extra");
		if (!(o || s || c) || !jt(e, t, i, n.upgraded)) continue;
		let l = At(t, i, "", {
			upgraded: n.upgraded,
			terrainAllowance: +(n.variant === 4 && !n.extraUsed)
		});
		for (let e of [
			o ? "regular" : "",
			s ? "engineer" : "",
			c ? "extra" : ""
		].filter(Boolean)) {
			let o = a * 2 + +(e === "extra" && !n.upgraded), s = {
				...l,
				terrainAllowance: !n.upgraded && t.money < o + 2 ? 0 : l.terrainAllowance
			};
			t.money < o || Be(F[t.map], t.buildings, i, s).length === 0 || r.push(N("games.arknova.buildBuilding", [A(t.rid, "beginBuild", o, JSON.stringify({
				kind: i,
				mode: e,
				rules: s
			}))], a + 2, {
				building: i,
				value: o
			}));
		}
	}
	return r;
}
function on(e, t, n) {
	let r = [];
	if (n.remaining <= 0) return r;
	let i = [...t.hand.map((e) => ({
		id: e,
		cost: 0
	})), ...n.upgraded ? e.market.slice(0, De(t.reputation)).flatMap((e, t) => e ? [{
		id: e,
		cost: t + 1
	}] : []) : []];
	for (let { id: a, cost: o } of i) {
		let i = P[a];
		i.kind === "animal" && tt(e, t, i, o) && (n.tasks.includes("smallOnly") && (!V(i) || o > 0) || r.push(N("games.arknova.playCard", [A(t.rid, "chooseHabitat", o, a)], i.appeal + i.conservation * 5 + i.reputation * 2 + i.abilities.length * 2, { card: a })));
	}
	return r;
}
function sn(e, t, n) {
	let r = [];
	if (n.mode === "cash" || !n.upgraded && n.performed > 0) return r;
	for (let [i, a] of [...t.hand.map((e) => [e, 0]), ...n.upgraded ? e.market.slice(0, De(t.reputation)).flatMap((e, t) => e ? [[e, t + 1]] : []) : []]) {
		let o = P[i];
		if (o.kind !== "sponsor" || !Vt(e, t, o, a)) continue;
		let s = Math.max(0, Bt(t, o) - (n.tasks.includes("discount") ? 2 : 0));
		s > n.remaining || r.push(N("games.arknova.playCard", [A(t.rid, "playSponsor", a, JSON.stringify({
			id: i,
			level: s
		}))], 4 + o.appeal + o.reputation * 2 + o.conservation * 5, { card: i }));
	}
	return r;
}
function cn(e, t, n) {
	let r = [], i = t.workers - Object.values(t.workersUsed).reduce((e, t) => e + t, 0);
	for (let a of [
		"reputation",
		"partner",
		"university",
		"project"
	]) {
		if (n.tasks.includes(a) || !n.upgraded && n.performed) continue;
		let o = a === "reputation" ? 2 : a === "partner" ? 3 : a === "university" || H(t, "203") ? 4 : 5, s = t.workersUsed[a] ?? 0, c = s === 0 ? 1 : s === 1 ? 2 : 5;
		for (let s = 0; s <= (n.variant === 2 && n.upgraded ? i - c : 0); s++) {
			let l = Math.max(0, o - s * 2);
			if (i < c + s || n.remaining < l) continue;
			let u = A(t.rid, "associationTask", l, JSON.stringify({
				task: a,
				workers: c + s
			}));
			if (a === "reputation" && r.push(N("games.arknova.taskReputation", [u, A(t.rid, "reputation", 2)], 4)), a === "partner") for (let i of ln(e, t, n.variant === 1)) r.push(N("games.arknova.takePartner", [u, A(t.rid, "partner", 1, i)], 7, { params: { tag: i } }));
			if (a === "university") for (let i of un(e, t, n.variant === 1 && n.upgraded)) r.push(N("games.arknova.takeUniversity", [u, A(t.rid, "university", 1, i)], 8, { params: { university: i } }));
			if (a === "project") {
				let a = [
					...e.projects.map((e) => ({
						id: e.card,
						cost: 0
					})),
					...t.hand.filter((e) => P[e].kind === "project").map((e) => ({
						id: e,
						cost: 0
					})),
					...n.upgraded ? e.market.slice(0, De(t.reputation)).flatMap((e, t) => e && P[e].kind === "project" ? [{
						id: e,
						cost: t + 1
					}] : []) : []
				];
				for (let { id: n, cost: i } of a) {
					let a = Xt(e, t, n, i);
					a.length && r.push(N("games.arknova.support", [u, A(t.rid, "projectMenu", i, n)], Math.max(...a.map((e) => e.score)), { card: n }));
				}
				n.variant === 2 && !n.upgraded && t.workers < 4 && i >= c + 1 && r.push(N("games.arknova.hire", [u, A(t.rid, "workerAtProject")], 7));
			}
		}
	}
	if (n.upgraded && n.performed && !n.donation) {
		let i = rn(e, t);
		t.money >= i && r.push(N("games.arknova.donate", [A(t.rid, "donate", i)], 6, { params: { n: i } })), n.variant === 4 && r.push(N("games.arknova.takeCard", [A(t.rid, "associationDraw")], 2));
	}
	return n.variant === 4 && !n.upgraded && n.strength >= 5 && !n.performed && r.push(N("games.arknova.ability", [A(t.rid, "associationDetermination")], 7)), r;
}
function ln(e, t, n = !1) {
	let r = M(e), i = r?.action === "association" && r.rid === t.rid ? r.upgraded : qe(t, "association");
	return t.partners.length >= (i ? 4 : 2) ? [] : n ? T.filter((t) => e.players.reduce((e, n) => e + n.partners.filter((e) => e === t).length, 0) + +!!e.partnerSupply.includes(t) < e.players.length) : e.partnerSupply.filter((e) => !t.partners.includes(e));
}
function un(e, t, n = !1) {
	return t.universities.length >= 3 ? [] : n ? [
		"hand",
		"science2",
		"science_rep",
		...e.marineUniversities.map((e) => `animal:${e}`)
	].filter((t) => t.startsWith("animal:") || e.players.reduce((e, n) => e + n.universities.filter((e) => e === t).length, 0) + +!!e.universitySupply.includes(t) < e.players.length) : e.universitySupply.flatMap((n) => n === "animal" ? t.universities.some((e) => e.startsWith("animal:")) ? [] : e.marineUniversities.map((e) => `animal:${e}`) : [n]).filter((e) => !t.universities.includes(e));
}
function dn(e, t) {
	let n = j(e, t.rid), r = [];
	if (t.repeatMode === "action") {
		if (t.action === "build" && r.push(...an(e, n, t)), t.action === "animals" && r.push(...on(e, n, t)), t.action === "sponsors" && (r.push(...sn(e, n, t)), t.performed === 0 && r.push(N("games.arknova.sponsorCash", [A(n.rid, "sponsorCash")], n.money < 10 ? 8 : 2)), t.variant === 1 && !t.bonusUsed && (n.x > 0 && r.push(N("games.arknova.tradeX", [A(n.rid, "sponsorTrade", 1, "x")], n.money < 15 ? 4 : 0)), n.money >= 5 && n.x < 5 && r.push(N("games.arknova.tradeMoney", [A(n.rid, "sponsorTrade", 1, "money")], 1)), t.upgraded && n.money >= 5 && r.push(N("games.arknova.tradeReputationMoney", [A(n.rid, "sponsorTrade", 1, "repMoney")], 2)), t.upgraded && n.x > 0 && r.push(N("games.arknova.tradeReputationX", [A(n.rid, "sponsorTrade", 1, "repX")], 3))), (t.variant === 3 || t.variant === 4) && !t.bonusUsed)) for (let i of n.hand) (t.upgraded || P[i].kind === "sponsor") && (t.variant === 3 && (r.push(N("games.arknova.sellCard", [A(n.rid, "sponsorDiscard", 1, i)], 2, { card: i })), t.upgraded && t.mode !== "cash" && r.push(N("games.arknova.discountSponsor", [A(n.rid, "sponsorDiscount", 1, i)], 1, { card: i }))), t.variant === 4 && !t.upgraded && e.market.some((e) => e && P[e].kind === "sponsor") && r.push(N("games.arknova.discard", [A(n.rid, "sponsorSnap", 1, i)], 1, { card: i })), t.variant === 4 && t.upgraded && t.mode === "cash" && r.push(N("games.arknova.discard", [A(n.rid, "sponsorMarketing", 1, i)], 1, { card: i })));
		if (t.action === "association" && r.push(...cn(e, n, t)), t.action === "cards" && !t.performed) {
			r.push(N("games.arknova.drawCards", [A(n.rid, "cardsDraw")], 5));
			let i = t.variant === 3 ? t.upgraded ? 2 : 3 : t.upgraded ? 3 : 5;
			t.strength >= i && e.market.some(Boolean) && r.push(N("games.arknova.snap", [A(n.rid, "cardsSnap", t.variant === 3 && t.upgraded && t.strength >= 5 ? 2 : 1)], 5));
		}
		t.action === "animals" && t.played.length && t.played.every((e) => V(B(e))) && H(n, "228") && !t.tasks.includes("smallProgram") && r.push(N("games.arknova.smallProgram", [A(n.rid, "smallProgram")], 2));
	}
	return t.performed && r.push(N("games.arknova.finish", [A(n.rid, "finishAction")], r.length ? -2 : 10)), r;
}
function fn(e, t, n, r) {
	let { kind: i, mode: a, rules: o } = JSON.parse(r);
	e.frames.push(Nt(e, t, i, "", n, !1, [A(t, "recordBuild", Pe[i].length, JSON.stringify({
		kind: i,
		mode: a
	}))], o));
}
function pn(e, t) {
	t.performed++, bt(e, j(e, t.rid), 2);
	let [n, r] = (t.upgraded ? Se : I)[Math.min(5, t.strength) - 1];
	G(e, [A(t.rid, t.upgraded ? "takeRange" : "draw", n), A(t.rid, "discardHand", t.variant === 1 ? 0 : r)], !0);
}
function mn(e, t) {
	if (t.repeats > 0) {
		e.frames.pop(), G(e, [A(t.rid, "repeatAction", 1, JSON.stringify({
			...t,
			repeats: t.repeats - 1
		}))], !0);
		return;
	}
	let n = j(e, t.owner), r = n.actions.find((e) => e.kind === t.action);
	r.constriction = !1, xt(n, t.action, 1), e.frames.pop(), G(e, t.after);
}
function hn(e, t, n) {
	let r = JSON.parse(n), i = j(e, t), a = N("games.arknova.finish", [A(t, "endRepeats", 0, n)], -5);
	return r.repeatMode === "x" ? [...i.x < 5 ? [N("games.arknova.gainX", [A(t, "repeatStart", 0, n)], 1)] : [], a] : [...Array.from({ length: i.x + 1 }, (e, t) => t).filter((e) => r.baseStrength + e > 0).filter((n) => {
		let a = structuredClone(e), o = {
			...structuredClone(r),
			strength: r.baseStrength + n,
			remaining: 0,
			performed: 0,
			built: [],
			played: [],
			tasks: [],
			extraUsed: !1,
			donation: !1,
			bonusUsed: !1,
			moneyAtStart: i.money,
			mode: "main"
		};
		return j(a, t).x -= n, a.frames.push(o), nn(a, o), dn(a, o).length > 0;
	}).map((e) => N("games.arknova.action", [A(t, "repeatStart", e, n)], r.baseStrength + e, {
		action: r.action,
		params: {
			n: r.baseStrength + e,
			x: e
		}
	})), a];
}
function gn(e) {
	return e.map === "4" && !e.harborUsed && Pt(e, "harbor_connecting_building_space");
}
function _n(e, t, n, r = t, i = 5) {
	return en(e, j(e, t), n, r, i, n === "any");
}
//#endregion
//#region src/games/arknova/lifecycle.ts
function vn(e, t) {
	if (e.endBy) return;
	let n = e.players.find((e) => e.rid === t);
	Ee(n.appeal, n.conservation) >= 0 && (e.endBy = t, e.finalTurns = e.phase === "break" ? e.players.length : e.players.length - 1);
}
function yn(e) {
	let t = e.players[e.turn];
	if (!t.removedVenom && t.actions.some((e) => e.venom)) {
		if (t.money < 2) {
			if (!e.turnStart) throw Error("Missing turn rollback");
			let n = e.revision, r = JSON.parse(e.turnStart);
			Object.assign(e, r, {
				revision: n,
				turnStart: null
			}), e.journal.push({
				key: "games.arknova.logUndoVenom",
				rid: t.rid
			});
			return;
		}
		t.money -= 2;
	}
	pt(e), e.finalTurns === null ? vn(e, t.rid) : e.finalTurns--, t.camouflage = 0, t.ignoredConditions = 0, t.harborUsed = !1, t.removedVenom = !1, t.cardTokens.gardener = 0, e.journal.push({
		key: "games.arknova.logTurn",
		rid: t.rid
	}), e.turn = (e.turn + 1) % e.players.length, e.turnNumber++, e.turnStart = null, e.breakBy ? bn(e) : e.finalTurns !== null && e.finalTurns <= 0 && wn(e);
}
function bn(e) {
	e.phase = "break", e.breakStage = 0, e.breakPlayer = e.players.findIndex((t) => t.rid === e.breakBy), e.breakNumber++, e.journal.push({
		key: "games.arknova.logBreak",
		rid: e.breakBy
	});
	let t = e.players.flatMap((e) => e.hand.length > Je(e) ? [A(e.rid, "discardHand", e.hand.length - Je(e))] : []);
	t.push(A(e.breakBy, "breakCleanup")), G(e, t, !0);
}
function xn(e) {
	for (let t of e.players) {
		for (let e of t.actions) e.multiplier = 0, e.venom = !1, e.constriction = !1;
		t.workersUsed = {}, t.cardTokens.gardener = 0;
	}
	e.partnerSupply = T.filter((t) => e.players.some((e) => !e.partners.includes(t))), e.universitySupply = [
		"hand",
		"science2",
		"science_rep"
	].filter((t) => e.players.some((e) => !e.universities.includes(t))), e.config.marine && e.marineUniversities.length && e.universitySupply.push("animal"), ft(e, 0, !0), ft(e, 1, !0), pt(e), e.breakStage = 1, G(e, [A(e.players[e.breakPlayer].rid, "breakIncome")], !0);
}
function Sn(e, t) {
	let n = e.players.find((e) => e.rid === t), r = [A(t, "money", we(n.appeal) + He(n.buildings)), ...Wt(e, n)];
	G(e, [A(t, "breakNext")], !0), G(e, r);
}
function Cn(e) {
	pt(e);
	for (let t of e.players) vn(e, t.rid);
	if (e.breakStage++, e.breakStage <= e.players.length) {
		e.breakPlayer = (e.breakPlayer + 1) % e.players.length, G(e, [A(e.players[e.breakPlayer].rid, "breakIncome")], !0);
		return;
	}
	e.breakProgress = 0, e.breakBy = null, e.breakStage = 0, e.phase = "play";
	for (let t of e.players) t.cardTokens.gardener = 0;
	e.finalTurns !== null && e.finalTurns <= 0 && wn(e);
}
function wn(e) {
	e.phase = "final";
	let t = e.finalDiscardTriggered ? [] : e.players.map((e) => A(e.rid, "discardFinal"));
	t.push(A(e.players[0].rid, "scoreFinal")), G(e, t, !0);
}
function Tn(e) {
	let t = {};
	for (let n of e.players) {
		t[n.rid] = n.finals.map((t) => ({
			card: t,
			appeal: 0,
			conservation: it(e, n, t)
		}));
		for (let r of n.sponsors) {
			let i = Gt(e, n, r);
			(i.appeal || i.conservation) && t[n.rid].push({
				card: r,
				...i
			});
		}
	}
	for (let n of e.players) for (let r of t[n.rid]) K(n, r.appeal), _t(e, n, r.conservation, !0);
	let n = e.players.map((e) => e.appeal);
	for (let r = 0; r < e.players.length; r++) {
		let i = e.players[r];
		if (H(i, "274")) {
			let e = 2 * n.filter((e) => e > n[r]).length;
			t[i.rid].push({
				card: "274",
				appeal: e,
				conservation: 0
			}), K(i, e);
		}
	}
	e.finalBreakdown = t, e.phase = "done", e.frames = [], e.turnStart = null;
}
function En(e, t, n) {
	return F[e.players.find((e) => e.rid === t).map].tokens[n].effects.map((e) => A(t, "bonus", 1, e));
}
//#endregion
//#region src/games/arknova/effects.ts
function Dn(e, t) {
	let n = t.card ? Kt(t.card) : null;
	return At(e, t.kind, t.card ?? "", {
		upgraded: qe(e, "build"),
		...n ? {
			water: n.water,
			rock: n.rock
		} : {}
	});
}
function q(e, t, n, r, i = !1) {
	r.length && (i && r.push(N("games.arknova.skip", [], -5)), e.frames.push({
		kind: "decision",
		rid: t,
		prompt: n,
		choices: r
	}));
}
function On(e, t, n, r, i = !1, a = () => !0) {
	let o = t.hand.filter(a).map((e) => N(r === "sell" ? "games.arknova.sellCard" : r === "pouch" ? "games.arknova.pouchCard" : "games.arknova.discard", [A(t.rid, r, 1, e, n.source), ...n.n > 1 ? [{
		...n,
		n: n.n - 1
	}] : []], 0, { card: e }));
	q(e, t.rid, r === "sell" ? "games.arknova.sellCard" : "games.arknova.discard", o, i);
}
function kn(e, t, n, r, i = () => !0, a = !1) {
	let o = [];
	a && (e.deck.length || e.discard.length) && o.push(N("games.arknova.drawDeck", [A(t.rid, "draw"), ...n.n > 1 ? [{
		...n,
		n: n.n - 1
	}] : []], 1));
	for (let a = 0; a < (r ? De(t.reputation) : 6); a++) {
		let r = e.market[a];
		r && i(r) && o.push(N("games.arknova.takeCard", [A(t.rid, "takeMarket", a, r), ...n.n > 1 ? [{
			...n,
			n: n.n - 1
		}] : []], P[r].kind === "animal" ? 3 : 2, { card: r }));
	}
	q(e, t.rid, r ? "games.arknova.takeCard" : "games.arknova.snap", o);
}
function An(e, t, n, r, i = 1, a = !1) {
	let o = [];
	if (a) e.discard = W(e, e.discard), o.push(...e.discard.splice(0, n));
	else for (let t = 0; t < n; t++) {
		let t = ut(e);
		t && o.push(t);
	}
	jn(e, t, o, r, i);
}
function jn(e, t, n, r, i) {
	let a = n.filter(r);
	if (!i || !a.length) {
		e.discard.push(...n);
		return;
	}
	q(e, t.rid, "games.arknova.takeCard", a.map((e) => N("games.arknova.takeCard", [A(t.rid, "keepRevealed", i, JSON.stringify({
		id: e,
		remaining: n.filter((t) => t !== e),
		allowed: a.filter((t) => t !== e)
	}))], P[e].kind === "animal" ? 3 : 2, { card: e })));
}
function Mn(e, t, n) {
	n <= 0 || t.finals.length <= 1 || q(e, t.rid, "games.arknova.finalDiscard", t.finals.map((e) => N("games.arknova.finalDiscard", [A(t.rid, "removeFinal", n, e)], -1, { card: e })));
}
function Nn(e, t) {
	let n = e.players.filter((e) => !H(e, "225") && e.appeal >= 5 && e[t] >= (t === "appeal" ? 5 : 1)), r = Math.max(0, ...n.map((e) => e[t]));
	return n.filter((e) => e[t] === r);
}
function Pn(e, t, n, r, i, a) {
	let o = Nn(e, r);
	q(e, t.rid, "games.arknova.targetPlayer", o.map((e) => N("games.arknova.targetPlayer", e.rid === t.rid ? [] : [A(e.rid, n, i, t.rid, a)], e.rid === t.rid ? 0 : 3, { params: { rid: e.rid } })));
}
function Fn(e, t, n) {
	let r = JSON.parse(n.arg), i = B(r.id), a = M(e), o = U(t), s = $e(e, t, i), c = +(a?.variant === 1 && a.action === "animals" && a.remaining === 2);
	if (a && s > et(e, t, i) - c && (a.remaining = 1), s && t.camouflage && (t.camouflage = 0), t.ignoredConditions &&= 0, t.money -= Qe(e, t, i, r.cost), r.cost) {
		let n = e.market.indexOf(i.id), r = e.marks[i.id] === t.rid;
		ft(e, n), r && a?.variant === 4 && a.upgraded && G(e, [A(t.rid, "reputation")]);
	} else t.hand.splice(t.hand.indexOf(i.id), 1);
	for (let e of r.allocations) {
		let n = t.buildings.find((t) => t.id === e.building);
		n.kind.startsWith("standard") ? n.occupied = !0 : n.used += e.markers;
	}
	t.animals.push(i.id), a && (a.played.push(i.id), a.remaining--, a.performed++);
	let l = Ut(e, t, i.id, o);
	for (let e of r.allocations) {
		let n = t.buildings.find((t) => t.id === e.building);
		if (n.kind.startsWith("standard")) {
			let e = qt(t, n.id);
			e && l.push(A(t.rid, "appeal", e));
		}
	}
	a?.action === "animals" && a.variant === 3 && a.upgraded && l.push(A(t.rid, "paidAppeal", 1, i.id)), G(e, l), e.journal.push({
		key: "games.arknova.logPlay",
		rid: t.rid,
		card: i.id
	});
}
function In(e, t, n, r = !1) {
	let { id: i, level: a } = JSON.parse(n.arg), o = Kt(i), s = U(t), c = M(e);
	t.money -= n.n, e.market.includes(i) ? ft(e, e.market.indexOf(i)) : t.hand.splice(t.hand.indexOf(i), 1), t.sponsors.push(i), !r && c && (c.remaining -= a, c.played.push(i), c.performed++, c.tasks = c.tasks.filter((e) => e !== "discount")), G(e, Ht(e, t, o, s)), e.journal.push({
		key: "games.arknova.logPlay",
		rid: t.rid,
		card: i
	});
}
function Ln(e, t, n) {
	let r = JSON.parse(n.arg), i = Jt(r.id), a = [];
	if (r.isNew) {
		r.marketCost ? (t.money -= r.marketCost, ft(e, e.market.indexOf(r.id))) : t.hand.splice(t.hand.indexOf(r.id), 1);
		let n = {
			card: r.id,
			base: !1,
			owner: t.rid,
			slots: [
				null,
				null,
				null
			]
		}, o = e.projects.filter((e) => e.base), s = e.projects.filter((e) => !e.base);
		s.unshift(n), s.length > e.players.length && e.discard.push(s.pop().card), e.projects = [...o, ...s], i.type === "release" && a.push(A(t.rid, "reputation")), i.type === "management" && a.push(A(t.rid, "bonus", 1, Zt(i, !0), i.id));
	}
	r.animal && Rn(e, t, r.animal), e.projects.find((e) => e.card === r.id).slots[r.slot] = t.rid, r.wildcard && t.cardTokens[r.wildcard]--, t.bonuses.push(r.bonus);
	let o = i.slots[r.slot];
	a.push(...En(e, t.rid, r.bonus), A(t.rid, "conservation", o.conservation + (i.type === "release" && H(t, "224") ? 1 : 0)), A(t.rid, "reputation", o.reputation)), o.effect && a.push(A(t.rid, "projectReward", 1, JSON.stringify({
		id: i.id,
		slot: r.slot
	}))), G(e, a);
}
function Rn(e, t, n) {
	let r = B(n);
	K(t, -r.appeal), nt(t, r), t.animals.splice(t.animals.indexOf(n), 1), e.discard.push(n, ...t.pouchedCards[n] ?? []), delete t.pouched[n], delete t.pouchedCards[n];
}
function zn(e, t, n) {
	t.money += n;
	let r = M(e);
	n > 0 && r?.rid === t.rid && r.action === "sponsors" && r.variant === 2 && !r.bonusUsed && (r.bonusUsed = !0, t.money += r.upgraded ? 5 : 3);
}
function Bn(e, t, n) {
	if (n.arg === "sponsorMoney" && e.config.marine) {
		t.cardTokens.sponsorMoney = (t.cardTokens.sponsorMoney ?? 0) + 1;
		return;
	}
	let r = n.arg, i = /^(money|appeal|conservation|reputation|rep|xtoken|cards|card|clever|pouch|enclosure|upgrade|worker|partner|university)(\d+)?$/.exec(r);
	if (i) {
		let r = Number(i[2] ?? 1), a = {
			xtoken: "x",
			rep: "reputation",
			card: "takeRange",
			cards: "draw",
			clever: "CLEVER",
			pouch: "POUCH",
			enclosure: "freeBuild",
			partner: "partnerMenu",
			university: "universityMenu"
		}[i[1]] ?? i[1];
		G(e, [A(t.rid, a, a === "freeBuild" ? 1 : r, a === "freeBuild" ? `standard${r}` : "", n.source)]);
		return;
	}
	let a = {
		upgrade: "upgrade",
		worker: "worker",
		partner: "partnerMenu",
		university: "universityMenu",
		sponsorMoney: "MARKETING",
		multiplier: "multiplierMenu",
		posturing: "POSTURING",
		posturing3: "POSTURING",
		adapt3: "ADAPT",
		kiosk: "freeBuild",
		pavilion: "freeBuild",
		release: "releaseMenu",
		sunbathing2: "SUN_BATHING",
		xtoken2: "x",
		clever: "CLEVER",
		reef: "reefAll"
	};
	if (a[r]) {
		G(e, [A(t.rid, a[r], r === "posturing3" || r === "adapt3" ? 3 : r === "sunbathing2" || r === "xtoken2" ? 2 : 1, r === "kiosk" || r === "pavilion" ? r : "", n.source)]);
		return;
	}
	if ([
		"ignoreConditions",
		"extraShift",
		"wildcard"
	].includes(r)) {
		t.cardTokens[r] = (t.cardTokens[r] ?? 0) + 1;
		return;
	}
	if (r === "snapHandLimit") {
		t.cardTokens.handLimit = (t.cardTokens.handLimit ?? 0) + 1, G(e, [A(t.rid, "SNAPPING_1")]);
		return;
	}
	if (r === "specialEnclosure") {
		q(e, t.rid, "games.arknova.placeBuilding", ["reptile", "aviary"].filter((n) => Mt(e, t, n, "", void 0, !0)).map((e) => N("games.arknova.buildBuilding", [A(t.rid, "freeBuild", 1, e)], 3, { building: e })), !0);
		return;
	}
	if (r === "hunterPredators") {
		G(e, [A(t.rid, "HUNTER", U(t).predator ?? 0, "", n.source)]);
		return;
	}
	throw Error(`Unknown Ark Nova bonus: ${r}`);
}
function Vn(e, t, n) {
	let r = n.arg ? n.arg.split(",") : [], i = t.buildings.find((e) => e.id === n.n);
	if (!i) return;
	let a = [];
	for (let e of t.animals.filter((e) => !r.includes(e))) {
		let o = B(e), s = o.special.find((e) => e.kind === "aquarium" ? i.kind === "aquariumSmall" || i.kind === "aquariumLarge" || i.card === "279" : e.kind === i.kind);
		if (!s || s.capacity === 0) continue;
		let c = structuredClone(t);
		if (c.buildings = c.buildings.filter((e) => e.id !== i.id), nt(c, o)) {
			c.buildings.push(structuredClone(i));
			for (let s of Ze(c, o).filter((e) => e.allocations.some((e) => e.building === i.id) && !e.key.startsWith("standard:"))) a.push(N("games.arknova.moveAnimal", [A(t.rid, "relocateAnimal", n.n, JSON.stringify({
				id: e,
				moved: r,
				allocations: s.allocations
			}))], 2, {
				card: e,
				params: { n: s.allocations.map((e) => `${e.building + 1}: ${e.markers}`).join(", ") },
				cells: s.allocations.flatMap((e) => t.buildings.find((t) => t.id === e.building).cells)
			}));
		}
	}
	q(e, t.rid, "games.arknova.moveAnimal", a, !0);
}
function Hn(e, t) {
	let n = j(e, t.rid), r = M(e), i = (e, r = 1, i = "", a = t.source) => A(n.rid, e, r, i, a);
	switch (t.op) {
		case "money":
			zn(e, n, t.n);
			return;
		case "appeal":
		case "APPEAL":
			K(n, t.n), e.phase === "break" && vn(e, n.rid);
			return;
		case "conservation":
		case "CONSERVATION_POINT":
			_t(e, n, t.n), e.phase === "break" && vn(e, n.rid);
			return;
		case "reputation":
		case "REPUTATION":
			vt(e, n, t.n);
			return;
		case "x":
		case "INVENTIVE":
			gt(n, t.n);
			return;
		case "worker":
		case "FULL_THROATED":
			yt(e, n);
			return;
		case "draw":
		case "SPRINT":
			dt(e, n, t.n);
			return;
		case "break":
			bt(e, n, t.n);
			return;
		case "bonus":
			Bn(e, n, t);
			return;
		case "startAction":
			tn(e, n.rid, t.arg);
			return;
		case "finishAction":
			mn(e, r);
			return;
		case "finishTurn":
			yn(e);
			return;
		case "beginBuild":
			fn(e, n.rid, t.n, t.arg);
			return;
		case "recordBuild": {
			let { kind: e, mode: n } = JSON.parse(t.arg);
			r.built.push(e), r.performed++, n === "regular" ? r.remaining -= t.n : r.tasks.push(n);
			return;
		}
		case "repeatAction":
			q(e, n.rid, "games.arknova.action", hn(e, n.rid, t.arg));
			return;
		case "endRepeats": {
			let n = JSON.parse(t.arg);
			n.repeats = 0, e.frames.push(n), mn(e, n);
			return;
		}
		case "repeatStart": {
			let r = JSON.parse(t.arg);
			n.x -= t.n;
			let i = {
				...r,
				strength: r.baseStrength + t.n,
				remaining: 0,
				spent: 0,
				performed: 0,
				built: [],
				played: [],
				tasks: [],
				extraUsed: !1,
				donation: !1,
				bonusUsed: !1,
				moneyAtStart: n.money,
				mode: "main"
			};
			e.frames.push(i), nn(e, i);
			return;
		}
		case "cardsDraw":
			pn(e, r);
			return;
		case "cardsSnap":
			r.performed++, bt(e, n, 2), G(e, [i("snapNoRefill", t.n)]);
			return;
		case "snapNoRefill":
			kn(e, n, t, !1);
			return;
		case "takeRange":
		case "TAKE_CARD_IN_RANGE":
			kn(e, n, t, !0, () => !0, !0);
			return;
		case "takeMarket": {
			let r = ft(e, t.n);
			r && n.hand.push(r);
			return;
		}
		case "discardHand":
			t.n > 0 && On(e, n, t, "discard");
			return;
		case "discard":
			n.hand.splice(n.hand.indexOf(t.arg), 1), e.discard.push(t.arg);
			return;
		case "sell":
			n.hand.splice(n.hand.indexOf(t.arg), 1), e.discard.push(t.arg), zn(e, n, 4);
			return;
		case "SUN_BATHING":
			On(e, n, t, "sell", !0);
			return;
		case "pouch":
			n.hand.splice(n.hand.indexOf(t.arg), 1), n.pouched[t.source] = (n.pouched[t.source] ?? 0) + 1, (n.pouchedCards[t.source] ??= []).push(t.arg), K(n, 2);
			return;
		case "POUCH":
			On(e, n, t, "pouch", !0);
			return;
		case "keepRevealed": {
			let { id: r, remaining: i, allowed: a } = JSON.parse(t.arg);
			n.hand.push(r), jn(e, n, i, (e) => a.includes(e), t.n - 1);
			return;
		}
		case "HUNTER":
			An(e, n, t.n, (e) => P[e].kind === "animal");
			return;
		case "SCUBA_DIVE":
			An(e, n, (U(n).seaAnimal ?? 0) + (U(n).reptile ?? 0), (e) => P[e].kind === "sponsor");
			return;
		case "PERCEPTION_2":
			An(e, n, 2, () => !0);
			return;
		case "PERCEPTION_4":
			An(e, n, 4, () => !0, 2);
			return;
		case "SCAVENGING":
			An(e, n, t.n, () => !0, 1, !0);
			return;
		case "animalHunter":
			n.hand.some((e) => P[e].kind === "animal") || An(e, n, t.n, (e) => P[e].kind === "animal");
			return;
		case "discardFinal":
			Mn(e, n, t.n);
			return;
		case "removeFinal":
			n.finals.splice(n.finals.indexOf(t.arg), 1), e.finalDeck.push(t.arg), Mn(e, n, t.n - 1);
			return;
		case "ADAPT": {
			let r = Math.min(t.n, e.finalDeck.length);
			n.finals.push(...e.finalDeck.splice(0, r)), Mn(e, n, r);
			return;
		}
		case "RESISTANCE": {
			let t = e.finalDeck.splice(0, 2);
			if (!t.length) return;
			q(e, n.rid, "games.arknova.takeCard", t.map((e) => N("games.arknova.takeCard", [i("keepFinal", 1, JSON.stringify({
				id: e,
				other: t.filter((t) => t !== e)
			}))], 1, { card: e })));
			return;
		}
		case "keepFinal": {
			let { id: r, other: i } = JSON.parse(t.arg);
			n.finals.push(r), e.finalDeck.push(...i);
			return;
		}
		case "chooseHabitat": {
			let r = B(t.arg);
			q(e, n.rid, "games.arknova.selectHabitat", Ze(n, r).map((e) => N(e.key === "flock" ? "games.arknova.flock" : "games.arknova.habitat", [i("playAnimal", 1, JSON.stringify({
				id: r.id,
				cost: t.n,
				allocations: e.allocations
			}))], e.key === "flock" ? 3 : 1, {
				card: r.id,
				params: { n: e.allocations.map((e) => e.building + 1).join(", ") },
				cells: e.allocations.flatMap((e) => n.buildings.find((t) => t.id === e.building).cells)
			})));
			return;
		}
		case "playAnimal":
			Fn(e, n, t);
			return;
		case "playSponsor":
			In(e, n, t);
			return;
		case "paidSponsor":
			In(e, n, t, !0);
			return;
		case "paidAppeal":
			n.money >= 2 && q(e, n.rid, "games.arknova.gainAppealPaid", [N("games.arknova.gainAppealPaid", [i("money", -2), i("appeal")], 1)], !0);
			return;
		case "freeBuild": {
			let r = t.arg;
			Mt(e, n, r, "", void 0, !0) && e.frames.push(Nt(e, n.rid, r, t.source));
			return;
		}
		case "unique": {
			let r = Kt(t.arg);
			e.frames.push(Nt(e, n.rid, "unique", t.arg, 0, !1, [], {
				upgraded: qe(n, "build"),
				water: r.water,
				rock: r.rock
			}));
			return;
		}
		case "relocate":
			Vn(e, n, t);
			return;
		case "relocateAnimal": {
			let { id: r, moved: a, allocations: o } = JSON.parse(t.arg), s = n.buildings.find((e) => e.id === t.n), c = B(r);
			n.buildings = n.buildings.filter((e) => e.id !== s.id), nt(n, c), n.buildings.push(s);
			for (let e of o) n.buildings.find((t) => t.id === e.building).used += e.markers;
			G(e, [i("relocate", s.id, [...a, r].join(","))]);
			return;
		}
		case "upgrade":
		case "upgradeOrWorker": {
			let r = n.actions.filter((e) => !e.upgraded).map((e) => N("games.arknova.upgrade", [i("upgradeAction", 1, e.kind)], 5, { action: e.kind }));
			t.op === "upgradeOrWorker" && n.workers < 4 && r.push(N("games.arknova.hire", [i("worker")], 5)), q(e, n.rid, "games.arknova.upgrade", r);
			return;
		}
		case "upgradeAction":
			n.actions.find((e) => e.kind === t.arg).upgraded = !0;
			return;
		case "trackReward": {
			let r = e.rewards[t.arg].map((e) => N("games.arknova.reward", [i("takeReward", 1, JSON.stringify({
				track: t.arg,
				id: e
			}))], 5, { params: { reward: e } }));
			r.push(t.arg === "reputation" ? N("games.arknova.gain", [i("appeal")], 1, { params: {
				n: 1,
				resource: "appeal"
			} }) : N("games.arknova.rewardMoney", [i("money", 5)], 2)), q(e, n.rid, "games.arknova.reward", r);
			return;
		}
		case "takeReward": {
			let { track: n, id: r } = JSON.parse(t.arg);
			e.rewards[n].splice(e.rewards[n].indexOf(r), 1), G(e, [i("bonus", 1, r)]);
			return;
		}
		case "placementBonus": {
			let t = new Set(n.buildings.flatMap((e) => e.cells.map(L)));
			q(e, n.rid, "games.arknova.reward", F[n.map].cells.filter((e) => e.bonus && !t.has(L(e.at))).map((e) => N("games.arknova.reward", [i("bonus", 1, e.bonus)], 2, {
				cells: [e.at],
				params: { reward: e.bonus }
			})));
			return;
		}
		case "partnerMenu":
			q(e, n.rid, "games.arknova.takePartner", ln(e, n).map((e) => N("games.arknova.takePartner", [i("partner", 1, e)], 3, { params: { tag: e } })));
			return;
		case "universityMenu":
			q(e, n.rid, "games.arknova.takeUniversity", un(e, n).map((e) => N("games.arknova.takeUniversity", [i("university", 1, e)], 4, { params: { university: e } })));
			return;
		case "partner": {
			let a = U(n), o = e.partnerSupply.indexOf(t.arg);
			o >= 0 && (r?.action !== "association" || r.variant !== 1) && e.partnerSupply.splice(o, 1), n.partners.push(t.arg), G(e, [...F[n.map].partnerBonuses[n.partners.length - 1].map((e) => i("bonus", 1, e)), ...Ot(e, n, [t.arg], a, "partner")]);
			return;
		}
		case "university": {
			let a = U(n), o = r?.action === "association" && r.variant === 1 && r.upgraded, s = t.arg.startsWith("animal:") ? "animal" : t.arg, c = e.universitySupply.indexOf(s);
			!o && c >= 0 && e.universitySupply.splice(c, 1), n.universities.push(t.arg);
			let l = F[n.map].universityBonuses[n.universities.length - 1].map((e) => i("bonus", 1, e)), u = t.arg === "science2" ? ["science", "science"] : t.arg === "science_rep" ? ["science"] : t.arg.startsWith("animal:") ? ["science", t.arg.slice(7)] : [];
			t.arg === "hand" && l.push(i("reputation")), t.arg === "science_rep" && l.push(i("reputation", 2)), t.arg.startsWith("animal:") && (e.marineUniversities.splice(e.marineUniversities.indexOf(t.arg.slice(7)), 1), l.push(i("searchTag", 1, t.arg.slice(7)))), l.push(...Ot(e, n, u, a, "university")), G(e, l);
			return;
		}
		case "associationTask": {
			let { task: e, workers: i } = JSON.parse(t.arg);
			r.tasks.push(e), r.remaining -= t.n, r.performed++, n.workersUsed[e] = (n.workersUsed[e] ?? 0) + i, r.variant === 3 && !r.upgraded && r.strength > t.n && gt(n, 1);
			return;
		}
		case "workerAtProject":
			yt(e, n), n.workersUsed.project = (n.workersUsed.project ?? 0) + 1;
			return;
		case "projectMenu":
			q(e, n.rid, "games.arknova.support", Xt(e, n, t.arg, t.n));
			return;
		case "supportProject":
			Ln(e, n, t);
			return;
		case "projectReward": {
			let { id: r, slot: a } = JSON.parse(t.arg), o = Jt(r), s = o.slots[a].effect;
			s === "scienceReputation" ? G(e, [i("reputation", Math.floor((U(n).science ?? 0) / 2))]) : s === "searchCategory" ? G(e, [i("searchTag", 1, o.tag)]) : G(e, [i("bonus", 1, s ?? "", r)]);
			return;
		}
		case "donation": {
			let t = rn(e, n);
			n.money >= t && q(e, n.rid, "games.arknova.donate", [N("games.arknova.donate", [i("donate", t)], 5, { params: { n: t } })], !0);
			return;
		}
		case "donate":
			n.money -= t.n, n.donations++, e.donations++, r?.action === "association" && (r.donation = !0), G(e, [i("conservation")]);
			return;
		case "associationDraw":
			r.donation = !0, G(e, [i("takeRange")]);
			return;
		case "associationDetermination":
			r.performed++, r.after.push(i("DETERMINATION"));
			return;
		case "sponsorCash":
			r.mode = "cash", r.performed++, bt(e, n, r.strength), zn(e, n, r.strength * (r.upgraded ? 2 : 1));
			return;
		case "sponsorTrade":
			r.bonusUsed = !0, t.arg === "x" && (n.x--, zn(e, n, 5)), t.arg === "money" && (n.money -= 5, gt(n, 1)), t.arg === "repMoney" && (n.money -= 5, vt(e, n, 1)), t.arg === "repX" && (n.x--, vt(e, n, 1));
			return;
		case "sponsorDiscard":
		case "sponsorDiscount":
		case "sponsorSnap":
		case "sponsorMarketing":
			r.bonusUsed = !0, n.hand.splice(n.hand.indexOf(t.arg), 1), e.discard.push(t.arg), t.op === "sponsorDiscard" && zn(e, n, 4), t.op === "sponsorDiscount" && r.tasks.push("discount"), t.op === "sponsorSnap" && kn(e, n, i("snapSponsor"), !1, (e) => P[e].kind === "sponsor"), t.op === "sponsorMarketing" && G(e, [i("MARKETING")]);
			return;
		case "smallProgram":
			r.tasks.push("smallProgram"), r.tasks.push("smallOnly"), r.remaining = 1, ht(e, i("smallSnap"));
			return;
		case "smallSnap":
			kn(e, n, t, !1, (e) => P[e].kind === "animal" && V(B(e)));
			return;
		case "PACK":
			K(n, U(n).predator ?? 0);
			return;
		case "PETTING_ZOO_ANIMAL":
			K(n, 3 * (U(n).pet ?? 0));
			return;
		case "WATER_AFFINITY":
			n.buildings.some((e) => e.kind === "petting" && z(F[n.map], n.buildings, e.cells, "water") > 0) && K(n, 2);
			return;
		case "INVENTIVE_BEAR":
			gt(n, Math.min(3, ot(e, "bear")));
			return;
		case "INVENTIVE_PRIMARY": {
			let e = U(n).primate ?? 0;
			gt(n, e >= 5 ? 3 : e >= 3 ? 2 : +(e >= 1));
			return;
		}
		case "ICONIC_ANIMAL":
			K(n, Math.min(8, ot(e, t.arg.toLowerCase())));
			return;
		case "JUMPING":
			bt(e, n, t.n), zn(e, n, t.n);
			return;
		case "CLEVER":
		case "cleverPaid": {
			let r = t.op === "cleverPaid" ? t.n : 0;
			if (n.money < r) return;
			q(e, n.rid, "games.arknova.moveOne", n.actions.map((e) => N("games.arknova.moveOne", [
				i("money", -r),
				i("moveAction", 1, e.kind),
				...t.op === "CLEVER" && t.n > 1 ? [i("CLEVER", t.n - 1)] : []
			], 1, { action: e.kind })), !0);
			return;
		}
		case "moveAction":
			xt(n, t.arg, t.n === 5 ? 5 : 1);
			return;
		case "BOOST_ASSOCIATION":
		case "BOOST_BUILDING":
		case "BOOST_CARD":
		case "BOOST_SPONSORS":
		case "BOOST_ANIMAL": {
			let r = {
				BOOST_ASSOCIATION: "association",
				BOOST_BUILDING: "build",
				BOOST_CARD: "cards",
				BOOST_SPONSORS: "sponsors",
				BOOST_ANIMAL: "animals"
			}[t.op];
			q(e, n.rid, "games.arknova.ability", [1, 5].map((e) => N(e === 1 ? "games.arknova.moveOne" : "games.arknova.moveFive", [i("moveAction", e, r)], e === 5 ? 3 : 0, { action: r })), !0);
			return;
		}
		case "ACTION_ASSOCIATION":
		case "ACTION_BUILDING":
		case "ACTION_CARDS":
		case "ACTION_SPONSORS":
		case "DETERMINATION": {
			let r = {
				ACTION_ASSOCIATION: "association",
				ACTION_BUILDING: "build",
				ACTION_CARDS: "cards",
				ACTION_SPONSORS: "sponsors",
				DETERMINATION: "any"
			}[t.op];
			q(e, n.rid, "games.arknova.action", _n(e, n.rid, r), !0);
			return;
		}
		case "MULTIPLIER_ASSOCIATION":
		case "MULTIPLIER_BUILDING":
		case "MULTIPLIER_CARD":
		case "MULTIPLIER_SPONSORS": {
			let e = {
				MULTIPLIER_ASSOCIATION: "association",
				MULTIPLIER_BUILDING: "build",
				MULTIPLIER_CARD: "cards",
				MULTIPLIER_SPONSORS: "sponsors"
			}[t.op];
			n.actions.find((t) => t.kind === e).multiplier++;
			return;
		}
		case "multiplierMenu":
			q(e, n.rid, "games.arknova.ability", n.actions.map((e) => N("games.arknova.ability", [i("addMultiplier", 1, e.kind)], 2, { action: e.kind })));
			return;
		case "addMultiplier":
			n.actions.find((e) => e.kind === t.arg).multiplier++;
			return;
		case "PEACOCKING":
			G(e, [i("freeBuild", 1, "aviary")]);
			return;
		case "POSTURING":
			q(e, n.rid, "games.arknova.placeBuilding", ["kiosk", "pavilion"].filter((t) => Mt(e, n, t)).map((e) => N("games.arknova.buildBuilding", [i("freeBuild", 1, e), ...t.n > 1 ? [i("POSTURING", t.n - 1)] : []], 2, { building: e })), !0);
			return;
		case "MARK":
			q(e, n.rid, "games.arknova.mark", e.market.flatMap((t) => t && P[t].kind === "animal" && !e.marks[t] ? [N("games.arknova.mark", [i("markCard", 1, t)], 2, { card: t })] : []), !0);
			return;
		case "markCard":
			e.marks[t.arg] = n.rid;
			return;
		case "DIGGING": {
			let r = n.hand.map((e) => N("games.arknova.discard", [
				i("discard", 1, e),
				i("draw"),
				...t.n > 1 ? [i("DIGGING", t.n - 1)] : []
			], 0, { card: e }));
			for (let n = 0; n < 6; n++) e.market[n] && r.push(N("games.arknova.discard", [i("digMarket", n), ...t.n > 1 ? [i("DIGGING", t.n - 1)] : []], 1, { card: e.market[n] }));
			q(e, n.rid, "games.arknova.discard", r, !0);
			return;
		}
		case "digMarket":
			ft(e, t.n, !0), pt(e);
			return;
		case "SNAPPING_1":
			kn(e, n, i("snapNoRefill"), !1);
			return;
		case "SNAPPING_2":
			q(e, n.rid, "games.arknova.snap", e.market.flatMap((e, t) => e ? [N("games.arknova.takeCard", [i("takeMarket", t, e), i("snapAgain")], 2, { card: e })] : []));
			return;
		case "snapAgain":
			q(e, n.rid, "games.arknova.snap", [N("games.arknova.snap", [i("SNAPPING_1")], 1), N("games.arknova.refillSnap", [i("refill"), i("SNAPPING_1")], 1)]);
			return;
		case "refill":
			pt(e);
			return;
		case "SPONSOR_MAGNET":
		case "SEA_ANIMAL_MAGNET":
			for (let r = 0; r < 6; r++) {
				let i = e.market[r];
				i && (t.op === "SPONSOR_MAGNET" ? P[i].kind === "sponsor" : P[i].kind !== "project" && P[i].kind !== "final" && P[i].tags.includes("seaAnimal")) && (ft(e, r), n.hand.push(i));
			}
			return;
		case "ASSERTION":
		case "DOMINANCE": {
			let r = t.op === "ASSERTION" ? e.baseReserve : e.baseReserve.filter((e) => e === "108");
			q(e, n.rid, "games.arknova.takeCard", r.map((e) => N("games.arknova.takeCard", [i("takeBase", 1, e)], 4, { card: e })), !0);
			return;
		}
		case "takeBase":
			e.baseReserve.splice(e.baseReserve.indexOf(t.arg), 1), n.hand.push(t.arg);
			return;
		case "VENOM":
		case "CONSTRICTION":
			for (let r of e.players) if (r.rid !== n.rid && r.appeal >= 5 && !H(r, "225")) {
				let e = t.op === "VENOM" ? r.appeal > n.appeal ? t.n : 0 : Number(r.appeal > n.appeal) + Number(r.conservation > n.conservation);
				for (let n = 0; n < e; n++) r.actions[t.op === "VENOM" ? n : 4 - n][t.op === "VENOM" ? "venom" : "constriction"] = !0;
			}
			return;
		case "PILFERING_1":
			Pn(e, n, "pilfer", "appeal", 1, t.source);
			return;
		case "PILFERING_2":
			G(e, [i("PILFERING_1"), i("pilferConservation")], !0);
			return;
		case "pilferConservation":
			Pn(e, n, "pilfer", "conservation", 1, t.source);
			return;
		case "pilfer": {
			let r = [];
			(n.money >= 5 || !n.hand.length) && r.push(N("games.arknova.stealMoney", [i("giveMoney", Math.min(5, n.money), t.arg)], 1)), n.hand.length && r.push(N("games.arknova.stealCard", [i("giveCard", 1, t.arg)], 1)), q(e, n.rid, "games.arknova.ability", r);
			return;
		}
		case "giveMoney":
			n.money -= t.n, zn(e, j(e, t.arg), t.n);
			return;
		case "giveCard": {
			let r = lt(e, n.hand);
			r && j(e, t.arg).hand.push(r);
			return;
		}
		case "HYPNOSIS":
			Pn(e, n, "hypnotized", "appeal", 3, t.source);
			return;
		case "hypnotized":
			ht(e, A(t.arg, "hypnosisAction", t.n, n.rid, t.source));
			return;
		case "hypnosisAction":
			q(e, n.rid, "games.arknova.action", _n(e, n.rid, "any", t.arg, t.n).filter((e) => e.key !== "games.arknova.gainX"), !0);
			return;
		case "TRADE": {
			let t = [];
			n.x && t.push(N("games.arknova.tradeX", [i("x", -1), i("money", 5)], 2)), n.money >= 5 && n.x < 5 && t.push(N("games.arknova.tradeMoney", [i("money", -5), i("x")], 1)), q(e, n.rid, "games.arknova.ability", t, !0);
			return;
		}
		case "REEF_MONEY":
			zn(e, n, 3);
			return;
		case "HELPFUL":
		case "FLOCK_ANIMAL": return;
		case "reefAll":
			G(e, n.animals.flatMap((e) => B(e).reef.map((t) => A(n.rid, t.ability, typeof t.value == "number" ? t.value : 1, typeof t.value == "string" ? t.value : "", e))));
			return;
		case "EXTRA_SHIFT":
			q(e, n.rid, "games.arknova.extraShift", Object.entries(n.workersUsed).filter(([, e]) => e > 0).map(([e]) => N("games.arknova.extraShift", [i("recallWorker", 1, e)], 3, { params: { task: e } })), !0);
			return;
		case "recallWorker":
			n.workersUsed[t.arg]--;
			return;
		case "CUT_DOWN":
			q(e, n.rid, "games.arknova.cutDown", n.buildings.filter((e) => e.kind.startsWith("standard") && !e.occupied).map((e) => N("games.arknova.cutDown", [i("cutEnclosure", e.id)], Xe(n, e), {
				cells: e.cells,
				params: { n: e.id + 1 }
			})), !0);
			return;
		case "cutEnclosure": {
			let r = n.buildings.find((e) => e.id === t.n);
			zn(e, n, Xe(n, r) * 2), n.buildings = n.buildings.filter((e) => e.id !== r.id), n.fullCoverAwarded = !1;
			return;
		}
		case "CAMOUFLAGE":
			n.camouflage = 1;
			return;
		case "SYMBIOSIS":
			q(e, n.rid, "games.arknova.symbiosis", n.animals.filter((e) => e !== t.source && B(e).tags.includes("seaAnimal")).flatMap((e) => B(e).abilities.filter((e) => e.ability !== "SYMBIOSIS").map((t) => N("games.arknova.ability", [i("copiedAbility", typeof t.value == "number" ? t.value : 1, JSON.stringify(t), e)], 2, {
				card: e,
				params: { ability: t.ability }
			}))), !0);
			return;
		case "copiedAbility": {
			let n = JSON.parse(t.arg), r = i(n.ability, typeof n.value == "number" ? n.value : 1, typeof n.value == "string" ? n.value : "");
			/^(BOOST_|ACTION_|CLEVER$|MARK$|DETERMINATION$)/.test(n.ability) ? ht(e, r) : G(e, [r]);
			return;
		}
		case "MONKEY_GANG":
			mt(e, n, (e) => P[e].kind !== "project" && P[e].kind !== "final" && P[e].tags.includes("primate"), !0);
			return;
		case "searchTag":
			mt(e, n, (e) => P[e].kind !== "project" && P[e].kind !== "final" && P[e].tags.includes(t.arg), !0);
			return;
		case "searchSponsor":
			mt(e, n, (e) => P[e].kind === "sponsor", !1);
			return;
		case "MARKETING":
		case "okapi":
			if (t.op === "okapi" && !(n.cardTokens[253] > 0)) return;
			q(e, n.rid, "games.arknova.playCard", n.hand.filter((e) => P[e].kind === "sponsor").map(Kt).filter((t) => n.money >= Bt(n, t) && $e(e, n, t) === 0 && (!kt[t.id] || Mt(e, n, "unique", t.id, At(n, "unique", t.id, {
				upgraded: qe(n, "build"),
				rock: t.rock,
				water: t.water
			})))).map((e) => N("games.arknova.playCard", [...t.op === "okapi" ? [i("consumeToken", 1, "253")] : t.arg === "bonus" ? [i("consumeToken", 1, "sponsorMoney")] : [], i("paidSponsor", Bt(n, e), JSON.stringify({
				id: e.id,
				level: 0
			}))], 4, { card: e.id })), !0);
			return;
		case "consumeToken":
			n.cardTokens[t.arg] -= t.n;
			return;
		case "assignment":
			q(e, n.rid, "games.arknova.ability", [N("games.arknova.assignmentSmall", [i("setAssignment", 1, "small")], 3), N("games.arknova.assignmentLarge", [i("setAssignment", 1, "large")], 3)]);
			return;
		case "setAssignment":
			n.assignment = t.arg, mt(e, n, (e) => P[e].kind === "animal" && (t.arg === "small" ? V(B(e)) : Ke(B(e))), e.config.marine);
			return;
		case "discardPet":
			q(e, n.rid, "games.arknova.takeCard", e.discard.filter((e) => P[e].kind === "animal" && B(e).tags.includes("pet")).map((e) => N("games.arknova.takeCard", [i("takeDiscard", 1, e)], 4, { card: e })));
			return;
		case "takeDiscard":
			e.discard.splice(e.discard.indexOf(t.arg), 1), n.hand.push(t.arg);
			return;
		case "pavilionAppeal":
			K(n, n.buildings.filter((e) => e.kind === "pavilion").length);
			return;
		case "gardener":
			G(e, [i("freeBuild", 1, "pavilion"), i("pavilionAppeal")], !0);
			return;
		case "releaseMenu":
			q(e, n.rid, "games.arknova.release", n.animals.map((e) => N("games.arknova.release", [i("releaseAnimal", 1, e)], -B(e).appeal, { card: e })), !0);
			return;
		case "releaseAnimal":
			Rn(e, n, t.arg);
			return;
		case "SHARK_ATTACK": {
			let r = e.market.slice(0, De(n.reputation)).flatMap((e, t) => e && P[e].kind === "animal" ? [{
				id: e,
				slot: t
			}] : []), a = t.n >= 2 && r.length >= 2 ? r.flatMap((e, t) => r.slice(t + 1).map((t) => [e, t])) : r.map((e) => [e]);
			q(e, n.rid, "games.arknova.sharkAttack", a.map((e) => N("games.arknova.sharkAttack", [i("sharkDiscard", 1, JSON.stringify(e.map((e) => e.slot)))], e.reduce((e, t) => e + B(t.id).appeal, 0) / 2, {
				card: e[0].id,
				params: { cards: e.map((e) => e.id).join(", ") }
			})));
			return;
		}
		case "sharkDiscard": {
			let r = 0;
			for (let n of JSON.parse(t.arg)) {
				let t = e.market[n];
				t && (r += B(t).appeal), ft(e, n, !0);
			}
			K(n, Math.floor(r / 2));
			return;
		}
		case "GLIDE":
			On(e, n, t, "glideCard", !0);
			return;
		case "glideCard": {
			let r = P[t.arg], a = r.kind === "animal" || r.kind === "sponsor" ? r.tags.filter((e) => e === "seaAnimal").length : 0;
			n.hand.splice(n.hand.indexOf(t.arg), 1), e.discard.push(t.arg), G(e, Array.from({ length: a }, () => i("glideReward")));
			return;
		}
		case "glideReward":
			q(e, n.rid, "games.arknova.reward", [
				N("games.arknova.gain", [i("reputation")], 3, { params: {
					n: 1,
					resource: "reputation"
				} }),
				N("games.arknova.gain", [i("appeal", 2)], 2, { params: {
					n: 2,
					resource: "appeal"
				} }),
				...Mt(e, n, "kiosk") ? [N("games.arknova.buildBuilding", [i("freeBuild", 1, "kiosk")], 2, { building: "kiosk" })] : []
			]);
			return;
		case "expedition":
			q(e, n.rid, "games.arknova.ability", [N("games.arknova.scubaDive", [i("expeditionDive")], 3), ...n.sponsors.filter((e) => Kt(e).person).map((e) => N("games.arknova.sendExpedition", [i("removeSponsor", 1, e), i("conservation")], 5, { card: e }))], !0);
			return;
		case "expeditionDive":
			An(e, n, 3, (e) => P[e].kind === "sponsor");
			return;
		case "removeSponsor":
			n.sponsors.splice(n.sponsors.indexOf(t.arg), 1), e.discard.push(t.arg, ...n.pouchedCards[t.arg] ?? []), delete n.pouched[t.arg], delete n.pouchedCards[t.arg];
			return;
		case "enlarge": {
			let t = [];
			for (let e of n.buildings.filter((e) => e.kind.startsWith("standard") && e.kind !== "standard5")) {
				let r = `standard${Number(e.kind.slice(-1)) + 1}`, a = n.buildings.filter((t) => t.id !== e.id), o = new Set(e.cells.map(L));
				for (let s of Be(F[n.map], a, r, At(n, r))) e.cells.every((e) => s.some((t) => L(t) === L(e))) && t.push(N("games.arknova.enlarge", [i("enlargeHere", e.id, JSON.stringify({
					kind: r,
					cells: s,
					added: s.filter((e) => !o.has(L(e)))
				}))], e.occupied ? 3 : 1, {
					cells: s,
					building: r
				}));
			}
			q(e, n.rid, "games.arknova.enlarge", t, !0);
			return;
		}
		case "enlargeHere": {
			let { kind: r, cells: a, added: o } = JSON.parse(t.arg), s = n.buildings.find((e) => e.id === t.n);
			s.kind = r, s.cells = a;
			let c = s.occupied ? [i("appeal", 2)] : [];
			c.push(...It(n, o, t.source)), G(e, c);
			return;
		}
		case "reconstruct":
			e.reconstruction = {
				rid: n.rid,
				buildings: [],
				placed: []
			}, G(e, [i("chooseReconstruct")]);
			return;
		case "chooseReconstruct": {
			let t = e.reconstruction.buildings, r = t.length < 3 ? n.buildings.map((e) => N("games.arknova.reconstruct", [i("pickReconstruct", e.id)], 1, { cells: e.cells })) : [];
			r.push(N("games.arknova.confirm", [i("reconstructPlace")], t.length ? 3 : 0)), t.length && r.push(N("games.arknova.reselectBuildings", [i("resetReconstruct")], 0)), q(e, n.rid, "games.arknova.reconstruct", r);
			return;
		}
		case "pickReconstruct": {
			let r = n.buildings.findIndex((e) => e.id === t.n);
			e.reconstruction.buildings.push(...n.buildings.splice(r, 1)), G(e, [i("chooseReconstruct")]);
			return;
		}
		case "reconstructPlace": {
			let t = e.reconstruction.buildings.filter((t) => !e.reconstruction.placed.includes(t.id));
			if (!t.length) {
				e.reconstruction = null, G(e, [i("freeBuild", 1, "kiosk"), i("freeBuild", 1, "pavilion")]);
				return;
			}
			let r = t.filter((e) => Be(F[n.map], n.buildings, e.kind, Dn(n, e), e.cells).length).map((e) => N("games.arknova.placeBuilding", [i("reconstructBuilding", e.id)], 2, {
				building: e.kind,
				params: { n: e.id + 1 }
			}));
			r.push(N("games.arknova.reselectBuildings", [i("resetReconstruct")], -5)), q(e, n.rid, "games.arknova.placeBuilding", r);
			return;
		}
		case "reconstructBuilding": {
			let r = e.reconstruction.buildings.find((e) => e.id === t.n), a = Nt(e, n.rid, r.kind, r.card ?? "", 0, !1, [i("reconstructPlaced", r.id)], Dn(n, r));
			a.moving = r.id, a.shape = r.cells, e.frames.push(a);
			return;
		}
		case "reconstructPlaced":
			e.reconstruction.placed.push(t.n), G(e, [i("reconstructPlace")]);
			return;
		case "resetReconstruct": {
			let t = e.reconstruction.buildings, r = new Set(t.map((e) => e.id));
			n.buildings = [...n.buildings.filter((e) => !r.has(e.id)), ...t], e.reconstruction = {
				rid: n.rid,
				buildings: [],
				placed: []
			}, G(e, [i("chooseReconstruct")]);
			return;
		}
		case "harbor":
			n.hand.splice(n.hand.indexOf(t.arg), 1), e.discard.push(t.arg), n.harborUsed = !0, zn(e, n, 3);
			return;
		case "useIgnore":
			n.cardTokens.ignoreConditions--, n.ignoredConditions = 3;
			return;
		case "useExtraShift":
			n.cardTokens.extraShift--, G(e, [i("EXTRA_SHIFT")]);
			return;
		case "useMarketing":
			G(e, [i("MARKETING", 1, "bonus")]);
			return;
		case "breakCleanup":
			xn(e);
			return;
		case "breakIncome":
			Sn(e, n.rid);
			return;
		case "breakNext":
			Cn(e);
			return;
		case "beginFinal":
			wn(e);
			return;
		case "scoreFinal":
			Tn(e);
			return;
		default: throw Error(`Unimplemented Ark Nova effect: ${t.op}`);
	}
}
//#endregion
//#region src/games/arknova/rules.ts
function Un(e) {
	for (let t = 0; t < 4096; t++) {
		let t = e.frames.at(-1);
		if (t?.kind !== "effects") return;
		if (!t.effects.length) {
			e.frames.pop();
			continue;
		}
		if (t.effects.length > 1 && !t.ordered) return;
		let n = t.effects.shift();
		t.effects.length || e.frames.pop(), Hn(e, n);
	}
	throw Error("Ark Nova effect chain did not settle");
}
function Wn(e, t) {
	if (e.phase !== "play" || e.players[e.turn].rid !== t) return [];
	let n = e.players[e.turn], r = [];
	if (gn(n)) for (let e of n.hand) r.push(N("games.arknova.harbor", [A(t, "harbor", 1, e)], 1, { card: e }));
	return n.cardTokens.ignoreConditions > 0 && !n.ignoredConditions && r.push(N("games.arknova.useIgnore", [A(t, "useIgnore")], 0)), n.cardTokens.extraShift > 0 && Object.values(n.workersUsed).some((e) => e > 0) && r.push(N("games.arknova.useRecall", [A(t, "useExtraShift")], 1)), n.cardTokens.sponsorMoney > 0 && r.push(N("games.arknova.useMarketing", [A(t, "useMarketing")], 1)), r;
}
function Gn(e, t) {
	if (![
		"play",
		"break",
		"final"
	].includes(e.phase)) return [];
	let n = e.frames.at(-1);
	if (n && n.rid !== t || !n && e.players[e.turn].rid !== t) return [];
	let r = [];
	if (!n) r = en(e, e.players[e.turn]);
	else if (n.kind === "action") r = dn(e, n);
	else if (n.kind === "decision") r = n.choices;
	else if (n.kind === "effects") r = n.effects.map((e) => N("games.arknova.resolve", [e], 2, {
		...e.source && /^\d{3}$/.test(e.source) ? { card: e.source } : {},
		params: {
			ability: e.op,
			n: e.n
		},
		value: e.n
	}));
	else if (n.kind === "place") {
		let i = e.players.find((e) => e.rid === t);
		r = Be(F[i.map], i.buildings, n.building, n.rules, n.shape).filter((e) => Ft(i, n, e) <= i.money).map((e) => N("games.arknova.placeHere", [], 2, {
			cells: e,
			building: n.building,
			value: Ft(i, n, e)
		})), n.optional && r.push(N("games.arknova.skip", [], -5));
	}
	return [...r.map((e, t) => ({
		...e,
		id: `c:${t}`
	})), ...Wn(e, t).map((e, t) => ({
		...e,
		id: `g:${t}`
	}))];
}
function Kn(e, t) {
	if (e.phase === "map") return "games.arknova.chooseMap";
	if (e.phase === "draft") return e.draftRound < 2 ? "games.arknova.chooseDraft" : "games.arknova.chooseVariants";
	if (e.phase === "setup") return "games.arknova.setupDiscard";
	let n = e.frames.at(-1);
	return n?.rid === t && n.kind === "decision" ? n.prompt : n?.kind === "place" ? "games.arknova.placeBuilding" : n?.kind === "effects" ? "games.arknova.chooseEffect" : "games.arknova.begin";
}
function qn(e, t) {
	let n = e.players.find((e) => e.rid === t), r = M(e), i = e.frames.at(-1), a = {
		config: e.config,
		revision: e.revision,
		phase: e.phase,
		players: e.players.map((t) => ({
			rid: t.rid,
			map: t.map,
			money: t.money,
			appeal: t.appeal,
			conservation: t.conservation,
			reputation: t.reputation,
			x: t.x,
			workers: t.workers,
			workersUsed: { ...t.workersUsed },
			actions: t.actions,
			buildings: t.buildings,
			animals: t.animals,
			sponsors: t.sponsors,
			partners: t.partners,
			universities: t.universities,
			bonuses: t.bonuses,
			extraTags: t.extraTags,
			cardTokens: t.cardTokens,
			pouched: t.pouched,
			handCount: t.hand.length,
			finalCount: t.finals.length,
			finals: e.phase === "done" ? t.finals : [],
			assignment: t.assignment,
			donations: t.donations,
			ready: t.setupReady
		})),
		turn: e.players[e.turn].rid,
		actor: [
			"map",
			"draft",
			"setup",
			"done"
		].includes(e.phase) ? null : i?.rid ?? e.players[e.turn].rid,
		turnNumber: e.turnNumber,
		breakNumber: e.breakNumber,
		breakProgress: e.breakProgress,
		breakLength: xe[e.players.length],
		market: e.market,
		marks: e.marks,
		deckCount: e.deck.length,
		discardCount: e.discard.length,
		projects: e.projects,
		partnerSupply: e.partnerSupply,
		universitySupply: e.universitySupply,
		marineUniversities: e.marineUniversities,
		donations: e.donations,
		rewards: e.rewards,
		finalTurns: e.finalTurns,
		endBy: e.endBy,
		activity: r ? {
			rid: r.rid,
			action: r.action,
			strength: r.strength,
			remaining: r.remaining
		} : null,
		journal: e.journal.slice(-30),
		finalBreakdown: e.finalBreakdown
	}, o = n ? Gn(e, t).map((e) => {
		let t = {
			id: e.id,
			key: e.key,
			score: e.score
		};
		for (let n of [
			"params",
			"card",
			"cells",
			"building",
			"action",
			"value"
		]) e[n] !== void 0 && Object.assign(t, { [n]: e[n] });
		return t;
	}) : [], s = {
		hand: n && !["map", "draft"].includes(e.phase) ? n.hand : [],
		finals: n && !["map", "draft"].includes(e.phase) ? n.finals : [],
		maps: n ? e.mapChoices[t] : [],
		draft: n ? e.draftHands[t] ?? [] : [],
		draftKept: n ? e.draftKept[t] ?? [] : [],
		draftRound: e.draftRound,
		draftSelected: n ? e.draftSelected[t] ?? null : null,
		choices: o,
		prompt: Kn(e, t)
	};
	return structuredClone({
		public: a,
		private: s
	});
}
function Jn(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((e) => [e.rid, Ee(e.appeal, e.conservation)])), n = (t) => e.players.find((e) => e.rid === t).bonuses.length, r = e.players.map((e) => e.rid).sort((e, r) => t[r] - t[e] || n(r) - n(e)), i = r[0];
	return {
		phase: "done",
		scores: t,
		ranking: r,
		winner: r.filter((e) => t[e] === t[i] && n(e) === n(i))
	};
}
var Yn = {
	meta: w,
	saveCompatibility: { version: "1" },
	schemas: {
		action: me,
		config: pe,
		publicView: ye,
		privateView: be
	},
	setup(e, t, n) {
		return { state: Ct(pe.parse(e), t, n) };
	},
	reduce(e, t, n) {
		if (!e.players.some((e) => e.rid === n.by)) return { code: "games.arknova.errTurn" };
		let r = structuredClone(e), i;
		if (t.type === "map") i = wt(r, n.by, t.map);
		else if (t.type === "draft") i = Tt(r, n.by, t.card);
		else if (t.type === "variants") i = Et(r, n.by, t.cards);
		else if (t.type === "hand") i = Dt(r, n.by, t.cards);
		else {
			if (t.revision !== e.revision) return { code: "games.arknova.errAction" };
			let a = Gn(r, n.by).find((e) => e.id === t.id);
			if (!a) return { code: "games.arknova.errTurn" };
			let o = r.frames.at(-1);
			t.id.startsWith("c:") && (o?.kind === "decision" && r.frames.pop(), o?.kind === "effects" && (o.effects.splice(Number(t.id.slice(2)), 1), o.effects.length || r.frames.pop()), o?.kind === "place" && (r.frames.pop(), a.cells && Lt(r, o, a.cells))), G(r, a.effects, !0), i = !0;
		}
		return i ? (r.revision++, Un(r), { state: r }) : { code: "games.arknova.errAction" };
	},
	viewFor: qn,
	status: Jn
};
//#endregion
//#region src/games/arknova/icon-markup.ts
function Xn(e, t = "") {
	let n = {
		leaf: "<path d=\"M19 3C7 2 2 8 5 16c8 4 15-2 14-13Z\"/><path d=\"m5 20 10-12M8 14l-1-5m4 2 5 1\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.5\"/>",
		paw: "<ellipse cx=\"12\" cy=\"16\" rx=\"6\" ry=\"4.5\"/><ellipse cx=\"4.8\" cy=\"10\" rx=\"2.4\" ry=\"3.2\" transform=\"rotate(-25 5 10)\"/><ellipse cx=\"10\" cy=\"6\" rx=\"2.4\" ry=\"3.2\"/><ellipse cx=\"16\" cy=\"6.5\" rx=\"2.4\" ry=\"3.2\"/><ellipse cx=\"20\" cy=\"11\" rx=\"2.4\" ry=\"3.2\" transform=\"rotate(25 20 11)\"/>",
		coin: "<circle cx=\"12\" cy=\"12\" r=\"9\"/><circle cx=\"12\" cy=\"12\" r=\"6.3\" fill=\"none\" stroke=\"var(--an-paper)\" stroke-width=\"1\"/><path d=\"M10 7h4v10h-4m-2-5h8\" fill=\"none\" stroke=\"var(--an-paper)\" stroke-width=\"1.7\"/>",
		ticket: "<path d=\"M3 6h18v5a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4Z\"/><path d=\"M8 8v9\" stroke=\"var(--an-paper)\" stroke-width=\"1.5\" stroke-dasharray=\"2 2\"/>",
		shield: "<path d=\"m12 2 9 4v7c0 4-4 7-9 9-5-2-9-5-9-9V6Z\"/><path d=\"m8 12 3 3 5-6\" fill=\"none\" stroke=\"var(--an-paper)\" stroke-width=\"1.6\"/>",
		cap: "<path d=\"m2 8 10-5 10 5-10 5Z\"/><path d=\"M6 12v5q6 5 12 0v-5M21 9v9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		worker: "<circle cx=\"12\" cy=\"5\" r=\"3\"/><path d=\"m8 10-4 6 4 1-1 5h10l-1-5 4-1-4-6Z\"/>",
		build: "<path d=\"m3 6 5-4 5 5-2 3 10 10-3 3L8 12l-3 1-3-5Z\"/>",
		cards: "<path d=\"M5 4h13v17H5Z\"/><path d=\"M1 1h13v2H3v15H1Z\"/><path d=\"m11.5 7 4 5-4 5-4-5Z\" fill=\"var(--an-paper)\"/>",
		association: "<path d=\"m2 8 5-4 5 3 5-3 5 4-3 9-5 4-9-5Z\"/><path d=\"m8 9 3 2 4-3m-4 3 7 6m-10-3 6 5\" stroke=\"var(--an-paper)\" stroke-width=\"1.5\" fill=\"none\"/>",
		water: "<path d=\"M12 2C9 7 5 11 5 15a7 7 0 0 0 14 0c0-4-4-8-7-13Z\"/><path d=\"M8 14q-1 4 3 5\" stroke=\"var(--an-paper)\" stroke-width=\"1.4\" fill=\"none\"/>",
		globe: "<circle cx=\"12\" cy=\"12\" r=\"9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/><path d=\"M4 7h7l2 4-3 2 1 6-4-3-1-5m11-7-3 4 5 3-2 7\"/>",
		bird: "<path d=\"M2 13q8-2 11-9 2 7 9 10l-8 1-2 7-4-7Z\"/>",
		turtle: "<ellipse cx=\"11\" cy=\"12\" rx=\"6\" ry=\"8\"/><path d=\"m7 6-5-2 2 5m12-3 5-2-3 6m-3 8 4 3-5-1m-6-2-4 3 1-4M17 10l5 1-1 3-4 1\"/>",
		hex: "<path d=\"m6 3 12 0 5 9-5 9H6l-5-9Z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"/>",
		arrow: "<path d=\"m5 12 14 0-5-5m5 5-5 5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		menu: "<path d=\"M4 6h16M4 12h16M4 18h16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		rotate: "<path d=\"M5 8a8 8 0 1 1-1 7M5 3v6h6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		fit: "<path d=\"M3 9V3h6m6 0h6v6m0 6v6h-6m-6 0H3v-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.7\"/>",
		chevron: "<path d=\"m6 9 6 6 6-6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		close: "<path d=\"m5 5 14 14M19 5 5 19\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/>",
		check: "<path d=\"m4 12 5 5L20 6\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\"/>"
	};
	return `<svg class="an-icon ${t}" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">${n[e] ?? n.leaf}</svg>`;
}
var Zn = {
	bear: "M4 12q-2-5 3-6l8 1q2-5 5-2l2 4-1 5-3 1-2-1v7h-3l-1-6-4-1-1 7H4l1-8Zm13-6-1-3 3-1 1 4M4 10 1 9l1-2 3 1",
	herbivore: "M4 12q0-5 5-6l7 1 3 3 2 1v7q-2 2-3-1v-4l-2-1v7h-3v-6h-3v6H7v-7l-1 1-1 5H3l1-7Zm12-4 1-3 2 2 1 3-3 1Z",
	predator: "M3 12q1-3 5-4h8l3 2 2 1 1 3-3 1-3-2-2 1 3 6h-3l-3-5H8l-2 5H3l2-7Zm13-3 1-3 2 2 1 2M4 12Q0 8 2 7",
	primate: "M5 12q0-5 5-5l3-3 4 1 2 4-2 2 3 7-3 2-3-6-2 3-1 4H8l1-7-2 1-2 5H2l3-8Zm-1 1q-6-1-2-6",
	bird: "M2 7q3 0 7 5l4-8q2 1 0 8 4 1 7-2l2 1-6 5-3 1-3 5-2-1v-5L3 13 1 9Zm15 6 3-3 1 2 2 1-4 1Z",
	reptile: "M18 3q3 1 1 4l-2 3-1 5-4 3-3 1q-6 0-6-5 0-3 3-2-2 2 0 4 4 2 7-3l2-6q-1-2 1-3Zm-3 6-5-1-3 2 1 1 3-1 3 2m1 2 4 1 2-2 1 1-2 4-6-1M13 15l-2 6-2 1-1-1 2-2 1-5",
	seaAnimal: "M10 5q6-5 9 1 2 4-2 7-2 1-4 0 4 5 7 1 3 5-2 6-3 0-6-5 1 5 4 6-5 2-6-5-1 6-5 4-3-2 0-5l1 1q-1 3 1 2 3-1 2-5-3 4-6 1-1-3 2-4l1 2q-2 1 0 2 2 0 4-3-5 1-6-3 1-3 4-2l-1 2q-2-1-1 1 2 1 5-1Q6 6 10 5Z",
	africa: "m9 3 5 1 2 2 4 1-1 4-3 1-1 4-3 5-2-1-1-4-3-2-1-3-2-1 1-4 3-1Zm9 14 1-3 1 1-1 4Z",
	asia: "M2 6 6 4 9 5 10 2 15 2 17 4 21 4 23 6 20 8 19 11 16 12 18 15 17 18 15 16 14 13 12 13 10 18 8 14 7 11 4 11 3 8 1 8ZM20 12l1-2 1 1-1 3Zm-2 7 3 1 1 1-4-1Zm-2-1 1 2 1 1-2-1Z",
	europe: "M9 2 12 1 12 4 10 7 11 10 14 9 14 7 18 7 20 10 18 12 15 13 16 16 18 17 17 19 15 18 13 15 11 14 11 17 8 17 6 15 3 16 2 13 5 12 6 9 8 9 7 6ZM4 7 5 5 6 8 5 10 3 9ZM1 9l2-1 1 2-2 1Zm12 9 1 1 1 3-2-1Z",
	americas: "M3 2 8 1 10 3 13 2 16 4 14 6 11 7 10 11 8 12 6 10 4 7 2 7 1 4ZM10 11 12 12 13 14 16 14 19 17 17 20 14 23 12 22 12 19 10 16 9 13Zm4-9 3-1 2 2-2 2Z",
	australia: "m3 11 4-3 3 1 2-4 2 2 2 1 1 3 3 1 1 5-4 2-4-1-3 1-3-3H3Zm13 10 2-1 1 2-2 1Z",
	science: "m8 2 4-1 6 9-4 3-6-9Zm-2 8 3-1 2 3-3 2Zm9 4 2-1q4 7-4 8H5v-3h5q5 0 5-4ZM4 13h9v2H4Z",
	pet: "M5 8 3 5 7 6 10 8 12 5 15 4 17 6 18 10 21 13 19 16 15 15 13 21 9 21 8 16 5 14ZM13 6q-4-4-5-1l2 2-4-1q1-6 6-3Z"
}, Qn = {
	herbivore: ["#249962", "#fff"],
	predator: ["#d52e23", "#fff"],
	primate: ["#f3b625", "#fff"],
	bird: ["#22a4d2", "#fff"],
	reptile: ["#503a96", "#fff"],
	seaAnimal: ["#445d9b", "#fff"],
	africa: ["#f7df16", "#131b21"],
	asia: ["#a9dec5", "#131b21"],
	europe: ["#68cee8", "#131b21"],
	americas: ["#ffad4d", "#131b21"],
	australia: ["#f04a72", "#131b21"],
	science: ["#a9cddc", "#111920"],
	pet: ["#202427", "#fff"],
	bear: ["#76523e", "#fff"]
}, $n = {
	x: "<path d=\"m5 3 7 7 7-7 3 3-7 6 7 6-3 3-7-7-7 7-3-3 7-6-7-6Z\" fill=\"#263e50\" stroke=\"#fff\" stroke-width=\".7\"/>",
	multiplier: "<path d=\"m12 1 10 6v11l-10 5-10-5V7Z\" fill=\"#7956a1\" stroke=\"#fff\"/><text x=\"12\" y=\"16\" text-anchor=\"middle\" fill=\"#fff\" font-family=\"Arial\" font-size=\"12\" font-weight=\"bold\">×2</text>",
	kiosk: "<path d=\"M4 11h16v11H4Z\" fill=\"#ead5a0\" stroke=\"#6c7049\"/><path d=\"m1 10 5-8h12l5 8Z\" fill=\"#d77549\"/><path d=\"M2 10h20v4H2Z\" fill=\"#f8eac4\"/><path d=\"M5 10v4m5-4v4m5-4v4m5-4v4\" stroke=\"#d77549\" stroke-width=\"3\"/><path d=\"M7 17h4v4H7m7-5h4v6h-4\" fill=\"#557c75\"/>",
	pavilion: "<path d=\"m1 10 11-8 11 8Z\" fill=\"#d39850\" stroke=\"#fff\"/><path d=\"M5 10v12m14-12v12M3 22h18\" stroke=\"#6d7149\" stroke-width=\"2\"/>",
	coin: "<rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"5\" fill=\"#4d5f69\" stroke=\"#fff\" stroke-width=\"1.4\"/><path d=\"M5 6q5-3 13 0\" fill=\"none\" stroke=\"#99abb4\" stroke-width=\"1.4\"/>",
	ticket: "<path d=\"M3 2h18v5a3 3 0 0 0 0 6v9H3v-9a3 3 0 0 0 0-6Z\" fill=\"#edb99c\" stroke=\"#755a45\" stroke-width=\"1.4\"/><path d=\"M5 6h14M5 18h14\" stroke=\"#a87f65\" fill=\"none\"/>",
	shield: "<path d=\"m12 1 6 3v4l4 2v5q-3 5-10 8Q5 20 2 15v-5l4-2V4Z\" fill=\"#fffef1\" stroke=\"#3a803e\" stroke-width=\"2\"/>",
	cap: "<path d=\"m1 9 11-7 11 7-11 7Z\" fill=\"#24333b\"/><path d=\"M6 13v6q6 4 12 0v-6\" fill=\"#253b46\"/><path d=\"M21 10v8\" stroke=\"#91c2d5\" stroke-width=\"2\"/>",
	worker: "<path d=\"M7 9a5 5 0 1 1 10 0v1l4 4-1 8H4l-1-8 4-4Z\" fill=\"currentColor\" stroke=\"#fffdf1\" stroke-width=\"1.3\"/>",
	water: "<path d=\"M2 20 5 3h14l3 17Z\" fill=\"#3b7bc5\" stroke=\"#fff\" stroke-width=\"1.3\"/><path d=\"M12 5q-6 8-3 11 4 4 7-1 1-2-4-10Z\" fill=\"#e7f3ff\"/>",
	rock: "<path d=\"M2 20 5 3h14l3 17Z\" fill=\"#898680\" stroke=\"#fff\" stroke-width=\"1.3\"/><path d=\"m5 16 4-7 3 4 3-6 5 9Z\" fill=\"#fff\"/>",
	hex: "<path d=\"m6 2 12 0 5 10-5 10H6L1 12Z\" fill=\"#76532e\" stroke=\"#fff\" stroke-width=\"1.4\"/>",
	wave: "<path d=\"M1 15q10-14 21-5-9-3-11 3 2 3 10 2-12 10-20 0Z\" fill=\"#0aa4d3\" stroke=\"#fff\" stroke-width=\".6\"/>",
	income: "<path d=\"m12 2 8 11H4Z\" fill=\"#e5d334\" stroke=\"#625914\" stroke-width=\"1\"/><path d=\"M6 16h12m-12 4h12\" stroke=\"#625914\" stroke-width=\"2\"/>",
	instant: "<path d=\"m14 1-9 13h6l-2 9 11-14h-7Z\" fill=\"#20292a\"/>",
	end: "<path d=\"M6 2h12M6 22h12M7 3q0 6 5 9-5 3-5 9m10-18q0 6-5 9 5 3 5 9\" fill=\"#fff\" stroke=\"#253840\" stroke-width=\"1.4\"/>",
	strength: "<path d=\"M3 2h19v20H3Z\" fill=\"#171e27\"/><path d=\"M1 4h4M1 8h4M1 12h4M1 16h4M1 20h4\" stroke=\"#fff\" stroke-width=\"1.5\"/>",
	aquarium: "<path d=\"m2 19 5-8V3h6v6l8 7v6H2Z\" fill=\"#17a8d0\" stroke=\"#fff\" stroke-width=\"1.5\"/>",
	reptileHouse: "<path d=\"m4 3 6-2 4 3 6-2v7l-4 4 4 4v5l-6-2-4 3-6-2v-6l4-3-4-4Z\" fill=\"#76532e\" stroke=\"#fff\" stroke-width=\"1.5\"/>",
	largeAnimal: "<rect x=\"3\" y=\"2\" width=\"18\" height=\"21\" rx=\"2\" fill=\"#76532e\" stroke=\"#fff\"/><text x=\"12\" y=\"15\" text-anchor=\"middle\" font-family=\"Arial\" font-size=\"11\" font-weight=\"bold\" fill=\"white\">4+</text><path d=\"M6 19h12\" stroke=\"#fff\" stroke-width=\"2\"/>",
	anyZoo: "<g fill=\"#17232b\" stroke=\"#fff\" stroke-width=\".7\"><path d=\"M2 9a3 3 0 1 1 6 0v2l3 2v7H0v-7l2-2Zm14 0a3 3 0 1 1 6 0v2l2 2v7H13v-7l3-2Z\"/><path d=\"M9 5a3 3 0 1 1 6 0v3l3 2v11H6V10l3-2Z\"/></g>"
};
function er(e, t = "") {
	if (e === "turtle" && (e = "seaAnimal"), e === "globe" && (e = "africa"), e === "paw" && (e = "herbivore"), Qn[e]) {
		let [n, r] = Qn[e];
		return `<svg xmlns="http://www.w3.org/2000/svg" class="an-icon an-tag-icon ${t}" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="11" fill="${n}" stroke="white" stroke-width="1.2"/><g transform="translate(2 2) scale(.83)" fill="${r}"><path d="${Zn[e]}"/></g></svg>`;
	}
	return $n[e] ? `<svg xmlns="http://www.w3.org/2000/svg" class="an-icon ${t}" viewBox="0 0 24 24" aria-hidden="true">${$n[e]}</svg>` : Xn(e, t);
}
function tr(e, t, n = "") {
	let r = er(e, `an-value-token ${n}`), i = e === "strength" ? 17 : 15;
	return r.replace("</svg>", `<text x="${e === "strength" ? 13 : 12}" y="${e === "cap" ? 13 : 17}" text-anchor="middle" font-family="Arial,Microsoft YaHei,sans-serif" font-weight="700" font-size="${i}" fill="${[
		"coin",
		"strength",
		"hex",
		"aquarium",
		"reptileHouse",
		"cap"
	].includes(e) ? "#fff" : "#13252a"}">${t}</text></svg>`);
}
//#endregion
//#region src/games/arknova/icons.tsx
function J({ name: e, value: t, title: n, className: r = "" }) {
	let i = (t === void 0 ? er(e) : tr(e, t)).replace(/^<svg[^>]*>/, "").replace(/<\/svg>$/, "");
	return /* @__PURE__ */ b("svg", {
		className: `an-icon ${r}`,
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": !n || void 0,
		role: n ? "img" : void 0,
		"aria-label": n,
		children: /* @__PURE__ */ b("g", { dangerouslySetInnerHTML: { __html: i } })
	});
}
function Y({ name: e, value: t }) {
	return /* @__PURE__ */ x("span", {
		className: `an-resource an-resource-${e}`,
		children: [/* @__PURE__ */ b(J, { name: e }), /* @__PURE__ */ b("b", { children: typeof t == "number" ? /* @__PURE__ */ b(oe, { value: t }) : t })]
	});
}
function nr({ name: e, x: t, y: n, size: r = 24 }) {
	let i = er(e).replace(/^<svg[^>]*>/, "").replace(/<\/svg>$/, "");
	return /* @__PURE__ */ b("svg", {
		x: t,
		y: n,
		width: r,
		height: r,
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": "true",
		dangerouslySetInnerHTML: { __html: i }
	});
}
//#endregion
//#region src/games/arknova/board.tsx
var rr = 40, ir = ([e, t]) => [e * rr * 1.5, Math.sqrt(3) * rr * (t + e / 2)], ar = (e, t = rr) => {
	let [n, r] = ir(e);
	return Array.from({ length: 6 }, (e, i) => [n + t * Math.cos(Math.PI * i / 3), r + t * Math.sin(Math.PI * i / 3)]);
}, or = (e, t = rr) => ar(e, t).map((e) => e.join(",")).join(" ");
function sr(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) {
		let e = ar(n);
		for (let n = 0; n < 6; n++) {
			let r = e[n], i = e[(n + 1) % 6], a = [r.map((e) => e.toFixed(2)).join(","), i.map((e) => e.toFixed(2)).join(",")].sort().join("|");
			t.has(a) ? t.delete(a) : t.set(a, `M${r}L${i}`);
		}
	}
	return [...t.values()].join(" ");
}
function cr({ x: e, y: t, scale: n = 1 }) {
	return /* @__PURE__ */ x("g", {
		transform: `translate(${e} ${t}) scale(${n})`,
		children: [
			/* @__PURE__ */ b("ellipse", {
				cy: "9",
				rx: "14",
				ry: "7",
				fill: "#426b3b",
				opacity: ".15"
			}),
			/* @__PURE__ */ b("path", {
				d: "m-2 8 1-19h3L3 8Z",
				fill: "#85703e"
			}),
			/* @__PURE__ */ b("path", {
				d: "M-16-10q-5-13 5-16 5-11 14-6 13-4 15 10 10 9-1 16-19 6-33-4Z",
				fill: "#3c9553"
			}),
			/* @__PURE__ */ b("path", {
				d: "M-10-20q8-11 18-7",
				stroke: "#99c870",
				strokeWidth: "3",
				fill: "none"
			})
		]
	});
}
function lr({ b: e }) {
	let t = u(), [n, r] = e.cells.map(ir).reduce((t, n) => [t[0] + n[0] / e.cells.length, t[1] + n[1] / e.cells.length], [0, 0]), i = e.kind.startsWith("aquarium"), a = e.kind.startsWith("standard"), o = e.occupied || e.used > 0, s = i ? "#35b5cd" : e.kind === "kiosk" ? "#e6ac4f" : e.kind === "pavilion" ? "#f2cf79" : e.kind === "unique" ? "#bca0d5" : o ? "#84bd4c" : "#dfb85a", c = e.card && P[e.card]?.kind === "animal" ? P[e.card] : null, l = c && c.kind === "animal" ? c.tags.find((e) => [
		"bird",
		"herbivore",
		"predator",
		"primate",
		"reptile",
		"seaAnimal"
	].includes(e)) ?? "paw" : e.kind === "petting" ? "pet" : e.kind === "aviary" ? "bird" : e.kind === "reptile" ? "reptile" : e.kind === "kiosk" ? "kiosk" : e.kind === "pavilion" ? "pavilion" : i ? "aquarium" : "paw";
	return /* @__PURE__ */ x("g", {
		className: "an-building",
		"data-building": e.id,
		children: [
			/* @__PURE__ */ x("title", { children: [
				t($t[e.kind]),
				" · ",
				e.id + 1
			] }),
			e.cells.map((e) => /* @__PURE__ */ b("polygon", {
				points: or(e),
				fill: s
			}, L(e))),
			/* @__PURE__ */ b("path", {
				d: sr(e.cells),
				fill: "none",
				stroke: "#fff1c5",
				strokeWidth: "7",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ b("path", {
				d: sr(e.cells),
				fill: "none",
				stroke: i ? "#347b88" : "#7d713f",
				strokeWidth: "2.6",
				strokeLinejoin: "round"
			}),
			a && !o ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("text", {
				x: n,
				y: r + 8,
				className: "an-capacity",
				children: e.cells.length
			}), /* @__PURE__ */ b("path", {
				d: `M${n - 12} ${r + 18}h24`,
				stroke: "#a28744"
			})] }) : /* @__PURE__ */ x(y, { children: [a ? /* @__PURE__ */ x(y, { children: [
				/* @__PURE__ */ b(cr, {
					x: n - 20,
					y: r - 8,
					scale: .7
				}),
				/* @__PURE__ */ b(nr, {
					x: n - 8,
					y: r - 7,
					name: l,
					size: 28
				}),
				/* @__PURE__ */ b("circle", {
					cx: n + 23,
					cy: r + 23,
					r: "8",
					fill: "#fff1c5"
				}),
				/* @__PURE__ */ b("path", {
					d: `m${n + 19} ${r + 23} 3 3 5-6`,
					fill: "none",
					stroke: "#3b7747",
					strokeWidth: "2"
				})
			] }) : i ? /* @__PURE__ */ x("g", {
				transform: `translate(${n - 24} ${r - 26})`,
				children: [
					/* @__PURE__ */ b("path", {
						d: "M-6 25 6 1h37l13 24v26H-6Z",
						fill: "#377e89",
						stroke: "#285c67",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ b("path", {
						d: "M0 23 9 7h31l10 16Z",
						fill: "#b9e4d9"
					}),
					/* @__PURE__ */ b("path", {
						d: "M3 28h44v16H3Z",
						fill: "#91d9df"
					}),
					/* @__PURE__ */ b("path", {
						d: "m8 35 10-4 7 4-7 4Zm20 2 8-3 6 3-6 3Z",
						fill: "#2b8497"
					}),
					/* @__PURE__ */ b("path", {
						d: "M14 10v10m13-11v12m12-11v10",
						stroke: "#56a7b4",
						strokeWidth: "2"
					})
				]
			}) : /* @__PURE__ */ b(nr, {
				x: n - 22,
				y: r - 22,
				name: l,
				size: 44
			}), !a && e.used > 0 && /* @__PURE__ */ b("text", {
				x: n + 24,
				y: r + 31,
				className: "an-building-used",
				children: e.used
			})] })
		]
	});
}
var ur = (e) => e.startsWith("money") ? "coin" : e.startsWith("rep") ? "cap" : e.startsWith("conservation") ? "shield" : e.startsWith("card") ? "cards" : e.startsWith("xtoken") ? "x" : e.startsWith("enclosure") ? "hex" : e === "kiosk" ? "kiosk" : e === "worker" ? "worker" : "leaf";
function dr({ p: e, preview: t = [], legalCells: n = [], onCell: r }) {
	let o = u(), c = i().replace(/:/g, ""), l = F[e.map], d = l.cells.map((e) => ir(e.at)), f = s(null), p = s(null);
	a(() => {
		let t = `${e.rid}:${e.map}`, n = p.current;
		p.current = {
			player: t,
			ids: new Set(e.buildings.map((e) => e.id))
		}, !(n?.player !== t || window.matchMedia("(prefers-reduced-motion: reduce)").matches) && f.current?.querySelectorAll("[data-building]").forEach((e) => {
			n.ids.has(Number(e.dataset.building)) || e.animate([{
				opacity: .55,
				transform: "translateY(-6px) scale(1.025)"
			}, {
				opacity: 1,
				transform: "translateY(0) scale(1)"
			}], {
				duration: 220,
				easing: "cubic-bezier(.2,.7,.2,1)"
			});
		});
	}, [
		e.rid,
		e.map,
		e.buildings
	]);
	let m = Math.min(...d.map((e) => e[0])) - 60, h = Math.min(...d.map((e) => e[1])) - 58, ee = Math.max(...d.map((e) => e[0])) + 60, g = Math.max(...d.map((e) => e[1])) + 58, _ = new Set(e.buildings.flatMap((e) => e.cells.map(L))), te = new Set(n.map(L)), ne = l.cells.filter((e) => e.terrain === "water").map((e) => e.at);
	return /* @__PURE__ */ x("svg", {
		ref: f,
		className: "an-zoo-svg",
		viewBox: `${m} ${h} ${ee - m} ${g - h}`,
		role: "img",
		"aria-label": o(l.nameKey),
		children: [
			/* @__PURE__ */ b("defs", { children: /* @__PURE__ */ b("pattern", {
				id: `${c}water`,
				width: "44",
				height: "24",
				patternUnits: "userSpaceOnUse",
				children: /* @__PURE__ */ b("path", {
					d: "M-8 10Q3 5 15 10t23 0 21 0",
					fill: "none",
					stroke: "#d2f3de",
					strokeWidth: "1.4",
					opacity: ".6"
				})
			}) }),
			/* @__PURE__ */ b("rect", {
				x: m,
				y: h,
				width: ee - m,
				height: g - h,
				rx: "8",
				fill: "#8fbc60"
			}),
			l.cells.map((e) => /* @__PURE__ */ b("polygon", {
				points: or(e.at, 47),
				fill: "#9ec76e"
			}, L(e.at))),
			/* @__PURE__ */ b("path", {
				d: sr(l.cells.map((e) => e.at)),
				fill: "none",
				stroke: "#f7e8b1",
				strokeWidth: "7"
			}),
			l.cells.map((e, t) => {
				let [n, r] = ir(e.at), i = !_.has(L(e.at));
				return /* @__PURE__ */ x("g", { children: [
					/* @__PURE__ */ b("polygon", {
						points: or(e.at),
						fill: [
							"#ead092",
							"#efd9a3",
							"#f2dfb1",
							"#e9ce8c",
							"#f0d79d"
						][t % 5],
						stroke: "#fff0cc",
						strokeWidth: "1.5"
					}),
					i && e.terrain === "rock" && /* @__PURE__ */ x("g", {
						transform: `translate(${n} ${r})`,
						children: [
							/* @__PURE__ */ b("path", {
								d: "m-28 13 2-25 14-16 24 3 17 22-6 23-25 9Z",
								fill: "#8c9886",
								stroke: "#ece8ca",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ b("path", {
								d: "m-26-10 18 7 20-22 9 25-25 8-4 19m0-30-4-22",
								fill: "#b2bba5",
								stroke: "#e0e2c8"
							}),
							/* @__PURE__ */ b("path", {
								d: "m-4 8 25-8 8-1-6 23-25 9Z",
								fill: "#7b8c7c"
							})
						]
					}),
					i && e.terrain === "plain" && /* @__PURE__ */ b("path", {
						d: `m${n - 22} ${r + 17} 3-7 3 7m${n + 16} ${r - 14} 2-5 3 6`,
						fill: "none",
						stroke: "#b2ad6e",
						opacity: ".7"
					}),
					i && e.bonus && /* @__PURE__ */ x("g", { children: [
						/* @__PURE__ */ b("path", {
							d: `m${n} ${r - 15} 15 10-5 17h-20l-5-17Z`,
							fill: "#fff0b4",
							stroke: "#b4a35b"
						}),
						/* @__PURE__ */ b(nr, {
							name: ur(e.bonus),
							x: n - 9,
							y: r - 9,
							size: 18
						}),
						/\d/.test(e.bonus) && /* @__PURE__ */ b("text", {
							x: n,
							y: r + 25,
							className: "an-bonus-count",
							children: e.bonus.match(/\d+/)?.[0]
						})
					] }),
					i && e.upgraded && /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("circle", {
						cx: n,
						cy: r,
						r: "12",
						fill: "#884c9c"
					}), /* @__PURE__ */ b("text", {
						x: n,
						y: r + 5,
						className: "an-upgrade-hex",
						children: "II"
					})] })
				] }, L(e.at));
			}),
			ne.filter((e) => !_.has(L(e))).map((e) => /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("polygon", {
				points: or(e),
				fill: "#45b9cf"
			}), /* @__PURE__ */ b("polygon", {
				points: or(e, 38),
				fill: `url(#${c}water)`
			})] }, L(e))),
			/* @__PURE__ */ b("path", {
				d: sr(ne.filter((e) => !_.has(L(e)))),
				fill: "none",
				stroke: "#fae5b3",
				strokeWidth: "5"
			}),
			e.buildings.map((e) => /* @__PURE__ */ b(lr, { b: e }, e.id)),
			r && n.map((e) => /* @__PURE__ */ b("polygon", {
				points: or(e, 32),
				fill: "#ffffff20",
				stroke: "#52894d",
				strokeWidth: "1",
				strokeDasharray: "3 5"
			}, L(e))),
			/* @__PURE__ */ x("g", {
				className: "an-placement-preview",
				children: [t.map((e) => /* @__PURE__ */ b("polygon", {
					points: or(e),
					fill: "#a3e0de",
					fillOpacity: ".85"
				}, L(e))), /* @__PURE__ */ b("path", {
					d: sr(t),
					fill: "none",
					stroke: "#126984",
					strokeWidth: "4",
					strokeDasharray: "8 4"
				})]
			}),
			[
				[-35, 78],
				[ee - 27, 180],
				[ee / 2, h + 18],
				[120, g - 17]
			].map(([e, t], n) => /* @__PURE__ */ b(cr, {
				x: e,
				y: t,
				scale: .65
			}, n)),
			r && l.cells.filter((e) => te.has(L(e.at))).map((e) => /* @__PURE__ */ b("polygon", {
				points: or(e.at),
				className: "an-hit-hex",
				role: "button",
				tabIndex: 0,
				"aria-label": `${o("games.arknova.placeHere")} ${e.at[0] + 1}, ${e.at[1] + 1}`,
				onClick: () => r(e.at),
				onKeyDown: (t) => {
					(t.key === "Enter" || t.key === " ") && (t.preventDefault(), r(e.at));
				}
			}, L(e.at)))
		]
	});
}
//#endregion
//#region src/games/arknova/board-viewport.tsx
function fr({ children: e, viewKey: t }) {
	let n = u(), [r, i] = c({}), a = r[t] ?? {
		scale: 1,
		x: 0,
		y: 0
	}, o = s(null), l = s(!1), d = (e) => i((n) => ({
		...n,
		[t]: e
	})), f = (e) => {
		let t = Math.max(1, Math.min(3, a.scale + e));
		d({
			scale: t,
			x: t === 1 ? 0 : a.x,
			y: t === 1 ? 0 : a.y
		});
	};
	return /* @__PURE__ */ x("div", {
		className: "an-board-viewport",
		children: [/* @__PURE__ */ b("div", {
			className: "an-pan-surface",
			onPointerDown: (e) => {
				a.scale <= 1 || e.button !== 0 || (o.current = {
					id: e.pointerId,
					x: e.clientX,
					y: e.clientY,
					ox: a.x,
					oy: a.y,
					moved: !1
				}, l.current = !1);
			},
			onPointerMove: (e) => {
				let t = o.current;
				if (!t || t.id !== e.pointerId) return;
				let n = e.clientX - t.x, r = e.clientY - t.y;
				if (Math.hypot(n, r) > 5 && (t.moved = !0, e.currentTarget.setPointerCapture(e.pointerId)), t.moved) {
					let i = e.currentTarget.getBoundingClientRect();
					d({
						...a,
						x: Math.max(-i.width * (a.scale - 1) / 2, Math.min(i.width * (a.scale - 1) / 2, t.ox + n)),
						y: Math.max(-i.height * (a.scale - 1) / 2, Math.min(i.height * (a.scale - 1) / 2, t.oy + r))
					});
				}
			},
			onPointerUp: () => {
				l.current = o.current?.moved ?? !1, o.current = null;
			},
			onPointerCancel: () => {
				o.current = null;
			},
			onClickCapture: (e) => {
				l.current &&= (e.stopPropagation(), !1);
			},
			children: /* @__PURE__ */ b("div", {
				className: "an-pan-content",
				style: { transform: `translate(${a.x}px, ${a.y}px) scale(${a.scale})` },
				children: e
			})
		}), /* @__PURE__ */ x("div", {
			className: "an-zoom-controls",
			children: [
				/* @__PURE__ */ b("button", {
					onClick: () => f(-.3),
					disabled: a.scale <= 1,
					"aria-label": n("games.arknova.zoomOut"),
					children: /* @__PURE__ */ b(re, { size: 19 })
				}),
				/* @__PURE__ */ x("button", {
					onClick: () => d({
						scale: 1,
						x: 0,
						y: 0
					}),
					"aria-label": n("games.arknova.resetView"),
					children: [/* @__PURE__ */ b(_, { size: 19 }), /* @__PURE__ */ x("span", { children: [Math.round(a.scale * 100), "%"] })]
				}),
				/* @__PURE__ */ b("button", {
					onClick: () => f(.3),
					disabled: a.scale >= 3,
					"aria-label": n("games.arknova.zoomIn"),
					children: /* @__PURE__ */ b(ne, { size: 19 })
				})
			]
		})]
	});
}
//#endregion
//#region src/games/arknova/ability-keys.ts
var pr = {
	SPRINT: "games.arknova.abilities.SPRINT",
	PACK: "games.arknova.abilities.PACK",
	HUNTER: "games.arknova.abilities.HUNTER",
	CLEVER: "games.arknova.abilities.CLEVER",
	BOOST_ASSOCIATION: "games.arknova.abilities.BOOST_ASSOCIATION",
	ACTION_ASSOCIATION: "games.arknova.abilities.ACTION_ASSOCIATION",
	INVENTIVE_BEAR: "games.arknova.abilities.INVENTIVE_BEAR",
	FULL_THROATED: "games.arknova.abilities.FULL_THROATED",
	JUMPING: "games.arknova.abilities.JUMPING",
	INVENTIVE: "games.arknova.abilities.INVENTIVE",
	MULTIPLIER_ASSOCIATION: "games.arknova.abilities.MULTIPLIER_ASSOCIATION",
	ICONIC_ANIMAL: "games.arknova.abilities.ICONIC_ANIMAL",
	BOOST_ANIMAL: "games.arknova.abilities.BOOST_ANIMAL",
	SUN_BATHING: "games.arknova.abilities.SUN_BATHING",
	POUCH: "games.arknova.abilities.POUCH",
	RESISTANCE: "games.arknova.abilities.RESISTANCE",
	ASSERTION: "games.arknova.abilities.ASSERTION",
	BOOST_SPONSORS: "games.arknova.abilities.BOOST_SPONSORS",
	FLOCK_ANIMAL: "games.arknova.abilities.FLOCK_ANIMAL",
	ACTION_SPONSORS: "games.arknova.abilities.ACTION_SPONSORS",
	MULTIPLIER_SPONSORS: "games.arknova.abilities.MULTIPLIER_SPONSORS",
	DIGGING: "games.arknova.abilities.DIGGING",
	SPONSOR_MAGNET: "games.arknova.abilities.SPONSOR_MAGNET",
	VENOM: "games.arknova.abilities.VENOM",
	DOMINANCE: "games.arknova.abilities.DOMINANCE",
	ACTION_CARDS: "games.arknova.abilities.ACTION_CARDS",
	PILFERING_1: "games.arknova.abilities.PILFERING_1",
	MULTIPLIER_CARD: "games.arknova.abilities.MULTIPLIER_CARD",
	PILFERING_2: "games.arknova.abilities.PILFERING_2",
	INVENTIVE_PRIMARY: "games.arknova.abilities.INVENTIVE_PRIMARY",
	BOOST_CARD: "games.arknova.abilities.BOOST_CARD",
	SNAPPING_2: "games.arknova.abilities.SNAPPING_2",
	CONSTRICTION: "games.arknova.abilities.CONSTRICTION",
	HYPNOSIS: "games.arknova.abilities.HYPNOSIS",
	SNAPPING_1: "games.arknova.abilities.SNAPPING_1",
	SCAVENGING: "games.arknova.abilities.SCAVENGING",
	POSTURING: "games.arknova.abilities.POSTURING",
	BOOST_BUILDING: "games.arknova.abilities.BOOST_BUILDING",
	PERCEPTION_4: "games.arknova.abilities.PERCEPTION_4",
	DETERMINATION: "games.arknova.abilities.DETERMINATION",
	MULTIPLIER_BUILDING: "games.arknova.abilities.MULTIPLIER_BUILDING",
	PEACOCKING: "games.arknova.abilities.PEACOCKING",
	ACTION_BUILDING: "games.arknova.abilities.ACTION_BUILDING",
	PETTING_ZOO_ANIMAL: "games.arknova.abilities.PETTING_ZOO_ANIMAL",
	MARK: "games.arknova.abilities.MARK",
	APPEAL: "games.arknova.abilities.APPEAL",
	TRADE: "games.arknova.abilities.TRADE",
	SEA_ANIMAL_MAGNET: "games.arknova.abilities.SEA_ANIMAL_MAGNET",
	REEF_MONEY: "games.arknova.abilities.REEF_MONEY",
	SYMBIOSIS: "games.arknova.abilities.SYMBIOSIS",
	HELPFUL: "games.arknova.abilities.HELPFUL",
	TAKE_CARD_IN_RANGE: "games.arknova.abilities.TAKE_CARD_IN_RANGE",
	REPUTATION: "games.arknova.abilities.REPUTATION",
	EXTRA_SHIFT: "games.arknova.abilities.EXTRA_SHIFT",
	GLIDE: "games.arknova.abilities.GLIDE",
	CONSERVATION_POINT: "games.arknova.abilities.CONSERVATION_POINT",
	SHARK_ATTACK: "games.arknova.abilities.SHARK_ATTACK",
	CUT_DOWN: "games.arknova.abilities.CUT_DOWN",
	CAMOUFLAGE: "games.arknova.abilities.CAMOUFLAGE",
	SCUBA_DIVE: "games.arknova.abilities.SCUBA_DIVE",
	MARKETING: "games.arknova.abilities.MARKETING",
	ADAPT: "games.arknova.abilities.ADAPT",
	MONKEY_GANG: "games.arknova.abilities.MONKEY_GANG"
}, X = {
	africa: "games.arknova.tags.africa",
	americas: "games.arknova.tags.americas",
	asia: "games.arknova.tags.asia",
	australia: "games.arknova.tags.australia",
	europe: "games.arknova.tags.europe",
	bird: "games.arknova.tags.bird",
	herbivore: "games.arknova.tags.herbivore",
	predator: "games.arknova.tags.predator",
	primate: "games.arknova.tags.primate",
	reptile: "games.arknova.tags.reptile",
	bear: "games.arknova.tags.bear",
	pet: "games.arknova.tags.pet",
	seaAnimal: "games.arknova.tags.seaAnimal",
	science: "games.arknova.tags.science",
	rock: "games.arknova.tags.rock",
	water: "games.arknova.tags.water"
}, mr = {
	money: "games.arknova.money",
	appeal: "games.arknova.appeal",
	conservation: "games.arknova.conservation",
	reputation: "games.arknova.reputation",
	x: "games.arknova.x"
}, hr = {
	draw: "games.arknova.drawCards",
	takeRange: "games.arknova.takeCard",
	worker: "games.arknova.hire",
	upgrade: "games.arknova.upgrade",
	upgradeOrWorker: "games.arknova.upgrade",
	trackReward: "games.arknova.reward",
	placementBonus: "games.arknova.placementBonus",
	bonus: "games.arknova.reward",
	freeBuild: "games.arknova.placeBuilding",
	unique: "games.arknova.placeBuilding",
	projectReward: "games.arknova.reward",
	assignment: "games.arknova.ability",
	expedition: "games.arknova.sendExpedition",
	enlarge: "games.arknova.enlarge",
	okapi: "games.arknova.playCard",
	relocate: "games.arknova.moveAnimal",
	reconstruct: "games.arknova.reconstruct",
	pavilionAppeal: "games.arknova.appeal",
	discardPet: "games.arknova.takeCard",
	paidAppeal: "games.arknova.gainAppealPaid",
	searchSponsor: "games.arknova.takeCard"
}, gr = {
	upgrade: "games.arknova.bonusNames.upgrade",
	worker: "games.arknova.bonusNames.worker",
	partner: "games.arknova.bonusNames.partner",
	university: "games.arknova.bonusNames.university",
	sponsorMoney: "games.arknova.bonusNames.sponsorMoney",
	multiplier: "games.arknova.bonusNames.multiplier",
	specialEnclosure: "games.arknova.bonusNames.specialEnclosure",
	kiosk: "games.arknova.bonusNames.kiosk",
	pavilion: "games.arknova.buildings.pavilion",
	wildcard: "games.arknova.bonusNames.wildcard",
	ignoreConditions: "games.arknova.useIgnore",
	extraShift: "games.arknova.extraShift",
	snapHandLimit: "games.arknova.refillSnap"
};
function _r(e, t) {
	return e.split("|").map((e) => {
		let n = {
			hunterPredators: "games.arknova.managementHunter",
			scienceReputation: "games.arknova.managementScience",
			searchCategory: "games.arknova.managementSearch",
			reef: "games.arknova.managementReef",
			sunbathing2: "games.arknova.managementSunbathing"
		};
		if (n[e]) return t(n[e]);
		if (gr[e]) return t(gr[e]);
		let r = /^(money|appeal|conservation|reputation|rep|xtoken|cards|card|clever|pouch|enclosure|upgrade|worker|partner|university|posturing|adapt)(\d+)?$/.exec(e);
		if (!r) return pr[e] ? t(pr[e]) : t("games.arknova.reward");
		let i = r[1], a = Number(r[2] ?? 1);
		return i === "enclosure" ? t($t[`standard${a}`]) : t("games.arknova.rewardCount", {
			n: a,
			reward: t(mr[{
				xtoken: "x",
				rep: "reputation"
			}[i] ?? i] ?? gr[i] ?? {
				card: "games.arknova.takeCard",
				cards: "games.arknova.drawCards",
				clever: pr.CLEVER,
				pouch: pr.POUCH,
				posturing: pr.POSTURING,
				adapt: pr.ADAPT
			}[i])
		});
	}).join(" · ");
}
function vr(e, t, n) {
	let r = { ...e.params };
	if (e.action && (r.action = t(Qt[e.action])), e.building && (r.building = t($t[e.building])), r.resource && mr[String(r.resource)] && (r.resource = t(mr[String(r.resource)])), r.bonus !== void 0) {
		let e = [t("games.arknova.projectChoice", r), t(Number(r.income) ? "games.arknova.recurringReward" : "games.arknova.immediateReward", { reward: _r(String(r.reward), t) })];
		return r.reputation && e.push(t("games.arknova.gain", {
			n: r.reputation,
			resource: t("games.arknova.reputation")
		})), r.slotEffect && e.push(_r(String(r.slotEffect), t)), r.firstEffect && e.push(t("games.arknova.firstProjectReward", { reward: _r(String(r.firstEffect), t) })), r.wildcard && e.push(t("games.arknova.spendWildcard", { card: P[String(r.wildcard)] ? t(P[String(r.wildcard)].nameKey) : t("games.arknova.bonusNames.wildcard") })), r.animal && e.push(t("games.arknova.releaseChoice", { card: t(P[String(r.animal)].nameKey) })), e.join(" · ");
	}
	if (r.reward) return `${t(e.key, r)} · ${_r(String(r.reward), t)}`;
	if (r.university) {
		let n = String(r.university), i = {
			hand: "games.arknova.universityHand",
			science2: "games.arknova.universityScience",
			science_rep: "games.arknova.universityReputation"
		}[n];
		return `${t(e.key, r)} · ${i ? t(i) : `🔬 ${t(X[n.slice(7)])}`}`;
	}
	if (e.key === "games.arknova.resolve") {
		let n = String(r.ability);
		return mr[n] ? t("games.arknova.gain", {
			n: e.value ?? 1,
			resource: t(mr[n])
		}) : pr[n] ? t("games.arknova.effect", { ability: t(pr[n]) }) : t(hr[n] ?? "games.arknova.ability");
	}
	if (r.rid) return `${t(e.key, r)} · ${n(String(r.rid))}`;
	if (e.key === "games.arknova.moveAnimal" && r.n) return `${t(e.key)} · ${t("games.arknova.habitat", { n: r.n })}`;
	if (r.tag && X[r.tag]) return `${t(e.key, r)} · ${t(X[r.tag])}`;
	let i = t(e.key, r);
	return e.action && e.key !== "games.arknova.action" ? `${i} · ${t(Qt[e.action])}` : i;
}
//#endregion
//#region src/games/arknova/natural-art.ts
var yr = 0, br = "<g fill=\"#72836a\"><path d=\"m42 160 4-72h5l8 72Z\" fill=\"#746b46\"/><path d=\"m49 109-22-26 3-2 21 19 18-23 4 1-21 31\" fill=\"#746b46\"/><path d=\"M4 80C8 67 28 65 37 67 47 55 68 57 74 65 93 61 108 70 106 79 89 88 24 91 4 80Z\"/><path d=\"M10 78q22-11 39-7 27-9 49 4\" fill=\"none\" stroke=\"#9ca480\" stroke-width=\"5\"/></g>", xr = "<g fill=\"none\" stroke=\"#839166\" stroke-width=\"1.4\" opacity=\".7\"><path d=\"m15 222 8-12-2 14 9-6m57 8 4-16 4 15 6-10m25 12 1-11 6 8m182 0 7-11 1 10 7-6m31 3 1-16 5 14 8-9m19 10 6-8\"/></g>";
function Sr(e) {
	let t = `animal${++yr}`;
	return `<svg xmlns="http://www.w3.org/2000/svg" class="an-natural-art" viewBox="0 0 400 250" aria-hidden="true">${e.replaceAll("__", t)}</svg>`;
}
function Cr() {
	return Sr(`<defs>
    <linearGradient id="__sky" x2="0" y2="1"><stop stop-color="#e8e4c9"/><stop offset="1" stop-color="#f5eedb"/></linearGradient>
    <linearGradient id="__coat" x1="0" x2="1" y2=".7"><stop stop-color="#d5aa67"/><stop offset=".45" stop-color="#efd4a0"/><stop offset="1" stop-color="#c39960"/></linearGradient>
    <linearGradient id="__neck" x1="0" x2="1"><stop stop-color="#c7a26a"/><stop offset=".55" stop-color="#e8c88c"/><stop offset="1" stop-color="#f4dfae"/></linearGradient>
    <clipPath id="__body"><path d="M121 151q6-29 41-28l71 6 26-80q4-12 12-10l13 6q3 4 0 13l-12 89q-3 22-31 29l-69 1q-39-1-51-26Z"/></clipPath>
  </defs>
  <rect width="400" height="250" fill="url(#__sky)"/>
  <path d="M0 155q73-29 143 0t141-5 116-12v112H0" fill="#b6bb91"/><path d="M0 188q124-21 217-5t183-13v80H0" fill="#d4caa4"/>
  <g opacity=".44" transform="translate(12 -7) scale(.9)">${br}</g><g transform="translate(287 40) scale(.77)">${br}</g>
  <ellipse cx="206" cy="237" rx="83" ry="5" fill="#9e936b" opacity=".25"/>
  <g stroke="#7d6444" stroke-linejoin="round">
    <path d="m161 165 9 26-7 42-7 3 2-43-12-24m97-4 15 25 8 42-7 3-13-42-14-25" fill="#b99561" stroke-width="1.2"/>
    <path d="M132 143q-24 13-14 41l-10 13" fill="none" stroke-width="2.8"/><path d="m108 193-7 14q11-1 13-10" fill="#504635"/>
    <path d="M121 151q6-29 41-28l71 6 26-80q4-12 12-10l13 6q3 4 0 13l-12 89q-3 22-31 29l-69 1q-39-1-51-26Z" fill="url(#__coat)" stroke-width="1.2"/>
    <path d="m237 133 22-84q4-12 12-10l13 6q3 4 0 13l-12 89-18 18" fill="url(#__neck)" stroke="none"/>
    <path d="m151 166-1 25 2 43-9 1-4-44-2-26m101 1 0 25-9 43-8 1 6-45-2-21" fill="#e4c28a" stroke-width="1.1"/>
    <g clip-path="url(#__body)" fill="#95633b" stroke="#805b39" stroke-width=".5">
      <path d="m130 135 12-7 12 5-3 12-13 4-8-5Zm24 18 16-7 10 8-5 13-14 1-8-8Zm3-24 15-4 7 13-8 6-15-3Zm24 1 14-1 5 12-9 6-12-5Zm1 23 15-6 10 10-9 12-13-2Zm23-21 16 1 4 13-10 6-12-9Zm1 24 16-6 13 6-4 14-16 4Zm22-18 14-9 7 11-4 12-14-1Zm18-12 7-15 12 1 5 10-10 11-9 1Zm8-26 4-16 12 2 2 15-10 5Zm9-44 9-8 9 8-3 13-12 3Zm-4 19 12-2 6 6-5 10-12-4Z"/>
      <path d="m125 149 14 5-2 12-12-3Zm115 12 10-14 14-3 1 16-15 10Z"/>
    </g>
    <path d="m150 188-8-3 1 11 8 0m-8 18 8 1 1 10h-8m90-25-8-2-3 11 8 2m-3 10-8-1-2 10 8 1" fill="#a47949" stroke="none"/>
    <path d="m140 233 13-1 0 5-13 1m80-4 11-1-1 5-12 1m-63-4 9-2 0 5-9 1m101-3 10-3 2 5-11 3" fill="#4e4838" stroke-width=".7"/>
    <path d="m257 52 0-10 4-6 2-7 2 5 1 12-2 9m-5 1-3 12-4 5m0 1-2 10m-1 2-2 9" stroke="#665039" stroke-width="2.2" fill="none"/>
    <path d="M269 43q-8-6-8-15l5-2q6 5 7 12m6-2q7-10 17-9l2 4-15 13" fill="#c49b65" stroke-width="1.2"/>
    <path d="m278 30-1-12 3-1 3 13m8-1 3-11 3 1-1 11" fill="#af8554" stroke-width="1.1"/><circle cx="278" cy="17" r="3" fill="#5c4934"/><circle cx="296" cy="17" r="3" fill="#5c4934"/>
    <path d="M271 36q8-11 22-4l5 5 26 7q7 4 5 10-4 4-15 2l-22-4-13 5-10-11Z" fill="#e0bf86" stroke-width="1.2"/>
    <path d="m308 41 15 3q7 4 5 10-5 3-14 1l-7-6Z" fill="#baa17a" stroke="none"/>
    <path d="M282 37q6-3 9 2l-7 3Z" fill="#3d3d2f" stroke="none"/><circle cx="287" cy="38" r=".9" fill="#fff4d8"/>
    <path d="m295 45 6 2m17 1 3 1m-13 6 12 0" fill="none" stroke="#715e43" stroke-width="1"/>
    <path d="m280 51 13-1 10 3-9 5-10 12" fill="none" stroke="#f6deb2" stroke-width="2.2"/>
    <path d="M136 165q32 16 81 8" fill="none" stroke="#fff0c6" stroke-width="2.5" opacity=".6"/>
  </g>${xr}`);
}
function wr() {
	return Sr("<defs><linearGradient id=\"__sky\" x2=\"0\" y2=\"1\"><stop stop-color=\"#e8e7d6\"/><stop offset=\"1\" stop-color=\"#efeadc\"/></linearGradient><linearGradient id=\"__feather\" x1=\"0\" y1=\"0\" x2=\".7\" y2=\"1\"><stop stop-color=\"#f6c5b4\"/><stop offset=\".5\" stop-color=\"#e99987\"/><stop offset=\"1\" stop-color=\"#bb6f66\"/></linearGradient></defs>\n  <rect width=\"400\" height=\"250\" fill=\"url(#__sky)\"/><path d=\"M0 117q82-16 153 0t137-5 110-6v144H0\" fill=\"#aebfb0\"/><path d=\"M0 144q78-13 153-2t147-4 100-9v121H0\" fill=\"#bfcebc\"/>\n  <g fill=\"none\" stroke=\"#f4f0dc\" opacity=\".65\"><path d=\"M28 180h91m142 25h108M8 221h140m26-30h51m-65-29h81m46 68h58\" stroke-width=\"2\"/></g>\n  <g fill=\"none\" stroke=\"#7e8b67\" stroke-width=\"2\"><path d=\"m35 188-6-78m7 60 9-51m-14 28-10-19m315 56 6-94m-7 74-9-44m19 27 9-35\"/><path d=\"m27 111 3 22m313-41-2 21\" stroke=\"#7b6f4a\" stroke-width=\"5\"/></g>\n  <ellipse cx=\"206\" cy=\"225\" rx=\"51\" ry=\"4\" fill=\"#768e7d\" opacity=\".18\"/>\n  <g fill=\"none\" stroke=\"#a86e65\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n    <path d=\"m185 141 8 40 15 39-12 2m12-2 10 3m-18-2-9 6m17-6 9 6\" stroke-width=\"3\"/>\n    <path d=\"m201 142-7 36-10 44-12 1m12-1 12 4m-12-4-6 6\" stroke-width=\"3.2\"/>\n    <path d=\"m192 179 5 2m-7 1 5 1\" stroke=\"#7a5752\" stroke-width=\"4\"/>\n  </g>\n  <path d=\"M134 127q18-28 54-25 21 1 38 15l18 17-26 9q-40 12-70-1l-27-7Z\" fill=\"url(#__feather)\" stroke=\"#ba7b70\" stroke-width=\"1.3\"/>\n  <path d=\"m130 129-15 8 36 9q19 8 41-3-23-4-34-14Z\" fill=\"#a65e5e\"/><path d=\"m129 133 23 9 26-1\" stroke=\"#484b42\" stroke-width=\"4\" fill=\"none\"/>\n  <path d=\"M210 120q21-17 7-36-16-18-5-34 8-13 22-14 15-3 20 10 4 10-5 15-5 2-9 0 9-8 3-14-6-7-16 0-12 8-3 24 22 29 3 50Z\" fill=\"url(#__feather)\" stroke=\"#bc8378\" stroke-width=\"1.2\"/>\n  <path d=\"M219 112q15-17 1-37-9-12-3-23 10-16 22-10\" fill=\"none\" stroke=\"#f5ccbd\" stroke-width=\"4\"/>\n  <path d=\"M239 37q15-5 21 5l1 12-13 5-11-8Z\" fill=\"#efac99\" stroke=\"#bc8378\" stroke-width=\"1\"/>\n  <path d=\"m253 47 19 8-8 19-7-4-3-11-8-6\" fill=\"#d4a4a0\" stroke=\"#8c6865\" stroke-width=\"1\"/><path d=\"m269 60-5 14-7-4-3-8 6 1 5-5Z\" fill=\"#3e4440\" stroke=\"#3e4440\"/>\n  <path d=\"m260 57 3 6\" stroke=\"#f4d6c7\" stroke-width=\"1.5\"/><circle cx=\"249\" cy=\"44\" r=\"2.8\" fill=\"#ede2c9\"/><circle cx=\"249.5\" cy=\"44\" r=\"1.4\" fill=\"#3f4a40\"/>\n  <g fill=\"none\" stroke=\"#cf897c\" stroke-width=\"1.1\"><path d=\"M153 118q28-9 54 7m-53-2q25-6 49 6m-43 2q22-4 38 4m-26-20q18-1 33 8m-25-12q17 2 27 10\"/></g>\n  <path d=\"m157 140 9-5 10 8m1-1 10-8 12 3m-18-28 13-1 9 6\" fill=\"none\" stroke=\"#f6c1ae\" stroke-width=\"2\"/>\n  <g transform=\"translate(65 68) scale(.45)\" opacity=\".42\"><path d=\"M125 130q37-44 80-9 38-35 10-52 0-37 30-26l10 15-10 12-9-16q-15 2-5 17 31 33 0 59-52 32-100 13Z\" fill=\"#d9a395\"/><path d=\"m188 144 6 79m17-78-19 77\" stroke=\"#b3887d\" stroke-width=\"4\"/></g>");
}
function Tr() {
	return Sr("<defs><linearGradient id=\"__sea\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#c3dcd2\"/><stop offset=\".55\" stop-color=\"#7faeac\"/><stop offset=\"1\" stop-color=\"#4d7e83\"/></linearGradient><linearGradient id=\"__shell\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\".8\"><stop stop-color=\"#a6a16a\"/><stop offset=\".5\" stop-color=\"#697659\"/><stop offset=\"1\" stop-color=\"#3d5b52\"/></linearGradient><linearGradient id=\"__skin\"><stop stop-color=\"#aab998\"/><stop offset=\"1\" stop-color=\"#718d77\"/></linearGradient></defs>\n  <rect width=\"400\" height=\"250\" fill=\"url(#__sea)\"/>\n  <path d=\"m16 0 128 250h32L66 0m78 0 63 250h25L190 0m93 0-24 250h24L329 0\" fill=\"#eef3d4\" opacity=\".09\"/>\n  <path d=\"M0 211q87-18 163 9t135-1 102-24v55H0Z\" fill=\"#8fae9e\" opacity=\".45\"/>\n  <g fill=\"none\" stroke=\"#dce8d2\" stroke-width=\"1\" opacity=\".45\"><path d=\"M10 38q34-12 63-1m226 18q26-11 54-6M26 184q20-8 39-2m212 32q21-8 37-5\"/></g>\n  <g fill=\"#d0dace\" opacity=\".65\"><path d=\"m49 77 16-4 8 4-8 4Z\"/><path d=\"m42 77-5-6v11Zm276 79 17-4 8 4-8 4Zm-7 0-6-5v10Z\"/></g>\n  <g stroke=\"#47675d\" stroke-width=\"1.4\" stroke-linejoin=\"round\">\n    <path d=\"M149 137q-32 7-63 43-12 17-30 18 1-13 11-23 27-39 67-60Z\" fill=\"#6f8f78\"/>\n    <path d=\"M189 86q10-33 7-58 1-17 13-22 18 19 9 46l-4 37Z\" fill=\"#88a58a\"/>\n    <path d=\"M251 119q31 12 46 39l32 38q8 10 6 16-30-2-48-22l-44-36Z\" fill=\"url(#__skin)\"/>\n    <path d=\"M167 164q-7 35-36 48-18 9-23 5 10-25 28-41l11-20Z\" fill=\"#78967b\"/>\n    <path d=\"m133 136-31 8 26-23\" fill=\"#799581\"/>\n    <path d=\"M234 78q24-17 46-14l22-14q12-5 21 3l15 14q7 12-6 18l-28 6-31 17-30-4Z\" fill=\"url(#__skin)\"/>\n    <path d=\"m308 57 12-2 12 9-12 3-15-3m16 6 16-2-1 9-15 2-7-5m-8 8 11-4 6 7-14 5-10-3m-17-12 10-7 9 7-8 9-11-1\" fill=\"#517569\" stroke=\"#adbea0\" stroke-width=\"1\"/>\n    <path d=\"M135 103q23-39 68-40 38 2 55 25 27 36-8 66-34 26-82 21-43-3-48-31-3-21 15-41Z\" fill=\"url(#__shell)\" stroke-width=\"2.5\"/>\n    <path d=\"M138 103q25-32 66-33 34 3 49 25 21 29-10 52-32 22-72 19-36-2-43-24-4-20 10-39Z\" fill=\"none\" stroke=\"#b5b389\" stroke-width=\"2\"/>\n    <g stroke=\"#c3bc8c\" stroke-width=\"1.7\" fill=\"none\"><path d=\"m171 80 17 18-6 23-27 5-16-17m49-11 30-6 15 18-7 24-29 7-15-20m36-29 13-13m2 31 19-8m-26 32 14 17m-43-10-7 21m-35-35-18 15m34-46 1-18\"/><path d=\"m142 94 11 7-9 15-13 4m1 26 21-5 9 19m31 5 1-9 22-5 9 8m22-23-9-6 9-15 13-2m-30-32-5 10-17-3-7-14\"/></g>\n    <path d=\"M144 96q27-27 60-25\" fill=\"none\" stroke=\"#ded1a0\" stroke-width=\"4\" opacity=\".5\"/>\n    <path d=\"m270 139 2 15 12 4 1-9m2 12 1 14 12 3-1-12m5 15 2 11 12 3-4-12m-165-2 2 9-11 9-6-4m5-9 1 8m-55-22 8 8 9-10-5-8m8-1 8 7 9-9-6-8m90-113 9 4 1 13-10 1m-1 5 9 2-2 15-9-1\" fill=\"#5c806b\" stroke=\"#a9bd9d\" stroke-width=\"1\"/>\n    <circle cx=\"317\" cy=\"63\" r=\"3.6\" fill=\"#ced0aa\"/><circle cx=\"318\" cy=\"63\" r=\"2\" fill=\"#243d36\"/><circle cx=\"319\" cy=\"62\" r=\".6\" fill=\"#f8f0d9\"/>\n    <path d=\"m328 78 7-3m-9 9 7-2\" stroke=\"#405b51\" fill=\"none\"/>\n  </g>\n  <g fill=\"none\" stroke=\"#688f7e\" stroke-linecap=\"round\"><path d=\"M17 250q15-35 2-59m10 59q10-28 2-43m335 43q-9-30 4-54m-10 53q-10-24-5-33\" stroke-width=\"4\"/><path d=\"M18 229 8 216m15 13 12-10m333 13 13-15m-18 13-9-15\" stroke-width=\"2\"/></g>");
}
function Er() {
	return Sr(`<defs><linearGradient id="__sky" x2="0" y2="1"><stop stop-color="#dbe5d6"/><stop offset="1" stop-color="#eee9d5"/></linearGradient></defs><rect width="400" height="250" fill="url(#__sky)"/>
  <path d="M0 175q90-26 182-2t218-11v88H0" fill="#a2b293"/><path d="m90 250 64-67h99l70 67" fill="#d6ceb4"/>
  <g fill="#5c7b5e"><path d="M23 192q-24-44 0-72 31 26 8 72m343-3q-26-51 3-81 32 42 6 82"/><path d="M41 183q-20-45 8-68 26 35 3 68"/></g>
  <path d="m79 170 0-72 116-48 126 54v68Z" fill="#c5c9ad" stroke="#72866f" stroke-width="2"/><path d="m75 99 120-57 133 55-6 13-127-48-115 48Z" fill="#66856d" stroke="#425e4e" stroke-width="2"/>
  <path d="m98 117 97-38 104 38v55H98Z" fill="#e4deca"/>
  <g fill="#7eaba6" stroke="#4e746b" stroke-width="2"><path d="M113 122h29v38h-29Zm42-12h28v50h-28Zm53 0h28v50h-28Zm40 12h34v38h-34Z"/></g>
  <g stroke="#dce5d4" stroke-width="2"><path d="M128 123v36m-14-18h27m14-13h28m39-17v49m27-18h32m-17-19v36"/></g>
  <path d="m183 119 25 0v56h-25Z" fill="#55776b" stroke="#3f6256" stroke-width="2"/><circle cx="201" cy="149" r="2" fill="#e4cc91"/>
  <path d="M112 176h174v8H112Z" fill="#a6ab95"/><path d="M104 184h190v6H104Z" fill="#858e7b"/>
  <g transform="translate(186 87)"><circle cx="9" cy="9" r="13" fill="#f1ead2" stroke="#758773" stroke-width="1"/><path d="m8 0 3 0v8l5 8H2l6-8Z" fill="#4d7a71"/><path d="M6 12h7" stroke="#d7e4d0"/></g>
  <path d="M56 201h60m190 0h34" stroke="#778566" stroke-width="2"/><g fill="#d1bc7e"><circle cx="63" cy="197" r="4"/><circle cx="81" cy="196" r="3"/><circle cx="327" cy="199" r="4"/></g>${xr}`);
}
var Dr = {
	"#e8e4c9": "#c9e9ef",
	"#f5eedb": "#f6edc9",
	"#b6bb91": "#9ac366",
	"#d4caa4": "#e3cc83",
	"#72836a": "#5d8c3e",
	"#9ca480": "#a4c566",
	"#e8e7d6": "#ccedf2",
	"#efeadc": "#f4ecce",
	"#aebfb0": "#6fc5ce",
	"#bfcebc": "#a0d7d5",
	"#f6c5b4": "#ffd4b9",
	"#e99987": "#f59b88",
	"#bb6f66": "#d5686c",
	"#c3dcd2": "#b0e9ef",
	"#7faeac": "#31a9c3",
	"#4d7e83": "#166c98",
	"#8fae9e": "#70bca9",
	"#dbe5d6": "#c2e4f0",
	"#eee9d5": "#fff1cf",
	"#a2b293": "#9bc164",
	"#66856d": "#32807c",
	"#7eaba6": "#74c6df",
	"#e4deca": "#f5e8be"
}, Or = (e) => Object.entries(Dr).reduce((e, [t, n]) => e.replaceAll(t, n), e), kr = () => Or(Cr()), Ar = () => Or(wr()), jr = () => Or(Tr()), Mr = () => Or(Er()), Nr = 0;
function Pr(e) {
	return `<svg xmlns="http://www.w3.org/2000/svg" class="an-natural-art" viewBox="0 0 400 250" aria-hidden="true">${e.replaceAll("__", `scene${++Nr}`)}</svg>`;
}
function Fr() {
	let e = (e, t, n) => Array.from({ length: n }, (n, r) => `<rect x="${e + r * 10}" y="${t - r % 3 * 3}" width="${7 + r % 2}" height="${33 + r % 3 * 3}" rx="1" fill="${[
		"#ac563f",
		"#e6bd61",
		"#328992",
		"#3f6c59",
		"#bd894f"
	][r % 5]}"/><path d="M${e + r * 10 + 2} ${t + 5}h4m-4 20h4" stroke="#ead5a7" stroke-width="1"/>`).join("");
	return Pr(`<defs><linearGradient id="__wall" x2="0" y2="1"><stop stop-color="#d0b681"/><stop offset="1" stop-color="#f1dfb3"/></linearGradient></defs><rect width="400" height="250" fill="url(#__wall)"/><path d="M0 220h400v30H0Z" fill="#9d794e"/><path d="m40 0 25 250m290-250-25 250" stroke="#e2d1a8" stroke-width="12"/><rect x="143" y="32" width="115" height="155" rx="52" fill="#7ccfe2" stroke="#917246" stroke-width="9"/><path d="M198 37v146m-50-79h104" stroke="#f5edcf" stroke-width="6"/><path d="M150 166q47-59 102-7v26H150Z" fill="#83ad55"/><g fill="#775434" stroke="#bd955e" stroke-width="4"><path d="M9 14h108v198H9Zm274 0h108v212H283Z"/></g>${[
		40,
		96,
		153
	].map((t) => `<g>${e(17, t, 9)}<path d="M12 ${t + 36}h103M287 ${t + 36}h102" stroke="#d6ad70" stroke-width="5"/>${e(290, t, 9)}</g>`).join("")}<ellipse cx="204" cy="224" rx="105" ry="12" fill="#634b34" opacity=".2"/><path d="m151 198-5 45m108-45 5 45" stroke="#705032" stroke-width="6"/><path d="M118 189h171v13H118Z" fill="#bd8e51" stroke="#785a36" stroke-width="2"/><path d="M165 172q20-9 40 0 17-10 37 0v18q-19-7-37 0-22-8-40-1Z" fill="#fff3d1" stroke="#8e8060" stroke-width="1.2"/><path d="M205 172v17m-32-12 24 1m16-1 20-1m-60 5 24 1m16-1 20-1" stroke="#bdaf8a"/><path d="M256 150v36m-16 2h31m-27-39 12-28 14 28Z" fill="#4c8269" stroke="#5f6543" stroke-width="2"/>`);
}
function Ir() {
	return Pr("<defs><linearGradient id=\"__wall\" x2=\"0\" y2=\"1\"><stop stop-color=\"#bee5ee\"/><stop offset=\"1\" stop-color=\"#eff5dc\"/></linearGradient></defs><rect width=\"400\" height=\"250\" fill=\"url(#__wall)\"/><path d=\"M0 177h400v73H0Z\" fill=\"#dbc493\"/><path d=\"M0 179h400\" stroke=\"#a78e63\" stroke-width=\"7\"/><rect x=\"26\" y=\"23\" width=\"111\" height=\"125\" rx=\"3\" fill=\"#75bdd1\" stroke=\"#f4f1d8\" stroke-width=\"8\"/><path d=\"M80 26v117m-51-60h105\" stroke=\"#f4f1d8\" stroke-width=\"5\"/><path d=\"m272 196 15-65-5-18h35l-5 18 18 65Z\" fill=\"#d4f4e7\" stroke=\"#548984\" stroke-width=\"3\"/><path d=\"m283 173 32 0 5 18h-41Z\" fill=\"#3eafae\"/><g stroke=\"#405865\" stroke-linejoin=\"round\"><path d=\"m170 48 27-15 48 77-28 17Z\" fill=\"#f0f5ed\" stroke-width=\"3\"/><path d=\"m167 47 26-16 8 11-27 16Zm43 67 27-16 7 13-27 17Z\" fill=\"#334d5b\" stroke-width=\"2\"/><path d=\"M239 128q33 65-38 72h-43v-16h37q43-2 27-45Z\" fill=\"#ebf0de\" stroke-width=\"4\"/><path d=\"M152 141h79v11h-79Zm-11 58h113v13H141Z\" fill=\"#527a86\" stroke-width=\"3\"/><circle cx=\"228\" cy=\"143\" r=\"9\" fill=\"#d1a65b\" stroke-width=\"2\"/><path d=\"M184 118v17\" stroke-width=\"7\"/></g><g fill=\"#a5cfd7\" stroke=\"#57848e\" stroke-width=\"2\"><path d=\"M340 121h10v69q-5 12-10 0Zm19-8h10v77q-5 12-10 0Z\"/></g><path d=\"M336 176h38v26h-38Z\" fill=\"#b89a61\"/>");
}
function Lr() {
	return Pr("<rect width=\"400\" height=\"250\" fill=\"#d5e7dc\"/><path d=\"M0 0h400v42H0Zm0 215h400v35H0Z\" fill=\"#a58b60\"/><rect x=\"26\" y=\"34\" width=\"350\" height=\"184\" rx=\"6\" fill=\"#1c8fac\" stroke=\"#537983\" stroke-width=\"8\"/><path d=\"M29 184q73-24 151 3t193-4v29H29Z\" fill=\"#bfcba0\"/><g fill=\"none\" stroke=\"#63c1a5\" stroke-width=\"8\"><path d=\"M63 201q25-42 4-102m10 100q5-32 19-66m236 65q-26-51-2-99m-19 99q-1-31-16-47\"/></g><path d=\"m150 117-30 43q-5 13 11 5l34-29m55-25 33 29 23 6-9-22-34-28\" fill=\"#a5c88b\" stroke=\"#496e61\" stroke-width=\"2\"/><path d=\"M151 105q4-43 43-46 39-3 52 33 9 36-32 48-44 12-63-15Z\" fill=\"#7d9157\" stroke=\"#3c665d\" stroke-width=\"3\"/><path d=\"m173 73 17 16-4 26-20 6m25-31 24-6 17 17-15 19-29-5m27-32 2-14m-1 52 7 12\" stroke=\"#d0ce8d\" fill=\"none\" stroke-width=\"2\"/><path d=\"m231 78 35-17q20-1 19 13-5 13-35 22\" fill=\"#adc99a\" stroke=\"#486d60\" stroke-width=\"2\"/><circle cx=\"274\" cy=\"69\" r=\"2\" fill=\"#193d41\"/><g fill=\"#dcf4da\" opacity=\".6\"><circle cx=\"127\" cy=\"75\" r=\"4\"/><circle cx=\"122\" cy=\"54\" r=\"2\"/><circle cx=\"293\" cy=\"111\" r=\"3\"/></g><path d=\"M32 55h337\" stroke=\"#c1f4f1\" stroke-width=\"3\" opacity=\".6\"/>");
}
function Rr() {
	return Mr().replace("</svg>", "<path d=\"M49 219q-1-58 16-97m-4 29q-28-37-49-6 33-5 46 11m6-20q8-41 30-31-19 12-28 35m-8-3q-16-40-34-21 27 13 34 29\" fill=\"#3d994f\" stroke=\"#5b7841\" stroke-width=\"3\"/></svg>");
}
var Z = {
	giraffe: kr,
	flamingo: Ar,
	turtle: jr,
	laboratory: Mr,
	library: Fr,
	microscope: Ir,
	aquarium: Lr,
	overseas: Rr
}, zr = 0, Br = (e, t) => `<g transform="translate(${e} ${t})"><path d="M-2 10V-50h4v60" stroke="#7d764e" stroke-width="3"/><path d="m0-73-25 33h13l-23 31h24l-21 27h64L12-9h23L12-40h13Z" fill="#4a925e"/></g>`;
function Vr(e, t, n, r) {
	return `<g transform="translate(${e} ${t})"><path d="m-13 20-9 60 13 6 15-40 12 39 15-5-10-63Z" fill="#5e775d"/><path d="M-20-25q-8 9-12 35l-18 22 9 8 29-26 3-18m29-21q18 22 24 53l-14 4-15-30" fill="${n}" stroke="#677b68" stroke-width="1.2"/><path d="m-20-25 39-1 8 52-55-1Z" fill="${n}" stroke="#6b7e6c" stroke-width="1.2"/><path d="m-2-29-2-10h12l1 12" fill="#cbaa82"/><ellipse cy="-57" rx="19" ry="24" fill="#d4b18a"/><path d="M-19-60q-8-30 18-29 30 1 20 30l-6-15-23 2Z" fill="#675b44"/><path d="m-6-32 8 7 9-8 7 6-15 21-16-18Z" fill="#f6efcd"/><path d="M-7-56h3m13 0h3m-9 5-2 7 5 1m-11 7q5 3 10-1" stroke="#5f5d49" stroke-width="1.4" fill="none"/>${r === "chart" ? "<path d=\"m-30-3 50 2-3 34-49-2Z\" fill=\"#f8edca\" stroke=\"#8d8c67\"/><path d=\"m-23 21 10-12 11 8 13-9\" stroke=\"#55a284\" stroke-width=\"2\" fill=\"none\"/><path d=\"m-23 26 35 1\" stroke=\"#a4b58a\"/>" : r === "field" ? "<path d=\"m-20-83 8-10h27l9 10 12 8h-67Z\" fill=\"#c5ab72\" stroke=\"#8b7c54\"/><path d=\"m-7-13 5 17m8-17 1 18\" stroke=\"#696b50\" stroke-width=\"3\"/><path d=\"M-9 1h20l3 12H-12Z\" fill=\"#52675f\"/>" : r === "veterinary" ? "<path d=\"M-11-12H8V5h-19Z\" fill=\"#f4f6da\"/><path d=\"M-2-9V2m-6-5H4\" stroke=\"#548a6b\" stroke-width=\"3\"/>" : ""}</g>`;
}
function Hr(e, t) {
	let n = `anSponsor${++zr}`, r = Number(t) % 4, i = `<defs><linearGradient id="${n}s" x2="0" y2="1"><stop stop-color="#bce4ec"/><stop offset="1" stop-color="#faf3d1"/></linearGradient></defs><rect width="400" height="250" fill="url(#${n}s)"/><path d="M0 163q81-35 174-12t226-4v103H0Z" fill="#92bd77"/><path d="M0 222q108-25 212-6t188-8v42H0Z" fill="#dfcd91"/>`, a;
	return a = e === "person" || e === "field" || e === "vet" ? `${Br(40, 185)}${Br(354, 184)}<path d="M42 196h316" stroke="#8c9d66"/>${Vr(195, 157, e === "vet" ? "#eff1da" : r % 2 ? "#769bab" : "#8aa975", e === "vet" ? "veterinary" : e === "field" ? "field" : "chart")}<path d="m49 227 6-14 4 15m264 0 6-13 6 13" stroke="#8fa763" fill="none"/>` : e === "finance" || e === "publication" ? `<path d="M0 177h400v73H0Z" fill="#c9ab71"/><g transform="rotate(-8 180 130)"><path d="M92 48h158l22 25v143H92Z" fill="#f9f0ce" stroke="#b6a77d" stroke-width="2"/><path d="M246 48v28h26" fill="#e6d7b0"/><path d="M114 86h105m-105 14h124m-124 14h91m-91 14h126m-126 14h111" stroke="#99ab8f" stroke-width="3"/><circle cx="192" cy="181" r="21" fill="#5f9f7b"/><path d="m180 180 8 8 18-18" fill="none" stroke="#f5f0ce" stroke-width="3"/></g><path d="m274 210 29-130 9 2-28 130-9 13Z" fill="#427c8c" stroke="#345e69"/><path d="M35 214h101l6 11H28Z" fill="#a29a64"/>${e === "finance" ? "<g fill=\"#e0bb51\" stroke=\"#967e40\"><ellipse cx=\"304\" cy=\"220\" rx=\"35\" ry=\"10\"/><path d=\"M269 206v14q35 15 70 0v-14Z\"/><ellipse cx=\"304\" cy=\"205\" rx=\"35\" ry=\"10\"/><path d=\"M275 190v14q29 13 59 0v-14Z\"/><ellipse cx=\"304\" cy=\"190\" rx=\"29\" ry=\"9\"/></g>" : ""}` : e === "cable" ? `${Br(44, 210)}${Br(352, 210)}<path d="m34 39 332 64M70 42l-8 151m262-102 9 116" fill="none" stroke="#5a7464" stroke-width="5"/><path d="M90 60h210" stroke="#6e8971" stroke-width="2"/><path d="M197 72v35" stroke="#5c796c" stroke-width="4"/><path d="M162 109q35-13 71 0l7 65h-87Z" fill="#d8883c" stroke="#6f785b" stroke-width="3"/><path d="M163 119h67l5 35h-77Z" fill="#b9dcd4"/><path d="M198 119v36" stroke="#5d8e85" stroke-width="3"/>` : e === "playground" ? `${Br(45, 207)}<path d="m105 202 21-98 37 0 23 98m37-3 20-95h38l22 95" stroke="#7d9364" stroke-width="7" fill="none"/><path d="M126 104h154" stroke="#7c8b5e" stroke-width="8"/><path d="m158 111 4 69m38-69-2 69" stroke="#766d4d" stroke-width="2"/><path d="M156 180h48" stroke="#c1843d" stroke-width="7"/><path d="M288 98v64q17 39 69 38" fill="none" stroke="#dfa942" stroke-width="13"/><path d="m281 163 11-4q17 35 63 34" fill="none" stroke="#f7cd62" stroke-width="5"/><path d="M266 183h23m-26-14h22m-19-15h18" stroke="#638b67" stroke-width="4"/>` : e === "garden" ? `${Br(40, 205)}${Br(350, 207)}<path d="M65 232q126-98 263-6" fill="none" stroke="#f2dda3" stroke-width="34"/><g fill="#48a16a">${[
		70,
		115,
		255,
		300
	].map((e, t) => `<path d="M${e} 202q-33-40 0-53 35 12 0 53Z"/><path d="M${e} 194v31" stroke="#5d8b4f" stroke-width="3"/><circle cx="${e + 6}" cy="${167 + t % 2 * 10}" r="8" fill="#e5b948"/>`).join("")}</g><path d="M163 165h70v32h-70Z" fill="#9c7c50"/><path d="M156 158h84v12h-84Z" fill="#b8945c"/>` : e === "construction" ? `${Br(40, 209)}<path d="M98 193V75h127v118" fill="#e6dcb3" stroke="#879971" stroke-width="3"/><path d="m84 79 77-45 81 45Z" fill="#7f9e7d" stroke="#527c65" stroke-width="3"/><path d="M114 98h35v45h-35m42-45h39v45h-39" fill="#a8d9d8" stroke="#eaf2cd" stroke-width="3"/><path d="M267 196V28l-38 168m-10-168h145m-40 1v74" stroke="#b5944c" stroke-width="6" fill="none"/><path d="m319 102-10 13 8 7 12-7" stroke="#6d8164" stroke-width="3" fill="none"/><path d="M72 205h251l14 20H56Z" fill="#baa479"/>` : `${Br(35, 212)}${Br(357, 207)}<path d="M83 207V92h237v115Z" fill="#e6d6a8" stroke="#74906b" stroke-width="2"/><path d="m64 94 136-65 140 65Z" fill="#4b8d7e" stroke="#3e7063" stroke-width="3"/><path d="M94 111h212v16H94Z" fill="#f7edc7"/><path d="M126 135h26v64h-26m50-64h48v72h-48m24-72v72m49-72h26v64h-26" fill="#77bac0" stroke="#e8efcf" stroke-width="3"/><path d="M55 211h290v13H55Z" fill="#b6bd86"/><g transform="translate(200 88)"><circle r="16" fill="#e8edca" stroke="#6c9772"/><path d="m-6 4 7-16 6 16Z" fill="#6c9d66"/></g>`, `<svg xmlns="http://www.w3.org/2000/svg" class="an-natural-art" viewBox="0 0 400 250" aria-hidden="true">${i}${a}</svg>`;
}
//#endregion
//#region src/games/arknova/species-art.ts
var Ur = Object.fromEntries([
	["cat", "401 402 403 404 406 407 412 413 418"],
	["fox", "405 417 424"],
	["bear", "408 409 411 416 433"],
	["mustelid", "410 414 415 419 420 425 434 556"],
	["seal", "421 422 423"],
	["elephant", "426 431"],
	["rhino", "427 432"],
	["zebra", "429"],
	["hippo", "430"],
	["tapir", "435 440"],
	["bison", "436 437 441"],
	["deer", "438 442 443"],
	["camel", "439 526"],
	["goat", "444 519 520"],
	["porcupine", "445"],
	["dugong", "446"],
	["kangaroo", "447 528"],
	["koala", "448"],
	["platypus", "449"],
	["wombat", "450"],
	["monkey", "451 452 453 454 455 456 457 458 459 460 461 462 463 464 465 466 467 468 555 558 559"],
	["crocodile", "469 479 480 489"],
	["snake", "470 474 475 482 483 485 487 488 492"],
	["tortoise", "471 481 484 551"],
	["lizard", "472 473 476 477 478 486 490 491 493"],
	["ostrich", "494 507 514 516"],
	["stork", "495 496 498 510"],
	["raptor", "499 500 504 505 506 509 560"],
	["peacock", "501 518"],
	["hornbill", "502 517"],
	["owl", "503 512 513"],
	["parrot", "508 527"],
	["pelican", "515"],
	["penguin", "554"],
	["horse", "521 522"],
	["rabbit", "523"],
	["pig", "524 557"],
	["rodent", "525"],
	["anemone", "529"],
	["fish", "530 531 533 535 536 537 538 539 540 542 547 553"],
	["plankton", "532"],
	["octopus", "534 549"],
	["ray", "541 543"],
	["shark", "544 545 546"],
	["seahorse", "548"],
	["jellyfish", "550"]
].flatMap(([e, t]) => t.split(" ").map((t) => [t, e]))), Wr = {
	cat: "#c7974c",
	fox: "#b77e43",
	bear: "#775538",
	mustelid: "#826449",
	seal: "#87775c",
	elephant: "#999885",
	rhino: "#a5a18c",
	zebra: "#eee5ce",
	hippo: "#8f8985",
	tapir: "#555b4f",
	bison: "#775337",
	deer: "#b19468",
	goat: "#b4a47b",
	camel: "#c8af81",
	porcupine: "#6d6255",
	kangaroo: "#c49567",
	koala: "#9d9d8e",
	platypus: "#8f7552",
	wombat: "#88765d",
	monkey: "#7d7254",
	crocodile: "#73835a",
	snake: "#6e8d41",
	tortoise: "#9f9b63",
	lizard: "#76a45b",
	ostrich: "#514e46",
	stork: "#e9e6d3",
	raptor: "#8d7250",
	peacock: "#247f98",
	hornbill: "#4d5149",
	owl: "#bcb092",
	parrot: "#df6543",
	pelican: "#eee7d4",
	penguin: "#263e49",
	horse: "#a3774b",
	rabbit: "#d5c6a5",
	pig: "#cfb49a",
	rodent: "#a48b5d",
	fish: "#37a3ba",
	octopus: "#b69070",
	ray: "#497f8a",
	shark: "#6f9ca3",
	seahorse: "#cd9a51",
	jellyfish: "#e9b284",
	dugong: "#8faba7"
}, Gr = {
	402: "#c39b5d",
	406: "#d79645",
	407: "#e19c46",
	405: "#dfc49a",
	409: "#403d31",
	415: "#96978a",
	419: "#7e8275",
	420: "#ad8157",
	433: "#ece7d3",
	434: "#bd683c",
	435: "#373e3c",
	437: "#806e54",
	454: "#a0a393",
	455: "#363c34",
	457: "#8f8a65",
	459: "#9da97b",
	465: "#e5ad4c",
	468: "#e7ded0",
	470: "#6cb43f",
	475: "#9c9756",
	477: "#65b357",
	482: "#839049",
	485: "#aa9475",
	491: "#ae8660",
	493: "#cda466",
	501: "#318895",
	503: "#ede9d9",
	505: "#4f5145",
	508: "#e75944",
	518: "#d9b957",
	527: "#4a9c68",
	530: "#f3a137",
	531: "#368fca",
	533: "#cc755c",
	535: "#4285ac",
	536: "#dcca65",
	537: "#3f8d9b",
	538: "#cc745b",
	539: "#c59c6d",
	540: "#bfa669",
	542: "#5caa9d",
	547: "#de9567",
	553: "#7f8c7b",
	555: "#cf9852",
	559: "#e6ded1"
}, Kr = (e) => `<g fill="${e}" opacity=".9">${Array.from({ length: 30 }, (e, t) => {
	let n = 110 + t % 10 * 13, r = 105 + Math.floor(t / 10) * 16;
	return `<ellipse cx="${n}" cy="${r}" rx="${3 + t % 3}" ry="${2 + t % 2}" transform="rotate(${t * 23 % 90} ${n} ${r})"/>`;
}).join("")}</g>`, qr = (e) => `<g stroke="${e}" stroke-width="5" fill="none" stroke-linecap="round">${Array.from({ length: 10 }, (e, t) => `<path d="M${116 + t * 13} 91q-12 21 1 54"/>`).join("")}</g>`, Q = (e = 278, t = 91) => `<ellipse cx="${e}" cy="${t}" rx="3.5" ry="2.5" fill="#24342d"/><circle cx="${e + 1}" cy="${t - 1}" r=".8" fill="#fff8e4"/>`;
function Jr(e, t, n, r) {
	return e ? `<defs><linearGradient id="${r}s" x2=".8" y2="1"><stop stop-color="#a9e8e8"/><stop offset=".5" stop-color="#37aabc"/><stop offset="1" stop-color="#24658a"/></linearGradient></defs><rect width="400" height="250" fill="url(#${r}s)"/><path d="m30 0 100 250h40L80 0m160 0-30 250h30L280 0" fill="#edffe9" opacity=".1"/><path d="M0 221q70-32 151-8t150-2 99 4v35H0Z" fill="#9fb995"/><g fill="none" stroke="#5aa18a" stroke-width="5"><path d="M32 245q25-41 8-79m-5 63 22-30m290 45q-16-45 10-85m-12 63-20-31"/></g>` : `<defs><linearGradient id="${r}s" x2="0" y2="1"><stop stop-color="${t ? "#b5d9c7" : "#c5e7ee"}"/><stop offset="1" stop-color="#f9edc4"/></linearGradient></defs><rect width="400" height="250" fill="url(#${r}s)"/><path d="M0 145q70-38 147-10t146-6 107 9v112H0Z" fill="${t ? "#68a36c" : "#a5c377"}"/><path d="M0 195q94-27 191-8t209-6v69H0Z" fill="${n ? "#88ced0" : "#e0c58c"}"/><g stroke="#52784d" stroke-width="3" fill="none" opacity=".6"><path d="M28 203 38 89m-3 32-18-21m21 39 20-31M358 193l-9-91m3 29 20-21"/></g><g fill="${t ? "#3d8556" : "#759e4a"}" opacity=".65"><path d="M0 102q23-28 60-7 10 15-8 24H0Zm324 5q23-34 64-12l12 19q-43 12-76-7Z"/></g><g stroke="#a8ac67" stroke-width="1.5" fill="none"><path d="m65 235 4-12 3 11 7-6m205 10 4-15 5 14 6-7m-87 6 2-9 5 8"/></g>`;
}
function Yr(e, t, n, r) {
	let i = e === "cat", a = e === "fox", o = e === "bear", s = t === "433", c = [
		"mustelid",
		"wombat",
		"pig"
	].includes(e), l = e === "elephant", u = e === "rhino", d = e === "hippo", f = l || u || d || o || e === "bison", p = [
		"deer",
		"goat",
		"camel",
		"horse",
		"zebra",
		"tapir"
	].includes(e), m = l ? 73 : u ? 94 : d ? 107 : o ? 91 : c ? 146 : 115, h = l ? 166 : f ? 178 : c ? 189 : 168, ee = l ? "M78 117C72 66 133 54 192 74Q228 70 249 111L251 154Q206 184 116 168Q77 157 78 117Z" : o ? "M72 148Q66 94 121 82Q175 78 216 103L257 135L244 180Q184 196 111 176Q82 171 72 148Z" : d ? "M70 150Q56 110 108 98Q171 87 231 122L259 151L249 180Q180 200 102 181Q79 176 70 150Z" : c ? "M75 169Q69 141 120 131Q183 119 235 149L255 170L243 190Q158 211 91 188Z" : "M72 141C69 112 102 104 135 109Q183 100 220 119L255 142L246 166Q182 185 112 166Q80 167 72 141Z", g = f ? 15 : 8, _ = h - 13, te = [
		{
			x: 105,
			end: 98,
			far: !0
		},
		{
			x: 207,
			end: 221,
			far: !0
		},
		{
			x: 126,
			end: 118,
			far: !1
		},
		{
			x: 231,
			end: 241,
			far: !1
		}
	].map(({ x: e, end: t, far: r }) => `<path d="M${e} ${_}q-4 23 ${(t - e) / 2} 35l${(t - e) / 2} ${229 - _ - 39}q10-1 ${g + 3} 6h-${g + 11}q-3-23-${Math.max(3, Math.abs(t - e) / 2)}-35l-8-${229 - _ - 35}Z" fill="${s ? "#353d35" : n}" opacity="${r ? .8 : 1}"/>`).join(""), ne = l ? "M79 123q-30 0-26 61" : d || o || e === "wombat" || e === "pig" ? "M79 158q-22 4-15 16" : a ? "M83 143Q33 102 16 151Q29 184 79 165" : c ? "M84 163Q24 194 14 174" : "M78 133Q25 123 28 156q1 32-17 26", re = l ? "M234 86Q253 65 276 77Q304 83 304 120L294 148L263 145Q238 127 234 86Z" : u ? "M228 117q15-30 40-16l33 32 33 8q14 15-6 24l-63 1-28-18Z" : d ? "M225 126q19-28 44-13l29 22q43-13 44 17 2 30-45 28l-45-12-23-17Z" : o ? "M227 118q-1-23 28-29 28-1 39 28l19 15-6 15-35 7-30-11Z" : p ? "M230 117Q239 90 250 65Q262 48 276 60l4 27 30 22q8 9-4 16l-18-3-27-17-14 41Z" : i ? "M238 119q-1-24 20-29 24-7 33 14l9 17-6 15-23 9-24-11Z" : a ? "M234 131q-6-25 16-34 23-9 33 12l30 16-7 12-33 7-28-6Z" : "M234 160q-2-25 19-29 27-7 35 18l25 12-5 15-34 6-29-9Z", v = "";
	l && (v += `<path d="M255 86q-26-29-49-6-14 36 22 64l26-9Z" fill="#aaa995"/><path d="M288 99q29 3 23 66l-3 29q-4 25-20 12 14-5 11-27l-8-48Z" fill="${n}"/><path d="M287 129q18 30 25 8-1 34-27 10" fill="#fff1cc" stroke="#a3a083"/><path d="M219 91q-13 21 9 37" fill="none" stroke="#878b77" stroke-width="2"/>`), u && (v += "<path d=\"m300 134 14-37 1 40 14 2 8-18 0 25-21 9Z\" fill=\"#e5d8b2\" stroke=\"#94896b\"/><path d=\"M145 100q-9 29 0 70m52-58q-10 31 0 57m-36-49 4 31\" fill=\"none\" stroke=\"#7d806e\" stroke-width=\"2\"/>"), d && (v += "<ellipse cx=\"304\" cy=\"139\" rx=\"6\" ry=\"4\" fill=\"#5d6459\"/><ellipse cx=\"328\" cy=\"142\" rx=\"5\" ry=\"4\" fill=\"#5d6459\"/><path d=\"M289 165q28 10 44-3\" fill=\"none\" stroke=\"#716e62\" stroke-width=\"2\"/>"), s && (v += "<path d=\"M98 94q18-14 34-7l13 91-40 0Zm92 8 26 7 27 61-40 14Z\" fill=\"#333f36\"/><ellipse cx=\"257\" cy=\"113\" rx=\"8\" ry=\"11\" fill=\"#353f36\"/><ellipse cx=\"280\" cy=\"112\" rx=\"7\" ry=\"10\" fill=\"#353f36\"/>"), (e === "deer" || e === "goat") && (v += "<g fill=\"none\" stroke=\"#8b7752\" stroke-width=\"4\" stroke-linecap=\"round\"><path d=\"M255 66q-17-22-10-45m5 27-16-12m31 27q15-25 8-44m1 24 14-15\"/></g>"), e === "bison" && (v += "<path d=\"M165 114q18-64 63-40l33 45-12 63-44 17-22-28Z\" fill=\"#674b35\"/><path d=\"m251 110 8 28 28 17-4 20-29-10-18-28\" fill=\"#634b35\"/><path d=\"M252 101q-19-22-24-4m52 4q10-25 20-10\" stroke=\"#e5d7b5\" stroke-width=\"6\" fill=\"none\"/>"), e === "camel" && (v += `<path d="M105 118q14-62 39-37 12 9 21 30${t === "439" ? "q9-59 33-27l15 36" : ""}" fill="${n}" stroke="#9c8358" stroke-width="1.5"/>`), (e === "horse" || e === "zebra") && (v += "<path d=\"M229 117q5-25 22-57l10 2q-9 37-13 67Z\" fill=\"#5d5a46\"/>"), i && t === "402" && (v += "<path d=\"M232 110q-9-36 28-40 36-2 43 38l-13 45-37 3-22-27Z\" fill=\"#986c3c\" stroke=\"#805a36\" stroke-width=\"2\"/>");
	let ie = t === "429" || [
		"406",
		"407",
		"267"
	].includes(t) ? qr("#4a4235") : [
		"401",
		"403",
		"412",
		"252"
	].includes(t) ? Kr("#584b36") : "", ae = l || d ? "" : o ? `<circle cx="247" cy="94" r="8" fill="${s ? "#333f36" : n}"/><circle cx="280" cy="91" r="8" fill="${s ? "#333f36" : n}"/>` : p ? "<path d=\"M255 64q-31-19-24-1l23 12m18-11q17-24 20-7l-17 17\"/>" : t === "252" ? "<circle cx=\"248\" cy=\"99\" r=\"12\"/><circle cx=\"276\" cy=\"96\" r=\"11\"/>" : a ? "<path d=\"m246 110-5-41q13 0 21 29m7 1 10-34q12 15 5 41\"/>" : i ? "<path d=\"m246 103 2-21 16 15m9-2 11-16 4 26\"/>" : "<path d=\"m251 141-5-16q17-6 21 11m8-2 8-14 7 8-5 16\"/>", oe = p ? 273 : l ? 287 : u ? 280 : d ? 272 : o ? 277 : i ? 278 : c ? 279 : 278, y = p ? 78 : l ? 103 : u ? 123 : d ? 132 : o ? 116 : i ? 111 : c ? 150 : 119;
	return `<defs><clipPath id="${r}body"><path d="${ee}"/></clipPath><linearGradient id="${r}coat" x2=".3" y2="1"><stop stop-color="${n}"/><stop offset="1" stop-color="${n}" stop-opacity=".8"/></linearGradient></defs><ellipse cx="191" cy="232" rx="117" ry="8" fill="#52624b" opacity=".18"/><g fill="${n}" stroke="#736f54" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="${ne}" fill="${a ? n : "none"}" stroke-width="${a ? 2 : c ? 6 : 3}"/>${te}<path d="${ee}" fill="url(#${r}coat)"/><g clip-path="url(#${r}body)">${ie}</g>${s ? "" : v}<path d="${re}" fill="${n}"/>${ae}${s ? v : ""}<path d="M118 ${m + 15}q39-12 72-2" stroke="#fff3d2" opacity=".35" fill="none" stroke-width="2"/>${Q(oe, y)}${!d && !u && !l ? `<path d="m${p ? 300 : i ? 288 : 302} ${p ? 108 : i ? 126 : c ? 163 : 135} 8 0-5 5Z" fill="#3d4b3d" stroke="none"/>` : ""}${i ? "<path d=\"m286 130 20-1m-20 5 18 5\" fill=\"none\" stroke-width=\".9\"/>" : ""}</g>`;
}
function Xr(e, t) {
	let n = e === "454", r = [
		"452",
		"461",
		"465",
		"467",
		"468"
	].includes(e);
	return `<ellipse cx="206" cy="228" rx="87" ry="8" fill="#46664a" opacity=".18"/><path d="M0 222q125-8 228-18t172 16" fill="none" stroke="#8a7049" stroke-width="15"/><g fill="${t}" stroke="#565b43" stroke-width="1.5" stroke-linejoin="round"><path d="M170 154q-95-6-93-80 3-42 33-31 23 17 0 33" stroke="${t}" stroke-width="${r ? 12 : 17}" fill="none"/>${n ? "<path d=\"m81 90 12 0m-8 19 15-5m-5 25 13-8m-3 20 15-8m-1 17 15-10\" stroke=\"#363f38\" stroke-width=\"9\"/>" : ""}<path d="M163 104q-32 33-14 88l29 24 62-8 8-61q-4-52-50-57Z"/><path d="m164 133-36 59-16 16 10 8 26-13 35-45m38-14 18 43-7 22 10 6 14-11 1-20-23-57"/><path d="m180 184 18 8-10 26 24 4-3 9h-43l-5-14m58-28 12 23 23 5-1 10-43-2-7-19"/><ellipse cx="203" cy="90" rx="${r ? 29 : 35}" ry="37"/><ellipse cx="172" cy="88" rx="10" ry="14"/><ellipse cx="233" cy="88" rx="10" ry="14"/><path d="M184 74q19-16 36 2l7 35q-20 23-45 0Z" fill="${[
		"455",
		"463",
		"468",
		"559"
	].includes(e) ? "#eee3c7" : "#c5ad83"}"/><path d="m194 89 4 15 11 2 4-16" fill="${e === "457" ? "#cc7066" : "#9b8664"}" stroke="none"/>${Q(190, 85)}${Q(218, 85)}<path d="M193 115q10 5 18-1" fill="none"/>${e === "451" ? "<path d=\"M198 88q27 0 13 25l-17-4Z\" fill=\"#c59a73\"/>" : e === "457" ? "<path d=\"M184 91v19m36-19v19\" stroke=\"#79a7b6\" stroke-width=\"5\"/>" : e === "468" ? "<path d=\"m179 67 9-22 11 11 12-15 13 24\" fill=\"#eee8d2\" stroke=\"#e8e4cb\"/>" : ""}</g>`;
}
function Zr(e, t, n, r) {
	if (e === "snake") return `<path d="M92 194q-62-38 20-55 114-21 134 18 18 38-90 48-52 7-51-22 1-27 80-30 57-3 57-34-1-36 42-46" stroke="#4d6244" stroke-width="31" fill="none"/><path d="M92 188q-53-31 22-45 111-21 126 16 10 31-87 39-38 3-39-15 0-22 74-24 61-2 62-40-1-32 36-39" stroke="${n}" stroke-width="24" fill="none"/><path d="M276 74q4-25 28-22l25 17-12 14-32 2Z" fill="${n}" stroke="#4d6244" stroke-width="2"/>${t === "475" ? "<path d=\"M271 92q-35-57 9-73 41-7 26 57\" fill=\"#b2a567\" stroke=\"#526449\" stroke-width=\"2\"/>" : ""}${Q(309, 66)}<path d="m322 76 24 4 7-6m-7 6 7 5" stroke="#8f5e4b" fill="none"/>`;
	if (e === "tortoise") return `<ellipse cx="205" cy="222" rx="110" ry="8" fill="#516a4f" opacity=".2"/><g fill="#9b9c70" stroke="#586a4a" stroke-width="2"><path d="m137 166-18 49 25 5 23-46m59 1 14 44 22-6-11-46m-28-51 56-27q30-4 32 18-5 21-57 23"/><path d="M98 174q-3-79 74-97 86-13 106 91l-43 25-100-2Z" fill="${n}"/><path d="m150 91 20 30-8 38-38 10m46-48 45-6 26 30-13 31-66-17m54-44 10-22m16 51 26 10m-42 21 10 17" fill="none" stroke="#d9cc8e" stroke-width="3"/>${Q(291, 112)}</g>`;
	let i = e === "crocodile", a = t === "477";
	return `<defs><clipPath id="${r}r"><path d="M99 146q15-53 106-39l55 32-16 40-125-1Z"/></clipPath></defs><g fill="${n}" stroke="#4f6d46" stroke-width="2" stroke-linejoin="round"><path d="M129 143q-80 64-114 34 52 7 85-41Z"/><path d="m142 145-27 46-39 16 4 8 35-2 46-37m52-24 37 37 33 3 5 11-44 0-44-31m-49-22-31-33-26 4-5-7 36-11 41 28m41 0 27-29 39 1 3 8-34 3-20 33"/><path d="M99 146q15-53 106-39l55 32-16 40-125-1Z"/>${t === "491" ? "<path d=\"m240 133-25-32 12-24 25 12 21-9 17 28-18 30Z\" fill=\"#d2ad72\" stroke=\"#847b4d\"/>" : ""}<path d="M227 119q17-43 52-25l${i ? "79 20-4 15-91 3" : "27 17-6 18-54 1"}Z"/>${Q(i ? 288 : 278, 109)}<path d="M115 143q65-32 126 6m-111-15 6 30m20-35 3 34m23-30 0 28m21-23 0 25" fill="none" stroke="#bec58d" stroke-width="2" opacity=".6"/>${i ? "<path d=\"m277 122 70-1m-59-17-5-6m16 8 3-5m-121 9 4-8m-25 9 1-7m-23 9-2-7\" stroke=\"#eff0c9\" fill=\"none\"/>" : a ? "<path d=\"M103 152q-66 45-63-6 5-28 26-9 7 15-8 17\" stroke=\"#579a47\" stroke-width=\"9\" fill=\"none\"/>" : ""}</g>`;
}
function Qr(e, t, n) {
	let r = [
		"ostrich",
		"stork",
		"pelican"
	].includes(e), i = e === "parrot", a = e === "owl", o = r ? 56 : 82, s = e === "hornbill" || e === "pelican" ? 56 : e === "stork" ? 44 : 16;
	return `<ellipse cx="213" cy="234" rx="73" ry="6" fill="#49644b" opacity=".18"/><g stroke="#71694c" stroke-width="1.4" stroke-linejoin="round"><path d="m186 153 6 42-3 34-17 4m29-82 12 43 7 35 19 3" fill="none" stroke="#9b7b55" stroke-width="${r ? 4 : 5}"/><path d="M124 120q22-36 61-34 58 2 68 59-35 40-111 15l-34-20Z" fill="${n}"/><path d="m126 121-38 53 56-11 51-28" fill="${t === "505" ? "#574b37" : n}"/><path d="M152 112q48-28 76 32-18 23-67 9Z" fill="${["stork", "pelican"].includes(e) ? "#788b83" : n}"/><path d="m155 123 53 17m-51-9 47 17m-47-8 37 14" stroke="#f5e7c0" opacity=".4" fill="none"/><path d="M218 134q-20-22-5-47l13-${r ? 35 : 8} 19 3 7 45Z" fill="${["505", "510"].includes(t) ? "#f4ebd5" : n}"/><ellipse cx="244" cy="${o + 15}" rx="${a ? 34 : 23}" ry="${a ? 35 : 26}" fill="${t === "505" ? "#f5ecd3" : n}"/><path d="m260 ${o + 14} ${s} 7-${i ? 10 : 5} ${i ? 22 : 7}-${s - 5}-${i ? 18 : 9}Z" fill="${t === "498" ? "#a8a276" : "#d2b36a"}"/>${Q(251, o + 11)}${a ? `<g fill="#e9dfbf" stroke="#a89572"><ellipse cx="230" cy="${o + 13}" rx="15" ry="20"/><ellipse cx="254" cy="${o + 13}" rx="15" ry="20"/></g>${Q(232, o + 13)}${Q(253, o + 13)}<path d="m239 ${o + 26} 8 0-4 9Z" fill="#9b8659"/>` : ""}${e === "peacock" ? "<path d=\"M148 140Q43-37 0 123q55 89 144 39Z\" fill=\"#408e72\" stroke=\"#d6bb63\" stroke-width=\"3\"/><g fill=\"#2e6d8c\" stroke=\"#c4bf63\" stroke-width=\"3\"><ellipse cx=\"41\" cy=\"109\" rx=\"10\" ry=\"18\"/><ellipse cx=\"72\" cy=\"83\" rx=\"10\" ry=\"18\"/><ellipse cx=\"100\" cy=\"107\" rx=\"10\" ry=\"18\"/></g>" : ""}${i ? "<path d=\"m123 143-26 82 51-62\" fill=\"#388c91\"/><path d=\"m157 128 41 26\" stroke=\"#e4bf51\" stroke-width=\"12\"/>" : ""}${e === "penguin" ? "<path d=\"M179 108q26-24 45 20l-4 42-34 0Z\" fill=\"#faf1d5\"/><path d=\"m157 113-18 60 28-20m67-40 35 51-30-13\" fill=\"#203f48\"/>" : ""}</g>`;
}
function $r(e, t, n, r) {
	if (e === "seal" || e === "dugong") return `<ellipse cx="205" cy="219" rx="130" ry="8" fill="#426e6a" opacity=".18"/><g fill="${n}" stroke="#52776d" stroke-width="1.7" stroke-linejoin="round"><path d="M112 145q-15-37 31-55 66-24 118 3l37 35q2 36-45 42l-88-2-49 24-34-8Z"/><path d="M119 154q-56-24-84 10l45 13-16 20 55-28m73-27-29 51q34 11 56-38"/><path d="M254 105q-5-28 21-31 34 2 34 33l10 15q-1 16-20 17l-30-4Z"/><path d="M297 127q9 9 17-2" fill="none"/>${Q(293, 105)}<path d="m309 123 32-6m-31 9 30 2m-31 1 25 8" fill="none" stroke-width=".9"/>${e === "dugong" ? "<path d=\"M94 165q-42-44-66-29l29 31-33 27q36 17 70-20\"/>" : ""}</g>`;
	if (e === "jellyfish") return `<path d="M120 109q-2-81 82-75 78 4 81 81-70 37-163-6Z" fill="#f0bd90" fill-opacity=".78" stroke="#f9e0ae" stroke-width="3"/><g fill="none" stroke="#eed2a8" stroke-width="3">${Array.from({ length: 8 }, (e, t) => `<path d="M${139 + t * 17} 117q-20 34 0 57t-3 57"/>`).join("")}</g>`;
	if (e === "octopus") return `<g fill="none" stroke="${n}" stroke-width="12" stroke-linecap="round">${Array.from({ length: 8 }, (e, t) => `<path d="M${170 + t * 7} 133Q${20 + t * 43} 232 ${45 + t * 42} ${184 - t % 3 * 19}q15-35 32-9"/>`).join("")}</g><path d="M153 123q-22-70 40-84 64-3 61 73-9 44-50 47Z" fill="${n}" stroke="#6c8675" stroke-width="2"/>${Q(176, 125)}${Q(221, 122)}${t === "534" ? "<g fill=\"none\" stroke=\"#436dba\" stroke-width=\"4\"><circle cx=\"175\" cy=\"83\" r=\"8\"/><circle cx=\"222\" cy=\"80\" r=\"7\"/><circle cx=\"199\" cy=\"111\" r=\"9\"/></g>" : ""}`;
	if (e === "anemone") return `<g fill="none" stroke="#c0a5be" stroke-width="8" stroke-linecap="round">${Array.from({ length: 30 }, (e, t) => `<path d="M${185 + t % 7 * 4} 205Q${63 + t * 9} 133 ${54 + t * 10} ${88 + t % 7 * 9}"/>`).join("")}</g><ellipse cx="203" cy="207" rx="74" ry="21" fill="#a8ad7b"/>`;
	if (e === "seahorse") return `<path d="M202 61q-25-38 15-42 26 8 30 30l31 9-7 15-31-4q-15 26 0 49 33 58-3 80-35 21-48-5-9-25 16-27 20 0 14 15" fill="none" stroke="${n}" stroke-width="23" stroke-linecap="round"/><path d="m228 99-30-17 6 44 22 13" fill="#d8bb6f" stroke="#9d8a5b" stroke-width="2"/>${Q(230, 46)}`;
	if (e === "ray") return `<path d="M200 109Q139 27 40 85l68 64 65 9q29 19 53-5l67-6 67-65q-95-53-152 29l-3-31-14 0Z" fill="${n}" stroke="#426e78" stroke-width="2"/><path d="M202 155q1 37 66 73" fill="none" stroke="#446674" stroke-width="5"/><path d="m171 135 25-18 24 16" fill="none" stroke="#acc4b7" stroke-width="4"/>${Q(182, 102)}${Q(220, 101)}${t === "541" ? Kr("#528bbc") : ""}`;
	if (e === "plankton") return `<g stroke="#e1f1d0" fill="#b7d6c5" fill-opacity=".6">${Array.from({ length: 9 }, (e, t) => `<g transform="translate(${65 + t % 3 * 120} ${52 + Math.floor(t / 3) * 75})"><ellipse rx="11" ry="23"/><path d="M0-24v-18m0 65v15m-10-25-16 18m36-18 16 18" fill="none"/><circle cy="-12" r="3" fill="#547e76"/></g>`).join("")}</g>`;
	let i = e === "shark" ? "M55 123q71-43 170-21l78 25-24 17-75 10-111-10Z" : "M104 128q25-67 118-54l69 48-15 39-82 14-65-21Z";
	return `<defs><clipPath id="${r}fish"><path d="${i}"/></clipPath><linearGradient id="${r}f" x2=".2" y2="1"><stop stop-color="${n}"/><stop offset="1" stop-color="#c7ddd0"/></linearGradient></defs><g stroke="#456f72" stroke-width="1.6" stroke-linejoin="round"><path d="M110 120 48 79l8 65-20 33 72-30" fill="${n}"/><path d="m169 110 36-65 30 67m-52 31 46 58 21-52" fill="${n}"/><path d="${i}" fill="url(#${r}f)"/><g clip-path="url(#${r}fish)">${t === "530" ? "<path d=\"m152 70-9 102m67-103-4 109m55-95-11 79\" stroke=\"#fff9df\" stroke-width=\"17\"/>" : t === "531" ? "<path d=\"M114 109q56-39 123 7l20 26-34 4q-42-57-93-11Z\" fill=\"#223a58\"/>" : t === "538" ? qr("#754f43") : t === "540" || t === "539" ? Kr("#eee5bf") : ""}</g><path d="m254 106-5 30m-6-32-6 29" stroke="#48777a" fill="none"/>${Q(274, 118)}<path d="M284 141q11-1 19-11" fill="none"/>${t === "545" ? "<path d=\"M285 126h98v8h-98Zm11-2 2-6m12 6 2-6m12 6 2-6m12 6 2-6m12 6 2-6m-54 17 2 6m12-6 2 6m12-6 2 6m12-6 2 6\" fill=\"#b9ceba\" stroke=\"#688a80\"/>" : ""}</g>`;
}
var ei = 0;
function ti(e) {
	let t = `anSponsorAnimal${++ei}`, n = Jr(!1, !1, !1, t), r;
	return e === "251" ? (n = "<rect width=\"400\" height=\"250\" fill=\"#c6e6ed\"/><path d=\"m0 173 91-85 66 71 70-107 94 100 79-24v122H0Z\" fill=\"#eaf4ef\"/><path d=\"M0 218q116-31 220-8t180-5v45H0Z\" fill=\"#99d3df\"/><path d=\"m0 219 129-13 68 25-104 19H0m243 6 66-33 91 15v23Z\" fill=\"#f8f9e9\"/>", r = Yr("bear", e, "#f1ebd6", t)) : e === "252" ? r = Yr("fox", e, "#bca16e", t) : e === "267" ? (n += "<path d=\"M0 167h400M0 192h400m20-44v62m71-62v62m71-62v62m71-62v62m71-62v62m71-62v62\" fill=\"none\" stroke=\"#bc9d68\" stroke-width=\"7\"/><path d=\"m25 210 40-19 44 23v36H25Z\" fill=\"#ae7751\"/><path d=\"m21 211 45-30 49 34\" fill=\"none\" stroke=\"#815e41\" stroke-width=\"5\"/>", r = `<g transform="translate(76 44) scale(.76)">${Yr("cat", e, "#aaa18a", t)}</g>`) : (n = Jr(!0, !1, !0, t), r = `<g stroke="#284d57" stroke-width="1.7" stroke-linejoin="round"><path d="M87 143q-54-2-77-40l4 42-13 35q44 3 83-23" fill="#263f46"/><path d="M157 116q10-43 35-79 7 40 7 69" fill="#263f46"/><path d="M76 141q29-51 134-52 87-1 140 40 34 28 3 41-88 27-204-3Z" fill="#263f46"/><path d="M125 146q83 26 130 12 18-7 14-28 37-9 63 5l25 23q-55 25-144 12l-64-10Z" fill="#f3f4df" stroke="none"/><path d="M202 154q-11 49 32 59 13-35 1-60" fill="#263f46"/><path d="M283 112q-20 3-26 18 19 5 37-9Z" fill="#f3f4df" stroke="none"/><path d="M315 151q27 5 44-1" fill="none"/>${Q(311, 135)}</g>`), `<svg xmlns="http://www.w3.org/2000/svg" class="an-natural-art" viewBox="0 0 400 250" aria-hidden="true">${n}${r}</svg>`;
}
function ni(e) {
	if (e === "428") return Z.giraffe();
	if (e === "497" || e === "511") return Z.flamingo();
	if (e === "552") return Z.turtle();
	let t = P[e], n = Ur[e];
	if (!n) throw Error(`Missing original animal illustration: ${e}`);
	let r = `anSpecies${++ei}`, i = Gr[e] ?? Wr[n] ?? "#7b9f8e", a = [
		"anemone",
		"fish",
		"plankton",
		"octopus",
		"ray",
		"shark",
		"seahorse",
		"jellyfish",
		"dugong"
	].includes(n), o = [
		"crocodile",
		"snake",
		"tortoise",
		"lizard"
	].includes(n), s = [
		"ostrich",
		"stork",
		"raptor",
		"peacock",
		"hornbill",
		"owl",
		"parrot",
		"pelican",
		"penguin"
	].includes(n), c = t.kind === "animal" && t.tags.some((e) => e === "asia" || e === "americas"), l = a || n === "seal" ? $r(n, e, i, r) : o ? Zr(n, e, i, r) : s ? Qr(n, e, i) : n === "monkey" ? Xr(e, i) : n === "kangaroo" ? d() : n === "koala" ? f() : n === "platypus" ? p() : n === "porcupine" ? m() : n === "rabbit" || n === "rodent" ? u() : Yr(n, e, i, r);
	function u() {
		return `<ellipse cx="205" cy="224" rx="100" ry="7" fill="#5b734d" opacity=".18"/><g fill="${i}" stroke="#897f5e" stroke-width="2"><path d="M99 192q-24-65 40-83 75-22 119 50l-4 48-126 9Z"/><ellipse cx="262" cy="142" rx="42" ry="36"/><path d="m143 181-13 27 43 9 7-9-25-9m81-9 21 23 44 0-2-9-29-9"/>${n === "rabbit" ? "<path d=\"m246 119-12-75q9-28 22-6l11 76m1-2 12-70q14-20 18 4l-9 71\"/><path d=\"m249 102-6-54m34 54 11-52\" stroke=\"#b08c76\" stroke-width=\"6\"/><circle cx=\"103\" cy=\"180\" r=\"18\" fill=\"#e5dcc0\"/>" : "<circle cx=\"249\" cy=\"113\" r=\"14\"/><circle cx=\"279\" cy=\"112\" r=\"12\"/><path d=\"M112 184q-70 48-90 8\" fill=\"none\" stroke-width=\"5\"/>"}<path d="m293 148 13 5-13 8Z" fill="#5f6651"/>${Q(279, 136)}<path d="m297 158 27 4m-28 0 25 10" fill="none" stroke-width="1"/></g>`;
	}
	function d() {
		return `<path d="M167 171q-53 47-134 47 73-12 104-67m42-3-21 64 80 15 4-9-54-20 24-30m-18-39 40 28 33-7" fill="${i}" stroke="#876e4c" stroke-width="4"/><path d="M140 160q-7-39 37-65l25-43 31 2-12 50-2 45-38 45Z" fill="${i}" stroke="#876e4c" stroke-width="2"/><path d="m204 60-4-41q14-3 17 35m7-1 14-32q14 3 0 37" fill="${i}" stroke="#876e4c" stroke-width="2"/><path d="M207 59q18-17 37-1l26 13-6 13-41-2Z" fill="${i}"/>${Q(241, 65)}`;
	}
	function f() {
		return `<path d="m144 250 38-230 24 2-15 228" fill="#927b52"/><g fill="${i}" stroke="#747761" stroke-width="2"><ellipse cx="204" cy="156" rx="57" ry="67"/><path d="m176 123-32 46 15 18 37-32m24 4-62 46 9 17 73-33"/><circle cx="205" cy="79" r="40"/><circle cx="166" cy="60" r="22"/><circle cx="244" cy="60" r="22"/><ellipse cx="205" cy="88" rx="13" ry="19" fill="#434b41"/>${Q(186, 78)}${Q(225, 78)}</g>`;
	}
	function p() {
		return `<path d="M135 161q-60-7-91 30 53 17 98-7" fill="#987954"/><ellipse cx="193" cy="157" rx="84" ry="45" fill="${i}"/><path d="m240 156 51-13q53 18 12 29l-58 1m-86 8-28 29 48-6m43-16 24 29 21-18" fill="#bea678" stroke="#7b8060" stroke-width="2"/>${Q(252, 143)}`;
	}
	function m() {
		return `<g stroke="#e9d8ac" stroke-width="4">${Array.from({ length: 27 }, (e, t) => `<path d="M185 156 ${80 + t * 5} ${45 + t % 5 * 7}"/>`).join("")}</g>${Yr("wombat", e, i, r)}`;
	}
	return `<svg xmlns="http://www.w3.org/2000/svg" class="an-natural-art" viewBox="0 0 400 250" aria-hidden="true">${Jr(a, c, t.kind === "animal" && t.water > 0, r)}${l}</svg>`;
}
function ri(e) {
	let t = P[e];
	if (t.kind === "animal") return ni(e);
	if (t.kind === "sponsor") {
		if ([
			"251",
			"252",
			"267",
			"277"
		].includes(e)) return ti(e);
		if (e === "208" || e === "207" || e === "273") return Z.library();
		if (e === "201" || e === "206" || e === "223" || e === "225") return Z.microscope();
		if (e === "250" || e === "245" || e === "279") return Z.aquarium();
		if (e === "226" || e === "278") return Z.overseas();
		let t = {
			205: "457",
			231: "451",
			232: "476",
			233: "499",
			234: "402",
			235: "426",
			243: "414",
			244: "554",
			247: "451",
			248: "458",
			249: "512",
			253: "435",
			258: "510",
			259: "486",
			260: "519",
			264: "464",
			275: "521"
		};
		return t[e] ? ni(t[e]) : Hr({
			202: "person",
			203: "vet",
			204: "institute",
			209: "institute",
			210: "field",
			211: "field",
			212: "field",
			213: "field",
			214: "field",
			215: "publication",
			216: "person",
			217: "construction",
			218: "publication",
			219: "field",
			220: "finance",
			221: "field",
			222: "publication",
			224: "field",
			227: "publication",
			228: "publication",
			229: "person",
			230: "person",
			236: "field",
			237: "field",
			238: "field",
			239: "field",
			240: "field",
			241: "field",
			242: "field",
			246: "cable",
			254: "institute",
			255: "playground",
			256: "garden",
			257: "institute",
			261: "person",
			262: "field",
			263: "publication",
			265: "finance",
			266: "vet",
			268: "institute",
			269: "institute",
			270: "field",
			271: "field",
			272: "construction",
			274: "garden",
			276: "garden",
			280: "construction"
		}[e] ?? "institute", e);
	}
	if (t.kind === "project") {
		let e = {
			predator: "406",
			herbivore: "428",
			primate: "454",
			reptile: "476",
			bird: "497",
			seaAnimal: "552",
			africa: "428",
			americas: "508",
			asia: "431",
			australia: "447",
			europe: "443",
			"animal-size-4": "428",
			"animal-size-2": "523"
		}, n = Object.keys(e).find((e) => t.tag.includes(e));
		return t.tag === "science" ? Z.microscope() : n ? ni(e[n]) : Z.overseas();
	}
	return e === "003" ? Z.microscope() : e === "011" ? Z.aquarium() : Z.overseas();
}
//#endregion
//#region src/games/arknova/card-rules.tsx
var ii = {
	Money: "coin",
	Appeal: "ticket",
	ConservationPoint: "shield",
	Reputation: "cap",
	XToken: "x",
	MultiplierToken: "multiplier",
	Size: "hex",
	SizeAnimal: "largeAnimal",
	Kiosk: "kiosk",
	Pavilion: "pavilion",
	ScienceIcon: "science",
	ScienceTag: "science",
	Marketing: "sponsors",
	ActionCard: "cards",
	AnimalActionCard: "paw",
	AssociationActionCard: "association",
	BuildActionCard: "build",
	BuildingActionCard: "build",
	CardsActionCard: "cards",
	SponsorsActionCard: "sponsors",
	SponsorActionCard: "sponsors",
	HerbivoreTag: "herbivore",
	SeaAnimalTag: "seaAnimal",
	PrimateTag: "primate",
	ReptileTag: "reptile",
	LargeBirdAviary: "bird"
};
function ai({ text: e }) {
	let t = u(), r = e.replace(/\b(africa|americas|asia|australia|europe|bird|herbivore|predator|primate|reptile|seaAnimal|science|water|rock)\b/gi, (e) => t(X[e.toLowerCase() === "seaanimal" ? "seaAnimal" : e.toLowerCase()]));
	return /* @__PURE__ */ b(y, { children: r.split(/(\{[A-Za-z]+(?:-[^}]+)?\})/g).map((e, t) => {
		let r = /^\{([A-Za-z]+)(?:-([^}]+))?\}$/.exec(e);
		if (!r) return /* @__PURE__ */ b(n, { children: e }, t);
		let [, i, a] = r;
		return i === "Slot" ? /* @__PURE__ */ b("b", {
			className: "an-rule-slot",
			children: a
		}, t) : /* @__PURE__ */ x("span", {
			className: "an-rule-symbol",
			children: [/* @__PURE__ */ b(J, { name: ii[i] ?? "cards" }), a && /* @__PURE__ */ b("b", { children: a })]
		}, t);
	}) });
}
//#endregion
//#region src/games/arknova/card.tsx
var oi = {
	428: "Giraffa",
	497: "Phoeniconaias minor",
	511: "Phoenicopterus roseus",
	552: "Chelonia mydas"
};
function si({ id: e }) {
	let t = (e, t) => /* @__PURE__ */ b(J, {
		name: e,
		value: t
	});
	switch (e) {
		case "209": return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("span", {
			className: "an-effect-immediate",
			children: [t("instant"), t("x")]
		}), /* @__PURE__ */ x("span", {
			className: "an-effect-end",
			children: [
				t("end"),
				"3 ",
				t("cap"),
				" : ",
				t("shield", 1)
			]
		})] });
		case "201": return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("span", {
			className: "an-effect-immediate",
			children: [t("income"), t("cards")]
		}), /* @__PURE__ */ x("span", {
			className: "an-effect-end",
			children: [
				t("end"),
				"3/6 ",
				t("science"),
				" : ",
				t("shield", "1/2")
			]
		})] });
		case "208": return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("span", {
			className: "an-effect-immediate",
			children: [
				t("instant"),
				t("science"),
				" : ",
				t("ticket", 1)
			]
		}), /* @__PURE__ */ x("span", {
			className: "an-effect-end",
			children: [
				t("end"),
				"5 ≠ ",
				/* @__PURE__ */ b("span", {
					className: "an-class-cluster",
					children: [
						"herbivore",
						"predator",
						"primate",
						"bird",
						"reptile",
						"pet"
					].map((e) => /* @__PURE__ */ b(J, { name: e }, e))
				}),
				" : ",
				t("shield", 1)
			]
		})] });
		case "250": return /* @__PURE__ */ x("span", {
			className: "an-effect-trigger",
			children: [
				t("reptile"),
				" : 2 ",
				t("cards"),
				" → ",
				t("coin", 4)
			]
		});
		case "226": return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("span", {
			className: "an-effect-immediate",
			children: [t("instant"), t("cap", 2)]
		}), /* @__PURE__ */ x("span", {
			className: "an-effect-end",
			children: [
				t("end"),
				"5 ≠ ",
				t("africa"),
				" : ",
				t("shield", 1)
			]
		})] });
		default: return null;
	}
}
function ci({ id: e, selected: t = !1, onClick: n, compact: r = !1, marine: i = !0 }) {
	let a = u(), s = P[e], c = o(() => ri(e).replace("<svg ", "<svg preserveAspectRatio=\"xMidYMid slice\" "), [e]), l = s.kind === "animal" || s.kind === "sponsor", d = a(s.descriptionKey), f = s.kind === "sponsor" && [
		"201",
		"208",
		"209",
		"226",
		"250"
	].includes(e), p = s.kind === "project" ? X[s.tag] ? s.tag : s.tag.includes("size") ? "largeAnimal" : "shield" : "shield", m = /* @__PURE__ */ x("span", {
		className: "an-card-face",
		children: [
			/* @__PURE__ */ b("span", {
				className: "an-card-picture",
				dangerouslySetInnerHTML: { __html: c }
			}),
			/* @__PURE__ */ x("span", {
				className: "an-card-cost",
				children: [s.kind === "animal" ? /* @__PURE__ */ x(y, { children: [
					/* @__PURE__ */ x("span", {
						className: "an-habitat",
						children: [
							s.standard && /* @__PURE__ */ b(J, {
								name: "hex",
								value: s.size
							}),
							" ",
							s.water > 0 && /* @__PURE__ */ b(J, {
								name: "water",
								value: s.water > 1 ? s.water : void 0
							}),
							" ",
							s.rock > 0 && /* @__PURE__ */ b(J, {
								name: "rock",
								value: s.rock > 1 ? s.rock : void 0
							})
						]
					}),
					/* @__PURE__ */ b(J, {
						name: "coin",
						value: s.price
					}),
					s.special.map((e) => /* @__PURE__ */ b(J, {
						name: e.kind === "aquarium" ? "aquarium" : e.kind === "aviary" ? "bird" : e.kind === "petting" ? "pet" : "reptileHouse",
						value: e.capacity
					}, e.kind))
				] }) : s.kind === "sponsor" ? /* @__PURE__ */ x(y, { children: [
					/* @__PURE__ */ b(J, {
						name: "strength",
						value: s.strength
					}),
					s.water > 0 && /* @__PURE__ */ b(J, {
						name: "water",
						value: s.water > 1 ? s.water : void 0
					}),
					" ",
					s.rock > 0 && /* @__PURE__ */ b(J, {
						name: "rock",
						value: s.rock > 1 ? s.rock : void 0
					})
				] }) : /* @__PURE__ */ b(J, { name: s.kind === "project" ? p : "end" }), l && s.requirements.length > 0 && /* @__PURE__ */ b("span", {
					className: "an-card-requirements",
					children: s.requirements.map((e, t) => X[e] ? /* @__PURE__ */ b(J, { name: e }, t) : e === "animalsII" || e === "sponsorsII" ? /* @__PURE__ */ b("span", {
						className: "an-requires-upgrade",
						children: "II"
					}, t) : /* @__PURE__ */ b(J, { name: e === "reputation" ? "cap" : e === "appeal" ? "ticket" : "worker" }, t))
				})]
			}),
			e === "208" && /* @__PURE__ */ x("span", {
				className: "an-card-trigger",
				children: [
					/* @__PURE__ */ b(J, { name: "anyZoo" }),
					/* @__PURE__ */ b(J, { name: "science" }),
					" : ",
					/* @__PURE__ */ b(J, {
						name: "coin",
						value: 2
					})
				]
			}),
			e === "250" && /* @__PURE__ */ x("span", {
				className: "an-card-trigger",
				children: [
					/* @__PURE__ */ b(J, { name: "worker" }),
					/* @__PURE__ */ b(J, { name: "reptile" }),
					" : 2 ",
					/* @__PURE__ */ b(J, { name: "cards" })
				]
			}),
			/* @__PURE__ */ b("span", {
				className: "an-card-tags",
				children: l && s.tags.map((e, t) => /* @__PURE__ */ b(J, {
					name: e,
					title: a(X[e])
				}, t))
			}),
			/* @__PURE__ */ x("strong", {
				className: "an-card-name",
				children: [
					/* @__PURE__ */ b("span", { children: a(s.nameKey) }),
					/* @__PURE__ */ b("small", { children: e }),
					oi[e] && /* @__PURE__ */ b("em", { children: oi[e] })
				]
			}),
			/* @__PURE__ */ x("span", {
				className: "an-card-body",
				children: [l && s.wave && /* @__PURE__ */ b("span", {
					className: "an-wave",
					children: /* @__PURE__ */ b(J, { name: "wave" })
				}), s.kind === "project" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("span", {
					className: "an-project-requirement",
					children: /* @__PURE__ */ b(ai, { text: d })
				}), /* @__PURE__ */ b("span", {
					className: "an-card-project-slots",
					children: s.slots.map((e, t) => /* @__PURE__ */ x("span", { children: [
						/* @__PURE__ */ b("b", { children: e.requirement }),
						/* @__PURE__ */ b(J, { name: p }),
						/* @__PURE__ */ b(J, {
							name: "shield",
							value: e.conservation
						}),
						e.reputation > 0 && /* @__PURE__ */ b(J, {
							name: "cap",
							value: e.reputation
						})
					] }, t))
				})] }) : s.kind === "final" ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b("span", {
					className: "an-card-rules",
					children: /* @__PURE__ */ b(ai, { text: d })
				}), /* @__PURE__ */ b("span", {
					className: "an-card-scoring",
					children: (i ? s.thresholds : s.baseThresholds).map((e, t) => /* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b("b", { children: e }), /* @__PURE__ */ b(J, {
						name: "shield",
						value: t + 1
					})] }, t))
				})] }) : /* @__PURE__ */ b("span", {
					className: "an-card-rules",
					"data-length": d.length > 160 ? "long" : "normal",
					children: /* @__PURE__ */ b(ai, { text: d })
				})]
			}),
			/* @__PURE__ */ b("span", {
				className: "an-card-rewards",
				"data-formula": f,
				children: f ? /* @__PURE__ */ b(si, { id: e }) : l ? /* @__PURE__ */ x(y, { children: [
					s.conservation > 0 && /* @__PURE__ */ b(J, {
						name: "shield",
						value: s.conservation
					}),
					" ",
					s.reputation > 0 && /* @__PURE__ */ b(J, {
						name: "cap",
						value: s.reputation
					}),
					" ",
					s.appeal > 0 && /* @__PURE__ */ b(J, {
						name: "ticket",
						value: s.appeal
					})
				] }) : null
			}),
			t && /* @__PURE__ */ b("span", {
				className: "an-card-selected",
				children: /* @__PURE__ */ b(J, { name: "check" })
			})
		]
	}), h = {
		"data-kind": s.kind,
		"data-card": e,
		"data-selected": t,
		"data-compact": r
	};
	return n ? /* @__PURE__ */ b("button", {
		className: "an-card",
		...h,
		onClick: n,
		"aria-label": a("games.arknova.inspectCard", { name: a(s.nameKey) }),
		"aria-pressed": t,
		children: m
	}) : /* @__PURE__ */ b("div", {
		className: "an-card",
		...h,
		children: m
	});
}
//#endregion
//#region src/games/arknova/action-rack.tsx
var li = {
	animals: "paw",
	build: "build",
	cards: "cards",
	association: "association",
	sponsors: "leaf"
};
function ui({ actions: e, active: t, enabled: n, onPick: r }) {
	let i = u(), o = s(null), c = s(/* @__PURE__ */ new Map());
	return a(() => {
		let e = /* @__PURE__ */ new Map(), t = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		o.current?.querySelectorAll("[data-action]").forEach((n) => {
			let r = n.dataset.action, i = n.getBoundingClientRect(), a = c.current.get(r);
			e.set(r, i), a && !t && Math.abs(a.x - i.x) > 2 && a.width === i.width && (n.getAnimations().forEach((e) => e.cancel()), n.animate([{ transform: `translateX(${a.x - i.x}px)` }, { transform: "translateX(0)" }], {
				duration: 220,
				easing: "cubic-bezier(.2,.7,.2,1)"
			}));
		}), c.current = e;
	}, [e]), /* @__PURE__ */ b("div", {
		className: "an-action-rack",
		ref: o,
		children: e.map((e, a) => /* @__PURE__ */ x("button", {
			className: "an-action-card",
			"data-action": e.kind,
			"data-upgraded": e.upgraded,
			"data-active": t === e.kind,
			disabled: !n(e.kind),
			onClick: () => r(e.kind),
			children: [
				/* @__PURE__ */ b("span", {
					className: "an-action-position",
					children: a + 1
				}),
				/* @__PURE__ */ x("span", {
					className: "an-action-level",
					children: [e.upgraded ? "II" : "I", e.variant ? ` · ${e.variant}` : ""]
				}),
				/* @__PURE__ */ b("span", {
					className: "an-action-art",
					children: /* @__PURE__ */ b(J, { name: li[e.kind] })
				}),
				/* @__PURE__ */ b("strong", { children: i(Qt[e.kind]) }),
				/* @__PURE__ */ x("span", {
					className: "an-action-tokens",
					children: [
						e.multiplier > 0 && /* @__PURE__ */ b(J, { name: "multiplier" }),
						e.venom && /* @__PURE__ */ b("span", {
							title: i("games.arknova.venom"),
							children: "◆"
						}),
						e.constriction && /* @__PURE__ */ b("span", {
							title: i("games.arknova.constriction"),
							children: "−2"
						})
					]
				})
			]
		}, e.kind))
	});
}
//#endregion
//#region src/games/arknova/view-player.tsx
var di = [
	{
		id: "zoo",
		key: "games.arknova.zoo"
	},
	{
		id: "market",
		key: "games.arknova.market"
	},
	{
		id: "projects",
		key: "games.arknova.association"
	},
	{
		id: "hand",
		key: "games.arknova.hand"
	},
	{
		id: "played",
		key: "games.arknova.played"
	}
];
function fi({ kind: e }) {
	let t = e === "unique" ? [[0, 0]] : Pe[e];
	return /* @__PURE__ */ b("svg", {
		className: "an-building-shape",
		viewBox: "-12 -30 100 110",
		"aria-hidden": "true",
		children: t.map(([t, n], r) => {
			let i = t * 24, a = (n + t / 2) * 27.7;
			return /* @__PURE__ */ b("polygon", {
				points: Array.from({ length: 6 }, (e, t) => `${i + 15 * Math.cos(Math.PI * t / 3)},${a + 15 * Math.sin(Math.PI * t / 3)}`).join(" "),
				fill: e.startsWith("aquarium") ? "#48b9cb" : "#dfba61",
				stroke: "#7f774b",
				strokeWidth: "1.2"
			}, r);
		})
	});
}
function pi(e) {
	d();
	let t = u(), n = l((e) => e.locale), r = e.public, i = e.private, [a, o] = c("zoo"), [s, p] = c(e.myRid), [h, g] = c(null), [_, ne] = c(null), [re, oe] = c({
		key: "",
		ids: []
	}), [se, ce] = c(null), S = r.players.find((t) => t.rid === e.myRid), C = r.players.find((e) => e.rid === s) ?? S ?? r.players[0], w = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? ae(r, n) : t;
	}, le = (t) => v[e.members.find((e) => e.rid === t)?.colorIndex ?? 0]?.hex ?? v[0].hex, T = r.phase === "done", E = T ? [] : i?.choices ?? [], D = E.some((e) => e.key === "games.arknova.placeHere"), ue = E.length > 0, O = se?.revision === r.revision ? E.find((e) => e.id === se.id) : E.find((e) => e.key === "games.arknova.placeHere"), de = [...new Map(E.flatMap((e) => e.key === "games.arknova.placeHere" ? e.cells ?? [] : []).map((e) => [L(e), e])).values()], fe = `${r.phase}:${i?.draftRound}:${S?.ready}`, k = re.key === fe ? re.ids : [], pe = i?.draftKept ?? [], me = k.length === 2 && new Set(k.map((e) => e.split(":")[0])).size === 2 && (pe.length !== 4 || k.includes(pe[3])), he = (e) => oe({
		key: fe,
		ids: k.includes(e) ? k.filter((t) => t !== e) : [...k, e]
	}), ge = (t) => {
		T || (e.send({
			type: "choose",
			revision: r.revision,
			id: t.id
		}), ne(null));
	}, _e = [
		"map",
		"draft",
		"setup"
	].includes(r.phase), ve = !r.activity && r.phase === "play" && ue && !D && i?.prompt === "games.arknova.begin", ye = (_?.action ? E.filter((e) => e.action === _.action) : E).filter((e) => e.key !== "games.arknova.placeHere"), be = _ !== null && _.revision === r.revision && !T, A = _e || r.actor === e.myRid ? i?.prompt : void 0, j = T ? t("games.arknova.phaseDone") : S?.ready && _e ? t("games.arknova.wait", { name: r.players.filter((e) => !e.ready).map((e) => w(e.rid)).join(", ") }) : A ? t(A) : t("games.arknova.wait", { name: w(r.actor ?? r.turn) }), M = (e) => {
		let t = E.filter((t) => t.key === "games.arknova.placeHere" && t.cells?.some((t) => L(t) === L(e)));
		if (!t.length) return;
		let n = t.findIndex((e) => e.id === O?.id);
		ce({
			revision: r.revision,
			id: t[(n + 1) % t.length].id
		});
	}, N = () => {
		let e = O?.cells?.[0], t = E.filter((t) => t.key === "games.arknova.placeHere" && (!e || t.cells?.some((t) => L(t) === L(e))));
		if (t.length) {
			let e = t.findIndex((e) => e.id === O?.id);
			ce({
				revision: r.revision,
				id: t[(e + 1) % t.length].id
			});
		}
	}, xe = (e) => ne({
		revision: r.revision,
		action: e
	}), I = h ? P[h] : null, Se = (e) => /* @__PURE__ */ x("button", {
		className: "an-choice",
		onClick: () => ge(e),
		children: [
			e.card && /* @__PURE__ */ b(ci, {
				id: e.card,
				marine: r.config.marine
			}),
			" ",
			e.building && /* @__PURE__ */ b(fi, { kind: e.building }),
			/* @__PURE__ */ b("strong", { children: vr(e, t, w) }),
			e.card && /* @__PURE__ */ b("span", { children: t(P[e.card].nameKey) }),
			e.params?.x !== void 0 && /* @__PURE__ */ x("span", { children: [
				/* @__PURE__ */ b(J, { name: "x" }),
				" +",
				e.params.x,
				Number(e.params.m) > 0 ? ` · ×${Number(e.params.m) + 1}` : ""
			] }),
			e.value !== void 0 && e.building && /* @__PURE__ */ b(Y, {
				name: "coin",
				value: e.value
			})
		]
	}, e.id), Ce = /* @__PURE__ */ x("section", {
		className: "an-market",
		children: [/* @__PURE__ */ x("div", {
			className: "an-section-title",
			children: [/* @__PURE__ */ x("strong", { children: [/* @__PURE__ */ b(J, { name: "cards" }), t("games.arknova.market")] }), /* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b(Y, {
				name: "cards",
				value: r.deckCount
			}), /* @__PURE__ */ b("span", {
				className: "an-discard",
				children: t("games.arknova.discardPile", { n: r.discardCount })
			})] })]
		}), /* @__PURE__ */ b("div", {
			className: "an-market-grid",
			children: r.market.map((e, t) => /* @__PURE__ */ x("div", {
				className: "an-market-slot",
				"data-range": t < De(S?.reputation ?? 1),
				children: [/* @__PURE__ */ x("span", {
					className: "an-slot-number",
					children: [t + 1, e && r.marks[e] && /* @__PURE__ */ b("span", {
						title: w(r.marks[e]),
						children: "●"
					})]
				}), e ? /* @__PURE__ */ b(ci, {
					marine: r.config.marine,
					id: e,
					onClick: () => g(e)
				}) : /* @__PURE__ */ b("div", { className: "an-card-back" })]
			}, t))
		})]
	}), we = /* @__PURE__ */ x("section", {
		className: "an-association",
		children: [
			/* @__PURE__ */ x("div", {
				className: "an-section-title",
				children: [/* @__PURE__ */ x("strong", { children: [/* @__PURE__ */ b(J, { name: "association" }), t("games.arknova.association")] }), /* @__PURE__ */ b(Y, {
					name: "worker",
					value: `${C.workers - Object.values(C.workersUsed).reduce((e, t) => e + t, 0)}/${C.workers}`
				})]
			}),
			/* @__PURE__ */ x("div", {
				className: "an-supply",
				children: [/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("span", { children: t("games.arknova.partnerZoos") }), /* @__PURE__ */ b("div", { children: r.partnerSupply.map((e) => /* @__PURE__ */ b("span", {
					className: "an-supply-token",
					children: /* @__PURE__ */ b(J, {
						name: e,
						title: t(X[e])
					})
				}, e)) })] }), /* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("span", { children: t("games.arknova.universities") }), /* @__PURE__ */ x("div", { children: [r.universitySupply.filter((e) => e !== "animal").map((e) => /* @__PURE__ */ x("span", {
					className: "an-university",
					title: t(e === "hand" ? "games.arknova.universityHand" : e === "science2" ? "games.arknova.universityScience" : "games.arknova.universityReputation"),
					children: [/* @__PURE__ */ b(J, { name: "science" }), e === "science2" ? /* @__PURE__ */ b(J, { name: "science" }) : e === "hand" ? /* @__PURE__ */ x("span", { children: ["5 ", /* @__PURE__ */ b(J, { name: "cards" })] }) : /* @__PURE__ */ b(Y, {
						name: "cap",
						value: 2
					})]
				}, e)), (r.universitySupply.includes("animal") ? r.marineUniversities : []).map((e) => /* @__PURE__ */ x("span", {
					className: "an-university",
					children: [/* @__PURE__ */ b(J, { name: "science" }), /* @__PURE__ */ b(J, {
						name: e.replace("marine:", ""),
						title: t(X[e.replace("marine:", "")] ?? "games.arknova.universities")
					})]
				}, e))] })] })]
			}),
			/* @__PURE__ */ b("div", {
				className: "an-project-list",
				children: r.projects.map((e) => {
					let n = P[e.card];
					return n.kind === "project" ? /* @__PURE__ */ x("button", {
						className: "an-project",
						onClick: () => g(e.card),
						children: [/* @__PURE__ */ x("strong", { children: [/* @__PURE__ */ b(J, { name: X[n.tag] ? n.tag : "shield" }), t(n.nameKey)] }), /* @__PURE__ */ b("span", {
							className: "an-project-spaces",
							children: n.slots.map((t, n) => /* @__PURE__ */ b("span", {
								"data-occupied": !!e.slots[n],
								children: e.slots[n] === "blocked" ? "×" : e.slots[n] ? /* @__PURE__ */ x("span", {
									style: { color: le(e.slots[n]) },
									children: ["● ", w(e.slots[n])]
								}) : /* @__PURE__ */ x(y, { children: [
									/* @__PURE__ */ b("b", { children: t.requirement }),
									/* @__PURE__ */ b(Y, {
										name: "shield",
										value: t.conservation
									}),
									t.reputation > 0 && /* @__PURE__ */ b(Y, {
										name: "cap",
										value: t.reputation
									})
								] })
							}, n))
						})]
					}, e.card) : null;
				})
			})
		]
	}), Te = /* @__PURE__ */ x(y, { children: [
		/* @__PURE__ */ b("div", {
			className: "an-cards-grid",
			children: i?.hand.map((e) => /* @__PURE__ */ b(ci, {
				marine: r.config.marine,
				id: e,
				onClick: () => g(e)
			}, e))
		}),
		!i?.hand.length && /* @__PURE__ */ b("p", {
			className: "an-empty",
			children: t("games.arknova.emptyHand")
		}),
		/* @__PURE__ */ b("div", {
			className: "an-section-title",
			children: /* @__PURE__ */ b("strong", { children: t("games.arknova.finals") })
		}),
		/* @__PURE__ */ b("div", {
			className: "an-cards-grid",
			children: i?.finals.map((e) => /* @__PURE__ */ b(ci, {
				marine: r.config.marine,
				id: e,
				onClick: () => g(e)
			}, e))
		})
	] }), Ee = /* @__PURE__ */ x("div", {
		className: "an-dock",
		children: [/* @__PURE__ */ x("section", {
			className: "an-action-area",
			children: [
				/* @__PURE__ */ x("div", {
					className: "an-dock-heading",
					children: [/* @__PURE__ */ b("strong", {
						"aria-live": "polite",
						children: j
					}), D ? /* @__PURE__ */ x("span", { children: [O?.building ? t($t[O.building]) : "", /* @__PURE__ */ b(Y, {
						name: "coin",
						value: O?.value ?? 0
					})] }) : r.activity && /* @__PURE__ */ b("span", { children: t("games.arknova.strength", { n: r.activity.strength }) })]
				}),
				/* @__PURE__ */ b(ui, {
					actions: S?.actions ?? C.actions,
					active: r.activity?.rid === e.myRid ? r.activity.action : void 0,
					enabled: (e) => ve && E.some((t) => t.action === e),
					onPick: (e) => xe(e)
				}),
				/* @__PURE__ */ b("div", {
					className: "an-control-row",
					children: D ? /* @__PURE__ */ x(y, { children: [
						/* @__PURE__ */ x("button", {
							className: "an-button",
							onClick: N,
							children: [/* @__PURE__ */ b(te, { size: 18 }), t("games.arknova.rotate")]
						}),
						/* @__PURE__ */ b(Y, {
							name: "coin",
							value: O?.value ?? 0
						}),
						/* @__PURE__ */ x("button", {
							className: "an-button an-primary",
							disabled: !O,
							onClick: () => O && ge(O),
							children: [/* @__PURE__ */ b(m, { size: 18 }), t("games.arknova.confirm")]
						}),
						E.some((e) => e.key === "games.arknova.skip") && /* @__PURE__ */ b("button", {
							className: "an-button",
							onClick: () => ge(E.find((e) => e.key === "games.arknova.skip")),
							children: t("games.arknova.skip")
						})
					] }) : _e ? /* @__PURE__ */ x(y, { children: [
						/* @__PURE__ */ b("span", { children: k.length ? t("games.arknova.selected", { n: k.length }) : j }),
						r.phase === "setup" && /* @__PURE__ */ b("button", {
							className: "an-button an-primary",
							disabled: k.length !== 4 || S?.ready,
							onClick: () => e.send({
								type: "hand",
								cards: k
							}),
							children: t("games.arknova.confirm")
						}),
						r.phase === "draft" && i?.draftRound === 2 && /* @__PURE__ */ b("button", {
							className: "an-button an-primary",
							disabled: !me || S?.ready,
							onClick: () => e.send({
								type: "variants",
								cards: k
							}),
							children: t("games.arknova.confirm")
						})
					] }) : ve ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ x("button", {
						className: "an-button",
						onClick: () => o("hand"),
						children: [
							t("games.arknova.hand"),
							" ",
							i?.hand.length ?? 0
						]
					}), /* @__PURE__ */ b("button", {
						className: "an-button an-primary",
						onClick: () => xe(),
						children: t("games.arknova.choose")
					})] }) : T ? /* @__PURE__ */ b("span", { children: t("games.arknova.reviewBoard") }) : /* @__PURE__ */ x(y, { children: [E.length === 1 && !E[0].card ? /* @__PURE__ */ b("button", {
						className: "an-button an-primary",
						onClick: () => ge(E[0]),
						children: vr(E[0], t, w)
					}) : /* @__PURE__ */ b("button", {
						className: "an-button an-primary",
						disabled: !ue,
						onClick: () => xe(),
						children: ue ? t("games.arknova.choose") : j
					}), /* @__PURE__ */ x("button", {
						className: "an-button",
						onClick: () => o("hand"),
						children: [
							t("games.arknova.hand"),
							" ",
							i?.hand.length ?? 0
						]
					})] })
				})
			]
		}), /* @__PURE__ */ x("section", {
			className: "an-hand-dock",
			children: [/* @__PURE__ */ x("div", {
				className: "an-dock-heading",
				children: [/* @__PURE__ */ x("strong", { children: [
					t("games.arknova.hand"),
					" ",
					/* @__PURE__ */ b("b", { children: i?.hand.length ?? 0 })
				] }), /* @__PURE__ */ b("button", {
					onClick: () => o("hand"),
					children: t("games.arknova.inspect")
				})]
			}), /* @__PURE__ */ b("div", {
				className: "an-hand-fan",
				children: i?.hand.map((e) => /* @__PURE__ */ b(ci, {
					marine: r.config.marine,
					id: e,
					onClick: () => g(e)
				}, e))
			})]
		})]
	});
	return /* @__PURE__ */ x("div", {
		className: "an-screen",
		children: [
			/* @__PURE__ */ b(ie, {
				adaptive: !0,
				scroll: !1,
				actionsHeight: "an-actions-height",
				actions: Ee,
				banner: /* @__PURE__ */ x("div", {
					className: "an-banner",
					children: [/* @__PURE__ */ x("div", {
						className: "an-topbar",
						children: [/* @__PURE__ */ x("div", {
							className: "an-brand",
							children: [/* @__PURE__ */ b(J, { name: "leaf" }), /* @__PURE__ */ x("span", { children: [t("games.arknova.name"), /* @__PURE__ */ b("small", { children: "ARK NOVA" })] })]
						}), /* @__PURE__ */ b("div", {
							className: "an-player-strip",
							children: r.players.map((n) => /* @__PURE__ */ x("button", {
								className: "an-player",
								style: { "--an-player-color": le(n.rid) },
								"data-current": !T && n.rid === r.turn,
								"data-viewed": n.rid === C.rid,
								"aria-pressed": n.rid === C.rid,
								onClick: () => {
									p(n.rid), o("zoo");
								},
								children: [
									/* @__PURE__ */ x("strong", { children: [
										w(n.rid),
										" ",
										n.rid === e.myRid && /* @__PURE__ */ b("small", { children: t("lobby.you") })
									] }),
									/* @__PURE__ */ x("span", {
										className: "an-player-scores",
										children: [/* @__PURE__ */ b(Y, {
											name: "ticket",
											value: n.appeal
										}), /* @__PURE__ */ b(Y, {
											name: "shield",
											value: n.conservation
										})]
									}),
									/* @__PURE__ */ x("span", {
										className: "an-player-resources",
										children: [
											/* @__PURE__ */ b(Y, {
												name: "coin",
												value: n.money
											}),
											/* @__PURE__ */ b(Y, {
												name: "cap",
												value: n.reputation
											}),
											/* @__PURE__ */ b(Y, {
												name: "x",
												value: n.x
											})
										]
									})
								]
							}, n.rid))
						})]
					}), /* @__PURE__ */ x("div", {
						className: "an-meta",
						children: [
							/* @__PURE__ */ x("span", {
								className: "an-round",
								children: [T ? t("games.arknova.phaseDone") : t("games.arknova.turn", { n: r.turnNumber }), !T && r.finalTurns !== null && /* @__PURE__ */ b("b", { children: t("games.arknova.lastTurns", { n: r.finalTurns }) })]
							}),
							/* @__PURE__ */ x("div", {
								className: "an-break",
								children: [
									/* @__PURE__ */ b("span", { children: t("games.arknova.phaseBreak") }),
									/* @__PURE__ */ b("div", {
										className: "an-break-meter",
										children: /* @__PURE__ */ b("i", { style: { width: `${Math.min(100, 100 * r.breakProgress / r.breakLength)}%` } })
									}),
									/* @__PURE__ */ x("b", { children: [
										r.breakProgress,
										" / ",
										r.breakLength
									] })
								]
							}),
							/* @__PURE__ */ x("span", {
								className: "an-self-resources",
								children: [
									/* @__PURE__ */ b(Y, {
										name: "coin",
										value: S?.money ?? 0
									}),
									/* @__PURE__ */ b(Y, {
										name: "cap",
										value: S?.reputation ?? 1
									}),
									/* @__PURE__ */ b(Y, {
										name: "x",
										value: S?.x ?? 0
									}),
									/* @__PURE__ */ b(Y, {
										name: "worker",
										value: S ? S.workers - Object.values(S.workersUsed).reduce((e, t) => e + t, 0) : 0
									})
								]
							})
						]
					})]
				}),
				children: /* @__PURE__ */ x("div", {
					className: "an-table",
					children: [/* @__PURE__ */ b("nav", {
						className: "an-tabs",
						"aria-label": t("games.arknova.zoo"),
						children: di.map((e) => /* @__PURE__ */ x("button", {
							"aria-pressed": (D ? "zoo" : a) === e.id,
							"data-active": (D ? "zoo" : a) === e.id,
							onClick: () => o(e.id),
							disabled: D && e.id !== "zoo",
							children: [t(e.key), e.id === "hand" ? ` ${i?.hand.length ?? 0}` : ""]
						}, e.id))
					}), /* @__PURE__ */ b("div", {
						className: "an-layout",
						"data-tab": D ? "zoo" : a,
						"data-setup": _e,
						children: _e ? /* @__PURE__ */ x("div", {
							className: "an-setup",
							"data-phase": r.phase,
							children: [
								r.phase === "map" && i?.maps.map((n) => /* @__PURE__ */ x("button", {
									className: "an-map-choice",
									disabled: S?.ready,
									onClick: () => e.send({
										type: "map",
										map: n
									}),
									children: [
										/* @__PURE__ */ b("strong", { children: t(F[n].nameKey) }),
										/* @__PURE__ */ b(dr, { p: {
											...C,
											map: n,
											buildings: []
										} }),
										/* @__PURE__ */ b("p", { children: t(F[n].descriptionKey) })
									]
								}, n)),
								r.phase === "draft" && (i?.draftRound === 2 ? i.draftKept : i?.draft ?? []).map((n) => {
									let [r, a] = n.split(":");
									return /* @__PURE__ */ x("button", {
										className: "an-variant",
										"data-selected": k.includes(n) || i?.draftSelected === n,
										disabled: S?.ready || i?.draftRound !== 2 && !!i?.draftSelected,
										onClick: () => i?.draftRound === 2 ? he(n) : e.send({
											type: "draft",
											card: n
										}),
										children: [
											/* @__PURE__ */ b("span", {
												className: "an-variant-art",
												children: /* @__PURE__ */ b(J, { name: li[r] })
											}),
											/* @__PURE__ */ x("strong", { children: [
												t(Qt[r]),
												" · ",
												a
											] }),
											/* @__PURE__ */ b("p", { children: t(mi[n]) }),
											(k.includes(n) || i?.draftSelected === n) && /* @__PURE__ */ b(m, { size: 22 })
										]
									}, n);
								}),
								r.phase === "setup" && i?.hand.map((e) => /* @__PURE__ */ x("div", {
									className: "an-setup-card",
									children: [/* @__PURE__ */ b(ci, {
										marine: r.config.marine,
										id: e,
										selected: k.includes(e),
										onClick: () => !S?.ready && he(e)
									}), /* @__PURE__ */ x("button", {
										className: "an-inspect-button",
										onClick: () => g(e),
										children: [/* @__PURE__ */ b(ee, { size: 17 }), t("games.arknova.inspect")]
									})]
								}, e))
							]
						}) : /* @__PURE__ */ x(y, { children: [
							/* @__PURE__ */ x("section", {
								className: "an-board-pane",
								children: [
									/* @__PURE__ */ x("div", {
										className: "an-section-title",
										children: [/* @__PURE__ */ x("strong", { children: [
											/* @__PURE__ */ b("span", {
												className: "an-map-label",
												children: (D ? S ?? C : C).map
											}),
											w(D ? e.myRid : C.rid),
											" · ",
											t(F[(D ? S ?? C : C).map].nameKey)
										] }), /* @__PURE__ */ x("button", {
											onClick: () => o("hand"),
											children: [
												t("games.arknova.hand"),
												" ",
												i?.hand.length ?? 0
											]
										})]
									}),
									/* @__PURE__ */ x("div", {
										className: "an-board-scene",
										children: [
											/* @__PURE__ */ x("aside", {
												className: "an-map-rail an-reward-rail",
												children: [/* @__PURE__ */ b("strong", { children: t("games.arknova.zooRewards") }), F[(D ? S ?? C : C).map].tokens.map((e, n) => /* @__PURE__ */ x("div", {
													"data-taken": (D ? S ?? C : C).bonuses.includes(n),
													children: [
														/* @__PURE__ */ b("b", { children: n + 1 }),
														/* @__PURE__ */ b("span", { children: e.effects.map((e) => _r(e, t)).join(" · ") }),
														(D ? S ?? C : C).bonuses.includes(n) && /* @__PURE__ */ b(m, { size: 15 })
													]
												}, n))]
											}),
											/* @__PURE__ */ b(fr, {
												viewKey: D ? e.myRid : C.rid,
												children: /* @__PURE__ */ b(dr, {
													p: D ? S ?? C : C,
													preview: D ? O?.cells ?? [] : [],
													legalCells: D ? de : [],
													onCell: D ? M : void 0
												})
											}),
											/* @__PURE__ */ x("aside", {
												className: "an-map-rail an-collection-rail",
												children: [
													/* @__PURE__ */ b("strong", { children: t("games.arknova.collection") }),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("b", { children: C.animals.length }), /* @__PURE__ */ b("span", { children: t("games.arknova.animals") })] }),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("b", { children: C.sponsors.length }), /* @__PURE__ */ b("span", { children: t("games.arknova.sponsors") })] }),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("b", { children: C.partners.length }), /* @__PURE__ */ b("span", { children: t("games.arknova.partnerZoos") })] }),
													/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("b", { children: C.universities.length }), /* @__PURE__ */ b("span", { children: t("games.arknova.universities") })] })
												]
											})
										]
									}),
									/* @__PURE__ */ x("div", {
										className: "an-zoo-details",
										children: [
											/* @__PURE__ */ x("span", { children: [C.partners.map((e, n) => /* @__PURE__ */ b(J, {
												name: e,
												title: t(X[e])
											}, n)), C.universities.length > 0 && /* @__PURE__ */ b(Y, {
												name: "science",
												value: C.universities.length
											})] }),
											/* @__PURE__ */ b("button", {
												className: "an-market-return",
												onClick: () => o("zoo"),
												children: t("games.arknova.market")
											}),
											/* @__PURE__ */ x("button", {
												onClick: () => o("played"),
												children: [
													t("games.arknova.played"),
													" ",
													C.animals.length + C.sponsors.length
												]
											}),
											/* @__PURE__ */ b("button", {
												onClick: () => xe(),
												disabled: !ue || T,
												children: t("games.arknova.choose")
											})
										]
									})
								]
							}),
							/* @__PURE__ */ x("aside", {
								className: "an-public-pane",
								children: [Ce, we]
							}),
							/* @__PURE__ */ x("section", {
								className: "an-card-pane an-hand-pane",
								children: [/* @__PURE__ */ x("div", {
									className: "an-section-title",
									children: [/* @__PURE__ */ b("strong", { children: t("games.arknova.hand") }), /* @__PURE__ */ b("span", { children: i?.hand.length ?? 0 })]
								}), Te]
							}),
							/* @__PURE__ */ x("section", {
								className: "an-card-pane an-played-pane",
								children: [/* @__PURE__ */ b("div", {
									className: "an-section-title",
									children: /* @__PURE__ */ x("strong", { children: [
										w(C.rid),
										" · ",
										t("games.arknova.played")
									] })
								}), /* @__PURE__ */ b("div", {
									className: "an-cards-grid",
									children: [
										...C.animals,
										...C.sponsors,
										...T ? C.finals : []
									].map((e) => /* @__PURE__ */ b(ci, {
										marine: r.config.marine,
										id: e,
										onClick: () => g(e)
									}, e))
								})]
							})
						] })
					})]
				})
			}),
			/* @__PURE__ */ b(f, {
				open: be,
				onClose: () => ne(null),
				label: j,
				title: _?.action ? t(Qt[_.action]) : j,
				children: /* @__PURE__ */ b("div", {
					className: "an-sheet",
					children: /* @__PURE__ */ b("div", {
						className: "an-choice-list",
						children: ye.map(Se)
					})
				})
			}),
			/* @__PURE__ */ b(f, {
				open: !!h,
				onClose: () => g(null),
				label: t("games.arknova.inspect"),
				title: I ? t(I.nameKey) : "",
				children: h && I && /* @__PURE__ */ x("div", {
					className: "an-inspection",
					children: [/* @__PURE__ */ b(ci, {
						marine: r.config.marine,
						id: h
					}), /* @__PURE__ */ x("div", {
						className: "an-inspection-rules",
						children: [
							(I.kind === "animal" || I.kind === "sponsor") && I.requirements.length > 0 && /* @__PURE__ */ x("p", { children: [/* @__PURE__ */ x("strong", { children: [t("games.arknova.conditions"), " : "] }), I.requirements.map((e, n) => /* @__PURE__ */ x("span", { children: [" ", X[e] ? /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(J, { name: e }), t(X[e])] }) : e === "animalsII" ? `${t("games.arknova.animals")} II` : e === "sponsorsII" ? `${t("games.arknova.sponsors")} II` : e === "reputation" ? t("games.arknova.reputation") : e === "appeal" ? `${t("games.arknova.appeal")} ≤25` : t(e === "Partner Zoo" ? "games.arknova.takePartner" : "games.arknova.takeUniversity")] }, n))] }),
							/* @__PURE__ */ b("p", { children: /* @__PURE__ */ b(ai, { text: t(I.descriptionKey) }) }),
							I.kind === "animal" && /* @__PURE__ */ x("p", { children: [I.standard && /* @__PURE__ */ b("span", { children: /* @__PURE__ */ b(J, {
								name: "hex",
								value: I.size
							}) }), I.special.map((e) => /* @__PURE__ */ x("span", { children: [
								t(e.kind === "aquarium" ? "games.arknova.aquarium" : $t[e.kind]),
								" ",
								e.capacity,
								" "
							] }, e.kind))] }),
							/* @__PURE__ */ b("div", {
								className: "an-choice-list",
								children: E.filter((e) => e.card === h).map((e) => /* @__PURE__ */ b("button", {
									className: "an-choice",
									onClick: () => {
										ge(e), g(null);
									},
									children: vr(e, t, w)
								}, e.id))
							})
						]
					})]
				})
			})
		]
	});
}
var mi = {
	"animals:1": "games.arknova.variants.animals1",
	"animals:2": "games.arknova.variants.animals2",
	"animals:3": "games.arknova.variants.animals3",
	"animals:4": "games.arknova.variants.animals4",
	"build:1": "games.arknova.variants.build1",
	"build:2": "games.arknova.variants.build2",
	"build:3": "games.arknova.variants.build3",
	"build:4": "games.arknova.variants.build4",
	"cards:1": "games.arknova.variants.cards1",
	"cards:2": "games.arknova.variants.cards2",
	"cards:3": "games.arknova.variants.cards3",
	"cards:4": "games.arknova.variants.cards4",
	"association:1": "games.arknova.variants.association1",
	"association:2": "games.arknova.variants.association2",
	"association:3": "games.arknova.variants.association3",
	"association:4": "games.arknova.variants.association4",
	"sponsors:1": "games.arknova.variants.sponsors1",
	"sponsors:2": "games.arknova.variants.sponsors2",
	"sponsors:3": "games.arknova.variants.sponsors3",
	"sponsors:4": "games.arknova.variants.sponsors4"
}, hi = {
	animal: 1,
	sponsor: 1,
	project: 1,
	acquire: 1,
	build: 1,
	money: 1,
	engine: 1,
	final: 1,
	x: 1.25
}, gi = (e, t, n) => Math.max(t, Math.min(n, e)), _i = (e) => e.size <= 2 || e.tags.includes("pet"), $ = (e, t = 0) => Math.max(t, ...e);
function vi(e) {
	let t = {}, n = (e, n = 1) => {
		t[e] = (t[e] ?? 0) + n;
	};
	for (let t of [...e.animals, ...e.sponsors]) {
		let e = P[t];
		(e.kind === "animal" || e.kind === "sponsor") && (e.tags.forEach((e) => n(e)), t !== "279" && !e.tags.includes("water") && n("water", e.water), e.tags.includes("rock") || n("rock", e.rock));
	}
	e.partners.forEach((e) => n(e));
	for (let t of e.universities) t === "science2" && n("science", 2), (t === "science_rep" || t.startsWith("animal:")) && n("science"), t.startsWith("animal:") && n(t.slice(7));
	e.extraTags.forEach((e) => n(e));
	for (let t of e.buildings) (t.kind === "aquariumSmall" || t.kind === "aquariumLarge") && n("water");
	return t;
}
function yi(e, t) {
	if (!t.kind.startsWith("standard")) return t.kind === "petting" ? 3 : t.kind === "aquariumSmall" || t.card === "279" ? 2 : 5;
	let n = new Set(R(t.cells).map(L)), r = e.map === "2" && (F[e.map].sites.outdoor_area ?? []).some((e) => n.has(L(e))) ? 2 : 0;
	return Number(t.kind.slice(-1)) + t.extra + r + Number(e.sponsors.includes("272") && t.kind === "standard3" && t.cells.some((t) => Re(F[e.map], t))) * 2;
}
function bi(e, t) {
	let n = (n) => e.sponsors.includes("219") || z(F[e.map], e.buildings, n.cells, "water") >= t.water && z(F[e.map], e.buildings, n.cells, "rock") >= t.rock;
	return t.standard && e.buildings.some((r) => r.kind.startsWith("standard") && !r.occupied && yi(e, r) >= t.size && n(r)) || t.abilities.some((e) => e.ability === "FLOCK_ANIMAL") && e.animals.some((e) => {
		let n = P[e];
		return n.kind === "animal" && n.tags.includes("herbivore") && n.size >= t.size;
	}) ? !0 : t.special.some((t) => {
		let r = e.buildings.filter((e) => (t.kind === "aquarium" ? e.kind === "aquariumSmall" || e.kind === "aquariumLarge" || e.card === "279" : e.kind === t.kind) && n(e));
		return t.kind === "aquarium" ? r.length > 0 && r.reduce((t, n) => t + yi(e, n) - n.used, 0) >= t.capacity : r.some((n) => yi(e, n) - n.used >= t.capacity);
	});
}
var xi = class {
	pub;
	priv;
	w;
	p;
	tags;
	future;
	cash;
	cp;
	free;
	values = /* @__PURE__ */ new Map();
	constructor(e, t, n, r) {
		this.pub = e, this.priv = t, this.w = r, this.p = e.players.find((e) => e.rid === n), this.tags = vi(this.p);
		let i = Math.max(...e.players.map((e) => Ee(e.appeal, e.conservation)));
		this.future = e.finalTurns === null ? gi(-i / 24, .2, 3.5) * r.engine : 0, this.cash = (e.finalTurns === null ? this.p.money < 12 ? .65 : this.p.money < 25 ? .4 : this.p.money < 45 ? .19 : .06 : .025) * r.money, this.cp = Te(this.p.conservation) - Te(this.p.conservation + 1), this.free = this.p.workers - Object.values(this.p.workersUsed).reduce((e, t) => e + t, 0);
	}
	upgraded(e) {
		return this.p.actions.some((t) => t.kind === e && t.upgraded);
	}
	price(e, t = 0) {
		let n = e.price - e.tags.reduce((e, t) => e + this.p.partners.filter((e) => e === t).length * 3, 0);
		return _i(e) && this.p.sponsors.includes("229") && (n -= 3), e.size >= 4 && this.p.sponsors.includes("230") && (n -= 4), this.p.actions.some((e) => e.kind === "animals" && e.variant === 3 && !e.upgraded) && (n -= 2), Math.max(0, n) + t;
	}
	missing(e) {
		let t = {};
		for (let n of e.requirements) t[n] = (t[n] ?? 0) + 1;
		let n = 0;
		for (let [r, i] of Object.entries(t)) {
			let t = this.tags[r] ?? 0;
			r === "Partner Zoo" && (t = e.kind === "animal" ? this.p.partners.filter((t) => e.tags.includes(t)).length : this.p.partners.length), r.toLowerCase() === "university" && (t = this.p.universities.length), (r === "animalsII" || r === "sponsorsII") && (t = Number(this.upgraded(r === "animalsII" ? "animals" : "sponsors"))), (r === "reputation" || r === "reputation_3") && (t = Number(this.p.reputation >= ([
				"227",
				"263",
				"275",
				"278"
			].includes(e.id) ? 6 : 3))), r === "appeal" && (t = Number(this.p.appeal <= 25)), r === "kiosk" && (t = this.p.buildings.filter((e) => e.kind === "kiosk").length), n += Math.max(0, i - t);
		}
		return n;
	}
	count(e, t) {
		let n = vi(e);
		return t === "all-animals" ? E.filter((e) => (this.pub.config.marine || e !== "seaAnimal") && (n[e] ?? 0) > 0).length : t === "all-continents" ? T.filter((e) => (n[e] ?? 0) > 0).length : t === "animal-size-2" || t === "animal-size-4" ? e.animals.filter((e) => {
			let n = P[e];
			return n.kind === "animal" && (t === "animal-size-2" ? _i(n) : n.size >= 4);
		}).length : n[t] ?? 0;
	}
	finalValue(e, t = this.p) {
		let n = P[e];
		if (n.kind !== "final") return 0;
		let r = vi(t), i = F[t.map], a = 0;
		switch (e) {
			case "001":
				a = this.count(t, "animal-size-4");
				break;
			case "002":
				a = this.count(t, "animal-size-2");
				break;
			case "003":
				a = r.science ?? 0;
				break;
			case "004": {
				let e = new Set(t.buildings.flatMap((e) => e.cells.map(L)));
				return Number(We(i, t.buildings, "water").isolated === 0) + Number(We(i, t.buildings, "rock").isolated === 0) + Number(i.cells.filter((e) => e.terrain === "plain" && Re(i, e.at)).every((t) => e.has(L(t.at)))) + Number(i.cells.filter((e) => e.terrain === "plain").every((t) => e.has(L(t.at))));
			}
			case "005":
				a = t.bonuses.length;
				break;
			case "006":
				a = Ue(i, t.buildings).reduce((e, t) => e + t, 0);
				break;
			case "007":
				a = t.reputation;
				break;
			case "008":
				a = t.sponsors.length;
				break;
			case "009":
			case "017": {
				let n = this.pub.players.findIndex((e) => e.rid === t.rid), i = this.pub.players[(n + this.pub.players.length - 1) % this.pub.players.length], a = vi(i);
				return Math.min(4, (e === "009" ? E : T).filter((n) => (r[n] ?? 0) + (e === "017" ? t.partners.filter((e) => e === n).length : 0) > (a[n] ?? 0)).length);
			}
			case "010":
				a = r.rock ?? 0;
				break;
			case "011":
				a = r.water ?? 0;
				break;
			case "012":
				a = new Set(t.buildings.map((e) => Ie(e.cells).map((e) => e.map(L).join(";")).sort()[0])).size;
				break;
			case "013":
			case "014": {
				let n = this.pub.projects.filter((n) => (n.base || e === "014" && [
					"108",
					"109",
					"110",
					"111",
					"112",
					"133"
				].includes(n.card)) && n.slots.includes(t.rid)).map((e) => {
					let t = P[e.card];
					return t.kind === "project" ? t.tag : "";
				});
				a = $((e === "013" ? T : E).filter((e) => !n.includes(e)).map((e) => r[e] ?? 0));
				break;
			}
			case "015":
				a = Math.min(t.buildings.filter((e) => e.kind === "kiosk").length, t.buildings.filter((e) => e.kind === "pavilion").length);
				break;
			case "016": a = [...t.animals, ...t.sponsors].reduce((e, t) => {
				let n = P[t];
				return e + (n.kind === "animal" || n.kind === "sponsor" ? n.requirements.length : 0);
			}, 0);
		}
		let o = this.pub.config.marine ? n.thresholds : n.baseThresholds, s = o.reduce((e, t, n) => a >= t ? n + 1 : e, 0);
		if (!this.future || s === o.length) return s;
		let c = o[s], l = s ? o[s - 1] : 0;
		return s + .5 * gi((a - l) / Math.max(1, c - l), 0, 1);
	}
	progress(e) {
		let t = this.priv.finals.reduce((t, n) => t + this.finalValue(n, e) - this.finalValue(n), 0) * this.cp * this.w.final;
		for (let n of this.pub.projects) {
			let r = P[n.card];
			if (r.kind !== "project" || r.type === "release" || r.type === "breed" || n.slots.includes(this.p.rid)) continue;
			let i = this.count(this.p, r.tag), a = this.count(e, r.tag);
			t += $(r.slots.map((e, t) => n.slots[t] ? 0 : (Math.min(a, e.requirement) - Math.min(i, e.requirement)) * this.cp * e.conservation / Math.max(2, e.requirement))) * .65;
		}
		return t;
	}
	reputation(e) {
		let t = this.p;
		return Math.min(e, 15 - t.reputation) * (.35 + this.future * .25) + [5, 8].filter((n) => t.reputation < n && t.reputation + e >= n).length * (1 + this.future);
	}
	ability(e, t) {
		return e === "CONSERVATION_POINT" ? this.cp * t : e === "APPEAL" ? t : e === "REPUTATION" ? this.reputation(t) : e === "SUN_BATHING" ? Math.min(t, this.priv.hand.length) * this.cash * 3 : e === "POUCH" ? Math.min(t, this.priv.hand.length) * .7 : e === "SPRINT" || e.startsWith("PERCEPTION") || e === "HUNTER" ? t * (this.p.handCount < 4 ? 1.1 : .4) : e === "FULL_THROATED" ? (4 - this.p.workers) * this.future : e === "PACK" ? this.tags.predator ?? 0 : e === "PETTING_ZOO_ANIMAL" ? 3 * ((this.tags.pet ?? 0) + 1) : e === "JUMPING" ? t * this.cash : e === "REEF_MONEY" ? 3 * this.cash : e === "FLOCK_ANIMAL" || e === "HELPFUL" ? 0 : Math.min(3, t) * .65;
	}
	sponsorValue(e) {
		let t = this.p, n = (e) => this.tags[e] ?? 0, r = e.appeal + e.conservation * this.cp + this.reputation(e.reputation);
		e.id === "207" && (r += Math.floor([...E, ...T].filter((e) => n(e)).length / 2) * this.cp), e.id === "222" && (r += Math.min(3, n("science")) * this.cp), e.id === "208" && (r += n("science") + this.future * 1.5), e.id === "206" && (r += t.bonuses.length * 2 + this.future * this.cp), e.id === "216" && (r += Math.max(0, 4 - t.workers) * (1 + this.future)), e.id === "220" && (r += 3 * (1 + this.future) * this.cash), ["215", "218"].includes(e.id) && (r += 2.5 * this.future), ["229", "230"].includes(e.id) && (r += this.future * 2 + t.animals.filter((t) => {
			let n = P[t];
			return n.kind === "animal" && (e.id === "229" ? _i(n) : n.size >= 4);
		}).length);
		let i = {
			210: "americas",
			211: "europe",
			212: "australia",
			213: "asia",
			214: "africa",
			231: "primate",
			232: "reptile",
			233: "bird",
			234: "predator",
			235: "herbivore",
			241: "water"
		}[e.id];
		return i && (r += n(i) + this.future * ([
			"231",
			"232",
			"233",
			"234",
			"235"
		].includes(e.id) ? this.cash * (n(i) >= 3 ? 6 : 3) : 1.2)), e.id === "242" && (r += 3 * Math.floor(n("rock") / 2)), e.id === "262" && (r += 2 * [...E, ...T].filter((e) => n(e)).length * this.cash), e.id === "219" && (r += 2 * (n("rock") + n("water")) * this.cash + this.future * 1.5), ["263", "272"].includes(e.id) && (r += (e.id === "263" ? 10 : 6) * this.cash + 2), ["201", "254"].includes(e.id) && (r += 2 + this.future), e.id === "265" && (r += this.future * this.cash * 2 + 1), e.id === "274" && (r += this.future + 2), r + this.future * .6;
	}
	card(e, t = !1) {
		let n = `${e}:${t}`, r = this.values.get(n);
		if (r !== void 0) return r;
		let i = P[e], a = this.p, o;
		if (i.kind === "final") o = this.finalValue(e) * this.cp;
		else if (i.kind === "project") o = this.projectValue(e) / (t ? 2 : 1);
		else {
			let n = {
				...a,
				animals: i.kind === "animal" ? [...a.animals, e] : a.animals,
				sponsors: i.kind === "sponsor" ? [...a.sponsors, e] : a.sponsors
			}, r = this.progress(n);
			if (o = i.kind === "animal" ? (i.appeal + i.conservation * this.cp + this.reputation(i.reputation) + i.abilities.reduce((e, t) => e + this.ability(t.ability, typeof t.value == "number" ? t.value : 1), 0)) * this.w.animal : this.sponsorValue(i) * this.w.sponsor, o += r, i.kind === "animal" && i.reefDweller) {
				for (let e of [...a.animals, i.id]) {
					let t = P[e];
					t.kind === "animal" && (o += t.reef.reduce((e, t) => e + this.ability(t.ability, typeof t.value == "number" ? t.value : 1), 0));
				}
				o += i.reef.length * this.future * .6;
			}
			if (t) {
				let e = this.missing(i), t = i.kind === "animal" ? this.price(i) : 0, n = i.kind === "animal" && !bi(a, i) ? i.standard ? i.size * 2 : 6 : 0;
				o = (o - t * this.cash * .4) / (1 + e * .9 + (n ? .65 : 0) + Math.max(0, t + n - a.money) / 15), i.kind === "animal" && (a.assignment === "small" && i.size >= 4 || a.assignment === "large" && _i(i)) && (o = -5), !this.future && (e || n || t > a.money) && (o = -5);
			} else i.kind === "animal" && (o -= this.price(i) * this.cash * .5);
		}
		return this.values.set(n, o), o;
	}
	projectValue(e) {
		let t = P[e], n = this.p;
		if (t.kind !== "project" || n.bonuses.length >= F[n.map].tokens.length) return 0;
		let r = this.pub.projects.find((t) => t.card === e);
		return r?.slots.includes(n.rid) && !(t.type === "release" && n.sponsors.includes("224")) ? 0 : $(t.slots.map((e, i) => {
			if (r?.slots[i]) return 0;
			let a = this.count(n, t.tag) >= e.requirement, o = 0;
			if (t.type === "release") {
				let e = n.animals.map((e) => P[e]).filter((e) => e.kind === "animal" && e.tags.includes(t.tag) && (i === 0 ? e.size >= 4 : i === 1 ? e.size === 3 : _i(e)));
				a = e.length > 0, o = a ? Math.min(...e.map((e) => e.appeal)) - 2 : 0;
			}
			return t.type === "breed" && (a = n.animals.some((e) => {
				let r = P[e];
				return r.kind === "animal" && r.tags.includes(t.tag) && n.partners.some((e) => r.tags.includes(e));
			})), !a && r?.base && (a = this.count(n, t.tag) + Number([
				"215",
				"218",
				"wildcard"
			].some((e) => (n.cardTokens[e] ?? 0) > 0)) >= e.requirement), a ? e.conservation * this.cp + this.reputation(e.reputation) + 2 + this.future * .7 - o : 0;
		})) * this.w.project;
	}
	partner(e) {
		return 1 + $(this.priv.hand.map((e) => P[e]).filter((t) => t.kind === "animal" && t.tags.includes(e)).map((e) => (this.missing(e) && e.requirements.includes("Partner Zoo") ? 3 : 0) + 3 * this.cash + this.card(e.id, !0) * .25)) + this.progress({
			...this.p,
			partners: [...this.p.partners, e]
		}) + this.future * .7;
	}
	university(e) {
		let t = {
			...this.p,
			universities: [...this.p.universities, e]
		}, n = e === "hand" ? this.reputation(1) + this.future * .8 : e === "science_rep" ? this.reputation(2) + this.future * .6 : this.future * .8;
		return e.startsWith("animal:") && (n += 2 + this.priv.hand.filter((t) => {
			let n = P[t];
			return n.kind === "animal" && n.tags.includes(e.slice(7));
		}).length), n += this.progress(t) + this.priv.hand.reduce((e, t) => {
			let n = P[t];
			return e + (n.kind === "animal" || n.kind === "sponsor" ? Math.min(this.missing(n), n.requirements.filter((e) => e === "science" || e.toLowerCase() === "university").length) : 0);
		}, 0), this.p.universities.length === 1 && (n += 2 + this.future), this.p.universities.length === 2 && this.p.workers < 4 && (n += 1 + this.future), n;
	}
	building(e, t) {
		let n = this.p;
		if (e === "pavilion") return 1.3 - t * this.cash;
		if (e === "kiosk") return (1 + this.future) * this.cash * 2.5 - t * this.cash;
		let r = e.startsWith("standard") ? Number(e.slice(-1)) : e === "aquariumSmall" ? 2 : e === "petting" ? 3 : 5;
		return $(this.priv.hand.map((e) => P[e]).filter((t) => t.kind === "animal" && this.missing(t) <= 1 && !bi(n, t) && (e.startsWith("standard") ? t.standard && t.size <= r : t.special.some((t) => (t.kind === "aquarium" ? e === "aquariumSmall" || e === "aquariumLarge" : t.kind === e) && t.capacity <= r))).map((e) => this.card(e.id, !0) * .8 - t * this.cash * .5 - Math.max(0, t + this.price(e) - n.money) * this.cash * .65 - (r - e.size) * .3), -2) * this.w.build;
	}
	action(e, t) {
		let n = this.p, r = this.upgraded(e), i = n.actions.find((t) => t.kind === e).variant, a = [...this.priv.hand.map((e) => ({
			id: e,
			cost: 0
		})), ...r ? this.pub.market.slice(0, De(n.reputation)).flatMap((e, t) => e ? [{
			id: e,
			cost: t + 1
		}] : []) : []];
		if (e === "animals") {
			if (!r && t < 2) return -10;
			let e = +(i === 1 && t >= (r ? 3 : 5) || n.map === "6" || n.cardTokens.ignoreConditions > 0), o = a.filter(({ id: t, cost: r }) => {
				let i = P[t];
				return i.kind === "animal" && this.price(i, r) <= n.money && this.missing(i) <= e && bi(n, i) && !(n.assignment === "small" && i.size >= 4 || n.assignment === "large" && _i(i));
			}).map(({ id: e, cost: t }) => this.card(e) - t * this.cash).sort((e, t) => t - e);
			return (o[0] ?? -7) + (t >= (r ? 3 : 5) ? (o[1] ?? 0) * .45 : 0) + (r && t >= 5 ? this.reputation(1) : 0);
		}
		if (e === "sponsors") {
			let e = t * (r ? 2 : 1) * this.cash + this.breakValue(t), i = a.filter(({ id: e, cost: i }) => {
				let a = P[e];
				return a.kind === "sponsor" && this.missing(a) === 0 && a.strength <= t + Number(r) && i <= n.money;
			}).map(({ id: e, cost: t }) => this.card(e) - t * this.cash);
			return Math.max(e, $(i));
		}
		if (e === "build") return $(Object.entries(Pe).filter(([e, a]) => a.length <= t + Number(i === 3) && a.length * 2 <= n.money && !(["aviary", "reptile"].includes(e) && !r) && !([
			"petting",
			"aviary",
			"reptile",
			"aquariumSmall",
			"aquariumLarge"
		].includes(e) && n.buildings.some((t) => t.kind === e)) && (this.pub.config.marine || !e.startsWith("aquarium"))).map(([e, t]) => this.building(e, t.length * 2)), -3);
		if (e === "cards") {
			if (this.pub.finalTurns !== null) return -1;
			let e = (r ? Se : I)[gi(t, 1, 5) - 1], n = e[0] - (i === 1 ? 0 : e[1]), a = $(this.priv.hand.map((e) => this.card(e, !0))), o = this.priv.hand.length < 2 ? 4.5 : this.priv.hand.length < 4 ? 2.8 : a < 4 ? 1.8 : .7, s = t >= (i === 3 ? r ? 2 : 3 : r ? 3 : 5) ? $(this.pub.market.filter((e) => !!e).map((e) => this.card(e, !0))) * .65 : 0;
			return (Math.max(n * o, s) + this.breakValue(2) - Math.max(0, this.priv.hand.length - 5) * .8) * this.w.acquire;
		}
		let o = -6, s = [
			{
				name: "reputation",
				cost: 2,
				value: this.reputation(2)
			},
			{
				name: "partner",
				cost: 3,
				value: n.partners.length < (r ? 4 : 2) ? $(this.pub.partnerSupply.filter((e) => !n.partners.includes(e)).map((e) => this.partner(e))) : 0
			},
			{
				name: "university",
				cost: 4,
				value: n.universities.length < 3 ? $(this.pub.universitySupply.filter((e) => !n.universities.includes(e)).flatMap((e) => e === "animal" ? this.pub.marineUniversities.map((e) => `animal:${e}`) : [e]).map((e) => this.university(e))) : 0
			},
			{
				name: "project",
				cost: n.sponsors.includes("203") ? 4 : 5,
				value: $([...this.pub.projects.map((e) => e.card), ...a.map((e) => e.id)].map((e) => this.projectValue(e)))
			}
		];
		for (let e of s) {
			let i = n.workersUsed[e.name] ?? 0, a = i === 0 ? 1 : i === 1 ? 2 : 5;
			t >= e.cost && this.free >= a && e.value > 0 && (o = Math.max(o, e.value + (r && n.money >= ke(this.pub.players.length, this.pub.donations) ? Math.max(0, this.cp - ke(this.pub.players.length, this.pub.donations) * this.cash) : 0)));
		}
		return o;
	}
	breakValue(e) {
		return this.future && e >= this.pub.breakLength - this.pub.breakProgress ? gi((this.free === 0 ? 1 : -this.free * .6) + (this.p.money < 10 ? 1.5 : 0) - Math.max(0, this.priv.hand.length - (this.p.universities.includes("hand") ? 5 : 3)) * .5, -3, 3) : 0;
	}
	reward(e, t = !1) {
		return e.split("|").reduce((e, t) => {
			let n = Number(t.match(/\d+$/)?.[0] ?? 1);
			return t.startsWith("money") ? e + n * this.cash : t.startsWith("conservation") ? e + n * this.cp : t.startsWith("reputation") ? e + this.reputation(n) : t.startsWith("appeal") ? e + n : t.startsWith("xtoken") ? e + Math.min(n, 5 - this.p.x) * 1.2 : t.startsWith("cards") || t === "draw" || t === "snapHandLimit" ? e + n * (this.priv.hand.length < 4 ? 1.6 : .5) : t === "worker" ? e + (this.p.workers < 4 ? 1 + this.future * 1.5 : 0) : t === "upgrade" ? e + 2 + this.future * 1.5 : t === "partner" ? e + $(this.pub.partnerSupply.map((e) => this.partner(e))) : t === "university" ? e + $(this.pub.universitySupply.map((e) => this.university(e))) : t === "enclosure3" ? e + Math.max(2, this.building("standard3", 0)) : e + this.future * .6 + .3;
		}, 0) * (t ? this.future : 1);
	}
	placement(e) {
		let t = this.p, n = e.cells, r = F[t.map], i = new Set(n.map(L)), a = -(e.value ?? 0) * this.cash;
		for (let e of r.cells) i.has(L(e.at)) && e.bonus && (a += this.reward(e.bonus));
		let o = e.building;
		if (o === "kiosk" && (a += (He([...t.buildings, {
			id: -1,
			kind: o,
			cells: n,
			occupied: !1,
			used: 0,
			extra: 0,
			card: null
		}]) - He(t.buildings)) * this.future * this.cash), o.startsWith("standard") || o.startsWith("aquarium") || [
			"petting",
			"aviary",
			"reptile"
		].includes(o)) {
			let e = {
				id: -1,
				kind: o,
				cells: n,
				occupied: !1,
				used: 0,
				extra: 0,
				card: null
			}, r = {
				...t,
				buildings: [...t.buildings, e]
			};
			a += $(this.priv.hand.map((e) => P[e]).filter((e) => e.kind === "animal" && this.missing(e) <= 1 && !bi(t, e) && bi(r, e)).map((e) => this.card(e.id, !0) * .8));
		}
		return a += n.filter((e) => Re(r, e)).length * .06, a += R(n).filter((e) => t.buildings.some((t) => t.cells.some((t) => L(t) === L(e)))).length * .025, a;
	}
	score(e) {
		let t = e.key.slice(14), n = this.p;
		if (t === "action" && e.action) return this.action(e.action, e.value ?? Number(e.params?.n ?? 1)) - Number(e.params?.x ?? 0) * this.w.x - Number(e.params?.m ?? 0) * .1 + (n.actions.some((t) => t.kind === e.action && t.venom) ? 80 : 0);
		if (t === "gainX") return (this.pub.finalTurns === null ? .8 : -10) - (n.actions.findIndex((t) => t.kind === e.action) + 1) * .2 + (n.actions.some((t) => t.kind === e.action && t.venom) ? 80 : 0);
		if (t === "finish" || t === "confirm") return 0;
		if (t === "skip") return -.1;
		if (t === "playCard" && e.card) return this.card(e.card);
		if (["takeCard", "mark"].includes(t) && e.card) return this.card(e.card, !0);
		if (t === "drawDeck") return 3;
		if ([
			"discard",
			"sellCard",
			"pouchCard",
			"harbor"
		].includes(t) && e.card) return this.priv.hand.includes(e.card) ? (t === "sellCard" ? this.cash * 4 : t === "pouchCard" ? 2 : t === "harbor" ? this.cash * 3 : 0) - this.card(e.card, !0) * .45 : -2;
		if (t === "finalDiscard" && e.card) return -this.finalValue(e.card);
		if (t === "buildBuilding" && e.building) return this.building(e.building, e.value ?? 0);
		if (t === "placeHere" && e.cells && e.building) return this.placement(e);
		if (t === "takePartner") return this.partner(String(e.params?.tag));
		if (t === "takeUniversity") return this.university(String(e.params?.university));
		if (t === "taskReputation") return this.reputation(2);
		if (t === "support" && e.card) {
			if (e.params?.conservation !== void 0) {
				let t = e.params.animal ? P[String(e.params.animal)] : null;
				return (Number(e.params.conservation) * this.cp + this.reputation(Number(e.params.reputation)) - (t?.kind === "animal" ? t.appeal - 2 : 0) + this.reward(String(e.params.reward), !!e.params.income)) * this.w.project;
			}
			return this.projectValue(e.card);
		}
		if (t === "sponsorCash") return (this.pub.activity?.strength ?? 1) * (this.upgraded("sponsors") ? 2 : 1) * this.cash + this.breakValue(this.pub.activity?.strength ?? 1);
		if (t === "drawCards") return 3 + this.breakValue(2);
		if (t === "snap") return $(this.pub.market.filter((e) => !!e).map((e) => this.card(e, !0))) * .65;
		if (t === "upgrade" && e.action) return {
			animals: 3.5,
			build: 2.8,
			association: 4,
			cards: 2,
			sponsors: 1.5
		}[e.action] + this.future;
		if (t === "hire") return n.workers < 4 ? this.future * (n.workers === 1 ? 3 : 1.4) + 1 : -1;
		if (t === "donate") return this.cp + (n.conservation < 2 ? 2 : 0) - Number(e.params?.n ?? 0) * this.cash;
		if (t === "reward" && e.params?.reward) return this.reward(String(e.params.reward));
		if (t === "rewardMoney") return 5 * this.cash;
		if (t === "gain") return e.params?.resource === "reputation" ? this.reputation(Number(e.params.n)) : Number(e.params?.n ?? 1);
		if (t === "gainAppealPaid") return 1 - 2 * this.cash;
		if (t === "habitat" || t === "flock") {
			let r = n.buildings.filter((t) => e.cells?.some((e) => t.cells.some((t) => L(e) === L(t))));
			return t === "flock" ? 5 : 3 - r.reduce((e, t) => e + yi(n, t) - t.used, 0) * .12 - Number(r.some((e) => e.kind.startsWith("standard"))) * .5;
		}
		if ((t === "moveOne" || t === "moveFive") && e.action) {
			let r = n.actions.findIndex((t) => t.kind === e.action) + 1;
			return t === "moveOne" ? (5 - r) * .3 - this.action(e.action, r) * .2 : this.action(e.action, 5) - this.action(e.action, r);
		}
		if (t === "tradeX") return this.cash * 5 - this.w.x;
		if (t === "tradeMoney") return this.w.x - 5 * this.cash;
		if (t === "tradeReputationMoney") return this.reputation(1) - 5 * this.cash;
		if (t === "tradeReputationX") return this.reputation(1) - this.w.x;
		if (t === "moveAnimal") return 2;
		if (t === "release" && e.card) {
			let t = P[e.card];
			return t.kind === "animal" ? 1 - t.appeal : -5;
		}
		return t === "reconstruct" || t === "reselectBuildings" ? -3 : t === "cutDown" && e.cells ? e.score * this.cash * 2 - 4 : t === "useIgnore" ? -1 : t === "useRecall" ? this.free === 0 ? 2 : -1 : t === "useMarketing" ? this.priv.hand.some((e) => {
			let t = P[e];
			return t.kind === "sponsor" && this.missing(t) === 0 && t.strength <= n.money;
		}) ? .5 : -Infinity : t === "stealMoney" ? -Math.min(5, n.money) * this.cash : t === "stealCard" ? -$(this.priv.hand.map((e) => this.card(e, !0))) * .3 : t === "assignmentSmall" || t === "assignmentLarge" ? this.priv.hand.map((e) => P[e]).filter((e) => e.kind === "animal" && (t === "assignmentSmall" ? _i(e) : e.size >= 4)).reduce((e, t) => e + this.card(t.id, !0), 0) : t === "resolve" ? this.ability(String(e.params?.ability), e.value ?? 1) + e.score * .01 : e.score * .5;
	}
};
function Si(e) {
	let t = 4294967296 - 4294967296 % e, n = /* @__PURE__ */ new Uint32Array(1);
	do
		crypto.getRandomValues(n);
	while (n[0] >= t);
	return n[0] % e;
}
var Ci = {
	animals: [
		0,
		4,
		2,
		3,
		2
	],
	build: [
		0,
		2,
		3,
		4,
		2
	],
	cards: [
		0,
		4,
		2,
		3,
		3
	],
	association: [
		0,
		2,
		3,
		3,
		4
	],
	sponsors: [
		0,
		2,
		4,
		3,
		3
	]
};
function wi(e, t) {
	let [n, r] = e.split(":");
	return Ci[n][Number(r)] - (t.some((e) => e.split(":")[0] === n) ? 5 : 0);
}
function Ti(e = {}) {
	let t = {
		...hi,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private, a = r.players.find((e) => e.rid === n.rid);
		if (!i || !a || r.phase === "done") return null;
		let o = new xi(r, i, n.rid, t);
		if (r.phase === "map" && !a.ready) return { action: {
			type: "map",
			map: [...i.maps].sort((e, t) => F[t].prebuilt.length - F[e].prebuilt.length)[0]
		} };
		if (r.phase === "draft") {
			if (i.draftRound < 2) return i.draftSelected ? null : { action: {
				type: "draft",
				card: [...i.draft].sort((e, t) => wi(t, i.draftKept) - wi(e, i.draftKept))[0]
			} };
			if (a.ready) return null;
			let e = i.draftKept.flatMap((e, t) => i.draftKept.slice(t + 1).filter((t) => e.split(":")[0] !== t.split(":")[0]).map((t) => [e, t]));
			return e.sort((e, t) => t.reduce((e, t) => e + wi(t, []), 0) - e.reduce((e, t) => e + wi(t, []), 0)), { action: {
				type: "variants",
				cards: e[0]
			} };
		}
		if (r.phase === "setup" && !a.ready) {
			let e = [...i.hand].sort((e, t) => o.card(t, !0) - o.card(e, !0)), t = e.slice(0, 4), n = e.find((e) => {
				let t = P[e];
				return t.kind === "animal" && !o.missing(t) && o.price(t) + (bi(a, t) ? 0 : t.size * 2) <= a.money;
			});
			return n && !t.includes(n) && (t[3] = n), { action: {
				type: "hand",
				cards: t
			} };
		}
		if (!i.choices.length) return null;
		let s = n.memory, c = s?.turn === r.turnNumber && Array.isArray(s.globals) ? s.globals : [], l = i.choices.filter((e) => !e.id.startsWith("g:") || !c.includes(e.key));
		if (!l.length) return null;
		let u = l[0];
		if (n.difficulty === "weak") u = l[Si(l.length)];
		else {
			let e = -Infinity;
			for (let t of l) {
				let n = o.score(t);
				n > e && (e = n, u = t);
			}
		}
		return {
			action: {
				type: "choose",
				revision: r.revision,
				id: u.id
			},
			memory: {
				turn: r.turnNumber,
				globals: u.id.startsWith("g:") ? [...c, u.key] : c
			}
		};
	};
}
var Ei = Ti(), Di = (e, t, n) => {
	if (e.type !== "choose") return n(e.type === "map" ? "games.arknova.chooseMap" : e.type === "hand" ? "games.arknova.setupDiscard" : e.type === "draft" ? "games.arknova.chooseDraft" : "games.arknova.chooseVariants");
	let r = t.private?.choices.find((t) => t.id === e.id);
	return r ? n(r.key, {
		...r.params,
		action: r.action ? n(Qt[r.action]) : "",
		n: r.value ?? r.params?.n ?? 1
	}) : n("games.arknova.begin");
};
//#endregion
//#region src/games/arknova/game-over.tsx
function Oi(e) {
	let t = u(), n = l((e) => e.locale), i = e.public, [a, o] = c(!0), d = s(null), f = s(null), m = s(null), ee = (t) => {
		let r = e.members.find((e) => e.rid === t);
		return r ? ae(r, n) : t;
	}, _ = (e) => i.players.find((t) => t.rid === e), te = (t) => e.result.scores?.[t] ?? Ee(_(t).appeal, _(t).conservation);
	return r(() => {
		(a ? f : m).current?.focus({ preventScroll: !0 });
	}, [a]), /* @__PURE__ */ x("div", {
		className: "an-endgame",
		children: [
			/* @__PURE__ */ b("div", {
				className: "an-endgame-board",
				inert: a,
				children: /* @__PURE__ */ b(pi, {
					public: e.public,
					private: e.private,
					members: e.members,
					myRid: e.myRid,
					send: () => {}
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "an-result-backdrop",
				hidden: !a,
				children: /* @__PURE__ */ x("section", {
					className: "an-result",
					role: "dialog",
					"aria-modal": "true",
					"aria-label": t("session.result.title"),
					ref: d,
					onKeyDown: (e) => {
						if (e.key === "Escape" && (e.stopPropagation(), o(!1)), e.key === "Tab") {
							let t = [...d.current?.querySelectorAll("button:not(:disabled),summary,[tabindex=\"0\"]") ?? []].filter((e) => e.getClientRects().length > 0), n = t[0], r = t[t.length - 1];
							e.shiftKey && document.activeElement === n ? (e.preventDefault(), r?.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n?.focus());
						}
					},
					children: [
						/* @__PURE__ */ x("header", {
							className: "an-result-heading",
							children: [
								/* @__PURE__ */ b("span", {
									className: "an-result-badge",
									children: /* @__PURE__ */ b(J, { name: "leaf" })
								}),
								/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("small", { children: "ARK NOVA" }), /* @__PURE__ */ b("h1", { children: t("games.arknova.conservationReport") })] }),
								/* @__PURE__ */ b("button", {
									ref: f,
									onClick: () => o(!1),
									"aria-label": t("games.arknova.reviewHide"),
									title: t("games.arknova.reviewHide"),
									children: /* @__PURE__ */ b(h, { size: 24 })
								})
							]
						}),
						/* @__PURE__ */ x("div", {
							className: "an-result-body",
							children: [
								/* @__PURE__ */ x("div", {
									className: "an-winner",
									children: [
										/* @__PURE__ */ b(J, { name: "leaf" }),
										/* @__PURE__ */ x("div", { children: [/* @__PURE__ */ b("span", { children: t(e.result.winner.length > 1 ? "games.arknova.jointWinners" : "games.arknova.winner") }), /* @__PURE__ */ b("strong", { children: e.result.winner.map(ee).join(" / ") })] }),
										e.result.winner[0] && /* @__PURE__ */ x("span", {
											className: "an-winner-score",
											children: [/* @__PURE__ */ b("b", { children: te(e.result.winner[0]) }), /* @__PURE__ */ b("span", { children: t("games.arknova.score") })]
										})
									]
								}),
								e.hintCount !== void 0 && /* @__PURE__ */ b("p", {
									className: "an-result-hints",
									children: t("session.hint.usedCount", { n: e.hintCount })
								}),
								/* @__PURE__ */ x("table", {
									className: "an-score-table",
									children: [
										/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "col",
											children: t("games.arknova.score")
										}), e.result.ranking.map((n) => /* @__PURE__ */ x("th", {
											scope: "col",
											"data-winner": e.result.winner.includes(n),
											children: [
												/* @__PURE__ */ x("span", {
													className: "an-score-name",
													children: [/* @__PURE__ */ b("i", { style: { background: v[e.members.find((e) => e.rid === n)?.colorIndex ?? 0]?.hex } }), ee(n)]
												}),
												e.result.winner.includes(n) && /* @__PURE__ */ b("small", { children: t("games.arknova.winner") }),
												e.result.autopilot?.[n] !== void 0 && e.result.autopilot[n] > 0 && /* @__PURE__ */ x("small", {
													title: t("session.autopilot.share", { n: Math.round(e.result.autopilot[n] * 100) }),
													children: [
														/* @__PURE__ */ b(p, { size: 12 }),
														" ",
														Math.round(e.result.autopilot[n] * 100),
														"%"
													]
												})
											]
										}, n))] }) }),
										/* @__PURE__ */ x("tbody", { children: [
											/* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ x("th", {
												scope: "row",
												children: [/* @__PURE__ */ b(J, { name: "ticket" }), t("games.arknova.appeal")]
											}), e.result.ranking.map((e) => /* @__PURE__ */ b("td", { children: _(e).appeal }, e))] }),
											/* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ x("th", {
												scope: "row",
												children: [/* @__PURE__ */ b(J, { name: "shield" }), t("games.arknova.conservation")]
											}), e.result.ranking.map((e) => /* @__PURE__ */ b("td", { children: _(e).conservation }, e))] }),
											/* @__PURE__ */ x("tr", {
												className: "an-score-target",
												children: [/* @__PURE__ */ b("th", {
													scope: "row",
													children: t("games.arknova.appealTarget")
												}), e.result.ranking.map((e) => /* @__PURE__ */ b("td", { children: Te(_(e).conservation) }, e))]
											})
										] }),
										/* @__PURE__ */ b("tfoot", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
											scope: "row",
											children: t("games.arknova.total")
										}), e.result.ranking.map((t) => /* @__PURE__ */ b("td", {
											"data-winner": e.result.winner.includes(t),
											children: te(t)
										}, t))] }) })
									]
								}),
								/* @__PURE__ */ x("details", {
									className: "an-final-details",
									children: [/* @__PURE__ */ b("summary", { children: t("games.arknova.finalRewards") }), /* @__PURE__ */ b("div", {
										className: "an-final-groups",
										children: e.result.ranking.map((e) => /* @__PURE__ */ x("section", { children: [/* @__PURE__ */ b("h2", { children: ee(e) }), i.finalBreakdown[e]?.map((e, n) => /* @__PURE__ */ x("div", {
											className: "an-final-line",
											children: [/* @__PURE__ */ b("span", { children: t(P[e.card].nameKey) }), /* @__PURE__ */ x("span", { children: [/* @__PURE__ */ b(Y, {
												name: "ticket",
												value: `+${e.appeal}`
											}), /* @__PURE__ */ b(Y, {
												name: "shield",
												value: `+${e.conservation}`
											})] })]
										}, n))] }, e))
									})]
								})
							]
						}),
						/* @__PURE__ */ x("footer", {
							className: "an-result-actions",
							children: [/* @__PURE__ */ x("button", {
								onClick: () => o(!1),
								children: [/* @__PURE__ */ b(h, { size: 18 }), t("games.arknova.reviewBoard")]
							}), /* @__PURE__ */ x("div", { children: [
								e.onBackToLobby && /* @__PURE__ */ b(se, {
									label: t("session.result.backToLobby"),
									confirmLabel: t("games.arknova.confirmLobby"),
									onConfirm: e.onBackToLobby
								}),
								" ",
								e.onPlayAgain && /* @__PURE__ */ b(se, {
									label: t("session.result.playAgain"),
									confirmLabel: t("games.arknova.confirmAgain"),
									onConfirm: e.onPlayAgain
								}),
								" ",
								!e.onPlayAgain && !e.onBackToLobby && /* @__PURE__ */ b("p", { children: t("session.result.waitHost") })
							] })]
						})
					]
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "an-result-toolbar",
				hidden: a,
				children: /* @__PURE__ */ x("button", {
					ref: m,
					onClick: () => o(!0),
					children: [/* @__PURE__ */ b(g, { size: 19 }), t("games.arknova.reviewShow")]
				})
			})
		]
	});
}
//#endregion
//#region src/games/arknova/game-over-row.tsx
function ki({ public: e, rid: t }) {
	let n = u(), r = e, i = r.players.find((e) => e.rid === t);
	return i ? /* @__PURE__ */ x("div", {
		className: "an-final-row",
		children: [/* @__PURE__ */ x("div", { children: [
			"🎟 ",
			i.appeal,
			" 🛡 ",
			i.conservation,
			" ",
			n("games.arknova.score"),
			" ",
			Ee(i.appeal, i.conservation)
		] }), r.finalBreakdown[t]?.map((e, t) => /* @__PURE__ */ x("div", { children: [
			n(P[e.card].nameKey),
			" · ",
			e.conservation ? `🛡 +${e.conservation}` : "",
			e.appeal ? ` 🎟 +${e.appeal}` : ""
		] }, t))]
	}) : null;
}
//#endregion
//#region src/games/arknova/options.tsx
function Ai({ value: e, onChange: t }) {
	let n = u(), r = pe.safeParse(e), i = r.success ? r.data : pe.parse(void 0);
	return /* @__PURE__ */ x(y, { children: [/* @__PURE__ */ b(C, {
		title: n("games.arknova.optMarine"),
		children: /* @__PURE__ */ b(ce, {
			name: "an-marine",
			value: "marine",
			checked: i.marine,
			label: n("games.arknova.marineOn"),
			onChange: () => t({
				...i,
				marine: !i.marine
			})
		})
	}), /* @__PURE__ */ x(C, {
		title: n("games.arknova.optMaps"),
		children: [
			/* @__PURE__ */ b(S, {
				name: "an-maps",
				value: "A",
				checked: i.maps === "A",
				accent: w.accent,
				label: n("games.arknova.mapA"),
				onChange: () => t({
					...i,
					maps: "A"
				})
			}),
			/* @__PURE__ */ b(S, {
				name: "an-maps",
				value: "0",
				checked: i.maps === "0",
				accent: w.accent,
				label: n("games.arknova.map0"),
				onChange: () => t({
					...i,
					maps: "0"
				})
			}),
			/* @__PURE__ */ b(S, {
				name: "an-maps",
				value: "advanced",
				checked: i.maps === "advanced",
				accent: w.accent,
				label: n("games.arknova.mapAdvanced"),
				onChange: () => t({
					...i,
					maps: "advanced"
				})
			})
		]
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/arknova/entry.tsx
var ji = {
	definition: Yn,
	View: pi,
	bot: Ei,
	describe: Di,
	OverView: Oi,
	RowView: ki,
	Options: Ai,
	locales: {
		zh: {
			name: "方舟动物园",
			desc: "规划动物园、引入动物并支持保育项目，包含海洋世界扩展",
			rules: "游戏目标：\n通过引入动物提高吸引力，通过支持保育项目提高保育分数。两条轨道相遇后，其他玩家各进行最后一个回合，再加上终局卡和赞助商的奖励计分。平分时，支持保育项目次数较多者获胜。\n行动：\n每回合使用一张行动卡，其位置决定强度。可以在开始行动前支付 X 标记，每枚增加 1 强度；使用后将行动卡移到位置 1。也可以选择任意行动卡，改为获得 1 枚 X 标记。X 标记最多保留 5 枚。\n· 建造：支付每格 2 金钱，放置围栏、特殊饲养区、贩售亭或休憩亭。首次建筑须位于边界，其后须连接已有建筑。贩售亭之间至少相距 3 格。升级后允许一次建造多种不同建筑，并开放大型鸟舍、爬行馆及指定格。\n· 动物：支付费用、满足条件并安排合适的围栏，随后获得动物的吸引力、图标与能力。升级后可直接打出声望范围内的市场动物，另付其文件夹编号的费用。\n· 卡牌：先推进休息标记 2 格，然后依强度抽牌并按表弃牌，或在足够强度下从市场抓取一张牌。升级后抽牌可以从声望范围内的市场选择。市场在回合结束后补齐。\n· 协会：派出协会工作人员，完成提升声望、取得合作动物园、取得大学或支持保育项目的工作。再次执行同一工作须使用两名工作人员；休息时全部召回。升级后可组合不同工作，并额外捐赠一次。\n· 赞助商：依强度打出赞助商卡，或推进休息标记并取得金钱。升级后可以组合打出多张卡，也能直接打出声望范围内的市场赞助商卡。\n休息：\n休息标记到达终点时，完成整个回合后开始休息。先弃牌至手牌上限，移除行动卡上的标记，召回工作人员并补齐协会供应，弃置市场最左两张后补齐，再领取吸引力、贩售亭和其他收入。一般手牌上限为 3；指定大学将其提高至 5。\n海洋世界：\n海洋扩展开启时使用替换版卡牌及新增卡牌。海洋馆须连接水域。海洋动物可按其容量标记分配到一个或多个符合地形条件的海洋馆。珊瑚生物入园时，自己所有珊瑚生物的珊瑚能力均触发一次。补市场时每揭示一个波浪，额外弃置最左一张并补牌；开局忽略波浪。开局轮抽替代行动卡，每人使用两种不同的替代行动。新大学提供一种动物图标与研究图标，并寻找一张匹配的卡牌。\n效果顺序：\n同时获得的效果可以依允许的顺序结算。“行动完成后”的效果在行动卡移到位置 1 后处理。最终回合在休息期间触发时，所有玩家各再行动一次。",
			cards: {
				c401: {
					name: "猎豹",
					description: "疾跑 3：从牌库中抓取3张卡牌。"
				},
				c402: {
					name: "狮子",
					description: "群居：你的动物园里每个食肉类图标，获得 {Appeal-1} 。"
				},
				c403: {
					name: "花豹",
					description: "狩猎 4：展示牌库顶端的4张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c404: {
					name: "狞猫",
					description: "狩猎 2：展示牌库顶端的2张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c405: {
					name: "耳廓狐",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c406: {
					name: "西伯利亚虎",
					description: ""
				},
				c407: {
					name: "苏门答腊虎",
					description: ""
				},
				c408: {
					name: "懒熊",
					description: "推动: 协会：在当前行动完成后，你可以将你的“协会”行动卡牌 {AssociationActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c409: {
					name: "马来熊",
					description: "行动: 协会：在当前行动完成后，你可以执行“协会” 行动 {AssociationActionCard} 。"
				},
				c410: {
					name: "黄喉貂",
					description: "狩猎 1：展示牌库顶端的1张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c411: {
					name: "灰棕熊",
					description: "创造力: 熊：所有的动物园里每个熊类图标， 获得1 {XToken} 标记(最多3)。 呼唤：雇佣1个协会事务员。"
				},
				c412: {
					name: "美洲豹",
					description: "狩猎 4：展示牌库顶端的4张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c413: {
					name: "美洲狮",
					description: "跳跃 3：将休息标记推进3格。获得 {Money-3} 。"
				},
				c414: {
					name: "南浣熊",
					description: "创造力：获得 {XToken} 标记。"
				},
				c415: {
					name: "北美浣熊",
					description: "推动: 协会：在当前行动完成后，你可以将你的“协会”行动卡牌 {AssociationActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c416: {
					name: "普通棕熊",
					description: "双重: 协会：放置1 {MultiplierToken} 到你的“协会”行动卡牌 {AssociationActionCard} 上。 呼唤：雇佣1个协会事务员。"
				},
				c417: {
					name: "狼",
					description: "群居：你的动物园里每个食肉类图标，获得 {Appeal-1} 。"
				},
				c418: {
					name: "猞猁",
					description: "标志性动物 Europe：所有的动物园里每个Europe图标， 获得 {Appeal-1} (最多8)。"
				},
				c419: {
					name: "欧洲獾",
					description: "推动: 动物：在当前行动完成后，你可以将你的“动物”行动卡牌 {AnimalActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c420: {
					name: "白鼬",
					description: "狩猎 1：展示牌库顶端的1张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c421: {
					name: "新澳海狗",
					description: "呼唤：雇佣1个协会事务员。"
				},
				c422: {
					name: "澳海狮",
					description: "日光浴 3：你可以从你的手牌中卖出最多3张卡牌，每张卡牌 {Money-4} 。"
				},
				c423: {
					name: "新西兰海狮",
					description: "群居：你的动物园里每个食肉类图标，获得 {Appeal-1} 。"
				},
				c424: {
					name: "澳洲野犬",
					description: "群居：你的动物园里每个食肉类图标，获得 {Appeal-1} 。"
				},
				c425: {
					name: "袋獾",
					description: "育儿袋 1：你可以从你的手牌中放置最多1张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。"
				},
				c426: {
					name: "非洲草原象",
					description: "抵抗：抓取2张终局计分卡牌。保留1张并弃除另一张。"
				},
				c427: {
					name: "白犀牛",
					description: "执着：你可以将任意一张未使用的基础保护项目卡牌加入你的手牌。"
				},
				c428: {
					name: "长颈鹿",
					description: "推动: 赞助商：在当前行动完成后，你可以将你的“赞助商”行动卡牌 {SponsorsActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c429: {
					name: "细纹斑马",
					description: "推动: 赞助商：在当前行动完成后，你可以将你的“赞助商”行动卡牌 {SponsorsActionCard} 放置到 {Slot-1} 或 {Slot-5} 。 群集动物 2：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c430: {
					name: "倭河马",
					description: "行动：赞助商：在当前行动完成后，你可以执行“赞助商” 行动 {SponsorsActionCard} 。"
				},
				c431: {
					name: "亚洲象",
					description: "抵抗：抓取2张终局计分卡牌。保留1张并弃除另一张。"
				},
				c432: {
					name: "印度犀",
					description: "执着：你可以将任意一张未使用的基础保护项目卡牌加入你的手牌。"
				},
				c433: {
					name: "大熊猫",
					description: ""
				},
				c434: {
					name: "小熊猫",
					description: "双重: 赞助商：放置1 {MultiplierToken} 到你的“赞助商”行动卡牌 {SponsorsActionCard} 上。"
				},
				c435: {
					name: "亚洲貘",
					description: "刨挖 3：选择最多3次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。"
				},
				c436: {
					name: "美洲野牛",
					description: "标志性动物 Americas：所有的动物园里每个Americas图标， 获得 {Appeal-1} (最多8)。"
				},
				c437: {
					name: "麝牛",
					description: "招商：将展示区中所有的赞助商卡牌加入你的手牌。"
				},
				c438: {
					name: "驯鹿",
					description: "群集动物 3：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c439: {
					name: "大羊驼",
					description: "群集动物 2：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c440: {
					name: "山貘",
					description: "刨挖 2：选择最多2次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。"
				},
				c441: {
					name: "欧洲野牛",
					description: "招商：将展示区中所有的赞助商卡牌加入你的手牌。"
				},
				c442: {
					name: "驼鹿",
					description: "双重: 赞助商：放置1 {MultiplierToken} 到你的“赞助商”行动卡牌 {SponsorsActionCard} 上。 群集动物 4：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c443: {
					name: "马鹿",
					description: "群集动物 3：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c444: {
					name: "羱羊",
					description: "跳跃 2：将休息标记推进2格。获得 {Money-2} 。"
				},
				c445: {
					name: "非洲冕豪猪",
					description: "刨挖 2：选择最多2次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。"
				},
				c446: {
					name: "儒艮",
					description: "刨挖 4：选择最多4次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。"
				},
				c447: {
					name: "红袋鼠",
					description: "育儿袋 2：你可以从你的手牌中放置最多2张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。 群集动物 4：可以与现有的 {HerbivoreTag} 共享 {Size-X+} 饲养区。"
				},
				c448: {
					name: "树袋熊",
					description: "育儿袋 2：你可以从你的手牌中放置最多2张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。"
				},
				c449: {
					name: "鸭嘴兽",
					description: "毒液 1：每位魅力记录条领先你的玩家，获得1枚毒液标记。"
				},
				c450: {
					name: "塔斯马尼亚袋熊",
					description: "育儿袋 1：你可以从你的手牌中放置最多1张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。"
				},
				c451: {
					name: "长鼻猴",
					description: "支配：如果“灵长类”基础保护项目卡牌不在游戏中，则你可以将其加入你的手牌。"
				},
				c452: {
					name: "塞内加尔婴猴",
					description: "标志性动物 africa：所有的动物园里每个africa图标， 获得 {Appeal-1} (最多8)。"
				},
				c453: {
					name: "白颈白眉猴",
					description: "行动：卡牌：在当前行动完成后，你可以执行“卡牌” 行动 {CardsActionCard} 。"
				},
				c454: {
					name: "环尾狐猴",
					description: "日光浴 3：你可以从你的手牌中卖出最多3张卡牌，每张卡牌 {Money-4} 。"
				},
				c455: {
					name: "东非黑白疣猴",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c456: {
					name: "地中海猕猴",
					description: "偷窃 1：从具有最高 {Appeal} 的玩家处，拿取 {Money-5} 或从其手牌中随机抓取1张卡牌。由对方选择。"
				},
				c457: {
					name: "山魈",
					description: "双重: 卡牌：放置1 {MultiplierToken} 到你的“卡牌”行动卡牌 {CardsActionCard} 上。"
				},
				c458: {
					name: "日本猕猴",
					description: "偷窃 2：从具有最高 {Appeal} 的玩家和具有最高 {ConservationPoint} 的玩家处，拿取 {Money-5} 或从其手牌中随机抓取1张卡牌。由对方选择。"
				},
				c459: {
					name: "红腿白臀叶猴",
					description: "创造力: 灵长类：你的动物园里有1/3/5个灵长类图标， 获得1/2/3 {XToken} 标记。"
				},
				c460: {
					name: "郁乌叶猴",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c461: {
					name: " 邦加跗猴",
					description: "跳跃 4：将休息标记推进4格。获得 {Money-4} 。"
				},
				c462: {
					name: "印度灰叶猴",
					description: "跳跃 3：将休息标记推进3格。获得 {Money-3} 。"
				},
				c463: {
					name: "巴拿马白面卷尾猴",
					description: "偷窃 1：从具有最高 {Appeal} 的玩家处，拿取 {Money-5} 或从其手牌中随机抓取1张卡牌。由对方选择。"
				},
				c464: {
					name: "棕蜘蛛猴",
					description: "创造力: 灵长类：你的动物园里有1/3/5个灵长类图标， 获得1/2/3 {XToken} 标记。"
				},
				c465: {
					name: "金狮面狨",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c466: {
					name: "玻利维亚红吼猴",
					description: "推动: 卡牌：在当前行动完成后，你可以将你的“卡牌”行动卡牌 {CardsActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c467: {
					name: "厄瓜多尔松鼠猴",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c468: {
					name: "绒顶柽柳猴",
					description: ""
				},
				c469: {
					name: "尼罗鳄",
					description: "捕捉 2：2次：获得展示区中的任意一张卡牌。你可以在两次之间填补展示区。"
				},
				c470: {
					name: "西部绿曼巴蛇",
					description: "毒液 2：每位魅力记录条领先你的玩家，获得2枚毒液标记。"
				},
				c471: {
					name: "苏卡达陆龟",
					description: "日光浴 3：你可以从你的手牌中卖出最多3张卡牌，每张卡牌 {Money-4} 。"
				},
				c472: {
					name: "岩巨蜥",
					description: "日光浴 3：你可以从你的手牌中卖出最多3张卡牌，每张卡牌 {Money-4} 。"
				},
				c473: {
					name: "彩虹飞蜥",
					description: "日光浴 2：你可以从你的手牌中卖出最多2张卡牌，每张卡牌 {Money-4} 。"
				},
				c474: {
					name: "印度蟒",
					description: "缠绕：每位记录条领先你的玩家，其每有一条 ( {Appeal} 和 {ConservationPoint} )领先，获得1枚缠绕标记。"
				},
				c475: {
					name: "印度眼镜蛇",
					description: "催眠 3：在当前行动完成后，你可以从具有最高 {Appeal} 玩家的 {Slot-1} 、 {Slot-2} 或 {Slot-3} 槽位中，选择执行1张行动卡牌 {ActionCard} 上的行动。如果是你自己，则无效。"
				},
				c476: {
					name: "科莫多巨蜥",
					description: "标志性动物 asia：所有的动物园里每个asia图标， 获得 {Appeal-1} (最多8)。"
				},
				c477: {
					name: "高冠变色龙",
					description: "捕捉 1：获得展示区中的任意一张卡牌。"
				},
				c478: {
					name: "长鬣蜥",
					description: "日光浴 2：你可以从你的手牌中卖出最多2张卡牌，每张卡牌 {Money-4} 。"
				},
				c479: {
					name: "美洲短吻鳄",
					description: "捕捉 1：获得展示区中的任意一张卡牌。"
				},
				c480: {
					name: "宽吻凯门鳄",
					description: "捕捉 1：获得展示区中的任意一张卡牌。"
				},
				c481: {
					name: "圣克鲁斯岛加拉帕戈斯象龟",
					description: "日光浴 4：你可以从你的手牌中卖出最多4张卡牌，每张卡牌 {Money-4} 。"
				},
				c482: {
					name: "亚马逊森蚺",
					description: "缠绕：每位记录条领先你的玩家，其每有一条 ( {Appeal} 和 {ConservationPoint} )领先，获得1枚缠绕标记。"
				},
				c483: {
					name: "红尾蚺",
					description: "缠绕：每位记录条领先你的玩家，其每有一条 ( {Appeal} 和 {ConservationPoint} )领先，获得1枚缠绕标记。"
				},
				c484: {
					name: "欧洲泽龟",
					description: ""
				},
				c485: {
					name: "极北蝰",
					description: "催眠 3：在当前行动完成后，你可以从具有最高 {Appeal} 玩家的 {Slot-1} 、 {Slot-2} 或 {Slot-3} 槽位中，选择执行1张行动卡牌 {ActionCard} 上的行动。如果是你自己，则无效。"
				},
				c486: {
					name: "普通壁蜥",
					description: ""
				},
				c487: {
					name: "领纹蛇",
					description: "机灵：在当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} 。"
				},
				c488: {
					name: "蛇蜥",
					description: ""
				},
				c489: {
					name: "湾鳄",
					description: "捕捉 2：2次：获得展示区中的任意一张卡牌。你可以在两次之间填补展示区。"
				},
				c490: {
					name: "砂巨蜥",
					description: "食腐 2：洗匀弃牌堆并从中抓取2张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c491: {
					name: "伞蜥",
					description: "疾跑 1：从牌库中抓取1张卡牌。"
				},
				c492: {
					name: "细鳞太攀蛇",
					description: "毒液 2：每位魅力记录条领先你的玩家，获得2枚毒液标记。"
				},
				c493: {
					name: "棘蜥",
					description: ""
				},
				c494: {
					name: "非洲鸵鸟",
					description: "疾跑 2：从牌库中抓取2张卡牌。"
				},
				c495: {
					name: "蛇鹫",
					description: ""
				},
				c496: {
					name: "秃鹳",
					description: "食腐 2：洗匀弃牌堆并从中抓取2张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c497: {
					name: "小红鹳",
					description: "姿态 1：最多1次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c498: {
					name: "鲸头鹳",
					description: ""
				},
				c499: {
					name: "秃鹫",
					description: "食腐 3：洗匀弃牌堆并从中抓取3张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c500: {
					name: "长喙兀鹫",
					description: "食腐 3：洗匀弃牌堆并从中抓取3张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c501: {
					name: "蓝孔雀",
					description: "姿态 2：最多2次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c502: {
					name: "双角犀鸟",
					description: "推动: 建造：在当前行动完成后，你可以将你的“建造”行动卡牌 {BuildActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c503: {
					name: "雪鸮",
					description: "洞察力 4：从牌库中抓取4张卡牌。保留2张到你的手牌，并弃除其余卡牌。"
				},
				c504: {
					name: "安第斯神鹫",
					description: "食腐 4：洗匀弃牌堆并从中抓取4张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c505: {
					name: "白头海雕",
					description: "果断：在当前行动完成后，额外执行一个行动 {ActionCard} 。"
				},
				c506: {
					name: "王鹫",
					description: "食腐 5：洗匀弃牌堆并从中抓取5张卡牌。保留1张到你的手牌，并弃除其余卡牌。"
				},
				c507: {
					name: "大美洲鸵",
					description: "疾跑 1：从牌库中抓取1张卡牌。"
				},
				c508: {
					name: "五彩金刚鹦鹉",
					description: "姿态 3：最多3次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c509: {
					name: "金雕",
					description: "果断：在当前行动完成后，额外执行一个行动 {ActionCard} 。"
				},
				c510: {
					name: "白鹳",
					description: "双重: 建造：放置1 {MultiplierToken} 到你的“建造”行动卡牌 {BuildActionCard} 上。"
				},
				c511: {
					name: "大红鹳",
					description: "姿态 1：最多1次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c512: {
					name: "雕鸮",
					description: "洞察力 4：从牌库中抓取4张卡牌。保留2张到你的手牌，并弃除其余卡牌。"
				},
				c513: {
					name: "仓鸮",
					description: "洞察力 4：从牌库中抓取4张卡牌。保留2张到你的手牌，并弃除其余卡牌。"
				},
				c514: {
					name: "鸸鹋",
					description: "炫耀：如可能，你可以免费放置“鸟禽馆” {LargeBirdAviary} 。"
				},
				c515: {
					name: "澳大利亚鹈鹕",
					description: "行动: 建造：在当前行动完成后，你可以执行“建造” 行动 {BuildActionCard} 。"
				},
				c516: {
					name: "单垂鹤鸵",
					description: "双重: 建造：放置1 {MultiplierToken} 到你的“建造”行动卡牌 {BuildActionCard} 上。"
				},
				c517: {
					name: "笑翠鸟",
					description: "标志性动物 australia：所有的动物园里每个australia图标， 获得 {Appeal-1} (最多8)。"
				},
				c518: {
					name: "小极乐鸟",
					description: "姿态 1：最多1次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c519: {
					name: "家山羊",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c520: {
					name: "绵羊",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c521: {
					name: "马",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c522: {
					name: "驴",
					description: "创造力：获得 {XToken} 标记。 萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c523: {
					name: "家兔",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c524: {
					name: "曼加利察猪",
					description: "刨挖 1：选择最多1次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。 萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c525: {
					name: "豚鼠",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c526: {
					name: "羊驼",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c527: {
					name: "虹彩吸蜜鹦鹉",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c528: {
					name: "红颈袋鼠",
					description: "育儿袋 1：你可以从你的手牌中放置最多1张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。 萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c529: {
					name: "公主海葵",
					description: "标示：在本行动完成后，标示展示区的1张动物卡牌。"
				},
				c530: {
					name: "太平洋双锯鱼",
					description: ""
				},
				c531: {
					name: "拟刺尾鲷",
					description: "交易：你仅可以用1 {XToken} 标记交易 {Money-5} ，反之亦然。"
				},
				c532: {
					name: "浮游动物",
					description: "海洋魅力：将展示区中具有 {SeaAnimalTag} 图标的所有卡牌加入你的手牌。"
				},
				c533: {
					name: "斑点鹰鱼",
					description: "姿态 1：最多1次：你可以免费放置1个贩售亭或休憩亭。"
				},
				c534: {
					name: "南蓝环章鱼",
					description: "毒液 1：每位魅力记录条领先你的玩家，获得1枚毒液标记。"
				},
				c535: {
					name: "金头霓虹虾虎鱼",
					description: "共生：使用你动物园内另一张 {SeaAnimalTag} 卡牌上的1个能力(非珊瑚礁住客效果)。 助益：其自身没有珊瑚住客效果。"
				},
				c536: {
					name: "长角鲀鱼",
					description: "推动: 赞助商：在当前行动完成后，你可以将你的“赞助商”行动卡牌 {SponsorsActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c537: {
					name: "叉斑锉鳞鲀",
					description: "缠绕：每位记录条领先你的玩家，其每有一条 ( {Appeal} 和 {ConservationPoint} )领先，获得1枚缠绕标记。"
				},
				c538: {
					name: "斑鳍蓑鲉",
					description: "毒液 1：每位魅力记录条领先你的玩家，获得1枚毒液标记。"
				},
				c539: {
					name: "白点刺鼻单棘鲀",
					description: ""
				},
				c540: {
					name: "白点叉鼻鲀",
					description: "毒液 1：每位魅力记录条领先你的玩家，获得1枚毒液标记。"
				},
				c541: {
					name: "蓝斑条尾魟",
					description: "刨挖 1：选择最多1次：从展示区弃除1张卡牌并填补展示区；或者，从你的手牌中弃除1张卡牌，以从牌库抓取1张卡牌。"
				},
				c542: {
					name: "波纹唇鱼",
					description: "加班：你可以将你的1个协会事务员返回你的便签簿。"
				},
				c543: {
					name: "珊瑚礁鬼蝠魟",
					description: "滑翔 3：从你的手牌中弃除最多3张卡牌，这些卡牌上每有一个 {SeaAnimalTag} 图标，获得以下3个效果中的1个： {Reputation-1} / {Appeal-2} / {Kiosk} 。"
				},
				c544: {
					name: "加勒比真鲨",
					description: "鲨鱼袭击 1：从展示区声望范围内弃除1张动物卡牌：获得那些卡牌一半的 {Appeal} (向下取整)。"
				},
				c545: {
					name: "后鳍锯鳐",
					description: "削减：你可以从你的动物园地图上移除1个闲置的标准饲养区并收回其成本。"
				},
				c546: {
					name: "锥齿鲨",
					description: "鲨鱼袭击 2：从展示区声望范围内弃除2张动物卡牌：获得那些卡牌一半的 {Appeal} (向下取整)。"
				},
				c547: {
					name: "杂斑盔鱼",
					description: "共生：使用你动物园内另一张 {SeaAnimalTag} 卡牌上的1个能力(非珊瑚礁住客效果)。"
				},
				c548: {
					name: "欧洲海马",
					description: "伪装：如果你在本回合中打出另一个动物，你可以忽略其上的1个条件。 育儿袋 1：你可以从你的手牌中放置最多1张卡牌到本卡牌下方。每放置一张，获得 {Appeal-2} 。"
				},
				c549: {
					name: "真蛸",
					description: "伪装：如果你在本回合中打出另一个动物，你可以忽略其上的1个条件。"
				},
				c550: {
					name: "罗盘水母",
					description: "滑翔 2：从你的手牌中弃除最多2张卡牌，这些卡牌上每有一个 {SeaAnimalTag} 图标，获得以下3个效果中的1个： {Reputation-1} / {Appeal-2} / {Kiosk} 。"
				},
				c551: {
					name: "红海龟",
					description: "蛙潜 X：展示牌库顶端的X张卡牌。选择1张赞助商卡牌并将其加入你的手牌。弃除其余的卡牌。X等于你动物园中 {SeaAnimalTag} + {ReptileTag} 的数量。 营销：{Marketing}"
				},
				c552: {
					name: "绿海龟",
					description: "蛙潜 X：展示牌库顶端的X张卡牌。选择1张赞助商卡牌并将其加入你的手牌。弃除其余的卡牌。X等于你动物园中 {SeaAnimalTag} + {ReptileTag} 的数量。"
				},
				c553: {
					name: "大盖巨脂鲤",
					description: "适应 1：抽取1张终局计分卡牌，然后弃除1张终局计分卡牌。"
				},
				c554: {
					name: "斑嘴环企鹅",
					description: "适应 2：抽取2张终局计分卡牌，然后弃除2张终局计分卡牌。"
				},
				c555: {
					name: "川金丝猴",
					description: "偷窃 1：从具有最高 {Appeal} 的玩家处，拿取 {Money-5} 或从其手牌中随机抓取1张卡牌。由对方选择。"
				},
				c556: {
					name: "貂熊",
					description: "推动: 协会：在当前行动完成后，你可以将你的“协会”行动卡牌 {AssociationActionCard} 放置到 {Slot-1} 或 {Slot-5} 。"
				},
				c557: {
					name: "越南大肚猪",
					description: "萌宠动物：你的动物园里每个萌宠类图标， 获得 {Appeal-3} 。"
				},
				c558: {
					name: "北绒毛蛛猴",
					description: "猴子帮：从牌库中逐一展示卡牌。将第一张具有 {PrimateTag} 的卡牌加入你的手牌中。将其余的卡牌塞入牌库底部。"
				},
				c559: {
					name: "克氏冕狐猴",
					description: "猴子帮：从牌库中逐一展示卡牌。将第一张具有 {PrimateTag} 的卡牌加入你的手牌中。将其余的卡牌塞入牌库底部。 跳跃 2：将休息标记推进2格。获得 {Money-2} 。"
				},
				c560: {
					name: "栗鸢",
					description: "狩猎 2：展示牌库顶端的2张卡牌。选择1张动物卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c201: {
					name: "科学实验室",
					description: "打出时及每次休息时，从牌库或声望范围内的市场取得 1 张牌。终局：3–5／6 个以上研究图标，获得 1／2 保育分数。\n收入： 从牌库或声望范围内拿取1张卡牌。 从牌库抽一张牌或者从声望范围内获得一张牌。 3/6个研究图标，获得 {ConservationPoint-1} / {ConservationPoint-2} 。"
				},
				c202: {
					name: "发言人",
					description: "每次你在 你的动物园 中打出研究图标时，获得 {Reputation-1} 。"
				},
				c203: {
					name: "兽医",
					description: "立即：按大学数量 1／2／3，获得 2／5／10 金钱。终局：拥有 3 所大学，获得 1 保育分数。\n支持保护项目，仅需 {Slot-4} 。"
				},
				c204: {
					name: "科学博物馆",
					description: "立即：每个研究图标获得 2 金钱。\n每次你在 你的动物园 中打出研究图标时，获得 {ConservationPoint-1} 。"
				},
				c205: {
					name: "大猩猩野外研究",
					description: "立即：获得 2 声望。\n立即：获得 1 保育分数。"
				},
				c206: {
					name: "医学突破",
					description: "立即：每次已支持的保育项目获得 2 吸引力。\n收入： 获得 {ConservationPoint-1} 。"
				},
				c207: {
					name: "基础研究",
					description: "每有2个不同的大洲和/或动物类目图标，获得 {ConservationPoint-1} 。你以此方式每获得 {ConservationPoint-1} , 每位其他玩家获得 {Money-2} 。"
				},
				c208: {
					name: "科学图书馆",
					description: "立即：每个研究图标获得 1 吸引力。\n每次 任何动物园 中打出研究图标时， 获得 {Money-2} 。 5个不同的动物类目图标，获得 {ConservationPoint-1} 。"
				},
				c209: {
					name: "技术研究所",
					description: "立即：获得 1 枚 X 标记。终局：拥有 3 所大学，获得 1 保育分数。\n收入： 获得1枚 {XToken} 标记。"
				},
				c210: {
					name: "美洲专家",
					description: "立即：每个美洲图标获得 1 吸引力。终局：拥有至少 5 座贩售亭，获得 1 保育分数。\n每次你在 你的动物园 中打出美洲图标时，你可以免费建造一个贩售亭。"
				},
				c211: {
					name: "欧洲专家",
					description: "立即：每个欧洲图标获得 1 吸引力。终局：拥有至少 5 个已占用的 1 格围栏，获得 1 保育分数。\n每次你在 你的动物园 中打出欧洲图标时，你可以免费建造1个1格饲养区。"
				},
				c212: {
					name: "澳洲专家",
					description: "立即：每个澳洲图标获得 1 吸引力。\n每次你在 你的动物园 中打出澳洲图标时，你可以从你的手牌中放置1张卡牌到本卡牌下方，以获得 {Appeal-2} (育儿袋 1)。"
				},
				c213: {
					name: "亚洲专家",
					description: "立即：每个亚洲图标获得 1 吸引力。\n每次你在 你的动物园 中打出亚洲图标时，你可以免费建造1个休憩亭。"
				},
				c214: {
					name: "非洲专家",
					description: "立即：每个非洲图标获得 1 吸引力。终局：每枚持有的 X 标记获得 1 吸引力。\n每次你在 你的动物园 中打出非洲图标时，在你当前行动完成后，你可以将任意一张行动卡牌放置到 {Slot-1} (机灵)。"
				},
				c215: {
					name: "全球繁育计划",
					description: "打出本卡牌时，在本卡牌上放置2个玩家标记。当支持 基础 保护项目时，你可以弃除本卡牌上的1个标记(仅限1个)以代表任一图标。 支持了5个保护项目，获得 {ConservationPoint-1} 。"
				},
				c216: {
					name: "优秀的协调员",
					description: "终局：声望至少为 9，获得 1 保育分数。\n雇佣1个协会事务员(呼唤)。"
				},
				c217: {
					name: "工程师",
					description: "终局：建满动物园，获得 5 吸引力。\n每当你使用“建造”行动 {BuildActionCard} 建造至少1个建筑时，你可以多建造 1个相同类型 的建筑(特殊饲养区除外)，按正常费用支付。"
				},
				c218: {
					name: "育种计划",
					description: "打出本卡牌时，在本卡牌上放置2个玩家标记。当支持 基础 保护项目时，你可以弃除本卡牌上的1个标记(仅限1个)以代表任一图标。 支持5个保护项目，获得 {ConservationPoint-1} 。"
				},
				c219: {
					name: "综合研究员",
					description: "终局：每组水域与岩石图标获得 2 吸引力，最多计算 3 组。\n你可以覆盖水域和岩石格。忽略所有水域和岩石的需求。 每个水域和岩石的需求，获得 {Money-2} 。"
				},
				c220: {
					name: "联邦资助金",
					description: "立即：获得 3 金钱。终局：声望至少为 9，获得 1 保育分数。\n收入： 获得 {Money-3} 。"
				},
				c221: {
					name: "考古学家",
					description: "终局：覆盖所有可建造的边界格，获得 1 保育分数。\n每次你获得你动物园边界格的放置奖励时，你免费获得你动物园中另一个未覆盖的放置奖励。"
				},
				c222: {
					name: "发布专利",
					description: "最多由本牌获得 3 保育分数。\n你的动物园里每个研究图标，获得 {ConservationPoint-1} (最多3)。你以此方式每获得 {ConservationPoint-1} ，每位其他玩家获得 {Money-2} 。"
				},
				c223: {
					name: "科研机构",
					description: ""
				},
				c224: {
					name: "迁徙记录",
					description: "立即：获得 1 枚 X 标记。\n每当你支持 放归野外 的保护项目时，额外获得 {ConservationPoint-1} 。 你可以多次支持每一个 放归野外 的保护项目。"
				},
				c225: {
					name: "检疫实验室",
					description: "立即：获得 1 枚 X 标记。\n毒液、缠绕、催眠 和 偷窃 的效果，对你无效。 5个不同的大洲图标，获得 {ConservationPoint-1} 。"
				},
				c226: {
					name: "海外研究所",
					description: "立即：获得 2 声望。\n5个不同的大洲图标，获得 {ConservationPoint-1} 。"
				},
				c227: {
					name: "世界动物园协会特别任务",
					description: "选择专注小型或大型动物；此后不能打出另一种体型的动物，仍可打出 3 格动物。\n选择并标记本卡牌上的 {SizeAnimal-2} 或 {SizeAnimal-4} 。从牌库中逐一展示卡牌，将第一张所选择类型的动物卡牌加入你的手牌，然后将其余的卡牌塞入牌库 底部 。 你不能再打出未放标记的类型。每当你打出小型或大型动物时，你获得 {Appeal-2} 或 {Appeal-4} 。"
				},
				c228: {
					name: "世界动物园协会小型动物计划",
					description: "立即：每只小型动物获得 2 金钱。\n每次你在“动物”行动 {AnimalActionCard} 中， 仅仅 打出 小型动物 时，你可以从你的手牌中按正常费用再打出1个小型动物。随后，从展示区拿取1个小型动物(如果有)。"
				},
				c229: {
					name: "小型动物专家",
					description: "立即：每只小型动物获得 1 吸引力。\n你打出小型动物的费用减 {Money-3} 。"
				},
				c230: {
					name: "大型动物专家",
					description: "立即：每只大型动物获得 2 吸引力。\n你打出大型动物的费用减 {Money-4} 。"
				},
				c231: {
					name: "灵长类资助计划",
					description: "立即：每个灵长类图标获得 1 吸引力。\n收入： 你的动物园里有1/3/5个灵长类图标，获得 {Money-3} / {Money-6} / {Money-9} 。"
				},
				c232: {
					name: "爬行类资助计划",
					description: "立即：每个爬行类图标获得 1 吸引力。\n收入： 你的动物园里有1/3/5个爬行类图标，获得 {Money-3} / {Money-6} / {Money-9} 。"
				},
				c233: {
					name: "秃鹫资助计划",
					description: "立即：每个鸟类图标获得 1 吸引力。\n收入： 你的动物园里有1/3/5个鸟类图标，获得 {Money-3} / {Money-6} / {Money-9} 。"
				},
				c234: {
					name: "狮子资助计划",
					description: "立即：每个食肉类图标获得 1 吸引力。\n收入： 你的动物园里有1/3/5个食肉类图标，获得 {Money-3} / {Money-6} / {Money-9} 。"
				},
				c235: {
					name: "大象资助计划",
					description: "立即：每个食草类图标获得 1 吸引力。\n收入： 你的动物园里有1/3/5个食草类图标，获得 {Money-3} / {Money-6} / {Money-9} 。"
				},
				c236: {
					name: "灵长类动物学家",
					description: "每次 任何动物园 中打出灵长类图标时，获得 {Money-3} 。"
				},
				c237: {
					name: "爬行类动物学家",
					description: "每次 任何动物园 中打出爬行类图标时，获得 {Money-3} 。"
				},
				c238: {
					name: "鸟类学家",
					description: "每次 任何动物园 中打出鸟类图标时，获得 {Money-3} 。"
				},
				c239: {
					name: "食肉动物专家",
					description: "每次 任何动物园 中打出食肉类图标时，获得 {Money-3} 。"
				},
				c240: {
					name: "食草动物专家",
					description: "每次 任何动物园 中打出食草类图标时，获得 {Money-3} 。"
				},
				c241: {
					name: "水文学家",
					description: "立即：每个水域图标获得 1 吸引力。\n你每覆盖一个与水域相邻的六角格， 获得 {Money-1} 。 如果所有的水域格都已相连，获得 {ConservationPoint-1} 。"
				},
				c242: {
					name: "地质学家",
					description: "立即：每 2 个岩石图标获得 3 吸引力。\n你每覆盖一个与岩石相邻的六角格， 获得 {Money-1} 。 如果所有的岩石格都已相连，获得 {ConservationPoint-1} 。"
				},
				c243: {
					name: "狐獴窝",
					description: "终局：至少 6 个食草类图标，获得 1 保育分数。\n每次你在 你的动物园 中打出食草类图标时，获得 {Appeal-2} 。 放置到至少相邻1个岩石格的位置。"
				},
				c244: {
					name: "企鹅馆",
					description: "终局：至少 6 个鸟类图标，获得 1 保育分数。\n每次你在 你的动物园 中打出鸟类图标时，获得 {Appeal-2} 。 放置到至少相邻1个水域格的位置。"
				},
				c245: {
					name: "水族馆",
					description: "终局：至少 6 个水域图标，获得 1 保育分数。\n每次你在 你的动物园 中打出水域图标时，获得 {Appeal-2} 。 放置到至少相邻2个水域格的位置。"
				},
				c246: {
					name: "空中索道",
					description: "终局：至少 6 个岩石图标，获得 1 保育分数。\n每次你在 你的动物园 中打出岩石图标时，获得 {Appeal-2} 。 放置到至少相邻2个岩石格的位置。"
				},
				c247: {
					name: "狒狒栖息岩",
					description: "终局：至少 6 个灵长类图标，获得 1 保育分数。\n每次你在 你的动物园 中打出灵长类图标时，获得 {Appeal-2} 。 放置到至少相邻1个岩石格的位置。"
				},
				c248: {
					name: "猕猴园",
					description: "每次你在 你的动物园 中打出灵长类图标时，获得 1个 {XToken} 标记。"
				},
				c249: {
					name: "猫头鹰棚屋",
					description: "每次你在 你的动物园 中打出鸟类图标时，从牌库中抓取2张卡牌。保留1张并弃除另一张(洞察力 2)。"
				},
				c250: {
					name: "海龟水族箱",
					description: "每张出售的牌获得 4 金钱。\n每次你在 你的动物园 中打出爬行类图标时，你可以从你的手牌中卖出最多2张卡牌，每张卡牌 {Money-4} (日光浴 2)。"
				},
				c251: {
					name: "北极熊展",
					description: "终局：3–5／6 个以上熊类图标，获得 1／2 保育分数。\n每次 任何动物园 中打出熊类图标时，获得 {Appeal-2} 。 放置到至少相邻1个水域格的位置。"
				},
				c252: {
					name: "斑鬣狗围场",
					description: "每次你在 你的动物园 中打出食肉类图标时，展示牌库顶端的X张卡牌。将1张动物卡牌加入你的手牌。弃除其余的卡牌。(X=你动物园里食肉类图标的数量)(狩猎X)。 放置到至少相邻1个岩石格的位置。"
				},
				c253: {
					name: "霍加狓棚厩",
					description: "打出本卡牌时，在本卡牌上放置 3个玩家标记 。每次你在 你的动物园 中打出食草类图标时，你可以移除本卡牌上的1个标记并支付 {Money-X} ，以打出一张赞助商卡牌( {Money-X} = {Slot-X} )。"
				},
				c254: {
					name: "动物园课外学校",
					description: "立即：获得 1 声望。\n立即：获得 1 保育分数。\n放置到至少2个边界格的位置。从牌库或声望范围内拿取1张卡牌。"
				},
				c255: {
					name: "儿童游乐园",
					description: "立即：获得 4 吸引力。\n放置到至少相邻1个岩石格的位置。"
				},
				c256: {
					name: "水上乐园",
					description: "立即：获得 4 吸引力。\n放置到至少相邻1个水域格的位置。"
				},
				c257: {
					name: "园区边门",
					description: "放置到2个边界格的位置。不必与其他建筑相邻。 收入： 每个相邻“园区边门”的建筑(闲置的标准饲养区除外)，获得 {Money-2} 。 如果地图被全部覆盖，则获得 {Appeal-5} 。"
				},
				c258: {
					name: "本地海鸟",
					description: "每个相连的水域格，获得 {Appeal-1} 。 每2个孤立的水域格，获得 {ConservationPoint-1} 。"
				},
				c259: {
					name: "本地蜥蜴",
					description: "每个相连的岩石格，获得 {Appeal-1} 。 每2个孤立的岩石格，获得 {ConservationPoint-1} 。"
				},
				c260: {
					name: "本地农牧动物",
					description: "每个相连的没有建筑的边界格，获得 {Appeal-1} 。 每一组由6个没有建筑的可建造六角格连成的区域，获得 {ConservationPoint-1} 。"
				},
				c261: {
					name: "导游学校参观",
					description: "立即：获得 1 吸引力。\n立即：获得 1 保育分数。\n5个不同的动物类目图标，获得 {ConservationPoint-1} 。"
				},
				c262: {
					name: "探险家",
					description: "同一张牌的重复图标只触发一次新图标奖励。\n每次你获得还未在 你动物园 里出现的大洲或动物类目图标时，获得 {Appeal-1} 和 {Money-2} 。 你的动物园里每个不同的大洲和动物类目图标，获得 {Money-2} 。"
				},
				c263: {
					name: "世界动物园协会大型动物计划",
					description: "如果你打出大型动物，你可以忽略1个由你选择的条件。 你可以免费放置1个5格饲养区。"
				},
				c264: {
					name: "自由放养的新世界猴",
					description: "每个相连的具有放置奖励的六角格， 获得 {Appeal-1} 。 每2个孤立的具有放置奖励的六角格， 获得 {ConservationPoint-1} 。"
				},
				c265: {
					name: "特许经营",
					description: "立即：获得 2 吸引力。\n收入：其他动物园 里每有一个贩售亭，获得 {Money-1} 。 免费放置一个贩售亭。 如果你拥有5个贩售亭, 则获得 {ConservationPoint-1} 。"
				},
				c266: {
					name: "海洋生物学家",
					description: "每次 任何动物园 中打出海洋类 图标时，获得 {Money-3} 。"
				},
				c267: {
					name: "农场猫",
					description: "立即：贩售亭与休憩亭合计 1–3／4–6／7 座以上，获得 1／3／5 吸引力。\n每个至少相邻3个空置可建造六角格 的 {Kiosk} ，获得 {ConservationPoint-1} (最多 {ConservationPoint-3} )。"
				},
				c268: {
					name: "欧洲会议",
					description: "立即：1–2／3–4／5 个以上欧洲图标，获得 2／5／10 金钱。\n每次你在 你的动物园 中打出欧洲图标时，你可以在当前行动完成后，标示1张动物卡牌。 如果你进行了3次捐赠，获得 {ConservationPoint-1} 。"
				},
				c269: {
					name: "澳洲会议",
					description: "每次你在 你的动物园 中打出澳洲图标时，你可以免费将一个标准饲养区的面积扩大一格。如果该饲养区已占用，获得 {Appeal-2} 。 每张 育儿袋 中的卡牌，获得 {Appeal-1} (最多5)。"
				},
				c270: {
					name: "海洋科考队",
					description: "每次你在 你的动物园 中打出海洋 类图标时，选择以下一项: 考察 | 你可以派遣你动物园中的一张 人物 赞助商卡牌(弃除)，以获得 {ConservationPoint-1} ; 或者，蛙潜 3 | 展示牌库顶的3张卡牌，选择1张赞助商卡牌并将其加入你的手牌。弃除其余的卡牌。"
				},
				c271: {
					name: "发掘现场",
					description: "放置本建筑时，获得两次放置奖励。 如果所有的放置奖励都被覆盖，获得 {ConservationPoint-1} 。"
				},
				c272: {
					name: "扩建区",
					description: "立即：免费放置 1 个 3 格围栏。\n将所有至少建在1个边界格上的3格饲养区视为5格饲养区。 如果所有的边界格都被覆盖，获得 {ConservationPoint-1} 。"
				},
				c273: {
					name: "出版物",
					description: "当进行捐赠时, 你的动物园中每有 一个 {ScienceTag} ，少支付 {Money-1} 。 你可以进行一次捐赠。"
				},
				c274: {
					name: "吉祥物雕塑",
					description: "立即：获得 1 吸引力。\n收入： 获得 {Appeal-1} 。 每有一个具有更高魅力点数的动物园，获得 {Appeal-2} (最后计算)。"
				},
				c275: {
					name: "驯马师",
					description: "每次 任何动物园 中打出萌宠类图标时，获得 {Money-2} 。 从 弃牌堆 中查找一个萌宠类动物，并将其加入手牌。"
				},
				c276: {
					name: "园林学家",
					description: "立即：可免费放置 1 座休憩亭，然后每座休憩亭获得 1 吸引力。\n每次你建造一个休憩亭，获得1枚 {XToken} 标记(每次行动最多1枚)。"
				},
				c277: {
					name: "实地研究D型虎鲸",
					description: "立即：获得 3 声望。"
				},
				c278: {
					name: "亚马逊馆",
					description: "立即：获得 4 吸引力。\n立即：获得 1 声望。\n立即：获得 2 保育分数。\n放置到至少相邻1个水域格和1个岩石格的位置。"
				},
				c279: {
					name: "海底隧道",
					description: "立即：获得 2 吸引力。\n能够安置 {SeaAnimalTag} (最多2个标记)。 放置到 2个水域格的位置。 相邻1/2个相邻的海洋馆，获得 {Appeal-3} / {Appeal-5} 。"
				},
				c280: {
					name: "重建",
					description: "重新放置已有建筑不再次获得新建收益。终局：建满动物园，获得 5 吸引力。\n不再获得放置奖励。 你可以改变最多3个建筑的位置。 你可以免费放置1个贩售亭和1个休憩亭。"
				},
				c101: {
					name: "物种多元化",
					description: "你的动物园里需要有不同的 动物类目 图标。"
				},
				c102: {
					name: "起源地多元化",
					description: "你的动物园里需要有不同的 大洲 图标。"
				},
				c103: {
					name: "非洲",
					description: "你的动物园里需要有 非洲 图标。"
				},
				c104: {
					name: "美洲",
					description: "你的动物园里需要有 美洲 图标。"
				},
				c105: {
					name: "澳洲",
					description: "你的动物园里需要有 澳洲 图标。"
				},
				c106: {
					name: "亚洲",
					description: "你的动物园里需要有 亚洲 图标。"
				},
				c107: {
					name: "欧洲",
					description: "你的动物园里需要有 欧洲 图标。"
				},
				c108: {
					name: "灵长类",
					description: "你的动物园里需要有 灵长类 图标。"
				},
				c109: {
					name: "爬行类",
					description: "你的动物园里需要有 爬行类 图标。"
				},
				c110: {
					name: "食肉类",
					description: "你的动物园里需要有 食肉类 图标。"
				},
				c111: {
					name: "食草类",
					description: "你的动物园里需要有 食草类 图标。"
				},
				c112: {
					name: "鸟类",
					description: "你的动物园里需要有 鸟类 图标。"
				},
				c113: {
					name: "巴伐利亚森林国家公园",
					description: "将1个具有 欧洲 图标的动物 放归 野外。"
				},
				c114: {
					name: "优胜美地国家公园",
					description: "将1个具有 美洲 图标的动物 放归 野外。"
				},
				c115: {
					name: "安通国家公园",
					description: "将1个具有 亚洲 图标的动物 放归 野外。"
				},
				c116: {
					name: "塞伦盖蒂国家公园",
					description: "将1个具有 非洲 图标的动物 放归 野外。"
				},
				c117: {
					name: "蓝山国家公园",
					description: "将1个具有 澳洲 图标的动物 放归 野外。"
				},
				c118: {
					name: "热带大草原",
					description: "将1个 食肉类 动物 放归 野外。"
				},
				c119: {
					name: "低矮山脉",
					description: "将1个 鸟类 动物 放归 野外。"
				},
				c120: {
					name: "竹林",
					description: "将1个 食草类 动物 放归 野外。"
				},
				c121: {
					name: "海蚀洞",
					description: "将1个 爬行类 动物 放归 野外。"
				},
				c122: {
					name: "丛林",
					description: "将1个 灵长类 动物 放归 野外。"
				},
				c123: {
					name: "鸟类动物繁育计划",
					description: "需要1个 鸟类 动物和 与之相同大洲的 合作动物园 。"
				},
				c124: {
					name: "食肉类动物繁育计划",
					description: "需要1个 食肉类 动物和 与之相同大洲的 合作动物园 。"
				},
				c125: {
					name: "爬行类动物繁育计划",
					description: "需要1个 爬行类 动物和 与之相同大洲的 合作动物园 。"
				},
				c126: {
					name: "食草类动物繁育计划",
					description: "需要1个 食草类 动物和 与之相同大洲的 合作动物园 。"
				},
				c127: {
					name: "灵长类动物繁育计划",
					description: "需要1个 灵长类 动物和 与之相同大洲的 合作动物园 。"
				},
				c128: {
					name: "水生态",
					description: "你的动物园里需要有 水域 图标。"
				},
				c129: {
					name: "地质学",
					description: "你的动物园里需要有 岩石 图标。"
				},
				c130: {
					name: "小型动物",
					description: "你的动物园里需要有 小型动物 。"
				},
				c131: {
					name: "大型动物",
					description: "你的动物园里需要有 大型动物 。"
				},
				c132: {
					name: "科研",
					description: "你的动物园里需要有 研究 图标。"
				},
				c133: {
					name: "海洋动物",
					description: "你的动物园里需要有 海洋类 图标。"
				},
				c134: {
					name: "食肉动物管理计划",
					description: "需要2个 食肉类 图标。"
				},
				c135: {
					name: "鸟类管理计划",
					description: "需要2个 鸟类 图标。"
				},
				c136: {
					name: "爬行类动物管理计划",
					description: "需要2个 爬行类 图标。"
				},
				c137: {
					name: "食草类动物管理计划",
					description: "需要2个 食草类 图标。"
				},
				c138: {
					name: "海洋动物管理计划",
					description: "需要2个 海洋类 图标。"
				},
				c139: {
					name: "灵长类动物管理计划",
					description: "需要2个 灵长类 图标。"
				},
				c001: {
					name: "大型动物公园",
					description: "根据你动物园里的 大型动物 ， 获得 {ConservationPoint} 。"
				},
				c002: {
					name: "小型动物公园",
					description: "根据你动物园里的 小型动物 ， 获得 {ConservationPoint} 。"
				},
				c003: {
					name: "科研动物园",
					description: "根据你动物园里的 研究 图标， 获得 {ConservationPoint} 。"
				},
				c004: {
					name: "主题建筑动物园",
					description: "根据你动物园里的 建筑物 ， 获得 {ConservationPoint} 。 与 所有的水域格相连 ，获得 {ConservationPoint-1} 。 与 所有的岩石格相连 ，获得 {ConservationPoint-1} 。 覆盖 所有的边界格 ，获得 {ConservationPoint-1} 。 完全覆盖 动物园地图 ，获得 {ConservationPoint-1} 。"
				},
				c005: {
					name: "公益保护动物园",
					description: "根据你 支持的保护项目 ， 获得 {ConservationPoint} 。"
				},
				c006: {
					name: "自然动物园",
					description: "根据你动物园里 空置的可建造 六角格 ，获得 {ConservationPoint} 。"
				},
				c007: {
					name: "人气动物园",
					description: "根据你动物园的 声望 ， 获得 {ConservationPoint} 。"
				},
				c008: {
					name: "慈善动物园",
					description: "根据你动物园的 赞助商卡牌 ， 获得 {ConservationPoint} 。"
				},
				c009: {
					name: "综合物种动物园",
					description: "你每有一种 动物类目 图标多于你右手边的玩家，获得 {ConservationPoint-1} ，最多 {ConservationPoint-4} 。"
				},
				c010: {
					name: "岩石公园",
					description: "根据你动物园的 岩石 图标， 获得 {ConservationPoint} 。"
				},
				c011: {
					name: "水生态公园",
					description: "根据你动物园的 水域 图标， 获得 {ConservationPoint} 。"
				},
				c012: {
					name: "时尚动物园",
					description: "根据你动物园里的 不同形状建筑 ， 获得 {ConservationPoint} 。"
				},
				c013: {
					name: "专项栖息动物园",
					description: "选择你 未支持的基础保护项目 上的1个 大洲 图标。 根据那些图标，获得 {ConservationPoint} 。"
				},
				c014: {
					name: "专项物种动物园",
					description: "选择你 未支持的基础保护项目 上的1个 动物类目 图标。 根据那些图标，获得 {ConservationPoint} 。"
				},
				c015: {
					name: "露营野餐区",
					description: "根据 成套的贩售亭和休憩亭 (无需相邻)，获得 {ConservationPoint} 。"
				},
				c016: {
					name: "无障碍动物园",
					description: "根据你动物园中的 卡牌上的条件数 ， 获得 {ConservationPoint} 。"
				},
				c017: {
					name: "国际动物园",
					description: "你每有一种 大洲 图标多于你右手边的玩家，获得 {ConservationPoint-1} ， 你合作动物园 上的图标计作 两次 。最多 {ConservationPoint-4} 。"
				}
			},
			maps: {
				m0: {
					name: "地图 0",
					description: ""
				},
				m1: {
					name: "观测塔",
					description: "每次你将一个与观测塔相邻的标准饲养区翻面至已占据的一面时，获得2魅力。 饲养区必须与观测塔的六角格相邻，而不仅仅是与另外3个岩石格相邻。 这个观测平台对特殊饲养区无效。 如果你将一个动物放归野外(而因此将一个已占用的饲养区翻回闲置的一面)，然后安置一个新动物到该饲养区，你将再次获得2魅力。"
				},
				m2: {
					name: "户外营地",
					description: "与大门相邻的每个标准饲养区的容量+2。 饲养区必须与户外营地的六角格相邻，而不仅仅是与另外4个水域格相邻。 户外营地对特殊饲养区无效。 当安置动物时，你可以将任何与户外营地相邻的标准饲养区，视为扩大2格的饲养区。"
				},
				m3: {
					name: "银湖",
					description: "银湖四周是高利润地区。 maps.desc1-2"
				},
				m4: {
					name: "商业港口",
					description: "如果港口已连接，则被激活：在你每个回合中仅限1次，你可以弃除1张手牌换取3块钱（在任何时候）。 你可以再你回合的前、中、后任意时刻，或是行动中，使用其能力。 你不可以在休息期间或其他玩家的回合中，使用其能力。"
				},
				m5: {
					name: "主题餐厅",
					description: "收入：与餐厅相邻的每个已被覆盖的六角格，获得1收入。 左侧动保奖励: 即使你还没有升级“建造”行动卡牌，你依然能够免费建造这2个指定特殊饲养区中的1个。 餐厅收入与你在这里建造的建筑类型，以及饲养区是否被占用无关。"
				},
				m6: {
					name: "研究院",
					description: "如果研究院已连接，则被激活：每次你打出动物卡牌时，忽略由你选择的1个条件。 一旦激活，你能在缺少1个条件的情况下，打出动物卡牌，但你不能忽略岩石或者水域格的需求。 maps.desc1-3"
				},
				m7: {
					name: "冰淇淋甜品店",
					description: "所有贩售亭都被覆盖的奖励： 收入: 每个贩售亭，获得1块钱额外收入 maps.desc1-2 maps.desc1-3"
				},
				m8: {
					name: "好莱坞山",
					description: "每次你覆盖 H 时，从牌堆中逐一展示卡牌，并将第一张赞助商卡牌加入你的手牌。所有 H 被覆盖：打出赞助商卡牌时，该卡牌强度-1。 左侧动保奖励: 如果未升级“协会”行动卡牌，则不能通过这个奖励来获得第三个合作动物园。 具有H标记的六角格可以如同其它六角格一样被覆盖，这类似于放置奖励，但并不视为一个放置奖励(不能触发考古学家的效果)。每次你放置一个建筑到H标记上时，从牌库中依次展示卡牌，直到你展示了一张赞助商卡牌，将该牌加入手牌并弃置其余展示的卡牌。一旦你覆盖了所有的H标志，则你之后打出的每张赞助商卡牌等级-1。"
				},
				mA: {
					name: "地图 A",
					description: "开局时，你在左下角有一个免费的3格饲养区和一个贩售亭。没有特殊能力。"
				}
			},
			abilities: {
				SPRINT: "疾跑",
				PACK: "群居",
				HUNTER: "狩猎",
				CLEVER: "机灵",
				BOOST_ASSOCIATION: "推动: 协会",
				ACTION_ASSOCIATION: "行动: 协会",
				INVENTIVE_BEAR: "创造力: 熊",
				FULL_THROATED: "呼唤",
				JUMPING: "跳跃",
				INVENTIVE: "创造力",
				MULTIPLIER_ASSOCIATION: "双重: 协会",
				ICONIC_ANIMAL: "标志性动物",
				BOOST_ANIMAL: "推动: 动物",
				SUN_BATHING: "日光浴",
				POUCH: "育儿袋",
				RESISTANCE: "抵抗",
				ASSERTION: "执着",
				BOOST_SPONSORS: "推动: 赞助商",
				FLOCK_ANIMAL: "群集动物",
				ACTION_SPONSORS: "行动：赞助商",
				MULTIPLIER_SPONSORS: "双重: 赞助商",
				DIGGING: "刨挖",
				SPONSOR_MAGNET: "招商",
				VENOM: "毒液",
				DOMINANCE: "支配",
				ACTION_CARDS: "行动：卡牌",
				PILFERING_1: "偷窃 1",
				MULTIPLIER_CARD: "双重: 卡牌",
				PILFERING_2: "偷窃 2",
				INVENTIVE_PRIMARY: "创造力: 灵长类",
				BOOST_CARD: "推动: 卡牌",
				SNAPPING_2: "捕捉 2",
				CONSTRICTION: "缠绕",
				HYPNOSIS: "催眠",
				SNAPPING_1: "捕捉 1",
				SCAVENGING: "食腐",
				POSTURING: "姿态",
				BOOST_BUILDING: "推动: 建造",
				PERCEPTION_4: "洞察力 4",
				DETERMINATION: "果断",
				MULTIPLIER_BUILDING: "双重: 建造",
				PEACOCKING: "炫耀",
				ACTION_BUILDING: "行动: 建造",
				PETTING_ZOO_ANIMAL: "萌宠动物",
				MARK: "标示",
				APPEAL: "魅力",
				TRADE: "交易",
				SEA_ANIMAL_MAGNET: "海洋魅力",
				REEF_MONEY: "金钱",
				SYMBIOSIS: "共生",
				HELPFUL: "助益",
				TAKE_CARD_IN_RANGE: "Take Card in Range",
				REPUTATION: "声望",
				EXTRA_SHIFT: "加班",
				GLIDE: "滑翔",
				CONSERVATION_POINT: "保护点数",
				SHARK_ATTACK: "鲨鱼袭击",
				CUT_DOWN: "削减",
				CAMOUFLAGE: "伪装",
				SCUBA_DIVE: "蛙潜 X",
				MARKETING: "营销",
				ADAPT: "适应",
				MONKEY_GANG: "猴子帮"
			},
			inspectCard: "查看{{name}}",
			zoomIn: "放大园区",
			zoomOut: "缩小园区",
			resetView: "复位园区视角",
			venom: "毒液",
			constriction: "缠绕",
			discardPile: "弃牌 {{n}}",
			partnerZoos: "合作动物园",
			universities: "大学",
			lastTurns: "最后 {{n}} 回合",
			conditions: "条件",
			reviewBoard: "回看动物园",
			reviewHide: "收起结算",
			reviewShow: "查看结算",
			conservationReport: "保育成果",
			winner: "获胜者",
			jointWinners: "共同获胜",
			appealTarget: "对应吸引力门槛",
			finalRewards: "终局卡与赞助商奖励",
			confirmLobby: "确认返回大厅",
			confirmAgain: "确认再来一局",
			zooRewards: "动物园奖励",
			collection: "园区收藏",
			animals: "动物",
			build: "建造",
			cardsAction: "卡牌",
			association: "协会",
			sponsors: "赞助商",
			action: "执行{{action}} · 强度 {{n}}",
			gainX: "获得 1 枚 X 标记",
			finish: "完成行动",
			skip: "放弃",
			chooseMap: "选择动物园地图",
			chooseDraft: "选择一张行动卡",
			chooseVariants: "保留两种不同的行动卡",
			setupDiscard: "保留 4 张起始手牌",
			discard: "弃置卡牌",
			finalDiscard: "弃置一张终局卡",
			resolve: "结算效果",
			gain: "获得{{n}}{{resource}}",
			playCard: "打出卡牌",
			takeCard: "取得卡牌",
			selectHabitat: "选择饲养区",
			habitat: "饲养区 {{n}}",
			flock: "与食草动物共用围栏",
			placeBuilding: "放置建筑",
			buildBuilding: "建造{{building}}",
			placeHere: "放置于此",
			drawDeck: "从牌库抽取卡牌",
			drawCards: "抽取卡牌",
			snap: "抓取市场卡牌",
			sellCard: "出售卡牌",
			pouchCard: "将卡牌放入袋中",
			money: "金钱",
			appeal: "吸引力",
			conservation: "保育分数",
			reputation: "声望",
			x: "X 标记",
			upgrade: "升级行动卡",
			hire: "聘用协会工作人员",
			takePartner: "取得合作动物园",
			takeUniversity: "取得大学",
			taskReputation: "提升 2 点声望",
			support: "支持保育项目",
			projectSlot: "支持档位 {{n}}",
			donate: "捐赠 {{n}} 金钱",
			reward: "选择奖励",
			rewardMoney: "获得 5 金钱",
			ability: "发动卡牌能力",
			moveOne: "移到位置 1",
			moveFive: "移到位置 5",
			tradeX: "支付 1 枚 X 标记，获得 5 金钱",
			tradeMoney: "支付 5 金钱，获得 1 枚 X 标记",
			tradeReputationMoney: "支付 5 金钱，获得 1 点声望",
			tradeReputationX: "支付 1 枚 X 标记，获得 1 点声望",
			mark: "标记市场动物",
			extraShift: "召回协会工作人员",
			cutDown: "拆除空置围栏",
			symbiosis: "选择其他海洋动物的能力",
			release: "放归动物",
			assignmentSmall: "专注小型动物",
			assignmentLarge: "专注大型动物",
			gainAppealPaid: "支付 2 金钱，获得 1 点吸引力",
			sponsorCash: "推进休息标记，获得金钱",
			stealMoney: "给予 5 金钱",
			stealCard: "让对方随机抽走一张手牌",
			targetPlayer: "选择玩家",
			harbor: "港口出售卡牌",
			hand: "手牌",
			market: "市场",
			projects: "保育项目",
			zoo: "动物园",
			finals: "终局卡",
			workers: "工作人员",
			score: "得分",
			turn: "回合 {{n}}",
			breakTrack: "休息 {{n}} / {{max}}",
			wait: "等待{{name}}",
			chooseEffect: "选择要结算的效果",
			inspect: "查看卡牌",
			close: "关闭",
			rotate: "旋转",
			reflect: "翻转",
			confirm: "确认",
			cancel: "取消",
			noPlacement: "没有合适的位置",
			optMarine: "海洋世界",
			marineOn: "基础版＋海洋扩展",
			marineOff: "仅基础版",
			optMaps: "动物园地图",
			mapA: "地图 A",
			map0: "地图 0",
			mapAdvanced: "地图 1–8 中二选一",
			errAction: "此选项已不可用，请重新选择。",
			errTurn: "请等待当前玩家完成选择。",
			logPlay: "打出卡牌",
			logBuild: "放置建筑",
			logTurn: "完成回合",
			logBreak: "开始休息",
			discountSponsor: "弃置卡牌，使下一张赞助商卡的强度降低 2",
			smallProgram: "使用小型动物计划",
			moveAnimal: "将动物迁入新饲养区",
			enlarge: "扩大围栏",
			reconstruct: "选择要重新放置的建筑",
			refillSnap: "补齐市场后抓取",
			sharkAttack: "弃置市场动物并获得吸引力",
			scubaDive: "寻找赞助商",
			sendExpedition: "派出赞助商参加考察",
			logUndoVenom: "金钱不足以支付毒液费用，请重新选择本回合行动。",
			begin: "选择行动",
			useIgnore: "使用忽略条件奖励",
			useRecall: "使用召回工作人员奖励",
			phaseBreak: "休息",
			phaseFinal: "终局计分",
			phaseDone: "游戏结束",
			emptyHand: "没有手牌",
			total: "总分",
			selected: "已选 {{n}} 张",
			cost: "费用 {{n}}",
			strength: "强度 {{n}}",
			effect: "结算{{ability}}",
			placementBonus: "放置奖励",
			supportBonus: "动物园奖励 {{n}}",
			played: "已打出卡牌",
			choose: "选择",
			reselectBuildings: "恢复建筑并重新选择",
			useMarketing: "使用赞助商奖励",
			aquarium: "海洋馆",
			managementHunter: "狩猎：数量为自己的食肉类图标数",
			managementScience: "每 2 个研究图标获得 1 点声望",
			managementSearch: "从牌库寻找 1 张相应动物类别的牌",
			managementReef: "触发所有珊瑚生物能力",
			managementSunbathing: "日光浴 2",
			firstProjectReward: "首次打出另得：{{reward}}",
			projectChoice: "档位 {{n}} · 获得 {{conservation}} 保育分数",
			recurringReward: "立即及每次休息：{{reward}}",
			immediateReward: "立即：{{reward}}",
			spendWildcard: "消耗通配标记：{{card}}",
			releaseChoice: "放归：{{card}}",
			rewardCount: "{{n}} {{reward}}",
			universityHand: "手牌上限为 5",
			universityScience: "2 个研究图标",
			universityReputation: "研究图标与 2 点声望",
			bonusNames: {
				upgrade: "升级行动卡",
				worker: "聘用工作人员",
				partner: "取得合作动物园",
				university: "取得大学",
				sponsorMoney: "支付强度等额金钱打出赞助商",
				multiplier: "乘倍标记",
				specialEnclosure: "大型鸟舍或爬行馆",
				kiosk: "贩售亭",
				wildcard: "通配标记"
			},
			variants: {
				animals1: "若强度允许打出 2 只动物，但只打出 1 只，可以忽略其 1 个条件。",
				animals2: "行动完成后，若手中没有动物，发动狩猎 4；升级后为狩猎 6。",
				animals3: "第 1 只动物费用降低 2；升级后改为每只动物可额外支付 2 金钱，增加 1 吸引力。",
				animals4: "行动完成后标记市场动物；升级后打出自己标记的市场动物还增加 1 声望。",
				build1: "可额外建造 1 座休憩亭，费用 3；升级后费用为 2。",
				build2: "可额外建造 1 座贩售亭，费用 3；升级后费用为 2。",
				build3: "建造强度增加 1；升级后，同种标准围栏可多次建造。",
				build4: "可额外支付 2 金钱覆盖 1 格水域或岩石；升级后改为获得 2 金钱。每次行动限 1 格。",
				cards1: "抽牌后无需弃牌。",
				cards2: "抽牌前发动挖掘 1；升级后为挖掘 2。",
				cards3: "强度 3 即可抓取；升级后强度 2 即可抓取，强度 5 可抓取两次且中途不补牌。",
				cards4: "行动完成后可支付 2 金钱将行动卡移至位置 1；升级后免费。",
				association1: "合作动物园从储备中取得，可以重复；升级后大学也适用。",
				association2: "支持项目时可改为聘用工作人员；升级后可每多派 1 名工作人员，降低该工作所需强度 2。",
				association3: "强度超过所做工作时获得 1 枚 X；升级后改为每枚持有的 X 令捐赠费用降低 1。",
				association4: "强度 5 时可不做工作，改为行动完成后再行动一次；升级后改为可用抽取 1 张牌代替捐赠。",
				sponsors1: "可支付 1 枚 X 换 5 金钱，或反向交换；升级后还可支付 5 金钱或 1 枚 X 换 1 声望。",
				sponsors2: "本次行动中首次获得金钱时额外获得 3；升级后为 5。",
				sponsors3: "可弃置 1 张手中赞助商换 4 金钱；升级后可弃任意牌，也可改为使下一张赞助商强度降低 2。",
				sponsors4: "可弃置手中赞助商，抓取市场赞助商；升级后改为在推进休息时可弃任意牌，并支付卡牌强度的金钱打出手中赞助商。"
			},
			buildings: {
				standard1: "1 格围栏",
				standard2: "2 格围栏",
				standard3: "3 格围栏",
				standard4: "4 格围栏",
				standard5: "5 格围栏",
				kiosk: "贩售亭",
				pavilion: "休憩亭",
				petting: "亲子动物园",
				aviary: "大型鸟舍",
				reptile: "爬行馆",
				aquariumSmall: "小型海洋馆",
				aquariumLarge: "大型海洋馆",
				unique: "专属建筑"
			},
			tags: {
				africa: "非洲",
				americas: "美洲",
				asia: "亚洲",
				australia: "澳洲",
				europe: "欧洲",
				bird: "鸟类",
				herbivore: "食草类",
				predator: "食肉类",
				primate: "灵长类",
				reptile: "爬行类",
				bear: "熊类",
				pet: "亲子动物",
				seaAnimal: "海洋动物",
				science: "研究",
				rock: "岩石",
				water: "水域"
			}
		},
		en: {
			name: "Ark Nova",
			desc: "Build a zoo, introduce animals and support conservation, including Marine Worlds",
			rules: "Objective:\nIncrease appeal by introducing animals and gain conservation points by supporting projects. When the two tracks meet, the other players take one final turn. Add Final Scoring cards and sponsor bonuses. Most supported conservation projects breaks ties.\nActions:\nChoose an action card; its slot determines its strength. Before starting, spend X-tokens to add 1 strength each. Move the used card to slot 1 after completing the action. Alternatively, use any card to gain 1 X-token. You may hold at most 5 X-tokens.\n· Build: Pay 2 per hex for enclosures, special enclosures, kiosks or pavilions. Your first building must touch the border; later buildings must touch an existing building. Kiosks must be at least 3 hexes apart. Upgrading allows several different buildings per action, Large Bird Aviaries, Reptile Houses and marked spaces.\n· Animals: Pay the price, meet conditions and choose a suitable enclosure. Gain appeal, icons and abilities. When upgraded, you may play animals from within reputation range, paying the folder number in addition.\n· Cards: Advance the break token 2 spaces, then draw and discard as shown on the card, or snap from the display at sufficient strength. When upgraded, draws may come from within reputation range. Replenish the display after the entire turn.\n· Association: Assign workers to gain reputation, partner zoos, universities or support conservation projects. Repeating a task requires 2 workers; recall workers during a break. Upgrading permits different tasks in one action and one additional donation.\n· Sponsors: Play sponsors within your strength budget, or advance the break token and gain money. Upgrading permits multiple sponsors and play from within reputation range.\nBreaks:\nWhen the token reaches the end, finish the entire turn before taking a break. Discard to your hand limit, remove action-card tokens, recall workers and replenish the Association board, discard the first two display cards and refill, then take appeal, kiosk and other income. The normal hand limit is 3; the indicated university increases it to 5.\nMarine Worlds:\nUse replacement and additional cards when enabled. Aquariums must touch water. Sea-animal markers may be split among suitable aquariums, each meeting terrain requirements. Playing a Reef Dweller triggers all your Reef Dweller effects once. Each wave revealed when refilling the display discards the lowest card and causes another refill; ignore waves during setup. Draft two different variant actions at setup. New universities provide a research and an animal icon and find one matching card.\nEffect order:\nResolve simultaneous effects in a permitted order of your choice. After-finishing effects resolve after moving the action card to slot 1. If the game end is triggered during a break, every player takes one final turn.",
			cards: {
				c401: {
					name: "CHEETAH",
					description: "Sprint 3：Draw 3 card(s) from the deck."
				},
				c402: {
					name: "LION",
					description: "Pack：Gain {Appeal-1} for each predator icon in your zoo."
				},
				c403: {
					name: "LEOPARD",
					description: "Hunter 4：Reveal the 4 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c404: {
					name: "CARACAL",
					description: "Hunter 2：Reveal the 2 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c405: {
					name: "FENNEC FOX",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c406: {
					name: "SIBERIAN TIGER",
					description: ""
				},
				c407: {
					name: "SUMATRAN TIGER",
					description: ""
				},
				c408: {
					name: "SLOTH BEAR",
					description: "Boost: Association：After finishing this action, you may place your Association Action card {AssociationActionCard} on {Slot-1} or {Slot-5} ."
				},
				c409: {
					name: "SUN BEAR",
					description: "Action: Association：After finishing this action, you may take the Association action {AssociationActionCard} ."
				},
				c410: {
					name: "YELLOW-THROATED MARTEN",
					description: "Hunter 1：Reveal the 1 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c411: {
					name: "GRIZZLY BEAR",
					description: "Inventive: Bear：Gain {XToken} -token for each bear icon in all zoos (max.3). Full-throated：Hire an association worker."
				},
				c412: {
					name: "JAGUAR",
					description: "Hunter 4：Reveal the 4 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c413: {
					name: "COUGAR",
					description: "Jumping 3：Advance the break token 3 spaces. Gain {Money-3}."
				},
				c414: {
					name: "SOUTH AMERICAN COATI",
					description: "Inventive：Gain {XToken} -token."
				},
				c415: {
					name: "RACCOON",
					description: "Boost: Association：After finishing this action, you may place your Association Action card {AssociationActionCard} on {Slot-1} or {Slot-5} ."
				},
				c416: {
					name: "EURASIAN BROWN BEAR",
					description: "Multiplier: Association：Place 1 {MultiplierToken} on your Association Action card {AssociationActionCard} . Full-throated：Hire an association worker."
				},
				c417: {
					name: "WOLF",
					description: "Pack：Gain {Appeal-1} for each predator icon in your zoo."
				},
				c418: {
					name: "EURASIAN LYNX",
					description: "Iconic Animal Europe：Gain {Appeal-1} for each Europe icon in all zoos (max. 8)."
				},
				c419: {
					name: "EUROPEAN BADGER",
					description: "Boost: Animal：After finishing this action, you may place your Animal Action card {AnimalActionCard} on {Slot-1} or {Slot-5} ."
				},
				c420: {
					name: "STOAT",
					description: "Hunter 1：Reveal the 1 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c421: {
					name: "NEW ZEALAND FUR SEAL",
					description: "Full-throated：Hire an association worker."
				},
				c422: {
					name: "AUSTRALIAN SEA LION",
					description: "Sun Bathing 3：You may sell up to 3 card(s) from your hand for {Money-4} each."
				},
				c423: {
					name: "NEW ZEALAND SEA LION",
					description: "Pack：Gain {Appeal-1} for each predator icon in your zoo."
				},
				c424: {
					name: "AUSTRALIAN DINGO",
					description: "Pack：Gain {Appeal-1} for each predator icon in your zoo."
				},
				c425: {
					name: "TASMANIAN DEVIL",
					description: "Pouch 1：You may place 1 card(s) from your hand under this card to gain {Appeal-2} ."
				},
				c426: {
					name: "AFRICAN BUSH ELEPHANT",
					description: "Resistance：Draw 2 Final Scoring cards. Keep 1 and discard the other."
				},
				c427: {
					name: "WHITE RHINOCEROS",
					description: "Assertion：You may add any 1 of the unused base conservation projects to your hand."
				},
				c428: {
					name: "GIRAFFE",
					description: "Boost: Sponsors：After finishing this action, you may place your Sponsors Action card {SponsorsActionCard} on {Slot-1} or {Slot-5} ."
				},
				c429: {
					name: "GREVY'S ZEBRA",
					description: "Boost: Sponsors：After finishing this action, you may place your Sponsors Action card {SponsorsActionCard} on {Slot-1} or {Slot-5} . Flock Animal 2：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c430: {
					name: "PYGMY HIPPOPOTAMUS",
					description: "Action: Sponsors：After finishing this action, you may take the Sponsors Action {SponsorsActionCard} ."
				},
				c431: {
					name: "ASIAN ELEPHANT",
					description: "Resistance：Draw 2 Final Scoring cards. Keep 1 and discard the other."
				},
				c432: {
					name: "INDIAN RHINOCEROS",
					description: "Assertion：You may add any 1 of the unused base conservation projects to your hand."
				},
				c433: {
					name: "GIANT PANDA",
					description: ""
				},
				c434: {
					name: "RED PANDA",
					description: "Multiplier: Sponsors：Place 1 {MultiplierToken} on your Sponsors Action card {SponsorsActionCard} ."
				},
				c435: {
					name: "MALAYAN TAPIR",
					description: "Digging 3：Choose up to 3x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck."
				},
				c436: {
					name: "AMERICAN BISON",
					description: "Iconic Animal Americas：Gain {Appeal-1} for each Americas icon in all zoos (max. 8)."
				},
				c437: {
					name: "MUSKOX",
					description: "Sponsor Magnet：Add all sponsors cards from the display to your hand."
				},
				c438: {
					name: "REINDEER",
					description: "Flock Animal 3：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c439: {
					name: "LAMA",
					description: "Flock Animal 2：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c440: {
					name: "MOUNTAIN TAPIR",
					description: "Digging 2：Choose up to 2x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck."
				},
				c441: {
					name: "EUROPEAN BISON",
					description: "Sponsor Magnet：Add all sponsors cards from the display to your hand."
				},
				c442: {
					name: "MOOSE",
					description: "Multiplier: Sponsors：Place 1 {MultiplierToken} on your Sponsors Action card {SponsorsActionCard} . Flock Animal 4：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c443: {
					name: "RED DEER",
					description: "Flock Animal 3：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c444: {
					name: "ALPINE IBEX",
					description: "Jumping 2：Advance the break token 2 spaces. Gain {Money-2}."
				},
				c445: {
					name: "CRESTED PORCUPINE",
					description: "Digging 2：Choose up to 2x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck."
				},
				c446: {
					name: "DUGONG",
					description: "Digging 4：Choose up to 4x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck."
				},
				c447: {
					name: "RED KANGAROO",
					description: "Pouch 2：You may place 2 card(s) from your hand under this card to gain {Appeal-2} . Flock Animal 4：May share the existing enclosure of a {HerbivoreTag} with {Size-X+}."
				},
				c448: {
					name: "KOALA",
					description: "Pouch 2：You may place 2 card(s) from your hand under this card to gain {Appeal-2} ."
				},
				c449: {
					name: "PLATYPUS",
					description: "Venom 1：Each player ahead of you on the Appeal track gains 1 Venom token(s)."
				},
				c450: {
					name: "COMMON WOMBAT",
					description: "Pouch 1：You may place 1 card(s) from your hand under this card to gain {Appeal-2} ."
				},
				c451: {
					name: "PROBOSCIS MONKEY",
					description: "Dominance：You may add the base conservation project Primates to your hand if it is not already in the game."
				},
				c452: {
					name: "SENEGAL BUSHBABY",
					description: "Iconic Animal africa：Gain {Appeal-1} for each africa icon in all zoos (max. 8)."
				},
				c453: {
					name: "COLLARED MANGABEY",
					description: "Action: Cards：After finishing this action, you may take the Card action {CardsActionCard} ."
				},
				c454: {
					name: "RING-TAILED LEMUR",
					description: "Sun Bathing 3：You may sell up to 3 card(s) from your hand for {Money-4} each."
				},
				c455: {
					name: "MANTLED GUEREZA",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c456: {
					name: "BARBARY MACAQUE",
					description: "Pilfering 1：Draw 1 card from the hand of or take {Money-5} from the player with the most {Appeal}. They decide."
				},
				c457: {
					name: "MANDRILL",
					description: "Multiplier: Card：Place 1 {MultiplierToken} on your Card Action card {CardsActionCard} ."
				},
				c458: {
					name: "JAPANESE MACAQUE",
					description: "Pilfering 2：From both the player with the highest {Appeal} and the player with the most {ConservationPoint}, Draw 1 card from the hand of or take {Money-5} from that player. They decide."
				},
				c459: {
					name: "RED-SHANKED DOUC",
					description: "Inventive: Primary：Gain 1/2/3 {XToken} -tokens for 1/3/5 primate icons in your zoo."
				},
				c460: {
					name: "DUSKY-LEAF MONKEY",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c461: {
					name: "HORSFIELD'S TARSIER",
					description: "Jumping 4：Advance the break token 4 spaces. Gain {Money-4}."
				},
				c462: {
					name: "NORTHERN PLAINS GRAY LANGUR",
					description: "Jumping 3：Advance the break token 3 spaces. Gain {Money-3}."
				},
				c463: {
					name: "PANAMANIAN WHITE-FACED CAPUCHIN",
					description: "Pilfering 1：Draw 1 card from the hand of or take {Money-5} from the player with the most {Appeal}. They decide."
				},
				c464: {
					name: "BROWN SPIDER MONKEY",
					description: "Inventive: Primary：Gain 1/2/3 {XToken} -tokens for 1/3/5 primate icons in your zoo."
				},
				c465: {
					name: "GOLDEN LION TAMARIN",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c466: {
					name: "BOLIVIAN RED HOWLER",
					description: "Boost: Card：After finishing this action, you may place your Card Action card {CardsActionCard} on {Slot-1} or {Slot-5} ."
				},
				c467: {
					name: "ECUADORIAN SQUIRELL MONKEY",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c468: {
					name: "COTTON-TOP TAMARIN",
					description: ""
				},
				c469: {
					name: "NILE CROCODILE",
					description: "Snapping 2：2x: Gain any 1 card from the display. You may replenish in between."
				},
				c470: {
					name: "WESTERN GREEN MAMBA",
					description: "Venom 2：Each player ahead of you on the Appeal track gains 2 Venom token(s)."
				},
				c471: {
					name: "AFRICAN SPURRED TORTOISE",
					description: "Sun Bathing 3：You may sell up to 3 card(s) from your hand for {Money-4} each."
				},
				c472: {
					name: "ROCK MONITOR",
					description: "Sun Bathing 3：You may sell up to 3 card(s) from your hand for {Money-4} each."
				},
				c473: {
					name: "COMMON AGAMA",
					description: "Sun Bathing 2：You may sell up to 2 card(s) from your hand for {Money-4} each."
				},
				c474: {
					name: "INDIAN ROCK PYTHON",
					description: "Constriction：Each player ahead of you on a track gains 1 Constriction token for each of those tracks ( {Appeal} and {ConservationPoint} )."
				},
				c475: {
					name: "KING COBRA",
					description: "Hypnosis 3：After finishing this action, you may take 1 action {ActionCard} from an Action card in slot {Slot-1} , {Slot-2} or {Slot-3} of the player with the most {Appeal}."
				},
				c476: {
					name: "KOMODO DRAGON",
					description: "Iconic Animal asia：Gain {Appeal-1} for each asia icon in all zoos (max. 8)."
				},
				c477: {
					name: "VEILED CHAMELEON",
					description: "Snapping 1：Gain any 1 card from the display."
				},
				c478: {
					name: "CHINESE WATER DRAGON",
					description: "Sun Bathing 2：You may sell up to 2 card(s) from your hand for {Money-4} each."
				},
				c479: {
					name: "AMERICAN ALLIGATOR",
					description: "Snapping 1：Gain any 1 card from the display."
				},
				c480: {
					name: "BROAD-SNOUTED CAIMAN",
					description: "Snapping 1：Gain any 1 card from the display."
				},
				c481: {
					name: "GALAPAGOS GIANT TORTOISE",
					description: "Sun Bathing 4：You may sell up to 4 card(s) from your hand for {Money-4} each."
				},
				c482: {
					name: "ANACONDA",
					description: "Constriction：Each player ahead of you on a track gains 1 Constriction token for each of those tracks ( {Appeal} and {ConservationPoint} )."
				},
				c483: {
					name: "BOA CONSTRICTOR",
					description: "Constriction：Each player ahead of you on a track gains 1 Constriction token for each of those tracks ( {Appeal} and {ConservationPoint} )."
				},
				c484: {
					name: "EUROPEAN POND TURTLE",
					description: ""
				},
				c485: {
					name: "COMMON EUROPEAN ADDER",
					description: "Hypnosis 3：After finishing this action, you may take 1 action {ActionCard} from an Action card in slot {Slot-1} , {Slot-2} or {Slot-3} of the player with the most {Appeal}."
				},
				c486: {
					name: "COMMON WALL LIZARD",
					description: ""
				},
				c487: {
					name: "EUROPEAN GRASS SNAKE",
					description: "Clever：After finishing you may place any Action card on {Slot-1} ."
				},
				c488: {
					name: "SLOW WORM",
					description: ""
				},
				c489: {
					name: "SALTWATER CROCODILE",
					description: "Snapping 2：2x: Gain any 1 card from the display. You may replenish in between."
				},
				c490: {
					name: "GOULD'S MONITOR",
					description: "Scavenging 2：Shuffle the discard pile and draw 2 cards. Add 1 to your hand and discard the other."
				},
				c491: {
					name: "FRILLED LIZARD",
					description: "Sprint 1：Draw 1 card(s) from the deck."
				},
				c492: {
					name: "INLAND TAIPAN",
					description: "Venom 2：Each player ahead of you on the Appeal track gains 2 Venom token(s)."
				},
				c493: {
					name: "THORNY DEVIL",
					description: ""
				},
				c494: {
					name: "AFRICAN OSTRICH",
					description: "Sprint 2：Draw 2 card(s) from the deck."
				},
				c495: {
					name: "SECRETARY BIRD",
					description: ""
				},
				c496: {
					name: "MARABOU",
					description: "Scavenging 2：Shuffle the discard pile and draw 2 cards. Add 1 to your hand and discard the other."
				},
				c497: {
					name: "LESSER FLAMINGO",
					description: "Posturing 1：Up to 1x: You may place 1 free kiosk or pavilion."
				},
				c498: {
					name: "SHOEBILL",
					description: ""
				},
				c499: {
					name: "CINEREOUS VULTURE",
					description: "Scavenging 3：Shuffle the discard pile and draw 3 cards. Add 1 to your hand and discard the other."
				},
				c500: {
					name: "LONG-BILLED VULTURE",
					description: "Scavenging 3：Shuffle the discard pile and draw 3 cards. Add 1 to your hand and discard the other."
				},
				c501: {
					name: "INDIAN PEAFOWL",
					description: "Posturing 2：Up to 2x: You may place 1 free kiosk or pavilion."
				},
				c502: {
					name: "GREAT HORNBILL",
					description: "Boost: Building：After finishing this action, you may place your Building Action card {BuildActionCard} on {Slot-1} or {Slot-5} ."
				},
				c503: {
					name: "SNOWY OWL",
					description: "Perception 4：Draw 4 cards from the deck. Add 2 to your hand and discard the rest."
				},
				c504: {
					name: "ANDEAN CONDOR",
					description: "Scavenging 4：Shuffle the discard pile and draw 4 cards. Add 1 to your hand and discard the other."
				},
				c505: {
					name: "BALD EAGLE",
					description: "Determination：After finishing this action, you take 1 other action {ActionCard} ."
				},
				c506: {
					name: "KING VULTURE",
					description: "Scavenging 5：Shuffle the discard pile and draw 5 cards. Add 1 to your hand and discard the other."
				},
				c507: {
					name: "GREATER RHEA",
					description: "Sprint 1：Draw 1 card(s) from the deck."
				},
				c508: {
					name: "SCARLET MACAW",
					description: "Posturing 3：Up to 3x: You may place 1 free kiosk or pavilion."
				},
				c509: {
					name: "GOLDEN EAGLE",
					description: "Determination：After finishing this action, you take 1 other action {ActionCard} ."
				},
				c510: {
					name: "WHITE STORK",
					description: "Multiplier: Building：Place 1 {MultiplierToken} on your Building Action card {BuildActionCard} ."
				},
				c511: {
					name: "GREATER FLAMINGO",
					description: "Posturing 1：Up to 1x: You may place 1 free kiosk or pavilion."
				},
				c512: {
					name: "EURASIAN EAGLE-OWL",
					description: "Perception 4：Draw 4 cards from the deck. Add 2 to your hand and discard the rest."
				},
				c513: {
					name: "BARN OWL",
					description: "Perception 4：Draw 4 cards from the deck. Add 2 to your hand and discard the rest."
				},
				c514: {
					name: "EMU",
					description: "Peacocking：You may place a Large Bird Aviary {LargeBirdAviary} for free, if possible."
				},
				c515: {
					name: "AUSTRALIAN PELICAN",
					description: "Action: Building：After finishing this action, you may take the Building action {BuildActionCard} ."
				},
				c516: {
					name: "NORTHERN CASSOWARY",
					description: "Multiplier: Building：Place 1 {MultiplierToken} on your Building Action card {BuildActionCard} ."
				},
				c517: {
					name: "LAUGHING KOOKABURRA",
					description: "Iconic Animal australia：Gain {Appeal-1} for each australia icon in all zoos (max. 8)."
				},
				c518: {
					name: "LESSER BIRD-OF-PARADISE",
					description: "Posturing 1：Up to 1x: You may place 1 free kiosk or pavilion."
				},
				c519: {
					name: "(DOMESTIC) GOAT",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c520: {
					name: "SHEEP",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c521: {
					name: "HORSE",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c522: {
					name: "DONKEY",
					description: "Inventive：Gain {XToken} -token. Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c523: {
					name: "DOMESTIC RABBIT",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c524: {
					name: "MANGALICA",
					description: "Digging 1：Choose up to 1x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck. Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c525: {
					name: "GUINEA PIG",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c526: {
					name: "ALPACA",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c527: {
					name: "COCONUT LORIKEET",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c528: {
					name: "BENNETT'S WALLABY",
					description: "Pouch 1：You may place 1 card(s) from your hand under this card to gain {Appeal-2} . Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c529: {
					name: "MAGNIFICENT SEA ANEMONE",
					description: "Mark：After finishing this action, mark 1 Animal card in the display."
				},
				c530: {
					name: "ORANGE CLOWNFISH",
					description: ""
				},
				c531: {
					name: "PALETTE SURGEONFISH",
					description: "Trade：You may trade exactly 1 {XToken} -Marker for {Money-5} or vice versa."
				},
				c532: {
					name: "ZOOPLANKTON",
					description: "Sea Animal Magnet：Add all cards with the {SeaAnimalTag} icon from the display to your hand."
				},
				c533: {
					name: "BLACKSIDE HAWKFISH",
					description: "Posturing 1：Up to 1x: You may place 1 free kiosk or pavilion."
				},
				c534: {
					name: "SOUTHERN BLUE-RINGED OCTOPUS",
					description: "Venom 1：Each player ahead of you on the Appeal track gains 1 Venom token(s)."
				},
				c535: {
					name: "SHARKNOSE GOBY",
					description: "Symbiosis：Use 1 ability (not a Reef Dweller effect) of 1 other {SeaAnimalTag} card in your zoo. Helpful：No Reef Dweller effect of its own."
				},
				c536: {
					name: "LONGHORN COWFISH",
					description: "Boost: Sponsors：After finishing this action, you may place your Sponsors Action card {SponsorsActionCard} on {Slot-1} or {Slot-5} ."
				},
				c537: {
					name: "BLACKBAR TRIGGERFISH",
					description: "Constriction：Each player ahead of you on a track gains 1 Constriction token for each of those tracks ( {Appeal} and {ConservationPoint} )."
				},
				c538: {
					name: "DEVIL FIREFISH",
					description: "Venom 1：Each player ahead of you on the Appeal track gains 1 Venom token(s)."
				},
				c539: {
					name: "AMERICAN WHITESPOTTED FILEFISH",
					description: ""
				},
				c540: {
					name: "GUINEAFOWL PUFFER",
					description: "Venom 1：Each player ahead of you on the Appeal track gains 1 Venom token(s)."
				},
				c541: {
					name: "BLUESPOTTED RIBBONTAIL RAY",
					description: "Digging 1：Choose up to 1x: Discard 1 card from the display and replenish OR discard 1 card from your hand and draw 1 other from the deck."
				},
				c542: {
					name: "HUMPHEAD WRASSE",
					description: "Extra Shift：You may return 1 of your association workers to your notepad."
				},
				c543: {
					name: "COASTAL MANTA RAY",
					description: "Glide 3：Discard up to 3 cards from your hand: For every {SeaAnimalTag} icon on them, gain 1 of these 3 effects: {Reputation-1} / {Appeal-2} / {Kiosk} ."
				},
				c544: {
					name: "CARIBBEAN REEF SHARK",
					description: "Shark Attack 1：Discard 1 Animal card(s) in reputation range from the display: Gain half the {Appeal} of those cards (round down)."
				},
				c545: {
					name: "LONGCOMB SAWFISH",
					description: "Cut Down：You may remove 1 empty standard enclosure from your zoo map and gain back its cost."
				},
				c546: {
					name: "SAND TIGER SHARK",
					description: "Shark Attack 2：Discard 2 Animal card(s) in reputation range from the display: Gain half the {Appeal} of those cards (round down)."
				},
				c547: {
					name: "MEDITERRANEAN RAINBOW",
					description: "Symbiosis：Use 1 ability (not a Reef Dweller effect) of 1 other {SeaAnimalTag} card in your zoo."
				},
				c548: {
					name: "LINED SEAHORSE",
					description: "Camouflage：If you play 1 other animal during this turn, you may ignore 1 of its conditions Pouch 1：You may place 1 card(s) from your hand under this card to gain {Appeal-2} ."
				},
				c549: {
					name: "COMMON OCTOPUS",
					description: "Camouflage：If you play 1 other animal during this turn, you may ignore 1 of its conditions"
				},
				c550: {
					name: "COMPASS JELLYFISH",
					description: "Glide 2：Discard up to 2 cards from your hand: For every {SeaAnimalTag} icon on them, gain 1 of these 3 effects: {Reputation-1} / {Appeal-2} / {Kiosk} ."
				},
				c551: {
					name: "LOGGERHEAD SEA TURTLE",
					description: "Scuba Dive X：Reveal the X topmost cards of the deck. Choose 1 Sponsor card and add it to your hand. Discard the other cards. X is the number of {SeaAnimalTag} + {ReptileTag} in your zoo. Marketing：{Marketing} ."
				},
				c552: {
					name: "GREEN SEA TURTLE",
					description: "Scuba Dive X：Reveal the X topmost cards of the deck. Choose 1 Sponsor card and add it to your hand. Discard the other cards. X is the number of {SeaAnimalTag} + {ReptileTag} in your zoo."
				},
				c553: {
					name: "TAMBAQUI",
					description: "Adapt 1：Draw 1 Final Scoring cards, then discard 1 Final Scoring cards."
				},
				c554: {
					name: "AFRICAN PENGUIN",
					description: "Adapt 2：Draw 2 Final Scoring cards, then discard 2 Final Scoring cards."
				},
				c555: {
					name: "GOLDEN SNUB-NOSED MONKEY",
					description: "Pilfering 1：Draw 1 card from the hand of or take {Money-5} from the player with the most {Appeal}. They decide."
				},
				c556: {
					name: "WOLVERINE",
					description: "Boost: Association：After finishing this action, you may place your Association Action card {AssociationActionCard} on {Slot-1} or {Slot-5} ."
				},
				c557: {
					name: "Vietnamese Pot-Bellied Pig",
					description: "Petting Zoo Animal：Gain {Appeal-3} for each Petting Zoo Animal icon in your zoo."
				},
				c558: {
					name: "NORTHERN MURIQUI",
					description: "Monkey Gang：Reveal cards from the deck. Take the first card with {PrimateTag} into your hand. Tuck the other cards under the deck."
				},
				c559: {
					name: "COQUERELS SIFAKA",
					description: "Monkey Gang：Reveal cards from the deck. Take the first card with {PrimateTag} into your hand. Tuck the other cards under the deck. Jumping 2：Advance the break token 2 spaces. Gain {Money-2}."
				},
				c560: {
					name: "BRAHMINY KITE",
					description: "Hunter 2：Reveal the 2 topmost card(s) of the deck. Choose 1 Animal card and add it to your hand. Discard the other cards."
				},
				c201: {
					name: "SCIENCE LAB",
					description: "When played and during each break, take 1 card from the deck or within reputation range. Endgame: gain 1/2 conservation for 3–5/6+ science icons.\nTake 1 card from the deck or in reputation range. Take 1 card from the deck or in reputation range. Gain {ConservationPoint-1} / {ConservationPoint-2} for 3 / 6 research icons."
				},
				c202: {
					name: "SPOKESPERSON",
					description: "Each time you play a research icon into your zoo, gain {Reputation-1} ."
				},
				c203: {
					name: "VETERINARIAN",
					description: "Immediately gain 2/5/10 money for 1/2/3 universities. Endgame: gain 1 conservation for 3 universities.\nSupporting a conservation project requires only {Slot-4} ."
				},
				c204: {
					name: "SCIENCE MUSEUM",
					description: "Immediately gain 2 money per science icon.\nEach time you play a research icon into your zoo, gain {ConservationPoint-1} ."
				},
				c205: {
					name: "GORILLA FIELD RESEARCH",
					description: "Immediately gain 2 reputation.\nImmediately gain 1 conservation."
				},
				c206: {
					name: "MEDICAL BREAKTHROUGH",
					description: "Immediately gain 2 appeal per conservation project you have supported.\nIncome: Gain {ConservationPoint-1} ."
				},
				c207: {
					name: "BASIC RESEARCH",
					description: "Gain {ConservationPoint-1} each for 2 different continent and/or animal category icons. For each {ConservationPoint-1} that you gain this way, all other players gain {Money-2} ."
				},
				c208: {
					name: "SCIENCE LIBRARY",
					description: "Immediately gain 1 appeal per science icon.\nEach time a research icon is played into any zoo, gain {Money-2} . Gain {ConservationPoint-1} for 5 different animal category icons."
				},
				c209: {
					name: "TECHNOLOGY INSTITUTE",
					description: "Immediately gain 1 X-token. Endgame: gain 1 conservation for 3 universities.\nIncome: Gain 1 {XToken} -token."
				},
				c210: {
					name: "EXPERT ON THE AMERICAS",
					description: "Immediately gain 1 appeal per Americas icon. Endgame: gain 1 conservation for at least 5 kiosks.\nEach time you play an Americas icon into your zoo, you may build 1 kiosk for free."
				},
				c211: {
					name: "EXPERT ON EUROPE",
					description: "Immediately gain 1 appeal per Europe icon. Endgame: gain 1 conservation for at least 5 occupied 1-space enclosures.\nEach time you play a Europe icon into your zoo, you may build a 1-space enclosure for free."
				},
				c212: {
					name: "EXPERT ON AUSTRALIA",
					description: "Immediately gain 1 appeal per Australia icon.\nEach time you play an Australia icon into your zoo, you may place 1 card from your hand under this card to gain {Appeal-2} (pouch 1)."
				},
				c213: {
					name: "EXPERT ON ASIA",
					description: "Immediately gain 1 appeal per Asia icon.\nEach time you play an Asia icon into your zoo, you may build 1 pavilion for free."
				},
				c214: {
					name: "EXPERT ON AFRICA",
					description: "Immediately gain 1 appeal per Africa icon. Endgame: gain 1 appeal per X-token you hold.\nEach time you play an Africa icon into your zoo, you may place any action card on {Slot-1} ."
				},
				c215: {
					name: "BREEDING COOPERATION",
					description: "When playing this card, place 2 player tokens on it. When supporting a base conservation project, you may discard exactly 1 token as any icon. Gain {ConservationPoint-1} for 5 supports of conservation projects."
				},
				c216: {
					name: "TALENTED COMMUNICATOR",
					description: "Endgame: gain 1 conservation for at least 9 reputation.\nHire 1 association worker. (Full-throated)."
				},
				c217: {
					name: "ENGINEER",
					description: "Endgame: gain 5 appeal for a completely covered zoo.\nEach time you build at least 1 building with a Build action {BuildActionCard} . you may build exactly 1 more of the same kind (except for special enclosures) at the normal cost."
				},
				c218: {
					name: "BREEDING PROGRAM",
					description: "When playing this card, place 2 player tokens on it. When supporting a base conservation project, you may discard exactly 1 token as any icon. Gain {ConservationPoint-1} for 5 supports of conservation projects."
				},
				c219: {
					name: "DIVERSITY RESEARCHER",
					description: "Endgame: gain 2 appeal per pair of water and rock icons, up to 3 pairs.\nYou may build over water and rock spaces. Ignore all requirements for water and rock spaces. Gain {Money-2} for each water and rock requirement."
				},
				c220: {
					name: "FEDERAL GRANTS",
					description: "Immediately gain 3 money. Endgame: gain 1 conservation for at least 9 reputation.\nIncome: Gain {Money-3} ."
				},
				c221: {
					name: "ARCHEOLOGIST",
					description: "Endgame: gain 1 conservation for covering every building space on the border.\nEach time you gain the placement bonus of a border space in your zoo, you additionally gain another free placement bonus."
				},
				c222: {
					name: "RELEASE OF PATENTS",
					description: "This card grants at most 3 conservation.\nGain {ConservationPoint-1} each for each research icon. For each {ConservationPoint-1} that you gain this way, all other players gain {Money-2} ."
				},
				c223: {
					name: "SCIENCE INSTITUTE",
					description: ""
				},
				c224: {
					name: "MIGRATION RECORDING",
					description: "Immediately gain 1 X-token.\nEach time you support a Release into the Wild conservation project, additionally gain {ConservationPoint-1} . You may support every Release into the Wild conservation project more than once."
				},
				c225: {
					name: "QUARANTINE LAB",
					description: "Immediately gain 1 X-token.\nThe effects of Venom, Constriction, Hypnosis, and Pilfering do not affect you. Gain {ConservationPoint-1} for 5 different continent icons."
				},
				c226: {
					name: "FOREIGN INSTITUTE",
					description: "Immediately gain 2 reputation.\nGain {ConservationPoint-1} for 5 different continent icons."
				},
				c227: {
					name: "WAZA SPECIAL ASSIGNMENT",
					description: "Choose small or large animals; you cannot play the other size for the rest of the game. You may still play 3-space animals.\nChoose and mark on this card. Successively reveal cards from the deck and take the first card of the chosen kind. You must not play the other kind any more. Each time you play a small or large animal, you gain {Appeal-2} or {Appeal-4} respectively."
				},
				c228: {
					name: "WAZA SMALL ANIMAL PROGRAM",
					description: "Immediately gain 2 money per small animal.\nEach time you play only small animals in the Animals action {AnimalActionCard} , you may play 1 further small animal at the normal cost. After that, take 1 small animal from the display (if available)."
				},
				c229: {
					name: "EXPERT IN SMALL ANIMALS",
					description: "Immediately gain 1 appeal per small animal.\nYour cost to play a small animal is reduced by {Money-3} ."
				},
				c230: {
					name: "EXPERT IN LARGE ANIMALS",
					description: "Immediately gain 2 appeal per large animal.\nYour cost to play a large animal is reduced by {Money-4} ."
				},
				c231: {
					name: "SPONSORSHIP: PRIMATES",
					description: "Immediately gain 1 appeal per primate icon.\nIncome: Gain {Money-3} / {Money-6} / {Money-9} for 1/3/5 primate icons in your zoo."
				},
				c232: {
					name: "SPONSORSHIP: REPTILES",
					description: "Immediately gain 1 appeal per reptile icon.\nIncome: Gain {Money-3} / {Money-6} / {Money-9} for 1/3/5 reptile icons in your zoo."
				},
				c233: {
					name: "SPONSORSHIP: VULTURES",
					description: "Immediately gain 1 appeal per bird icon.\nIncome: Gain {Money-3} / {Money-6} / {Money-9} for 1/3/5 bird icons in your zoo."
				},
				c234: {
					name: "SPONSORSHIP: LIONS",
					description: "Immediately gain 1 appeal per predator icon.\nIncome: Gain {Money-3} / {Money-6} / {Money-9} for 1/3/5 predator icons in your zoo."
				},
				c235: {
					name: "SPONSORSHIP: ELEPHANTS",
					description: "Immediately gain 1 appeal per herbivore icon.\nIncome: Gain {Money-3} / {Money-6} / {Money-9} for 1/3/5 herbivore icons in your zoo."
				},
				c236: {
					name: "PRIMATOLOGIST",
					description: "Each time a primate icon is played into any zoo, gain {Money-3} ."
				},
				c237: {
					name: "HERPETOLOGIST",
					description: "Each time a reptile icon is played into any zoo, gain {Money-3} ."
				},
				c238: {
					name: "ORNITHOLOGIST",
					description: "Each time a bird icon is played into any zoo, gain {Money-3} ."
				},
				c239: {
					name: "EXPERT IN PREDATORS",
					description: "Each time a predator icon is played into any zoo, gain {Money-3} ."
				},
				c240: {
					name: "EXPERT IN HERBIVORES",
					description: "Each time a herbivore icon is played into any zoo, gain {Money-3} ."
				},
				c241: {
					name: "HYDROLOGIST",
					description: "Immediately gain 1 appeal per water icon.\nFor each space you cover that is next to a water space, gain {Money-1} . Gain {ConservationPoint-1} , if all water spaces are connected."
				},
				c242: {
					name: "GEOLOGIST",
					description: "Immediately gain 3 appeal per 2 rock icons.\nFor each space you cover that is next to a rock space, gain {Money-1} . Gain {ConservationPoint-1} , if all rock spaces are connected."
				},
				c243: {
					name: "MEERKAT DEN",
					description: "Endgame: gain 1 conservation for at least 6 herbivore icons.\nEach time you play a herbivore icon into your zoo, gain {Appeal-2} . Place next to at least 1 rock space."
				},
				c244: {
					name: "PENGUIN POOL",
					description: "Endgame: gain 1 conservation for at least 6 bird icons.\nEach time you play a bird icon into your zoo, gain {Appeal-2} . Place next to at least 1 water space."
				},
				c245: {
					name: "AQUARIUM",
					description: "Endgame: gain 1 conservation for at least 6 water icons.\nEach time you play a water icon into your zoo, gain {Appeal-2} . Place next to at least 2 water spaces."
				},
				c246: {
					name: "CABLE CAR",
					description: "Endgame: gain 1 conservation for at least 6 rock icons.\nEach time you play a rock icon into your zoo, gain {Appeal-2} . Place next to at least 2 rock spaces."
				},
				c247: {
					name: "BABOON ROCK",
					description: "Endgame: gain 1 conservation for at least 6 primate icons.\nEach time you play a primate icon into your zoo, gain {Appeal-2} . Place next to at least 1 rock space."
				},
				c248: {
					name: "RHESUS MONKEY PARK",
					description: "Each time you play a primate icon into your zoo, gain 1 {XToken} -token."
				},
				c249: {
					name: "BARRED OWL HUT",
					description: "Each time you play a bird icon into your zoo, draw 2 cards from the deck. Keep 1 and discard the other (Perception 2)."
				},
				c250: {
					name: "SEA TURTLE TANK",
					description: "Gain 4 money per card sold.\nEach time you play a reptile icon into your zoo, you may sell up to 2 cards from your hand for each (Sunbathing 2)."
				},
				c251: {
					name: "POLAR BEAR EXHIBIT",
					description: "Endgame: gain 1/2 conservation for 3–5/6+ bear icons.\nEach time a bear icon is played into any zoo, gain {Appeal-2} ."
				},
				c252: {
					name: "SPOTTED HYENA COMPOUND",
					description: "Each time you play a predator icon into your zoo, reveal the topmost X cards of the deck. Add 1 animal card to your hand. Discard the other cards. (X = number of your predator icons) ."
				},
				c253: {
					name: "OKAPI STABLE",
					description: "Place 3 player tokens on this card. Each time you play a Herbivore icon into your zoo, you may remove 1 token and play a sponsors card for {Money-X} ( {Money-X} = {Slot-X} )."
				},
				c254: {
					name: "ZOO SCHOOL",
					description: "Immediately gain 1 reputation.\nImmediately gain 1 conservation.\nPlace on at least 2 border spaces. Take 1 card from the deck or in reputation range."
				},
				c255: {
					name: "ADVENTURE PLAYGROUND",
					description: "Immediately gain 4 appeal.\nPlace next to at least 1 rock space."
				},
				c256: {
					name: "WATER PLAYGROUND",
					description: "Immediately gain 4 appeal.\nPlace next to at least 1 water space."
				},
				c257: {
					name: "SIDE ENTRANCE",
					description: "Place on 2 border spaces. Need not be adjacent to other buildings. Income: Gain {Money-2} for each building, except empty standard enclosures, next to the side entrance. Gain {Appeal-5} if zoo is completely covered."
				},
				c258: {
					name: "NATIVE SEABIRDS",
					description: "Gain {Appeal-1} for each connected water space. Gain {ConservationPoint-1} for each 2 unconnected water spaces."
				},
				c259: {
					name: "NATIVE LIZARDS",
					description: "Gain {Appeal-1} for each connected rock space. Gain {ConservationPoint-1} for each 2 unconnected rock spaces."
				},
				c260: {
					name: "NATIVE FARM ANIMALS",
					description: "Gain {Appeal-1} for each connected border space without buildings. Gain {ConservationPoint-1} for each group of 6 spaces without buildings."
				},
				c261: {
					name: "GUIDED SCHOOL TOURS",
					description: "Immediately gain 1 appeal.\nImmediately gain 1 conservation.\nGain {ConservationPoint-1} for 5 different animal category icons."
				},
				c262: {
					name: "EXPLORER",
					description: "A repeated icon on the same card grants the new-icon bonus only once.\nEach time you gain a continent or animal category icon that is not yet in your zoo, gain {Appeal-1} and {Money-2} . {Money-2} for each different continent or animal category icon in your zoo."
				},
				c263: {
					name: "WAZA LARGE ANIMAL PROGRAM",
					description: "If you play a large animal, you may ignore 1 condition of your choice. You may place 1 5-space enclosure for free."
				},
				c264: {
					name: "FREE-RANGE NEW WORLD MONKEYS",
					description: "Gain {Appeal-1} for each connected space with a placement bonus. Gain {ConservationPoint-1} for each 2 unconnected spaces with a placement bonus."
				},
				c265: {
					name: "FRANCHISE BUSINESS",
					description: "Immediately gain 2 appeal.\nGain {Money-1} for each kiosk in other zoos. Place a kiosk. If you have 5 kiosks, gain {ConservationPoint-1} ."
				},
				c266: {
					name: "MARINE BIOLOGIST",
					description: "Each time a sea animal icon is played into any zoo, gain {Money-3} ."
				},
				c267: {
					name: "FARM CAT",
					description: "Immediately gain 1/3/5 appeal for a total of 1–3/4–6/7+ kiosks and pavilions.\nGain {ConservationPoint-1} for each {Kiosk} with at least 3 empty building spaces next to it (max. {ConservationPoint-3} )."
				},
				c268: {
					name: "CONFERENCE ON EUROPE",
					description: "Immediately gain 2/5/10 money for 1–2/3–4/5+ Europe icons.\nEach time you play a Europe icon into your zoo, you may mark 1 Animal card after finishing the current action. Gain {ConservationPoint-1} if you did 3 donations."
				},
				c269: {
					name: "CONFERENCE ON AUSTRALIA",
					description: "Each time you play an Australia icon into your zoo, you may increase the size of a standard enclosure by 1 for free. If the enclosure is occupied, gain {Appeal-2} . Gain {Appeal-1} for each card pouched (max. 5)."
				},
				c270: {
					name: "MARINE RESEARCH EXPEDITION",
					description: "Expedition | You may send a person Sponsor card in your zoo away (discard) to gain {ConservationPoint-1} OR Scuba Dive 3 | Reveal the 3 topmost cards of the deck. Choose 1 Sponsor card and add it to your hand. Discard the other cards."
				},
				c271: {
					name: "EXCAVATION SITE",
					description: "Gain placement bonuses twice for placing this building. Gain {ConservationPoint-1} if all placement bonuses are covered."
				},
				c272: {
					name: "EXPANSION AREA",
					description: "Immediately place 1 free 3-space enclosure.\nTreat all 3-space enclosures on at least 1 border space as 5-space enclosures. Gain {ConservationPoint-1} if all border spaces are covered."
				},
				c273: {
					name: "PUBLICATIONS",
					description: "When making a donation, pay {Money-1} less for each {ScienceIcon} in your zoo. You may make 1 donation."
				},
				c274: {
					name: "MASCOT STATUE",
					description: "Immediately gain 1 appeal.\nIncome: Gain {Appeal-1} . Gain {Appeal-2} for each zoo with higher appeal (score last)."
				},
				c275: {
					name: "HORSE WHISPERER",
					description: "Each time a Petting Zoo Animal icon is played into any zoo , gain {Money-2} . Search the discard pile for 1 Petting Zoo Animal and take it into hand."
				},
				c276: {
					name: "LANDSCAPE GARDENER",
					description: "Immediately place 1 pavilion for free, then gain 1 appeal per pavilion.\nEach time you build a pavilion, gain 1 {XToken} -marker (max. 1 per action)."
				},
				c277: {
					name: "FIELD RESEARCH TYPE D ORCAS",
					description: "Immediately gain 3 reputation."
				},
				c278: {
					name: "AMAZON HOUSE",
					description: "Immediately gain 4 appeal.\nImmediately gain 1 reputation.\nImmediately gain 2 conservation.\nPlace next to at least 1 water space and 1 rock space."
				},
				c279: {
					name: "UNDERWATER TUNNEL",
					description: "Immediately gain 2 appeal.\nCan accommodate {SeaAnimalTag} (max. 2 markers). Place on 2 water spaces. Gain {Appeal-3} / {Appeal-5} for 1/2 adjacent aquariums."
				},
				c280: {
					name: "RECONSTRUCTION",
					description: "Repositioned buildings do not grant their construction benefits again. Endgame: gain 5 appeal for a completely covered zoo.\nDo not gain placement bonuses anymore. You may reposition up to 3 buildings. You may build 1 pavilion and 1 kiosk."
				},
				c101: {
					name: "SPECIES DIVERSITY",
					description: "Requires different animal category icons in your zoo."
				},
				c102: {
					name: "HABITAT DIVERSITY",
					description: "Requires different continent icons in your zoo."
				},
				c103: {
					name: "AFRICA",
					description: "Requires Africa icons in your zoo."
				},
				c104: {
					name: "AMERICAS",
					description: "Requires Americas icons in your zoo."
				},
				c105: {
					name: "AUSTRALIA",
					description: "Requires Australia icons in your zoo."
				},
				c106: {
					name: "ASIA",
					description: "Requires Asia icons in your zoo."
				},
				c107: {
					name: "EUROPE",
					description: "Requires Europe icons in your zoo."
				},
				c108: {
					name: "PRIMATES",
					description: "Requires primate icons in your zoo."
				},
				c109: {
					name: "REPTILES",
					description: "Requires reptile icons in your zoo."
				},
				c110: {
					name: "PREDATORS",
					description: "Requires predator icons in your zoo."
				},
				c111: {
					name: "HERBIVORES",
					description: "Requires herbivore icons in your zoo."
				},
				c112: {
					name: "BIRDS",
					description: "Requires bird icons in your zoo."
				},
				c113: {
					name: "BAVARIAN FOREST NATIONAL PARK",
					description: "Release 1 animal with Europe icon into the wild."
				},
				c114: {
					name: "YOSEMITE NATIONAL PARK",
					description: "Release 1 animal with Americas icon into the wild."
				},
				c115: {
					name: "ANGTHONG NATIONAL PARK",
					description: "Release 1 animal with Asia icon into the wild."
				},
				c116: {
					name: "SERENGETI NATIONAL PARK",
					description: "Release 1 animal with Africa icon into the wild."
				},
				c117: {
					name: "BLUE MOUNTAINS NATIONAL PARK",
					description: "Release 1 animal with Australia icon into the wild."
				},
				c118: {
					name: "SAVANNA",
					description: "Release 1 predator into the wild."
				},
				c119: {
					name: "LOW MOUNTAIN RANGE",
					description: "Release 1 bird into the wild."
				},
				c120: {
					name: "BAMBOO FOREST",
					description: "Release 1 herbivore into the wild."
				},
				c121: {
					name: "SEA CAVE",
					description: "Release 1 reptile into the wild."
				},
				c122: {
					name: "JUNGLE",
					description: "Release 1 primate into the wild."
				},
				c123: {
					name: "BIRD BREEDING PROGRAM",
					description: "Requires 1 bird and a partner zoo of the same continent."
				},
				c124: {
					name: "PREDATOR BREEDING PROGRAM",
					description: "Requires 1 predator and a partner zoo of the same continent."
				},
				c125: {
					name: "REPTILE BREEDING PROGRAM",
					description: "Requires 1 reptile and a partner zoo of the same continent."
				},
				c126: {
					name: "HERBIVORE BREEDING PROGRAM",
					description: "Requires 1 herbivore and a partner zoo of the same continent."
				},
				c127: {
					name: "PRIMATE BREEDING PROGRAM",
					description: "Requires 1 primate and a partner zoo of the same continent."
				},
				c128: {
					name: "AQUATIC",
					description: "Requires water icons in your zoo."
				},
				c129: {
					name: "GEOLOGICAL",
					description: "Requires rock icons in your zoo."
				},
				c130: {
					name: "SMALL ANIMALS",
					description: "Requires small animals in your zoo."
				},
				c131: {
					name: "LARGE ANIMALS",
					description: "Requires large animals in your zoo."
				},
				c132: {
					name: "RESEARCH",
					description: "Requires research icons in your zoo."
				},
				c133: {
					name: "SEA ANIMALS",
					description: "Requires **sea** **animal** icons <br> in your zoo."
				},
				c134: {
					name: "PREDATOR MANAGEMENT PLAN",
					description: "Requires 2 predator icons."
				},
				c135: {
					name: "BIRD MANAGEMENT PLAN",
					description: "Requires 2 bird icons."
				},
				c136: {
					name: "REPTILE MANAGEMENT PLAN",
					description: "Requires 2 reptile icons."
				},
				c137: {
					name: "HERBIVORE MANAGEMENT PLAN",
					description: "Requires 2 herbivore icons."
				},
				c138: {
					name: "SEA ANIMAL MANAGEMENT PLAN",
					description: "Requires 2 seaAnimal icons."
				},
				c139: {
					name: "PRIMATE MANAGEMENT PLAN",
					description: "Requires 2 primate icons."
				},
				c001: {
					name: "Large Animal Zoo",
					description: "Gain {ConservationPoint} for large animals in your zoo."
				},
				c002: {
					name: "Small Animal Zoo",
					description: "Gain {ConservationPoint} for small animals in your zoo."
				},
				c003: {
					name: "Research Zoo",
					description: "Gain {ConservationPoint} for research icons in your zoo."
				},
				c004: {
					name: "Architectural Zoo",
					description: "Gain {ConservationPoint} for building of your zoo. {ConservationPoint-1} for connecting all water spaces . {ConservationPoint-1} for connecting all rock spaces . {ConservationPoint-1} for connecting all boarder spaces . {ConservationPoint-1} for completely covering the zoo map ."
				},
				c005: {
					name: "Conservation Zoo",
					description: "Gain {ConservationPoint} for supporting conservation projects"
				},
				c006: {
					name: "Naturalists Zoo",
					description: "Gain {ConservationPoint} for empty building spaces in your zo0."
				},
				c007: {
					name: "Favorite Zoo",
					description: "Gain {ConservationPoint} for the reputation of your zoo."
				},
				c008: {
					name: "Sponsored Zoo",
					description: "Gain {ConservationPoint} for sponsors cards in your zoo."
				},
				c009: {
					name: "Diverse Species Zoo",
					description: "Gain {ConservationPoint-1} for each animal category icon of which you have more than the person to your right. Max. {ConservationPoint-4} ."
				},
				c010: {
					name: "Climbing Park",
					description: "Gain {ConservationPoint} for rock icons in your zoo."
				},
				c011: {
					name: "Aquatic Park",
					description: "Gain {ConservationPoint} for water icons in your zoo."
				},
				c012: {
					name: "Designer Zoo",
					description: "Gain {ConservationPoint} for different shaped buildings in your zoo."
				},
				c013: {
					name: "Specialized Habitat Zoo",
					description: "Choose 1 continent icon you did not support a Base Conservation Project with. Gain {ConservationPoint} for those icons."
				},
				c014: {
					name: "Specialized Species Zoo",
					description: "Choose 1 animal category icon you did not support a Base Conservation Project with. Gain {ConservationPoint} for those icons."
				},
				c015: {
					name: "Catered Picnic Areas",
					description: "Gain {ConservationPoint} for sets of kiosk and pavilion (do not have to be adjacent)."
				},
				c016: {
					name: "Accessible Zoo",
					description: "Gain {ConservationPoint} for conditions on cards in your zoo."
				},
				c017: {
					name: "International Zoo",
					description: "Gain {ConservationPoint-1} for each continent icon of which you have more than the person to your right. Icons on your partner zoos count twice . Max. {ConservationPoint-4} ."
				}
			},
			maps: {
				m0: {
					name: "Map 0",
					description: ""
				},
				m1: {
					name: "Observation Tower",
					description: "Gain 2 Appeals every time you flip a standard enclosure to its occupied side next to the Observation Tower. The enclosure must be adjacent to the space with the tower, not merely to any one of the other 3 rock spaces. The platform has no effect on special enclosures. If you release an animal into the wild (and thus flip an occupied enclosure back to the empty side) and then accommodate a new animal in this enclosure, you gain the 2 appeal again. The Observation Tower itself does not count as a building (e. g. for kiosks)."
				},
				m2: {
					name: "Outdoor Areas",
					description: "Each standard enclosure adjacent to Gates has +2 capacity. After placing any standard enclosure adjacent to the Outdoor Areas, you treat it as if it were 2 spaces larger for all purposes (e. g. release). The enclosure must be adjacent to the space with the Outdoor Area, not merely to any one of the other 4 water spaces. The Outdoor Area itself is not considered a building (e. g. for kiosks)."
				},
				m3: {
					name: "Silver Lake",
					description: "Profitable area around the Lake. maps.desc1-2"
				},
				m4: {
					name: "Commercial Harbor",
					description: "Active if Harbor is connected: Once during your turn, you may discard 1 hand card for 3 Money (at any time). The Commercial Harbor is considered to be connected as soon as you have placed a building on the adjacent building space. You may use the ability at any time during your turn, before, after, or during an action. However, you may only discard 1 card with the Commercial Harbor per turn. You may not use the ability during a break or someone else’s turn. The Commercial Harbor itself does not count as a building (e. g. for kiosks)."
				},
				m5: {
					name: "Park Restaurant",
					description: "Income: gain 1 Money income for each covered space adjacent to the Restaurant. The left bonus: you can build 1 of the 2 depicted special enclosures in your zoo for free, even if you did not upgrade the Build Action card yet. During the break, you gain income of 1 money for each space adjacent to the Park Restaurant with a building on it. It does not matter if these are single buildings or if several spaces belong to the same building. It also doesn’t matter what kind of buildings you build there and whether enclosures are occupied or not. The Park Restaurant itself does not count as a building (e. g. for kiosks)."
				},
				m6: {
					name: "Research Institute",
					description: "Active if Institute is connected: Each time you play an animal card, ignore 1 condition of your choice. The Research Institute is considered connected as soon as you have placed a building on the adjacent building space. You may build your first building directly adjacent to the Research Institute, but you do not have to. Once active, you can play Animal cards even when you are 1 condition short; you must still fulfill all other conditions. You cannot ignore rock or water requirements. maps.desc1-3"
				},
				m7: {
					name: "Ice Cream Parlors",
					description: "All kiosk placement bonuses covered: Income: Gain 1 Money extra income for each kiosk If you have covered all parlors, you gain 1 additional money for each kiosk on your zoo map as income during the break. It does not matter if these kiosks were built as placement bonuses or by other means. It also does not matter if they generate income without this bonus or not. maps.desc1-3"
				},
				m8: {
					name: "Hollywood Hills",
					description: "Each time you cover an H, reveal cards from the deck and add the first Sponsor card to your hand. All H covered: Each Sponsor card Strength decrease 1 when played. The left bonus: if you have not yet upgraded the Association Action card, you can not gain a third partner zoo. Spaces with an H may be covered like any other space. This is similar to a placement bonus, but does not count as one (e. g. for card 221). Every time you place a building on an H, reveal cards from the deck one by one until you reveal a Sponsor card. Add this card to your hand and put all other revealed cards onto the discard pile. Once you have covered all 3 spaces, the level of each Sponsor card you play is 1 lower. This means you can play them more easily."
				},
				mA: {
					name: "Map A",
					description: "You start with a free size-3 enclosure and a kiosk in the bottom left corner. No special ability."
				}
			},
			abilities: {
				SPRINT: "Sprint",
				PACK: "Pack",
				HUNTER: "Hunter",
				CLEVER: "Clever",
				BOOST_ASSOCIATION: "Boost: Association",
				ACTION_ASSOCIATION: "Action: Association",
				INVENTIVE_BEAR: "Inventive: Bear",
				FULL_THROATED: "Full-throated",
				JUMPING: "Jumping",
				INVENTIVE: "Inventive",
				MULTIPLIER_ASSOCIATION: "Multiplier: Association",
				ICONIC_ANIMAL: "Iconic Animal",
				BOOST_ANIMAL: "Boost: Animal",
				SUN_BATHING: "Sun Bathing",
				POUCH: "Pouch",
				RESISTANCE: "Resistance",
				ASSERTION: "Assertion",
				BOOST_SPONSORS: "Boost: Sponsors",
				FLOCK_ANIMAL: "Flock Animal",
				ACTION_SPONSORS: "Action: Sponsors",
				MULTIPLIER_SPONSORS: "Multiplier: Sponsors",
				DIGGING: "Digging",
				SPONSOR_MAGNET: "Sponsor Magnet",
				VENOM: "Venom",
				DOMINANCE: "Dominance",
				ACTION_CARDS: "Action: Cards",
				PILFERING_1: "Pilfering 1",
				MULTIPLIER_CARD: "Multiplier: Card",
				PILFERING_2: "Pilfering 2",
				INVENTIVE_PRIMARY: "Inventive: Primary",
				BOOST_CARD: "Boost: Card",
				SNAPPING_2: "Snapping 2",
				CONSTRICTION: "Constriction",
				HYPNOSIS: "Hypnosis",
				SNAPPING_1: "Snapping 1",
				SCAVENGING: "Scavenging",
				POSTURING: "Posturing",
				BOOST_BUILDING: "Boost: Building",
				PERCEPTION_4: "Perception 4",
				DETERMINATION: "Determination",
				MULTIPLIER_BUILDING: "Multiplier: Building",
				PEACOCKING: "Peacocking",
				ACTION_BUILDING: "Action: Building",
				PETTING_ZOO_ANIMAL: "Petting Zoo Animal",
				MARK: "Mark",
				APPEAL: "Appeal",
				TRADE: "Trade",
				SEA_ANIMAL_MAGNET: "Sea Animal Magnet",
				REEF_MONEY: "Money",
				SYMBIOSIS: "Symbiosis",
				HELPFUL: "Helpful",
				TAKE_CARD_IN_RANGE: "Take Card in Range",
				REPUTATION: "Reputation",
				EXTRA_SHIFT: "Extra Shift",
				GLIDE: "Glide",
				CONSERVATION_POINT: "Conservation Point",
				SHARK_ATTACK: "Shark Attack",
				CUT_DOWN: "Cut Down",
				CAMOUFLAGE: "Camouflage",
				SCUBA_DIVE: "Scuba Dive X",
				MARKETING: "Marketing",
				ADAPT: "Adapt",
				MONKEY_GANG: "Monkey Gang"
			},
			inspectCard: "View {{name}}",
			zoomIn: "Zoom in",
			zoomOut: "Zoom out",
			resetView: "Reset zoo view",
			venom: "Venom",
			constriction: "Constriction",
			discardPile: "Discard {{n}}",
			partnerZoos: "Partner zoos",
			universities: "Universities",
			lastTurns: "{{n}} final turns",
			conditions: "Conditions",
			reviewBoard: "Review zoo",
			reviewHide: "Hide results",
			reviewShow: "Show results",
			conservationReport: "Conservation report",
			winner: "Winner",
			jointWinners: "Joint winners",
			appealTarget: "Appeal threshold",
			finalRewards: "Final card & sponsor rewards",
			confirmLobby: "Confirm return",
			confirmAgain: "Confirm new game",
			zooRewards: "Zoo rewards",
			collection: "Zoo collection",
			animals: "Animals",
			build: "Build",
			cardsAction: "Cards",
			association: "Association",
			sponsors: "Sponsors",
			action: "{{action}} · Strength {{n}}",
			gainX: "Gain 1 X-token",
			finish: "Finish action",
			skip: "Decline",
			chooseMap: "Choose a zoo map",
			chooseDraft: "Choose an action card",
			chooseVariants: "Keep two different action types",
			setupDiscard: "Keep 4 starting cards",
			discard: "Discard a card",
			finalDiscard: "Discard a Final Scoring card",
			resolve: "Resolve effect",
			gain: "Gain {{n}} {{resource}}",
			playCard: "Play card",
			takeCard: "Take card",
			selectHabitat: "Choose an enclosure",
			habitat: "Enclosure {{n}}",
			flock: "Share a herbivore enclosure",
			placeBuilding: "Place building",
			buildBuilding: "Build {{building}}",
			placeHere: "Place here",
			drawDeck: "Draw from deck",
			drawCards: "Draw cards",
			snap: "Snap from display",
			sellCard: "Sell card",
			pouchCard: "Pouch card",
			money: "Money",
			appeal: "Appeal",
			conservation: "Conservation",
			reputation: "Reputation",
			x: "X-tokens",
			upgrade: "Upgrade an action card",
			hire: "Hire an Association worker",
			takePartner: "Take a partner zoo",
			takeUniversity: "Take a university",
			taskReputation: "Gain 2 reputation",
			support: "Support conservation",
			projectSlot: "Support space {{n}}",
			donate: "Donate {{n}} money",
			reward: "Choose a bonus",
			rewardMoney: "Gain 5 money",
			ability: "Use card ability",
			moveOne: "Move to slot 1",
			moveFive: "Move to slot 5",
			tradeX: "Pay 1 X-token to gain 5 money",
			tradeMoney: "Pay 5 money to gain 1 X-token",
			tradeReputationMoney: "Pay 5 money to gain 1 reputation",
			tradeReputationX: "Pay 1 X-token to gain 1 reputation",
			mark: "Mark a display animal",
			extraShift: "Recall an Association worker",
			cutDown: "Remove an empty enclosure",
			symbiosis: "Choose another sea animal ability",
			release: "Release an animal",
			assignmentSmall: "Focus on small animals",
			assignmentLarge: "Focus on large animals",
			gainAppealPaid: "Pay 2 money to gain 1 appeal",
			sponsorCash: "Advance break and gain money",
			stealMoney: "Give 5 money",
			stealCard: "Allow a random hand card to be taken",
			targetPlayer: "Choose a player",
			harbor: "Sell a card at the harbor",
			hand: "Hand",
			market: "Display",
			projects: "Conservation",
			zoo: "Zoo",
			finals: "Final Scoring",
			workers: "Workers",
			score: "Score",
			turn: "Turn {{n}}",
			breakTrack: "Break {{n}} / {{max}}",
			wait: "Waiting for {{name}}",
			chooseEffect: "Choose an effect to resolve",
			inspect: "Inspect card",
			close: "Close",
			rotate: "Rotate",
			reflect: "Flip",
			confirm: "Confirm",
			cancel: "Cancel",
			noPlacement: "No suitable position",
			optMarine: "Marine Worlds",
			marineOn: "Base + Marine Worlds",
			marineOff: "Base game only",
			optMaps: "Zoo maps",
			mapA: "Map A",
			map0: "Map 0",
			mapAdvanced: "Choose from two maps, 1–8",
			errAction: "That option is no longer available. Choose again.",
			errTurn: "Wait for the current player to choose.",
			logPlay: "Played a card",
			logBuild: "Placed a building",
			logTurn: "Completed a turn",
			logBreak: "Started a break",
			discountSponsor: "Discard to reduce the next sponsor level by 2",
			smallProgram: "Use the Small Animals Program",
			moveAnimal: "Move an animal into the new enclosure",
			enlarge: "Enlarge an enclosure",
			reconstruct: "Choose buildings to reposition",
			refillSnap: "Refill the display, then snap",
			sharkAttack: "Discard display animals to gain appeal",
			scubaDive: "Search for a sponsor",
			sendExpedition: "Send a sponsor on expedition",
			logUndoVenom: "You cannot pay the Venom cost. Choose your action again.",
			begin: "Choose an action",
			useIgnore: "Use the ignore-conditions bonus",
			useRecall: "Use the worker-recall bonus",
			phaseBreak: "Break",
			phaseFinal: "Final scoring",
			phaseDone: "Game over",
			emptyHand: "No hand cards",
			total: "Total score",
			selected: "{{n}} selected",
			cost: "Cost {{n}}",
			strength: "Strength {{n}}",
			effect: "Resolve {{ability}}",
			placementBonus: "Placement bonus",
			supportBonus: "Zoo bonus {{n}}",
			played: "Played cards",
			choose: "Choose",
			reselectBuildings: "Restore buildings and choose again",
			useMarketing: "Use sponsor bonus",
			aquarium: "Aquarium",
			managementHunter: "Hunter: your number of predator icons",
			managementScience: "Gain 1 reputation per 2 science icons",
			managementSearch: "Find 1 card with the matching animal category",
			managementReef: "Trigger all Reef Dweller effects",
			managementSunbathing: "Sunbathing 2",
			firstProjectReward: "When first played, also gain: {{reward}}",
			projectChoice: "Space {{n}} · Gain {{conservation}} conservation",
			recurringReward: "Now and each break: {{reward}}",
			immediateReward: "Now: {{reward}}",
			spendWildcard: "Use wildcard: {{card}}",
			releaseChoice: "Release: {{card}}",
			rewardCount: "{{n}} {{reward}}",
			universityHand: "Hand limit 5",
			universityScience: "2 science icons",
			universityReputation: "Science icon and 2 reputation",
			bonusNames: {
				upgrade: "Upgrade an action",
				worker: "Hire a worker",
				partner: "Take a partner zoo",
				university: "Take a university",
				sponsorMoney: "Play a sponsor by paying its level",
				multiplier: "Multiplier token",
				specialEnclosure: "Large bird aviary or reptile house",
				kiosk: "Kiosk",
				wildcard: "Wildcard token"
			},
			variants: {
				animals1: "If strength allows 2 animals but you play only 1, ignore 1 condition on that animal.",
				animals2: "After finishing, if no animal remains in your hand, use Hunter 4; Hunter 6 when upgraded.",
				animals3: "The first animal costs 2 less. When upgraded, instead pay 2 extra per animal to gain 1 appeal.",
				animals4: "After finishing, mark a display animal. When upgraded, playing your marked display animal also gains 1 reputation.",
				build1: "Build an extra pavilion for 3 money; 2 when upgraded.",
				build2: "Build an extra kiosk for 3 money; 2 when upgraded.",
				build3: "Build at +1 strength. When upgraded, standard enclosure types may be repeated.",
				build4: "Pay 2 to cover one water or rock hex; when upgraded, gain 2 instead. Once per action.",
				cards1: "Keep all drawn cards without discarding.",
				cards2: "Use Digging 1 before drawing; Digging 2 when upgraded.",
				cards3: "Snap at strength 3; at 2 when upgraded. Upgraded strength 5 allows 2 snaps without refilling between them.",
				cards4: "After finishing, pay 2 to move an action to slot 1; free when upgraded.",
				association1: "Take partner zoos from reserve, allowing duplicates. When upgraded, this also applies to universities.",
				association2: "Hire a worker instead of supporting a project. When upgraded, each extra worker assigned reduces a task strength by 2.",
				association3: "Gain 1 X-token if strength exceeds the task value. When upgraded, instead reduce donation cost by 1 per X-token held.",
				association4: "At strength 5, do no task and take another action after finishing. When upgraded, instead draw a card in place of donating.",
				sponsors1: "Exchange 1 X-token for 5 money or vice versa. When upgraded, also exchange 5 money or 1 X-token for 1 reputation.",
				sponsors2: "The first time you gain money during this action, gain 3 extra; 5 when upgraded.",
				sponsors3: "Discard a hand sponsor for 4 money. When upgraded, discard any card, or reduce the next sponsor level by 2 instead.",
				sponsors4: "Discard a hand sponsor to snap a display sponsor. When upgraded, instead discard any card while advancing the break, then pay a hand sponsor level in money to play it."
			},
			buildings: {
				standard1: "Size-1 enclosure",
				standard2: "Size-2 enclosure",
				standard3: "Size-3 enclosure",
				standard4: "Size-4 enclosure",
				standard5: "Size-5 enclosure",
				kiosk: "Kiosk",
				pavilion: "Pavilion",
				petting: "Petting Zoo",
				aviary: "Large Bird Aviary",
				reptile: "Reptile House",
				aquariumSmall: "Small Aquarium",
				aquariumLarge: "Large Aquarium",
				unique: "Unique building"
			},
			tags: {
				africa: "Africa",
				americas: "Americas",
				asia: "Asia",
				australia: "Australia",
				europe: "Europe",
				bird: "Bird",
				herbivore: "Herbivore",
				predator: "Predator",
				primate: "Primate",
				reptile: "Reptile",
				bear: "Bear",
				pet: "Petting Zoo Animal",
				seaAnimal: "Sea Animal",
				science: "Research",
				rock: "Rock",
				water: "Water"
			}
		}
	}
};
//#endregion
export { ji as default };
