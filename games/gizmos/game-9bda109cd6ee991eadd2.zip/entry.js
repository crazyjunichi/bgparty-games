import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useLayoutEffect as i, useMemo as a, useRef as o, useState as s } from "react";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { playTurn as d, useSoundEdge as f } from "@bgparty/sdk/sfx";
import { GameScreen as p } from "@bgparty/sdk/ui/game-screen";
import { HintRing as m } from "@bgparty/sdk/ui/hint-ring";
import { SeatBadgedAvatar as h, seatName as g } from "@bgparty/sdk/ui/player-strip";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { Floater as b, FlySprite as x, PulseBox as S } from "@bgparty/sdk/fx/primitives";
import { IconBack as C, IconBot as w, IconExpand as T, IconLog as E } from "@bgparty/sdk/icons";
import { Confetti as ee } from "@bgparty/sdk/ui/confetti";
//#region src/games/gizmos/cards.ts
var te = [
	"k",
	"b",
	"r",
	"y"
], D = 0, O = (e, t) => ({
	id: `t1-${D += 1}`,
	tier: 1,
	color: e,
	any: !1,
	cost: 1,
	vp: 1,
	effect: t
}), k = 0, A = (e, t, n, r) => ({
	id: `t2-${k += 1}`,
	tier: 2,
	color: e,
	any: !1,
	cost: t,
	vp: n,
	effect: r
}), j = 0, M = (e, t, n, r) => ({
	id: `t3-${j += 1}`,
	tier: 3,
	color: e,
	any: !1,
	cost: t,
	vp: n,
	effect: r
}), N = {
	id: "t0",
	tier: 0,
	color: null,
	any: !1,
	cost: 0,
	vp: 0,
	effect: {
		kind: "trigger",
		on: "file",
		fx: "draw1"
	}
}, P = [
	O("k", {
		kind: "upgrade",
		add: {
			storage: 1,
			file: 1
		}
	}),
	O("b", {
		kind: "upgrade",
		add: {
			storage: 1,
			file: 1
		}
	}),
	O("r", {
		kind: "upgrade",
		add: {
			storage: 1,
			file: 1
		}
	}),
	O("y", {
		kind: "upgrade",
		add: {
			storage: 1,
			file: 1
		}
	}),
	O("k", {
		kind: "upgrade",
		add: {
			storage: 1,
			research: 1
		}
	}),
	O("b", {
		kind: "upgrade",
		add: {
			storage: 1,
			research: 1
		}
	}),
	O("r", {
		kind: "upgrade",
		add: {
			storage: 1,
			research: 1
		}
	}),
	O("y", {
		kind: "upgrade",
		add: {
			storage: 1,
			research: 1
		}
	}),
	O("k", {
		kind: "trigger",
		on: "pick",
		color: "b",
		fx: "draw1"
	}),
	O("k", {
		kind: "trigger",
		on: "pick",
		color: "y",
		fx: "draw1"
	}),
	O("b", {
		kind: "trigger",
		on: "pick",
		color: "k",
		fx: "draw1"
	}),
	O("b", {
		kind: "trigger",
		on: "pick",
		color: "r",
		fx: "draw1"
	}),
	O("r", {
		kind: "trigger",
		on: "pick",
		color: "k",
		fx: "draw1"
	}),
	O("r", {
		kind: "trigger",
		on: "pick",
		color: "y",
		fx: "draw1"
	}),
	O("y", {
		kind: "trigger",
		on: "pick",
		color: "k",
		fx: "draw1"
	}),
	O("y", {
		kind: "trigger",
		on: "pick",
		color: "r",
		fx: "draw1"
	}),
	O("k", {
		kind: "trigger",
		on: "file",
		fx: "pick1"
	}),
	O("b", {
		kind: "trigger",
		on: "file",
		fx: "pick1"
	}),
	O("r", {
		kind: "trigger",
		on: "file",
		fx: "pick1"
	}),
	O("y", {
		kind: "trigger",
		on: "file",
		fx: "pick1"
	}),
	O("k", {
		kind: "trigger",
		on: "build",
		color: "r",
		fx: "vp1"
	}),
	O("b", {
		kind: "trigger",
		on: "build",
		color: "k",
		fx: "vp1"
	}),
	O("r", {
		kind: "trigger",
		on: "build",
		color: "y",
		fx: "vp1"
	}),
	O("y", {
		kind: "trigger",
		on: "build",
		color: "b",
		fx: "vp1"
	}),
	O("k", {
		kind: "trigger",
		on: "build",
		color: "b",
		fx: "pick1"
	}),
	O("b", {
		kind: "trigger",
		on: "build",
		color: "y",
		fx: "pick1"
	}),
	O("r", {
		kind: "trigger",
		on: "build",
		color: "k",
		fx: "pick1"
	}),
	O("y", {
		kind: "trigger",
		on: "build",
		color: "r",
		fx: "pick1"
	}),
	O("k", {
		kind: "converter",
		conv: "toAny",
		color: "r"
	}),
	O("k", {
		kind: "converter",
		conv: "toAny",
		color: "y"
	}),
	O("b", {
		kind: "converter",
		conv: "toAny",
		color: "r"
	}),
	O("b", {
		kind: "converter",
		conv: "toAny",
		color: "y"
	}),
	O("r", {
		kind: "converter",
		conv: "toAny",
		color: "b"
	}),
	O("r", {
		kind: "converter",
		conv: "toAny",
		color: "k"
	}),
	O("y", {
		kind: "converter",
		conv: "toAny",
		color: "b"
	}),
	O("y", {
		kind: "converter",
		conv: "toAny",
		color: "k"
	})
], F = [
	A("k", 3, 3, {
		kind: "upgrade",
		add: {
			storage: 2,
			file: 1,
			research: 2
		}
	}),
	A("b", 3, 3, {
		kind: "upgrade",
		add: {
			storage: 2,
			file: 1,
			research: 2
		}
	}),
	A("r", 3, 3, {
		kind: "upgrade",
		add: {
			storage: 2,
			file: 1,
			research: 2
		}
	}),
	A("y", 3, 3, {
		kind: "upgrade",
		add: {
			storage: 2,
			file: 1,
			research: 2
		}
	}),
	A("k", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "y"
	}),
	A("k", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "r"
	}),
	A("b", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "r"
	}),
	A("b", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "y"
	}),
	A("r", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "k"
	}),
	A("r", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "b"
	}),
	A("y", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "k"
	}),
	A("y", 3, 3, {
		kind: "converter",
		conv: "double",
		color: "b"
	}),
	A("k", 2, 2, {
		kind: "converter",
		conv: "oneOrTwoToAny",
		color: "b"
	}),
	A("b", 2, 2, {
		kind: "converter",
		conv: "oneOrTwoToAny",
		color: "k"
	}),
	A("r", 2, 2, {
		kind: "converter",
		conv: "oneOrTwoToAny",
		color: "y"
	}),
	A("y", 2, 2, {
		kind: "converter",
		conv: "oneOrTwoToAny",
		color: "r"
	}),
	A("k", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["r", "b"],
		fx: "pick1"
	}),
	A("k", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "r"],
		fx: "pick1"
	}),
	A("b", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "k"],
		fx: "pick1"
	}),
	A("b", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "r"],
		fx: "pick1"
	}),
	A("r", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "y"],
		fx: "pick1"
	}),
	A("r", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "k"],
		fx: "pick1"
	}),
	A("y", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["k", "r"],
		fx: "pick1"
	}),
	A("y", 2, 2, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "k"],
		fx: "pick1"
	}),
	A("k", 3, 3, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "y"],
		fx: "vp1"
	}),
	A("b", 3, 3, {
		kind: "trigger",
		on: "build2",
		colors: ["k", "r"],
		fx: "vp1"
	}),
	A("r", 3, 3, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "k"],
		fx: "vp1"
	}),
	A("y", 3, 3, {
		kind: "trigger",
		on: "build2",
		colors: ["r", "b"],
		fx: "vp1"
	}),
	A("k", 2, 2, {
		kind: "trigger",
		on: "pick2",
		colors: ["y", "r"],
		fx: "draw1"
	}),
	A("b", 2, 2, {
		kind: "trigger",
		on: "pick2",
		colors: ["y", "k"],
		fx: "draw1"
	}),
	A("r", 2, 2, {
		kind: "trigger",
		on: "pick2",
		colors: ["b", "k"],
		fx: "draw1"
	}),
	A("y", 2, 2, {
		kind: "trigger",
		on: "pick2",
		colors: ["r", "b"],
		fx: "draw1"
	}),
	A("k", 3, 3, {
		kind: "trigger",
		on: "buildArchive",
		fx: "pick2"
	}),
	A("b", 3, 3, {
		kind: "trigger",
		on: "buildArchive",
		fx: "pick2"
	}),
	A("r", 3, 3, {
		kind: "trigger",
		on: "buildArchive",
		fx: "pick2"
	}),
	A("y", 3, 3, {
		kind: "trigger",
		on: "buildArchive",
		fx: "pick2"
	})
], ne = [
	M("k", 6, 6, {
		kind: "trigger",
		on: "buildTier2",
		fx: "pick2"
	}),
	M("r", 6, 6, {
		kind: "trigger",
		on: "buildTier2",
		fx: "pick2"
	}),
	M("k", 6, 6, {
		kind: "upgrade",
		discount: "researchBuild"
	}),
	M("y", 6, 6, {
		kind: "upgrade",
		discount: "researchBuild"
	}),
	M("k", 5, 5, {
		kind: "trigger",
		on: "build2",
		colors: ["r", "b"],
		fx: "vp2"
	}),
	M("r", 5, 5, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "k"],
		fx: "vp2"
	}),
	M("r", 5, 5, {
		kind: "trigger",
		on: "buildArchive",
		fx: "vp2"
	}),
	M("y", 5, 5, {
		kind: "trigger",
		on: "buildArchive",
		fx: "vp2"
	}),
	M("b", 4, 7, {
		kind: "upgrade",
		ban: "file"
	}),
	M("r", 4, 7, {
		kind: "upgrade",
		ban: "file"
	}),
	M("k", 4, 8, {
		kind: "upgrade",
		ban: "research"
	}),
	M("y", 4, 8, {
		kind: "upgrade",
		ban: "research"
	}),
	M("b", 4, 4, {
		kind: "trigger",
		on: "file",
		fx: "draw3"
	}),
	M("y", 4, 4, {
		kind: "trigger",
		on: "file",
		fx: "draw3"
	}),
	M("k", 4, 4, {
		kind: "trigger",
		on: "file",
		fx: "vp1"
	}),
	M("r", 4, 4, {
		kind: "trigger",
		on: "file",
		fx: "vp1"
	}),
	M("b", 4, 4, {
		kind: "upgrade",
		add: { storage: 4 }
	}),
	M("k", 4, 4, {
		kind: "upgrade",
		add: { storage: 4 }
	}),
	M("k", 5, 5, {
		kind: "converter",
		conv: "pairDouble",
		pair: ["b", "y"]
	}),
	M("b", 5, 5, {
		kind: "converter",
		conv: "pairDouble",
		pair: ["k", "r"]
	}),
	M("r", 4, 4, {
		kind: "converter",
		conv: "anyToAny"
	}),
	M("y", 4, 4, {
		kind: "converter",
		conv: "anyToAny"
	}),
	M("k", 5, 5, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "y"],
		fx: "file"
	}),
	M("y", 5, 5, {
		kind: "trigger",
		on: "build2",
		colors: ["k", "r"],
		fx: "file"
	}),
	M("b", 6, 6, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "r"],
		fx: "freeBuild1"
	}),
	M("y", 6, 6, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "k"],
		fx: "freeBuild1"
	}),
	M("b", 7, 7, {
		kind: "trigger",
		on: "build2",
		colors: ["y", "r"],
		fx: "research"
	}),
	M("r", 7, 7, {
		kind: "trigger",
		on: "build2",
		colors: ["b", "k"],
		fx: "research"
	}),
	M("b", 5, 5, {
		kind: "upgrade",
		discount: "tier2"
	}),
	M("y", 5, 5, {
		kind: "upgrade",
		discount: "tier2"
	}),
	M("b", 5, 5, {
		kind: "upgrade",
		discount: "archive"
	}),
	M("r", 5, 5, {
		kind: "upgrade",
		discount: "archive"
	}),
	{
		id: `t3-${j += 1}`,
		tier: 3,
		color: null,
		any: !0,
		cost: 7,
		vp: "award",
		effect: {
			kind: "upgrade",
			award: "perEnergy"
		}
	},
	{
		id: `t3-${j += 1}`,
		tier: 3,
		color: null,
		any: !0,
		cost: 7,
		vp: "award",
		effect: {
			kind: "upgrade",
			award: "perVp"
		}
	}
], re = [
	N,
	...P,
	...F,
	...ne
], ie = new Map(re.map((e) => [e.id, e])), I = (e) => {
	let t = ie.get(e);
	if (!t) throw Error(`unknown card ${e}`);
	return t;
}, ae = P.map((e) => e.id), L = F.map((e) => e.id), oe = ne.map((e) => e.id), se = [
	6,
	4,
	4
], ce = {
	storage: 5,
	file: 1,
	research: 3
};
function R(e) {
	let t = { ...ce };
	for (let n of e) {
		let e = I(n).effect;
		e.kind === "upgrade" && "add" in e && e.add && (t.storage += e.add.storage ?? 0, t.file += e.add.file ?? 0, t.research += e.add.research ?? 0);
	}
	return t;
}
function le(e) {
	let t = {
		file: !1,
		research: !1
	};
	for (let n of e) {
		let e = I(n).effect;
		e.kind === "upgrade" && "ban" in e && e.ban && (t[e.ban] = !0);
	}
	return t;
}
function z(e) {
	let t = {
		tier2: !1,
		archive: !1,
		researchBuild: !1
	};
	for (let n of e) {
		let e = I(n).effect;
		e.kind === "upgrade" && "discount" in e && e.discount && (t[e.discount] = !0);
	}
	return t;
}
function B(e, t, n) {
	let r = 0;
	for (let i of e) {
		let e = I(i);
		if (e.vp === "award") {
			let i = e.effect;
			i.kind === "upgrade" && "award" in i && (r += i.award === "perEnergy" ? t : n);
		} else r += e.vp;
	}
	return r;
}
//#endregion
//#region src/games/gizmos/meta.ts
var V = {
	id: "gizmos",
	tier: "beta",
	mechanics: ["engine-building"],
	interactionTags: [],
	nameKey: "games.gizmos.name",
	descKey: "games.gizmos.desc",
	rulesKey: "games.gizmos.rules",
	icon: "⚙️",
	iconImg: "games/gizmos.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/gizmos/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#7c3aed",
	releasedAt: "2026-09-28",
	search: {
		py: "bao zhu fa ming",
		init: "bzfm"
	},
	hotseat: "cover"
}, ue = t.enum([
	"k",
	"b",
	"r",
	"y"
]), H = t.string().min(1), U = t.union([
	t.literal(1),
	t.literal(2),
	t.literal(3)
]), de = t.object({
	conv: H,
	to: ue
}), fe = t.object({
	marble: t.int().nonnegative(),
	chain: t.array(de).max(6)
}), pe = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("file"),
		cardId: H
	}),
	t.object({
		type: t.literal("pick"),
		index: t.int().min(0).max(5)
	}),
	t.object({
		type: t.literal("build"),
		cardId: H,
		from: t.enum(["market", "archive"]),
		pay: t.array(fe).max(12)
	}),
	t.object({
		type: t.literal("research"),
		tier: U
	}),
	t.object({
		type: t.literal("researchTake"),
		mode: t.enum([
			"build",
			"file",
			"none"
		]),
		cardId: H.optional(),
		pay: t.array(fe).max(12).optional()
	}),
	t.object({
		type: t.literal("resolve"),
		cardId: H,
		index: t.int().min(0).max(5).optional(),
		tier: U.optional(),
		target: H.optional()
	}),
	t.object({ type: t.literal("skipTriggers") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), me = t.object({
	rid: t.string(),
	storage: t.array(ue),
	archive: t.array(H),
	built: t.array(H),
	vp: t.int().nonnegative()
}), he = t.object({
	phase: t.enum([
		"action",
		"research",
		"done"
	]),
	turn: t.string(),
	market: t.tuple([
		t.array(H.nullable()),
		t.array(H.nullable()),
		t.array(H.nullable())
	]),
	deckCounts: t.tuple([
		t.int().nonnegative(),
		t.int().nonnegative(),
		t.int().nonnegative()
	]),
	row: t.array(ue),
	supplyCount: t.int().nonnegative(),
	players: t.array(me),
	pending: t.array(t.object({
		cardId: H,
		left: t.int().positive()
	})).nullable(),
	used: t.array(H),
	research: t.object({
		tier: U,
		count: t.int().positive()
	}).nullable(),
	lastLap: t.boolean()
}), ge = t.object({ researchCards: t.array(H).nullable() }), W = (e) => ({ code: e });
function _e(t, n, r) {
	let i = 0, a = (t) => {
		for (let n = t.length - 1; n > 0; --n) {
			let a = e(r, i, n + 1);
			i += 1, [t[n], t[a]] = [t[a], t[n]];
		}
		return t;
	}, o = [
		a([...ae]),
		a([...L]),
		a([...oe]).slice(0, oe.length - 20)
	], s = [
		[],
		[],
		[]
	];
	for (let e = 0; e < 3; e += 1) for (let t = 0; t < se[e]; t += 1) s[e].push(o[e].pop() ?? null);
	let c = a(te.flatMap((e) => Array.from({ length: 13 }, () => e))), l = c.splice(-6), u = {};
	for (let e of n) u[e] = {
		storage: [],
		archive: [],
		built: [N.id],
		vp: 0
	};
	return {
		state: {
			players: n,
			turn: 0,
			phase: "action",
			decks: o,
			market: s,
			row: l,
			supply: c,
			boards: u,
			pending: [],
			used: [],
			research: null,
			finalLeft: null,
			seed: r,
			rngCursor: i
		},
		fx: []
	};
}
function ve(e, t, n) {
	let r = [];
	for (let i of e.boards[t].built) {
		if (e.used.includes(i) || n.type === "build" && n.card === i) continue;
		let t = I(i).effect;
		if (t.kind !== "trigger") continue;
		let a = !1;
		if (n.type === "file") a = t.on === "file";
		else if (n.type === "pick") a = t.on === "pick" && t.color === n.color || t.on === "pick2" && t.colors.includes(n.color);
		else {
			let e = I(n.card), r = (t) => e.any || e.color === t;
			t.on === "build" ? a = r(t.color) : t.on === "build2" ? a = t.colors.some(r) : t.on === "buildArchive" ? a = n.fromArchive : t.on === "buildTier2" && (a = e.tier === 2);
		}
		a && r.push({
			cardId: i,
			left: t.fx === "pick2" ? 2 : 1
		});
	}
	return r;
}
var ye = (e) => e === "draw1" || e === "draw3" || e === "vp1" || e === "vp2";
function be(e, t, n) {
	let r = I(n).effect.fx, i = e.boards[t];
	if (r === "vp1" || r === "vp2") {
		let e = r === "vp1" ? 1 : 2;
		return i.vp += e, [{
			kind: "vp",
			rid: t,
			data: {
				n: e,
				cardId: n
			}
		}];
	}
	let a = r === "draw1" ? 1 : 3, o = R(i.built).storage - i.storage.length, s = [];
	for (let t = 0; t < Math.min(a, o); t += 1) {
		let t = e.supply.pop();
		if (!t) break;
		i.storage.push(t), s.push(t);
	}
	return s.length ? [{
		kind: "draw",
		rid: t,
		data: {
			colors: s,
			cardId: n
		}
	}] : [];
}
function xe(e, t, n, r) {
	for (e.pending.push(...n); e.pending.length > 0 && e.pending.every((e) => ye(I(e.cardId).effect.fx));) {
		let n = e.pending.shift();
		e.used.push(n.cardId), r.push(...be(e, t, n.cardId));
	}
}
function G(e) {
	if (!(e.phase !== "action" || e.pending.length > 0)) {
		if (e.used = [], e.finalLeft !== null) {
			if (e.finalLeft === 0) {
				e.phase = "done";
				return;
			}
			--e.finalLeft;
		}
		e.turn = (e.turn + 1) % e.players.length;
	}
}
function Se(e, t) {
	if (e.finalLeft !== null) return;
	let n = e.boards[t].built;
	if (n.filter((e) => I(e).tier === 3).length >= 4 || n.length >= 16) {
		let t = e.players.length;
		e.finalLeft = ((t - 1 - e.turn) % t + t) % t;
	}
}
function Ce(e, t, n) {
	e.market[t][n] = e.decks[t].pop() ?? null;
}
function we(e, t) {
	for (let n = 0; n < 3; n += 1) {
		let r = e.market[n].indexOf(t);
		if (r >= 0) return {
			tier: n,
			slot: r
		};
	}
	return null;
}
function Te(e, t, n, r, i, a) {
	if (i.length !== r) return null;
	let o = {}, s = {}, c = [], l = /* @__PURE__ */ new Map();
	for (let t of i) {
		if (t.marble < 0 || t.marble >= e.storage.length) return null;
		let n = l.get(t.marble) ?? [];
		n.push(t), l.set(t.marble, n);
	}
	for (let [, e] of l) {
		if (e.length === 1) continue;
		if (e.length !== 2) return null;
		let [t, n] = e, r = 0;
		for (; r < t.chain.length && r < n.chain.length && t.chain[r].conv === n.chain[r].conv && t.chain[r].to === n.chain[r].to;) r += 1;
		if (r === 0) return null;
		let i = t.chain[r - 1], a = I(i.conv).effect;
		if (a.kind !== "converter" || a.conv !== "double" && a.conv !== "pairDouble" || a.conv === "double" && i.to !== a.color) return null;
	}
	for (let r of i) {
		let i = e.storage[r.marble];
		for (let e of r.chain) {
			let t = I(e.conv);
			if (t.effect.kind !== "converter" || a.includes(t.id)) return null;
			let n = t.effect;
			if (n.conv === "toAny") {
				if (n.color !== i || (o[t.id] = (o[t.id] ?? 0) + 1, o[t.id] > 1)) return null;
				i = e.to;
			} else if (n.conv === "anyToAny") {
				if (o[t.id] = (o[t.id] ?? 0) + 1, o[t.id] > 1) return null;
				i = e.to;
			} else if (n.conv === "oneOrTwoToAny") {
				if (n.color !== i || (o[t.id] = (o[t.id] ?? 0) + 1, o[t.id] > 2)) return null;
				i = e.to;
			} else if (n.conv === "double") {
				if (n.color !== i || e.to !== i) return null;
				i = e.to;
			} else {
				if (!n.pair?.includes(i) || e.to !== i) return null;
				let r = s[t.id] ?? [];
				if (!r.includes(i) && (s[t.id] = [...r, i], o[t.id] = (o[t.id] ?? 0) + 1, o[t.id] > 2)) return null;
				i = e.to;
			}
			c.includes(t.id) || c.push(t.id);
		}
		if (!n && i !== t) return null;
	}
	let u = /* @__PURE__ */ new Set();
	for (let e of i) for (let t = 0; t < e.chain.length; t += 1) {
		let n = e.chain[t], r = I(n.conv).effect;
		if (r.kind === "converter" && r.conv === "double") {
			let r = `${e.marble}:${e.chain.slice(0, t + 1).map((e) => `${e.conv}>${e.to}`).join(",")}`;
			if (!u.has(r) && (u.add(r), o[n.conv] = (o[n.conv] ?? 0) + 1, o[n.conv] > 1)) return null;
		}
	}
	return {
		marbles: [...l.keys()],
		convs: c
	};
}
function Ee(e, t, n, r) {
	let i = I(t), a = z(e), o = i.cost;
	return a.tier2 && i.tier === 2 && --o, a.archive && n && --o, a.researchBuild && r && --o, Math.max(0, o);
}
function De(e, t, n, r, i) {
	let a = I(t), o = Ee(e.built, t, n, r);
	if (o === 0) return [];
	let s = [], c = /* @__PURE__ */ new Set(), l = (t) => {
		let n = e.storage.findIndex((e, n) => !c.has(n) && e === t);
		return n >= 0 && c.add(n), n >= 0 ? n : null;
	}, u = a.color ?? "k";
	for (let t = 0; t < o; t += 1) {
		if (a.any) {
			let t = e.storage.findIndex((e, t) => !c.has(t));
			if (t < 0) return null;
			c.add(t), s.push({
				marble: t,
				chain: []
			});
			continue;
		}
		let t = l(u);
		if (t !== null) {
			s.push({
				marble: t,
				chain: []
			});
			continue;
		}
		let n = !1;
		for (let t of e.built) {
			if (i.includes(t) || s.some((e) => e.chain.some((e) => e.conv === t))) continue;
			let r = I(t).effect;
			if (!(r.kind !== "converter" || r.conv !== "toAny" && r.conv !== "anyToAny")) {
				for (let i = 0; i < e.storage.length; i += 1) if (!c.has(i) && (r.conv !== "toAny" || r.color === e.storage[i])) {
					c.add(i), s.push({
						marble: i,
						chain: [{
							conv: t,
							to: u
						}]
					}), n = !0;
					break;
				}
				if (n) break;
			}
		}
		if (!n) return null;
	}
	return s;
}
function Oe(e, t, n, r, i, a, o, s) {
	let c = e.boards[t], l = I(n), u = Ee(c.built, n, r, i), d = Te(c, l.color, l.any, u, a, e.used);
	if (!d) return W("games.gizmos.errBadPay");
	for (let t of [...d.marbles].sort((e, t) => t - e)) {
		let [n] = c.storage.splice(t, 1);
		e.supply.unshift(n);
	}
	e.used.push(...d.convs);
	let f = null;
	if (r) c.archive = c.archive.filter((e) => e !== n);
	else if (!i) {
		let t = we(e, n);
		t && (f = t.slot, Ce(e, t.tier, t.slot));
	}
	return c.built.push(n), o.push({
		kind: "build",
		rid: t,
		data: {
			cardId: n,
			tier: l.tier,
			slot: f,
			...s ? { sourceCardId: s } : {}
		}
	}), xe(e, t, ve(e, t, {
		type: "build",
		card: n,
		fromArchive: r
	}), o), Se(e, t), null;
}
function ke(e, t, n, r, i) {
	let a = e.boards[t];
	if (a.archive.length >= R(a.built).file) return W("games.gizmos.errArchiveFull");
	let o = we(e, n);
	return o ? (e.market[o.tier][o.slot] = null, Ce(e, o.tier, o.slot), a.archive.push(n), r.push({
		kind: "file",
		rid: t,
		data: {
			cardId: n,
			tier: o.tier + 1,
			slot: o.slot,
			...i ? { sourceCardId: i } : {}
		}
	}), xe(e, t, ve(e, t, { type: "file" }), r), null) : W("games.gizmos.errBadCard");
}
function Ae(e, t, n, r, i) {
	let a = e.boards[t];
	if (a.storage.length >= R(a.built).storage) return W("games.gizmos.errStorageFull");
	let o = e.row[n];
	if (!o) return W("games.gizmos.errBadPick");
	e.row.splice(n, 1);
	let s = e.supply.pop();
	return s && e.row.push(s), a.storage.push(o), r.push({
		kind: "pick",
		rid: t,
		data: {
			color: o,
			index: n,
			...i ? { sourceCardId: i } : {}
		}
	}), xe(e, t, ve(e, t, {
		type: "pick",
		color: o
	}), r), null;
}
function je(e, t, n, r, i) {
	let a = e.decks[n - 1];
	if (a.length === 0) return W("games.gizmos.errDeckEmpty");
	let o = Math.min(R(e.boards[t].built).research, a.length), s = [];
	for (let e = 0; e < o; e += 1) s.push(a.pop());
	return e.research = {
		tier: n,
		cards: s
	}, e.phase = "research", r.push({
		kind: "research",
		rid: t,
		data: {
			tier: n,
			count: o,
			...i ? { sourceCardId: i } : {}
		}
	}), null;
}
function Me(e, t, n) {
	if (t.type === "tick") return {
		state: e,
		fx: []
	};
	if (e.phase === "done" || e.players[e.turn] !== n.by) return W("games.gizmos.errNotYourTurn");
	let r = n.by, i = e.boards[r], a = le(i.built);
	if (t.type === "researchTake") {
		if (e.phase !== "research" || !e.research) return W("games.gizmos.errNotYourTurn");
		let { tier: n, cards: i } = e.research, a = t.cardId;
		if (t.mode !== "none" && (!a || !i.includes(a))) return W("games.gizmos.errBadCard");
		let o = structuredClone(e), s = [];
		if (t.mode === "build") {
			let e = Oe(o, r, a, !1, !0, t.pay ?? [], s);
			if (e) return e;
		} else if (t.mode === "file") {
			let e = o.boards[r];
			if (e.archive.length >= R(e.built).file) return W("games.gizmos.errArchiveFull");
			e.archive.push(a), s.push({
				kind: "file",
				rid: r,
				data: { cardId: a }
			}), xe(o, r, ve(o, r, { type: "file" }), s);
		}
		let c = i.filter((e) => e !== a);
		return o.decks[n - 1].unshift(...c), o.research = null, o.phase = "action", G(o), {
			state: o,
			fx: s
		};
	}
	if (t.type === "resolve") {
		let n = e.pending.find((e) => e.cardId === t.cardId);
		if (!n || e.phase !== "action") return W("games.gizmos.errBadCard");
		let i = I(n.cardId).effect;
		if (i.kind !== "trigger") return W("games.gizmos.errBadCard");
		let a = structuredClone(e), o = [];
		if (a.used.push(n.cardId), a.pending = a.pending.filter((e) => e.cardId !== n.cardId), i.fx === "pick1" || i.fx === "pick2") {
			if (t.index === void 0) return W("games.gizmos.errBadPick");
			let e = Ae(a, r, t.index, o, n.cardId);
			if (e) return e;
			n.left > 1 && a.pending.unshift({
				cardId: n.cardId,
				left: n.left - 1
			});
		} else if (i.fx === "file") {
			if (le(a.boards[r].built).file) return G(a), {
				state: a,
				fx: o
			};
			if (!t.target) return W("games.gizmos.errBadCard");
			let e = ke(a, r, t.target, o, n.cardId);
			if (e) return e;
		} else if (i.fx === "research") {
			if (le(a.boards[r].built).research) return G(a), {
				state: a,
				fx: o
			};
			if (t.tier === void 0) return W("games.gizmos.errBadCard");
			let e = je(a, r, t.tier, o, n.cardId);
			if (e) return e;
		} else if (i.fx === "freeBuild1") {
			if (!t.target || I(t.target).tier !== 1 || !we(a, t.target)) return W("games.gizmos.errBadCard");
			let e = Oe(a, r, t.target, !1, !1, [], o, n.cardId);
			if (e) return e;
		} else o.push(...be(a, r, n.cardId));
		return G(a), {
			state: a,
			fx: o
		};
	}
	if (t.type === "skipTriggers") {
		if (e.pending.length === 0) return W("games.gizmos.errNoPending");
		let t = structuredClone(e);
		return t.pending = [], G(t), {
			state: t,
			fx: []
		};
	}
	if (e.phase !== "action" || e.pending.length > 0) return W("games.gizmos.errPending");
	if (t.type === "file") {
		if (a.file) return W("games.gizmos.errBanned");
		let n = structuredClone(e), i = [];
		return ke(n, r, t.cardId, i) || (G(n), {
			state: n,
			fx: i
		});
	}
	if (t.type === "pick") {
		let n = structuredClone(e), i = [];
		return Ae(n, r, t.index, i) || (G(n), {
			state: n,
			fx: i
		});
	}
	if (t.type === "build") {
		let n = we(e, t.cardId) !== null, a = i.archive.includes(t.cardId);
		if (t.from === "market" && !n || t.from === "archive" && !a) return W("games.gizmos.errBadCard");
		let o = structuredClone(e), s = [];
		return Oe(o, r, t.cardId, t.from === "archive", !1, t.pay, s) || (G(o), {
			state: o,
			fx: s
		});
	}
	if (a.research) return W("games.gizmos.errBanned");
	{
		let n = structuredClone(e), i = [];
		return je(n, r, t.tier, i) || {
			state: n,
			fx: i
		};
	}
}
function Ne(e, t) {
	let n = e.boards[t];
	return B(n.built, n.storage.length, n.vp) + n.vp;
}
function Pe(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turn],
			market: e.market.map((e) => [...e]),
			deckCounts: [
				e.decks[0].length,
				e.decks[1].length,
				e.decks[2].length
			],
			row: [...e.row],
			supplyCount: e.supply.length,
			players: e.players.map((t) => {
				let n = e.boards[t];
				return {
					rid: t,
					storage: [...n.storage],
					archive: [...n.archive],
					built: [...n.built],
					vp: n.vp
				};
			}),
			pending: e.pending.length ? e.pending.map((e) => ({ ...e })) : null,
			used: [...e.used],
			research: e.research ? {
				tier: e.research.tier,
				count: e.research.cards.length
			} : null,
			lastLap: e.finalLeft !== null
		},
		private: { researchCards: e.research && e.players[e.turn] === t ? [...e.research.cards] : null }
	};
}
function Fe(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t, n) => {
		let r = Ne(e, n) - Ne(e, t);
		if (r !== 0) return r;
		let i = e.boards[n].built.length - e.boards[t].built.length;
		if (i !== 0) return i;
		let a = e.boards[n].storage.length - e.boards[t].storage.length;
		return a === 0 ? e.players.indexOf(n) - e.players.indexOf(t) : a;
	}, n = [...e.players].sort(t), r = {};
	for (let t of e.players) r[t] = Ne(e, t);
	return {
		phase: "done",
		winner: [n[0]],
		ranking: n,
		scores: r
	};
}
var Ie = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: V,
	schemas: {
		action: pe,
		publicView: he,
		privateView: ge
	},
	setup: _e,
	reduce: Me,
	viewFor: Pe,
	status: Fe
}, Le = {
	any: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKDklEQVR4nO1da3BV1RU+Uzt9jX38anVkTMskOWvtfW4CCTr9UQ0ixEedKuHGqkDCYwZFQQnyaEWhLQ9fzOhMp4MTDGkq+KPjtNP6GgkGqxXRTgkRtaEdQMGCVpLcS1olJmR31sm9GYGzzz37vG9y1syaydzcux/fd/bea6+99jqalkgiiSSSSCKJJJJIzKS8ovwHYMCPdabfixybkeEryPEAMjwMDHqBw4CpDHrps9z/6DvN9BvgcAOVEXU/ikZKU6UTgEEjMmwDBkeRo/BDc2X9Fjg0lFWWXRJ1P2MlE3444euMsXrg0I4ch/0C3UbPIMO/AoNFuq5/UxuvwjlH5NiKDD8NAXTZyPgfMGjRU7qujRcpN8orgMHvkOFQVMBLRsWznPPLtLEqAHAxctwR0jQjXOowcNjOGLtIGzNSr12ABt6NDDOqgBgpQ9T/dJZ44IGfiZaWLaKj4wXxz+794tjRgyLbd1wMDvSZSn/TZ/S/jpdfML97//2rRf3Ns8wylIlgmAEGS6jtWjFLWapsIjB4S6XzU6fViE2bfmmC3Z/9SIgz/Z70VPaEWRaVOfWqGrU1gsObRWvGMsbSTp/6SVWTxOrV94rXX98lzgxmPYMu06HBjFnHqlXLzTodkcCgDzjUacUiNTU1X0aOv3bSuSmXV4tHH90oPvn4/cBAlynV+cgjG0X1ZVVOiXg89lMS2fTA4U+FOpOqTJmdz/T+O3Tgz9W+ng/NtlCbHKwNfygpKfmaFkeprKz8DnB4tVAn5jTcai6WUQMvztHDh94RCxY2OiHhlYnVE7+txRD8TruGV06uFDt2bBPDQ6ciB1tIlNq2fXuL2dYCi/O+2JCQm3Zsn/zptdNEV+feyAEWDvXdA38T11w3o9BI2FNdXf2NyBfcQnP+woXzfDEnRchK5uv8BQ0F14RIF+ZC1s7y5XeLz0/3Rg6mcKkDn/WIZU1LCpHwWHR2vk3D1q27L1CbXoSk1Ie1a39uR8IwGDAzVPARsQQ49MgatXTpYnPTEzV4wkcSmpqW2m7Wwtsx12sX2LkXaM4v5mlH2ExH8+bPtRsJb4SyHpiONUkjrr2+tigXXKGwMNdeM93OPL0zUPDJTUvDTWbnk/kWNUgiYH3nwFt2+4Qsud0DIwA5Pi1jnzZZKh3p2r9XtLY+YSr9HTaQXup/6qkn7ayitkDAZ4xNkh2mzJ57i+MdLk1RixYtFDrqZyl9Rn79oIGnOmT1O50+qa8NjbOlVpGe0lO+E4AMn7Gq0KgwRPc/9jkG4PY7zu+8ntO69E2BkkBlUx2y+qltTssif5aNA+9pX8EvN8rBPDe1qIw8iU4bvb/zDWnn9YBJKAR+XqmNTsukQx7JNDQEAOW+EWBGL0j8+Sou5W3bthQEQA+ABKfgk1IbnZbbe/KYqJoyWbY3eNIX8EtLS79F4RtWlWzevEkJCKcE6D6SoAK+KgGkDz+8QUbAfxljF3p/+g1cYFUBHen956MjSo11MgXpPpKgCr7qFJQ/WZtcJRkFHBq8EzASa3le4XSG6wYUu0VY95EEN+CrLMJf1JUrm2QEtHuO1ZSZnnS47aaxpzInlIGpUyTBDfj0fWqbmz699tpOmTV0xtPGTGf6PKuCKbzDi7Mtmzku6m+uUwLoppk/Mc9vnZSdrlcre2bdjY7KtnPWyUJeGGOzXRNAuzqrQh988FeuGxskCdkIwM/rhg3rZItxi2sCgMMHVoXu3v2i5wb7TUI2QvBJ29ufla0D77uOarPc+aYM0yvoR6OFTyREDb7Zhr7j8jBIxBI3T/8NVoVRrKZfjRY+kBAH8PNK7ZAQcL0yAchxhVVhFPTqd8OFB8slaItKRe9bs1I2DS1TJ4DhVqvCKPI4iMYLlyMhDk9+Xrdu/Y1sId7i2waMwr+D6oAIkISgwSd9edfzMudchzoBdOPQorCD3Z2BdkIEQEIY4JN2v7dPRsDbygSQ+WRV2PEP/xV4R4SPJIQFPildEpEQcNgNAZZhJ2FGNGc9khAm+Hn3tMQl8YkbAgasCgs75CTrwjoK2tqxC12REHC6eAnIqNv5Kr6jOBMQiyko7QL8qEjwewqKfBFOewA/ChJ8XYSjNkPTPoAfNgk2ZmiXOgEMd0e1EUv7CH6YJOxqf87XjVizVWGqh9ZxAF8PiQRfXRG5HD3nFUa31gMBvy9xxp0llCgpTHd02qVLOcjjTVWdVT/TegpCvE55BNCFg7AOZNIe/flxIMHuQIYxdqkyAXamKOVeiAv4IiYk7Nz5Z3+PJO1CEikmMk7gixiQsH792gAO5Sl/m0WhNVdd6TksJahjxGwEJAx9nhFX1PzI/7AUSnAni4pOArP6Rwl49S8vyez/Ic/Jn2gTYVV4EprYP0rAihXLZATs1LwKY2y+LDj34xOHlYbqeAvORY5z/SDgQuDQb1UB5foZ7+HpDz20PtjwdBLgsM2qEkp2pLJ4jbULGj0njwZ/QYMkuaLUb0nAxo2/COeKEglw+L30kt574++S3sHuTrPvkrl/h+a3cM4rk2uq/aPXVOc23hbuNVUSSmoqqdTMNDVeLmq3tTXLwCdt1YISwzC+Z5eqgK7xhw2kCFkPdL0pKiZVyBbe3oqKiu9qQQpllJWxX3vtdF89pSJmSleYZtRebff0L9ZCSVfDYa+sEZTShcIzogZL+KynPz0pGhvnyMFnuEfTtC8FT8DI5uxSu4RNdy25fcwlbFpmk7os3IRNOaF0vjZD0UzzNRZSlg0NZsxjWJu+DiPijaGCP0oCg8ftSKCnppino4HPesQ999xlBz7pZi0yGVkP/mjXQFoTinFhPpU5YT/nj8z7z0SeT5ox9pXc+1+kDb16xjSxf5+al1FEqGROk0VXAPzdsckjTWl8KZ2vXYNpn0CZpuKeuritrVlq539B/x6b1MV5IdcrHUAUaLj5VgvazEQNtjhHyZ81e84txZm8Oy80JCmdb6FOkBOLbtv3njwWOfDkUiavpo1j7aw5v7S09Kta7N8Zw/AxJy/rqZoy2cy3o5r2xg+l0zw6TJH5888zNcnaiXrBVRFK52u+YrBw5wQdb65c1WRmHQlyA0dl0wE6pZcplKI+r2YforLzvYqu69+njLJOOoo5vXLqFWbiC7ry6TZ9zLlnAJTHgeJ2ZKEjNlPOHldpBmIlI3uFO2VeVLRbK1KGGW+5Zs0qM/KYwr8pQ+PRD7rNmzp0XYqU/qbPaCElsOm79Bv6rZvXWOVG7uLQfDthCLlpc+lvYv0iN+TYGrhLOUoBAINeZQgMBmMA+FmvMgSAKm28CB1aA4MWCt+ICniqm6IXELFMG++vs0V6AsMZFcnrbGXCGLsIDZxDIwM5HvER9CNUJgXKjq0XdQYsiFhCt0uAwXLg8IR5cZBhFzI8RAdCo680p8Mhhody/+ug7wKDJvqt68sRiSSSSCKJJJJIIolowcn/Aay/6BSrZnTMAAAAAElFTkSuQmCC",
	build: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAALoklEQVR4nO1dCZBdVRF9kwAiiRCBMElM5s/r5fT9L8kk5YCIVTooi6AQqyyHvVAElIKgYNgErYkbIlUUiyKLCgGiZgGRNS5IgIgFxRIwQZDVhSVCgEAIGMgwVv/5QxLIMn8y77/3fjxVnVSlUu+/Pn1v33v7dveLos0PTf4HM48zk04znm5KVxn4jwFyT4D81cWM7w/GdwPxfICuBvhsVfqiSEuStQKFh9m4MU4mwJeZ8W0GfiAYPxHAzxhkSa/ws8H46QB+yowfMuM/m8lsVT6+XObxbW3Nw7LWo3AoTSqNSFQnA3QBwH8PJm8nZe0phz6RnmC9UnZ5599Xi0H+CdB1qnSwmY3JWqdCIIQxOyCO28z4jKCyIIDfcDL7yK5F+gwByD2AdI1nHpe1frnFxIktHzSjiWbxWaa0wMDLB0r8ugTunjQ+PWs9cwkRGWlGX4fKne5aBpP4NcWMbwGwY9b65goio0YC9H3312mQvoZ0m9LDzDwla51zgyRJRvkiayb/SWvUr+2G6LYQ+MNZ650LtBHtBPAMA69Km/iK+4EsUeVvZq13LhBC2MGUrizXhXh+y92bGk8TGcfR5o5SqTQCoB/Xw+UE49cNdIeqfj5rvXOBJEmGm/J0gF+qw8hfbio3a6x7Zq13LtDR0bEFEB8Gpcfq4POXQWku0PKprPXODURkWyhdX4eRvxTgS8z4YzW+4tD29vYtkyTZyv/uCwQ2BJIk2QqQY31BTNkAL/j6olqaXMv79fRETWa8OyQ+1pRODoiPa6jYkZl9wJRmp0z+ywaekWj8kdrfj4838E2m9CSUPbq6MIB+ISLF3zWJyPtE6BCoh4zTcjvyokGuUG39RK3vB1CXgZ/zaOvaz+UXAD7P7yKiovv+AL4sjW1nb6STnzWlc4ho51rfzZRPMvBr63t28JlQ5JNze/vobVRbjzbw31IhX/kZVf4hgFDru6m2Hu4u570jf60FfTkgp0VFxaRJk0b4FWIao9/Ar5vKLLPaRz6YDwyQO4PJBsMgSRk+Cy6JiohSqbS1SPwFgBelMfoN9C9T+lKt75UYHQHQfQbZ6I6s6obmRkVEO9F2EP4elN5KyfcvUqXP1PJOJnQMwI/aRkb+2obm30dFBIAdoZra4uvZEFrutwGazORQv7D3e4Eaf2d+VERMiOPmYDQnLQO4C9JAB1d/bkOn1iY2nmLgO6wG8gtvgCQpjTKja1O7XgS/CfA1IpJswAhNxry7QW7y/z8wV0e3RkVEkrIBXKC81JR/7rk/63oH1fjjBv61QVYOdKYB/IeoiEjqYIDqTHjZlH4blA5W1cmqYz+ElpZYJN4fyjODyYpNSWsx8I1RERFCy+gAuq4eFy8GXmmQRytpicJnQ/k88/tf8Kub8vsVAxhdGxURZjbGt3D1ufmqih/OwEsN/OJAfP66DBDAV0dFzXgwyOK6kb8GaWumLW6KJD4DlGZHhUNnNBTgA9w11NsAgymei2rGV0VFAxFNAHhuXd1PSrPJjH8aFQkiLUkQOdt9cZENUD3srQTo21ER0NUVDfHIZABfHIyfb4zRT4+byf5R3tHT09Ok2jrJrwQNPOB9dw4NMI+ZJco74jhuNuNzBzulPDvyq3lFoDNdtyjHGOIHLlM+3pRfaATye6VyAr49iOztGR1RPtE1BMAuQHxR0RfcdYz+5wA50bM5opyiiZl3M5XZwfi/jUL+OwKa6+H0KK9IEpbqgruy0cg35SdV+fDmPFZWdkTRFiLbb2vG0zwK2Wjku0BpZnvOypiGep2teG4n0R5B4ssBfrERyTfwE+DWA0odHVtnlMUg23r+vlcsehFFMnbs9oFLu5nJMQa6NKg8YsieqJSkG6rnOQd1TRlvHz16m5EjRw43iQ9V5e8Acn6lKl1pjoeTg/K9nndZ9hE/SFHGHEq3ga/xjYVzkjrxvrdta2sbxsyfNOXTTWmWQRZByWPpb69dcZ45OT1pioG7Tflm5lavntwydeKTZORwVT7azJNZ+ZE+orMmImREvirNA3gfP9ekTf5wU/oWQHdvroSH97qdG5hLn+zqSpl8ItoumMzJgdI9OZFub+IRguzlUdyUc/Pj/QL4+kb35aG/An7VNxki8V4ey0rV5ajGU4PJA5krbblZbG8x02l+tkm1Bqy9nbZzf2/g57NWPGQu/LyBf+PBNd9ipr7N9O2lmXzZUiwJCgUQKP/DNJ4VwEe1R1Gl+jGqB8rl1pIpL2jknU55jXPK6sQsXhZMHjPwbSY8AxKfqNq6a10OVn0gop08StmYpEtv3welxQb+lWfAmcZnGPM0JztwPNVP8yGUdmtubhs2evTobaKojuQnpZInQl3aqCPe/KQO+QEQ7+LxGhc/VLY1tw1ra24e5iEVj2d1dET1I70Pk73jFPN0KL+aNVlhkMUgb3iKuBl/euzYse9Pdes4UHhluIHuazS/b+BKiZCq1lz/WzdMmlQaocrTsyYrpOF2lBd4C4Eo75lo3km2kUZ/uTcvf6FnJeS6aUZzc/MwMzrGu8hmTVoYRDGjBwHaN9fkO+IQwy8SsiYsDKJA5b5CkO/bMFP6qoEfbwT3U+5Nhr2/Sn7+AcRtAF9vqK30MsfkLy7XWHidGSZM8FzM+FAzebQRRr8ZPw2hE+oaNtgUAKV9zOIfBfBLRTeAgVd4izGvbMy93+8DIIeZ0ZUBvN5WK4URyJ3VRkvFIN/heTqADGoJaBYzySrBNT6rs7PTL0iKAzP6mhnf7FV8g0BCt8eQqqWdy+t7dclPmsSd1S6FxUGlyZzxTZtigN4KEFlmoLu8jXDlSxXKMyulpahPUM/At09AKfQUyf04vNf+ps6ASkGz8QwznjIBcVvCLJUyI+YppnyVX+WlbQCAb0ySKK8FEOtHAH8jmMwbqN/2zGaI99fUXdf1fDcEQDPTnglmMqcaYi4WADnBTOYNbAbwK6b0M+b1dgOsuAPvRmXguwz96y4VBjYDfllIA4TAx5nxjbUbgF8BeKYE+ejGfqOlpWV05doPsjS1GQC6opAGKEOO9CBcLS7IIMt8sQ1BOvr7OxBvNyxL0tqiQvkiv0aMioZymQ80kyv772v5lQC+3NOva/kdiJziuUWpGUCoy7P3oqIBwB6qdE4wXrHxkc+vVRbUfridNUFEE6s1AivSGf20Srn18MKdARy+Zay0YFR5akOjs5IvozRvID2VyyJHemfatPw/lBZ73k41TbB4MKKdoTR/wwagJwD+XK3PFmndGyrz02w3Y0qzChP9XBeojXaC0KlQXucsMPCSoHx0rc/19A/PmzfwG6mRD34tKE8ttAEc40W4bHyhn2rfpeBS09aTa31eCKWDALoj5UZL3dV2wMUKP6wPIcSA0AWm/HDFEOB7zfikWp8D8IGeiZDyd73eNuOF/nnaXCZYDRQiMjaE+ChvtW4W19zfpgzaI0BuTbvFmIFXQejMhiK/iqbOzmho1afWtKuofDsFdIP3fEibfDP+U7m87vjTZglV+qyn/qW54IbVBngTQqc0jO/fVIjI/pW7gDp0NjRwdwD9LooyyFzOI9znm8lf6vBZqZ41OpB8JWu9c4EySvsCNH8wOsuGfgiUH1H1D2kWMOYz2Kh83N776NeH/G4o3+P1ar3VKpsxfHfk8SAvTq6X24F3VhE64v8jv1qw7T7YwP9Om/hy9fNSAXJaIWP9acCJUOWphvRKV8urKxYXAnSqt0fIWu88oYmI1HvqD/blSlJ5Hq8C+F5VujCI7OdVO1krnEN0DjWNT/e2XINhhHJvFcvKoPwgwBf7JX6pVBpVyAuWOmGIJ8Aax9/1Twu+u9i5v6SXV7ua5/xe2oQOMRs3pvCh5Xqh3Npagh/EnDzwomoEtTcCulanrCrZ7xBOK707roEf8u+qeLdc/4KRt0bIWqdCwqzVyhrvGZQOqmRZKJ8F8Pmm9BN3KZWUcY0vcr9uyud6/r6ZdAaRvcZr66RkZDI8ax3qjf8BU1n/rLMN+LQAAAAASUVORK5CYII=",
	convert: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAEUUlEQVR4nO2dPZDcNBTHFQgfRRIavhrIR5cEOHnt/bplz3d7tvWkJ2+GYiu4K2mhozwqhjYlbUpayhs+0oZJUiYz6QKTKl9FyCTHgBnf7WaWWLkLE9ay5febec1Wkv5e+S/p+YkxgiAIgiAIgiCI5+eQUvCZRLnp+/4rNHAlo7TYUBqyPCTCNUQhym5Do5Eovp4J8EQIDdtKqdO229ZYAfZCPFIavgkn4RHbbWyMAEImmUTx1L9B/A4In+bvCtttdV6A4cog63SCLIpHxX8EikuQQs92e50XgHtLu9Ff7mZCxv/+N6D4SyJciD+J37bdbucFyMNr8d3fCtMSinuI8NVkMnnVdvudFmAWfruVjaI1w7QE16WW0nYfnBdgFt1eO0tEZBLiB0Q8Zbsvzgswi8Fw2TQtPZYI58fj8VHbfXJegDxavpeFoxWjbZUoN8m2LliAWbRz25qsF6YlqcVFxGRpsY+PA7yoAE9s66C/u5Az2VYAeMt2P50XgO9nW7W4K1F8EYbhYdv9dVoAPo2g7WfrBttKu60lCcCn0evnq2mzbRXnxInyH7eGCcDnbCuowvvhodTi28bvtpYhAM9X04GXrY1C07b3b1Pb2kzKEoDPbGs3yCJR3G2VGn6GFD5iTaNsAfjULeW2FZ6yrUrDn1KL77TWb7KmYEMAPreaHq5+XLCtSsOd3LZOJpOXmevYFIBPI+j42XpssK1aXEUUQ+YyVRCAz9nWBGKjbVVKHWcuUiUB+Gw1PRxkUhV2W//I2xqG4evMJaomAJ+GH7TMthXhplO2taoC8Gl0eu0sNh4CiR8R4w9Y3am6AHzetiqDbUU4H0XRG6yu1EEAPn8ItDo0bfLdrq1trZMA/ODd1ssylQNWJ+ooAJ/fbS3a1r+lhu+1jt5ndaDOAvB9DoGUhgd53wDgNVZl6i4AP9i23kCECasqrgjA53KXYjAlCcC2SMVZVjVcE4BPY2C2rTu5bQWAY6wquCoA38e2Kg23EOHzra2tl2yPv9MC8LlDoPXEmHL/q9aiTwJ45QixlyRgsK0IF5RS79I/wFu8CJ7Ps5XQeAh0HxC+LD2lsglTEDeEH/jZKFo1JQlskAAeCWD9CeU0Bbn6Ek6ML+E0Hb1DL2FvgblIZEOXSn/iaSHm2ZtuaCvCq95mHIzhDKsarqwDfNqOXrIy8HQgU9EjyeRc8h6rA3WcggI6lLcz8C1KS6lcYtYOJWaVkJqYiKKtpNTEBQ+8T8m59qabIaWn2xn8Hn2gUa1PlBSKK/SJ0gIHvkUf6dFnqo1bCXee/aH2T1LKD1nToFIFlqFiHZahcjUNK9gEGhLbfXa3ZJlPJcusCdCnon3VKlupUPxCZSsXKAAVbq1o6eKQbtywU7w7TeOT/9dD0SieR4Bgn/L1SiVguw+1hi5wsAxdYVKjS3yUUl3b7XUOusbKMnSRm2XoKkPL0GWe9qHrbAmCIAiCIAiCINh/5x80yG0CBQeF9gAAAABJRU5ErkJggg==",
	draw: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nOy9B1hU59oubKz0OsDAAENvgoioSFHERi+C9A5W7CK2qNgFpDepAoqKaGKiScxOM23HxMSdRJPYUXrvvc39X887gyXJ95/vnOvsfPv7zl7XdV/vMLNmrfU+99Pfd3TSpH8f/z7+ffz7+Pfx7+Pfx/97R3x8/OSSkhKxysrKKfR3ZXz89PyMeJvs5Hi7zOR4o7y0I/fKC9JQXpAxXll6GpfL8nC57DQqS3NRcSYbFWeycKmExmz2XmVp9sj7l0tQUZiRVFaQbFCWk2Kfm37cdOJ++flrp2VkbJ7xXzrpf5UjPz9/WmVl5XR6XVacaF92+kTM2dMJO6+czcCFwmRB5Zl0lOUmoTQ3GRcKM1FxJgcXi7NxoSgL5wszcDYvDWfzUlFekMr+vlgsJOPSmWxcu1CE9y6dEXxQWYLLpdlPz2Se8C/IOLojP/WYKt0vIyNjxgTp/08eE5MvK0wwLj2dkP3uxZy7n75bgmsXc8bO5SeNlBcmj5QXJI+U56UIyvPTcE4k7NLcFJzJTkZxVhKKMhNRlJmA4qwElOacwtm8FJwvTGdWUXEmZ6yyJGekojhrpLIke/R6ReH4+5cKUJp36p3TKYeP0L0BvEGY9P/KgUmTXptwYdbxd87ln/rlxltFqChJGz6Xnzh4ruDUcHnhKZQXkjBTcS4vFWeyk1CQdgK5yUeRlXgYmYmHkZV4CJkJ8QxZifHIPXUYealHUZh5EiWMjFSUk1UUZuJCYcb4ufzUodKcpMGLxem4UJQ6lHXq0I+ZyfG7JtwSucJJ/9PdDU3y7NlTkqisnHLmdMJnb1/IwfmilLGi7OPDxVnHxwszjyAv7RBOpwqRm0yCjkfqsX1IOBiHY/u249CebTi8ZxuO7CVsF2LfNhx7cztOHIhF0qFdSDmyF2nH30RmwkHkJB1BbvIR5KUeQ37aMZxOOzqam3J4uCQnafRsXhIyEw5soeejuCByif/z3BL5+QkNu1CcmnW9shAVpRkjZXnJY8XZCeN56UeRkbQfSUficGz/VhzavREHd23A/p0b8OaO9dizbS12bo7GjpgobN8Qhe0xUdixkUDvRbPXsRujEbcpGrs3r8HuLWuxZ8sa7N26Dm/u2IADcZtwdN8OJB3ehdQT+5GZFI/s5MNjBZknxotyEgXnC1JQmpO0gp4vPj5+KmHS/5TjZnz8VNKqvMwj3hUlGanXLxfhbH7qaHlhuqAsLxn5GSeQlrgfx+JjsS92PbZtCMOGqACsDffFmnA/rIvwx/qoAGxYHYSYNaHYtC7iBTYT1kZg49pwbFwThk2rQxliooKxLjwAq0N8ER2yCmvC/bF5TSj2bFuHQ/u24dTRvchKOoy89JMoyk4SlOWl4EpZbm9xdtKGgszEhRNuadJ/92PCnEtyE+OuXjiNitJMQWFWwmgx+fSMROQkH0XysX04vG8bdm1bh81rQ7EmzB8RQd4IC1yJSBJeRAA2rQ/H9i1rEBe7EXt2bcPe3duwL24b9hJ2bsXunZuxe/sm7NoWg52b12Pr+iisjwxBRKAvgn09EOjjgbCAlVgXEYCt6yOxL3YjThyMQ+rJg8hJOYairEScyTk1fL2iCBXFGfU5pw7Me/X5/1selZXxwvQyLzHunQt5KM1PHirMShjOTTuOtBMHcTJ+F+J3bUHctnXYuiESMatDsT4qBOuiQphGb90QjZ3bY7B/3w6cOLYfqSnHkZOVjLy8DOTnZSAvV4ScdJzOSUVuZgpy0pOQfuokEo7GI37fLuzcEoP10eGICPZHsJ8XQv08EBHgzUjeui4ce7dvwIkDcchMjEdBxkkiYuB8Yfp4eX5qW1bCfjN6/v+W7ogKKxoLMo5tu3ohDxeLMwbL8lIEBZkJSDlxAPG7t2FbTDTWRQQhKsQPUaF+WBcZjO0xa7AvbjuOH96P9JSTKMjPwvnyYrz7TiU++vg9fP7FR/j675/i668/xVdffvISX3yMr25+jM8/+RAf33gP196+jIvnSpGfnYmEo4exJ3YbYqIjEO6/Cv5eLljl5ogAT2dEBflg+/pIHNmzDeknD6Iwg1LapLHzBeljxVkJg+mJ+/VpHjdv3vzvQwIVODQWZ5/YcvlsFkpyk4ZKcpMERVlJyEg4hMP7dmDbhmhEh/gjxG8lwvx9sDYylGnr8UP7kZeVjksXzuJvH1zD11/fxE8/3caTJ/fR2FyDtvYmdHS2oKOjBe3tzS/R1sTQ2tyAuuoqPH7wG376xw/48rNPcbWyEgW52TgefwDbNqxDRMAq+Lg6wnOFA3xcliPczxNb1oTh0O6tSDtxAPnpJ4mE8bOnU6jGGMxJO2JM86EMadJ/l+NCcdqWq+dzUZR1cjw//QRyko8g+eibiN+1FdvXR2FdRCAig3yxJiwQWzesQfzeXchITsD5sjP48P3r+O7W13h4/1fU1VWjs7MNwyODEAjG8J85xkZHMDDQh/bWFjyvqsKPP9zBJx99iIvnypCelIg3d+7AuvBQBHq5wdtlOVa5LkeIjztiIoOwb0cMTh3Zh7y0ExQTxssLqGbIbMxNPmlB88K/cq0wkWaeKzgVd/1SPsqLUsdKTycj+9Rhlp/v2ryGTXJ1sC/WhQdi6/poxO/diazUJFwqL8XHH76P77+7hQf3f0VtzXO0t7eiv78P4+MvBS8QEAT/MV6eiZGRYXR3d6OxoQGPHz3Endu38ckHH+BCWQlSE44jbusmRAX7wdfdCZ5OS7DK3RHRwauwZ+s6JB/dj8LMRKq6xy4WZeHy2dP1pzMT5v9LB+abN4XB6p0LuT9dKstCeVH6OGUXSYf3MuGvCVmF0FXuiAr0QeymtTh17CDKSwrw2Ufv45ef76Cu5hk6OlrR29uDgYEBDA8PY2xsFK+K9X/nGB8fx8jICAYHB9Hf14vO9g7UVVfj3j/u4OMP3kNxfg4OvbkLa8KDsNJlOZyXLISXy1KWtr4ZuxHpCfE4k5uM0tMpgzeuluG9KyVxNL+J3tW/ZMZTWpCQU16cgjOnk8YKsxKQfuIA3twRg/VhfgjxcUOYrye2ro1A8vF4XD5fim+/+gzVTx+gt6sN42PDTHNfVfeJv8bGxjAyMorhoSEMDg4woRJJLzGIoaEhJvDR0VHR1/9I3NjoKHo6O1D1+CG+uvkJzp0pwKE3d7NEwN3RAc5L7eDjugzrwv1xYNdmpCfGoygnCeVnMkYqynJwsTSHFWuVlb5T/uWC7tmilN03rhbjTG7icHbKYSQc3o1929cjJjIQEf6eiAj0ZhlH8vGDuFpxFne+/Ro1z56iv7cTEAiF9tKBvKrJY8wVdXS0o7GxHs+rq/DkyWM8evRQhEeoqqpCXV0t2tqEFjQ6OvK7q7x6cQH6enrw/NlT3Pr6C1w4W4wjB/YgOjQAXi7L4LrMDt6uS7A6bBXe3BmD9KR4nMlPQWV53vg7FUUoOZ2mJZr6f30Tb6Kxlp0dL3XuTOr1y+dzkJd+bPTkoZ2I3RSF6CAf5nYiA32wc/NaZCQewbUrF3DvH9+htameuYbxMRLW2B8EJhCMY2hogLmlmppn+O23u7h9+xZu3vwEN268j/feu4br19/B++9fx8cff4Rvvvka9+79hGfPq1j8GB4chGB8/M/d05iQ1Ma6Gty5/XdcvliG44f2YW1kEDycF2P5Yiu4OS5CZIg39u/ejKzUYygtSB+/WJqD4uwE1jv6VziY8GNjQyQrSjOuX79SjOK8U2OZSQexZ/tahAd4wcd1KQI8nbB5TRhSTx7C9SvnmfA7WxsxNjrMhAwIMD4+jLGRAYyODGFkeAB9PZ1obqrDo0e/4vb3f8dHH32AS5XnUVh0Gmnpp3DixFEcORKPw4cP4ujRI0hOTkJ+/mlcvlyJzz77BHd//gm1NdXo6erC2MgIiwcsSIvGCRc1OjyE1uY6/Pj9LVReLMPR+N0ICfCEw8K5sFtgDlfHhVi3OhBHD+5ETtpxFGYloaIkC7SuQHP/L+2gTmj/jaslWu9eykdxXtJQQXYCTsbHYePqYKxyXw4PR3uE+Xni8N5YXLlQgrs/fIPW5nqMjw6/7pvHRjDU14Ou9lY01Fbjt19+xheff4LKS+eRlZ2G+Pg3sXnLBkREhmCV70q4uzvDxcURLi4r4ObmDD9fH0RHR2L37jikpaWgouIivvz8Czx+8AAdrS0YHOhnWdH46IiI9JfH6Mggmhtqcef7v+NcWT52bFkH5xWLYDXXFHbWs+Hj5YitG6Nw/NAuZJ46PE4x4WJJxk//ErUBkVCSf+pxcW4iTmccR+rJ/XgzNgbRIT7wcV8Gfy9nbI+JRnFOGn74+020NtZgeGjgj255fAwDfT1oqq/F3Z/u4Mb77yI3OwM7d2xDQIAvliyxx5w5s2FsbAAdXS1oaPKgoaHGwOerw8BAFxYW5nBwWIzAgADsjtuFvNw8fPzR3/DwwX20tbZgaLAfgrFRutnv784+a26qwddffoL01ASEh/ph8aL5sJpnCgcHKwT4uWP7pmgci49DVsqRsXMFqbRSlz6xhPpfIHih+7lYlmN8sSx7qCgnkQn/0N5t2LIujLmfoFVu2BAVjKRjB/Hhu2+h7tlDjA33C3N55u9fydoFAgz096K66im++vwzFBfkY/uWzVixYimMjAygpKQIKUkJSEqIs1FKSgLS0pIMUtISkJaRgoKCPNRU1TDLzAzOjs7YvGkz8vNO48vPb+JZ1RP0dHeIMq1xEcZeWANzRyODqHr6EG9fqcC+vXHw8XaDne0cWM03wzKHBQj2d0fcjvVITTwwevlsLipKsj8iN/xfsqo2UYxcf6vk1yvnC5CbcWL8+IGdrD9PeTQRQAEtfl8szpcU4Kfvv0FfV9sLoZPGk9uhYCgQFVEDfb149uQJPvnbDaSdSkKQvx9mGhsyIb/xxiRMmTwZstLSUOWqQFNDHVpamswSuKoq4HAUISMjDQkJCSjIK8LIwAjOTs7YvXs3Lpwvxw+3v0VjQy2GBvogGB+BYHwUY2NDGGVx6KUidHW147tvv0Z+fjY2bVoDR8dFmGNhxOC4zAbrVwci6dhelOQlD33y7nm8V1G0n+Tww1/tiiaKrotnc3+sPF+ArJSj42/u3Mj698Gr3BAVsgp7dmxEfnYKK7Rqnz/G2PDgay5nbHToNQIG+/tR/awKn338N0aA3ypvGOnrQUZaChIS4lBV48JitjmWLVsCN3cXuLu7wslpBRY7LMKcORbg8zUZCWIzxKAor8AsITAwEKcSE3Hjg/fw8OFv6O5qZ1YgVIAhjI1Si+OlS6Ik4FnVY9y48S4SEg4jINALlpYmMDRQx3xLYwT6urL1hOKcU8MfXinDxZLMuL/cDU0Iv+h08s7zpdk4W5yJ1MR4wY7NqxHs5w6/lc7YsDoEyZT1XK3Ar3fvoLO9hWneqwQIRoeAcVH+LyA/PIjG+nrc/ubvKM7Pw7rVq7HQxhomRgYwNzeDk7Mj1q9bg0OHD+JUciJOnUrE0aOHEbcrFhHhYXBYvBjaWnxISUpCXEwM6mpqWOLggJ2xO1B+rgw/fH8brS2UfQ0xSxRQ7UHW8EqPicigtPfnn7/H+fPF2LJ5NWxt50BHhwsTAw24rliIuC1rkJt8bLyCdmYUpLecPZ1i/pf2iSZK8YqzuRXvVJ5BcV7qaOKxNxGzNhSrvJwYATs2r0FJQTa+v/UFGuufo7+/F+Pjo6yoYsInLWQEjAAC4Xujw8PoamvDg1/u4b1330HC8WNYGx2FwAA/rF4dhSNHDqG8vAyffvoJvvvuFsPnn3+Gt96+jPS0VKxdsxoLrOZDiaOIadOmQFZGGrPNzREZEY6c7Ex88flN1NdVM60XVQOAgKxhmKWpExgc7Ed9/XN89tkHOHJkH1Y4LoKujip0tZSx2GYO1kcGIPnIXhRlJAx/8nY53r9Y7PyXrRsIgw3eiI+fNLk479RHl8rzkJedNHY0Pg6rI/zh7bEcAavc8eae7bh6+TyqHv6C/t4ujJK/F0z4faHwBSODAPng8RGWnYwND2Owtw9N9XX4x/e3cfXKZeTn5iAzIw3FxYWs+Lp37x6amprQ09ODvr5eVnDdv/8Lrl97F0cOxcPVxQka6mqYNnUyxGZMg56uDnxXeSMpMQEffXgDNc+rWLCdyH4EAuo3DWF0bPhFPBijyruvE3fv3kZ2Tgp8VrnCyJAPTXUO5pobItDbGftjY5CVcGjk7ZJcnM9P3/RSNn+R9l+5mL/n/atlKM5PHc5OP44De7YgMnQVvD0dERbsgxNH9+PjG9fR0lDDtH1iwmNjlIsPMQLGhwcgGB7E+AhhCOMjwxgZHERfdxea6urw2y/38P3tW/j21tf48cc7rN1A3U0S0IuKdnwcDQ11uHnzUySfSoT3Sk9oa2lixvSpIgK04OPjhaSE4/jow/dR/fzpKwSQyxnB2NggRkYHMDomdE1CFzmM6ucPUV5ejMjIIFhYGIOvoQRTIy3Wqti8OhiJB+NQmHpi7KMrZbh5tUTrLyFhIticL8ve897bpSjKSx1OO3UIu2NjEB7sAz8fV6yJCkZa8gl8/fkn6G5rFmoamxUFXhL2wAsCxocGMDbUj7GhAYwTGcNDGBsewvBAP/p7ulnQ7O5uR29vF2vCkcDpYjRSg66/vx+PHj3AtXffxaH4g3BxcmQWQMKXkhTHTBNDhAT7Iz0tGTc/+wh1tc9/R8AoRkao89qH0RGqT6hSZqUhmhqr8fbbFdiyZR3sbOdBX5fH4sASO0tEBXohfudG5CYdHn+7NBfvns3U/msIEFlA5fn8PR++W478nFPDicf3YceWNYyAIH8vbNoQjdNZqbh96yv0dbeLdJ/mNorR4X5hLUBaT8If7MfoQB8DvR4fGgTIYigzYZJ4ifGxUdbxJCtobm5GTU0N7t69i/ffu4b0tBRERYbD0nI25OVkMH3aZHAU5bDAai42xqxDyZlCfPfd39FMVfiLriu1JkYwNNSHwYFujAz3MkKEaakAHe2N+PDGNezbFwtHx8Uwm6nLLMB+gTmCvZ3ZtpeM4/vHiICLJcIG3T+VgInc/+3KYvurlSW4UJo7fjozQUDV4ZYNkQgL9EFY8CrEbotBcUEOfvzhWwz0db2S+YxgdLAXo4N9TPsnhD/c34vh/h6GkYFeRtDvu6MkfMrRa2qqce/eXXz11Ze4du0aiouKEH/oACLCQ2BnuwBqaiqYPn0KxMWmQUdbE+5uTjh86ACuvfs27t+/i67O1pfFmGCMub+hgR4M9nVieLBHmBCI7tnd3cas5tjRA/Be6Yp5c2bCfKYuFlmZwd99GXasD0fKod2Cc7kpuFiYcf+f3h2l/T00fvz+RbevP30H54qzh7NSjyN+33ZsXBuG8CAfRIUFYt+u7ThbUoC7P97GYP8rBIwNvyboEZHgh/p6MNTbjcHeLgz0dDBhCBgJogxpdBCdbS347dd7uPnZx7hUcQGZGel4c99eREVGwMlpOSwsZkGdx4WkpBjExaZDlavECNm0cR3OFOfj1q2vUF9fjYH+boyTr6drUwOQtL+/G/29HRge6H6N+J6eDnz91edIOXUCIUG+sLeZi3nmhrC3mgVf1yXYEhWEk/u2ozj9JC4VZvUB+OemoRNp1ruXy9xufvgWygozh9OSDmPfrs3YEB2CCFpqjA7Fof27cfF8KX75+QcM9HaIyn4B8/EDPZ0v0S0c+2ns7UR/Tzt6O1vR29WKkQGhoKhDOtDdhqeP7rMgmnc6G/v27UF4WCgcVyxnhZmmhhoUFWQhKy0BBTlpaGmqw87WGqujw5GZnoxPP7mBp0/uM40eGRH6+rHRAYyN9GO4vxuDPR0Y6G7HcN/rBPT2dLCqOCcrFWujw+C4xA42c00ZAStXLMT6kFU4vHMj8k8dwdmc5N5/emd0goD33xYScCYvdfjU8QPYvSMG66KCEBnqh43ronD88AFcqSjH/Xs/YpAWW4iA8XGMDvajp6MN3e2t6O5oQXdbC7rbW9BDy5Dd7ejrbkNXezO6O5oxPNiNcZaeDqOnowU/37mN8tJi7InbAR9vL8yfNxfa2lpQVJCHlIQYE766mgoszEzg7rICWzduQHZmKj768D08enCX+fPhoR6MDvdhmFxOfzeG+rqY8Pu72tDX2YqhHloYosJMGLX6ejvxj++/RVF+NrbErIGbowNs582CneVMuCxegEhfN+zbshrZJw+iNDup759eiL1qAZ9+cBmFOcnDCUf3so1Va2iXQ6g/Nm9YjcTjh3G1sgIPfrmLwZ4uYUAdH8NQXy86WprR1tSAtqZ6hvaWBnS2NaGnsxU9nS3obGtEV3sTRod6RX56FN3tTbj11efISj2F8OAAzLOczfpB1JQTF5sBOVlp6Gprwn6hNSJCAnEk/k2cKynGl59/gqePf0NXWyPT9LHhXowM9WCgtx29XS1M6NSf6iUF6GjBICUMYy9rBFKeu3duo7QoD7GbN8DTaSls55rBerYRlttYIshjBXauD0P60X0ozU7sA/4LCDh5ZC9it67DmsjfEXD5dQIEoyPo7+5Ca2MDmutr0Vxfw9DSWIuOlnp0dzShu7MZHW0N6GpvfEnA+Ag6mutw8+MbOHHkIDxdHKHD14DEjOmYNvkNyEpLwUBXG47LlmBLzHpkpiXj+tW38I/vbqHu2RMm4LGhXowP92J0gGJNJxM2kdJNxLc3o6eN0IT+zlYIhida5QIM9nTi3g+3UVaYh9hN6+HpuBS2c0xhZW6AJQtmw99lCbZFB1EgxpnMk38dAeSCPrtxBYW5RMA+xG5Zh+iIQESE+GHTumicPBqPty9dwP27P2Ggq4Oln5Tf97a3o7m+Do21NWiue52ArvYmJvj21np0tjVgdLBbuEwpGGZrCFTUxe/bjRVLFoGnoohpb7wBsWlTwFdXw7Il9ojduhmlxQX44rNP8PDXX9DaUIeh7g6hQMnfD/RgmOIMWVprEzrJ8loaGAndrU3oamlEb1szxgcplpIPGsdAVxt+/u4WzpzOxrb1q+G2zB42s2fCahYRYA4/FwdsiQrEqQNUkB37CwmgIHyDYkD6cNLxA4jbHoPoiGCEBq3C+tXhOHxgHy6Vn8UvP95Bb0cb037y/12trWiqrUVDTTVa6mrQUl+D1sZatDfXoaOlAe0t5JZq0NlSi5F+ih2UqQyhpaEaH31wjQV35+VLwOdxISMxA1xFOVjPtcDGddFM+D99/x2aGhrQ093N0t3xwV6WTY0N9GKwqx19HS1M+F3NDehsrkdHcwO6WhvR1dKAjsY6dDc3YJQF4jGmNH1tLbjz1RfIS0/BhshQONrbwMrcSOiCbC0R4L6MZUIJ+3bgdOLhv9YFffbBFZQWZAynJBzG3p1bsCYyBCH+PogODcKbu2Jx7kwRfvr+NiMA1GIY6GP+v7GmGg3VzxkBrQ21jICWxlq0NdHrarQ0VKG9qRpDvW2AgJp1Q8wCyAUlnjgM/1VemDPLBPpa6phjZoxAH0+kn0pgMYIyKOHa7zgEIwMY6e1kgu/vaEV3cyO6mhrQ2VT/Ah00NtPrOrTV16CzsQ7D3Z3CDu3YCHqaGvDNpx8j7fhRRPh5w8HKEvNMDWBjYQxneysE01JldDBO7NmOrGMH/rogfLm8wO3jaxdRVpA5nJl8HAf3xmLDmggE+3kj1H8VYrdsRHFeLu58dws97S0vCGhvbkRD9TOGlvpqZgHUK2pmr5+jqbYKjTWP0VJfhYGuZgjGBoDxQeaivvnyM+RmpSJmbRRcljtgse18eDovR9z2Tai8cBbPnzxgxdqE/x4f7kd/ewvTdtLutvpqtNXVoL2+hv1Nwp4Y2xtq0Fr7nH021NnOGoQYHUJnXQ1uvn8dx9/cC19XJ1ibz8RcE30smmsGj2ULEeHrhu2rQ3F89zakHd7b95eloeXFWW7vXylDWX7G8On0JJw4tI/t7wzx84a/tydi1kQjJy0F3355Ex3NjazhNtLfg/amBib8+udVaK4jgT9HU00VGmqeoOH5Y9Q/e4jaqvtoqH6InrYGFjgxPoCu9gbc+e7vKDuTz4q88CA/+Ht7YF1kKBKPH8JH77/DrvdirZeWF/u70d1cj7a6arTUPkNzdRWaa56hte45Ohpq0dlQiw4io74G7bXVaKmuQnvtcwy2tQBD/RD096DxyWO8f7kCe7dugov9Qswx0oWlkR6WLpgDX+dlWB3ojR1rw3EkbguSDu766wgoy012e+dCEUrz0ocLs1KQcvIQ4rbGsJ3OXq6OCA/yR+Kxw/jsww/QTP33wX5GAPncxhohAU21ZAlPUf/sMVsrrqu6j9qq31D9+FfUPbuPrtZajA11A2P96GprwI/ff4PzZ4tx+MAexKyOxJqIEOzcuhFZaUn49MPrqHv2mBVtrL8zMsi0n4TfXFOFxudPGIgEoaZXo73uOdpqhGgnYqqr0FFXjUFqHg70YrirHVX3fsKlkiJsigqH/TwLmJDbM9DGCpt5CPRwwvpgX+ygXdU7NyFhf9xfR0BxVqLblXN5tENsuOR0BrKSj2PPjs0IXOUJxyWL4OPhwuLA9bevoPrJQ1ZhEgFdrU1MUxtJKDVPUVv1CDVPHqD6yW+offIrQ/XjXxgBnS01GBuglkQP2pprcPubL1BWnIeD++LYDy6IgF3bNyMrPQl/e+8dPLl/j+X1I0N9GOnpRFdTPRqfPUF91SPUPX3IQFbWXPMULTVVaKl+gqaqx2iuesKET4R0NdViqLMV6O9Bf2sTfrl9C8VZ6YjwWwlLY33oqirBXI8PJzsrhK50w4Ywf2YBB3fE4MT+HX8dAQVZJ9zol+olp9OHzxZkIy8jCft3bUWAjzsc7OYzEjavX43ykiL8+tMdJvj+rnaWcZDvF1rBE1Q/uY/nD3/Fs0e/MMEzEp7+iobnD9DVUoOR/g4M93WgofoxPv/4A2SnJWJrzFpGdNAqT3aPUyeP4J0rFbj34220Ndair7uDpZrt9bVoeIT1SgYAACAASURBVPYEtU8foubJfdQ8vo+6qodofP6Yof7pA9Q8+hW1j35D07PHaK9/jt6WBgxTG6S7Da3VT/HNp39DyolD8HZZBmMtHjQ4sjDT1YDTQiuE0Xb2iABsXxuGA9s34PhfSQCzgLP5KM3LGD5/5jSKclJxaF8sE8pi23mwt5mP8CBfZKYk4MtP/4bqJw/Q3lTHCGhrrGMkNFQ/wfPHv6HqwT08e3gPNU9+RX3VfdQ/u4/mmkfoaavD6EA7Brpb8PTBPVx7qwLxb8bBz8cDDrZWWGJnhQAfT/ZrmrPF+fj2q5vMDVFro6+9BR0NdWh8/hR1zMruo/rxb6h9Std/iPqqh6h5/CuqfvsJzx/cY4R0NtWiv7MZg12t6GquxaO7d3D98gXsj9sKR3tr6KkrQ50jDVM9DTjZL0CYrzs2RgRix7pw7N8Rg4T4uH9+GjrRji7KTHC9fDYP54qyhyvKClCan4kT8XtYM26ZvTUWWVtilaczDuyJZfv+aRMuCYcIoCq0s7WBxYDq1wj4DQ1VD5j2t9Q+Rm97PUYHOtDX2Yz7d+/g3Jl8bFwTCdv5ltDRUIWeJg+28+cgKjQQaUkn8NH77+Lxb/dYakmZF43Ntc/R8Jxc3cPXCKiresBiTdX9n1H96Be01D1DH/Wf+trZ/Wqe3sdXn36IguwUbIgOxSIrC+hrqkBbVQEWRtpwcbAWEhAZgNgNEYiP24Skw7u7/5JtihNb8Urz0vZfv3wWlWcLh8uLc5CacAib1kaw3cXkhpyXLWL77pOOH8K1ty7ht5/voLOlEcN9Xazz2FpfjeePf8WT+z+j6sFdYfB9Sm7iPhqrH6G7rY65n572Rran6HRmCvxXukObp4oZU9/AjGmToamqDKeli7F/1w5cuXgO9+7cZtZFLq/9VQKePsDzCTf39D4D3ZvuS687m2sx0teB0YEudDTX4B/ffYXzpQXYt2srvD0cMX+2CYx11WGiq4EFFkZwW2qDMD93xEQFYufGyLGTB2KRuD9O/9UNa//0JcmyvMw4IuDyucLhitJ85KYnYP+uzYgM8WVdw+WLbeDpsgwxayKY7/7ikw/RUF3FCBjq62TFFgXfp/d/wtP7P4sE9Cuek5Cq7qOjuRaDPW3obKnDnW+/Yu7Mw2kZOLIyEP6LB5NYNWwz1wLbYtaivKSQWRoFeGoxUDwgK6NYU/P0AdscUPXwHrsnaTih+smvaKx+jJ72Boz0daK/q5m5u+tvV+LYwT1sdY/WACxnGWGOmT4WzDHBUltLeDnZIzzAg60L7966Zjzh0C6kx+/W/EuXJD++Vrnni79dxVvlxcNXzhdTUcasYE/sJkQEr4LrCtribYtVni7YG7uFuaL7d//BOpuDvR3obiM39BR1zx4wlzDhGmrJDVU/Zp9TO6KnvQl373yLvKxU+K10A5+rhGmTJ2PylClQkpNm8YYKv4pzJew8sgBqsE2QIMy66D4PX1yb7ttS/wzNdVWM6L6OJgb67NaXn+B0VgrWRoVg6WIbzDU3xjyLmbC3sYSjgw3bbOzvtQKrQ7zZ9vuDuzePleWn4WLJ6b9mUX7CzxUWpqtcvXjmhw+vVeCditKxy+eLcLYoG5kpJxgJlKkQASsc7BAZ4o/UxOO4+bcP8PzxfXS3NaKvswW9HdSNbEBXSx06m2rQ3liNtobn6Gipw1AfVaS0YNKBJ/fvovJ8KbZuXAt763nQ09aClrYW5s42RaCvNyvGbly/ylJRaq5Rx7O/q5VtCKB7dbbWo72pBm2N1cyiyK0NdLVioLtVdF4D6p8/wp1vv0TFuWLWWiHrnT/HFHPMDGG3YA7cnRez/U5Bq1wREeSFTWuCsT8uZvR0+nHkpp1InPRXHr+IrODGOxcqPvvwbbx1sXT0auVZvH3pLM6XFSAl4Qhi1kbA1XEJ7G3nw81pKRNe0ekslhVVPfqVFVfDveR3OzFIK2Ed1JGsR3drPXo7mjEy0AmM9LGR0sdPblxDWuJxbFgdDt+VHvD28kBkaCAO7tuNcyVFuPXVTdQ+I3fSwmIMESxsNzeye3W11aOrtR7d7Q0Y6GnD6GAX8/m9nc3MOm7//XNUlJ/BkQO7EejnCdsFFpg1Uw+Ws42xbLE1/LxdEBHsg+gwX6yL9Efs5mgcPbBj+HJ5Hi6W5v5TN2aRSb1mVvGiOFB5riDjrYslOF+aP37p/BlcvVzOfmlCJhy3fSO8PV2wyHouFtnMg4+nC3bt2IzivCx88emHQhJaG9Df3crcUmvDczTWPkVTXRVrypGg+rqamdCePf4VX3/+Ec6XFSE54SgO7I3D/r07Wdu7KC8b77/7NmtVPHt8H011z9EiulZ99WM01BCeoLH2MRprn6C5vgrtzbXo6RASU/f8Edu9d/HcGRzavwshAd6wt5sHc1N9mJnoYr6lKZyWL0SgnweiwvywJsIfG6KDELtlteD4oZ3jBTlJKMpPcXj1X4Px9fWdQuOrEAXn/5x7mrjIK8L/PV6wnZl64ufC3FTk56SNlxWfZtVqVloiE7a/jwcT/lwLU9gusIS3pzN2btuIgtwMtmH3159/wJNH9/Dot59x98fv8OMP3+Cnf9zC3Z9u47e73+P+vR/w693b+P7bL/DJh9dQebEUhXlZyExNQmZqAvsnCspLi9iv4j//9G/4/tZX+Mftb/CP218zoX7395u4/Q3hc9z57gvc+e5L/Pj917j343e4f/cHNhKxF88Vs1Z3kP9KLLSxhJmxLgz1NRgBC+bNwoqldmzLZXCAJ8KCVrINaBvWBA8nHtuDY4fidr+qlP+Zfy/pP6PxL7/A2Hs9sPhWMoYl6PXeuC2/Hdi3Awf2xY6fOLIfCccO4eD+Xdi4IQreXq6wtZ4DE2MdGOhpwmKWCVwcl2BTzBqkpSSwhft3rl7C1bcu4tLFUlwoP4OK8yW4dLEMlRVCXK4oxcXyYpSeOY28nDRkpiUhJek4khOPIjX5JLLSklFwOhOlxXk4V1rIrKS8rABlZ06jpCgbZwqzcKYwG2XFOThXksfSywvnilFx/gzOluazVsbeXVvht8oD1vPMoa/DgwZPEdqaKphppIW5c0yw0M4SK5bZwc1pMTzdlsDHazkCfF2Ht24Kx5ZN4SdIDnEbo9Q2bPDXWB3qbxAW5jMzNNTLeF2Et/7mtf66q1eHaG+MilKLX7tW4n8p+Pj4cLF1kcEmgX6ujj4+TiG+Pk7h/r7OQaH+7p4hISuXB/m7u/n7u/n7+rhG+Xu7RAf5e5YH+XkhLMQXqyODsXZ1GCLCA+Hn6wHHFYsxb+4s6Oqog6uiwGBooA2HxbYIDwvAztgtOHBgFw7uj8PePduxe9c27N69HXt3b8ce0bhvz3bs27vjxee74rYibsdmZkmxIuzcvom9tyt2M+JiN2Hnjhjs2LoOWzevxuaN0dgcE41tm9cgdut6tngUt0N4ztaNaxAZ5g83lyWYa2ECLU1lKHOkoKQoCU0eBwZ66mwzloW5IebPNYW1lTn7yZK93RzBsiVWcHGy6/Fwczjn7m5/zN11Uaqr88J85xU2l1YsW/CB03Lrdx2XW19xWWZ9xXWF7QUvZ4eMYB/XqE2rQ9gOuj89Nm4MVQzwcV7juMz6ykIbi4dWVmYtC6xmNdpaz35ib2d5Z6nD/M+X2s/7u73d3Lu21pZPbKznPFtgZfGTnc3cMQf7BVjqYIOlS+ywZIkd7O2tsWDBHJiaGUJTkws5OUlISkyDvJwkdHTUYWVlAccVDvDwcISnlzPc3VfA1U0E1+UMbq7L4eHuCC8vZ/h4u2KVtztWeXvA18cDPl6uWOnhAi93J7i7LYcr/bzUeSmcnRzg7GgPx+ULsXyZLZYutcGyJTZYvswOTssXwcVxMVwcHeC4wh5LF1szoc401oY6TwEKcmKQlZkGRQVx8FTloautykgw0NOAgb4G26A701gLs0y1MdtcD+bmOkOzzXW758zRG7aYrU+vh81NtUfMZvLHZs3UGjMz1RozM+aPmRnxRy1n6Y862M6557fSaVtcXJT0H4QfGxIiucp7+S5bG7PnJsZa0OKrCjQ0lMHXUmFbsw31eZhpzIeJMR9GBprQ1yOow0Bfk4EezshQC8ZGOjA21oWJiR4MjXSgraMOFa4CpKRnYPr0NzBjxhuQlZUAT00Jevp8GJvoYqapPjvf2EQPRuR/jXRgaKTLXpvM1MOsWYawmG0CyzlmmGtpjnlzzTF3jhnmzJ4J81lGMJ2pz9wc3d/QgJ6HBKYOfT0e9PTUoKfHY4I0NODD2FAbRgZa7Jl1ddSgqaEEFWUpyMlOh7TkZEhLTYGCvBhUubLQUFcEX1MJGhpKUFdXhIa6AjQ16D1F8PmK0OQLRw0NeQZNgrocNHj0XTmo82ShpiINFSUpaHDlBKZGfCxdNO/r6JCVy0Vif9m6iAhxX77YzuJHfT1VKMhLjktKiEFKarpATk5MoCAvDiVFCXCVpcDlyoCrIgMVFVkGZWUZKE/8rSwLroo8uFwFqKpyoKqqCGVlOcjL0++4ZkBMbAojQUx8CqSkp0NOXgIKilJQ5EhDkSPDIKcoDTkFKQZ5BfqMri8HLlcRaqocRpw6T5mNaqqK7F5KSrJQVJRi95GTE3sBem4FBXEoKoqDoygJDrkXjgyUONLg0H0VJCAvLwZZ2WmQlpoMGempzAIUFMSgpCQJLlcaqqqy4HJprtKMKGUVKSgpS4CjJAEFjhgUFWcIFBRnCBQVpws4HDEGJQ59n+5J+5WmQkJ8MmQkpwh4XBlYmusNr3RdnLQzJpz7GgneXsv2zDHX61NSFMf0aW8IprwxCdOmvQFxicmQlJwCKcnJkJGZCjm56eyhaWLyChKQkxN/MWFZWYI4ZOXEmZbLyv0R0tJikJSaDnGJqYwIgrjEVEhITmOYITEV08WnMMygzySnQZJhOqR+B+H70yDBrjUZYuJvYIbYJAYxsUmQEH+DPbu09FRISU+DtMx0SEsTZrBRRno6ZGVpPjMgrzADHI4EOIriTPgTUFYmSLGRBK/IEWPnyilMh6zcNAY5+WmQVyDipjMoEjgkoxmMWLEZkyA+YxIU5KbDUE8NSxZZfhXq7+UW7+s7kTm9McndxS7dzIQPGelpgslvCHst06ZNgpjEZEgQJN+AlPQUyMhOY8KWlxeHvDwRICESvBhkZGZARkYMMtJikCLQa1lxyClIgqMkCyUVOSgqyUBWXgISUtOYgCeELCE1nUFMchqmT5AgNgViElMhTiPD5BcQp1F8MsQlpkCcETmZPesMIkH8DYiLTYI4ESA1QcB0SMlMFxJBJMjMEApfQYwJnjRbqO0yTONJ6C8IUCHNl4SSigQUlcQgN0GAAgl+OuQVp0OBM52sAQoEzgxwlMShyBFnFkUWICE+CfKyU6HNV8SCuYZtXm4OiauDvCxfdFDdHBfmms3UgrzstPGpU+gXiaRFkyHNNGcapGSmQUZ2BuSY9gvNmUOuQ5F+HkrmL3QZE2BuhNyCojQ45JrUFMHlcaCiqsBIkJETh5TMDEaSrJwk5BTI9UhDRl4S0nISkJQRh6T0DEiSxUjPYC6MNJcIliXhkZWR9ckLRxk5MQZp8uWk6TLTRQpBgqZ7iEFWnqyVFIesVxwK5JqUJKDMFQpfjSf/AlxVWagwMqQZKSqq0uw8joo4FJXEoaAkBkVlMXCUxV8DEUSfE1kcZXJx9NxTISMzBRyF6eCry2O2mfbIMod5H/l7r9i0ISJCgxHg5brklLmpzqiykiQzXTJnGdnp4HBIe6WgqCQNJRUZKCvTg5FPFvp6goqKCFxFqKgKoayqIHytpggVniLUNJTB01RhI73HUZEDR0UWSnQNNQ5UeUpQ5SmDy1OCihoHHK4CO0dRSQ4cZTkoKctBhSsPVVUFqKkpQo33EqpqCuCqktDk2bMRlFl8egX0N8Up8ud0Dmk7QU0WXJ4c1Hhy4KkrvMBLMoSfqfJkGVTUpF6Ay5OGqroMA72m95S4klBWlWSEEZSUSVlnQIkzA1wVCfA15GFqojluZ2322N1lUXZ4iLvT2rVrp03y8Vx6eM5s/V6eqiwFJQEFJhK8Go8eSBFq6hyos2xAiY2UIWloqIjAFUJTFRp8IdT5XBFUoK6lAk1tNQa+jhp7n8ggqPNVwdfmQUtHHVo6GuDrqENTm8fe52moQF1DhY0afBVoanGhpaUKbR2116ClzQVfSwhNOo+vAg1Ner7XwZ6bshpNDjT4SlDnK0JdUxE8DQWoa7wUPkFdQ1EE0Wca8uBpEuTA48tDnS8PTS0FaGorQoOgJfxcVZ0IlXlBmKoaWZAEVLmS4PFkmAsyNdGE9XyTOscVNhcDV7lFhoSsVJ7k7bHs4Bxz/T41LhEwVUD+kTSGHphNiE2KCz6f+3KCmiosx9fkqwqhpfYCGlqqL8DXVoOWLg9auuoMmtrC90nI6uxcNWhqq4PPwGMgsoTvqzLwtVWhpaMGHR0edPV40NEVQos+Ewl+ggR6j4HI0Xr5uQZfGZqaykzo6poc8DRJsH8OIUmvQhHqWkJBq2srMKGT8DV1hNDQUoC6ljzUNOUYCWoEHlmZFFRUJJn289SEBJjN1BRYW82sdmYEOK6japkIiLcwMxikVEtaeopARoYIkGNC5osm8aqWCQmgCZHG0XvcP2o+nUffIWHoTpAgFC6do0YuSZOsQQgihFmQJhHDFQpfS0iAUKCq0CYydUR/0+d8EqgSeBoclq/T8058JrQOIoGeTYkJXV2dA1V10lR5qDLXIgdVNdJWOaipyzMwAvh/JECDESDS+N9DiwhSgBpZCRO+DLhq0lBWkYAShzIrMXC5ktDR4sB8lvbYIjvzn9yc7fKDfZ3CRQSs2GNhZtBHRYOU1BSB9P8RAS8F/0cCVP9IgIYKVNWVoaquBK66ElQpTpDbITK0udDUmfieCCLBs+cQuRpyK2rMRZK7IAK4TPBkHbp66mzU1uFCU0tIAJ1HwuaqEUQx4P8SATSq8xVeEqBKmRQFfUpPZzBL0NVRxhwLveElDpafeLnZHw8Ldl25Nsxfd5LvSpftc8wNu6nIEhIwQ0QA+V01RgL52ldNnpm0SBDCv18lgDRTmb0m383X4YLPrEDoVuh9IQFKLPAyqAsJoOuQ8Pl6PGhPQJf8/YTWk+sTKgDFJBIqswBNqtxVoaunAT19TegbaEJPXwPauvTMdF0OE67aq9ovwoTgWTzQVPxPE6Cpw2Hgi0ZmCSIrIAI4SmIiAqYJCdBVwVxL/b4VS+e/6+215E0KwuvCfHmTAnzc1lvONm7nqshCSmoqI4Ayj5cW8EcC/gA2SSFI+Dzmb5XZ33xtFfBJqDqqrxDwivarE4SEsbhBPp402EAduvrq0NFTe3HvCetjBFBiIAJ9RsI3MNSEkbE2g76BBnT0yHqURVYgDLxqlOmINH5C+BOfqZPAtZSE4E9AEZr/EQG6HGjpKoGvq8yIYPGCYgEjgCxgGgMRoKfHxby5hh2OKxZc9vNeFhsRsnJJZKSv0qQgX9c18+YYN6ly5ahYEVDhwlGSAU9dGITJxUwQ8DoJyq9Da4IIkQVQ1sHeV4amNmVDJGDKgJSgpjEheCVGBlkEuSzm88mFkPBFBGgTASR8UTYjdDciN8gnzecyd6NP/R5jbZjM1IWxiTYjgwggBdDUeqnRPA1h9vOnWq+lxMh6HRwhAb9zPZraHAYiQEtXGVo6wnM1+JTKUtou8aJC5nKloK+vivnzjFqdHa3LA3wdN64O91sQG7JcclKwr2vUfMuZDTyuPKSkpgmkpKZBkSMFVR6xKZzsRIahTQJifphIUHoNTNPZZEU+mq8MDRK+SKPU+UpQI+GTL2bgMCLIWnhM+4UkEAHaZAH6ZAnkgiggU0qqBJ46h2EiQ6PnIr9P7sbQSBszTXVhaqYH45na0DcSWgBfmyzxz1zLH0HPytei+SqDr01zmhiFboa5GvL3WsJsiLIiyoj4OkpCaHPA16K0nWoS6j+xnhFUVaVhICSg2dnJtiTA1zUqMtLP3N7efuqkYB+PqPlzTBsnCJCUmgYFRUmoqslDnflXeigVYR7+OwImzJRPD65DrkYFWjpcBiEZIgL4JGgOVDUoEArBAqimEnhkMQQtYd2gQdamp8Y0n/y/pg7FF2VWj1DxRQSQFRABpBRC7ddkWk8EzDTTg5GJFvQN1UXC50BdkzT9P/LxrxDAnxA6afQrIBejywFfV4kJnidKOwlUF5DWU21ABGiRxWhSU1KaBWJljhjUGAFcLJhv3OjqbFMU5O8Yui4iUJ+1IwJ8XNfMszBp4qnIQ0pyqkBScioUqAOqShUiZRgclnmQ4LW1Jggg81d6RXM4oodVgbYul4Fe00SEBAhNX5Wn8AIsgGqSZSj/AS+yIB1VaGgLtV+N9ycEvHA/5Pu1YDJTGyamOjA00YSuAe+F73/Vz/9vE0DuRU9Z5OuFBJDguRRsKevRkGVFmiZfAVraHGiTxfAVoaYmAxVlCago0RqDNAwZAUaNri52haFBbkExUd581owL9HLdNH+2aZva/1UCyBKURVbwf0YAX1SEvYgbf0KAMD5NWAG5IU0YGvOhb0QuTPWfTAC1IagdIQuexusEaNOc1eXBVZH8HQHGDX8gwN/Ldevc2SZtZAEyklMFUpJToagoAVURARq0EPGCAO7/ggBlaNNIk9AS+kO+Fn2fXJmoCtVQfJE+qk8EahYvJtwWWQ5lTJTDU40hDL4v/D8LxMI6RJhpCVNiSlV19XnQM1CHngG5MLreyxjEYhULqkIB/xk02XP/CQEMStDUERGgIceEP0GAOi3I8BWho60EHR1lhgk3pKoiCXU1GRjpq8KaLMDJrjAk0DU4JipISEDASpftc2cbdfBUZBkB0lJT2SKGmqo81HmK0OApgK9J2qEMLco6RMJ/jQBtJeb7tERCp4fR0KSyXkG4ejTxPgWoF0QICZhIV0mb+RO9nYmcn4IzZT903kQGJMqGeOrKrzXmmFVoCS1Qi1mg0Pr+DP9/BAgzIeFrmtdLiHJ9vjwjQJX1fWSY9tM8aX462soMZAUadA5XilmBkAA1LJhr3OzmaFcW4u8ewYowIsDXyyVuzizDXi5HGpJibwgkxSdDQU4cXGVZqHHlGGjdVLg0p8jGl80rKjzkWQFCjBNoiY6nTp1EqgpfPtyrBJBLeOGKeC/dyqt5/oTGvypkIThQpRY3dV1V5KBMPXwVKn7onpTXK77WbPszvMj7fwce1QlUsL2A/CsQ9npYB1SNOp5SDJRy0nw1NBSYpbMlS00FFniVJ4Iwl37TzIWVpWGHm6NNWYifW2RMtK8e26ri6+m028JUf5gjJw6xaZME4tMnQV5aDCocGUYCV0mGrZOSS1JTFY7UQ2egUl5NFuokaNH6KFsPVZOBqpoMI0FTU/4FARMVqSpPHiqq1BoWtpCFrWYhGQzUZmZtb2GbmbWcRa1nak1Tpa6kLAsORwYcJWkGJWXqv8hAmfXwhVDmSv8BwnaxzIt29KtVMb3H+v+UwXAJ1GaWEn1X1HLmSrK1AQL1/okE6nzSXHk8OahTYFaTgTItXcrTQv80cJXFoaetjPlzDPpcHK3PU+21dq23Ef3rY5N8vZw3zTEz6uPIS2LGlEkCsWmTICc1A8oK0owEFUUpcJWkwFWWFq4Nq9AozUZVtnYqvLk6acHEgjQJX0QApWgvCSBtJ2GS4GWZsFivnq39voSwp0/FjOhz1sd/2e/nKIsEz6FUTxrKJHxlWrcQgqMsCUXRMiJbIlQUjgSqUGkxhvr1RJoSPYOIHCUVSbaYwla1XgW9xzCxADOxKCMGJS6RIMnaD1zy+awLSkuc9E8pTIGc3BRmBbpaHMy3MOh3Wm5dEeTrtDY62suYpaH+vt7+8y3N6lWUZCE+fZJAfNokyEpOB0dOEkoKUlBWkIQKh6K5FFSUaBS9ZmQICVHlyrCWKwMRMgEiQBSghHFBSIAqESBaeVJmiz00viJIJWpmiYRLC/9coYuhJUNaHOLQeUrSUFEh65SDmhpZp5AkEiQJi61esaVCWn6k2mY6gyJnBlsyJBI4SqTNIqFPCH6CtFfBSBP/cwJUxKFMJHAlGajzqUwrZHRf2cmQl5sCFSUx6GlzYGWh3++01OpSgA9Vwr6z2S7E6LCAWfZ2837Q4XMhIzl9XFKMVvKnQVGOWJSEssgCVJXJJZElSAqhIsmCjBCvCJ0r9RJEyIR1UHxg/pEyK9Fih5pQqCRIFWXh7gO2A0GJFsPpbxnm6ng8eahTzBGtVLEMTY1cniK0tCjoqUCbVbAUqMnFEWlEJq35CgVLC+v0N/VlaL2XRiW204EsgT6n1vHEecJx4jtCAdPy5UuQoF/ghQWIPlORgLKSGJQUprEVMZ6qFAz1lGFlqd/ptHxBRcCqFduiw71tN292mjEpPn6thKezQ4bFLMNBDVoSlJcQcOTFBSpK0gJVroxAQ1VewKeJUjqqLg8NnpxAgycHvroc7YcRTECdJyuEmoxAgyf7EupyAg0NeYGWFkdAHUHqiRjoqzHoULFGWQcFTgr05EN5IuGqy7PsiwSrq8OFnp4q9HQJXOjqcmGgpwZjIw2YmmrBzFSbjSYmmjA05EFfnwtdHSVoaytCmypUikOUDBBEe3r4bPGFkgs5gRpPhoGnRs/L5sNil+bEd7QUoK3Fga72S9C1tfgEBWjRPVi6LXytRfej7Ignw0Z9HQ7MZ2pioZXJU9cVC84FeC+LXR2ycsmGDUHybF04MtLHynm5XeV8S+M+Y0NN6GlzBXps0lwY6qvBxEgDM400YGJI/3idGoxpNOTB2FAdRoY8GBiqsUnr66kwGNL39LgwIIET9LjsPDNTPixm645bzNYbI5ib6QhMTfjs+kaia03AxFgdpiYaMDPVgrmZtmD2LB0GC3NdwWxzXcGc2Xqj8+cadi2Yb9KwwMqkhjB/nnHTXEuDbgsLvdHZs3UFs2bxBbPMoPAOagAABW5JREFU+AJaiTKbyceroGvTPYwMSBm4rFdjaKAKYyN1mBhrYKYJQVP0DJoCczMtgcUs7XEGM22B+Uy+YBZdy0STgc6bwExjdcyk6xjx2N8WZlpYYGnQtWTh7FvuTtaFAT5Lt0eHuDttCfVlv65h/y1HZORKcx+P5duXL13wrq21edX8ucZdlpYG/XMtDfvnzzVqXzDPuNVqnlG79TyjVmsr40br+Sb1VvOMW6zmGbfOn2fUPs/SqHuepWEvYb6lYR9h3mz9/rkECwO6RqeNtdnjRXazfrJfaPGtwyKLW4tszX+2tZ712GaB2TMbK9Ma6wUzq2nJzsbKtNpmwcwqW2vTR7bWZo/srGc9WGht+sDO2vTBIptZvyyyNb+32M7itoP9nM+XLp73tyUOc28sXTLv/SUOljcc7C0/X7xo9nf2tuZ36Xy7BWZPbBeYPrG1Nnv8EqaPba1MnzPy5hq2zbM06CVYWRp2W803brWeT/ObWW9jNbPWZoFJ1ULrmQ/sbWfdXWxnfofBxvxne+tZvy20Nn1oZ236mO5ht2DmU9sFM5/ZWJnUUMFFclowz7DVdp5xPZ3jYGd+23npvGueLnbZ/l5L48ICXFeuj/I1fG2bIu1z3xIRqB/o5+bj5bHsiLOTXcmK5daXnJZbVzo52px3dbItcXdemOPpZp/u4boo081lUa67y6LT7s72OR6u9jkeLotyCW5OCwtcne2KXJ3sSlwc7UppdHVddNrNxT7dy33xKU+PxScIXm4OiSvdFyd5eTgkrvRccmKl59JjDO7Ljnq7ORz38nBI8HS1z6B7ujvZFrg72RW6OtnlsWdwXZzq6Wqf4u5un+LuuiiJXc/D/vhK10VJHm6L0txcFua6ONsV0xxcnRaecXexO+3uupCeMcvDxS7L3cnuND2nm5NtgZuzXTHNzcXRptRlhV2py3KbMpcV9Nqm1N15UZ6768IMem4fd4djBC83h4SVrvYpBPa+66Kkle6LkrxcFqV5ONvkuS63Pu+ybMFlp2Xzr7gsm1/hstz6vNty6zIvZ9scH3f7Y4Hey7ZGBriu3Bjhy/7HPnaINgqxndK0LX3jxii1sDBvh+AAl5DAVc6rQwI9gsOCPTzCwrwXhUT6WEWGetlFh/ssjgrzXhQV6mUdEbFyTkSwEOTSIiJ8bCjQhId7264OX7mAQN8JD/dZTIsRhPBgz8XCz30to0JWmkZH++oRqEiJWe0zMzrMa35kqMeyqGAPj+AAL79Qf7egkEDXgMgwj1VhwR4rQ4Pc/IP83UKD2PseAaFBrr7BAe5+hFB/t9BAP7fIIH/3CHodGrTSNzTIy5vmEBrk7il6vTIi1NMlLMjLOTjAw1X4vgddI5CuRwgL8FgZGeTmHBGxcgk9P5tDsOfiyFDXZWuDPZdGhnrZR0V5WUcFellHhXk40PXDA12DKdUM8l2+McBn+UZ/72Vb/b2W7ghauXx7kK/j+vBAp+A1oR7LtkR46/9hq/qrRFCatDkyUmltaKjm2kA3Trx9uFh8vP1U4S9B7Kf+f0tLS2OttwfdmIq6qQN5twgqDdVTH8oGagHUh4ayGaelsSJtCkEBYD2hoWyhoaGcaaGh/EVpkSKFyaFCoMorLS1SJD0uThrUpQdFGmh4NzMxSikxMUopJSVUMS0tXBmEMzOjlNLSQuUyMmLEQKvA4+P9BdLSQvnj4+MFoqOj+eLj7TlAboHgXPbc6Gi+ZKgdmVFRgjGurtwgcZCbQW4Huz80lM0D5H6oGOwa3NDQULaJEz3YQfrT00OlU2ID1HITQ7USEnxMU2P8rTKi/W1BiTI1IdA0KyZUJS3NB+++gVEwCkbBKBgFo2AUjAKGYQsACXAvktNXlEUAAAAASUVORK5CYII=",
	b: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nOy8d4zceXreOTpJuzAs6w8ZBwvWrqzZnWVskp1jdVVXV3dX6Orq6lwdKuecc+zAbnLIYRzOcMgZDnNostk5d3NITti5O9snCWcBXtjC2oAg2IC8GO/MWsGaz+FXXK0sW4dzthx+wItiAKq73uf7fcPzPm+99tr/ev7X828/vPbazxWLxf9taGjo5yUSyS/U1NT8Yk2N4xePHBn6xp/ZG2/4v/kXTfHNoSND3/gzczgcv+ioqfnFokTyC/NDQz8vvB+89nP/zg/7X8+/+1z01/9yZqj71xxq9SGdUlOratKIW6uH5Ye/O6z97rfHhw+/bpg48j2LqeINi+Xo60ZrxevjloaDY6bOivGJgcbxYUv7qDbSOyovDveLT+uVtZd86kM3M0O/tnFx/Jf/kh/3P+8Dr/2c36/4ZlzT/DesQ12/4lGpftWvURxxaFRSs6pneLizz9MjHch3ikbOiur0V08cM906ctD28PgR19PKCu9K9VHvevUR50b1Edt6c4VlpaPK9FTbZHw43m685VDorwbVQ2djvb35zHCvpzjeMzxpUElPjrcfiQ1JfrU41PUrpy2av3HRr/jm/7Q348xE519PTUjeiPZLxX6tfNihVgUsas3suEJ7Y6Cjf00tGfpc3jr+A6nI/PuiZuePGhq8X9TUhr5oaIj9y6bGxI9bGhNfNtdHvmyuDXwprvX+WFbv/pfdLc4vBtrsX0x0Wn9k7hz/fVvn0A9ccu3n/m71WqRXcSPZ1zWbGugMFHXy4TmDSvyWp+uN29HOv/7a/yzPHb/il0/ZJN+KDndWOLs7VHqFzD/WqTw/0tk7P9Q19HxAMf6bvV2mf6RsN/2zjjbLVx1S19cdHSE6ulJIOwu0dU4hU8zSqZxDrpilq2uGTlmRLmkGhTRFT3uC/s4YOnkEXaeXEan569G2sa/00qF/ZpL1/iNrh/o3nXLVc79GMR/vl58vjHf5Z00K1QVXd8Udv+JbG8X/gcNUcUjyS5Pj6rr4sGLcrVEUDHL5zUGZ8oWmTfNDVdvwVyqZ+WuV3ItCEaGjK4ZMnqRLlUOhmULVN4dq8C26Ry6iGb2MdvQyfbrLaIcvohk4i7p3jm71DGrlFD3KIhpFnp7ODD3tMTRtPrRiG/2iCYbEw4y19X1t6uz5yt3d/cPYQPeL/Kjq5kmjqnDW1j1+wa2ue9sj+aXX/kd55oeGvjE90vXtgEJWZ+qSjeg6u2cGZN2LmjbNbynF2n/a2Tr4B53i0T+Wy+z0qKP0DxQY0s0xNHqWkYmLTFiuYnB8gMF9k3HPbUZ9txn33UXvv4vBK9idV/9nf59Ry3uMGt5FN34Z3eh5dCNvoRt6E13/NCOaPCOqOENyH0MdNoY79Ohkuj+ekA//gUXZ90+davVv+bWKxfiQfKak7xq5YFfU3Yj0fvv/mR/6xmv/HT4/NzT02s+HGxv/WlClOuxVKweMCuX0SGfPE41s4O8p2ob/hbx9gs52MzKpg45OH0p1kv7hacaN5zE7r2LzfogreJ9A4imhzAqB3BrO3DLW7CK27CL27CKOzBLOzBJu4TX1FEf8MbbwI6z+e1g8N7G6b2B1foDFdhWT6W0M42cZGZiirztFb1eIXpmX3g4Hw11GxuXDGOQ9/8LZrfx7oQHVk8yocnrOoh44b1Udfmuo8a/ND73288Lneu2/h+ejouQXsiOt3/aoZAqjXJkY6VLf75MN/I6mY+wLtdL2k26V50/VPRHUvUk0/QX6hmcY1r+Fwf4udt+HuCMP8MUXCKZWiOY3iRV3CE/u4J3axDG5ir24gq2wjD2/jKu4imdyDW9pHW9hDXduFWdqEXtsHkd0HmdkHlf4Ic7AfRzemxitVxkZO8fA4Cx92hJaTZa+7jB9cjt9Hbo/HZJpfzLWof7ColT+TqhfcT8/pkzMWlWKs+7ebxeLxV947a/yIzQ84aGuX7F0SiqG2zt1GrH6Ure0f69bNvq7qi7z19reEAMjWYbHp9HpTzNmPo/e/g4m93Vsgdt4oo8IpBYJZdcI5TYJ53eIFveJlp4RmtrHd3Ib18l1bJPLmAtLWApL2EsruKfX8c1s45/ZwTu9jbu4gSO7gjOzgjuziiezhje9ii+1jCM8j8F1izHLNUYMbzM4do7+oRl6NSl6lH56umxoZRP0tfd9bVB2/65Xo9xLjSgvnTR264REfT089CvC53ztr+ITM0p+1dWjbB+VyePylp7HLfWDPxS1GL6SyjxfK3qS9OlmmLBfxOa/hit8C1/8IcH0AqHsMpHCGrHSDvHJPWJT+0QmnxEqfkQw/xGBwjN8pX38s7t45jaxTi5hzD/BkHuCubCIY3IN98ltfHN7eOf2cE3vYC9u4Shu4Spt45ncxTe5T2DqGd78NrbEEmYBCN89JlwforNeZXDiPL2DsyjUWdpkQaRiC0rJ4Ne6Ds1Xbk33D/Njqsdv2VTxc7ae9reNql997a/SUxw68g1fT+frY3J5b79Mc1IhGXrWLjH+Xlu76086VXHUA5MM6s8y4XgXR+QWvvQjQvklIqV1YlPbxKZ3iU/vE5t+TnTqOeHJ5wRLz/HlP8Kd3sed2ccr3IQzz4lfeIZnbh1r6SmmvADAU2ylVVwzW3hn9/DM7uGY2sVS2MZS2MJa3MExuY97+jm+2Y/xTj/HWdjFll7HHF/GGHrMhO8+o66bDJmv0jt6HoV2hk5lAnmnk56OCQY7+/7EqOz+PW+v4llOpzj5pqmn95qv5/X54l+RBG3u7/6OQdUzqm3vv6iUjn5fKrX/pFMZR90/ycD4WcZsVzD7b+CKPsCfXSBUWiUytUV0ZpfYyX2iM88IT39EcPI5gdJz/MXnePPPcWWeYYvvYk/s4snvkzr3MfkrHxN6cwtnaQlz9gnm7AKW3DKOyQ3cMzu4Z3axlXYw5rYw5LYw5newlPaxTz/HPfsp7pOf4px6ia24jyW7jSmxhiG2hD6ywIT/AaOuDxkyv4t29CwqbY5OuQ+ZVE932yBD7aqf+HqV38+NKi/OGlSj58zd3/lv6niB6Ar0dVaMK3tt/V0jN7s7Lb8tV/i/lPdk0Yy8yYj1XYzeD7GF7+NKPsGbXcZfWCVQ3CBQ2sI/tYN/SggPe+UT7s4/+6l9hDv/ElfuBbbkM+zJPVzZXWKzeyTf3MZXXMKaeoQhdh99/CHG5GNsuRWcxU2ck9tlAEz5bYz5XYz5fUylj7BOv8Qx+30cs59hn/kUy+QLTIVnGNI7GNJbGNMbmJIrGKML6IMCEDfoN1yge6BEhzJEu9RMZ+sA/W3KL82Krt+ODcpvzhiUtvddfRVC0fFf3flCInJ2d3/P2K21D8on7vQoXL/T3R37Q83gDNqx8+hs1zGHH+JKPsWXXcVf2MBX2sSdX8eVW8eZ28Betk3s2S1smW2s6V1smT0cuY9wFz4pmyPzEnvqGY7kFt70Mt70PNbQHSZ8HzLqvcGo7xYToXuY4gvYMqvY85vYCjtYiruYi/uYix9hmnyBZfoTbLPfxzr7fSwzn2Ga/ARD6QUTuWcYBJAK+1gKu1jzm1iya+X3G/Pdot98GdXQNG2KMGKJmY7WITQS1R+aFF2/Ex3suvOmpdt+wdn9vfn5+f+6iTna11lh7O53aDvGH6gVvh90a/J/pB0+w7DpHcZdH2IJz+POrRMo7RCc2ic4vY9vcheb8OFSyxiSy+gTgq1giK+ij69jiG9iSu5gyz7DVfwUz+T3cec/LQNgiaxicN9mzHyFIcNl+vWX6De+zYDlXUYcH5TjuCn6FGtqFVtuG2txD6tw8qdelp1vPfkZlpPfxzTzfYxTn6EvfcJ46SVjxedMlJ5jmnqBdfoFjpnnOKaflZO4ObnAWOA2/ZYrKIZO0qaM0yS2I2oZQt4i/yODsvMHqbGuB3PmHsf7geGK/yqOf89R84vu7u7vGJR9tmGlcPJ9/7CnN/eH/WMXGLFeR++9U64whErDnlnHld/GU9rDM7WPs7iDKb2KIbWCISW8rpevvjmziTm9jTm1jVm4BdlnOPMf4yx8jCX1jPHAKv2WO3T1nkIsTSDpzCBVFujomUbef5rukfP06t9l0PYhOs8DJiKLGFPrWAp72KZeYJ8RTv9n5dNvmvkM/dSnjJc+ZkwAYPI545MvME6/xDLzEvusEKpe4Jjew1ZYx5hcQBe4TZ/lCvLhOUTKJM1SBxLRMOo29R8aVPJ/GB1W3pkzqW3n3N3f+bvvOX7xvygAQrVjVvWMDnaN3tQonL+j1mT+aGDsHKP26xiEDjS2gC25jCW5zER0EUNiBXNmA2t+G0t+C4MAQGYNc16oUHZxlJ7hmvoI1+RHOAr72HJ7WDN72DPPsCR30flX6DHdoa33PMfqArxxYJyjlXaqGwM0iOO0dOQQK6do65mjY+AtFGPv0Gu7yUhgvgywtfQMx8mPccx9hm3u+5hPfop+6mPGSy8YKz3/KQDP0U89xzj9HPPMc6wzH2ETAJjcxpJbxZB4/Oom2N5FoTuFVJ1C1O6iVTRKR4v6j8zdit9Jjshvnrb1jF6LDr3+X8TxQiteHJL8ql4oNdv7L/Z0Wn9brY7+K63uFDrrdYz++9jiT3Fk1nEKzs1uMB5fRp9cxZTdxFLcwVzYQp9ZQ59dw1zcxj61V3a+Z+Y57ikBAMH5wk3YxJzYZCK8gtb+gM6RqzQpZjlS5eGNAxNU1rpobI3RKssi7irSqijR3FWkSTFJa88pOkYu0SPchvBCORkLFZBj9hPsc59gnnmJXnB68RljpX3GJ5+VbaK0j35yH8PkPuapfaxTu9indrEVN7HmVrEkF9CH7jFofw+V7jTS7jQtEhetzTo0bd3/yqDo/O34cNfFGZO898PY0K/Oz/9nbta8srq/6Va1S7VSoc4f/Vyp8H/ZOzjNkPltJrx3scae4spu4Cnu4pl8hqO4hyGzgSm3WT7ptqk9LJPbZee/AmAT+9QOrul9PDPPcE8Jp38bc3K1XBZOhJ8y5HmIUv8+Eu05GrumqGoMU13rRSJLo1BPo+o7haLvFO09J2nsyFHdlqZGlqdJfRLZ6CX6PHeYSK1gKe3iOPkc++wLzNMfoS/tMV7YYby4g35yl4nSLhOFHSYK22UzFLexCAdkchdnaQdXaavcXTszQt/wkCHreyiH3kTclaa51YG0ZRh1q/JLi1L6eWxYdvKKWyW97NX+zf8sjhemRUKZNdEpqRiSyOKdoqFnbRL7TxTqDH1jbzHm+gBz5DHOzFrZ+b7pj/CdfIl75gVWof6eeobz5HOcc8+xzexhyK2iz65gKgjhYRPH1DbuqR2cxS0s6RUMkSeM+h8y7LlHr+UD2ocu0KKeo1k+hURRQqk5yfDEJfS2a+jt1xk2vYt6+C2a5XlOtMY5Kopxoj1Nk+YkSvNVdJFHmHJr2Kd3cJzcxzK1g6GwyUR+A31hE2NpG0Nhi4ncBuPZNcYz6+VbasquYysKv9su/uk9QjP7BCd3cadXMfofMmC6Rpf2NC3tSRqabIgb+tG0tv3EppQ8mzN2xt9xdVfwUfEXXoP/NAJPYDUjva3fHm5X6NTi3sedbebfk6tSaHVnGHVcwxJ5gD25iD2zhqu4i3fmI7xzH+M6+RLrpNAAPSs733VKCAN7GAsCAEvos4sYBXZTINOmt/BMbmJLL2IIP2TI9SFqwxVkA2do7p4uh5Y29Ul6Ry+gt13H6r2NPXgXW+AuBo/Qwb5LR/8cDfI8ldIkx9riVHVmaBs5i9Zzg4nEY+yldTxze9intzDmVjBklzFmVzAX1spmzAu5aYWJ1DLj8UX0iUWs2TVchS38k3tEZj4iNv0RocIO7sQqBs9D+vXX6Ow5TYMoTmO9AXmznFFp6++FteLHxdF23ZVI77cFYcF/EgACpexQyRRDst7L8nb9D7u7Q38yMHoKg+t9HPF5vAL7mF3FGF/Ekl3HObmLa/Y59hmhvt7EVNoun3zn3D6O2R3MpTUmMguMJh4xlniEOfOEwOwWobltPPklzJH7DNjepbWnRHVbjBppnBZ5DsXA6TLv708+xRV5hDV4D3PgLubgXYyB2wza3kM5dh5J30lqutIclURoUBeRGy8xHLiJLb9I+M1dvCc3MWefYkw9xpR6gkWgtgVmtbiMNbdUrnrGw48YDz3CHFvAkVzBKxCDxV1ipWdlC+d28cbWsXofMzTxPm2dczQ1+ZDU96Juav2Tifb6H4Z6xZffNKoUApX9H+38+aEj33CrOg6PybsTfV26Pbnc/ZO+4RLj9rexR+7jyy0TnNzClV/HKBBc2TXspR2cJ59hn94rX3XT5BbWmR0cs0Ic3sYyuYoht8BE6iH65ANsuSdETm8TP72NL/8Uc+gWfcbzNMjiHGv0UCcJ06bKox07hzP6iNjkFl6BbhZACD8oHwJn6jHG4N1ygpSPnqVOkeFgi4+qzgTSkTm0jnewJB8QPrWJf2YVW3YeS+pB2WzpeVz5BTylJdwCu5pewBR5hDH8CHt8AXdqBX92g0hhl1jx2SvLPSOY3MEdWmPC+hB5z9u0SjJIGsdRNMnpEzX9xCZv2UsMtyWmRjoO/0dzRkLosSkUg30d2ntqufF3VZr4nw4bz2IOfIA7/ZhAcY1gmf7dxJxZxZwT4rpQdQhJdwdTaRPz1CbWmS3sM5vYp9exlKnkBcy5R1hzj/BMPiV5Zpvkm1v4cvMYfdfRjJ2iThLgWL2DFlkEZd8UOsvbeNNPiZ/cw5ddwynchOTCq0NQEv4ukGof0iOAp8pwoMnN8bYgot4C3Yaz6EM3CE4t4i8t4Mjcx5a8iy15B0fyHp7sIwKlRQLFJbzZpzgTj3HGn+BLLxPMrBHObhLN7xLL7xPN7RNJ7xMU+KnwFibnIpqhG3TI55CJ3XQ1D9DdJP3TcVnz73p6mu+lde2DwizhPwqAYXFTXW+bYlopHfkHCoXjTzXDJcYcV7DH7uLJPsVXXMM3JcTv7TL1axMSaXETS2kDqxDTp3ewzQg3YAPr1GqZRrZMLmKfXMQ9/RT/zBKxU2sULuyReXMDb1qgh9+me2SKhlYvtU1OOrtTDI6dxuy+hj+zSGR69xWtkRc4pTWiM9sk5oR/W8YUuo3WdIFmVZqDjXYqWt00KePIh6fQOS/hTd/Bl72LO3ULV/Imzvgr82XuEykuEC0tES0uEcotEc6tEC9ukiztkCjuEs/vEsnsEkhs441ul53vDG5ici0zMH6fbu3bKLoyKNts9Ig0jLZL/tQmb/4Hob626fy4rO4/2PmeIckvKZvbRrpaVI/bpRNfdGujDBpOYxJOf+Yx3vwS3uIantIG3qkdvDP72Ce3MeWFGL9UNoOQcHOLjKXn0SXvoYvfLttE4jbm9F0c2Xt48w+JTD3Bn72HwXOF/olZujQpGkUuWlo99PYXMVov4AndJJBZJFjcJljcIlQS2NQdMm9+RP6sQGOvY4/eY8h6GUlPlooWJ8dETuplAaQ9SXrHZzB5LmENXMHiv4zZdxmj+zJ610Us/ndxRz/El7hLIHkff+IhwdQCsfwaicIW8cI2sdwOofQ23tgW7sg27sgOrsgutuA2E85VhvV30fadQd0ZRt2qY1QqZ0La8oVdKX7sU7eNeCT/AYN+QToSHVbUyZtkM6IG9d+XyMxfdQ9mGHNewpG4R6C0jK+0iqckVD7reKd3CZx6jn1yh/HUEgORB/QGbtPjv4nSdY1O62XaTW8h1Z+mfWIO2cQs8ok5lPpZegxzaI2n0YxN09WbQiIPIZJ6aGy2I20PoBudxeW5Sjh+n2B6EV9mnVB+i2hpl9TMM4pnXjJ17iUpoZKKzzPhfBfFwBR1Uj/VIid1rS6a2z20KyP0DGbp0xXQjuTRDGXp7kvTpYmj7M+gHZ1mUP8mOtN5xqyXMLquYQ/ewxNdwJdcIZDewJ/ewivcgOQevvRzArlPCOQ/w5v9DFtok1H9NTTKDIpmPZpmFdpm8VdDrZK/PyaRzJhkijq/4t9T8lIcV3zL06cY72hRLTY2Dv6orcvzrzWjU5j81/FlHxOeXicwtV4GwCncgukdAqc+wlrcYDj6CJXrA9pNb9M6cY6mkTnq+yep1eap1aSp16Ro6EnSqI7TpIrSrIzQLA/RKPNS12KjptFMbb2J+noz7W1+Roancdjfxh+8hSf0EGf4Kd74CqH0OrH8FumpHTJT24SExOy7hc54EbmmSKPER02jjap6MzWNJhpFVsTtbmRyPx2KQPlVIvPQLHEgknmQqaJ0aTIo+4t0D06jHXuTEcu76F03sQQf4Igt4kqu4Upu48ns4y98THDqc8In/y7hk/83nswLDPZ79GmmkbfY6KrX0lXb8a+V9bIf9TR2LPY1K8b76hXf+vcCINDXXWFWqwtScf9vNUtMdPbEGTCewRa5RbCwSHRmk+D0Bp7SOk5hED61hffkHsbMElrfLaSGy9QPzHGiO0+FIsVReZyKrijH5RGqlVFqFWFqOgNUST2caHVwrNHM0ZoJjpzQcfT4CMePj1JTZUDc7KK3O83YyBwm42VMlg8w2e9hdT/E6Z/HE3yMNzSPy38fk/19RsYvoO6doU0Wp67RSWW1kWPHxzh2Qkdl9Si19XqaRWZaJXZaJQ5aWm3UN5tobLXRKvMh7gojUcZpU6WQaQooh0/Tq7/EsP398rDGHF3CmtzEmd3HU/oY/8znBOf+LsG53yxT50bPPAMDZ1CI/bTX6ZBW99BRo0ZWo/qtjlp1obO2u+L/t+sV5IJ6Rbeqv6vvprRt7J+Iu7yohoro7JdxJu4TKq2UAQhNbeIV2vO8cAs2cBQ3GY0+QmG9SuPAKY50pvg7zR5+vcnFd0QeDrb5ON4RpFYZpV4Robrdx3GRg8N1Bt44Nsx3DvXxne/18b0DfRw+OMDxo6PUVZoQN7rolEZQK/L0973F8Mh7jI5dZ3T8OrqxqwwNX6ZXewaFYhKpNElzY5DaajvHK/QcPTTCoQMDHDyg5dAhLUeP9lNTraOp0UhLi4VmkZUGkblMMbdIPTS3+2hsD1AvDVIvE25nljbtDIrRC/TZb6ALzmNIrGHN7eGYfIlr5jNcs5/jOPl/Yck/Z8L7mMGRi6hlCdobLLRW6xBXj9BcOfBPRFWDN7sb+lXb0eN//f9Ti3rR/8Y3Uz1db/TJevyK9sEX7R22P+joTaLVn0bvuYY79ZBgcYXw1DqhyU18xU1c+TVsuVWMyUW0npu0jZ6jurvIAUmYb9c7+DuNLg61+amUR2nWpGkfKiEbLCLpSdHcGaJa5OBI5TgHjg5x8NAwhw4PU3F4hKqKCWqPGak7ZqKhyo6oIYBMWkApfxO18i3UijMou2ZplxQRNSWorw5QfdzJiaMWThw2cvzwBMcOjnL0wBBHDgxw5NAAxyoGqa/V0yZ2IpN56ejy0y73I1OGkHXHkCqjiLoi1LeHqGoLUSWNUifPItLO0aV/B637LrrYMobcDqbiR5gnX2KaesmEQG2ndxj1PmZk4l361VN0tgYR1dlorjHTUGX4g8Zq44se0bD/LWvjGxv+N775lwIgqJQ9mk6xWqo53ybR/bBT5f/j3tFpRu2XsQRu4k4+KtfJ/twKwZIwVtzEU1zHknrKcOAecuMVmvvmqFLkOCFPU6fO0dI/RcfYaTSW8+g872AOf4Al9AEGzzuMWs6jHZmhU5VE0h6kVexH1OyjtclHW3OAtqYAojovzdUemqr8NNVEaanPIGkqIG0p0NacQ1SfpLE6Qn2lj9pKD/VVbprrPIgbfbQ2ehE1uBE1OBE1O2mTeFCr4owMTzE+cYoJw2l0hjlGTacZs55jyHQWzbhAa0/R3J2jujNJdVeG+p4pxCPnUdg+YEDgqjIbjOd3GM/vo8vtMZDZYSC2hs7/GL3tQyZ0F8o3tq01RGuTn6YG7x83N7h/qG0bPV8crhOf1jT/jb8UAGtX16+YVfJhZVvfvEg88ZWqL4HOcg6z7zqOyD3ciXncySe4k4sECusES69ugSn+BK3jA6Qjb1GvmqSyM/OKBhh/C639CqO+97HEbuPJPiQ6tUhscpFIbh5/7A42tyCUOoNGO4lSmaVTlqSjLYFckqRLnKCtMUJLTZCGE36qj/qpOhqkoTJGS20SUW2S5uoYDZUh6isDNFQHaKkPIhVF6ZIm6GyL0yGJImuL0CmLolQm0OlO4nBcweO/jjf4Pk7/e7hC7+OJ38YeucmE9z205ou0D81Rq8hyoitDlapEY/+btJuu0ht6xEhqFV1uC11uh6HMNtrkBv3RFUZDC5i997BYrqHVnqKjI4ukLYGoNUGLKPJVn2x8PqGtHi4OHfmVvxQAXU/73xqTqwJdkqHnzRLL170jk5i9V3GGb+NJPMItdIixxziiQt2+Rqi4hb+0hSn6mB7ze7T2naK6K8+J9hQizTQD9qsYQrexJx6Uq6fI5BKZ2Q1yc5ukZ1aJ5xbwhW9jML/NwOApVMoine0p2lvjdIiSdLSkaKuPIxJO+PEgxw96OHrATc2xEI3VcVrqEjTXxmmsjtJYHaa5LoK4KYZMnEYuy9LZlqRdHEXaFkUmi6NQZhifOIs/cJNI8gGR9EMC8bsE04/KTViosIAz+YAx3w0UExeoUxU51pnlmLxAjWYW8cTbaAIPGE6tMJrbZDS/zUhum4HMFsPJdfTxZewCM+y+zeDIBeSqadq7Ckg6SojbM18PdI0/j6orA2ldxd/6SwEwaxRHhro0s+1i3W82SdwMjp/GExEIsIf4U49xxx/jiMxjC8/jS68SLm4RFBQIkcd066/Q0jNDZXua420JxNoZxn03sSce4UnPE8gtECkukZhcJT29RnpKAOAp/vA9DOZ30PadokOapaUhUj7JzdVhRDUxWmvitFTHqD8epuKAm0Pfc1J1LEhDbQJRU6psLY3JsomakohbUkjFGWRtGVpbYjQ2BGlsCtLcGkbamWJk7Dy+0D1i6QWiuacEUvNE8kuk57ZJzjjyangAACAASURBVG4RKK1giT9CY71Kg3qaYx05jnbkqeyeQTR6EY3vPiOpFSbyW+iFeUJprzzMMRb3sOe38KSWcQUfMqy/glJ7Gln3NG3Kk0jkRQaVY78ZUlfNRjWVR/5i9fPaaz8nNF8WjUaq7ey/IZXo/3GzNMiI4QLBxAPCmSdlBZsn/hi7IH4NPsKbWiFc2CqzhJbIE3r07yBST1MpTXFcEkeincEQuI0zOY8nNY9feI/sU8K5RWL5JRKFZaKZBbzBe0wY30GtnqWlMUFlhZeKg05OHPRSezREc6UAQIqm6gRVx8McPxGmoTGNWFxAKpssW1t7EUlbAbEkT6skh0icoUWUoqY2SMVxFxUnXJyo9dEojqMdOVfWiYZTi4SzS3iTTwgXVsmcfkb69DPCM1s4Mov0Oz6gseckx2Q5jrbnOKGcRjRygV7vPcZSKxgLW1gmd8t0u2P2Je7Zl/hmPsJf2MQde8KI5Rqq4XN0aE8h1byJVD3DsHr8H/u7q2/4NTVS/3j9Lwt+LwMgLLAl+hTfGlP2j/S0j6x3tNv+eZs8yZjlMsHEQ6KZp0QyS2WlsivyGHvwEb7kMuH8ZpkldMaWGbbdQNZ/hlpZjhPiOCJViRHbtTJd7Io9IiC8R2GFRHGN9OQG2clNUrlVgpF5jJbr9PS8SUtDkuOHfRz6roOj3/VQdTBE47Ek4roCMvEsSvU5eoevMDB2lcHx9xgYexfN8GWUfW/RoT6NpGualvYCDeIMVY1xDh738vohK79x2MaBE26qW2KoBs9h8T/An1omkF3FnXxKIL9OYvYZ8dn9sl7JmnhKn/V9GrtnON6e5Zg0R41iBunwJQa9D8pzbmHkKpx4hzABnH5B4ORLQjPPCU5t480sMur+EI3hbVSj55HrLiMfOceYVv/PfaqqdZ+6asTfV/8twe9lAIShgUPdf2i4c9jT3a7/vKvD85W8p8CE7R0CcQGARWKZFcKpZbyxBZzhx68AyG4Sye/gS65h8j2ke/QyTV2TVIoTNHTk6NGdZ8z+AbbQAwLpReLFNVKTm2Qnt8kWt0hk1vAH59EbrtPd/SaNdSmOHQxw6Dsejr0RpPZIElFVkU7Rm/SqrzBhvVfuSB3RRWyhJxh9Dxl13KLPcI1u3dt09L2FWDVLY0eJSlGaNyr9fOuQjb990MZvVLg42hilXXuGUddd7LFFPGmhs13Bn9skOv2M0OQunuw6xuA8PYb3qJdPcaItS6W0QJPqFHLdO4z5HmFNrOJMCyPKDVyZLfxFQdn3vDy0CQkC4cIKY/7baK3v0WO8gtp0jR7TO+gHjV/5lFWf+1S1Hl9/06GfDWuEVVBdh6ZWI9Xl5O3mHygUoa97+k9isL+HP/aQaHqJRHaVWGadQGIZd+QpvvgKwfQ6kewWocwmrtgSg8brZQdUiZJUi5Pla6cdv4zJcxt/YoF4fo1kYYNkboOo8MFDT7DYbjEweBlZ+ww1lUkqDoao+F6I2oo04roZ5K3n6FdeY2z0Lo7wMgFBpl7YwpVZL0tfDKF5Rtx36LfdQGO8hlz3Nm19b9GoPMmRlhS/fsLH365w860KN9+tDdOgOIlaf40x7yOssRVcqU38hV1CpX18+R3ssWXGXPdRjLxNraxElThHXXuJtp6zaCauYw4s4EkKzO0WnuQ6nsQ6wewrFXdkep/Q9A6e4ipjwbto7dfptV5F47hBn+M6phHz115V9Q986rqcV1NXKygLfwZAZ5NG3Nk6frar3fH7PT0ZBnVnMdmv4w3dJ5JaKjstld8mkl7HH1/GH18hkFwjktkkVtglmt9hwnEHWc9pKpvjHKkLUi2K09E7x6j1Ou7IYyKZFSKZVQKxp9jd95kwfIC27yJS6Qz1tRmOHY1ScTBK9dE00qbTaLveY6LvPnb9Ei73Bu7UVpn2cBQ3sOXWyjNkY2KRiegT9NEnTEQeo/M/ot91B5XpOk29ZzgszvIbdVF+rTLAr1UGOSjK0dhzFpX+BuP+p3jzgvT9ZVmB7UptYfQvMGC6hUx7gWpJkSpRnqaOGRR9lxg138EbXSWS3SWS3iEQW8cXWSGc2CCa2SZc3CYgDKgKK+iCd+i1X0Njf49e900GPDewjdvwdVf/vldVe9ajaRL/DABhCbqpulcubtJf7Wz3/Kivb5Ix/UUsjvdxB+4RTi6SzG+SKe0Sz20RTK7hT6ziT64RSm+QnNwnIwzh/fMo+s9RLUpy4ISHgyfcNLVn6Ru7jNV7D190AW/kCVbXHYZH36W7+wzi1iKVx6McPhjg8IEgx48IpeU0WuV1rGNPCTv2SIQ+IZr8BGdmB0N2BUNm+ZWllzGmVzBlVnGUhAH6Hq7JPeyFbfTJFVTWD6nXnOGQJM+3ayP87xU+/nZlmIOiPC2aC/Tb7pcV2OHJj/Gkd7GEVtDZ7tM98h5i5RmqRQVqW4tI5KfpG3kPm2ueWGqbdP4Zycwu4egageASkcgq0cQ6oawwp1jHnl1iJHCbXsc1ep3X6PPeYdh/C6fegVdV8yNvd91Vb2+T3OGoeSXiEjbPT1T0a5sajLdk7b4v+gammTC/jd17E2/0EeHMMtHCBjGh7Mxt4E2t4Umt4kmv48tsECntEpt6hiu2yLD5fTp7T1PXmuTIcRd1jRHkqhlGdJcwGd/DYrqOfvQdBnrfQimbprU+VU68h9/wcOxwmLqaLDLpWcbHHuDzbBMLvyCe/Ixw9rOyWEsQ0pqy25hzO1jyO1hzO9jyu2VdkW/mJb6p57iL+1jTG2jtdxBpz3Fckuf16hB/65CDbx11c7AuSn37JPKBS4w77mJ0P2RMCIX6a3QPXESqnKNFNkmztIRUMUvP4EX0llt4gwtEk+vE01vE0puE42sEoytE42tEkhsEBQBy6zgyy+jDjxj132U0cJeJ6ALG2GM8JjceVdUXLlXtLYe6Xjs0dOQbPwPg6OGhkfo640Npe/AL7eAME9YrOEN38QsLFAL1UFjDV1jDlVvFkf6pZdfLWiCfcPWK2+UtFKFE1VneR94zR3W1j9oaPxJRku6OEv2qk4yoTzOsOkVf5zQqcR5JbZzKQ24qvuem+ngMUUuJbvUlrM5FwomPiKZeEM58gi/7CbbMC4zp51hzL7EXPsZZFOSLL3EWXuCZ/Bjf1Cf4Sy/KYcWR3GTIfpf2vvPUtuU5WBXgWwesvH7EztHqALXNccSyAnL1HKreN1Fq5uhUTiORFWhqTdEiyZT/3jt4jnHzNdyBh4RiS68svkwosUIwuUootUY0vUEkvUkwu4lPECZkVrEKIgVBqxp7iiO9iUsoOMw+3MrKL1yq6ocOZe3IzwAQvmfhyMHB8Zoa01OxNPRjzcAs47Z3cEbvEcgtEsiv4M2v4MyvYMuulGOvNSsokddx5DfxFLbKidGX28STXMEm6GZGLtLSFKWhRuBzwkgbY8hbkqhEGdStWdQiYXCRpq02Ss1hNycOeaivjtMmmUbT9w4O3zKR7IuyhXIv8eZeYst+jCnzKbbC93GWPsdV+n5ZxOsqfIK39Cn+yU8JFF8SLDzHm9ll3PUA5dAlWjomOVYX5jtHbByscFBZ46e2IUxDc5Smlhii1jitkgQtrTGaWqLUN4YQS1JotKcY07+D3XuHUHyRWHqFoDCgCS/giz7Fn1guAyDkwXB2m0B2C09mE2dqHXtipWyO5Cqe/B7e/BYBSwC3ovLHbmXNU2d347hf8VNSTgDg0PeGjNXV5hWxNPLvAODPL+POLZdjmyW9hCklKCBWsQkACI3HTwEIFLbxZ9ZxRxYYN16jq6NAa5PA24RoqfQhOu6l9bgPaVWQzroonfVxpHVRGo75qT0WoLkuSbt0ht7+K9i9i4TSzwhmnhHIPi8DYM9+ijX7fRzF/wNn6f/EJYBQ+Kws5PUWPsVf/JRg8WPCpZeE8s8w+5+gHb9Ku2qOOlGSI5UeTlT7qG+MUN8YpqbWx7HjDk5UOqip81JX76e+PkBDYxCpLMPQyHmsjg/wR+ZJZNdIZNfxhx/jCjzCFXqMpwzCCmEBgNyfA+BICRXaKvbEKo7UGu78fnk16s8A8KiqV1zddca/AMDBgzrLiWrLemtb+MuegVnGLO/gEEJQRtD3L+HOLpU7RHNqsUw9m4VbkFvDUdjAXdx6FYZ+CoDwi5nsN+nrO0Nne57W+gj1FS6qD1iofN1I/QEb4hN+2msjtNfHaa2J0lwTQ9SYQSadQdN7CZN9Hm90C298G29qH2/2Ba7cpzjyn+MUACh+jrPwKY7sx9jTL3BnX+ITplSlj4lOfUJs6kW5QRyx3EDZfw5RR5GqxggNLXHE0gzNojiV1V7eOKAvW8VxB1XVHurqAzQJZJ5qstyhe3x3iSWXyBa3SeW38IWf4PA9xOZ9iN0/jyuySDC98TMA3OlN7Ml1LPFVLLEVrPFVHJm9V/2C2S+EoC9dqup1V3e95d8AwP/NAwfGrFXVto3WtsiXPf2zjJmuYA/cwZdaKHd2rswi9vQipuRTDAlB2LRcXmR4BcA2vtLOTwFYwy0A4BDq+3PIO0u0NkSpO+rkxHeNHP32GFXfMdJc4UZSE0JaF0NcG0VUG6e1KYOsfRpN70VMtod4Ixt444IOaA9v5jlOwdllED7FkfsEe/YF1uQzLPFdHKlneHLPCRZfEJ36mPjUS9yxFcast1APXkTcOUmNEBJFcVrb0jQ2Rzle6eb1747z+nfHOHTEwrETTqpr/TS2RF4BYLqKJ/CAeHqV3OQu6cIOvsgCdt9DLJ6HWL2PcIQW8CeFXmALfxmADWzJdcyxFczR5TIItvQOjtQGXpMPl6LyS6eiesOpqrf+BQAOH9Rbqqsd62JJ5Mse7Syjhrex+W7jTTzBk17EmV7EJpz+xFP08QUMyaWyFsie/3MA/EIoSq/ijDxBb/8Q7cBbdHUWaW2MUnfMReUBMxW/MU7Vd400VbhorQ4iqY3QWhNBVBujtSmNrH0KTe8FTLYHeCPr+OJb+FK7eNPPcGSeY828KCdjm5CMk/uYYjsYI5vYEtu4M3sE8s+ITr4kPvkCt0ARm2/S3X+BVlmRqoYwtU0RGlsT1DWGOFbp4rsHDHzne3oOHrZw9JiQH3zUN4XpUJTQGd7F6b9PNLVKdnKPdHEPX2yxfPIt3kdlswWe4I2v4k9v4BUa0p8CYIouY4wsYYouYU4K9MYaboMXp/zElw559bpd8RdugOKbx47ojXXV9pU2cfTHPZqT6CYuYfXewhObx5N8ijO1hC25iDG+wETsCYbEqzBky62X9ZOe4hYeYfVIyP7+++iM76HqnUMmyyFuFuhiH3UVDqoPWqg7bKel0ou4JkhrbZjmqgBN1aEyo9kuLdGjOYdJqNEjq/jjm/iTO/hSezjS+1jS+1hTz7Al97HEdzBGNzGE17DGhEZth0B2j2jxI2LFj3CGFhkyfIBcc5amtizHavycqPVT2xSmuiHA8RovhytsHDpq48gxxyvSrkYY5oeQdOTp113G4rxNILZIsrBDsrhbjvnO0NOy4y3++fKrO7pc7oqF0+9Mb2JLbWCMCqXoU/ThRfSxjTIgTr0HR9eJH9vl1SsOxb+VA6orJsYbauxP21rDP+5RT6Mbu4DVc/NnALhSS2UR7l8GgFAJufIbOFIrmMOPGXfcRDNykbauAq2SJGJRDHFTBHFDCHFtAEldEGl9mLb6MK21QeqPe6g77qWpPkqbpECP5ixm+z380VWC8c2yDNCfEsLMbnlpw5raLy/uCafeLHy4yBr22Aae5DaBzA7R/D6R3C5W32P6xt5FqpqlpjnOwWNODh93lh1fWe+nuiFIbWOI2oYQ1XUBKmv9nBBe64M0SdKotGfQGa/h8D8knNkgnt8mmFrHG1vBGVnCJgAReoozsowrLqjzNsol558BMBF6yrhgkfUyEI6JnwLQVfXUpqj78ypI6ANqj+pHWmrsD9tbw19ouqcYGT2P1XUDb3QeX1IgrpbLt8AshKDYQpkCKCdiQQ+a28AmSLpjC4x57tJnuEp7zyzVTaHyBxSLE3TJcqjlJbTyEr2dRVTSDB1CCVjjp/qwncrD9vJcV9KaoUdzBovjHoHYGqHEBqHUNoHUDi7B+Ykd7Kl9nGXbxZHYLDvfldjEl9oimN4mnN0hkNrE4LpH9+AFmmUFjtYE+DvfM/L6ASOHjtmprPPTJE7QoZwshxuRNE29KFYOU8dqA1Q3RZF0lugePM+o9UY5rwnVTii7RSC9iTe5gTO2ii28jC28gi0iVD3CIdzCLmxdRlcYDz5lLLjAWHit/Gf7mAtH1/Ev7PLKh9auqj/vAwQAmipGtZJa6y2ZKPBFr6rI8PDZcgnmi87jTy7iz6zgEUrP1DKmuFAJLZUBeGWrZXHuqP8BWst15MPnaeoqcKzOR01TiPaOLL2aWXRDZzGOnEc/+BZDPSfp6cjT3hyltsJJ5WEbtZVeRM0JlMpZDKYbeAJCzb1EILqGPy44eQuHIIoVFrezz/Bl9/Cmd3AnBYds4ksK4WodX2KtXJ2MmD+gs+cUda0pDp7w8OtvGHj9oImKKjcNohidyikGRy8yqLuIqvc07copmqVZqptjVDfFaZRky7dHo3sbveserugygYzQcO3gz+zgSW7iiK1jCa9giaxg+ykAjsw2xsgyY/4FRn2PGfEvofPOYxt1/hSAqluWrpo/74QFLqjt+LBcVme82tXi/lGvIsfQwJtYbdfxRx4RTC0RzK3hzwsU7Fp5/0vYdHy17bhU1tKPhR/T57hJ19glWjWz1AqTscYAjZI4CvUUI7pzWEzv4LZdx2W+innsIjrtKbo7crTU+qk55qRW4I7qw8jaCwyPXC4zpXbXfVy+x7hDizhjAn28VXZ8UCDR8vsEsrv40lv4BIYyLjh+CXvwCSb3PbS6t5F0TVLdFOPgcRe/ccDEwWMO6pqjtMtL9A2fx2S/gdlxk1HDe/SNXEKuOV0uWevFGWpbMzTJSnRoztI3cR2DRxjLrpV/ZiC3jy+zWz4Uwgan+acAONPbODPbGEJL6DzzDLseMOB6wqDjPtYRO0758R85FJVXXfI6ufClgj9jQ1VV/WJF/cRZeYv993s6kwxo5zBb3sMfekQoJQhW1wkWtnBn17GmVsrONwqLeILzo08Y8j9AZXoPsTCUkRepbEtQLY4ilufoHTyNwXQFt/sGIf8dQkJuEYY14xcZ1MzQ3hqjscZHnaBqqAnQKkrSozmNbvRKeVZgtt7C6n6ALSh8Jc0avvQ2wezuq5OY2sQrVBjRJRzBBSzeh+gddxgxXUfRe4YmSZbjtSEOHHPy3cNWjtf4aW3Poe57kzHTNVyBB3hCj7F57qO3fsjA2DvINW8i6pikpjVDrTiHqOsk8v7LDJlvlcONcOv8OeEG7uNK7mCJrGEKr2KLb74CIL2FPvCUYedDBmx30doeorXcxjhoEQD4fYei6qxDVffnbGh5HtCsqdU0jeWULeYfqKShr7XqGYzGd/EFH5QBCOc2CBW28WQ3XgGQfLXrK2yTjITmy/tYsrHL1HfPcKw9zQlBJKXIIe+fY1gvcDvv4w/cIRp5QDx0j7DvFm77NQyj51ArCrS1CLSFj9oqLw11IWSyPGr1Kfr7zjGiu8KY8QMMznuYgws4haojvoonvlIONfbAE8yeB2XHj1o+YHD8XXoGzyPpnKS6McaRSh8HKpxlGqKuOYZcPcvw+BUsrtv4owtlXkeg2F2BJxgcdxgYf5eOnjepk+SpFmWpayvRqjpDt+4aeu8CjoTQ8e7hEQAQCoPIOqbw2isAUtvlvDThe8KA9R69pluoDXdQT7zPeJ/ha5fi2A8cqqqcQ/lvzAOEyYyxS31oWDTsUbfoP1dJfF9plCUM+iv4/PcIJZaICFsihW28fwZAYhmDEPejTxkKPKLHeZPW4fOc6CpwWBKnujOLYuQMg+Yrr7ZpfLfwhe4SDt8nFn1ALPKAsP8Obtt7jA+dobsrj6gxSE2lm6oTLhrqheSdorNDIOdOoR28wJAwSLHfweh+UD7pZmE86LpTTpJDhmv0jV5BPXgeheY0UsVUmXA7UuktVz8CABVVXsQdBfp1lzDaP8QZeIRfSK6pdWLZbcLpTTxC7e55QO/ouzR3zlDdmqeqNU+dbAap9iJD9gfl0+5I7OAUSuPkHubYJuboRhkAYaPfHltnzD1Pn+D88esoRm8gH36X0V79V27Fsc+dimqPQ/1vTMSE2aRfmAm39Y9oRSPr3WLnP+/uyDKuu4jbfbtMQIUza2VVsiezjiUhJOIl9LFFRqMLDAYe0m2/QfPAWSo6shxsjVGjyKMxvc24+wPMAhcevIM3dJdA6C6R6H3i8YfEIvcJeD/EYrhEv2aaNlGU2io3J47ZqTrhpqEuiKglQXt7Hrlyhu6+t9DqrjA4cZVhw3sMGa7SP/42PUPnUWrP0KmeKzteLGxKSlIcrw2UT/2BCjuHjruorAvSoZph1HQNu/c+nrAwn3hKKLlOoryAsUswvYkjvMiQ6QatilNUi4ucEOWpbJtEpD6H1nKXiYDQ4W6Vv0TElhAA2MYc3cQW2yhXZLbyXOEemrH3UQy+w//b3pfGyHVdZ9KTAIPAY/9wfsSAJcTWTrL32l/t+77v9V7t+17V1Subq0g2KS4im/vSbPZe3VW9sJukFSmCx/4V/0lgG4iAGImhBDCCDOAYSiTFS6RvcG+TgsYzxsSOPbaTucBF43V3Ec1z3j3Ld75zrs5zExrnZQSs3P8omvseF819wYzpUzVhUp2fYU2fTxkcar/CM2eVp/7GqBpF0HsB2cw9lOtrqI89QG3yEfJjO3SgRay1SXHu8PAGfLX2ngI853FQO4UXZSMYMh2FI3UDbPk+krUF5BtLKDWWUK4vot7cU8Lw8ApqlXlkyPgBzxloVeMQCyoYIpBAfwH8oTLEwiZkBL9RTUKlPwat+SSFuk3OszA6zkBnOQmV4Rhk2sNgVJOQKMYp3EBgh56hMl4mwu/N4eBgGXymRU9HLHMfhVqHCr/Q2ERl5CFaU29i+PBbqFIFPIA/OQ+5+RyGlMfRJz+KftWrYGyX4EguI1LdQWL4DaRG3qLJ4FMFpJuPqfBT5U34Y/OweK9DZ78EleUSFIazcBvYvymYeueKloPqqukFQlX/XzmiSZPpQFjlnLbJYt8yyOvwO6eRStxCsbyEamuDFuKzo6STsQuOJFzNLsLDXfg/pYADmik8L21h0HgEtuQNhEv3kagtItdcQrG5p4BaYwmN4RU0mkuolOeQTl1HwHsWes0kpOIaPQW8gQL4gyUI+VWIhITbswcfi+WjkKkmIddM0didxPICZhg8SZNmsE/3kKiBnsESXunN40B/gZ4GkXwCNs/rSOaXUSKCb20j39hEubWL5iSpbRPciQhxG97EPGTmcxhUHkev/Bj6VSfB2C/DkVyhCiDwR7L15hPhP1FA4xEylW0ksgSOvwOj7RLUhrOQac+CUZ6AQxv+VsHSO111HDjwc5lxnMpWs0sjXzdICx/77MeRiF5FvjCPcmMdpdEtZEj9tb4Gtk46CTsIN/cUYMvdpyaIKOA56TB6dVMwcjPw5cgIgwVkiQKGl1FuLKHaWKJKqNTmkS/cQTxxBX7vWRh1hyBnGvQUiPhluoUkOiLOmWSvQyX088rgCWs0weOJ6hgQVNA7VKSb/IwkWE8zXAI7ELtPIh8eoTiqD8Ppv4J0cRXl4W1URnYorFAi8T0JY8cfI0cwnEoXTm4OEuNr6FccRw8pm6pPQeaYgSu1Cra2SxWQaP3JJztJTkT9IdLFDcQTi3C7r0JvOAuF6gQksuMQiCc/tihDXy9Zemq1n8eMI9zQjNEScMuCHaMk9YHHfIhGKZnsLArVZdoemqy3wZaXEKmuIlJfR7jRgb++Rp2w1HcR+zVT+IqkiZcJN8g9DVv8KjVD+dYqZaE1xjuoj7YpJbFQnkUqfR3hyAW4CQ1cPwUNIXXJhqGUtaCQDoMR1akSBgeKOHgwjZf3J3GgN0vh457e7B6W05Oiz/1DJQwJ6xBJW5CqJqgp4ktaEEpHwSgmoTacgCd8A7lqB7WxhxRGrow+pIlbZewxCq1dJKubCOUIK+IWeOqTOMgcwUHZMQxqpqFwX4cv10GsSdDOPcHHyR55c88kEd+QW0eMm4PD/jo06lchZQ5BwB/H4EDjAwMT7FTtPYHmz+OGUna0xaLwyryXzEzsXZdh+CcR/1kkkjeQLc4jX19FqraCaGUJ0VobXKODSLODQH0NzsICFKEZ9BmP40X5KF6UtdCvm4TSMw03iYTKc9QMFZpLyNbmkMzfBJu4jEDwNTicJ2AyTUFDJqHIhqGQNj9RgFTchFhQo/6gry+LAwfT6OvPY2CwSHf/QAG9A+S5hEF+heI6YtkIVQBBPYXSEYhkY5AoJqHQHofNdxlcdhGZagf55jay9U2kaxuIlzuI5Fbgjd+HNXwbCvvrGCBvv5TY/5MQmS9CH5pFqLxNhU8gEQoGjjxRQOMxEqVNxJOLiPivw2achlp+CIygBX5f7ScDPYV3tQLvpZZjv2LU8Yef+7n9AU274YWAzFm1S4PfcGrLP/A5j4NlX0cyexe52hKyzTYyzTWkWhtIkOlSrQ2EGutwlZagj98E4z2PftMxvKQYwXOiCnpUI5DbT8AcOg8Xdwlu9iIcwTMwu8gkqimodGNQqIYhldYhEpbAHyqAN5AHf7AAIa8MRtSAVDIMGTMMiaQBiYQMThqDWnMIGu0U/apQjYORjUDEDEPwKV9Aoh5ihvr5NfQLGxRekOmOw+A8D3vgClyRm3Czt2EP3YDRMwO14yKkltdoyDmkOkHNz5D6JCTm89D5b8GZWkWU2PmxP0V24m2kSQg69hYSI3+CWG0XXGYVoeBNeKxnYVZNQiOpQ8YrQdiX+QHvQOIb2kFndcL+/Asz1X3/5/4A0rnR4vSfDautFo/COe9Qp//WZRlHwD+NaOIaHaaab7YpQzo7jc4dmQAAGJdJREFUtoX02DYSo1v0FHjKy7Bm70HHXYPE8xoOaCbxpYEsviIoYUA9CsZ8BCr7caisRyA3TECsakIgJba5BIG4BB6/gIGBDPp60ug9kETP/hQG+3KQiprQEKq67jCMhiMwm4/D4ZyG2/MaPN5zcHvOweEkc6SPQ6U5BEYxCr64SbmgBwdLtAxJ92AFB/kNDDJjEKnJ33ASKgsZ9HEeCvNZiLSvYlB5DL2ywzggnsRByRQGlK9CbDwHjecaHPEFhEpb1NnmKBC4N0ot9UQB0fI2QrF5eBwXYdNMwchUoBVmoOYlIOuL/K1of2Be3eO0nOf+6Od3yDxdnF7fE9ZYjtpU7Ldt+grczsMIRc4jkb+NHOF6jnZpozSBp1OEGEUioeoq3KVF2DKz0LJXMGQ+jmeHCvgyv4iD8iZ4GkJXnIBQMwKevIEBcRn9ggIG+HnwRCXwBEX09WfQczCFg/sT2P9SHP09WSiYEVgMx+BxnkHQfwGRyGVEY9cQT9xAPHGTbi56Hf7A67A5pqE1EFbDGAYENaqAV/qLdO8f2FNAn6iFQdkEBMrDEGmOQ6I/SSkqA/LD6GEOYb94Eq+IJtAjPQKB7gyUjhmYI7PwZ9cQre8iM/omTcAIGkuSsPTom0i03gBb3IA/fAcO0ymYmDoMwiQM/DD0PD/U/a5vK3psR5Wv/F96xJ6uqlv5TMZkYu0K37ZBEfuhxdj8V4/3VUQSM0iW7tEhfFl6CjbpKSA5Qbi+jkB1FZ7iIqzJO1D4zlNIolc9hiH9JESGQxDrJyHQjIKvbEGoGIZI0YRU2YJKOw6FahRCURWDQwWaiPUcSEMwVIFRdxQB7wWk4rdQKc2jXl9BpbqIEikWlRdQriyhVF5CLj+PRPI2AqHLMNlOQ6qcoNByD69Goeg+4TCGZBMQqgjT7QSkhlOQGafBmKbBGKchNuxtkfEsxMazkFouQO26AmPgNhyxBQRz64hWHyDd+ipyY28iP/4WzYYzIyQC+irYfAde/3VYtYeh52dg4gdg5tv+1cQz/tDI028b+g2sqfff2CU5Q/qE3SaBXW4/pZcF/sKgKXxgd0zCFz6LSPo6EiR7bawi0+ogM7pJ6wDRZgeR+hqCRAm5eVjiN6HyX4DCfRZKzxna7KawHQdjnILUcAgq8xForUdhsr8Kh/sMrPaTUJExM8ww+PwqBgdKYETDsFtPI8ZeR6W4iInxLRw58hCjox3UG6uo1VfRGF7HcKuLJmkaqbWRzs7BE7gEtfE4RPJxDIpbGGRGIVROQWE6Ba3jPPSuSzB4LkPnugSV4yLUzkvQea7C6L8BU+g2LOE7sLGzsHNzcBKzklpGKLcOrryFVPMhzXZzI28g2/oqUs1HiNd2EU6vwOW+CLNyBPohDnahHS6x5gOXSP4XTrH8lI2vELBC0+d/oU55m9wQNMqdXa0y9p7F0oTDexz+6OuI5m4jUZlHurFClZBqdREb7oBrrCFcXUWgtEyV4EzfhSNxa48hzF6BOXgBOvdp6N2nYPaehd1/Dp7QRVr+9IVeh4k0M2imwEhHwRfUwYhHYDWdRiR4FfnsfYyObODQ1A4azTbKlcW9BLHWRmO4i8bwBsrVNoWXCZlKrjsKoWICAsUkJJqj1N5bA9fgYm9TaNnJ3YEtfAsG3zWYg7fgiM7Bk1yEP7OCYK6NQHYV/vQKAk+eI4UOopVNpJukC+YRss1HSNV3KDgXzK1RZ26znYRJUYFZEEJAbkFQIX8vrJB2I3Im6D/wS4zEdysUArvCdFKvCPylXpP+yGQbhyt4BuHkFUQLdynGQ8xRigxFGu4g1lgDW11FuLKKUGUVkdoq2MoKIiVyhO/Bl7oJB3sZjsgleLgrCMSuIZK8SUnAXPIm3L6LMFpPQ6U5AjEzAoYh02tPwut+HYnYHdTraxglAzqqy8gX7iObn0exsoJaYx2V+jpypWWwibuwOM9DrJqimL5ES4R/Blb/VYTSi2BzKzTcDGaW4Ench529C1fsPhU4W+ogVt1EoraNWHULbLGDSHEdbHEd0VIX8comrYBlm7tI1x4gXuoilFmGk5ulPQpG/TiM0hQsQhf8cvVHUa3kL+M68cmEVvKLz4ogq2iQPxtS6n0WuWPFoIx8T6uvfmRzH4WfPU+n4cZL95CqLVFzlGysIVZrUwWwlTai9Q5So4Sat4l0q4tUo41YZQkh0lCdvoNw5i647CwS+fvIlZeQys8jxN2Ey3sJRss07XJhpBO0SG8xn4XffwX5wiIaZBp6aRHp3Bzd+dIiytVV5EpLiKbv0UK62nwavCeOVmE6DZP3MvyJ+0jXSQ13mxK2uNI6gtlVeFNLVPhceQPJxgNkWg+RbT1CurlLBR6rbNCdqGwgVdtEbngH2cYDJMsbYLPL8LB3YHBfpniUWlaAXuSHma//KKiQfi+pF64k9Txfwsl/9peeCR3V6fZ7VMYxo9L/tkqd+dBoHYUrcArBxGVw+dtIlOeRrC4hQRO0FbDlZbDlFURr60i3CHb+APnxB7SzMjeygWRtFXFy6UJpAfHiApKlJeRqbWQrq4iTaYfsLTg9l6DRvQqp7BAYhrQjkfDzDGLxOyjXVlEoLyFbXEC2uIh8ZRn5ygqiqVm4Q1doCZLY+x7hMMXztY6LcHG3aTWrPPEGiqOPkapvIUoESN/wDhV+vLaNZGMH6eFdpJo7SNa3ESffL3ep8NO1LYqSEqpLtrGNeKGNQPweLN7LYPQnwZc0IB4MQjOoh4Un+TCk4L+dNvLG0pbB/Z+UHn+Z5ReL/4AzaE0WlfOqUsG+qzWUfmp1H4aHJbMUriGau4t4aR6x8iKdGcqVlsCWlsGVV5GorSNDEMfxHVQOPUR5chf5EfIWriFZWUa8tIREeRnZ2jpytQ4ypTZiqQUEwrdgsp6DTHkUfCHxB6OQKw7DF5hBtjBPhU9OTZZ8tryMZH4B7vBVaK3TEKsPo1c4jP28BsSaEzD7ryGYXkSG1JYPv03rx4nangKI4GO1bSTqDz61ifnZRKzcRay4TscPJCsbyDWI8HdQIgqobYDLLNL6g8Y6jUHpOHr7k+DtN0HVI/qpjdf3bkjRdzVnEJia4md++YlZVAH+fb9XdBqedWtMIaPC1dWoE9/XW1p0IrqbPY9Q8jq43CzixXkq0HhpBdHSKrjiCtjCMuKVNjLDmyiOkVPwAPnWJmVQE8HHnvx+tt6hsHCOcG0KbbDxedg9V6DWn4ZQfAhDgjGImEkYrdMIRK6CTdxGLD2LaHoObGoWHvYGFT558/vEIzgoGEafeAwK01k42btg821kh3dRmiRh4yPqONlSF9EKmdC1g2Rjl56AWGWT2nquuA6usIZYsY0E6aSpdpFrkP64LeTrG0gWVhAkVHb3BSh0UxgSVsAbCEHep4ZxiP/9ANPf5ZR9oaKB/yyR369saqJLbRzVKoNfU6ozH+otI7B6yXT01xFJ3UI8P0fNSZK8+ZU1RIsrCKXnweYXkaiuIdPsIju8gUyji2SljVhxGdECUcAqLaIXmgQaJhNPNhDLrMATvA2D5SIY+QnwRVPgSyYhVx+FyTYNV+Ay/JHr8EWuwxm4QsuHQuVh9Ahb2M9volc0BoHqGPSuGfgSC4iVukg3dpEZIf1fO4gUuwgXnyrgIVUAiXC4Uhdsfg2RXBtcfvWJAtaQrq4jV99Ajvi10grY5CzcgcswmE9ApiBYVQrMkBO6IemHTgnva3Ht0GhB39dzTLnv939ld5SVXYI/jBk0aoPcdlrOBL+pUOfeJ9OsCJGX1HxjmbtIFReRrraRqa4jXlhFMDmHcHoeUXISym2qCPI1Rk5IfpnueKlNAbHC8A7yTXK8HyCeX4efnYfFdR1K/WsQESUwhyFgxsEoD0FnnYbFfYFurfkMxKqj6BG08NJgDa/wmrSOq7Scgz18G6HsKhV0vLZDE6lIaRPBfAehQpfG9Yn6QyRqO+BKG4gU1hHJr9Ioicuv0L8tVW4jTci4VcIHXQGXvkepLBbHaajUY5BK8lCJw9AKze87JZJvhpSDp4sGoZrIa9+venJuySL4ol2udeoY+4xMGv6OXFX4F4P1MDyBi5TImi4sIl9bQ6G5SdFGUiRns4u0d+ypwFnyvfzec7RA3rAOco0HyA/vIlffQbqyjWi2gwC3CLvvLoyOq1AaCLvhJAaEo+jlNyBSTkGmP06BNYH80J7wB2p4cbCOXsk4ZKYzsIXvIJBZBlvcE3S4uAFftg1/bg3BQoc+k+/HqzuIVbb33n4Schba4ArtPeFX1pCutKngE4VFau68oSuwOk5Do52AXFqBXBSFUWL/F4dM852wUjyT0PKcIxbBF39t15xwevlXvEpdWCG0zUvF7DtKdePHNsIlZa8imb2PQpWwmrdoJyVRQqLYRjS/QovpofQCgql5hDOLT96wdaSqm8g1d5FrPKTCj+c3EEmtwcctwRW6D0fgHsyum1AZL2BANI6X+8voE41QWGFQOkHt/Yv9VSr8A6IxCLWvwhS4QaObWHUb0co2IkXCUFiFNXqf1nRDxS4ixA9UtsCViOkhYWkXXKmDaKmDRKWzx/usEgLuKuK5BUphIU0nZttpqMkoBoYMAklAJfL82KPUv8NpZPNJnTCc0Qt/PbOjny7SWBbRyp4zMrqMWuxekjOJv9JqRn7kdJ9FmLuBZGYeuXIbhVqXOtV0uUPNEYmZw6lFhFILiGSW6NsfLxF/sI0MefNJma+wCS7TQSi5Bl+UxNiL8ESW4Azeh8l1HYzmJIak4xA9wXPE2uPgKabQx0xgUHmEYjlazwyN7QlXJ004mbUdhAsbcKdWYGbn4EwuI0TMTWULEXoyutQnUKdc6iJGFbCOZHmNkru4zH0ECWkrcAlm2ylqduRMEQohB7XA+SOL2PBXQZViKa0TZ4pa/nOfNN79uldAL+mxykw5hcDVVkoz39Xpxn9sd55BIHwN0cQ9pPIryBI6HvkPkWOdXQGbXgabWQaXXUWsQEI8EmdvI1neRqK4BTbbRTi9ThUQiLfhj63CH1uDN7oKZ2gOBudlqC1noLMTPOcidM4LUNnOQW45S/Ec8ua7EvPgKlvIj7+JzMgbiNZ2ESps0FKimZunmH6oRC5n2KYKIL4g/DMKIM43ml9GJDUHP3sDDtLnYH0Vag2x+QXIBBGo+LYfm4Xq73qlTJtTi3IFJf//zf0Bn/YJHoXuRTNjzarF4SWpJPeOWjXyI5vtDLy+GUSid5HMkhi9jTgROHGGuTZi5JkIv9ilCogWNxAtbIDNEeF3EE6tI5TuIJQiu4tQisxd6FJluCOzcISuwxW+CVfkNpykmBK5TTEdAicQHIcIMtV6hPzknyL9RAHBIhk9sAZbnDR0ryFc2kKk8gDh8jaChS5CxQ79HEeSsnybdk6GknPwEJ6R5wJt1lCqRyFjipALo1Dy7D8yCtTvuKWSpahOkE3oBl78d48o/mUWCbMCSn2PTuzMyPjheZko9x2lbPh9ne4E7C4SKt5BJD4PLrWMGCE0FbuUskF2nDjBfAfh7DqC6TYCqTWE0l1Esptg89uIFnYQLewikttBKLOFYHId/vgCfPFZBBNzCCbnaYIVyi4jmF1BuLAOlii0uoU4ieubj8HVd/eEXNqCL78BT45wNYnwCXF2B+HKA4SKGwgTH0Az43WEMysUtnCGb8DoPE85pHLVCBW+TMBBJXC+bxTqvuOUSObDSkGmYO3rOXZs32/2greIzPqcS2kPy3m+GVF/7M8EvNqHcuVxGCyvweG7jgA3h2hmleInJNLJkMgjv4FwZg2+xApc0SV4YisIZzcQLZHC+BvINN9Cuv4WosVHVAH+xBp8VAH3EErNI5JdRrS4RhkMiRrBbLbAljYRLnQRyHXgzazBk12HL9+lCghXd8DWCU38Ebj6Q7C1HXoKiBmizri8gXCuDS9JAkM3oHech0x7jLYrCYVZyIRU+B86GO2fBdXSGVYtDCdlvb/ZW5Q+jRlxev1XtDyjU97vOi0eDH9NIk5/X6Wu/tRonqJ4P6GAk87JdG4J6fwq4ullcIlFhKILNOYPxZYQzxKS7A7y1ccoNL6KbO0x4oVtRNLrCMSX4Y3dhyc2i0CCXL5Gwtm1JyjlFmKlLXCFTYRzXQTS6/Am2vCl1hDMdhEpbCJafoBEhQBsO4iVt8CRZCzXRjCzCH9yDt7YHXpDq813AUbHSWiME5Apy5AyMUiFnp9qhNbvmyX6rwXk0tNRrdBJop1jB/b9dtwj9nSRPMGvlmj0QmZUJTZ2lTL/uxpF7AO9pvCxxdiCx3kCXOgi4tx1xNmbiEfuIhaZRTQ8i0R0Abl0G6XCBkrlbRTLW8gVu0gS35FcpPVWLzcLF3cX3tgc/ER56VVEsuvgcsScbYLLbSKS2UA41UU4sY5IsgM21UU0vYF4dgNJuju0/YlLLiAYJZT0GdjIRRD2E9CbD0FnaEGnr0KtTkEh9X6sZswf6KWad51yeTesFo9y8iFNXCn47bpJ7+ki13akDeIvuCX8HqtMFtLLdVc0YuPbKpHje2qR/2OLKg+/ZQys81VE3a8h4b2MpO86kr4byIRmUYovoZJuo5Jto5hdQS69gExyDonELNjYLFWAk7sHd/Q+vOTkxJcRSrQRTu0JmkttgkttgUtuIZrYQCy+gVisg3h8DYnYKhLRZaroODeLSOAavK5zsFqOQatpQi7NQcrEoZCy0CpD0EjtH2sl6u+ZGfnbLoX0SkApCnF6fk/acOALvxGH+4us/35s3+8nDPxn7cpBk14oHtMMSVeVA9p3NHzXe1ZF8kO3uv5RQD+FkPEUIqZziJjPI2afQTZwG3n2HgqxOeRi95CJ3UUmdhupOGHPzSKUnIcvvYxAagWhFBH8GhU8m95ANEX2FmKpLUSJAuIbiHLr4CKrYEOEqzOHkOcOQp4bCLpm4LWehd1wFAb1MJRMCpIhL8QDlo9kPMOHarHuPYNE+Y5VLFj1yHhjnFZgIsDaJ3Ty34H1Gf++fb8nFov/IKgQ7ffI5V6zUHFSzzNu6EW+P9cLE/9oElVhFo3BJJqEUTwFm/w4fMZziDgvg/NdRyx4A/HwDSS5m0jG7yKVmadtoaRoQkqB6eou0pVdpMu7SJV2kSrsIJHdpgrg4l2E2TUEAkvweu7B5bgFu/kqLDoyIOQ1mDQnYVAfhl4xAq28DJWIhXzQDMWg8h/1AubP7VLxhlfBPxmQD3qDCoLni//Av8//u3Of8P92CYST/6xbIhGY+aqgUWg9peN5t9UDkW+r+5N/p+zL/kDRm/+JZqgOs3QKTu2r8JjOwmt7DX7HeQQ9FxAOXEaEvUGbrtkSgYpJvN4Bl+3QzJlNdRCJryHErcIfXoI3MA+XZxZ2+w2YzZdh1J2HXnUaWulRaKUT0Emb0DFF6JjkT3RM5Acaof3v1EPKb+t5om2rkH/KL+8LstqDgoTh4LMkwNj3H2X5lcr/FlAoBA6xijUM6Y5q+i3zyh7XN6SvBN6VHYx+oBosfKwTNWCQjsGomIBJdQgW3RSspmOw2qZp9ckSuglr8CasgVuw+W/D5rsDm/cOrK5bsDhuwGS7BqN5BgbDRWg1Z6BSnICSmYJCRDryK1AJMtAI2Y/1It8HJrHjXavU+A0Ho5x3iIVHfcwQG5DwBX7lgf84d8r/7KqahJ93K4XP6PmSHtOA2qLtMVRlL9suyV7xdeS93Nfl/ZlvKQaLfy3jlf9Byq98IBPVPpZLyTSTw5DqT1OaIGO6AMZ0EVLj65AZL0NumIFcNwOF9hIU6otQKMkgqDOQMscgEY59LBmsf8AM5v9BNpD8ayUv9C2D0PF1q8TccTHaS26ZsupRiCwBCb+HVfY+wwqF/3bqyO/6aun7PusfFL+g369WKF6yBCT73TXJwfA00xudE/dGHwl7498U9ie/KxpM/71QkP8hj6m9NyRvvceTt/6JLxv5Z4F87H2hfOJ9kWzyfbF08p8l0sl/YiQT70nFY+8xwtYPJfza30t4xe9KBtLfZPqij6QDwTkNzzFtk6hqfoU0EFMLFGnl4Ast/R99dt9/xoV9+z5TfeGF/+p4mfmc4YDhC8oD/i9qBhwHLIxF7ZIaA06ZvuSUao+45doLHqXhlkdjWvDqTGt+rXHLrzPu+rXGx36d8at+rflxUGveDagtWwGNZS2osiz4ldZbXqXlgltpPuKTmUpeqTFgYQxqk9B0wK9UftFvEH8hxbz8OdKt/sn8zv+/9tYxdt/nD/mf+dKw549faZif5bcsX1bUrc8b6+aXXA3L84Ga6SWubnkxUTW9kKqYXiBTR1IVy3OJmukFrmp/PlA3P+8atj5vbDm+rBh1PMef9PzxK6f8z3zpGPuF/zzm5d+zsG/fZ44d2/dfSEGbxN6koZlsQu8gUQnZ5M392f30Z+T3nn6GfJ4kTuTf+2180/8nvqsrzFeSYXYAAAAASUVORK5CYII=",
	k: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nO19d2zb97WvmsRTy7Ktyb03Ke4hkdQmRW3JpCRrWpYlay9rWYPW9JIty07a3IFcp7lt85y+5CFoCjwgSJO/mj9uiyR4DdCgDdwCQdACaeDGdjMan4dzyB9NyUtK7CS9vT/ggBrkb5zP93v2OYyJ+Z/jf46NB0DM94LB4GN+v//xoNv9hNFo3IakVCq3K5Ux22NiiHbcheh/+B7mM263+wk6TzD4GJ73jov9z3Hn8fNgQ8LloRLWUkuRfLDcYQrYNS6niu9R8FIqM/bHBuJ3xjZu27at9bHHHmt7LCbm8GMxMfjaunPbtsak2NgAOyWxUstP9zg1fFeNQ20arrbLzzX7Wc8F+xLucrl/3gMAvrfW590x2uaIH/IX7W3xudNGyi3KvnJHbrfPFmgtNHTXZKlnCvXSFatc8LRSkPEsj5X8fOr+fS8mJSW9nJiY+EpiQsLPExMS8PXlfUlJL7JSkp8XslOf1QjYT1sU/JXCTPHMgWxNd3OBLdDhc+R2lluULT5z2pDftne0rTwer/9PuzN+ONIYG2wsEo8Hcl19ZVmBDo+1/1CRcbk2R/tMhUP1M49J9qZbK37PqhZ9aJALP9ZI+NfkIv41sYD3V4GA94mAx78u4PNCxON9IuTz/yoR8K8pRIJrGongY71M8KFNJXjPnSl9s9is/Fl1luaZhjz98mGPub+vMiswXp3rCja6xT9sLIyN+WcSL//aV8U+21aiHq12+dq95r76HO1qhV11pdgoez3fIH3LpZP8zqGR/Mmiltwwq6W3LDolWPUasBp0YDXpwWY2gtViApvFAnZriPBnq9kMVpMRrEYDvdeiU4FJLb9lUctu2DSyP2Vppb9z6aRv5Rmkrxeb5FcqrerVBre2r9Nr9U0G3Oq1di8b7y/mv+sR9Lvjllu95hONRQ2j/pzZjmLr5VqX9g2vWXbVqRHdMMv5tzJlAtDKRaBVySBTpwGz0QjZDjvk5bjAU5gPJcVeqCgrgaqKMqipqoADVZVE+DP+rbzUBz6vB4oK8iHX5YIsmw0sRiMYdFrQquR0bp2Uf8siF9xwacRXSyzKN+rd+sudPtvs6AFnw1xDvhnvM+a/y/H/rgS3PzNcwcEHGyh11DYXmharHKqXCo2yt1068R8dGtFHVrX4c5tOAVkmLbgdZijKc0F5iRcC/mpobW6EI+1t0NV5BHp7jsJAXw8MD/bByFA/HBsagNHhQSL8eWRoAIb6e6G/rxt6u49CV8cROHLoEDQ3NEDgQDWUlXihMNcFLqsJHAYNWDWyz61qyUdWpfiPdqXw7fxM8UsVNvliU462tr/Ubl5preDg/cf8Ax7f8/tjHh/y23ZN17oU4wFnTVeJbaEpz/DTMrvqVy6d+C8mpRAMSjEYNHKwGjPBnW0Hn7cAAjUVcLilEQZ6j8LxiWOwvHACTp9chDOnluAs0ullOHfm5D3oFKycXqb34HvPnFyCU4vzsDA7DZNjI9DXcxRamxrgQEUZeAtzwZVlBYteB5lKOWikQjDIBH9x6cS/KrMpflqfk7lwtMha01XpUgz5/bvweSDmH0RZ/yLofmKhtogz4Xd7O4stYwdz9D8utSnfzTPIr2VppDetWvmXdqMOcrLt4C0qgANV5dB4sBaOHG6F/t4uGB8dhhOzU3B6eQHWzp+FSxfOfWXCz58/exJOLs1BcOY4jB0bgr7uTmg/1AwH6/xQWVYKRQV54HTYwJyp/tKolNy0qYTXnFrRu8Vm2Y/rXLqx7iqbd6rVyYFfBJ+I+S4fV65cefzckH9vMFCo7imx1zUXGC6WWZWv5ugk79vVklt2rRzsmWrIcVih1FsI9bV+6Gg/DCODA3B8YpQYtDgfhFPLC7By5iRcOHcGnlw7D09dXKXXr0oXL6zA6rnTtDNOLs/D4twsBKcnYWJsBAZ6e6C97RDU1frBW5gPWVYT2PRqMCrFt8xK4fsurfjVEqviYn2evm4k4Fbj88GVK4/HfBePJ7v9aQuNxXkj1e7RpgLDCx6T9KpJxrsh5bFvKSQiMOq0kON0ktLs6miH4+OjcGppAS6unoPvX7oAT126EHoNM/zi6gqt4K9Nq2dh7cJZuLR2Dp68eJ6ugYTXWF05DcsLczA1MQYd7W1QWVkOOW4n6DO1IBWLbsmEnBtGCedqsUn+QpvHMjpel5v3ZLcvLea7dFwJ+refbS8THKtxVrQUGZfK7MrXcjMlH1iUoi9MJOP1UJDjhprKCmhrbYHhgT4ITh+H08uLxKDvX1qDp5+6CD94cg1+gMy5uEriIxoA/JkRK8hEBOlehIxd93kEYDUkyp66tErXYa6H78WddubkIsxMTUB/fw+0tjZBdXUFFOTn0b3rZMIvjFL+B1lqwWtes3zpYE5mxVRjoeBK8DuioE8eyhdO1bnr24qMayU2xS/tKuFNg0IEmWo5KdeaynLobD8EE8eGYWk+SIry/NlT9OBIyKiNtHEVbwTgfiDcAcCG82y8DnMf51dOwemTCzB3Ypr0UM/RI1BZVgJWkwHUMhEoBBk3jVLuL4uM0rVOn71+sDpf+K0yHgNlS42F6sEqZ/uhAtNlj0n6jk0lvG7WyMBhNkBRfi7UBw6QSTg9OQanluYjcp1h5sVNiJkL58+QqEBLB1fq8uIJ0hVoISEtRSgIy4tzdB20ggjk82cidK/zR8BdO0f64vy506SHTsxMQs/RDqiuLAd3tgP0agUohLzregnnnQKj9HLArWlHBy7o/haUM8CVx6frXZKhmuwjTfmG50otynetSsGneoUYsq0mKCv2QltrM9nn88EZOHNq8Q6lemkTAOB7LqycgTPLi6Q8pyZGyQ9Aa2mwr5toIIrwf+PHhmF2agJOLc9vCQBmZyEQKLLOnVmGudlpGOzvhYN1ASjIy4FMjQpUIu6nBhnn3XyD6Lk6t+ZIa4FVggbINwrAv/cH1DMHczsOe4w/8Zpl7xllvM+UIh5katRQ7ismJTsfnKZVuHG1b2bVX2SYsnYezp85BfOz0zA2MghdHYfJekKx5q+pJDpQjVQB/poqqAv44VBLEwF0YvY4iZXV86fvC8A6Zb26/tqMokYrDc9bkJ8DWrUChNyMz1T8jPey1IKf1OYaOiYDhepvhPHwLx3bzneVCI/X57UfKbY8V2ZT/tahEX2aqRCDzWyAEp8XOo8cphWIpl+0xbEVq+bi6gp9Bj+LlhIq7pbGg1Dq81DsR5+pA7PJABazAcwmY/hnI9isFsjPywH/gSoY6u+Bk4snYOXMMgFwL/1yV/BXz9FO/cFTa6Ss0RGcGD8GbYeaoKgwH3S0E3if6sSc37o0oudKbfL2rpJs4X91dGx7pAD8sNcvWG4uqO8otlyuyFK/69CIPjOqpKSocBUODfTQyjt7egnWLoRW0pbNydWzJIsRAHz4ueA0tDY3kMOk1aghIz0N9u3bC2lpqZCengYZ6en0Sj9npINUKobsLDsBdjfds5VFgPcR8iPOkEeODmLnkTbwegrAYtCBSsj7TMnPeNciZV9uLjDWT/mdgkfC+Ct+/+No/55s9VQcq85aK7cr33FqJX+zauWQZTXTyu8+2gGL87O04sjsW7s/8y+GVyQDUoQQuLXwCnxyjXZTrb8a7DYL8HlciI+Lgx07dkBcXBzEx8dDQnwCvcbF4+9xBBDa8YGaKhgdGSRFjdeL9i8iivc+ltc6sRTxqk8RqCiOiosKwZypBbmA/TclL/2dIqN8rTZHU3HMb05Dfj1UAJab8vctNeflDlVnLbUUGN90akTXTUoJZFuNUFbqgyPth2BmahJWV05FGPig1X8xyrSMttnp86v495DCPj5+DCrLS0nsIHN37toJTzzxBOzauQt279oNu3fF0iv+vnPnLkjevx/UKgVFTVExL5yYITnOALDx2g/cpWEfgtELaGGhE3mouQk8BXmgU8lBxmdfN8t4b+brxUvNRcbcnnzzvofDeYDv/eIXwSeCjW71aLVztCE38zWPUX5TJ+XRhUu8HujsaCcxcY4U7u1VfC+TklGIl8IPdDtmc5podQXNTrTN8eFXKH5TVlIMOo0a0tNSIC4uFnbs2AlxsXEQHxcfIfw9dnccpCSngEoph1KfF3q6OuDE9CT5HiEmr9C5CQQyPc/Dk5sA4eIGwwBF2vTEGLQ0NoArywEqqRik3PSbmWLOax6TbLTRbVJj7Aizfl+L/7iVnpmq4IwFsusOe8wv+CyKD7I0EtCr5RSnb2o4CMcnxtbJ2Ptt6YhZeO4MrSR0zJi4DIaTRwZDYWYm1IzMb2luALczG+RSCaQkJ0NCfDzs3h1LTEfxE6G4BIiLjYfk/ckgFonAlZ1FogtlNoap8VyjI0N07rGRYZgMx5/Qh4j4Defuby3hc6FhgJ40+iR4v4Gaasi22UAu4oNSwPrApuC9UGKS1w1XODlYEPD1ABjy73qyu8w7WOW4VOPUXM3WiL5AiyfPlQX1AT9ZJxhLiY4+3o8YANDGnj4+Bl2d7VBfG6AVXliQBwV5uVCYn0c/Y1IFkzAOuw3kchmw2SzYt3cvMZtZ/esAQF0QFw9Je5JIMctlMrCYTOByZpNlVFRYQOfE8+PPKDrr6wLQdfQI+RcnF04QCA8ylRkRe37lJCzMzVBuInCgBgyZOlCIeF9oRBlXXRr+JX+20uu32XZ9deYH/dvnmwoUMwfzxto9pleLTPKbVrUYDFoVVJeXQn/3UYrpoIf6IAuDHmg1BMC5sydhaX4W+no6KZOFq1uv04JCLgO5VEqvSoWcSKWQ02pmsTIgOTmZmMswGl8TExKJEhISQhSfAHsSE2H/vn3AYrFAJBSCVCoBhQzPqQClXE7nV8jlkKnTEjjVVRXkX8wcH6OdwIjHB1lpF8lZw2cJkgGSl5sDBo0SHbWbJhnv1RwNf6zSqlJc8fu/Wszoqa4KzmSd+0B3mfVHfpfm/Wyd5EuzVgHZdiu0tTRBcGqCYvabMfFINIXDwhibnxw/Bk0NdcR8ZA6bxYLUlBQSMfialpoaIfwbrvw9iUmwJ3HPuhV/BwAJ+LcESNqzB/bt2wcpeE48X9Q5mesgqHKZlExWNKEH+7vh5OIc3S+jrB9kQFwknRJy1DDr5sqyg1Yu+VItZL9vFGX8qMSiPNBV4eR8JQAuHCk1D1dlL1Q5FL/JyRR/aVFJwG7SU84V5ej5cMz+fkE0hggg3LZnT8GJmeOkHH1eD6iUCmIGmpREsbER85IhlPkJEXGTeIfYuSuFwYg+D0N4/p07d0JsbCyk7N8PUomI9BkuKgw9IEOjzdV7g3DbMkI9gmlTzElbDJkg5bO+lLGTf+M1SRdavSbzlpmPiemFpqLanjLbC7k64TWrSgBYnVCQ44TGg/VwYmYKngq76puR/YwJiFsW7WiME+W4XSAQ8Mmu37Z9OzFl565dRLvQrAwTmpn3kvn3IobRyGQyUaMITVU0Y7dt20bnRNNWo1ZBnf8ATE+OR0TqgwEI7QJ8NvwM7oLmxoOQ63aCQiIAISvlWo5W+EKFQ1HrVio3n+h/rqEhYa7Ba570uxcPFRl+bZVzb2C1gstuBn91BdnWGHXcSkSTAQDNQbTr0bPNcTtBJBSQyEDm7969G3bHxhLTkOHRtFnG3wFC/PrzhEzVWLrerl27IDExkcQS6gXURyga0brZzK6OBgIlAXrcA73dlObEmJiEy7phkXN+7VZzF/NVArNXLN5cycupBi97KpDf0FNieyng0nysl3L/rlNKwVuQB0faWmAW7eozJ78yAJggb2k6CG5XNgGASnP3zp0hERQRO+uZGZHzWwEhSjFvtJQQZKQ9e/aQTpBKxFBZUUp5ANRrqGA3C8Btq+kMTE2OQXPDQciy20ApEf09U8z+2CjOeMksZjdYxCz25sRPo1s9Up0925RveLvMrgK9XAgmvY5WCJqduEIiinWTN7kRgObG+ggAqDB379oVYnxEkSbeQdGKNsLYezD5bp+PnAfN2LCeSQoDIBGLoKK8hHyFCAAXNg8AI4oWwxZRsccDpkwtaMU8UHBT31ZyU2bl7NT7R0zRa/vh2cbY0YDL1+mzXq6wqf6QkykFI2a2nFkU/0CzE73HrQbZIgCcOUnbHAHIcWWDeCsARBgepYgjAEQpbAaA+DB9QwAwUVM8x8G6WshzZYNWJkJd8Ade+v7LrLQkX2pqTOw9a1F/vta348mhMvFgVXZfS4HxjfxM6UdmhQhsxkwo83mhr6eLMkVPf//SA820BwGAIihnCwAwDEdxhb7A/n37ydlC85XDYROhMkX7H03V6M/cYbI+QgDOr5ymaDDuAkxnZqoVwGelfcRKTX4jPXVvH5udLBaLqZT+zuPfR8vjVzvKXf2V2av1OZlXXVrx5walBPJcDjhY66fIIiL8g6cubims+3UBSGAcr4QE2Lc3iZQmMsxmMVPJIoapMUaf7bCRLMf/I0jxYUX8TQBA+YuLoRgR+jmoS9DPsRj1IORxP+dkpF/NSE1dZaeluWSyffF3BeDcUNHes+2+QG+p/UpNtuYGxnwMajmUFRdCx+FDMH18nBiI5SPfFAAJCciskNJMSMA4zz7gsFkUGS0vLaGYf0f7IaLAgSowGQ3A5XDCAIRMUQaERw0Avv/C6hmqP8Lg5NGOw+DMdoBSJgURn39DwONdEfH5ATabvfeuACz1l6UutuT3dxRbXi+zqm7Z1FIw67RQ56+mXOv8iRnaYqgDtppk2SoACVGmJDIfTUb0FxAAzAlgVgytDXQIMV+AhOEEZ3YWCAQCSEpKivgBxOwNPsTDBiC6/ohJ3iDPPEUFYDLqQaNS3lIpFK+r1Yp+gVqdenfrpyFPOVXrWm7ON7xVZJSDWSUFm8kEbc2NMHN8nOQ/pfbuEWp+mADER3mtyPzt27dD7O7dlAlDANAo6O7soIQ/hsGRxkaGKJgnFArJvES/Aj+Lr9He9SMD4PztzyAI6JhVYUWFK5tSpVaz6S271bycZ7Eo11s/MTHfe66vIWEykJfbV2Z75oBT+3uXTgJGlRycjizo6eyA5fkTlOBmMkSPBIC48Cq9BwDISIzvCPg8yMtxwxCaxKeW4PtPrhHNHJ+kLJVYLCIAdt0DAModPCIAonMcKIYa6uso5FKYl4vBut8X5uU8U53nyl3zihMixb4QDD6GTRPDFY7ag27tKx6T7M8OtQSsei14Cgsp3LqCUcLwTW2V+VsBIJ7ZBYkJkLhnDzESvVX8356kJMr7SsViKMzPpXIRZNaTeO6L5ymMgA+LoWuML+3ZgzI/AfYkJJL1hOdhFDqFNh4xAFhGc/hQC1VuVJSVQllpyZ/LS32vHCzNqe3zatjYOBhJuvzHcL28v9TeXWySvulUC29Y1RLItpmo6QG30oVzKPvPfSMAJCYkwt69eyElNRU4HA5wuVzgstkUN0LmGvV6KCvxUTIE3X/Mwl1aPUtiEouosEoCGYo7hcflAofFgvS0VNi/fz+ZqExI4lEDgLno7qNHyOfBUpq62gM36gPVb7ZW5Hf3FqnlkWRNMOh+4tnBGlOHzzqdpeS9Z5Rxb2F1W47TDvW1ByhrRFUKTNHSIwIgLhxwC4UHUimWbzLowW6zgt1qhewsB+TlucFXXARNDfWUl0Vlh8zCMMDc7BQcammkAgGMM2GsP8thp0QJZtO4HDaFtUN55JBYeug6ICrXjKHtwf4estAw+Nh2qPlWW3PDe+2V+dMdDpkJKwsjAPznSLWrw2tZ0YtZH2rEHDBnKqEo3w2tzQcp68NUFn8TAOzduxd4XB5lszDGjjePWxkfBLNXfb1HiVHo9uP5kPm4Q3E3TIwOQ19vFxztbIeerk6qeMZd4cp2UHIHmY3Je6RHDQAuDupH6DlK4Xe8r66Otg87qzwrHU6JKwLAv3R0bPvRcLWno9j8tIqf9rFCyAGrQQulaP+3t1LNJVU5hEVQdLnfZokBD23kiTEMRdwOxt0GAPO8cSQqpBIJeAoLqBoOGYvxJyx3wWwaQ1T1du40OT8Yw189G6ofRcL/4TXxfRi9RRCwgY+VkREKe2PwLzZ2AwClYQDmI0l4Jou3WWIq6zDhj8+KwbljwwNkko6NjsBQb9fHXX7v0+1OmafDaNwWST3+aDhQ2eGzPitlp1yT8NkUfqgsKyYZhsWwl9ZWvhkA4uMJAJlUSgbA+LEhOLO8AGdPLVKnC+Zh6fXsSVg9FwUAElZVhAFgylDwfSgGqqvK0Qz8RgAI+QMrtDuDM5NwfHwEJsaGqfx9fLj/Wnet99m2bGml36/cHgHgP0dra4+W2J/np++/JuCwwW4yQk1lGdVYUuz/GwZALBJBrttNC2BqfBSmJ0chOD0Bc7PHiTCnjNV3WMbClJdjpBUzU6gLMGGEuVp00NrbWkhv6PWZkJ6e/o0BgLtv4cQ0zE6NU755/sQ0TI0NXeup8z3f5JDWRgDAbvHnR+sbjvrsL7JS9n7CYWWA3WIi8wlXDzpguKXIAsIbolW3NXqSCrVWKOk9sSEcvQdt9igRRDqAx6O+39rAATjS1godh1vJ0+3tOgIDPUdhgnTALDEdV/uFlZAOQP2CIgeDYX3dR6kkpaaqHFxOBygx/Yk6YFdYB0QDIBJRIRfGu04tzcFapDwlpF82TVFAoBhcXgjCfHCKFg1KkpnJY5/0BopfbHHKGrxe8Y4IAP9rrKHlaIn15bR9ez7JSM8Au9VMNTUou75pAPbs2QNp6ekkhtCKQacrL9dNQbcSbxFUlZdS/hZLSVBhMgBgNTY2+qG48XoKSYfk5+ZQUzfmnnk8LjlylHlDK+gbAADPtTg3QzuBeg6mxj7prS1+uSlL0rIegPG6tq5S2yvJSYnX09LSKdZS668hJ4wAWNdR8ogAiAsHzrCqISmJRFFaWhqkhisZWBnpIBLwQatWQXFRAfUGoJghEbRyGqbGj0FZaTHodBrgcjnktKWkpEJKSjKVtODOCgX3bseIHjoAYXGIn8UCBDzX8sIsiUz02uemx6/31ha/0pQla+uLBuA/R2oPd/psP48AYLNAXaAGjj1yAIQRANZHQ8OUmEhpSjRR0ZtNx1C0SAj5OW4YQP20MBcuJ18hAIo9hSCTSmD//n3hUAY6d6EkDp6PCXPcEYrYAMCFhwjAUgSAZZibnrjeV+f7eUuW4vA6AJ4d9rcdKbaEdkD6BgCW5tcBQCbfFonJoOEqYGLlbmfWpgCIjwCwB9LT0khhomjBBPjJxfmI94nVFj5vEdX6YIEuw+zoc94XgNISKodEB4rEWpiZW3nOjQBgbmBxYZb01WnaARPXB+p8r7RmKdbvgGdH/C3txZaXU5L2fIIA2KxmcoIwB8wUK4VW/xk68VaJAQ+dk40AJCWFIpfrw9Gh9CKFo3eHwtEYx0lNSQYhn08FXViHc2J2OtI9j3WfWNIoEYvJ4w0l3sOBuDisrGBSlncCgFZXeYmPwtsYQsB7Zpi6leeMBgLvCRXv/Nw0WUDYo3zi+NgnAwdLXj6cI29ZB8APhw80HPZYXiQlnJEONouJWn8G+3q+XQDibgOA/09J3k/h6Cy7leZIINMxVIKNE+j5ut0hsbY3KQQAnhdfvxUATp+klY8pSixGQxN5ZuLYJwP1vhfb8pUNEQCCfv/2Z4b9tW0ey/Os5H3XMHhlNRupZhLzwIyi+zYASIgqsMK/o2jhcTlgNhqoSqO9rZVcfSQcd4A7l8/jEQARUfMt7AAk1Hdomc0en4CZyXGYn52BqdHha331vudb86P8AATgP4arK9s8pmd5afuvCbgsalBGpYTbfGFuNgoAvKGTWyYmYIZ9uOOjQxsASLovAAwjQznhvZR8xyJeLCf0FhWS5YOE+WEs6M3IyIikJOO3DEA/2e7kaWOoY+XUlp4z9JlQWAQ7O9ERnBw7RjGqmeMTMDbUf62n1vtsizvKE6ZY0FjA0+41PS1lp3yMoQiLXgsl3kJoP9xKiQVmW+EFsLR8qxQJmC3Pw9ixQVqtrvsAEFHCUYoTGYeWEIKAylgoEJDCZSqpUTljpQTa+qHYf/w6ipwvCgA0ANA5E4lEVK4+MtRHFgveM8PUrTxn6DOnqLMTJ7WgYzg81A9DA70wemwYBnuOftxVsyEWhNHQ58cDrk6vaUUnzPhQJeLQtClPfg40NzeQjGW2F15g5fTSlgmZj+ChVTA6MgAN9QFKWCMT756UvxOE20xMJMahXY8pSixFQcLfmQTO3c6xDoAop48BoLS0GIYHe8lxwntmmLqV56RAIKZIUQHPn6BAXG93J4VUentC0dCOKs9KW3Q0FAH48fE6U2+pddoh571nkHJvWbRyyHU6aIoIVkM8WgASHwgAw7iISAorWAorRBEp3PB5tgxAycMFAM8z2NtFYZTDh0L5gMMtDe+1VeZPtzmEt/MBmBH76WSLfKgiu9ujF73pUApwVht1vGNSeXJsNBJhxFcanLRFYpQZWlSjw18PgISIhRR3JzH//woAlPiKSVRgUx/eM8aZaADUFp6TAQAXKoYfeo62Q0tjPT1vfZ3/RkNt9ZttpfndvW6pHIdARXLC/zvYwB6tdtb6s1WvFBikf7apJWAz6KDYUwTDgwMUc7njhk4ubppWw1bCZgFIoPKRezB5ExRt/dwuWQyf/34A9PfCQjAKgC0+57nwIBIEYG7mOLQfaoLaA1WU2q0oL/1zVZnvlaZiZ+2YW8wOBmNCOWHMzuO0wMmAK7fTZ3mmMlvze6dOCmaNCtxOJxztaCc7mxmCERoHtkhx+s0SE6dHEw8tDZxWlZ1lpzwvKlas24+u3Ql1PsZSKcpXod1RFCp3DzGcqYxgYkHrRBAC0NdDYxHw+ZhFtpXnRMDwOVdOn4SZyQloqAtASTEOEaT+t9978vOeqS5y5K55996uioiuCxr3u5Yb8vRvFRhkYFLJwGox05w1jN+gOYp2PAGAF8RM1SbpfNhbZQCoJwBsIQASwgDEYidMdC3nbaWLinVrFApjMAp5Y7IzV84AABGlSURBVL3RPQHo7YH5mSgANvmcp/E1DADuHJyFhENDMBOXm+OCLIcNbFbrWw67fdmbvaEuiDku9JelLrcU9rd7zK/7zIpbZpUEDJlaqD1QTXkB7As4Gd4FeDG86GYJtyYlTOaDMDLYR8n+bIcNBPwwABSfv13BhnEftGzQ3MQsFvZzbY5YYcqgagj8GSOq94qG4u7DEhY0h3Ek5mBvN8zNhObVMbt8s89ImTv8zEmc7BKkCY8YFreYTaDTam5pVKrXtVptv1ptvXtl3L8N+fc+2VkW6Cu3X6nJUt+wq0WQqZJDmc9DcXbcBczAJbwIiqTNEqM7sFZmeKAX6gM1kG3fCEBITCSGPV6s8VQpFKDX6aiywaDfDGWC0aCnagoc3oFlgSqlkqrl0EdAn4NCFOEY0XoAPGS1YNgA7xlBQNrM8zEAYDYNHTl0wLAgAPUcdt8IBaHaUD5fFGArlXevDf0/o+Xx/z5Q7Rquzl5tyNFddapFn+vlEsh3Z9OKZSwEZnDSowIgac8eiv1jEgW929JiL3W9l5cUb4J8FNXENiHMhKE3n+t2gV6vJyYjsFQtt+vRAIDTWTD2MzYyAI31tWA26IHP43zOyki/mpaaupqWlubad6/qaOwP+LehMvFwVXZfa4HxjbxMyUdGhQjsZj0xAJuqse2fAKCLzVFz82YotDUXqMQFJ6pgqDvLbqPIJgMAIxZQVKBucNitVP+Do8OQ0KHZDGEqsr+niywanHhV6z8AeXk5NGkFS9cpJ7xjJwX5ogHAqjr8HHbu4z2fwulbm3nGxTkCijr/F4IwOT5C6dPKMh/o1ArgbegPiLlXfwB2yPxf7JCpdvk6i62XfWb5H7BE3agJdchgIh3bi5CZiPhy9E3MB+9LpMxOzt8dgMT1AGAoAes7MQ2JDJ2eGKX0IzqEmyGskEMRgC2n+Ln2Qy20gFA0oRjCSSs77gFAHwMAjs9EEDbxbNEAYNgZJQVaP/k5TtDIRMBnpfyBm7ov0iET86Bp7TgHbaDcMet3at4uNMpxaiCY9Zk09RDD08vhi0YDgH+7HzHyEW8QG6Ix3+ywW0Eg4FENJ+PFYvYLU5EY08ekCw5ZxUQLjpVExm6WQgBM3QEApinvC0D3UfosPeMmnw35wJjo+FnsC8Dr2Ux6UIu5IGYnvy3O2D8rTE3a3FStYIOXPXEgp6HdY3qpyqH6WCvm/F2jkNKcBaxQQ4ZgnJsRQTQ4bz54XyJZuhkA4kI7AKsiqDKuporGwiC1tTRvmqiS7vAhSt7jqBuqjAtXRTBlKdQleQ8AlqKHAj7g2RgA8Bkx1N7YUA9OnKAiE/9dLWR9rOGnvqQTpDRYWHs31yW5hn3CgXzzaFXWYnNe5q/1EvYNlZRPSRCcyzbQ10UBOsx3PgoA9mBVRFoaVcc5bDaqD8rFyoicnE0T7p6i/DzIz8mhVia1Skl5AgQ3Om70sABAwgYWHDCO9UWZWg2IeKwbehH713Ypa9GlYm++T5h2gd8dN1ubX3vYY3rBruRe08v5YNGraUARtgVhszXtgLAoQuvmfoQrBN+LYgFzuZjutNutwOfzqBSdWZEIADpPyCiM66MoCg3XuD3AY7OkDg/nwFg/VlljdQWCy/QIM9dCHwHNVAy79HZ1kgjDe2YYHP0caAUyFFn9i3OwEAzNGm1qrKcyGqVMDEJW6jWHgvdCsV5U61Ymb30kPs767yq2LRToRb+xKvlfGlU4IctMZt5gX8gkZdD/SgDY7g4AlahjNySWpiQnRwZupG6BsBSFGcqBpicTqiZvOMoR+yoAYJYrGgCUAjOTodE7WOCL8/OkAs6XElbKb3K0goUGl2rrsyKYaSmDVfYDAYfqRwV68fsmheBLs0YJOdnZcLi1hRQjWhrMzW5cIdHE7BS0sdHUQ1Fmt4ZmwCFTcD5EdBcL/hwdz9kqrQtRh+NBt/vF4iJ/w2uj0se+MsyuodmKOg7v+W6rHpkfDQAS/oy9CnX+GuoN1illX8r5rPdVnOQfFRrFB7oqVF9tWgrWjI7VuhS9JZaxA1nqV7PUwptoEeHosMryMug52klmKcNgvBnmBpmbvBsAaOph2aP9AQBQUI2cpq1TNAD4O54r7r4A8KmhjmpRJ0bp/hdPrF/10cQsOvwfWT5HDlN/mlGrAaWId1MnYr9qE7PHfHqJAvkY81WPc0O2XWcOF3nbPKZLhQbJVa2E+4VULABXVhbUHqghM5Gm1C7N3wFANDHKDG1sTKATALZ7A/BVw9CbpXsBgP0H2BEUvYA2PguzO/AVxRWufpweZsjMBJmQ/4WSl3HVKuNc8ulFXj/7a0zMwsN/xf84iiL8PoCAU/uCSyP6QC8T0NSsHJeTRvqix4myHU1TdLSQ8EbxbwwxIgrBwklZCIDNaqEKB2TI9h07IiLikRONsAk172FuYN++9QAwOwAtNuY57iZ6kPkoTg/W19J0eJVEBHIe6wODiP2CW8Wrq3WqOJGky9eamhgMPjFS5VYf9VhGy6yK17LVwptqCZ+mx2K0D+1urOPHGMiDARgnABglzOOG5oBu374jErt/1EBQ3zGOx6Fir3hSwmKREIq9RaQDHgQAPgf+jFHd5oZ6KMjPBYNGBTIe66aan/GaW8UfLTQJ1fhNIg/tO8ommsz7RstduU35+qVSi/xNlSDjukzIpQKuyooy8v4mx4dhLjgV2bZYTYGJHJT7i+HtPDM1Tj0H2LSWnWWnjBhaIuiZrkugPGoAUC/s2kV+AJa5KBUymnaFfgB2W4bufypEUQAgYe8Blpqgh41jO/VaNUh43OsqXvqbRnHGks8oy600yx/S3NDwceWK//Gg353WV+moaMrVrVnlnHdUgoy/aRToLFmgvKyEMmfYkoM3TPJzbjYEwsxxspPRUcEuEay4bmvFQdi5VN8Tco5ClgszSOnrWEAPJJyaFQ5FYM4BK7RxIWE1OJZiopgkRmNFG4EQ1gdhuT8xOgJH2g5R9BVNTgmf8zdRRuo7Fil7LUfDr/CblWlfe1zlvY6FxkJBr89eX2GVXc5W8t+V8zM+k4sFFGepqaqk5ghUYnjT2ESHTEcACIjgNMyEZ4Si8q4sLwWjPhM4bDbZ/OtmO2ycDfQwKHpUQWxovCV2TmKuwecppPDF+OgI3W9opYdKHvHe8TmYZ+nuPELJG4vRAFIh7zNhRsq7Mvb+yz6jpL7RqX00s6OZA6eDT5RkCw8XGNsrbPLn7Areb9VC9qf4HTFOhx0OVFXQGOOR4QFiNt488wD4OjtzPNS4NtRPHjV2tmMnjFqtooYMnHaCr1hw9dBJeptkEimolUpq3sB7wNg9Wmc4hJbZwZgbZkQpRllx56K5WVVWSitfJRF+KuOm/1bDS3/OKEpvr87WCP+rI1xs9aiPYMCt7igydFRYFD+xK3nvyfmsz9QyCdjMJhrC2trSCEODfXTjzCpCwhgSpjZxl/T3dFG+2V9dSRUJGOzD+A29Fj4CKrhNoW/l89CCwXvo78HW10GybCIAhBUwPgOmZLG1FmW+zWQAmYj/mYyX8Z6Gn/aTbCW3o8Qk/2a+P4A58BsjOkuskvYi85FSi/w5m4L7rpST/qmYz6fC3tJiD0UiMTaOzEamI/MZYkA4NjxAD48rC/UCfoZeHxk1EmGhFPYdY74B7wF35ez0BN1XSPTgfU7C1GToGzswF1LsKaAcuUzA/VTKSX9Xw894zqHkHnEpWJJHJvPvd2BlF+YOmvMy24tN0ss6UcY7Yk76dZVURFsUv6QNqx+6O9tp+zLfFYbiCE3VufCOQNd/cnSY6oUeJSGjjw33E40dG6AiYWQwMvr2PU2Rs4h/x26ZrqPt9Az4fTg4A07M51wXslLfUfFSLpul7HY0N/FLo2O+zWOiOlvYW2avr85Srjm1gl8qBOk3JXwuTcR12KyUmsPVh9sYtzM+LCrohSgrKTg1GZn7w6zEh07M+SPXmKCVTqYzxn3mZ0OtpJOjlLVDpYwzKbC/WIHRTU76TVFG8i81goy13ExJfYlJ8+1+ixJzYKwDraNOn6Wi0q5csiv4r2lE7A9kfPYXWoWUvp0Oty+1nB4+RFNOMHR7fAK3/STpCJz7sy7oxVDY9p7bYJdTL/B9iN4TZQCEKCo+hc7iiZCpiUCgCMIe4f7ebuorxpQptjvZkfli4RdSfsYHUk7aa1p+2pJFyqnwO7UCLOuP+S4dwRZfWm+ZPa/erRst0EteMEjYV1VCzg2VRHjLoFVTPT+GfHHSOM5/6O0+Sj1Z+PAoijZGHYmB65gdks0ko6P0yd2ITN87gJi+7amfQPHH6KHB0Bd9NjeRKe0pyqdCqkyt5pZCLLwh5WZc1YvYLzhV/NFigzQP7fyY7+JxxX/l8aC/aG9/iV1dn6etK7XIL9qU/FeVfNb7Eh77llwsBK1aSd/xixZIfQC/S7KNRBPuCAxvbxQRwXUiKepvUxPk1DF/w58ZYsQNynKGmPcxhKCjDkC/BZUxlkriLkUrDr93WCLg3RJyMt6XcNJf1QkyLtrlvLpCrVzttyn3fisKdysHfnPESquT01dm85YYpWMmEevHCk7quxJ22jUJL+OmSir+EqcJ5rnxe4NLIl89hZ40igAabHFskOYrYOYNZTJVO0yNhwCIsqiYXRH6nZH3E2ROonJHwnPgubAsHhswMCGE18IeM/R+0WzGCgazXvOlQiS4KWSnX+On73+Xm7r3xwpu8phNyvNWmFScSDn5d/3AotMr4e8T7iqwKlpy9DUVFvlCrk70U6OE/Ss5P+MvEh4bZEIhqJUKMBkMNGzP6ymixkA0+TC2xHwxG8pm/G5hBIBRmiGrJaQ4QxQSK+TsTU+GLKuxEQoSYs1/X28ndBxppVJxf3UVeAsLIctuB31mJqgUMrTrQcrL+IuCl/YrnTDjpxYxa8GhEtS4VDyFzcbeFRNa9f8Y3yccfUAwuP2p1gpOf6nJ7HeoanO1wkWcpSznpL0tZqf9UcJjfSQX8j5HZW3W68CdZaOvla2uKKPqOewlw92BpZGY8sMQBjpwKLbQx0DmhqiHOucx0IdzItCvwBkTbS2N0NRQC7X+Kqgs90FxYR64s+xg0mnxe18+lwp4Hwm56X8UsVPflrGSX9JyUxetUk6tN1NgrnWaOF8rmfJdO7rd7rgjXpO5yqZsyNEKZy0y7uVMMesNjZB1VSlg31AKube0cjEYtSryNp0OK+TlOGk+HPoU6NxVlPqo7LCqopwqj7H8MERlVINfWV5CpiN6rDjOoCg/h75uxWm3gNWkpzyGRi6+pRRxb6gErKtaYcYbejHrskXKnnUquQ35mVLzlkbN/6MdwQZvQrvbwi4xCdUFRokvV8vvcyi4q3ox64qMm/q6lJv2loSb8TsJn/MnqYh/QymT3NIo5TQfAr9yBLNOBr0BDAYjGI1GMJkYMoDRaACDXk9iBctCUOGrFbJbCqnohkzE/5NEwP2dmJfxloST/rpKkH4lU5C2apaw+xwKls8tZ6u9Fhxxbtl86cg/+vHDkcbYoSKbOGDXuFxqfkDB3d8vTkta5qYkPcNJ2fszblrymwJ22nsiTsaHYi77Ywmfe00q4F2TCAV/lQgFn0hFwusycYikIvxd8FepgH9NyuddE/M5H4u4rA/57PT3uBkpb3JS9v2MtX/PM+z9icvc/Xv6dfzUQK6C7SqzicQjhdrYmH/GAwC+1+f17mhzyOKLlOy9Sl5ymkWcpnSpRLkFOlGg0CDtLjbLZ3wWxUqJVfF0qV35bJlN+XypXfVimVX5cplN9UqZTfVzerUrXy61ql7E//vMyme9ZsXTXpN8pTBTOoPnydWJAg4ZL1fJTVPyknen2djsvQ7ZvngcGfPQslb/XY7ngg0JP2guYS3Vu+XH6xymqYDdNVZt9wxUWCr7ysyBXp+psdtjaO32mtq6vMbD+NrtM7T2ek2N9P9iS+VAid0zUm53jZabTcF6u/xccx4Lh9N+28/2D2PGBoPBx9DhQdsbG5o7OozbsLMcKehXbsc5CxsJ/868hz5jNG7Dz9N5gsHH7ujJ+g4c/x8PDbUXryt4GQAAAABJRU5ErkJggg==",
	r: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nO1dd3BU19Vf9d63CLTafX1XlSaJrlWXKEYUq/eVEEJCvaK2qDcwzZhi07toNgZsx8Sf/Vf8TzK2Z+KZeBIPyUzGk8w4HmIgLjHnm3Pfe9JKSFiAcOwv35s581T2lXt+955+7ioU/3/8/zH5AIXCxmKx2I6mpdlZTCb70tJFDodLFzlY0tIcZdpbmeI0maz/j5/H6/B6ch+LxRbv+8jD/v949LDkRHnuSosL6MsyGXvzEiIG8hOjB/OSk/sKktYPFiWnD+cn5g4UJBcOFKaY+wpSigcKk8y9BYmFA0WJuYP5yel9uXHre/MSkvG6obyEiL6CJOOu/DUBeN8pHvffe4BCYYMzd8i8zsNSnORrKVjt35cTF9yXHxc7mJOQ3p+XWN6bl9jRn5+4c6Ag5dCQOeXksDnlwpA5+eqQedX1QfOqmwPmlFuD5uSbg+bk64PmpKuDRckX+gsST/YXJB3C6/rzEjuGClPKRxAYc1JsX1FcMD4HnzdkXuZRWZnipPhvXRn1uYlulmIT14MzPD8hvb8gsWogL6G/Ly/xWH9+0o3egqQP+/KTPusvTPpiyJzy1XDJ6rsjSJtX/3O4ZPXXQ8Wr7iENiuevh4tX/XPQnHx3oIjQVwOFSV8MFCR9NliQ/OFQYcqNocLkY0NFSf39RYlVfUUJ6fhcS66Jw/dQ/LcclpwUT0uOSduXmxjanZewuicvvrIvP3H3QGHS6GBh8vt9+Ykf9eYm/rE7O/5vOzLj7ne+GPOwa1MMdG+Iga7UaLCsXQHtq5ZDW/IyaE1cOpGSlkFbyjLoWLMCLOuiwZIaDZ0boh92pcXe78mK/1tvXsIfBwuTPxopXvX+SEnK6Ejxqt3DJSmVQ8Upq/eY14TuLUnR7s1J+b8rpixpJveOnPjIHVnxOV05cZ3d2XEnunMSPujOTbjTm5twvy8/6WFPbiJYMuKgY1MMtL6wEhoTl0Dt8kVQuTActgYHQSnLg1nLQOEcCgr89VCgkchfD4VzaTDrWNjMCVAWEgzbFoVD3YpF0JK0FNpSV0JHegz05SfCiHnVwxFzyv2dxSl3hotTPhg2J58YKUrp3FmQkjNSmBKJ76n4v3JY0oIdezJWBnblxEf25MVndOXG93Zlx1/bkR37cUd6zF+2v2j6smnjyu+aNq6Apg0roHHdcmhYvYwwvsEUCbVLFkDVvDDYZgiCbRQPFQEsbFVTUOanhzJfHZT56GCrjw7KfPVQpqRgq4aBci0HFYwA24zBUD0/HOqXLISGmCioT14MTeuWwfZN0dCWZoL29JjvOjNjv+zKiftLf17ix4P5iddGzIm9O4tXZYxsToncWZgUOJqW5qj4BR42aWkKu11paS7dedFBvbkxm3bkxPVYsuMu78iK/a0lM/Yf3Vlx0JlmIgyvTo6CrXELoXTlfNiybB6UR82DqgVhUBsWCrXGYKhjDdCgF6BpLgctGg5aVAxs92Og1ZeGNolafRloVTLQouKg2Z+HxgAeGvQGqGONUGcMgeqwMKhYGAZli8OhdOU8qIiNgNqUxdC8bjlYcGXkJEBPTvw/+vMTfjtYmHx5uCipZ7ggftPuvISgXWlLXHA8vxhlbTKZ7HsKkwL7C+JT+nLjmrpz485ZsuM+bc+MvduabnqwfVP0D+0bo6FlzTKoj4+C6hULoCIyDMrnhUB5UBBsYw1QE8hD41wOtmtY6FCx0OXHQp8vC4PeLAx5sTDixcIuK9rpxZG/DXtzMODNQa+veE2nioVWDQdNATzU6Q1QyRuhHMXTwlCoWboAGuIioXX1MtQV0LYp+oeOzJgHXbnxd3vzEz8dLEg8N1yU3DRcnJSyc2tSoMVislf8nI80dHiK03xRwfYVJGb2Fybs682Lv92dHfd5R0bMw870GGhatxzqUhZDXVwk1C5bCLWLwqE2LATqBCM00gbYPpeHDiUH3V4sDLozsNuNgZfdWDjoysIRFw6OunBwzIWD4y4cnHThx+iECw/HXXg45sLDay4c+Sxes9+VJfcY9mCh14eHDjUPLVoBGhkDNBiDoX5+GNQvng8N0YugPjEKml5YBpa0GNQXD3uz4z7vz4u/PViYuG/QnJg5UpYYuqs4yRcdO8XP8bCkrfa3ZCbGDeQlNvbnJVzqzUu405MTd39HRuzD1tSVUJ+0GCpWLoCyRaGwNdgI2zgD1FECNAdw0KlhYUDJwW5PDg45c3DCkYfzDjxcsRfgDXsBrtsJ8KZEN2ZA+Dm85pqdAJftBTjvIMBxJwFecRPgJW8e+pT4TA6aA3io0fNQwQtQFhYEW6PCoMq0CBpXLYH2DSsfdmXG3u/Oi78zUJB0acSc3DiQmxg3XLDaX/FzOtD1HylJpAfyklN78+L7LFmx77Wnm/7a+uLK79s2rITWNcuhMTYSapbMh8p5IVDNGaEhgINWNQfdfig2WNjnwcJhdw5OOvFw0Y6HqzYC3LAR4G0bA/zKxgDvKp6O3lEYyD1u2Bjgqq0BzjsY4LgzD4fcONjrwcGgFwtdPgxsV7FQG8hBpcFA3rF26Txoio+C5jVLoWn98u/b00x/7c6Kf28wL7HvpZLkVBwvjlvxczgGstcw/fkJWQP5CXt7cuN+04ZyfuNKImqqTYugevF8qJkfCnVBQdBAG6BDI8CgJwd73Dg4hKLEmYNzjhyMOvBkxr5pI8AtiXnIxNvPSDIQt2wMcN3WAFftBPKss448HHfCFcfCHjeW6I3tcziop3ioNRigal4IVCwOh20xi6B57XJo32h60Jcd/5vhwqS9Q0UJWQNFa5j/KOMtJoV9nzkxdCA/oaQvN+FET27cJx0ZpnuNqcuJuKldsRAq54dCJWeAWh0Prf4c9PiJjD9qz8M5WwGu2gpw01aAt5FsBHgHZ7zVDB5npHEaBhtnRO8SEu+Nz8Bn3bIV4Lr0DufteDjizMEuT3xHBrZrGKjRskQ0lc8PhfroCGhdtRy6NsXc689K+KQvP+7EQGFCCY4f+fAfUbhDWQn8oDlh82BBwun+nPhPO9NN37RtWAE18ZFQuXgeMSPrKQM0q1jY4c3CCCpTZxZO23FwVSHADYkh7ykM8D/SGenX0zL66QGQr39vEt2W3uGWQoDLtjyccOTgFRcWdrox0OVBQ5OagWpGgOrwEGhYvgjaVy2DjtSV3/Rkxnzamxt7erAgYfNQYQL/kytmtHQGCuJLh4qSzg/mJ37Wlx33bdu65VBjWgTlC0OhQjBAXQALO3xY2O3Cw6uOPJy15+GaLQ83UbYrBCIWfiUxYWqmTw3Aryd8/skAmEo8iStDgLdsxBVxxY6H8/Y8HLPnYKc7C61qBqp0LJQJAmydHwK1pkXQtm75tzvSTJ/15sWfRz6MmBNDfxLGk7h8UTzTm59Q0pMbf7o7O/YPXWkx3+xIjSaKFkVONWeApjloSjKw35mFk/Y8XLYxwJtjDBckMjyBjB8XIW9P0A/PDsBtq3d6V4GTwwA3FQa4phDguCMHuzxY6PCjoWYOA2U0B9vmh0JjTCS0rF76Tfum6D90ZceeRjE8UBTPIH+eKwA9JYl0T35CVm9+wokdWbGfbl+/8tvtq5ZBw4pFUD0/FGo4A7TN4WHIm4PDqFzJrBfIgKZXqsYZyXCiSBUGeF1hgDcUBnjrGe/5OFDEZwlEYZ924mG/Gws9PgzU+9NQQfNQHhoMNSsWQn3Kkm87XjR9inGtnpzYrJHcRPq5MH40TWE3XGDy782LSe3JI9bOJ51p0f9qXr0U6pH5YSFQwwiw3V/0Ul9z5uAyMl42JZ9KZBitABAZfl1hgAs2BjiPZiWuKhsDER2y4n56/TARlLHVhs9AJe3Aw0FXDvq8GGhUM1Cu56A8NAi2LZ+PPsO/2jat/KQ7J3Zvb158KvJp1nVCf16831B+XGx3biza+R92pEXf60xdSTzImvBQqKUEaFWzMOzBwFEnlsjRdx6R188GwC2FAS7bGuCYgwEOOwpwzJGHM44CXLJHn2HcepoNAGSSFTVOpIsOaCmxMODJQIOShnLUCyFGqFm5EOpSou61vRj94Y7s+L6h/KTY/rz1frPDeVDYjJmbeYmNlqz491rTTA8aVi+F6hULoWpeKNQyBmhTs7DXnYMzaMvb8HDLRphGuT49ADdsBTjnKMBeDx76vDnoR8vKE0MOPFyyE2X3r2YZAPn9UUnjmK7a8WSCDXkw0KxioELHQonRAFsWh0N9yuIHbS+ufG8gL75xJBfNU5M98u+Z+I9RwJ7ClYHduXGZO7LiL7W8GP3XptTlUBm9ELaGB0MNMl/DkVjLSUeeiARRLguzYDYaHwHgrJMAu714sChZaFHS0OrHQK8XC0eceBi1FZ24t59KQT9eL4wraB4u2/HwqjNHVkKjioHNWho2hxiJ01mTEvXX5vXLL1nS4zIxgIei+5kAwFBsf4EppT0zZn/zphV3qtcs/r7CtBC2zA+GCkZ0rnZ6cnDMiScOzfjgZ0seG+HXElPQYbvoKMABDx56fDmoV9JQraShwY+GXk8GXnbhiKn7+gQQZucdxhW0qNdG7Xk44iquwnoNWkcslIQFgTkq7PvSuIV3mjet2L+rdHXKaO0Sl6dmPsY6uvMSgnpy45pa06Jv16xZ/KA6PhIqIsKhnBegwZ+FQS8OXnPi4IotLtHZksHGRwBAUfCWrQCXHQR41V2AQW8e6pQ0lKko2KKioFZJwQ5vBl5x5uA8BuIknTAb+mcyEEQfkcnAwytuHHT7MFA3h4HNDAd5oQbIigx+ULEq6nZHdkwT5kNGLU8ZM+rJSArszjG92JUVc7Zlw4rPt8VH/FC1dD5UBQVDQwAPXV4sHHLi4JIdT2bcbM7621MAgOGKqw4CnHQTYKcXD3V+NGxWUSQlWazRQ42ShgEPURxdtBcnhAzAu7MIgGxYYNT1nKNoou7wZWDbHAbyGBY2hHA/FEbP+7z6haVnt29Y8SLmRp4KAMzfdmZE9+xIN/2+Ze3SHyqXL4BtoSFQo+Whx5ODVxw5OG/Lk6jlu7OocG8/BoBrDgKcwpCyFw+NfjSZ/QhAvkYPpWo9NPkxMOCJuQMeXrcTngsAMgjvSJ7zBXseXnblSIZuSwAN2TwD2QuDEITfV62K6ulIj458YuZjYnpHdkxGR3r0pbYNK+62r1oK1RHhUMUaoNmPgb1OHJy14eENElKYXYvn9o8AcNpNVMTNfqIIQgDyNHooVOuhXEOTdCV6r5gDkMMdsw2ArJhx7DcVApy252HQg4YGNQ0legbyURQtCr67OX7hpeq1izOeKNGPpRn9OfGRXbmxvW1pK3/XuGrp/YboCKgJC4VGHQ/d3gy85sCRmP2tWVd2xmkBeMdWgNcnAMCMAYAroFCjh80aCmpVNPR4MXDUGVcBymvRMpudd3vUa0bxi04nBhq7vVmonsNCIctDZqhwP3d56O9KEyN6O9LjI/dWzrDkZbAkRdufG5/TmR1zrWXj8q+qYyP+XbUoHOp5I3T6c/CSBwvn7DliDUy0u58/ANesRBCKG1kEFUgAFGkoKFfR0OrDwH43Hs47GuC6ncik5wGA6CMY4LqNQHyg3W4ctPqxsDmQhRwj9++cqOCvimLmX6tZsySnaYNJOyMAMLLXlxfX2ZFh+nj7+hVQsWw+VAQZoSWQh0FfMd96zY4nzsnzYvrtaUTQFQcBjrnzJPle70dDqYqCQg2SCACuBFTM9b40DKF57CKQtCaGK0Tl+eMMfVIw5DAJZtxedeKh15OFyjk0FPIcFEaEQMGysI83x8zvLEuMeHzEFEBhM5Ib7tZfmLC6NzfuRGd6zJ9b1y4n5RyVFA87lCxRNhfseCL33v0JAXhPMkNHHQU45MFDry8HNWgFqR8FoFithyo/ioTC0We44CgmfRCA96Zh4q+fEQBcBW/ZGOAcrgJ3FprVNGyhWTCHGyF3gfHP+RFBJwoXB62uDw93m7ZKe28l59SPtZo5sZWdmXEftK+P/rIlfglUhgRD/RwWhj1ZOOHAwXVJ+fyUANy28oRf8uShTclCpZKGkmkAqFBSsF3JwC5vDs44CSSgJsZ2HmWidQ75aQGQf8ZQxREXFrp9aKgJYKBE4CA3iP8yJ0T4ICecryxfEMxVchwWBD96vGZe5jFgTozuzIjZ3bJ+xZ2m5CXfNS5dCHW8EdrVLOxz5+A8LucJlsXzAsDwiKK7YieQJY7ZtWoVTSrkijUUkftmIv9FXYBn/F+9ioY+HxZOOPMkF2ztmFmbp6ig35qUZ3gyw2LcN0Cz9DTmENxYaFWyUKZnIY9lv8vluTu5Bna3meejzQaDx5QAYM0L1t+3pZlGa1cvuV9viiB1My06gRRFverCkfi4/HI/FQBvY/zfxkBMvT0uLDT60lCKsv4xAGxRU1CtocHix8Jr6BNMAgArLTDUfNNGvDeGttF7losBfvWUAGAOYdROgMNEF3BQOZeFYoqFfJq9n09zo0UUm16s1fpOCcCe4hc0WLrdvGHl+5UJkQ+rl8yHeiEILBoO9niwcAaDbbbCpLzt8xA7hgliAUPNGF446MhBrztDxAsyGZluJswfBwDFEP68RUPBNn8a2pUMidlgtYVsiqLxgF7sVXsBLqBVhTVDDpiYN8DrCIoEwpMAINM7UrLorJ0B9rjy0KBhYGsgCyVa5mFxAPN+cQBTVUzTmikBwOaFvqKk/pbUlR9VxUaQ+swGnQADXhwcISEHtCYmJ86fh8w3TFCKV2wNcMiZh34PnP0MbFaNz/QnBYCYswoxqPeaG09qgwY8Oej1YOGAkwAXbMWVIJutMxvnRHF5S7KIjjjz0O7LQI0/A+VzaCjzpz8q86f6t3Bc8KM9WTlRnl3ZcbHdeYnHWl5Y8aeqFYugKjgEmjQc7Hbm4bSt7PU+S1L8yVbAO1Ju9pSjWEfUqGRgq4YGs1oPBeofB6DanwaLkoFXrQDA+2LI+lVXHgZ9UE4zUK2moUpFw4AbB6fsBLIKnhYAeRXgqj3lyJNQebOSgVo1DdUq6k/VaupYaYghNqeStEuJ1hA2sGHTxI6MmIzOjJibjauW/r1q8Xyo5oOgVcnBQSnWLpeRzL7TZRgbrGxTI9gXiNLlYMSdhe0+DFSqaCghMn+c0agDRBrXAQhQuZoiJSUDviypHX3djidWFIqdk848DHmy0OLLQJWahq0aitx72B3D2WIk9clE0EQiq8BGTGNiVQWaw21Yze1D/327H3tza3hQxoacKC3yfazGBxvZLFkx5W0boz9siF98v3phONTRBrD4cCT1h4n1W88RgHeRUAnaGOCajQHOoGtPFBkDzb40VCopKFWPz/SixwBQgn6AkoIOPwb2eHFwzkkE4Jq9AKedRbGDnjKasaisyWpR0bDLnYMLVunNZwEAC78u2fOkOBiruXu9WejxZO93+7AfVoUZyzdmLTIi36UVYLLvLV0VYUmPbW9ZveyzelPEw5p5YdAUKEC/Jwtn7Hm4IYmf2RY1twnjBRJmuImK0U6AUxhddOSgz50lSRc0KTdLDC+cgvlmq1VRIHnCGKru82LhsBsPlxzEQt1LDjwcduOgx5cdc+LwPnjvGhUNL7lzMGqPk0CswniWcaGiR7GHUQMEHCvudrmzD4e92c/qw4La121aEIFl/GMAjJSuju7YZNpZn7D4i4ZlC6EuOBja5/J4EQm3vkUcr9kF4Ney2LERmX/JSYCjLjzscuPA4slAHYZ3J836ohkAgPGhZh8adrtycNaBhzcwVYlhYwce9npypBAX40XFxIl7PgCgk4qgn3DmSCHwAXcOjrhxuCK/qAsL2bluY2T0GABYTLS7bE1yx0bToZoVi76qXzQPGngjdGk4kmzApYRL6nkA8K4UYrjiKMBRd4HEeFr8GChXUUSWF0o0bnaO02QA5M9sU1HQ6cXAEUceXseKN4WYK8Zi3BEvDurVDJSpRQDwmhKNnijhnUQEoQKdHQAQ9LNOUs+CKw9nXAQ46MF/VRcWdmhNamRy6SKpiAtTjzu3rlrfsX7lyW2R8+7WhYZCE2UgNfSHXdH5whITOezw7GJHnvnv2BjgdXuByGgUDdjZgrF8VIibkfHSrJbFzri8n0gIQIH08za12K60E/0Wh3G9hcUCZ5ywYIyFWg0NZZLekJU5Ao7iFhX0NXsM/D2JFTQ1AKSUBfUOZvEcMY9sgNdchbv1YaEn165dtD4tLdjRCoC1GR3rVlwonx96t5YPgu1aAYZ8xI6U1ydEPmdJ7mOFm70Ap5x52O/OESVVr2SgQiVGODGeM53ImQ4AVNK4eoa9WGJ6YhRUDpm8aWsgFW4EAH+0ycU0pgwwPrPTh4GD7hyccxbgunTtswBACn7RGsJyGrTAFAY44Wi42xAWeiE1dUHGGADiXgtrcjpTV14tCw36uoYyQJs/D7u8edIwgfENawDefQoaixqSSjlxeZ5x4kl8qceHJZUNRN4TmS+GF8QQg0hTM36iN4xWTZ83CwfdeTjvhHplfBbflADAHrMafxq2WAEgWk4UNPnRMILJJlceRh3GY17WFtHMxjsev7qmMMAlid5UGOGMg+HrxvCwqxvWLcxJSZGCcgjAnqoXCjpfWHG91GD4ujqAhw4VB3s9efLSb84CAGPy3kYguVqUjfvQRvZmSHXDFhUNRWpxJhfOEAB5ZWAWDEUKOjz7PDg4i8E3nMFSUn4mACDwKPra/dAcZeG4I0/KIN9+RgAwLHFVolsKI5xDAMJCr7/wwvyCCQDsrV5n7nxh+c3NDHevSsOQIBaKBsz6owPz7iwBICsmNM06fRioUorKsAAVovpRxk8HAP5Nlt/IfJTr2O6ECu8NKWBoHfl8HABEx6gp4uRVqCjo8GJgnzMHo9jaNKkA+EkBeFMCAQuK31YY4YKD4V5DWNjNNWsWmCevgOLOF5bdKqHYezgT0Ht72Y2D888IgCwXcTbesDPABUceDqCZ6cNArR81ltHKn4bx0wFQNAmAGg0NPX6iEkVmy00fMvBv2BrguBMPPd4sVPjTsHkyANKKQuWP5m+vO5a3iJFNdA7x/WcOgFzNbYQbCiNcVxjhDeSBIgguOhjvNYSG3lq9en7xxBVQuc7csXb5zWIdc68Ss0neLBxw4+GCk0AAQBEkIos3mimNL12MPmI2C21hrDCu9qNgi1IPJSpx8IU/AsBksgYAPdlKDQ2dfizxI96wE5n+67HuFwOM2hqIZ93uzcBmfwqK/ccdO9nKwjOCgtFWDFMMeWFKUyxvQYtNdLBmPn4E4KbCSGQ/gvCuIghGHYz36sPCbqasCX9kBRS0r1523RzIfF3lS0OXN0taOi84ict3vG/rSV5gPKh2xQHtYY40VWM5CUY0i9DSIdbO9KLnxwAgs1aDWxTQ0KJk4QAqYEeBiCF07vCMXZdH0Qdw5aDRh57k2MnPHo+wooeMMSKMpKIYHiVFXsYnnnxyo8ebEqEkuIw6IDT0esqasEk6oHJNTvuqpVdnGwA5onnakYe97gxYMK6joolzVTBh+T89ACiSNmtoUhmHMh5NSQzAoTI+7czBQReWBPRQtlf60RNm/WQAxFUlKvU6DQUjHqwUoBNn9KwAEBJyNWXNvHErCP2A3dVrM1pTll4wa5m7YkKbIe7zeWdMXshZovGl9SiJn5GzSXKa7y3JFDvoxEGXF4Zk9UT+Ts0EaowZUxM1LSGgpDJORUOXkoUhXxZ2e7PwkhcDO3xpaFTSsE0tyvjHP3vcO65Q66HXg4Hj9ti3LI5FnojiWKfjhcgP/Dwq8esS4eS95GC42xQaemHV2vBxP0ACYH1L8tKT5kD2LlomFl8GXpackqcFANN9mJhAL3DInYUmX4qkEoskAIqmYYK1BzzRG54eAMwPYOiiAmeuWuxubFMy0Iq9XWpU1Hoi92VZ/2MAICGg7Z4MvOKErVbjBb9PAoBsBSEh70ZFAE4mpc4b94RJLKg6Nbk5aekhs477Cs3QTj/JpiZ+gOyQiDd/e0oSl5xsN6PSwoKo005iQ0UHMTlF52lc9OinBWBsH6BJRVePWwGoTzAUvUUtJuXRpMQQA/4ue9YTmT/1PeXPFKv0RGdgTP+Ys+hZy8qYdOBPy4vxfrY3JAmAfsBbaIbaG75qDgo5lLBxoVUsyGKy3129LrolecnOYob7onIuA+0qluSBTzlxkic8zvy3pqRxkSP3VmH8/YgrTxL62NJjXUYoKjxqrKRkauaIlor1/yZ+Vr7+0VVDrh1T8tZAUj9KY6WOaqy4pqDfiyERTUxj4rjkQoGp+GA9IW9JzL8iecJoCZ2zM3zREhSyMzF9wXg0FAF4qWZdxPbkxe0lPP9ZeSDzsFXDwi5PlrTyYzj3nScAQBY/2LuFVkSrioFKLFpVo70vFtJOZIZ+bNbLpmCJFCbeIp2tw82FjwEg34ryJv0+UwDGrlXroVJFQZcsjp2eDABUwJfRBMbGQoUBLiqEh6fshM/agkLaEzKt8gGYmdlXt9HYkrK4fEuw4cMKmrvfMoeDYR8WjjqzJGj2ts04829NQ+MvISa2sdl5pwcD9Sq0KsTZbM2MAiuS/y6blWiFoDyvxLMEnlwFPc7MR2nyfSeLsZkQ3j8Xn4U6RU1Bh5IheYQzzmJRgpw2nY4HIp9E+X9RIcB5hQBnCPH3j9sKH7YKIeVJBRMyYhbbvU0btC2rIjLK5gXfrBCEvzfpeOhXcnDIlSV51CcBgPTySnU8Ax4YXhYzWoUzAKCULHsaGv0YEtnERjhMlpTOEIDZIGsAMLeMynzPUwCA8h+joKdtBTiOZMP//Yg9d7ONDcmIKrHKCWNVxGlLjmdjUlTstqiwY5XhQX+qZ43Q7S92f+B+O289AQC49K7YGIj51uMhJleKZwBAoUYP1b4UdHkyJEE+4iFGSpuwGgJDFmqRMT81AO1PAcDb8iR05En/HJaoHHZk//SKC3tsOxsSy1msqiLkoz4uKrhmxYL+qkWhH9Uag6AjQCAWAJYj3pgww7pSfcsAABLaSURBVKcHAM+49DCQ9ZoDD10emH0ad3SsAcifxEyU+y3eNLzkiq1PPBxy4WHYiyMVBeUSADn/AQAmiiDRI56OD+MrwAjXsKcZGe/Gw8vu6IiyH+3x4Pot/pPqguSj6oXFmvrExVXVi+e9XxUa/LAlUIA+TwZOYl6VKBXxITenIfl/+FkscMKUIOZ2UaxMVpCiotMRKpDMRBxsF1ocTpyYRXISYI8nDx2+YjUcApAtXZOP1/2IzH9awvvn4nPUOmLKyiY5FvliSOJXj+GD9UTEWlbMKO735HFPu4fDXuz7I95M1R63aSrjLElLfLevX55eY1owWjk/5H4tzUOnN026Ya5gklkCAenGFCT/HZE/52CAV1x4aPNmSMBNtiysKUcaaKFKzEhhMe2IJ0sKmtDmxpjOPk+OAFDuJzpbWdI1IgDiWaTJAFv/b7rPTE3WAGB+mUSG3Xk45yQm7N/5ER6I4BhIK+t+dxaGvBncZ+J+ty892u1Dpe/ynKY2dGjdMg9L+sromvhFu7dFhN3ZxvLftfjRcABbPzGlRnY8GX/4m5NoDAA7A5x1MMABFx5avRni0PwYAFtVFDFXcaljCBz3icOWVIzrdHljDEdcAQiAfF3eBJp8//H/PS0ABWod1PiJueJDrjzG8gkAb00zfutJiGIYewUwN93pQ33X6kff2e5D7W7z1kY3+k1THY39AbiXck18ZOW2JfM+KBcMXzZoWNjpgY3YHImNY5n3dADIf8Pkwzk7Axx05Ikrj95pwWMAKFKLlQxYRnjAgyPlIxi/x+T4SWeBPJ/UhKopIptRDGVqdAQM/Bnvg7phIj0K1OOZ/ih4+F5NPgzswR0ZHQxwyRZjO+Mh5qnGL/MAHbDjDthNykCDH/VllZ/ug0qVrrJWpeUqFdP0B5AOmfpEt9qExau3rVhwYmuQ8c/1WJrux5EkyllHTCeK2v/HAMAdTY7YT9QBjwOgSkVBtx8Dhzw4sikGlowjCDjrXnEVe5JJnRBaVCqpVEWK/6D+KFFRhIpJQl8qabGa/TMBIFdWvpJ4w8BduxcDBx0FOGtrJOEE63FON/5rNkaiA9GQ6PBloUKl/3OpWnei2F+/OlejcVMo4PH7R1QlRoRWRM/vLAsP+riWM0CHP1Z2sWS3wStWAFyfRPKLYPZn1MYIR+0F6PZgiXiRnbDxQY4DYMalrqRIyOKwOw8XsZLNRrzXFVsjnHAUYI8rBz0eLGz3ZqDelyKiATNqWAGHvWLYM4DU4EuTv1XjNsYIDLFsZBAe9Y6txY68avB3fF90wvCZr9kLcNEGJ9ajY7YeO/LkDRsjWSknHQTSsNeoYjH6+3HRXF1nrlY7s121KlOitJXxC3PKFoVcqwgyfFWvZf/d68OQHQ5H7cZj3GKUzzhG1i902cYIx+0F6HPnYBtpJRJde2S4zPgc6YwzuE5JkUJaawBwqV+XBnTKXoDDDgLsRdPUg4UBb2kXXW+OmKpY+vcSlv95iltR4vYBzSoatmkw1ytaTDL41qtCBiXXSpyhsi+VoqrDHmLF9FWb8dTioySGmzH0jI0g5xzQ+uEx8/fvCg39VX4AdS1Xq8vZwAXMrEuyMifKsyolInLb0vDeivnBv6uk2PttKobsdngGw7LSA60BeH0SEFdsjIRp6FCRqgeppHwmAFyQALBeaddwVSmMpPEBOx9fcxPgqJsAx5BcBTjpKsAp6XzUlSe5DASoFfMAKlFMyWJmKuVtDQDRSZIDth/z4phZk1bk61PSOAC4Z8YJJ55sQNvqx9zfHED/LlvH9ObQdGQK5zvzrfHLTcHujfERGdVL5l3awvN3cePsAS+GbNOCjRro5V2fBIBMhGE2RhJD3yMF43A548BwkLIpmS0NGOV1tYqCXiULr3jgjrnigGVl94YEAEYVce+5i/aibrjoYMD4+tj5kkT4O27kdNSJhz2uLLR606IjN0nU4DvIq0J+HzzjZMEaISyTxPYmND5QJ11/DABvSFLhgi1PNgzBPUir/Km7hRR7KUNgM9KCVU++JX7H2qWRNdELezYbDb+v0LE/dEp1N+heY9fKjwGA9f0H3bCllIU6rO0nnqwIQI4VAIVS1BHbYPd78HDWAQGWZKp0z2uSZYGDRT8DS9hflwh/Jn+zFRU3/g3fDxPxGA7BrBbqjJJpAECrSbaWRH2kJ7sBYIEXAold8MQoeAwAhGwE4rTilpcNSuqHkgDq9zkc15MeIjz5XhF4tGUkBdaYFr1YEh50tozlPq+fw/4w4CPudnsRV4EEwDiDRBL/hmYbLkcB9njw0O7DQLmSgny1yHh5JWRLMpfEXFDMeXKkI+aqrWzOiWQ94Mk6Zyo9JP+OwbBhN7GxD2c2yn75+QQIfB+1eC5S6Ym/0Y7hEHcWTjljWYrYwPf6FOO0BgC3bcDkP25U2O1F/1Choj7P1VFnM4O5F1Mj2KfbLQX3ualOWBBUHBXStCXYcLtSzz3oUJM6d6ILrk0C4OqEFxMDcmiOHXUUoN9dNCOLrVZBpsQIVM4YL2pWM6R6GTfZRutHlv2TaepZ+ChIeP1FWwFecuNImQlmyVAZZ1mDoNZBlkoHOSodlCn1pBMH97171Rl3xpJWGEmsjD9/4jiRBLJlD276its4NPvSDzbP0d9Op6imjBA+KFhOPT7NUbtE61JqCk8pnR+0fysn3Kmdw35PNutw4uES7qEmiwWrErxrk37HHQ6x0gxLxtHhQrMQZ12mxAR0+VE8YR8V7kCFvcBo+bwxxb1mSvJKRADI/g0YT5IAmODEqXWQq9JBgVIHdb6Y/WLhoAtHLJnrklyf6vmyOBTHLpCdul52xXYk+vsqtf5OQaB+/wZWn5K25Bl2zMIDkwZ1qRGBZUvDM8tCgy6V65m/Nitp2O2OW8yLfVziEh1Pv12Z9KKYFcI2J1zWmBtGqwRFUZa8CtSi248z1IKy10kMfcjMlxlw5QnoquyP2ArEemuTAEAbP02jg3QJBAK+Skfy1bjR7AFXjtjwOAFkBk9+tvUkuyJlvI5JuY86JfXXzVrqUpZen5kaMhdFz7PtGQcANv/zPyZ73GiiLCqssZTj3iv3px5gaeE+N44UsaKctH6hyS+KZ7SIXsXuF9KfhR4thifG5XCuWrSGmr1p2I3fH4AdM88AwBVJPOAE2WUlgvIkADIk5mOBGG53huPZ68bBCQeeiE0Un9ODOz5W9PhP2RpgjxMHTV7Ugy1q3XtZFNW4gdGGmsRNvWfna0/y4iP9SqPnxRaHG/u2MOyHtWrqXq83A/tdOTjlgOJoaibJKwFnIoaYD0uOVIsv2ucUmEmgTrJK1Dqo8qWgx52BAxiSthMII+TBXp4Byc9Fc5U4cI48DGCvGekJE62dTLUO8lX4pT964lVjCBxXNOoqXHmXHvM86zFdtBHghB0PB5x4sHgw9ypU+g9z5+r61rH62Hjj3FnaN9RKFJWbIv23RIWlloYZ95YG6j+p8dP9q8+DgcPOPJyzn8iAK48wRICLtgbStYLbieFOi+2+2KkoZssQgEx1IJT46Ul/1yApjhWBfVIA8IzPQjmOq87ihRt7iH4Igpyv0sFWpdhH1ueJX3OCMx+Zj9cKY/eR6/qnAgDPZ+0EeNmJgx0ezL9qlNQnhVr93k0UlWrS6/0Vz7pd5XRHfWIUXb40LCub1Z8wawI/bfKmvsXeqqNO4uyRByCTPAgZCGQofosFeq+70FvElYDJFhVaI4FQoNIRnwDBwVl5DlcBWhlW9700DY0xDreNsRdI7Ar9lu2YT8CaJJUezEo9+QqsFh+a7C2HOYvT9sIExk5+zlQr7CJm/Bx56Hdnvq1RUZ8WafUnMhkmK00Qns/e0fJxuLTUYeuKCCYrhC0ppJjT5RrqDy0+1DdYe4kvRJawzcTZaD0I/HlUmp2vocsuBdlQ9mPWq0yqRMDwBeYBsK4TRdw5Wx5GbUQQpmL+qNVzUIYfx2SOO0d2S8G+MxRBuIlTqycDPa4MvOTCku+qQYWLq8V61U4GdfLKxpXyqpOAXzL0TbMv9YfNc/Wns2i6ZCPPM2PFVs/7MC8NDy0KNpYWUvT5Mn/dZ40++m93urFEjp6xF0XAVDN2VMoXIzPP2QpwkgTZeGKrY+aJtPUrKWIStmFVmicDh10wIMYTmfs4AGQQztni7BTzCDt8Wej0Zcj3xOCM3+vMw6t2Apy04+GsHU+UKE6Yx62qsYmDfo2NQFKtAx7st82+1Gdb51Dnc3VU6QaG+Wm+P0A+cHfwrCCGzwxmNxfoqdNbNNSn233ob7DXFjfWwJmFFsjkwVkzalTyEbBsA1cPzthBTxZ2eDLQ6UlDjycNL5FsFEeat3Hw1vewpotWdM4GzUIB9rnyMOyJ1RX4VVYsyexhiPys9FwUI5Pfa3QKAPB83gYbyAXioPW70d80+NCflmmo03k6anNWAMNLX/T2Ex8mhf2GCGNoukCX5OvoE1s11CfN3vQ93DwVkyhYlHvBbnoALo0xD1eDgSThUfHud8INQliyNxDmYlGRnpYAGJ0BAGOgOggkKYL3xP4AXG1ncduzad5jOhDwnidR4Tpz0OfB3Gv0pT4pVetP5GjpEpz5krn5nzs2hvFMppHPygjU7y3S6H7T4Ec9GPTm4ICrtBJw0GgF4TYx0oAmD/ayVRnfedwhBeNIDtg5L37/F1ocKC6sGf1jhOWAeA0ReY+A/uh7jIMpvSu2mOLMJ/tWCNDtzjyoVlK/KZyr35up12dt5HX/2W9Rko/g4GDHtHCBXs9Sqdlaqm/LHOo99Ah3eNHfoyXzGjZK4LcmSTN4uhVxZUItpagj0HfAuBMyAkXGTJk/GVzr81QAWE8CUk6IbbRoMjvxsNOZ/X6HO/3Xeh/qvSJ/Xd8mKjA1TdDROG7Fz+lICw72zxSEOPQEC+fqL1UodXe2+9D3+72YhwfwKwixK15i4ug0zLgoz1zcrkZiBDIff36S2f80QMniBsXUMdyl3Y19OODO3G/y1N/ZqtRfKpira0wL0MWt1qt+Xt+kZ+2sFQcH+6JcxFhIfoB+31Z/6nadkv6804t5iJbOKyiPHXii0M4icwmjpxYFU8n3cYAeTz/G8LH7Sp3s2IaEih6tuIPOPAy6MQ93eNOfN/hSt8vUgfsKNPrMdK02NA33e/uPKNwnOUwm+9QQNhCjgbk6qsk8lzpXqaTQabtrcWceDLuxP6ADdNRRlK/nrJg2ExBmCwDUNejoYf4Btzne58L+MODGPuj0oO82e1GfVvrpzhVrdE2Zem1K6lw2cKyc/Bdw2CjS0uzSlmhdMng+KIumN+UF6HuK5+gvl6n1v230pf+BYd99rjwcceDhBMp69AskpYezckwRSsoQzzNh/EQSRRdaT/LPeK8L0rNOo8OG3wvjKm5jY/Fm/lHrR/12qzLwcpEmsCfXX7cpw18flKbVuuB4fjHfJ2x9oKJKCmED19LayAwqMCNbq+vdoqGu1flRH7d60n/pcaW/HHJmvtvrjJ6pWEmMATQUCRhOwIQ4kmxBTWcqTl4tMgAIKM5yvB8q1VO4fYyTmLd9yZn9btCV/rLLk/5Luy/zcY2Kumaeo+vNnjs3Y63WPzKJZQN/dor2WQ5MTG8Q6Mh0nS4nZ66us0itO7HFV/dBtY/uTrM3dd/izTzE3XlxDwl0vrDpGuM5BBCiLyaKqqkAwP/j59DZQl8AbX8MmaMDhd92sdeDhSFP5mGHF32/0Ud/p9JX90GpUneiyB/rdnQ56TQd+VQJ9F/KkRLFeaZwnHaDVhuaHhCwOmeOrtLsr9u9xZ8erVLT7zf60R91+FB/7PGm/zbgydwf8mQf7nXn4aALboaKYQD0mgWiP45Z0VGJXnU0wBEnAxx0FmC/K+6+xT4cdmPu93vSf+v2pv/Y4Ut/1OxHv1+tpke3aHS7C+boKrP8A1ajgsW6nRSOm3npyC/9SAzXuL0QrOXW8VR0GkWlZ+uoqiJ/qr9MrTtWpdLfqFPqP8R4S5s380WnJ/NVlwd9t8edudvrzvyzz535us+duTdO7Nd97uw/e9zZu90e7N0dnsxXnV7MF63e1GdNPvoP63z1NyqVumPlaqq/aA5VlRNIpadTVDQ+H99D8V962KRwnNM6g8EjLVjrm6bX++fodMH5AfrYormB6WZ/bXmZWtdRodLtrFTpD1Up9Ser/PQXapTU1Wql/nqNH3Wzxo+6hedqJXW9RklfrfGjL1Qp6ZNVSv2hapVuZ7la17HFX1teoglMN2v0sUX+uuACvd4fzUl8Lj7/F6lcn+cRxXGecbw2YK1+jnFTYGBEtlYbnafVJudqtevz5wamF/nrcgs0gYVmjd5cpNEV4xl/z/fX5ebPpdJztfr1+Pl8rTY6MzAwYqN+jnENrw2I8v0vEi/PeNhYFArbNIXCzqRQ2JcqFjlgnD0NQx7BwY6W4GBH3AJ+MuHf5c/g5/E6vB7vg/f7Oc70/wXC8dy2444AqgAAAABJRU5ErkJggg==",
	y: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nOy8B3TUV7bmy+12tsE2oJylUuVSTiCQyNB2B3cAbAsskYPBGNs4Emxyxhi7DW43Juecc0ZCqVQ5KquqVFVSKUuAfdu/t/6Fu2/3m34z8+6bcOfNnLX2Ki1BSf/a3zk7fPs76tXr/6z/s/7vi169/mXJkiU/OzR27M+X5OY+Nn166uPbpk9/fMnYsU/81ebOHfPk5r+zuWPGPPn3/75teurjwvuE9/t/zpIlPxN+7n/yy/7P+k/Xkry8PstnvBy2Iv+X0uUTf5226o3f5Syf+JvRS/N/88rSqb8ft3TSKxOW5v+mYGnBK5M/nfCrKUvyXp685PWXCpbmvTRhad5L45ZM+MUryye+PHrV5JdyNk7+RdoX00dJN8x4OWxJ3pg+/+TX/e+7oNe/CLv328m/7r1hyti+S/JfCl6RN0y+5o1RQzdOHTHu82lDZn8xPXfRVzMGr98yfeDWzZMH7Px8UtaBzZMzj30+eeCpLyYPOrtl6uBzX0wdfPbzyYNPbSoYfGzjpNwD6ycP2blu0vCt6wuGr1+bP3LRuoKRszdOGj1uzeSXhq6bMUa+dvZLwRvmj+27ZvKvewu/X3iOXv87rnXvjnz2y9mjRJum/zpn46RfjVuXP/KttfnDVq7PH7J9y9ScM9/MGnjvu7mptt3zEhr3zBW37poW2b6jIKR956TQjt1TIjr3z4jpOjxH0nX0LXnXvjnKzl0zEzq+nZ7Svm16VvtXUwe1fj4pp3HdxCG21ROH31tbMOrMxmkvb/985ksrN0x/6a3NU18at2nySzlfThklEp6j1/8ua/PcMX025+WGr5gwUrly4tCXVrw6dO6y8UM3rXp9yKG1E3JufF4wWPPVlOzKP83K9Hw3N7V793zFj0cWiDn5QQyn3o3g9LxQTr8dypn54ZxfEMOVj8RcXSjj7Acyjr+j4ODbSex7O4Pdbw3imxmD2JQ/6Mc1eYO7V76W41nx+pDK5a8P0SzPG3ZjRd7wQ6smDN+0duLwuWsKRry0bvLLys1Tx4QLz9fr/6/ry9m5z30+bUz6+vxReWsmjli86vWhO5a/mntz6djs2pWvDuzelD/wx29mDGDn3Az2vpPMgQVyDrwfw+EPwjn+URjnF0VzdYmIK0viuLJExNXPxFxfJuX6chnnF0s4+ZGUIx8oOPR+EgcWZLBzXiZbZ2ayKT+Dla+ms+R36Sz5wwA+HTfox6Wv5nSvyBtSu3riiJtr80ftWJM/avGayaPy1k0bk75kdu5zvf7/soSKZH3BqIiVeWPS10wcNX7NG6OXr3tj9PGNBaO0n08aXr950hDf5vzs77+ZMZCD7w3i9OJsLizL4PxyOWeXRnFiSQCnPu3LhRWBFG4SofljAuqvlJRvUVC6RUHZlwpKtii4tUHM1TUiLq4Wc3G1gourUzi3PJVji9PYsyCNrbNT2FiQzIb8TDZOymF9wVDW5g//fm3BaN/qiSPrl+eN0C6fOOL4moKRy1cWjBq/smB4uvDch8aOfaLX/4LrX8aO7fXzDWOznl46cYRsVf7w36/MG7Zs9cShR9ZPGlG+ecrIlm9mjWbH3JHsmpfLnrezOPphBldWDqRwywBKt6Vzb6uUu1+FcfOL/tz6sh/3vgnBvFdO3dF0ag6nUn0ohcqDSX6zHkhEv0uGeoeYsu/ElH+nQP1dMmV/TuXu1lQubUzl6GdJ7HhXxbdvp/Lt/Gy2zh3CV7OHs3nGCDZMGcHq/OEsf2NYy6r8EeWrC0YeWZ0/Ytna/OG/3zTxJdmG+VlPHxrb6+fC5+r1v8K6npv7mH/X5w8fs+z1Ye8vfy1n37LXBphWTxzY/tWMnJ4/z839y94FORz+OJvjizI4sTiBC6tU3Ps6Ff2eDOxH06k8kUDVaRk15yTUX5TiuKzAczUF3/VMfNcz8N3IoOVmOi23Mmi5k4H3Rgqua4k4rybivJKC43IGtRcysZ3KQHMgjTvfJnJ2g4JTa5M4vjqTA59lsePDLL56K42NMzJZOyWblQWD/7Iif0jPqoLh7Wvyh5tW5Y/ct3bSL97fPOWlMcLnWbIk97Fe/5GXv+GZMqrvknG5yqUTcl9dM2XYF6sLcq6sLhhYvTo//cetb2ax/6PBnFyaw/nV2VzZmMWNL1K5uUXBvT8pMB5MpuZsGq5rabhvJeEtTKC1NIEOdSId6mQ6y1LpLMugqzyd7op07mvSeaBL54EhnR5dCp2aRDoqEmlXJ9FWnoqvJJXGO6nUXEnCeErJvb0yCncncOe7NC5/nc6JdSnsXqzkm/cT+XJ+Op/PGcjGWYP5fOZQVhUM+XH5xKHVKycOv7KmYOQX6/LHvLpu8kilUC4Ln7PXf8S1ZOxLwUteHTxs4fjBC5ZNHHx4/fTc2k2zsrs3z0778et5Sez9OJlLmwZS9G0O6j2D0R/KxnQ0A/PRRCpPJeC4lkrT3VRaSlPwlStpqZDTppXRoZfRaVDQZUiky5BCtzGF++YkHlgSeWhL4KFdxX2bnG6LhC5z/CMzSegwSPFpZLhLZdTdlmK9LMZ6UYn1fCraE2kU7k3m4lYVxzep2L8qme8Wp/H1gnQ+fyuD1dMG8Gle9o+f5eV0L584rHZNwajDGyaPXrCx4BfD1ua/FNzrP9JaMlb+xLqpI2MWjR/ym6UTslesLMi+tmFWlnPru5k/7PgolT2LVRxeLuPSZhWa/QOoPJtLw5UhuG/l4L2TjedOGs1FKbRXpNGlT6XblEi7UUqLQUSLPoZWQzRtplg6rDI6bSq67Eq6K2X0VEm4Xx1PT42I7upouioj6LCHPjJbGB2WcNrMkfgM0Xg0sbjK4mgsVeAuSaH+bhr2K6loTiZTeCCRq98lcurLBPatUvKnRQq+eDeRDW9msm76YNZMHvrDuikjnesnjb62YdKoFWsLRv/mi6m/ihEKjF7/Edaq1wfFrnxj6GufvjZw84o3soo+n53Rs/OTTA6vTOHkeiXnNku48U086gMK6i9n0XRvMG3lOXRqB9OtH0inLpUuQzIPbCk8rEziQZWCTls8LeYomgxhNBlCaTaF02qLp71KTlu1mLbqONqro2mviaCtJpTW6kBaK/vRan/hkdleoNX6Iq3W/rRYgmm1hNNqjqHdLKPDnEyrPo1mdTqOonTsN1LRnUuk6LCCS9ulHN0iZtcqKVs/SWTL/Ew+n53DllkjWT9lZM/6yaOK1k4etXn91NGvrZr0cuz/VMcvyV3ymNDALHlt8NQl4zN2LJuQpNs4I7FrxyfJnN6Yxs1v07m3O5my/Qp0x6RUXpDjKUyhpSyF5vJEmsuVNJWJcZfE4FXH0GoU0WkT01UlprMyjnZ7FK22CFpsETTbImmyxeG1i/FUxuGxR+Gxh+OpDMJd2ReP/Xk8tufwWp/Ga3nKb02WZ2iy9MZn6UurNYgOWyRd9ni6bAo6LUl0mFNpNaTTrMnEWZJJzZ0MzFfTUZ/J4PKOBHYsj+bLBSI2zVWx2Z8fhrF2yoiuNZNG6dZOHr1j/ZTRUz+fOVL5PyU5jx079udLC0bEr508YtryiQN2L5+QZFo/Xflgx0cqTm9I5M72FHRHM7CeSaXqQgK1VxW47shpLU+gtUKBtzyexpIoHPdCqS0MoL44ELc2nBZLNO2VsbRXxdJRFUNbZTQtldE02WNotMXhtMbjsMbisEbSYAujwRqAw/oCTlsfXLbncFufxmN56pGZBXuWZotwGgLpsgsAxNJpFdNpFU5ZIt22NDrNGfh0GTRpsnCrs3GWDEF3Lo0TX0awY1kEX38Uz1fvJbNl3iA2zRzGyvxhD1bmjzStKRixe8PUUdPWzHg5/n94YhaohOX5OdPXThmyf+3UNNumWYqH332k4NR6FYU7kjEeS6PqfBoN11JovJWAt0hBi1pOl0FBu0FKkzYWd3kYjpIgau/1o74kgEZdGE1mYdcLjo+jrTKWFlsMTZYY3JZYHJZ46iwS6iwi6izR1FkjqLMGU28NwGnvR2NlPzyVL+K1v4DX1gePpTce8/M0m/vRag2lyx5NhzWONpNgEjosCnpsKbQZEnGXK3CXJ+CpSKNFP5iGogGUHJdxabuYo5sk7F6qYtv7qaybnsmKidksfT3n4coJw2zrC0btX58/arpQIf0PcbzAy6+aNDx2aV7u1JUFWbs3zEi1fjVP9WDPYhnnNim5tzMJ68l06i+n47yehOduAr4SFW0aBV1GOfftcrpsElqMMXi14bjUwdSXBdCgDqJRH0GTORqfNRafPR6fVYTXFEOjIQaHIY5as5Rqi5xqi/AqotYaQ601gnpbKK7qMLy1YTTXhtJcE0JzVRBeawBecyDN5lBarVF02US0mUQ0a2Np1opoMUjpNCfgVUuovh1Oze0onMUS2k2ZtBsH4SodgOVKOkUHEzn9hYxdiyVsniNnzaQklk8YwPK8nAer3hhhXTNxxO41b4yYKvhFmEP8dwVg2YSRMcvyhr629I0BO9ZMTTFtmSt9uP9TKRe3yCnbm0Tl2XTcN7JovpuO964KX4mC9r863ybnQY2c7ioJbdZYmo2RuHVhOLWhOHVhuI3ReE2xNJlFNFkkeM1iGnVxOLRx1OniqTYpqLQkUGVRUmWRUW2Jp8YSQ701isaaWJrq42gRrC4WX3U0zbYomkxR+MyxtFnEdNmUtBpkeMpFNJaKcJfF+51fczsc7Zne6M+9QPXNMP+J+KFmMH+pG0WHcTjVN7K4s0vK8bVRbP8wis2zxKzKT2blxGyW5Q15uCJvqGnVhGE71rwx4jWhGvzvFvOXjM0N/vj3Gb9ZPD5187J8hW7THNn9XYvEXPmjCsPRLBouZ9N8N5uO0oF0lKfTVp5Ih0ZJl1FJt1Xh3/09VVI67UKFE4vXEOXf9U5tBA5tJC5dDI36ONwGMV6jDK9RjtegwG1Q4jIlUG9NoboylWpbEpVWJXaTBKs+BpsuklpzDE57HG67CI8tHq8lHq9RTLNBSqtZRZc1lYfV2XRbBtCiScZVJKPqWjT6M4HcO/QcN3c/TvGR57BdD6XDkgjOQeAYwgN7Dt6yLMznVBTtknLxCykHP5WzdV4iG6aksuz1DBaPH3j/0/G5ulUTR2xeWzD8N2vzc4MFf/03BeDNV9L7LRqXM/TjcYkrFufJ762dKer6bmE8pzdJqDiUivf2MDrLhtNTkcN93QB6dGl06ZLoMqroNiv9lUeXXUaHTUyrRUSzKRaPIQaXIRqXLhqHJgaHJhZHhQinRoJbJ6dJr6LZmIzPlEqTLR1nZSa11RlUV6ZQaVVhNUoxaWIwlkdSqYul3iTGaZbSaJLj1inwaFU0a5NpNWTQbcnh+6rR3DcPp6VsAHXXlWiPh3Pju2e4sPXnXPzTYxQd7I39Rjhd9kR+dGbyQ00aPbZU2vRpuItSqb6civ5oCje3JnFkqYqtc+Wsmihn6WtpLBw7oGvpa7n3Vk4YvmLN5FFDV058pd9/E8cLc9Tc3NzH3np5gPLdX2cs+OQ12bUV00Q92z6M4/j6eAp3Kam5mElX+TAe6ofyvWEQDwwZ9BiT6TIo6TQq6DDLabfIaLVIaBbCi9/i/SFGMI9JTKNBjEMjokEdj6NcjEstx6tJoMWQSqtQpdgycVZlUFudRlVlMpXWBGxGKRZtHJaKGGoNMlyWBLzWZJotafj0QnmZQZM6i2b1INo1w+gyjMZXMoSGq6kYT4q5tzeYK9ue4dK2J7m58znUJ/tReyeSTpuShzUJdFkkdJhktBsTaTNk0KweQMONTPRHUrj6pYIDC+PYMjOGFRPlfDI2mQ9/n9mz5LUh1zZNHb3gc6E8F8rT/6/TtrG9ev38nVGDI97/Q+ari15PO7x6ptz57UIxJzZJub1TgeVMMk13s7ivy+F7UzYPjZncNybTbVTRrpfRJoQAo5RmowSvMZ5Ggwi3KZ4mq5RmmwKfTYXPrsJrVvh3fkNZPPUl8TSUSnALdIQulVaTAEAGDiH8VCVSZU+gyqqkyiTFbhBTpRfjsibRUpVFR/VguuxD6DQNoVWTS1NJDp6iHDyFQ/HcHU71hSy0B6Xc2xHJzT8FcO2bPtze+QIVx4KwX4mgsSSWDrOETmGTVITSrI2i1SSluyaDnqrBtFYMoPZyCmV7ZJxdH8l374fy+YwoPsuT8P7vUvjg9wOcKyeOOLw6f+Sr62cJdLafRf33r/ljs56e/6tBYxbmpW9Z82ZS7beLlD+c/kpO8cEkbBfTcN/NokOdSY8unfuGFHoEvsao9JeaPp2YJp0Yr05IpmKcOjEN2nicRileu4qW6mTaalJpr0nDZ0uiUSenoUxMfbGI+nsiXCUCl5NEqyEVnyWFBpuKSpuUSqtQBUn9VVGtSUKDWU5LdSb3G4bxQ8MY/rX2ZR7aXqZDMwpP4TAc13KouTAY26lsSncpuboljEufB3D1y/4U7ghCfzySuhvxeEuktGrEtBviaNaE0lD0PM6yAJrNsdx3pfODO4ce2wC895KxnpJw69swjq3qz64P+rN+ahjzfiPhrV+l/PDh73Nql74+fIvAoh6an/X0v3/3jx37xMLxObKPXh34/sppqVe++iCh59B6OVd3SNCfTcJRmEm7VqAS0mjzE2dS2vVSOoxS2oRdr5fQpJfiNchwG+S4jHKcRhkusxKvPZHmqmRaqlNorUqh2ZqIWy/HpZbgLIvHWSLCXSrGV6GgRaukySin3hJPpTUauzkKuyGKSl0UldooqjVxNFmS6aoezPc1o/mx9tf8xf5bOtS/wHltCPZTWWj2JlO4Tc6l9ZGcWtmf8+sCuLU1HP0RKXWXE/AUJdKqTnhE+pnFtBkj8VQE4NUF0WKNortewUNHCg8qU2mrSKThugzd0WhubAvi5KoX2Pp2fxaMjWHOLxOY/VJ6z/u/y76y7PUh76+eOEL27x7qvDN+VMSSvAF/+GxS5t5N81Kqdy1X/uXs1xJu7xNhER66PIMuSxYdhgS8ZdE0qaNo0cXSZhT7j22zUUaTUYHXpMRjTsBtSaDRmoDblojHnoTXnkSTYLYEvGYlHr0Mj1aCtyKepnIRvnIRLep4fBUiPEKSNUdQaQ3GZgzEqg3Eqg7EUhqErTgMV4WMVmM6PZYhfG9/mR8sr9BSNJrq0wPR7E7k1pZ4Ti8L5eiifhz/tC+XNoRRukNC3cUBNN3Npqk4g9aKZDqNKnpsMrrtIjqskbRbw2m3CSRftJ/G6LHJ6TQoaSqWU3MlHu3hCG5sfZ59S15k2eRo5r2iYPKI5L+8+XJ69Qe/Hbh3aV7uH74q+E3EvwuAD3+bk7504sBla2dnGrd9lPKXY5sVXNspoey4iKqbCpo0SXRZk2kzCvE6DG9FOD59NK3meFqsUprM8keONQuOT3pktmQahXAjmDUBt1WFxyKAJMNrEEJWPM06Ea2aONo1sXRoYmnTRNOsi8RhDqba2p9qUz+q9P2p1gRSVR5MTUkEbrWMFm0q7dpBdGlG0FE6hoYLg9HvSeLuV2IurIzg6Mf9OfJxf84sC+bmlyIMB1Pw3BxOW8lwfKVZtFSk0KZX0mGV0mkT0WGLot0WTps1lBZLKK3mcDotcXSaJLRopDQWSqi8GI36YF/OfdGfr9+NZ1FeEm++lMH0Ual/mf2LNOOHvx+0TBhv/r92/pKxuc99MjZz/PL8zMNfzEttP7g6hUvfKig+IsF4QUxdoUAnyGgzS2kxRuOuCMarD8Nnjvazli12KR6rHLdVSaMlwZ8kndbknywJpyUBp1mJyyzHbZbiNQk1uwifIY5WQyyd+hi69dH06KLo0kfSZgij0RxAnbUvDZZ+OMyBuAyhuHSRuDVxNFcoaSlPwXcvk6Zb2TgvZmPcl0Thl/FcWRXB6cXBHP0wgFNLQrm2Po6y7YlUnRpEa9Ev6Cwfha90AM3lyTRr5bQIJ9gSS6s1wu94nzkYrzGAJkMQraZI2k1xtOrFNKslOO7EYrsQSOGeUI6uUrFlzkAWjh/CvF9mMW1kcvv8VwYe/mT84PGCP/+rnb95zJg+n43LSV80Nm358vxE9dfvqbqPb1Rxd68C43kZNbelOEtFeDTRNOnD8RqC8eiDaDKH4bPH0Fotxlclw21T0GhV4bIm4rAk+63enES9OZEGkxKHSY7TJKHRFI/HFIfPFEOrKZpOUxQ9pkgemiL5wRTJ9+YIui2hNFn64bS+gMceQLM9jDZ7DB22R3RChzaZtuJUPNdTqTkpzIjl3NkczcWlwZz+pD8nPwzk9MJQrq2Op/ybFOyHBuO+PIqu0l/RqR5Fc0kWntJEPOUSPFqhR4nEawzFawzCY+hPo64vbl0/PzXeYoykxRhLiy4eb1kcjrvhmM7GcudPGRxbOoo/zv4lH/1+EDNHJ3e/+XKGev5vBiz/LC8nffd/rTJv9W/HhC8bNyRveV7q8fXTlK07Fyn+9eLXSrQnVNTeVuIul9GojsFZLvA4L9JQ8QIuQ1/c5iA8tgi89ljcNjEOi4wGs4J6s8rv+DrBTInUmxL8ADjNclxmCW7zI87HZ4qk1RRBhzGMbmMI9w3BPNAHc18fRJcxEJ+5P25bP3z2UD9L2mWXcN+WwH1TKu1lqXivJ1NzQol2u4hb60M5t7gfJxa8wIn3+3L241BurBRT/nU6VYeG47n4SzoKf8sDzW/p1ozGVzYAb1kSbrWURo0Itz4KjykcjzkUtykIl74/Ll1/3IZgmgzh+IzRtBjj8OmEcjWauhsSNPsyuLRmJLveeoml4wcy76Wkf337l6mt7/06/fin4wbmrc7LDf+vAmDFuJHKVXk5izdMTtF++04Cx9coubNLReWVJLzqRNqETlMTSW1JX6x3n8Ze8hT1+t44TH39cdphjqDeFEONMZ4ag5Qag5wao4oaYwJ1AqVgUuEQwo9FjlvgfITO2BxDiymCVmMobYZgOnT96dD0pb38Rb+1afrhMwXRZAuj1RpNuyWeLqOCHkMKXRXpNN1MofakEv2OeG6vD+X0R89zZN6zHJ7bm5PvBXB1SSzqzalU7R1B08Xf0lk4nofqV/lB/3vu68bQqs6muTwFT4UCt06CxxhHkzUGry0KjzWcRlMwLkMQjYYQPIZwmoxR+EyxtJhEtJricBVJMRxK5draweyfM5R1r2Ww8LdJLPxdCp/8NlW7bHzG4hXjBvznGVNBI/nuhJHPrnxtxEvr83N2fDUrqe7AQgWXt8ipOKzCeTeZdlMi3VUyf7yvKemD+c7j2EqfoMHUG6e1Lw5rMA3mcOpM0VQbRFTrJVQbZNQYlNQYVNSaVD/tfgWNFhkeq5hmq4gWixB+Imj7CYB2XX/aK/rSVvYCbWUv0qoOoNUgxOQ4WozxtGiltJapaC1Oofl2GvWnkzDtklG8OYaLiwI49OYz7J/+DIdmvcDZd8O4s0yOZetgGo/+ko7r47lf/BoP1eO4XyGEoOE0lwonIBm3AIBe6u/Om2zxNNmFIVA0bosAQqg/77gN4XiMkTSZov2clkAsekol2I+ncO/zbE6/M4StBemsfTWRNa8ms2JcUt3a8ak71ryW+ZLg3//H7njzXNGTS8bmitZOzJ37xdTsm9+9neA7uUxC4Z+l2M4qaS5PoqdSxcM6gVIIpqb8WSxFj1GpfhJ35Qu4qwNorAzFaYukzhJLtVFEteGvACj8INSalDSYFDjNMhotQqKOx2cT0WqNoc0cQbspnHZDKO26INo1AbSV96OtTHgNo10nps2golmtwFOkwHVdhfNiIrUnkzHtUlH6hZjrSyM5Oa8fewueYd+k3hydGcTlBbGUrkqh5s8jaD7xCl3XxtFz9w903fs1LYXD8N4dSGNhKq7iBFxqAQAZHrOMJruUpkox3koRblsMjZZIXMYIGo3hNBoj8JgiaTZF+fsEb5mIujPJ6LcO5taiYRycnck3kxLZWpDAVxNVvq8nJtzcmJc6d/7YXNHcMaIn/ykAC349sPcnvxuQs/GNzE1/mpVee+AD+feX1ovQ7JPQcFWof1X8UCvnB0ccLbYA6nXPYi9/gnrTs7Q2BNHqDKe5PhpPTSwNdhE1Fgk1Zhk1Jjm1xkfOrzMqqDfKcAjJ1yzGaxVK1jj/LuqwRtNpiaLLHEmXMZwufRidmhA6K8LpqIijS5tMhyYT751k6i+pqDyuwLxPifZbJfc2Srn+WRxn343g0NQAdr3+PAfyAzj9Zgw3P1KiWzcQ546XaD3+Ch0XfkvblZdpujKU+gtp1FxSUXtDQf1dGY4yGY16ub80bqpU0lSlwFslx10p9k/kXOZoXKYIXAIIhjDchlA8xhDcZVE4LyZRu3sIxvW/4NqHAzk+N4nDs1UcmCX7/sBMee2XBUmbpv96cM7kXw/s/U8BmD9W3nfp77PG/XFK2qE9byd1n1umoOhrMbYTMrx3FfSYFXxfG8/9unB8thdoMDxNjfZxnNbnaHUE4XMIQ5EoXNUxOOzxNNgVNNhVNFhVNAiJ2A+AjHqBeDOKcJni8Jhj8Vli/AB02mLptsXRY43jvkXEfbOI+yYRPXoJXRolHWWZNN8dSN35ZMyHlWi2Syn+UsqdNVKuLZFw4T0RJ2ZHcyA/jD2vBnM4P5Lzc6Tc+SgZ7eps6raNxLlrBI79udQcysR6UIVuXyzaw1EYz8VguxZHdVE8DRoZLpMSt02F2670W6NdRqNN4JziaDRH0WgSTkIoLn0QTn0/XGVheK4m4D0yjIZtv6R0eTZXPlBxbr6Us2+LOD43tvvLAsWhqaOzx43NGtX3nyffX2UGrX41/a0/zUi8cewD5Y+FmxMw7VXhupxIW5mK+xYp3ZWRtNr64TE9g8PwBPWGx3HansVT2w9XVQD1liBqzcKsVoS3NglvbQreaqH5SvTH/QaDmAZ9LA59FE59BG5DBE1C9WOJplNwvl3MA7uM7yuV/FCZyL9WJvPALIiu0vHczqTmdAb6vSpKtkq4tV7E1aUiLn0s5vw7Us7MkXJympijb8Rz6HURJyL1OvIAACAASURBVCdJuThbxa33kildnI5hbSbaDQmUbRRR9Hk4tzb35/qW57n17QuUHApAey4M841oqkvF1GnlNBgV/irOIZhFhssqxW2T4LHF4bFG4TYLOUGIBH1wlAXRdFNJ65lhNO39JfqNWdxcLOXS+zFcXhAuKLp//HyC+Eb+kMy3fjVsWNA/B2Bshnx9XvLK72bJNWcXStFsS6DuRAq+W8l0Vai4b46n3RKC19gbt/FpXKYncVmexl31PJ6aABz2QGqNwVQbwnFYRPjqkvHVpdBcnYzHnkCjWYbDIPqb8136MDyC7MQUQYs5mnZrHF1WCd1WOT3WBO5bk7lvSaNdl4a3KJXKMylodiZw90sxV1fHcG5xNKcXxHJqnphTb8o5PUPFqSkqTryh4nieijOTErk0M5Eb8xK5+34C9xYruL04miuL+nPh0+c4t+JJzq17nKtfP0PR/hepOBvyEwASajVyanUK6gxCyHwEhMsqx2OX+/OCIBLwWMNoNAX4K0CnOgBfoYLOK8NoP/5LrF9nULRCxPXF4dxYFMTFDwLYODFOkzckc2XesAz5P1Y/vXr9y9y8MX3WvJ4xdPNE1fbdb4qrLiyOwbRdhed8Gh1FKfRoVPSY4mjRB9KofYZG49N4bc/RXP0CvroAmmpDcNlDqTeFU2uIxGmJx1ebREttMs1ViXhtCtxmCS7/ECbib/HTawyl2Rzu1wC1muNoNYlpNUhp0clp1qj8Za+jMAH7RSVluyRc3xDL+WWRnPgojCPzwzk8J5ojM8WcmJHA6WmpnJ6Szpn8dM5MTOfcpDQuTU/i6mwF1+aJufZeFBfeCeDk/Gc4/sFjnPz0Xzi79mdc/+YpSg/3RX8xFNudOGrK5NRqldRoldTqlNQZlP4Q2mhT0VSlwlctw1cVR5M9ArclgAbDc7i0/Wkpk9N9ZyhdF35J9XdplG2I4c7KUO6u6M/Vxf1Y90Zs1as56dvfGJYxdEleRp+/3VkTLrAt+e2Y8PWvJ4//6g3p2T2zI72XFgVj+U5G8+V0uooFABR06GLwVPSlofwp3MbetFT3p9MVRmdjFG2OaJprYnDbY3FZRTRaJTRVqmiuVNFkEzghCR5TLF5jJF5TmH9Q7jOH0GIJodUaRos5kiZDNG5hKlYWR01hHLabcZiuxKE+FcPd3eGcXRfIwQ/6svftF9k9uy+7pgWxd0okB6dIOD4thbPTBnJ+Wg4XJ+dysWAwFydlcnFyIhemijk3PYIzM/txdMaz7J/5GAff+ZkfgCuf/5x7u5/DcCYY+80YakukOLSJNOiTqdEmUqtNpE6fiMOchNuejK8mmbY6FW21Ylqqo2iyB+IyP4vH2I82nYye8qH03HqZ2gMpVPwxmqJNwZRs6s+tNf1YUxDrHZudcnbikLTxc8dkhAt+9wMgzC/Xv5Yr/aogafb2KZJ7h+dFdt9YFkrVHiVt17PoKU2nR6P0k2Pusn7Ulz6L2/AirdWhdDXG0OUS0VofR3N1PF57PG6rmEbB4WahnBNqamE++8j5zaZHjm+1BtNmC6HdFkKHPYxWSwQeXSQN5VFUFkaivxJO6Zkw7hwN4cquQM58+SIHFz/HzrlPs33Ws3w37Xl2TA5kz6QoDk2WcXJaOuen53BpxjCuTBvBlSlDuTwpiwuTVJybFMeZKSGcmtaHozOf4sjcJzj58RNcWfckxdufxXQygJrrMThKZDRqE/GY0nAZ06jTJlOrTaZOn4zTnIKnMpWW2hTa6xNorxPTWhNJc2UAHpsgAOtLh0nCfX0uPSUvU38yBf3OGMq/CUPzbRD3/hjMmqnx3eMGJt+bmJMye86oVOnf5sbC6GzLxPS07dMTF+6fLbed+1DyY/kmCc6jGXTfzuVBWTY9Fcm0V8TjKQuhobQvjbpAmoWutCYGX7VAPcTgMsfhEmK8IR6HTpjtxuHUxODSRuHWhePVh9BsDKTVEkCHPZDOymC6KkPorgqj3SoAEEFdSTiWm6GUngvi5pEAzu/uy4mtfTi8/jkOLH6Gfe88w563erP3zb7smxnKgemxHJ2m4PSMTC7OzOXKzGFcmzGCa9OGcmVyJhcmKTk/JZbz00O4MOcFLi3ozfVP+1D0+Yvodvan6nQ4jbfi8ZWraDWk0GLNoNmWhduSSb0+jXp9Kg3GVJyWNNz2VJprkmmpEQZAsTRXhtBkfwGP7Wl/VSgIvh6YBnNf/Qscl9IwHxGhPxCD5XAkun3RrJ8t/3HswGTb64OTF07OTU4TrtD+DYCtb6hyds9QrT/+trLx7vJEzNtSaDqdw4O7I3hQlkOPOo32Chne8ihcZSG4tWF4hbBhjX0kmjIIlU0cDp3g/EfzXYfAF6mjcKnDcWuC8eoCaDb0pdX8Ih32vnRWBdBVFUR3jSCoDcejj6CuNBzzrTBKzoVw7XAgZ3b249jWFzmy6QWOr3iBk4v6cvyjAI4tCOXY29EcmyPmxMwEzs7M5NLMXK7OHMaNGcO5MV0AIIOLk+RcnBrD5VkhXH+3H4VL+1OxJRjr7nAaTkfTdEtCu1pFtzGVLmsG7ZVZ+GxZNJozqNOlUadLpd6QisOcRqMtBY8wPrXH47UJ8b8fbsuzeGxP4LM/76ew71sG0KMdietGGvazEiyn4qk+L8J6WswX8xMYNzC5MW9Q8vrJQ5Nz/gaAICb6ZqJk9P6Zsq1nFyhbNRvSqd2ZTdv5ETwsHM2D0iF0l2fSrlbSrBbhUUfj0Ub7VQ1uYxxOfRz12jj/uNGhk+LSyXBpJbjUcbjUUTSqQ3FXBOLVvkiTrg8txt60W/vQWfkCXVX96K4JoqMyjCZjJA51FPbCaNSXo7h9MoJL+8M4tyOMc9vCuPplODc3RnFtdSyXP4vnwidSzr6r4MybSZyfJQAwmKszhnBjxlBuzhjC1SlpXJ4s5cqMGK6/FUbhx0FoN4ZTtUdE4xkJLTfldJYq6TEkcd+aRrc9gzZ7Bl5zOg5DKjWaFL/V6lJoEMKSJRmXWegRonEag3AYeuM0PoHb+nN89ufosMXQbUmnUzcE151Uqq/IsV+SUn9TRvVVBV9/kMz4gSmtrw9K2lowJGX09NSfRFyHxvZ64qvfhbyyb0rszovvKdpNnw+gcf8Iui7+god3xnC/eChdpQNoL0+iVaOgRSdwQYJ0JB6nVkSDRkSdJh6nThg9qmgyJtIkvGqleDWxeDVhj8Z7mj40aZ6mWfcUraanaLc+Q4e9N51V/eioCqHFGo3HGE9DhRxrkQrN9QSKBdXyqSRKjiVjOJKC7UAahu/SKP8ylcK1qVxblMKFt1O5OEcAIJsr0wdxY1oOt6bncm1KClcmS7g2M5o770RQvjScqj9JaDqXStedNO6Xp/JAk8h9QyI95mTaLck0mZJwaBKoKldhK03AXpZIZUUSdfoUGgQyURdHrSaE6ornqa54nFpNL1zmXjTZnqRVmJ6ZEmnRZuMoSqb6ptxvrhIl9YWJbPsklfHZye2vD07eOSE38ZWxY+VP/A2AL37XZ/zeqWEHLn8gbbd+NYDmo6PpuSwAMJL79wbTVZLhB6BDq6LDoMJnkOPRSXBpRNT/BIBDL8dtSqBZUChYkmgxK/EZRTQLMwNtfzya3njUT+KteJwW3eO0GZ+iw/IcXZX96KwKpd0uUBwyPAJlrU3FXpaBqSgL0+2B2G4MwnllKN6zw6g/NATr9kFUbM7izmfpXHo3hYtz07gwK4NLMzK5PjObW7MHcWN2CjfmyLnznoiyT+MwbxbhPpxM991B/KAdxA/GDO7rVXTr5XQYFfiMcv/prS2XYiuWYr2nwFaiwq5OpFYnJGMVNZpYqspDsJc9j73sSarUP8Np+hc8lqdpMoXRpFfgUWdQdy+B6rtyagoVuCtUOEqT2LYolVezk9rzcpMOTByeMP5vAGye2+vJryc8m7d/bsCxS5/Fddq2p9J8Zij3bw7jh3uDeViczv0SFZ1lYro1InoMYjpMYlqE6sbfWMVRoxO0OSLqLVJcNjmeaiW+WiXNVYJKTeBN+uPSPIez7Ck8ZU/SWvEsHbo+9Jj689AWzoPKaLorRbTbxTTbpDjMMqqNcqyCaZRUFaXgOj8Yz4Fh1H6Xi/nLAZSvSePWJ4lceFvJuTkqzr6ZyIU5SVydn86tD7IoXJxB6cpUdJtTsP85GefRVNpuZPGwYhAPTVncNyfTZpDQYojDZxQqtXhc+ngatGJq1VJqyhXUqAWnC6VoCvX6JOqEBq0inpqKSGoqQqjTBuI0BNBoDKFRF0tjhQJHWTI1hUqq7sqoLpTjqlBQX5LA1oUpvJad3DlhSNKx/OEpeWP+SsoJAGyb8lT+wff6nrqyOqrTtieR5gvZ3Bd2SmkmD0sSuV8ST1dJJD0VkTwwRNNtiqXdEofPLMJpjKVGF0W1Idovmq2rFOOsleJ1yPHWi3BXClRuAI3a53GVP4u39Flay5+nU9OP+/pgHpqieGCJpdsaR7tNRLNNhNMaS60tBntlNDZjLJX3ZDScyMTxp1zsWwaiXZPGvU8TufqejLNvijk1S8KpN2Wcnafk8vvJ3Pw0neJ1mei+zsK+ZwANJwbQdHUAHSUDua/PokegN0wKmg2PJJIeo5DPhCYxFqdehEMnoUGroEGrokEn9AUpOPTJ/q/rtUoatDI/UMLmc/rfI1R8YhzlcupLVdQUyqm6K6G6UOoXDNSXKNm6MNkPQF5u4qmC4Un5/wjA7McnH/yoz9lr68O6bPsUNF3MpKcwk+/LUnhQKqe7OJrO4hC61cKkKpxucxTt1hh81jicphiqdZFUClIRgYaujKOuJh5Xg5jGuljc1RF4bcE0GfvTrH0Rn/pF2tT96CgPoEsdTHdFBF3aaDoMwkwgFq85Fqc1mlp7JPbKMCzGCCx34rDvS8K+PgvdylTuLVZxY4GU83PiOD49hmPTYzk+K46T86Rc+FDFjeWplHyRifG7gVQdzcZxIZum2wNoLU2nTZtEm17uvwLlNUT6+X23n2aOpNEYjcsglNNiXIJMRq/EqU/AqU/CKfQDfhO+TsBpUOI0yHEaZDj1UhwaKQ1qGfWlMmrvSagpEvtf3cL3SxV8/UkS4wYkd70+KPHsxKEJk/9GS/tD0KxeUw58+Oy5a+tDuqz7ZHgvpNFzN53vS5N4UCKhuziSjuIgOgWHGcLoNEfSZo2m2Rr7bwAYo/0AVNniqLbHUmOLpKEqEk9NpL9p6ayOoNseTpcphPaKAFpL+tNc2B/vnQA8hcF4S8PxVETTqI/BYRKk59HYLOEY1WFoLkWh/lpC6SdKbi+QcnleLGdmRXJ0Uhj7J4ZyoCCCw9NjOD5XwvmfACjdkolxxwDsRwZQdy4T57UUXLeVOItEuEqjaayIwKMP/wmARxz/fx6ApP8iAI4KKY5yKfUlYuqKBZWfIEyT4ix/BMDYrKSuVwclnpswJGHKPwCwbWavyQfff/rstbXBXdY9EjznUui+ncb3xYncLxbTVRxBW3Eg7eogOoWBiTA+tETTZInFaRQAiKLKGEOVOdYfhipN0di0wdSaQvFWR9JZH8tDh4h/bRDxoDKSdm0QzcX9aLz1IvVXX6TueoB/uO0sicFZ8aikrdbFYVRHoL4ZRtGRMG6tieHqXBHnZ0Zzcmo4RwpC2Pd6ELteDWLPhHAOTInh2Jtizr2v4tpnyRRtTKPimzT0u5MxH1H51WyWc1GYLwZhuxFIbXGQXx7vMf49AFH+MOQyCPlAhkuvwKlX4dQn/p0JgPzV+VKcBglOvRinVoxLI5TfEhpKRdSXxNFQGu9XaDeq5Xz9SSJ/yEzsGp+dcDYvJ2HyP4Sg7dN75R9d8NSpm2sCO227RLhPJ9J5M4n7RUq6ikW0F4fhK+lPizqQVn0ILYZwms1R/nAhNGE12mhqDLHUmkTUmuOp0kdjVQdRowvGbQ2jrSqKntpYHtQKnH8UbbpQmstC8N4LxV0YgedeHE1lcrzqBBrVidSVKjDfiafkcgg3jgRw6Zsgrnway9U5ci7MlnB6ejzHJ8dxKD+W/RNjOVAg4uBUMUdnSTgxX8qZj2RcXCrh2loRN7+I4c62cO5uD+TOzhe5s/c5yk72xnyjLy5NCF5TqD+JugR+3xiO0xD1KK4bxI8crJc/cvjfTABF9sjxhnicBhFO4dTo4mjUxOFWx+EoiaZBuIJVGo1PH4tbHc/WhUp+n5XYOX6g6lTeYNU/5oC9U3vlnVzw1LFbqwI77TvicJ9U0X49ga4iOR3FsbQUh+Et6U+TOoBmXTDNhnC8pijcxr8CEEudXuQftjQIw3htNHZBNFURhMsQgs8STrs9gk57BB3mCFp1EfgqIvGpY2mpkNJakUSrNoPmiixcpRlU3kyk4lw81w4Ecnrbi5xY259zH4q48mYSF99M4NwsFaenKzk+TcmRKUoOT1VweLqMw7MkHJ4j4sj8GI59EM6JRUGcXt6Ps+v6cH7zM5z/8kkufvMEtw88je7y8zg1QXjNwTQag3AZg/0gOA0ROA3RPzlW7A8vj0D4qwkh56/OF5JwjP//CzL7Rk00bnU0jpIIGu6F4ygOp1kbQWNZNFsXyv0AvDYo4diEIYn/VgUJfcD+KT8bf+bdZw7cXhnUXrk9DvdxJW3XVHQWyWkvjsVXGoa7NOBvekmBx/f8dFwF3qdO6AeEqkAnHEehgoilujyUOnUwTm0QHgE0YzAtpmBajGG06AUZYxytOhltekGRlkWLZhCekkHU3cpEfzaBO/tiOfPH/hxa3Yf9C/ty8u14Ls5K5cKsVM7PTuXsrFROzUrjxMxUjs5I4shMBQdnStg/K4Z9b4ax7+3+HHi/D4cXPsPR5U9wcv3PObX5Z5zf9hi3DjyF9nIfHJpAPILsxCCUk0E4DSE49OH+mYWfWtH/RK3opH9nEv/3/ZWPPganf74RiUsbSWNFJI1lkTQUh1FfFOI3b0UIzpJwtn4iE5Jwe96gxAMThyj+rQ8QADgw+YlXzr/7/M67K0Laq7eLcB/7OwBK4vCVheMuD6RRE0ijXnjgMFzGR0dVAKBeaMQ0Ehq1Ur+qoFHokiuicKpDcagDcZb3x1neF5e6L25tEE16QVcj3MdKotM8kDZDLt7SXOpuZmM8k0bhbhnnvojgwLIX2PF+b75760UOz4zn7PR0zs3I4PzsTM69OYBzc7I5M2cgJ2ancWSWigMzJOyeHsF30wL4bnZvds1/in0fPcbhZT/j9MafcXHrz7mx+wlKTj6D+ebzOLQBj3Q//wBA2E8ACPyWUJIKIEh+MgEMoen8R+f7B0yaCBrVkbhKIqgrDKbmdoDfGksDqC8MZuvHjwB4fXDizgnD/q4TLpve6/EjBX1GX3o3YGvR8vDWmj+LcR9V0XY1gc4iJe2CSrk8CrcmBJcuGKchGIcxDIfx0UM2CHREhRhXhRSPRkaTTkazTuq/COepiMBZFkh98YvU3utDTXEfGtQBePTR+Exy2sxptJkH01SRS+3NbAyn0vyXPs5viuHgkiC2v/M822b14U9T+rFvUjwnJqdzelomZ2cN5PycwVx4K5fz83I4OSeTI7MS2D9DzM6pYXw75UX+PPMZdsx/gv2fPMaJ1Y9x5esnKNz7NBWnn8Ny/Xlqivvi1AlNVOA/ASASh1CN+QnGv4LwVxOaT6H2j/Y73qkPx6kLx1URgassEue9CGpuBWG/3s9vDUX9qL4VyB8/lDJuQErrq4OStk78ey7o+pLcx45MDs65+HbE+sJPYxvtf5TTeCiJtivJdBQJ82A5Po3IL9fzJylTGA2mCBoM0TToYmkQdr9aQqNahlctTLLktGjkfq29ryIab3kojWUBOMv74VD3w6kVusZoXFoxDWUKqooSMF5SUXxQyrVvRJzeEMWhRSHsfjeQ7+YGsH1GEDumhrOvQMqR/FSOTU7nxLRMTs8awOk3szk9dyDHZqdyeJaS/TPj2T0znJ2z+7Nn/vMcXNibU6t7c/WPz1Oyry+mc0HU3A7FURbqT8AufYB/ruvUB+DQB+LQB9OgC6NBF0GD7qfPpxUuCor+zgRQYnDqovyOFy4YOoUbnxWRuMqicdyLpvpmCNarAViu9KfmTn9s1wLZssAPQONrg5LXv/H3bKgAwOGJsWkX58QvvP2xxKbboPrRuT+N1ovptBem0laegE8nDFfiaLRE4zRH0WCKpsEQQ4Muzr/7hdq3sUxOU5kCX7mC1nI5beVi2oQb8JoofNpwmvXC/FfIHcKlvGiqS2Iw3Yih9GwUN/aGcfarYI6sCmTfokB2vRPIrrnB7JkTwb5Zsf6dfWCSkkNvJHNoUgpHpqRybFoax2akcWyW4PwEDs2WcfBNEQfnRXLwvRCOLQri7NpArn8dTOm+MH8J2nBHRJMmHp+gfDNG4tIH4tT3/y8DINDrfzMBkH8GQAyuchGOe2KqbkRgvhyM8WIQlTcCMV0KYtM7kh/HDUixvZotzAOU/zYPEK7R7P2dUnpmhmL29QXKe5o1Sd0NuzLwnR9A251MWstS8OlVeK2Sn26rx9BgiqHeINDQ8dSrxThKpTSWymkqVfivpraUyGgrEdFeHusfZXYYY+gQ5CfCxWtzDA0VUVgLIyi/GMrNQwGc/aYfR9f3Zd+n/dj9fgC754Wwb04Uh+bEc+RNBUdnJnBoSiIHC5Ie2ZREDk1N5NC0RA7NUPmdf3iumKPvxHHiw2hOL4ni0tpIbn0dSemeGEyn4qi7KaGpXOaXVrZZ4v1ltFMfRIOuPw5dAA5dIA5dMA3aMBq0ETRoo/3FRIPg8ArR39mjQZNTG+V3vFMbhkuodCriaCyX4SxWUXk9FtPFcPTnQrBeCUZ3LpSN88Xd47KS7r02KGV2fu7fTcRY0utn34xRhR+ZkjD+wrzEsyXLUr3Vf87CezqblpsD/e27T5+E16rwa2Oc1jgaTHH/KQAlcv/FBd89Ob4iMb6iGNrKYujSC1qfeO5XiekWlNNWEXUVURhvhVJ8NpAre/ty+usXOb4hgCPLQzi8MIqjC+I5MV/BqXmJnJ6bwqnZqRyfnsKRacmPgJiq4sBUOQemyTgwQ+wH6ug7Ik59LOLC0niur5dQtE1CxV4p5hNSqq/IcBXJaaqQ4TNI8PlHpBE4dYH/BIBwGrSRNGiiadD8ZwDQROHUhOPUhOHSCBWQBI86icbidCqvyzGej0V7OhLThQgqTkawab7E+4eMxLPjByaPz8tV/dtM2P+XaseI+ux5I3Ho8Zkp228vSq+y/HEArmODabo2GF/xAHyCNES4RmST+f9egx8AYRCjiae+XIyjRIq7WEZTkYzmQglNt+Pw3IrAVyzo++N4YJf8X+V9B3SU17UuL8HE2AYMBqtM731GbVQoEphiIDfBdgK2LyTGDUK3wYDNxYANxmB6i+ldAiQEkgAVJE3R9KaGNBpJ05saGGMbp137u+v8Eo6Tl7yXe+O8JC97rW/9v5bWaGn2PmefffbZ+zv4bVCK34SkVP9AqJ6JFn0SbNefhKZgNG6eSET1YQ5q9ktQuyMV2s3Z0K4fh+rVOahaQSIeNa4vyUDp0jQUL1KiaKEUlxYIcWEBDxd+wUbRGxyUvsND1RYhDHukcB5XUQRQvuupCNeoEDUoELdLEHPwEHOSgx8aoo0JVBT0jfKbyM/JiDQyEGlkIdJAZioXkYY/YYAGsmNnI9bARKyBdOiQHgk5euuz0W3Lg0+TjpYbEjSU8NFynQvnZQ72rhT7nstMO/lcZvqkZZl8Uqr+hzWiJ+amSPNfVm+9uTqrsWHXWAQKchGryEUPaeFpyESvOxXdHilibQJEWnkIN/MQbuBTnY1RmwhdVjF6SeOGSYheAxc9dXTctjLxWRMXX3oE+JVXiPs+IdX0FnIx0WagobGKDnsJC7ZCEVwX01B/dizqj06Ea89kWLZMgmbNWFQuTUfZQiVKFslQvESMokUCFC7ionARG4VLWLj8Bgtl6zi4uUUAw14JXCdU8BRmIFieiZhWjW5TOrptSnQ5SV8DF2E7DSFHEkL1CYg0EsUPKL8xCdFGGiINTEQa2IjUcxGp5yFST45XBQMg73zE6rmIUUeubMTqGdTpX7dLhV7HBHSZpqCzMgtNV+RwXBSh4TIPlnMc7H1D1PhsVurWH6ek/GFd0AM59qOshCMvZC0vWT5WZ3h/3NdtJ/Lgv5qLmHY8ehxZ6LmVhi63DNFWQf/ob+IiTP5BBx9RmxBxiwjdZhF6TQL0GrnoMTAoA9xtYOOzWxzcIzX1bhZ6mlgIOZjwmVho1wnQXiNHR2UW/OWTELj6NLwFM+E+PB2ObU9BszoT1xeR3S4fF19n4cIvaLi4KBmXliTj8goarr7FwPX1LNR8yINpvxiuE0q0FaUhVJGFLm02+syZ6HOko9epRLeLNAByEHYMGMCViEhDIiKNBEmINBDlMxCpZyFSz/lG+RFXf+9yP8i7ADEXHzEXDzEX6ZMg5+SE/SUVPaaJiGuehqckB658BUynRLCe5kH7Mfvr/SsEumfVyuVPybP+dGXcrtnSUft+kj3n4sKxhRVrx9137MtD+8U8hG5OQNycg57GdHTdklO7QEr5DWyEXZz+pJNNgJhFgC6zAD1mPnpMXPSYWeizMXHbyaTSDrcb6egl09VFR9jOQtDCQ8goQ8SoRkyfh67a6Yjd+DcEC38EzxFigDzUrEpFyQIBLs6n4dwro3F2weMoWDwKhW+MRsnaRJRvYkCznQvLIRGazsjhKUxDqDyzn6/CnIVPyPpVn4I+UvVMlOdkI+x8YACi9OQB0BCpH1C+i42Ii4uIq1/5EaJ4p2gA5F3Y38np5CPm5CLmYiPuEKLLnIFu7VOIlM9A64WxsB1ToO6QCLr9HFR8xLi/dym/8Bm1as40qXTUn62O/vDHObkn54/dc2XF+KBuW+5vW85NhP9GLmKGcehxqdHVJEeULLwNHIRdTIQdLITtHERsPMQsPMTNPHSbeeixcNFn56DPwUKvg4Ee3NjJ4QAAG3BJREFUKpWRiLg9EVFbMqJWFiIWIeJmJbrN2eipm4j4zakIl0xD57kpaNyfC+N7GahYIcHl15g4/9JonJj/KE68/gOcX/YoiteMRPn7CdDtZsN+VIyWAgV8JWmIVP5e+XfsGbjjTEGfS0a1HsVdpOiLibCLjpCLRiHSQB/At0Y+pXzegPJFFKJO8bdAZtIDI5BZwKV6mrsMmeiqmozwlRloPjkWpv0KaHYIULmF9dvSjbTg3oWcPTPVqbljx4r+dHU0yU9vnJbHP/TC2GXnFo7TV72fd6fhxCR0lkxEVDsevfZMdNcrqCkYdrIRcjIQthOQ3AcbEQsHUTMHcQsHPXYePmkQ4HY9l8rzx62JiJrHIGIag4g5GTELG11mIbqNSvTUqRG7mQPflSy0nlHDeSAVus0SVKzm4uoSOi6+9iTOzB+OIy8NxpHXByH/zSEo3TgC2t1JqD8lQOeVFEQrCXVlDlU9fceagzu2DPTZVOiykrCQ3///OYjyiaKJj/9jsAfczh8rX0zhDw0gRswpQtwpRNzJR9zFQ9wqQZc2C/FrUxAqmIH6gzmo2yZH9SYeyt5m3ClemaDf9xJz2bTsVP50/p/pDyCr8irl1Ef3zsmdefzl3NM3NkwKuY5NRVtRHgKVYxEzpqPboUBPA8lvk6nHRMRBQ9hGQ9BCQ8jMQNjCRNTGRreTi9uNfIqKLG6nI2JORMg4BmHDk4gZ6eix8NFnluK2MQV9ukxEb2TCU6CC62Mp6rbzceMdGoqXjcHFhaNQ8PrjOL9wGPJXDEXhuqG48cEIaPc+CccJJtqKxAhXpqBHp8Yd4nLsmbjjyMBt0nBnlyJmEyBi4yJsYyFMGYDZP9IbON8QhJD3kIsMKIJ+10N29tF6CYWIU4zQwAELQcQuRIy4HCdpzxWiy8VH3CxBV3UWYpenwHd8Bmzbs1H9rgzla3goWkoP5S9MOP3xz2gzlUqKKPz/zB+x49k8+aGXJm4oe3dqk+XQNDSdn4D2EjUCNUp0W+W42yzHJ00C9JIwjPhTayJ8xgT4TUkIWumUWyKLUxcJ1ciUt9IQNCUiaEhAxJCMbhMbd6wSfErSHIQxsTYLkdIMtJ6SwrqXh+r3abiyahQKFj+G8wseRcGix3B51QhUfTgGpsPJcJxkoPE8G21FfPivSxCtkfezcplV6LMq0WuXo8chQZdDiLiDh6iDi4iD+P4BEB/fwKVKauLNpAyGh4CdBb+NhYCdgzCJ6urFiDdKESMGcIjgt/DgM7LhN3EQMnMRtQnQ7RSj1yVBD1mAjVLEy7MQzp8Mz/6nod+QhbI3pLi8mIezLzOaTvwsccPxeQl/GavWxul59N3zJs69tHbK1cptk+5aj+b8ZwuhCi6Xocckx+fNStxrEuE2ZYBkhKwJ8JmehI9kAEmI52IgTPlTEu3QEbAkI2BKQsiQjJiRiT6zEJ9alfjcnI57+kz0VWYiWJiCxo/5qNtGw431o3BpxSM4t+gHOL/4YRS+OQw3Nj0B21Em2q8I0FEihPeaCIEKEcLVYsS0EnQZJOg2S9BtIfsREbocAoqmMu4kfp+LCIl+BhAiTxLhEGocaiNJDMCG38amDBBy9rsfklyMukQUeYjfzIHPyILfyEbIzEHUSqgUxOh1StBLiAcNMkTLMuE7MQmNW6egcqUa514T/+exudy7Hz/PvLrvp0lz982l/WVdkssypw/fOjdXffKNvC3FG8bV6/Zn3m++QDY1cvQZFfi8XoFPXQL0OZiI2hMRsScgbE9CyJGMoIuOYD0dAQIXHX47DX7KADRETEx0m/n4xCLH51ZSHJWFT2uy0FWSivbTElh20VC1cRSurH4U+csewvmlD6HwrcdwfeNo6PfQ4L7IR7RainC1BJEaCaIaEaI6IWJ6AeJGPmJmPhUIxGz9o56KUIgBqEWVi7CTS7mYIAUeAo7+J0GI9HhRGHgfOFIMU+6Li7C1/xmx8hC18hAjZCI2wvgoQh9xRQY5QlfUaD0wAcZ38lC0MA2HXhDe3/Mst37HLPaWrf9GV5PN7l9kAGoWzM57bM/8jOdPrUwtqtyReq/1ghqRqnTcMahw1yxGr4mJuCEBIeMTiLsIrycPPa0kccVCoIEOrysZnU4avDYafMQFWZiIW/n4xC7HF/Z0/Mqajfv6HHxSoUYgX4r6/Uzc3DQSxauGIn/ZYJxd+j1ceuthVGxJgPEABw1nhOgoJSNeiHCNAOFaPsJaHiJ6LqIGDmImDqIkCLCSKmcOIg4Oos5+RJwDyicKdxDF8+G1ctFuIukQOvXeRQiebskQb5JQRiAV2u36JPgMyQhb2ehrFONuC3G9cvSRXmKyFpg4iBi5uO0Uo8eghPeSGrZtJEubiWNzlfjgx8J7780UFm2YIXx+Y96Y/z4l/rtzZOoDS+Sby7aqWi3H0r8Kl6vRp1WiV8tHXEtHVJeAsGEMuuvpuNtOON5IrpwNfwMdHa5ktNuTKSINv41JjaYeuwSfOdNw35aF+8ZsfHpTjfhlFVoPc2DYOgZla4fiwvLBOLf0+yhY+RBKN42A8SAXTecV6ChJQaBSilANH6FaLkIaHsI6LiJ1RAlsRMxsRKzs/mjHzkbYwfkG3yjezoPfzofPLkCHmQt3HRNNmiS0m8lxogw9LXJ0NfcboNNER5t2DDr1CQhZmbjdJMZnbgU+a1XibpMcvQ4xokYewnouuq0iRGrkuHUmHZpNWch/WY1tzyi+WjtD1PrWNPHm5ZNl/32uCCL/MSuDsXthyk8LN6jyNQdS/Z6i1K+i5TJEKnmIVrMQ19HRZSYnZWz0kiqCFh5CTSz4Ghhod9LQZktGh51Bffm4S4w7LhU+Jwwrlix8UpOB+FUlOk8JYN2RgKr1w1C88iFcfGMwLq0agpINw6HZQ0PjOQW8pVkU426kVomQho+QloeQjodwHRdhIwdhExthCxthGxthonw7GyE7G0EKHATsXPhtfPisAvisQnitQrSb+GitY6NZS0ObkYmgS4gIqd9pEFBuym9loMOQAK8xEUELHV1OwiEkpgKQT5uUuEMoLi1SRPUiajC0lQhh+qUKZetycPjn4756d1a6f/FUef7Cp6Q/nT+B9z9jS5ktlQ7ZsyhVcmqNas2Nj1Q1zlOyL9uLxPCV8hCp4qFLz6OqGbrJZqSej3ADF4EGFnz1/QZw25LRaSehn5Cqj7xbn051Ot6tUyN+TQnveSEaDtCh2TgC11Y/TBng8lsPo3T9MFTvSITthICKviK1E9BlGI9YXQpCOn4/6ngIG7kImzgIm9mUmyAGCH1L+WRhJYuq38allO+1COG1iNBpEcFjFKC1jotbOibcBiY6rRz4HWQ9IOsE6ZRhwmtK6g8sLMlUeN3l4FH8RXcbVLjjSkWvRYWIRoL26yzYzrJxfZscp1Zk4cPnx325amZ6zcsTFWt+liuTED0O+p/KrjfpQw8uS51euEl2QLtfGHScFPyu/bIQkUoJuutk6LMRMmwxghYufDY2fHYWvE4G2kmdv40Gr4NNhXS9jYQQKQN3rWp0V6fAe1GExsNMGLaNRvnaoShZOQSlax5B+YaRqP0oCbajArQWpSJYNR5xYx66LRMQM6YgpBf0w8BHyMSlIpKQhY2QlY0QiWIGQCIan40Dn42UNfLQaSFuR/QNPEYh3HV8tOq5aK1joc3EpM4nfDYmtR8goXTASkPAkoSAOQkBI42aab12Ke44UnDbloZuQyr8lTI0XEzGzQPJOP22CB/NT/3dmh9nB38xNe3AvPHS6bOz/wrGLGoWDBr0/c2LZIxTq7gvXH6PXaQ/JIh1XlYgfjMdPQY1teOMmWTo0LLh0TPhMTHRYWWiw85EJ3E/Lh66G2W43ajCHUcqevQq+EqEcB2jQf/RE6h491GUrBqCsjWPomZLIsz7eGg8pYT3ajbCN3MR0eYiYhiPiDELYYMKYYMYISOBEEEzn8onBa3cAcVz4LNy4LVyqBHdaeGi08JDh1mAdrMQHpPoG7SRJzGGRYQ2IxfNOhqVHm83JiFISkqcLEScTIRsDARMyejQJsKnpSNmFFO797g+DeHqdLRdlcFwdAyK3h+NXQs5eOs5Sez1KalF8/KULzw/QcYg+vurDEB2bXl5gwbvfYUuP7qKvrp8h1DjOKn80nctGz36CbhjmYBoXSraqnhwV7PQpmej08KBj/heEoHUCygCjD6XHN0mGUKVQtwqYMCw/wlUbnkMpf8xFCVrH0HlptGw7hei5Ww6/CW56K6dih7DVET0ExDQZ8FPyDgMSoTJ3zBLKb6ioFmIoEUAv5VPjXQy4oniO6wctJtJlMOjfD0Z7W1GEdzfQptJjHaLGF6bBO1mPm7p6ZQBPIZE+K00hB3ECEyEbUwETUx4dXT4NWxEdFJEalXwV6TAcyUFjjMSVO18EsdWPoG35zC/XPA0X/P8WNnqZ3PEcsI2+Z3d3vf2z8RP7FrEm3R2vfCDGztl1vr87C9i1ZPRR5SkGQv3dQnclQJ0aMmmRYCwQ4hoPaGfFFEblphFhGAtD21XGbCfGgPNnhGo2PoYrr8/HJWbx6BuNwfNp9MQuJqLrpvTcNs4A73mKQjqcuDVpqJDq4DfoEDIQiBH0CJFwCKG3yKEz0L8Ox9earRzKeV7TDx4jET5ArgNIrgNErR+G0YJ2swStFvF6CCLsoWLDgsLHSY6vOYkyv/7TcQFMREmewuLGHGjAlFtGvwVaWgpUsJ2XILqXXwUb2Bg70L6F0tncKzzJvA/eC5TNukZtfi74Q19IORSno0vSRP3LRPOOrdetk/zy5zmpotP/SpycyYi1ZPgLk2B54YcPg3hXJAh7pCip16KbhdRPh9BHRvt5TTUXxwNw9ERqN47DJUfDUfVR2Og28uG87gSncXjEauahtuGH+IT20z0Wp9CQKdGR40cnloJfHVyhKwqhKwKBK0yBCwS+C2ifgOY+eg0kxFPlM9Fm5GHNiOfKm9sNYjQapCi5Q8ggdskgYfMArsYfqcIfrI/IEYwJqJd/yQ69YnwG5mIWkToc6Shz5qNiCYHnqtq2E4oUbNThMJ1XBxewv3Vlnm85lem8Pb9JJM3a6ZU+t0z5z6QzfOEnINLFS9e3pJzWnt4krv18ozf+K5NRduVHHReVyNYk4aYIQW9NhKqKdBjFyFsYKHzZiKar46C5exj0B55FDUHh6Nm/2joDzFgP0nuj8lGqGIyunUzcNvyQ9yxPY1uSy782lS0V0vgqRFRBghaVQhalQhY5fAT+mHC22YWoNPMR4eZ1698Ew9uIx9uMvqNQrQYxANKl30LUriNUnhIHb9DilCDlApFfVY2PHWJ1B6gXZsIfx0bMbMcd5xjccc2EaGbuWgqyIZmrwrF60U4/AvOb7bPFbnXzpKcnjtJ8OKPMoV/G+7oB0KKiT5cpOAeWZ39WuHmcec0B3PbXWee+rW/5GlEKycjVjMO3To1bptTqQt4yOFMoCYJLWWPw3FpKAynh0B34lHUnRwN8xkWXBdkcJdkw1c+CaHaKYjqpyJmnIyYYQLCdWr4tUp4NRJ0aiXwGxUIWlQIkPYfqxxeiwSdVFRDFlkePGYe3CYuWk08tBr5aCWj/w8MIP8GrUY5PGYFOm0K+B0yBJwS+Ox8dJjIOpaENm0SOvVMBOtEFE9SryUX3XWT4S2dBOfJ8aj4UI1TKxS/3jFX1L5uluzckimK1/59vICbPuhvzJ7+QDbOy5AfWJKx4Py6tAuaPXkd7vwZvwmWPI1YRR56qrNwW5+Gu2Y5unVs+CpGo6n4EVgLBsNwZjCM54bBfikZDVfFcJer4ddMRFA3FQEdcTkT4deOha82Hb5aBfxaGQJ6KQIGKQKm3xvAZ5Wj0yJBh1lILaIeMxetBCYuWkw8tBj5aDEK0PJnDOA2KdBhS0HAmQK/Q45OanPGQVsdE216Gjw6Bnx1fAT0coR06QjVjIfv2kQ0nZuI2j3jUbA26zf7X03r2PCM6sKSaaoFc3Iy/t/cH/BAiI/bPj9LcHCx+vXCddnntDvGuV1Hcn4dLMpG/FoGequUuK0VoauaDt/1kbhV/DCclwbDcmEI7EUj0FDGQkuVDO2aLPgNkxAwTIZXPxGd2nHoqFWjvVqJjhoJAjoxdQNSyCRB0EzcjhJ+Cxn9UrSbxfCYBGgzceE2sdFiYuOWkY1mIwfNBi6aDTw0G4RoNojQTAxgVKDFqESrUQmPRQWvIxWh+jT47XK0Gbho1THRqqWjTcdAh44Dn14Eb60CnvIUNBWlw35KDe3ebOSvzfz1vlfS3Zt+mnJuxTTV6/NzUwSDBv0drrbKG5Q3eOOcDPmRX6S/Vrg69XTtVlWz65eqL3z5CvSUStBbwUGsPBH+shFwX30YTVeGwHVlKBquj8atm1x4dAp0GLLgNeXBa5qI9rrx8Giz4KlNhadaio4aIQI6AcIGIcImEYJmGbwWJbwWOTooA5DYnrgdNlpNTNwyMdFsJGCh2cD+vxgghTJAuCEdfpsMrTo2mmvpuFVLh1vLQruWh45aCVrLZXAWymA4JsW17VLkv636Yv+ClOaNz6lOL3s65bV5OUoq3Bz095Td/67gfvyy9MXLK4X7at8XWBoO8b4M53MQK6YhQhjJS4eh89oj8Nx4BC2VI9BSk4g2HQkT5Wg3ZcBjHguPaRzchiy06TPg0anQUSuFVyNAUMtFmEo78BEwEZ+vQIdZhnazBB5z/+hvNbLQYmSg2chAEwUmmgysgVkgQLNRhGajFC0mBVpNSrhNqn4D2FOoGeC1StFCGYCB5hoGWms5aKvho6VcBEeREJrjfJRt5+LEW5wvd78ismx4TrZv8RTFiy+PV/x9b1F6ICTXsWO2kHPyNfasK6uYH9RuelJTv2d0zHd25O+6Skagp3IY4rXDENKNgM84Bu0mGtzEVRiEaDTIUG9IRZMhAy0mNTwmNbymNASMSgQNYgS1bAQ0DAR0LPgMov/NAO4/MkDjAxiIEThoMgjQZBShySjFLZMCLWYlWs1KuC1kFsjQbpWig+wFqFQFD546DtwaNpormHAUJ6P2eDKKtif/7tgaemz3ArZm/XP8D5ZNlsyaN0HJkQ76K3I8fwv5aDYr8ZfzEp4699qQ1dXv/qCo5fCjQf/FEffD10Z+Ha8djbgxkeoa8ZtZcNex0ajlwqkRwF4rRb1eBbdZDa8tCyF7JqL2NEQtUgS1TPiqE+GtIVEJD51mKTqI7zcL0Wbmw23i/IkZwECzgYlbBg5uGQS4ZRThllGKVpMCbrMKbeYUaia01ElxSyeExyiBz6aAzyqDRy9CYyUbpsIkVBwZ+fWlbSPvH107OrhzAb1o/fPc1a9NEj41Wyr9x7pJ74HMHjT7+7tmDx+1Y85D8rNvjnyhbCttf81+To3pBM/vyhd+HSyXIlolQ6RKhkCFBL5KCTqqpGi7KYdHkwqfKQtBWw7CjkxEbCkIm0UIaGjw3RyDzuox8JAFso4Nt4ENt5EFt5EJt4kxAPrAk4k2EwseE4dKQ7QbxegwStFZp4S3Lg0+gxq+uix0krWmJhPuynTcKk9H04102K+mwHBBjprTYlzcyf36+Ea2f88qVs2WhZz961/kvrD8h1z5q9mkpucf9C7J30ve4JXzZYytb6qnH3k3fc3FD9IKKvelu81H0u65T2V8GTif/lV3YSr6rqSgm9wheUOF8M00RPTZ1PVRYVsmAhYlAgYBZYBA9ZPwVo+GR5OIVm0yWvXJaDUkw22koc1Eg8dMR7uFQaUSCNGH18yFz8yH30Qu6JEiWKdASJeKsEaNcO1YhGtyEajIQ8e1iXAXT4SzYDx0J7JQui/1q/wPFV8e3yC9t2+1xL1lkbzgnZdUa5Y9mzp9/rQMBvleg/6p7hN+M3vo+4uyJLuWT/jJsbfGby5ZP/6y7YNxro7d2Z/cOZ6J++fS8cXFFNy+rEL3tVTEarIQ1mcjYMxAZ50CnTpiACZCtcnwaxLRrk1AqzYBbl0i3HVJ8BiT0W6mocPKQKeVBZ+VS1UvhCwCKmqK1EkR0SkQqU1B5GY6ohVZiN6YgEjZU/AXT4XnwjQ0nnoa+oNPoXhLDo68lfbJjkUq16aX5ZfXzFVuXj5H+ZNFz6RKyCUWZHb/09wn/G2RSmcPWTRrGuO9+ZPVZ5ZOfL561bgtrg3qq50fqprCOyTh2AHBHd8vub/1nhXCX5oCf1UGfNoMePWpCNQpqGqHXhMp+hUhRjrPqe5zIQI2IYJ2EYKEYM8hRtAuQcgmQcgiQcgoRUgvQ6hWhmCVHIEbSvhLUxEozkCgKAe+glw0Hp2Aut3jfntjc86dgrezwh8vy2j68NXUq+/MUW5ZMUv5/PzpKepZEzIY0kH/IBd2fhdycLH0sXOvy9TXFovm6lawN1jfSjrtWDdGb974RND4UeJ9y1HB184LcjSWpsFdlQG/Vk3dtEoOcT5zZOITZxZ6XVkUG0l3fSbiLjViTjWijgyErWkImlLg1yvRWaNAe4UcbWVStF6WoPmCBA1npHAek8N5OAXmfelfV21W3r+0Rho89DpXv/3n/NPvzVVuWP2sau6i6TL14jzp/z93yv+x7JvLH148l0+/9gpdfnPh6Jnli0YtK1v++J6yt8cUXtvC1JXv5TdWH5V6dadlPeZ82f2mS9Kv/dfkiFUpEa0lfjwNQW0aApo0+DQpFKF4Z7UKniol3OUy3CqVorFYDNcFIayn+NAe5H5ds5t7/+Z2Xs/1LQJv6UZx4+V1Ct3ZFdLCQ68K9myew1y2/jnWzHeeVcqX5Snoc/vr9v81ZJUy4dGt0+j8g8+Nzv3456PnHFuatPzUO8yt59/jnCzczr1euotlrd7D7Kg7xOiyHGXftZ3k3bOdEd2znhN+Zj4r/Nx0RvCF8YzgC8Np/hf6k7zPNcc4n9V8zL5XdYB178Yuxt3SD+ldVzbROy6tY1jz32JcP7mUefLwa9ytO+aJlr//E+GctTMFuYvzePypygRSLvgvKf+LFARv//ETw3a9OnzUwcVjEvetSpQeWk2bdHRN8pwzb49ZfGHdqHeL3318Z+l7ow5f3/bkmfIdtIvXdyZfub4zqez6zuQb13Yll5ftTLpR8lFS2ZVtiVeKP0i8eGlTwpmC9QmHz72dsPPUysR3jy9NXnx0YfKcfa/QJu14mSndOFuaSGiaV48VDRsgzPjnW1z/ljJ3+qjh62YPpX3w4hDx7p8Nzjj8yuDck0u+//TZlUOfKXhn5Jxz7zw+78K6EfML1o965fyGUa+S59l1o+afXvvEvNNrhs85vmLEM0eXjHz64ILHc3e/8kTGzheTxFtmj6Ityxz1r+Ne/hoB6VnbOOh7pHtz48ZBg48sGPQQQeHGQUMegPBblC/jfwNCvV+4UfrN7x98hnx+4O987zs7n/0O5b8A+1kfSfvv7jAAAAAASUVORK5CYII=",
	file: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAJQ0lEQVR4nO1da4xdVRW+LQWVFh+pdWyZ9p6z11rf2vdSxkdj0EQcjNWEGMGoRYkIFJGmUNDaUqxiFWvFtBKtiTxiCgai/SFRMTGiMcEQyw9FS0RJ5VGKQisKVQu0tJ2ZY9Z5zNzOg5k7va/O7C/5cu6cc3rOPuvbe+33aqkUEBAQEBAQEBAQEBAQEBAQEBAQEBAQ0FLMMFar1VNEuk8H8GGAVwL8BVH6KkAbRezIGwC3wY6qdIMqfc3o4b7u4TZ50GaV+Nsebkt+7UuqskKpfE61Wp2zZMmSk1v7WSeO8UtExBC6HeA/qtL/Kl6SagUD1QqSgnYuPz+MMsT0+tA9Cu5X8B6A71OVa7u7u19TKpVOLt4bUCqVNIpUQX81w3mVAa9s7FNQn4L7NP2dMTufn8vpR2Hxb7xyv1dORal4PgqhH1e4/Lbc8LOmvQDe+7kK+oXlbAUdzg1mAiQNZCqoPbviZcCDbi2Vlp1UKpUK1ltim8WWY4ZyfJmC9ucGaqTRRxXChPbKR8C02eqc/MNn5kLMHIW1QtUrVr0o0tAyMWZ60G25URqd68di6pIUdMSDviMip/f09MzO0zPuh5to5XL51aPR6hfj/PnzTzVW51XnqOppRntHT09XSmsQMPNry+Xy643OudfZ/cPeb0I0F2fQgoUK90CNm2iFAEVJGEhLAtwDIu4S1XLEZ3J3vDjuUtUFqhqpqoqUK0DcQ57e7j0tEXEXpqWW3XIg/rRRJLrCCOaVQrQKcJ8zqtAaFXctEH9exV0DxFcCbiU4Xq3irgfcJhW6kZk2qtJa9vxOIlpYnTdvTktEEHGXenV/b6HhB6kmuBcrDf0e9KxX+p2qu9OruxmIfwBx9yjT/QA96MF/9qBdqrRbQY+r0O6U4KdSKv3D6JWeVtA+BT9bw38qaG9+ze7dY38r6HkFvaCgFyF0wO71Sk8A7m5VudQ596bcTM1zeyLRNdbkbIcAfqjUDVQ8p81bBR31Sge98qHMVWXN3nrpPafMnps9+1iOkpaaNKjyY4D7hsgiZ3bq7e2d1ZR6oQK3zqt7uY0CJDX1Qt8wN2i/rQ8xvInb30AWTe6B2jTkQjynoO0i0VtycxWNhQYKwG6dR5rj2i1AUlsiWlwfjZaG/lwE6wvdXxE52ypqs1nemz+mZbZsWemk3t7SLCspozPt74x0ZczRZ/MmaLsNn3QgazIBPaLKy5l5Xk1pqBu5KxvqfALxVVZJdcDHJh3KvI5KS8MewG3xzO8XKb8VKHvv3GIROYt91DtI5g8AdD5AFwD0ceX4o1KJlwLoyQUoDZYGkXhVEIAnIkTmkpQPKngvshbZQzZ8o8JDrbGU9LRXa32lraznvdK/7ZyCdqrKDRWJlw7WJeD4yiAA19WBzAYjs0HH4vcEW2fZ+Bq7h0TcR3IB3MogANfrkuptYQ3+XcmYQPheGwC1fsAKD3qmA3xtMk2YiZL2NWRFSSj6TBCA2yFCAtDWVICsC9/2nJFMNwFU3F1BAG2fACJuWwkUX27ThR2QK5JpVwLUXZ+OhlrbtQMSlUwz/78LcO8LAmjrBbA+ARBvTYczQgnglud+D76vIvKemgmZtOvc7qKZTI+BPdoNoqsGhyKY3fIgALdsGANC2/J1UcVwtFuu4H0dkEOS6VDxqsYfOmZSJwjArRCgL50mBd1tqzGOmU8IAnArcr8tOjjkwatHrI3ldFFWmJDxTRLA1sXa+lgP3mGTOCOmyNKxoCBA0kz3YyUAoFtHuJ9cgCsU9K8OqKiSqer7Vd1OyWbBRs4je6JV2bRZ2xObTMnxHvB/mGmrLX8ckfvzOeE1qvzfDkhwMsXYb4u/FPSrMxC/Y8xVFCLRWg860AEJTqZe7qe9IvH6anVwnelIEQC3TpVe7IBEJ1OFtpgr3Rmk9Fvn3OIxjZ8LcJ0qvdTuRPupw3w5JaX7H2xZfBBA29DyAT3iid6VG3/s9aShBHDDBbCjgn7CzN1BAG396jmA9gLu3HGNH0oAN9r32/EgQNujKCoHAbQtvv9RkfjsCe+sCXUANzD308sedLttOpxQ7jeIRmtDM5Qb4vtt/1mlko75TCz3G1TjNfmerFYW16k54yXuHtvpOeHcnwkQrVW4Ix3wEcmJnPttOMc2ZJhN6wpI4sHXKagZoQmmm/t5GNmgW2lZPdtabXmcguxBQQCt2/jp9lrL/Sp8U7VafXNd7icrAW5T8bAOyE3JCcZ0s4VtUyKlc8ye+W7IicMj3hwE4MkZP3M9+21D94SGHUaDirspCMCTEsCOEHoQcO+u2/cPlQC3JQjAk8r93mYSidafuWjRGya9d7ii8TeDADxZ9/OwSHTWcQX0CCWAJ2H89HjIAhV2dXXNPq4ATyLue6EEcP0CgJ5UpfPMhjW73ycjAG0LAnC9vv8w4L4L4I3HHWsOTHcEAbguN6RwfxJxH2xIMCeAbgsCcB3Gp31CtCYPXXP8wf1U3Y15pRJ6wjquAH0WbtMvWDA3N9/xR9ASoasVbPGCggD6yr4foJ/H8eKuhsaRswiBEHdv7TaaQC5sYOt7is0VfyhaPY2O9jsDHK3D0ALd/g4JVzbQQI4WueSVaGHKjlqa0g6X0O9Z48uY+VVNCWNpYbhU3Pfz4H0DeSzosUKu1MO+Otg/RiC9iRq2YS60iAHk4Z7x4n5KROflQV2bB124cIGKu9krP1UEFxoe2rEyyRCS41KzGKKW6yB0WEGHFPRSSqEXvNCBWubXDub3HjTm5/cr+Lk0hqjFB81oMUKfsGPaeQI9qqC/pVT3WBF/FEJPorguaSDZO4H4cmvr13S0mhbOOH2wDSqlsSOUtnvhHQr+iyo97oV3paG5QDshbocK/QagX49HFffLnD+zDWoK+pEH/VDV3ZUGaAXdYasIgPgWC90C5m+lQ7ugjWD3FbDbIEJfFKH1tQS7L9u12nvs/zkAeLUKXW2RdL13l3gpSBfbsQL6FBBdoBx/zFhVXqYafxKIL7KjXWdmSoOZ69zTSseO7Tc9lnTxglnm66rOLRLvLhShiwG+yIv7BBCdLyJLlcrvrURRuaurZ3YRd3k0Wmxmoy1Qte05WezmofjNS+bPP9VYxHu296bvrlZPKWjzq8NZe334PTXhIcfizHE4ll0CAgICAgICAgICAgICAgICAgICAgICSico/g/3GN8skNlXFQAAAABJRU5ErkJggg==",
	pick: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAMdUlEQVR4nO1de4xcZRW/pbwEfBAofTIz9zx+57uzbXksGCCSIipBFEWkRlCrGAIhCMpThQIJCsFqRBTFgigCRWgRklZMeZV3tSgUC1IkAXkWobSlIG3pY2vOnVnY1t3tzp2Znd3t/SVf+keTud93zved9zkbRTly5MiRI0eOHDly5MiRI0eOOkFEH1blE03pCgNfC/C0EOSzOWH7Ae3t7duZ0X4AX27KjwTjfwTIw2b8qxBkktmeY/pjH1stwpiwmymfZ0YvBtONSaisYLwmQBZB+NdBSoeZ0YRisfiRVu93yGGCjB0XQDMSk41hs+WMMPA6A//LwHf4KwlKR5vxQapKZvbBVu9/0KOtTdjAd1Zu/f8zoZMR5c6XAXnNwAtM5WYzPhWI91fVsdHAw7BoMMCsZC7ze2PA5sxI3hdTLwMyH6AfG/NBZlaKBhDxAcRBZJKLUIA+RkQaDTSoFhMzeaSvDAjdMMPAyw3yKMA3mMmR/iparbyZeU9Tcavu8YoITfc3y4SOS5KUEdtEAwEAgkHmZ2FA6GTEJsyQ1wB6GOBrQpDDgGLo7zOVy+VdTPkyM1nR9cVWL8vLpnSbSXxMHMcjo1ajVCoVfUPlBJkZELp5Ff57Bn7JwH8ys4/7jeyvM4nJFwP4373tz/8fEk9zE/zCC1v4GkaPHr0TQCcH43X1vILQk/JOdKOZPGNKP02Y20TkQ808z4j09tP1Bn63t735vgL4LQPfmigdEUXR8KhVIKI9DHyjgdc3mgmhyohgtDJA5qryWaqlvUIYs1ujz9HeHm0H8AkG/k9f92bgDQZeGJRPFBGePLk1jBhe8YZpVjB5sxlMCO/7FSsNfL/7FCLxp0RkH6AQ+yXwkEgdZ9jWb7IZP+i+Sy37qohffjOozA3KU0TGjmuJknZieDwoGL/eDAaElAmbWE9LTPlBVbrJNP4RJD4doEPdpA3M+3JFZLH7GSGEHl9MuVzenogODca3B5P12cWl6y1ZBsTT3WyNoknbtoAJhTIQTwvGzwVwpsOEbAp7vSkvdcUN5acNtMDAd5nSTDO+LIDPCCIHOEPGj49Hui7x5ZaMKn3BQHOCyYY699TxnvevdIdJfGQ0KaqJCcP9plSf8x4uZ32THnDr6w+4RUBE+5nGlxn4nwZZ7be2mYwImzFkU2cvVeKrDPKCy2qAZgN8pWppqiqfB6VrUhnehP1AeZHrBrfg/JX1SrjDRXZQjT+qyt8y44s8pKwaX2RWOkuVvow4nsjMYmZjAOzu8ranHxWREar0dYB+HkweCsYrtmRVhH5iTmdIpKI8ZX0SUGVU479ZFUkrAJoB8OG9MWGbwHygKl0N8CIDLzPw2nQpvW3KSyq3h2eb0dUGusSMzgZKX3Plq6p7i0jZGdTmnjHz51IGCH0XiC838ByAnzaPkLaQCS1YHZXXzx0BfFdC+ES31C+Xi6MAPsOUF6c3pYfb0yWG4zdolYFXBPArBnrSlB8CaC6UZ5nxb1I3XvmXKcNUZhr4AYCXDACi9Puq0mwlhKd1ywA3m0z50mC8tJbn2L3MTW3jFcHci5VnXA9UlKK8GExWtZoYrVoG2eiiqFsGuJlmxpe66Gkk1zddrSdCKxfAa12v9iCCRuxiRieZ8vPNUkhb80pc6Ru/oJWQRfcIgdvdqWn1ZsMQXQDPKBQKcY8MKBaLoyD8A4/Nt3qzYYgtAz0mUpoUbQkebTSVe1q94TBklm6EytMB8ekio0ZskQHuXIH5FA8jbO1KMzRgQfkVU76oWC6P2iLxuzBhDzP+UadFlCtlycgAWgPQVZkKDsaPHz8SIucHI4+ReBjhnapnvK5zNSBwtXHIrorV81AIvG+UFePGjfsAMx/isSGAfxaMZpry3Qa6z71eAz9hkFfTAqxWH9gG1jJL89rnTJhQ2DVqFDZG0TAUi8Hj7F6q4dUBBrkkDTEor231ocMAWoD8seklLO68qfIUT0VC+Y1WHzoMgFWNsi40k8nFYnHHpjLAi5Yq0U66r9YUXhiyywvNShfsvbds2eTMiGHO2RBovEf2KrpA3mn9wWVALICvZR7TlPKZYSKyQwgBAH0vgOYF0Fu5iSpdRc9fPS/ScMJ7FsdjGKp8qqn82YyXN6oIKwyRleajQZf0lvjPRHjPcIXgKUq5zUBv5ISXnm7/X1R1r8YQPoq298qGtOkCfKcH53LCSy8vgF43jc8dM6a+QjEvx95WVZNEaarb9pVqhgGZG9hQTfCvdiewlRaYgVcH8PS2tux1q0744V7hDKQm5TwPOwzUQJyB3wX4sQD+XQBPM5NfVLxz/q/L4RaInjkuprMSfhszM3B8htdceqFpE258R7XSrAFxI17pBAeKR3U9SOBwYGJ6mml8TzXn3NEvxFdebBZ/pb29faeaqV8uU8Hbg6q35+0mbNIJvgppIp4XmPFT9dUF8RqvVertTGmIBHShgZ8PJk0VS6lOBP82FAqjaya+1ywC9B0zfrYZMt51h/eAqfKZAH06UT3ClM91OznJ9r213mnZ1/N5h00w9tewtom3/zmR4gFRFlSjm7c2Y3PVVqPfM/OBnd+bPHnycE/HATwnAwPWG/h21fjgWs6YJHowlO5txkvwyjozmuldnpkY4GFSM767gbe/I80XKD8CyDml0hjb/JtezugJ/6S2b3ZA6ClwfEK2c/KXoPxqo28/vNZJ6PjMLbYh6LEuv+qs1eyoEn65d4iY0mleO9rd9zx2JL5hpaU1vqZVpqWpmQ75HhPoh8EaF6tymhnoqnrMzhRJop80kyczvQLfhPJib5AAUfe1jl3gyegAuqGWbxl4PZRv8A7Mes7p/QEA3eLZvEbcfjN5wC3HqF54njIxPTtYpRa0BsK8Csh0Ah3a16yaKn0DSjXlC8ztepNv1n3Qyos/2ksu67/98qYZTW1Ylqsil+kkqMzbUloxNVUrvsIpXO674+Fl6lCeUeNL2xDM9Um8f0MO6kwAT69H5FYr2xZ4GD5qNJLEn6lM874rg3QpyuI1wYtqjXykwFlZgk1ps7Pxgppemcl6gP/QyDO6QvbetbrsfuVrmjpSgYgKqnQsICdD6GTP+TLv2Zb19zyaqkqf6Sx5r0H8rKvF7u8rAL4/q0fuoRkIneMN3FGTMWyzlRmewAHz5w38VM0M0PjKqMFIPdcMFRxVx2uJdw9Fgwn+AtwT9hkLtVpApnRdo/cTQD/J0p/Qme3yDqBosMEHbrgnW6MSXu+jDwYKAyqd+nS9iHjv7+CCT8hKRwzUaAUBdEej9xJMrqvVEqqIH1oqEp9eZxN4a+BeMHNpiinV0nmzwaeveFauUfvgwPuayuJaQ9WV0APdG8cxosEK1XFjDfRADa+gI4AXiRT3adQevJLDMoQk0pkRoIvdn4kGKyYUCru6I1QLAwy8kGjchEZ830yO8fBxFuUbIPd6mjYazPBxNj4moAYGbIDS3EZ8G+CjoPz3LPMfPN9rGl8KjN49GuzwAJbHUkLfDr7O+4vr/yYf4t59lsRMNfTwBNB9hHfQwUMSUH6mL6/AI5dqdFI932tr00SVbjZkK52vMIBucv0VDQWEUBjdF0VsaRiaZtfjhXuq0O12zydkIX66fBKW0bebPZ2r3+BWRFCa1QcGLDOj47N+p2xyXLXVdnVW4qemp9K8ZCCOqMyKQqGwq5lc0RsD0hgQ2GNAmUZ++fCQ6pCRzPVBVbv/JaRdjUPk9js8ipjmotGzLW6gZyX0oZe2G3hRmY8yyyxyOvegvNzHVQ7QSb71IUlKRS959KqCHsIP52f53eDl8tYA4oNW+pCpMlEhGoqYOHLkzsqx1wo95gmOTaarKF23xYlS3cAnXtWTaKmIHf+XlwJyyZC8+V0BjN7d05pB+RYDzTfle3y+XHnEiJoTHRD5queo6yF+NdL5IkAXhBBqr3IbjGhvb9/J89Ei8TEipcMmTpy4c5bfCT7auI46UH+FgCzyCj4f4hdtbSgWiztmETudcH2ShQHVBMsygG/0JHvWC7BVI0m4Lf1TKTUwoEJ4Wgnl2V4q46+w1ecYtDCj/Qz0aF8ZUJ0rulCVv2/FYqnpPbxDHUVvlbV0rE5Hn2S90nwTOa6RTXRbPQJ4Rm8M6PzDED6pyv8GQX7rG4wAuri7gNv7c6VpvrfWDspk+mCA+pwKS+P9m/+Fi2e9Y93LSPqjkGqrRdErLizt6LzTjB+H8t+CT/ZVPnPIe7QDBeQDxlWPVi1NEYkn+98RaOiMnhw5cuTIkSNHjhw5cuTIkSNHVB/+B1v35BeaAo+/AAAAAElFTkSuQmCC",
	pickEffect: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAOKUlEQVR4nO1dDZBcxXF+dyBhu2I7QlFFJ/b27XRPfz13QnYSATEyWIAxPyaxY5cdC4EJCVi/TmKSorAjgWSMCRZGKHbFdpkq2/woBvEvWeAqwDGpUAFCpSIgQujHRmARJOsfEYGku0313p6Q7t7uvb29vd077VfVVVe7b+e9+Xqmp6e7510UNdFEE0000UQTTTTRRBNNNNFEE02MTGSz2XHCub+Gp+96z0tE6KJ6P9Mxg86oc6yIOxdw9yt4bRB+XpXuCUKflWyW2tra3hdF0XH1fs5Ri85M5kQVd2sA7Q3q8yYKOhiEfwXvfgq4q0Tok8hmHdD2e5lM5r1RFLXU+7lHDVTbJwFudS/5R0i3gt4OytsU/mUVegigb4vQX3if7Yzj+Hfr/eyjArlcLob4pxIU0FcOBfX7g9JrAD8m4hYo0RTv/QeG+5lFhJSz07yPP9Le3s7RSEYcxznA/2cKBRwlEN4J8NOAv9EWbZG4w/vohCiKWmv5vLlcTtXT3RBeB/BaEXoU3l1BdJJEUTQ2Gmlg5nYI/bJSBYR3ZT+Efw34f1WhqwE6ozgrhnydaDdzKbxc1f/fkc+g4K0QWgnvLtX29knRSMK4ceM+CO+WBOWuKpSQLxKxS8FPAu7vNI5z3nubEUOF42z9UeGtJe59IAitU3E3TZa4YyQ5Ci22qAL0TFBfvRLUH1TQ6xC6S4QuJmrLdnZWbRpamNsnA7xawYfKDIAuBe+G0MPi3LlE9MFohOB4kfgzpgQFv2MeULWKCIV1grYDtNJ7N4+ZT2fOeOfc7xf3Fi1HSFnE8YSJKu5bIrRdwQM+W0cQ8+BeVeGlzNk/sv5FjQ7z771zfwpxP1fwvpCioyG9adqnwi+J0C/g3e3wtEiYZ6mnmcz8aWY+23v/h5lM5sQ4jt8TRdGY4uZvjPcnZQoeF+jVCgdGd1B+W8T9u0h8+aRJk8YPN6djbKSZxHHU26mysGtFshcpaJX2jLaS0z0MTroVbJu8vRDerqDXFH49wM9B/MMAmUc1G8h9mog+7r37HLz7p0GQX1RA4X5dCtroPV1rM7Czs7P2npL3J35AxJ1pixbg5nkf/yVz7lNEmZMzmcxJNtLGjx///qRF0vuJE7ynuQDdp+BXbDOWZtqHqmaIrT38dgDbbnxrAP8awi8r/ObiZ0NwH9mmQitMuUUTWDMcB+Y/Y6aVEN4Mobfg3Zvw9IZ6WiPiHgTouzatAXcFc3w6EU1xzsFGiDKfzZy7zPvctYC7XYSfA2hfLRUQkmdKYQQPZZtB+ZCC/ktz/KmasS+SOQnCy1R4e/lRR4cKtl7ot4DbAOHnROiXpiBlulOF7oDQvbZHEOEtw6yAfO2E98PTD2umAHP7jDwFvzWYByzGf3Yp/FYF/6/Z6oJ5qDtxfkgE4C4ILa+ZAixiCXHLFLyn3p0NDSgK2uM9faVmCujZMfJlKgXPoe4dDg0mAD/jXObUqMYBqw+Lp4cUo8d0hCrFFnVze+HjeTUP2tlmRoguV9CmoLV1IcMIEQVvE6alxahpzeNELRZmFqGlZvPq3flQd/LpoAjdZe72cKZXWy1xIcxLVWkTwPsg9A6EDhbFdrnHxOxQ0H+r8rR65bbf45z7hPd0jQrdpt6tFnGPw9NTENoAob213umGOgrAOwC6RnX8+6NGQHt7+6QOIhHnTgO7KwF+QDwdleAYPcJvW/+y2ayLGg0WB/I+d57ZRvH0Zv3J8kMqhaAf+DlV97k0gchhhXlJyjwNRN8xM2QRw9GnANomkrs6hOEPQ5fD8QBcIb7uc88GsJme0Wj/uywcY+Y2agC0WPjVqgmY3Xz1/nGA93YEqTdJ+VoJhHZ6TzOHOCddOfEW84dzp3pPf6vKj1hwbSjyvqGhhfeLuDuy2WxbXdOL5uWo0EJ4floL1W18cLjJ0J7I4wEFHSjuO2p9P4v3/xuQ/Wi98sCtZC5mIdlSSLC/Wa8FFkIHYMkPoTtF6Dbx/Lglh2r5PACv8979ST02XCcY8fDuKvX8pPYsrlVlowp1Nur394yq9Bs17Ql67RDhpd5npvc+IGKEAL5SvXsiKO8plpAMnQMAv8sqJ6zqYliZj+N4ogjNUKFHVXh3lVPYSNmlws+K+BUK/ilAa9Mm59XIF96hwtcXq6j7ogXOfUjELdYK2k0hllN+ViT3sWEf/cy5LwK0qtqsVXGkb4KnbxPRKVa0673/CLz7QU9Rbqo23rKCLD9AwaxVVgP8RYh7cShMUoeVn3i6xYoNouFGwadXXlONyYER5/lJEZ51pPdgNZ7C7qaUCugG0zPMufPTLICFkLnwLBHeWfFgCb0ieVXkofIG1N+OEL4C4FIROS3+8DCVz9tIUtBjlXg5RRtvI343PK9WT3MsfN2n6Rbn3Ifgc48NZCoU3A2hN9XHf1Xp84vQ9xSFtabsevAu4ZpHSCXdULyIgO8AOKeWVdtjRfhLCr+hWMNflnwIvwPh9RD+PoguLGGrC66sBesCBq6IgFi8nb9nJYSVPrxz7lQR90TyAJIC6SkJLy+qr4rqwlrMjBYg64Lw1wD/fKmZYKMYwlvg+QEGf2GinzihXKPM7CG0KsXM6rYNngh9ZjAPb7tVgOZaG0fOgiEjvr/sMUUM9S651WofAb5Ahe6xEd6bD7ZNkAptVPADAM/33nOx/rIsrJjWygYHNGfquwB6yqoxBvvwRHSylbUXvLCCqUGtyD8songZwBnREMNynWOZs1N7Fjj6G5X48jgu1MuPqcAOjvHeXaFSCF0MtJ50gWlVlSHfFoAWAXIgDXmhsyN/wSfPz8+fPzd//fXX5m+++R8LYn/bZ/adXZNCCQcR8NVGPEswVohmK/j1VAqQ6hQwderUMaL4j3JkdZ48OT933uz8o488lN+1Y0s+37WvrOzc/pv86tUP5OfMnVX47QDrw+32DFED4TgrYlXwxnQKcL/oHGSph3UcAStLkTN5ysn5G765OP/6lo0Dkl5K7Lc2O8opQgIebiglEGWmBFCa05NdCnq6eECvUrRI0DtLkTLzkhn5TRteHDTxfWXD+ufzM2b+edmZ0DDmyDZkwu5HVkmRYiP3gh0hqvQeorogiQjtCPlly27OHzqwZ8jI7xVr85ZbbircI1kRhTWhIXC8SO6yYg5hADeUNjmXOa2SxqVDPoagh/oS0DG5M3/fvcuHnPi+smLFnYV7JS7MgIWz645WEH08KK8deAbQ2kwm49M2bD64BKxLGvn33ntXzcnvlQcfvDtxJohifRpXveaw8ESA/3m5gJmCu8S7xyupt0TAoqTpf+utS4aN/F4xc5TsouqCqN7oOcZEtyl8yd2wgg+J0D+nzUBNmTJlnATs7dvhSy69ONHm7975ev5flv+kIPZ3pQQP9Hu7Z4mFefewBfRKwZL5QO7GUtFQtSCcp7Ui8R+kbRMB1yW5mknejhF21jlnHb5u+lnT86/86qXU5Nu19pve31tbSUow7yjJRa37LDA7aFm2oH5fqQioiFtWQe1NK4Ju7dvRG25YlEjg8uU/7kfKmdPPTKUEu8au7ft7azPp+q9//doEtxSba/3ui4Ew1nt3CdD/vJmaApB7RiT3x2kbQ/BXJe1wS22ykhSQRgmlyC+ngC2/2Zg4C1T17KiOaCmcnBR+oqO/Ag6IuL9P6y0EnzsP6rf37eC8eXPK2u8jTUgaJZQj39oqt47MmfOlpB3ysqie8FF0gqd4LuD+58hiLnj3k7QhXTt0raAXC9mrPh202M5gTInJtDOm5Teuf2FQ1ybJqlX3Jyng+ajesIPfwc6debpNxK1QyS3MRNF70/3Ws71KRpUP9u2cRSzTBNbSEFst+SY7fvta0r6guyFe+mFH/O0MsqUpVTV1rT2IPqqgDRp8d19iLrzogoo8mlIE2+flvqvEczr/wvP6twPU9lBfhWit8B0/MxT8RlDppwCL3aclZiAlVDPyj1oH5s7q145XnRmNUIzxPp5jb7RSRT8FfOMb11VETiVKGAz5pdxRCeHL0UiFiDu38NKPBAUsXfqtiglKo4RKzc5AoQkJ4WvRSIUqnaLCa5BggmqlgMGO/lGpAOccel4T4/vley1LNRJMEALmRyMVbW1t7+vZTcsLlWzCGmkRlhAujkYyJkyY8Dsi/OW+HbPqhUZzQ8+74BMN74YOChbaLZQLNvBGbPu2VxM3YvV4O3BNgEKt5tHkPLL6warJH8y1SbJy5X0J5kfXRKMFsELZPh20Wp9GCcbNnn1lfwWo3hqNFgA4p2HD0a9tSAxH+xAOn/IZDWi1KuW07uhwJmQWLV6QMPrxSr0TMkMOUV2YlJK0tGC9UpLr160pUaKi/xCNNsQ93tCevp21xHi9kvJfmPH5/uZKdVdDhKFrASlREWdhgEoJrlaWLPlmw1fI1Sa3EJILs+65545hI9/ulUS+FWbV+zUHNQeAM3rq84/uvNliKxusNfl3331HqdLEAxzC6dGxAAR8NWkE2kwwc1Sr4twlS24sYXYKC+/V0TGEFisJL0WGLcxJ3tFgxbydxAX3Xbv/o4YpTx8uTLXTMQEPlyLFNkcWIra6ncESb5us6xYtSDQ5h0d+0IemT5/e+P/ooRaYaqdkysyEXkVY3c7PfnZ/oXphINLtGiszsfBCOeJ7R/4xS/4RaLE1IWlhTlojLGxscaTFixcePqRnM8U+s+9KH8A4esEt2vxjy+yk8I5eHoi8akWCvnTMeDuVonCAo2eztnvIyVfdZTNtWP6VyWgIW4gpQrG5euKx2WI7oza8UGO0qupZVihrtZp9M2slpNuSKRbPL4aUR1dUs56wUWx5WlW9xCoWEHBNUeZZFZuqnjJq0ohNNNFEE1E//D+p23boIkYVDwAAAABJRU5ErkJggg==",
	research: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAMbElEQVR4nO1da0xU2R2/235okz6+9EObdtsmbbdN288WYrLdxkS5I6tmteJud43OrN4L87iXxyDjC1RcRlYUEEXFFwwovtCKI4goguCMoMACDuKq3fWB21TUJu1udt2kp/kfmOHcc+8MwzIz9w7ef/JPbua+zvmdc//vc4ZhdNJJJ5100kknnXSKU3pT4H6RJPLvsAKfz4rcMVbge1mBu8eK3DNW4L/CjI+5ewaR6xm7Jh/umZOZ9nO12x93tHjx4m+zNm4OK3AVBpG/axB5NCUWuDsGkd9rEPjZeXl531K7f5qe6azIFbIC92jKoAdh/GyB36J/GQQlp6f9yiDwpQaR+zJawCvwC1bkXEli6u+Yl5VYm+2HBoEvNgjc16HASs5MQ8sL85D90E606XQ1Km6tR3s6m9HBj64gl8+DGY7hNzi38XQ1vnbZljx87wTi6WtW4LfNzzb9gHmZKEnkFhpEbjgYMPOzrci6uwhtvXgKVQ1cRTW3rn0jrhroQFsv1CFr+VY0z24NKZpYgX+Lme70xrJl3zUIfHkwIJbkrcKzfCqghxoM+DpScleFGAh+J2uzfYeZrkrWIHI9Sh1fvN6OCs4eRTWD3pAgVvo8aG9fKyrrvoRKbzSj4usXMMMx/Abn4JqQgzHoRZvP1uJ3KoslvnvaKemk9BV/NIj8QyX5nu3aHXTGV/k8GFin143WtZ5EOZeOhcVrW0+iLR43Kuu+iJ+h/EVcRdmucmU9IXAPWBv/B2Y60FyRSzAI/FO6kym52ais45wiOBV9bcjpcSNHy/GwQQ/Gq1uO42fBM5XetaO9AaUofQ0C/3ROBv8nJu5nviAHny91osr+dkXgN3WcCQrm+rY6tL2zEVX2X0G1Pi86MdSJGY7hNzgH1wS7P7/jDKrolw/Eob52xJcUKIgkbiRuvwTWtuJVVuTv050SK0pksh7ERKH3HHIogLbtWiM6d7cX9T/5FH32+VP0zy+ehWS4Bq513+nB98oGouU42uI9J9MV1YNelHFgh6KFNNds/iUTd9aOKFe4q1y7ZbMPFCct39e0nECugQ7ke/pgQsAnYngGPAueSb4D3rn3I/nXAHpBNggidyOurCMlU1OsKJZ1tvR6s2zW7+9tRR8/fzxl4Gn++Pkw2td7WfIueDdYUHS70g+UKllIO5j4cbLkMp8UO9W3rqFtneclYGxoO408w7cjDjzN8A54l0TMdTXiNpGmKqegE+ba+AWMlglcejqYlrLejpUcOcNo8Eu7mtDdf38WdfD9DO8q6TovGwSJz9Hfjh1DahAevmE2f5/RKuHYDmXnl1GmZsmNZknH9/a0oEf/HYkZ+H5+9J8R/G7JRKDE0Y4r51Byhpm2jLYyWiRD5orf0oG1bErpgsIlZT4A8DgMyyZaPPy5dBCgbbRitlfJlPIL1sb9mtEasSJ/kGzoX9dl4vgLaWqCh0qKHTVmvtKXUEKIxHWtdRITFTxmOmwBySJGe3Ee/gXZyAKI7RAzCWxvUuHGUuaHoxNIxQw+Cdn2zWeP0EG7rzQVL4IsEx3VrCGsHvBwSdETC2tnsnx1+LbEWdtHeMzVPi8OnVCiyMloJodLWT4QUq4hZhAZXtjfe1l1sINxRc9lSdiC7MOG0y5ZwE4TOWZIoNPJFFL2V/S1jQfGLp+IipMVKb79bFjiMZNxo8qBdjTfbpEOQnrqLLXxZ8aqFwKNgkwWOXOcHnegQ66BdtVBnoirBtoD7S3wuCV9Me/aSkdMy9XGn6FLR4qaT41bEIMeHA72dygSsZ1o882RB5JQNuSc/f35sOkkrYxva8H6kTheZHKlrPuSJKqpNrjhMhlFLeu5JElr0o4ZRH1VGwCDwP2NbAxUL0hNT3egIxBSVhvYcPnsnZ5Au50eqUm6zJlLfQWpb6s2AKzIbyIbA+UgZGPXEo4XxOjVBjZc7nvyicQxI/uUdWgnbY5uUHEAuGNkYzb+vWbcarjpkWSywkmmaIUhPELmKCp9V0OZo0dUGwA66VJyuV4S98kZ60BxZ/zIfyU9QOaTt7eckSVr1BsAgfuEbMzernGFVdZ9cXwG9V9RHdDJ8kHCfyEVMVTgUSLoHyoOgDThfoCIJJYQYeejPq/qgE6Wa30exTD1gd5W2hR9otoAQFCKbIyLkJXFXU2BDtTd7lId0Mly3VBXoP3brzeNm6I3PXR+4Et9AL54SQdgOougI/EggkIp4Z09uhKOwQDw3eGYodunsxkq8NcZrThiZB6gcpo6Yhu15IhN21DEvz6Nj1AEHYyDZUGSXIB3PBgHtZpqAxsu19/pDrQbctmSYNwWDQXjIDEtCUdnmCXZsDLCG46rcLS3IdDund0aDkcDja3DDTQI1mSRpSiriYQMJDvUBnciHhi5P14nBAkZorigkErIGARuSFXw8QDAImiiUZYQKcmqeEhJ9o+nJJ0TpSRFbpfa+IMpOjvcpPyaFkjKD6sOcjAeevZI8sXumyApnyTyf1EbfwZKM+j1XxtDlqW0qg50MK4gyhTpshTa/ITFJ5ooSwGCIiWycbAUtNonLcyCYidtF2YNSQqzKvquSAuz5OWJBYxWCKwhOjL6gbs2aGliXtspdEdD9UGy0sRrDZK259cfkQXgVLd+aDKI3H6ykYvWZmG5GZChPo/Eu4T6fCiMVRt8aEMxVZwL5TSk6bl4XRZt/exhtEZzMsy/kZenl0tmEpR+0+XpUCKuFvjw7j1E6YzjEogeqjy9chft+b6ADUYYLdIcG7dH4phlpuF1uGSHSpUWaKjwJcA7SfBx2LmbXqDhljteIlfIaJEShPd/PNNqHEwSOEmDU9bb0UFCoQHDciCy4yCOYrpE6fljidjBnnrXedkSJdm+EgL3QJNLlGaYl/0kwWK6lWg1oddtK+hPFsEiaNkiPWoQQAlCiXi0we94NISNAAn4nVLwwepZWSxbpPe/JDF1PqNl8IHfKspFS4s3yQZBUFqmekO+TBVKxKFKORpOFmnnj8p8udgBztivsExV4EuZeADf0XwU5VyoRYty5fsv0ErZ7yOA5UECA94ohC0gLjNV4CH+BM8iPVy/taO0f0R2lUzp4qSL5hZqg8xPtBpvkuDnXDyGHGOc5XahBatFpLhgm9qqAExUWBZEOmsB8eBtwKFsiNGHs6AProFrIaRcREQ1SScL3kWamn6xA22TzXyRfwhFyEw8ge/n9NMH0ZsKO1XBImhaMQND7CW/vV4Omj+z1noSh7UP9bXhpLl/sw44hkIqOBdqWxu8WYfCe6EtCjIfb9YxV0z7PRMPYocG3zHGwsl9ioOQkmvH63BpMLBY6m/DiyNosTGV7WrIwBptaipv3sSNsMLKGUw8g+8gvoQFOYKsk2BjwzpcMnpKMiyOgLJAKBGfzIZNIN/hHkimkAssJGJvoB07WfKF2KOBtrif+Q6KM90utDBPeZswWFO8uf6wJICnCJrvKlackGmTb1l2EZ8LtkMWKeshtgOhEqW2jCpcjcV5lGT+ZMB3jDFYR0tL8hU7PiqWsnH5NxlDihTDMyGkrLg71pidD6am5qydqc58hwKba3ah+Q65hRRI6tgtyFJehNdkTWUw4F5II5p3fShf4Uh5uHHjZClZO9+EsxsPo3nrM4ODQugJqESAchD4OqAwCkrEoQwSioGB4Rh+g3NwDVwL9yRnpIWzg27h7Kz3vse8TOA7mo+iRdvy8HNnWt9Hs2wrn8Vy6+KxHdddyQL/GqNFCtfOnyr4iVYTSrAYh2ZaTD/Fe8wJXAGIg6gBL/L3WZH/QHNKVm3wGTrHnJ46C297JnBDEQD+FlQvQAJdMzlcrYKvRKNfRurbUAJoELlabCbCnzUI/FP/HziMHnP34BxcM3btkuQM/mdMvJAWwX9pSAdfRdLBV5F08FWkGZalP0q0GgdjI/NNt8CvULO/WqNXEi2mBj9AC4vyphxeIMGHwUzUwQ9OCdblS/wAzXOuiejMl4Jv1K0dxQGwGHsAoD/b05C98bA+82NJCcLy1/wz9J1ypw5+rCnBanzPPwDWuv26zI81JViNDv8AZDcd0T3cWFOCxZQTkQHQwwsqiiDd1FRRCevgq2iG6uBHhhLNxpRJO2K6kxW9UMQ852pkPx/8S4BzMFB6eCHCwbgEq6nfD+rrWWlYJ4BiXtVcixmO4Tc4578OAnh6YC2SEVHiS5iQLaYGuCdS79dplF4BneBXzEqMz5mNKXCtDlq0TVSb6d1Eq3EVZpvpXfgtmu/USSeddNKJiQb9H917NyXLjKg1AAAAAElFTkSuQmCC",
	storage: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAMUElEQVR4nO1da2wcVxWeAKGABKIUhMRPJP7wCBUIBEIqFRICJCTgR9LdTZOd2RlvHrYTO3HiPJsHCXGIE8fvdf3YOPauZ9aesb0zdpK6rfMsaYhjF+pHGgfqxBBHSM2j6ZamNBeda693ZvZ1x/bueO35pCNb6/HMOd+9c8695957lqIsWLBgwYIFCxYsWLBgwYIFCxYs6PFbt/sLDs75rI1j/mBnGcbO0jkOji4Egd/hM/gbXLM8f/nno25gwRCW2NjVy+xZ9EY7S3faOPpdO8c8sXMMIpQn8D82lumAezjc9PfgnlYbJIGDc/7QztGldo6eMEA2qdyxs3TJCjf9A6shVFi+fPlnHRzD2lnm7UQEOrJciMldh7IL8tDG7QUof2ch2rx7Oxb4HT5bX5CPr4FrEzcG/Xebi3bBsxdtY/w6N/cpG8tssHPMrVgkrV6XhXK2bka7DuxFh8uKUenLFaiMUODaw6XFaOeBPSi3cBNavdYduyFYZgzix6JriBdY5/M2jh7UE7Iyi0U5WzehfYcPGCKcRA4eK0Ibd2xBK9dwUQ1hY5l37Bz9K2qhY9WqVc/YOYaP7u1utG3fbnS8unROSY8l8IzCfbvxGxbjrfAtZ9mvUAsRDtb5M727WbUmC+3440vouKeMiDyPtwZ5/Q2oOXAS+duakCD5sMDvzYFG/De4hqghasrQ9v0voVX6NwLcksv1U2oh4QUXXWBn6Y/VAXXDtgJ0tKokIUl1TbWY4K4zEjp7oRudv3SaSODa7lck/L91TXUJn1FcWYI2bNusCdw2ln5sY5l8KtOxZ8+eT00OK1W9fm0W2vfng3EJqW6oRoF2P3qlVyYmPJnAveCecO94zwWdQDft20CXgA1UJsLtdi8Fn6o2yJ2Xi4orYvd6j7cGtSsCOnfxVFwi33jzVdQ/cBENDf8VjVzvQ+/c6McCv8Nn1wYu4mvi/T/cW5IDyOP1xNThSMUxrKM+LoAtVIZhiZ1jTqgNyd6SH9PXV9RVotaOlpjEX/pLDxoavoJu3x5GD+6No9Cju0Ty4N5t/D+DQ1fwPWI1RKDDj58dNYT1lOOhq26U1JJRb4Kdo4+pDcjfuTVmj2torkOvno12Ndf6L6Dx8evo0cMJYtLjyaOHd9D4+Ai6NnAh6jk9vTKqb46OEaU15Wjzrm36RqikMibgasgvjEk+3+6L6vVA/N2Jm7MmPZ5MTNxEfbqGAB14sTmmjvk7CrWNwDF51HyDJAd+LCpCPkjR8SMMjCDCCsNMNsrl1Faizu5WrW+/3INu3RpKGfFamUC3xobQpcta1xTsasW66fWFiaEqKH986NghLmwv2G4a8d3dTV+SFKFLUgSklqr6CjzJgWAG/lRLfhUeHqoN7x+4iH12esiPyP17t3HQVusCw13QUTtfKEfuvBxsE9imtxc4AC7S3gCiLMgxlJlqhMqo0Q70Lj35I9evoQ/en72fn6nAs0dG+mI0QmXU6AhsimcvcJFW8tsU/rl4yoSl5kRkqFdeW4GCp7Ru5+bNv5lGvF5Gb74V5Y7UDQC2JLMXOElbA0gy70umkNfXMG0AzEjnK/mhOI2gDsxgSzJ7gZO0kB8M+r4qyvx/SRsAhprq0Q5MmswmOxRH1O4IdA4PUUkaADgBblLeAFIwsClpb1AE5DnhwRMd9TgfAq6ZPj+UREA3GAqr5wnltZXYFhKbgZuUN4Ao84PJFBE6/LjnwAxXPdQ0Y7QTMij337utGaLCjBm70XYfyVswghBK3dpzu9zyPElPgFcWeo3a9aRvnH931gLzBLUrgjxVg7+e9C34ecoaQJR5f9JeoPCooq4KJ9bUM1yzSQ0ZkgnUN3B+Wn9JFrBN8NO0YCxJ0jOSLHyYTAFfoBFVN2h7fyrTC6EUycTEqOYtqPJWo+bWkwRvAf9RoDvwtTlvgDaZ30zyCtacqMH+Mqw85F7MJjM0Q1EHZBhKg22mBWMjwRdGD2HFIatpNpGhGQpkUacXdV4PmheMjQRfWEZU5/MhHWw2kaEZCuiuXk+oPVlrTjA2EnzVs15YTDGbxNAsBRZ11G4o7cHYSPCFVxSSWWGFYVXKbAJDs5Rbt4Y1iTqwMa3B2EjwBeXUuxcyYeIVIpiYhe3pvXBqKjmXxmBsJPjC8FO9gG42eaE5EpjFh+3yeKvTF4yNBF+ctPI3aPI+ZhMXSsFwtMFXP5lkTEcwNhJ8sW8MNE4rCsHLbOJCKQjEYOPkbo4UB2OjwRekpa05I9LOoVmkqWEbZNjelAZjo8FXv/ByY7TfdOJCcyQ3Rgc0Q9HISlmKgjEEDknhh5P2/taTmqW7xdYAZS9XYA4I3oJhQ8GYNPgWVxzTKLPYXFAZ3tx7dO6DMcmaL8iew/s1yiymIFw2JXuK9pM1AGkwrrlas1RU+IckN21ubdRs4VhMw9Cyqa02wAEJV8ApcEvUCKIiFBK1Km6ESBxYDBOx6gaPwVFQuAGEQmIXBDuBJUXoIb05ZEDDSi2GVETZ1OERcvL5s4FA4NOUEXR2+r8uKsIE0QNkHlVN9YyFl4wbmrZHOT2ZjKuqr0ZtQZ605/+no8P/DWomkLpafiPK/BOSB8Fu57Ja7VB0IQTiwaE3I5u1JB/epsJLzWTkY+5afjcj8qcbQeYrSF+1Rt6Lz2Qt5AWZE7zXiOspp2aL7u7upyRFGCB96MuNNZrzXbCsZzaRoRnKbd2SpKeRcOaLhX87EAjMTdGQju7At0WF/4Dkwa2dLSjQHtmQBds7zCYyNBeL8u0+1NrpJyNfFj5s7fQvo+YSkhxYR9r6LWKTZlsKnEwxm8yQQblzJ7It5eyFU8hP6PexBIW1VCogKkI7sRJyQLc1Zf7uCQ1FyQTq69duzCK3m1dStj1RUXxPSwo/RvgaotfOKZGtiWOZszVx7N3Bab1fO9eFh9mEfn8c0vhU6g9n8P8jVAiduxjZnAvHgswmN5RE7r83ji5djpw1Fsl7/ydiV+AXVDogKsKfSF9J+YwY2SOaCdvTByKBVz4tGhn1HKTShd7e3s+ICv8GqXI9vcFImnpk/qaph0euTusJ5xrIyReuECfa5gptSts3RVl4QKKgqAiaHBEcBzKb7JBORkcjR5RAV5G857/fJrd9izIDosyvJO0l7UpkVDTfGmFUdz5MUgLEvR84oMyEpAiNpMoqp9s0ho6M9Jl+TFXtdrDfP9VmxPU0Umajo6Pji6LC3yBR+ITfq8mWnp86vAEpXzNGO/r6EZDtBB3J3Cp/A2yn5gPEIP8jSRYek2zgmixVoH0TLkGpAjxPSMfbMIHGxgY1Q02Qjq5WnOkkO5IqPAabqfkEklU09eFtSO2e0xXrgNknnExJZXpBPcONVayD5FC2odWtdAFW0URFOBNPaf1uApD65jrNYQ516gKyqHORyoZ7QFZTTzxIz+tBVK9azZveatLWlIj8M/O2dlCiAh5QWDVWwaby2kp8FDRewSZY1IGVNSOzaIgpiQo2QXJN6JhcXNHrA8U58nZsmV+FOYwCyri0BlsKDh0v6svekqcqWZaDC1/Eqs3j8dbg/FGykmUQtIFYGEFNlywb6cOfQVBVL6DHIh7yOuqFdW1RjqMoKy9bVeUrDxWVHr4KtphammYWWAKF77RF+zi0N0HRvipvNV7WhAWQeEQaFbgXLJmG161jyd7DB3AZTV2J4+IFUfQbKk2pCzmB5BZuRkcrE5etrFWVrYQdCaSEw7XwPxDo605G+3jNzraKkqgacXaO+cjGOXOphYSVnPMnU2Xopw19cQ2Htu/fjUoIC7dWez2owQeFWxtjFm6Fv8E1JPeCZ0K13qhSxizzTzvLZqS7SQrHOsfTNpZu1n8XwOq1ULp4V1pKF5fg0sW7YpUuBp1OOp3OL1MLHQ6X67lY5epXpqF494tuNlYV9es2lv4ltZiAC7tm0ev1bklbvn4T2gHl60uLcSlJUrLh2qLSI7h8PdwjqiJupETxP+wsvSYTC7POGdxu91IH56LtHP1Woi9dcHAMcuWsQ+sL8nDdaahFGvkCh634M/gbk70WX5voXvAsG0s7FzXxseDgnM9C0VcbS/87MYEzEfpfNpY5uoJhvm+2nZmAJStcru/CN2zYOKYdRiY2lv6ElGy4dsq9SDCctHGrv2O2QRkPp9P5OfzNSi7n78F92DgmO/w1VvA7fDb5t9XL4Fqz9bVgwYIFCxYsWLBgwYIFCxYsWLBgwQI1v/B/czIycvFVEswAAAAASUVORK5CYII=",
	upgrade: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAKKElEQVR4nO1dCawdZRUeRUTFuGDwBXl9985ZvnPmdqHxIWCBUiqLW1hCKi5RcU2DMQECxpgoEXADoWwlIoIYaZRNG0CwKItAiiAoiywuIGUrFAq0ssnSmjP33vfuK6Cl+v65cOdLTjqdO+/e//+/+f+ZOec7Z7KsRo0Xx7yNWi2dmeeY4U7TuMWSrSdawyxmtLUWOpuZd242m7PFZTuRbJP1/Y6BxOjo6MZEpO6yk1n+CYd8A5BDTflrZnxwAd7XlT5qJvNcaW9V2hvgPWM7zCTfx0z2cfBBZnyYGS8wpYUQOh7gI83ks2a8s2qjEJGajF7EgDDzLAOd4MY3Gvh+N15l4H8a+BEDP2zgle1/5UE3vseM7jHwstguDXyfQZab8UMOXm3gZ91krSGM/+XGDxnkz1A+1UV2Gxoa2nRCIwYZLWYxlRMN/FirwNrCdW3hsrYw6Wy/TDNZ6+tY7I/vNsjjqvRzVd2q6n73Daw8+/mPMUDrDtz/21qFxoy4A+B9syx7TdV97wuY5PMc/I84SyebgPgNgzxgyt/0kZEtskHH8PDwZmrNQ6B8X0oCHHLotDwfygYdjUbjbUB+IJCOADe504Tmt1qbvzkbdAwPD78RyD+XcgmC8c0Aza26730Dd9nNje9MtwTx1QBtX3W/+wYAvz8VAaWpXOoi21Xd774BQB9ItQR1CLisJqAHNQGDRgDk1+Gwq7rffQMz3t2M/56EAPAagM5Tbcysut99A5fmbgb6W5oZwE87+GzVZu0LqoIAgzzlyosK5qljDRh0eMoZAF4dLmmg4VX3e0CXIHnMwSd7nqPqfg8cAUX7KXilKZ3IvP5hzlc9PDEBDj5OVanqfvcNvCZgUAiQuAt6NMKf9RJU2UWYVhnoh2ZmvW0YaHjaB7E2Ac1mTUAXAL3PlG9LdBF+1J2Ory/CPQjBlEFuTkTAclM+TFW37G1DNugEOOSmRAQsU+WDRWTzqvvdNwBG5jr49jQE0N2mdIjMrAko0cparzel/QC+K9Ft6IOm9B3md01pt2DAISLDpvkCgzwymYPfNYM8H/EA5im1N7TRaLzBuLmHKf82xeCPLUMW0kQ6YHSU3poNsBR9BGjsZaCfGPiBVOHIzoX4GTO+FpD93XOENqm3fSJbDgMjueoImTWaXYv/xxN0uLJFRlpONM2Mpkdwx5lHw8rcBM23iaA/QDuE/CX+H8e1iEYi9+EFAzIvm7dRLAXuPFrEPbnxHqG9L5Q+6CK7hojJjOcU2pzd+dIdCtXYnttr3WMKzXdUzXeMHzfjWdEAIH9PJErEPlf6mBl/rzzzQSvcZE2qGdAloR0Zk5uA/DRV/mL5MFiGRunjkPxwUzrGlBc46Ptdg/KxAJ2gSqdA6dQ4eRy0yFTOhPJ5YQa+AOAlDrnMIEsNdLWBLwf4bAgdEfHvGTNmbDpBm29kWwN8uBtf4uCbIkBu4LsM8tfQ1Bv4hlAvO/gPZnxNmEOu6+zvMbk+jukcd62Bfw/QUgNfEY0w46vKz8C3AnK/gZ9LFoh/SeNVnf7+JayzvbyTk/Bw5BV0rZOjsNLiaXo8f+EJAz8dfQlz4+e7JPeamTzX+d7fuNKnReQtJQExBU35JDNesUFa/P/BvNKBnzgjXm7+QbGhy5/JM3FSAs2PZNOnT387wJ80yLJ+GhB/FVupTVVebUqnZJFvBfCPU6/Bg25FnOzKl2Tu/AUDn58iM6U2mUCAgZbGDJjfJqBefjz1DDC+KnPlTzn4nHoGSNoZGjNA6aKsYN7TlH4UPpJ6iZBkY2AmTwB8elY+dCkd7SZP1gRIsuWnfL4AHxt++Dmm/F0Dr6pngaQkYDmEj2xHomoC1qac/R1n4IMAHZUVmu8SPo54pK6XIElGQOnWUF5QE2AVE+AuHwbo+HAo1TNAUl4DVkZhkshO3AvgH4R/vCZA0hKgvDCLGjxQPq3tRk0/HX3QCQi/tIMXVd0oHzxH3EOx9GehRnDwGbU3VFLPgOUQOiozo890CCijOLVJIgLk7ohAZg7+vJucVQ+8pJ4B9wJ0ROaQA93kwjoaJgkJKLVJK5VpYRZR+giW1wRI0uXXIGtM6ZdZPI2FdKImQKrwB12edbQ5V9YESHoCQFfHNeAAAy+pQ5JSwTJES7JCdZdwR4dMYlBnQZFQ9zQm0gLf6+AjsxlDQ5uWckOlcyJMNl409T9bzJi2obQXfo4Jn71UQ7zigY/KKW4hjeQ7Q61XqgCVb4u6omUeAXhZx+4KG1cMdvbH37X/9o6OtY8zvtdAKwz8ZKix46Lr4Kfa1X3p+hDCqersMWliJEio0okhlTDwLQDfHilDBr4m7pJC59ixSw18salc5ODzzGixgX9hJmdNMPC5sR/gcwE+I0RIHU3lQgifDtXzDfynyFhMHYnr/N5TCCmiRntpftSrjgFR1R1dZKfIWXPJd+1axE16rbs/juu1sc899LT5/lGbNOpWq9LRAH3blA8O/elUEZ4gCB4dzTZuq4FDREtzVfNdymgZ86wQ7HaVv8787ij5a0TTRaQVKmGzphUFaa/FvrDcc0QyXKiCVYe37KqO0YBH5dpS3FqeRSmfxPl5U74xlNHR1pDIT44CfIs3ufs7IhUqz/MhInpnqzW8Wd9U6xWRTZz5veETMZO7UyxJPUl6JxVEWvUY9ANeS6DtY6mKaueJkvRuCEnmZJ35rzhIyOOF5hvonskmoBXCWPDlLdW6XFkvIuHDwDcnIuACcpo2oQGDDjOeFQkdSZYgo8Vc1OXKJqBMWwJfl4IAgM6vCVgHxjzHwbckughfXFdMXJcAkyQvcOgQ8DujumjrGNx9i3iZQvhHkhCgcpWqbjPeggGHiAx3AkMPJCLgypqAdQkAfSucYsmWoLpu9Diibo9qHhL5lSkICIdi+LTSz/U+RdFsNqD5sZH4vCG5txswA5bU7xDrgcgUduGTw3c+mYM/fg3gC6NuQ3WnXJ/BwnWt9NP26wYnn4DaFbEOCuappnRmCoFwewbQ4ohlVHO69SGKmoA+IAD8sxRLUFiES1v1DJhIQLxQoXyxQk1AejjRNFeOi/DjSa4B4F/Vd0EVLUHFmDe0joiNIc5GMzqr+wbsBARcUbsieqDa3MpMFidMjlhaqG7b24aBhmpjphknyVHoEHA9gB2q7nffwEP4ZXJJQl3QLWw8p+p+9w0K1W1jXU5IwK2qjf02b7XqlzkHyqKmiXIUujNAlT5U/niNLAPyGZGuY5j8i3DLETm617rX7xIeAzNPgdDXQ9bdlrOvz5n833T9LzL4BUKSshrgU1UbxXgLarwu7stN+Zio2ttOFunJISizCqOWRcQLQm8f1Wrl0QhhmpZVR0oL7X1bf88ryrqckDU9CRHPtnNzaVHIyEMOWQ97D9o5CsglNPdCX4kyap18hRNCX2/Gh8UsKQ3yVYAPcvCXYi3vWueVuLvH69FN+csQPtyMFwB8XGxHYZKpqkUtyq2RdfFvRyiI4BwxchIAAAAASUVORK5CYII=",
	vp: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAACXBIWXMAAAPoAAAD6AG1e1JrAAAgAElEQVR4nOS9B3SU55kv7mT3v3vLlhTbGGzTO0gC1WnfN1/vdUZT1HsvNBuwjS3cseNug02vAiHUu4SEGkUIUUTvIAlEdezESRzbsZ7/eQc715vd3JNkk5C9+57znNEIzozm+b1PL/PAA/81zvcQAcD3ioqKvv/N88ApKir6XwsW5E7OzMu0ZmenY3mBx2xLbm6mo6Age25BQcG/fPc17t9H+K95vvf7mFZUVPT38+fnzkpOjsv1eV3vetzGumiXvj46Wl/vdhtrPR7Xyrg43/KMjCT/vHlZ47/zen/14/F4/u6B/2pML7p30xGjv780J+eHC3NyHi8oyJyUnZ06OysrmY2P9xe6TXULz1O9NI2dpynsPE3jZyjaeR4RyxCnRJHrNAy5zO93v5qenswXFWX+r/vxgf6rAPC93/3F6tWZ/19eXmp4SoovLS5OX+7zySsNg98liM6DNGkbdNgjPrPbI7602yM+xzDLJxhuvYPhlp/aHVGfoUcn4bhGkvZBhiFPGKZckpqR5C4qKvofv+/9/ruql+9995cFBQX/uHBhzuM5OckR6SneRJ9XflfTyFpesPVQTNQ53Bl612YP+Y3VGgxWSwjYbKFfY1jEz3HCdoMg7UM4Yb2B4Za7GG65gzttN+245WcOzPIzmsHPejza6vTsZOy/K/O/q1q+97v6vOCpgofSsuLZuDjXUo9bXKdpVKMg2HsYOvICSYUOEcScGzgRcgfDgz/BnXN+iuOhP3U6w2+TpGWIYeznGNbZf4+wUxRjP4eIpO3nnYTtGkZYbhGU45Ks8Y0JCb6lhYXZs/87gfD7jOg/LFq06OH8/PyQ5PQE3R8fvUw1+AqGcZzFsLCf2WxzvrI5gr50YCG/wJxz7hLknGGSmjtA0+HnWS6ynxOshwXRsV+U8G5JcnZIEtkuSVSHIJF7ecHZc4/wgwyLHaNZ+ymadZwUJarb5VLXp6XE5+Tn50944L+Bavkt8+fNm/cDZEQzM5FOTxTjE305vhj3K7pH3SDqQh0rkr1OyjZod0T8wmqb+xuLPeQrOz7n5zgZdp1iI84zbORJlos8zvFRRwTRul+UHF2SjLfKirNFUYgWWSF2izKxR5LwblHEDogitl8QHft43t7LcfajLGvr5zj8sKpydTEx7teys1OUpUtzfvjA/8vuIvLbCwsLR2VnJ1NJSf48r9d4y+VSdskK18bxxFGCdlzBCNtNu9Ny105Y7mCE5aaTsFwnSMsAwVgu0bz1GCc59gsy3ilJWLsk2Tsk2d4hIpIc7bKM7blHzj3o30UR6xIErEfgHX0Cbz8kCtYegbcc4jjbEZa1HeM47Kgs021ut7Y6JSU+LS8vMzwvL+/HDzwA3/t/hulFRfB9pF7ynnxyTEZGohgbH/2U261ukFWumWGdxwjSPojh1o/tWMSvLLawr6328C/tWMQvMCLqFkE7LjIcdpwR8D5WdPZyEtYtKESbqBLNskK0SLKzFZGs4LsDt192fgMA9g0Aji5JdBwQeOshkbf0ioKlR+KjekUu8ojAWo/xnOOIJNEdhiEXxyf6lqRnJZqFhRkR3wnW/ubPv1MtyGvJy8sbk5mXHJSTk+BMTvP5YhPNJ9xeZZWsMLsR00nGcQl5KE7Cfg0nbMO403brnqcSdZcgLDdIynqZYewnOB7v4wS8hxPxA6yI9bKio5eXnHsFydnFy84ORKJEtEsy0SbJZKskEe2i6OwUJSwgDZKEdciCfZ/M23pk3toj85YDEh/ZK7IRxzg26iTH2vtFkezWNKnS63f9JCUlNjM/P4NZtCj74e98vr/J82+YjjyZJUuW/Gt2YfZsdIsSkqIXefzKO7qL2SEozjaKtx3HyajrNiz8MxsW8UsHHvUpcglJynGZZvAzLIudZlj8JMNiJ1nWcZzjHEd5pDok515ewrvvAYAfZAXsECc69yMABJncI8hUmyRTbaJM7hElsl0Uic7vAhAg0dEtC/b9smDdLwuW/ZIQeVDgIo9yXNQJnnUcE0WyS9OEKq/XeDchyT8/KytNys3NfeQ7n/Nvl/kLFiz4nwUFWTNT0hPNmETP0x6vtkozuXJ0M2nWespJRQxgRNhNOxl+x0aE37HjEZ84nFF3nZR1gGSwczSDn2BZ5zGOw49ynOMwx9kPB3QzaznJsdZ+ZDAF0b6PF20HOMlxgBPsCJQuUaF2SypbL2tsraKy9YJMtwki1SnIVCcCQwhIBN4qyXgbkgIJGWjR3iWL1m5ZjNon8lG9LG85gt6Tl8huWeXqUEwQl+BbmpWVYi5a9LfrEQUYn5mJItLMoKTUhAyPR18ly1wrw+EnSMZ6CSejbjicYXdt2Nxf2PA5n9mJsNsYE3GVYK2nKB47xnD4YVYkDrAisU8Qyf08jx/ieayP5219HGc9zCHvhg6/wDFh53g24jjPRx7h+MijDB91jBVshxEAskI1KhpXpehiuaIL1aLM7hYktp2TmHZeploRiQq5W5SdraLs3CNKeDuSCkmydyESJNveAKA81suJ5H5Z4Rtd0er6mDjPc8mZCbELFuQFoVjkgb9F5j/5ZOo/Z2Ul616f8a6scLsZxnkKqRMHFvWpAw//xIGHfWrH536KOUN/ihFht5x0xGWSt5ygRXsPKxFdnEK2Cwq9R5DIduSjCwJ+EHklHBvZz3MRx3ku7ITIhJ6Q2LB+iQ89JvJzj7FMyBmGDrnAMBFnUDAW0PkK3YQYJyKS+WZB4VsEhdvNy2wrrzBt3wIhKET7PXuBdwiyo1NUsHZEguzsRPaFFYiDksS0mYZcjHJEKSkxObm5mTiS7u9+7r+J015U9PdpaQkew5AqKRq7iBjvJBzXnYRtmCCtAyRluUTRkRcpOuI8zVpOMpz1OC1YDzOivZeR8X2cjHdwCtHOSWQ3kgJOwPt4zn6EYyNOc9TcSyIdclYTQvd79cjqGNOy0W9EbPboc+tUYfZhgZp5maWCrwpMxAmJdxwQBWK/KFLdvMR2SKrYLKlSvaAKTZzMt3IK0/ZbkqkOTiY6EfGysxMBIspkK1JV/L0g7SB6HU0Xqtwe9aPY+Ohl6IL9Ttr6b+PkzsuMMqOVTbjTetNqC//agVk+JSnsEs3ip5BqQYaTE20HkIiLCrZHULA9vOzoRO4jK2FdnIK38YpzDwKAQV4Nbz/Cc5ajLB12gSGCbsjM7FOxRtS23CQm48kcwbMgk0vJTLDMjzGCtqjM1LMcPu0OTwYPCkzkCYGzHxUEZ48oMl2izLUKstDCK0ILpwi77xG3m5O5Vk6h2jmZ+gYAAgGwR1DoFglJh0h0CiKxX+SJA7JEtemGuMMXY76Wnp7onZeU9IO/KQDy8tKnxse6XmZY/Bjy1a32iC9xwn6N4cmjHE8eQp6KIGL7ReSry/ZOQXEgANo5CdvLStgBBAKvOVt4jWhGUsCKjoO8YOsLBEb03PMcMXPYJQTvy47HC19d4jc/fCX5iQ9fjVvxylL59YWp1ldi5Gm1snPiTR6fckcgQy5JbNQxiccOSCLZLQj0XkFg9vIi18nLfGtAFal8My9zraxC77knBWTHPQDIdl6m20SZakUeFEpZiAJ+UBCcB2WZbvF41JWp6fFxhYVpo/6cAKAgFKm1b9Pqf/RJTY2JU1WmGScsN+x4xM+dpPU6zRLHkArg0Q1D7iEK9yVsLwIARaec5OhiUAJNdNxTQSqxm9epRkEjG1E0K4i2HpGP7BWooPMyNf1qjBZSvjSHy1zzWsorlevmVVRvyO/b/FbM2RVP0J15/tmbvcy4gzI+7o7knHpdoeac1gTrflXCOySeOMDzeB/LU4c4iQmoJWQLBIXdzct0wBbwCnHPVUVeEnoMxA9kq4zUEY/38Bx2RBKJbpdL2pyWHJM1f37OxD8nACg+ys7OftjpdP5pxj0hIbqAE5yHHc7Ij1GKgGAcZxme7P3G8+jkRXzfvwFAcrQj9cOKjn2MaO9hZHwvp5K7BZ2plXWmSlSdTUhVyXxYn0TNOqex004nmyEfvjCPf3XrW6lNrTsWXO/eNe/rpk0psOFV5avn8yIuZ5mTd3vosf0aPuGGSs64ZPLhBw3B1inz9h4+4L46jrMsdozjnb08iglQcKaSTbJKNCBSNbJBQc+/YbyiOFtUmdgtC9h+kcf6RB4/qCtMbWy8+/mcnIyI/wwAqOjyXU8KPV+wwPOnS0B8kieTF4hDTtIyTFC2SxSLnaQFso+RqL3IpfxWAkTRsV+SHN2SjHWIMtYRAEHGulnZ2cGpdKuocTWKwe9SdKJali2dEh9yTKanXXALU/Zn+YI/eGUhU7Xj7diPu0ry4FBVHuwtSYbaD12wdjkJz6YH/zxdG9/tocaeMJ0TB0x61imDC+1VuYg+gY08ztFRZxk68iLLRJ3jOcsRSbJ2y7K9VVHsTYqCNeoK1qjJjhZVcrRrkr0DkSpie1QR61Z47AACQhXJdo9bWpuVnqCjAtAfwJr/ECDEcOQxopv/74DJ/BMqcSkp/hhJpjoI2n6R5hwnaMF5mBGJXlYiuziJ7OIlohvdflF07JMCj1iXKGN7kB+ODB+v0G0B91Bj6xEAqkFUKlJUl8TNOq7Qky/4pUnNhXEhW15/grhc9p4X9pakjhyrSYcjlYnQtc0zUva2MPLBEissjp92N1ka1+0lHr9gYBNvaMT0ixoVfFphQ/tFOuwMS84ZZMjgQeQx8UzQOYELOSFyc44q3NyjMjunX2LmnJDoOWclOvSszEb0q7y1R+Md3YaIt+uSs02TyFaPKWxBagilVH4Pk/+ggj667Shm+p1b//0lmZn/+kcDkJoab6ga00zR9vMUaz9NowQZYrxCtwgKFUj9IoZLItYliRhKAXcFAiAUFKFiisK0IAA4hdkta0ytouJ1shi+X+KmndDY8adj5QmNC+Jnd7+zBPtN9Qcm9O5KGDnbkAznGuPhWKUX9qzXYPsrxNdvzpsLi/yTbsczo4+ajkc+Vu2PfaISUwZ1Zla/ygYfl6nZFwVy+oBATBkWiMnDEjllUKKmXJGJKQMqOWVAIaZcV4hpwyo5e0Bjwk5qnKVXFxydhkzsNmSixVSoeo8hbE6Kcz2Tk5PI/Z4U9R+llhAA3+j+P92epKUlSLrOVVGM7RySAorHjiLPQtCYWlFl6qRAhtLZokh4uyI6uyQR5eGdXQEAFKZRVLlmXmb2cBLdIalUs6zYWhRhzkGZnXLSYB8/FSePbXkyYcbgqqftUL9KGzlaEQNXWuJhoDUGztd74OB2Here42D9s/aRV7KDIccYe8WDP3RZsTz8tWR99NcKPuGWSiAGT72qEJOvKuSEQZWcOKAzE8+4mElHo9nJvV5uclesML0xXgopSVQj1icZ+IZYndzqVskKQ8LbdB7rNmWqGUlAnE97LTU5JregIMNWVOT5hwf+kwdJgsfj+Z9/MgiZmUm06ZK3U4zjDEFaBgnOcZKVyQ5RZ6pknaqSVbJORYZOJnarqCIl4HuRV4G8DklhW0SVb76XLqC7AgZQtu5R+OA+jZl4xmTHHE+Ux/QsTpzy+YdPW6D5IxlOVnnhWlsM3Gj3wNVmF/SXadC+VoKyn1CwckkUPJUw/fMkfvRxw/7jj+WoB0GKehgk25gvVWLsDRcz8aiHn9IRo0ytTjRmr8t0B63K8YasXxAbtv7pFOy95/OlpS/NMz1P5XvthanR/mSv+JYpYu0SHXlGZu2H3Tpd4ffIKxPijOeyM5LcS5eiGkHgfJd5v+3U+EMP6sJYtCj+f/9JIGTmJjjcHnUtzWIncdIy7GSsFynJuV/QqVpZI2sljahX7oHQrCAXT8D3CoJzb8D1U5jdyDfnRK7zHgBEmypZO2Qu6KhKTzjvokefSFYeOftU0kT46JkI2L1ahNPVbrixJxpudxhwrUWDM5Uy9GyRoHklB9texOGNwlBY6J/0aQIz6qJu/eFdzfKDX5r2hwd97NjuFG1KZZ4/aMvCpLCdz2Q7dr5YSNa8Np/Z/+6TYv+aIk/v1p+kl2x9c96Tq14omPtiQeKktBj1WY2z9rGOuZ9wzvBruky0eN38urgY/ZX09PjE7/QRffd87491KRFgTz755D9/Iwl/3MnLSw71xRhvc7yzz0lYhjHSeo3kHcfv5XbIFhG5dxrZGCgFSng7jwIvCd/7beSJdD8jMV2cRHVLsrNNlWwdMhvcr1ITLpn06JPJyiMXnkmZCKuXhcHuNQycqtLgeqsGt9oluN4iwIVqHo7t4KF7HQM1bzhh3dORsCJ7JjzpG/dlrjrmk2xlzMcFrvGDS+JnXF+eMfeTV/Ojfv7uk/iv1jwnfr7lZfPXO16L/qrsDf/XDauyftm6afGxxk3LVm56e7G4bL5/VrKHfVvEw4ZIa9AIi4Xe1QRnl9cUN8b5jRXpKbGZBQWpc/9cyTkUkP1JfUEFBemPxcd7F8sq00xS1ksO0nLDyTgu0gJxKBDmI09HdrbxAdfT3slKji5Oxjs5DW/mNaqe06hmRiK6GMm5F3lGimjrlJigU4pz/DWTeORsujr6ynPpk2Dtc3OhZbUTjpdzMNjMws1WGm60UHC1joYzuyg4vJmA9g/sUP5yOKxfMnvkvcIZ8FbedHgnfzasXBQKG562QvFyDHa9TEHNGwLsXumGznVx0LU+CTrWpsC+bfnQVbz447r1i8tWv5Zj5CcovmjZvoe2B/+KtAQBh4ffNBAAurg1zmO8kZIUW5idnc5/p0hzfw66AdnZybzpVjZSrON0IBij7FdoHj/KiGQPK5EHWNG5n5Ec+xnZvpdV7R2chrfxOt7IG0Q9pzmbGAXvZKV7wZrIRR3h8Vk3RPvjv9Kxh6+lK49cX54xCdYVhUDLagccK6PgSgMBwy043GjB4VqDE65U4nB6uwN610TB7rfmQOVLs6Fk+WwoeX7OSMXLUVD3BjbS9i410rWSHdm/Whjp26iNHC/2jZwuTRo5uTMd+ralw4FtObB7Q96X295IbXxhoTs1VrOu5fGgu5R11lecI+yOTFtPGhLV6tGkYr/XfDMxPvaJ7IxU96JFBTORIb2vIDz1VMFDqKbLC+RBnLQNUYFomOhFUnCP8EO0YD9Ei7YeRnXsQbef07EGXscaBM3ZIKp4cyAlLNgO8lTYRc469XPRMgZ0249uZygPf/Ji1gTY9HwwtK21QH8ZBlfq7XC9yQo3m61wo9EG12uscKXMAqe2hsHBj4Jhz9szofmNGdD8VhC0vx8OB9Zi0L+ZgbM7BLi4U4GBchOGamJhqC4FLlVnwLGSdOjckAIlb8Z+8eYSZVeWJ+p1lZgxRFmmAesI+lTlrH2GhLcaEt1k6uJOn9d4NzEu5un0lMTEwtxcR97Spd8a4/t3ktNiXZLGNZO04zzN48d4idrLCM6ee8zH+2jBEUg/s4qji1Mc7Zxia+dkW6cQ6FpwtKHyoMRGHBOdQdcEy4SvlKhRv/HiPxzO0x/64tWc8VD80izoWBcBJ8pscKXeCtcaI+FGYzjcbIiAG7URcK0qHC6VzoUTm2bBwY+mwd6VU6B71XQ4uC4E+rdFwfldOAxVs3CjVoLbDSbcbvTD9YZEuFCZCr1bEkdq3/XC+0u44UWJkRtd9NRDTNREIKOmjUhU2MVohax168wuQ2HrdUWo8riNj2L93ufTkhPT87Ky2MLCwrF/cirhP3sA7rlOWflpka5obRPDEUdpHjvGCs6DHGp6Eol9qGDOidgBQcB7eNSNINgOcnzUUVTlEpjwkxIbflyhw0/p1NwzhnPmVRc+YdDnHH02TXj4p0tjRsPbheNGSl+eAZ3r5sCJXRFwuS4ChhrC4Hr9HBiuC4bhmiC4Xh0MAxVBcL5kJpzcOhWObZkKx7bOgJM7guBcWThcqbbBjQYS7jTx8HGzDjcaPHC52g/9O2Jh9yrPyKYiAZ5Ni9oXL0ytFa3jP6ciJwHjmP1zlbP1enR6l1tjyjSZaVElrtk0la0xPvdrSUnxeYFa8YIFk+9npSwAwBNPZE6KiXO/KEpUB83ZT7Ac1o8qS7JM7VZkukURiS6Zxw/InKNPZKJOinToWYmac1EiQy5rVND5aDroRAwf3JkkzKjOlKe1zHdPvPFs/Hh4I2c8bHhqItS8PhX2rZ0Fx0uC4HJNCAzWB8NQ3UwYrJ4Kg5VTYahqWoCuVEyFi+VT4UL5NLhYNSvwf6/WhcJgPZIYB9xqpOFmkwRXqzU4vkOH9tXaSMkrAqzItd7OMmeWm84JlzjLxK8Zx6yfS1TEGU3E2w2FrDMUqkkRmS5Z4Dp1TS73edzvJSbGPpGenmLm5+dPv+8AoMYqVLbTdaGc5ez9DGs7hcqKqkw3KzLZInNYr0zbTslk5AWFCL2sEyEXXVTwaQ8dfCiWC9qdLAXtyHPN3bw0bm73C6mhn7yZFwKrFswa2fz0dKh4aSq0vjcNejdOh1MlM+FyzSwYrJ8Jg3VTYbB6IgxWToCh6okwVDMJrlZPgivVk+FK7RS4Wj8DBhpmw0BDMAw1hML1xigYqsdgoJaBM7sE2Leeh/IVFLy1wAoL/UH7PdTEXtE24XPWMfPnAhV5ThXwTk0mWjSJaFNFqkMWmW5Z5Dp0VaqOjjbXxMX5nk7PSvSiHlKPp+g/HRX/pw6K5jIz01SPV1nFo3YRxnZK5LFeTSTbNY44oJDW8zIWfl3F5w65yJALsWxId6o8pyTHDFuzyB9R8lyqpf21PMfwqieIkS3PEbDzRQdUvxoFTW/OhY73ZkPv2plwYtsMuLBrOlytmQqDdZNhsG4CXKsdB9dqxsL12rGBn4dqx8LVmrFwpXYcXKmdBAMNU2GocSZcawyGocYwuFJtgfPlOBzeRkHTe86Rdc9EwdLEGbdimbE9gvXxL2jLJGCwkDsy7zikoVuv0E2KRLbLEt2hSlyrIvMtuipWu01tY0yM58XU1PhkVBFELZX3GYCi7xcW5oT5Y93Po2oSR9nOiSzWr3HEfo3B+nTKctYkIs762Yh9KUr4tnxP1NtPJ9t2vJKLH3t3IfGLDc9xULpChLq3lJHdH0gj3as56FlDwOENFujfOBdObwuCi7tmwpXKaTBQMwkGasfBYN1YuF73OAzXPRagazWPwmD1GLhSNQYuVT0Kl6oQEBNhoH46DDUEwUDdHDi/KyxglDs/ssDOlyJGXs+dCRnq2POKbfRtxjIOKPvMX/FU5HlJJLtQf6iicE2yyOxRZHa3pvD1uiLWGZpU6TKVrf5A0xYq1qfSqFX+gQceuG8DFt/0A2U9mpTkL0R9lRRpHeQo60WVxXpNHt/rE7DdKRqxpdBHLn02lV32RqFQt+pp6dPtL6tQ/ZY20rRKH+lab470bnVB/w4DzpTKcK6UgQs77XBpZzgMlIXA9apZcA3p/JrxcLX2MRiofRSu1T0Kw7VjYLjmERiqHgUDlaPgasUjcKliNFyseBwuV0+EqzXT4WrtbLhUGQLHtwXDvo+CoGrFLFi1cAos9o/5tZd4aJiLegRIy+SvOTJsQJKce1WVa9A0vlJW+QZZ5nYritCkKUItIiQBhiGV+DzGe/HxvieyshLNhQszp9/PeCAAQFFR7j+lpCXGKwrfSBDWYdppua6y2CGfRNSnu9n3FyUpCa8uiE788Fl/8fbX/HfrVsVC21r/yIGtvpEjO31wqtwDF6rdcKXWgMFaGYZqGbhejcFwVSTcqA6BmzUz4Tq6/UjF1IyGqzWPwGDNKLhWPQquVTwIQ+U/hsHyhwIAXKl4FC5XjIMrVVPgctVMuFQZBOd2BsGhdShGmAKbloyFF1NGQab4g1+qlh98xkU9Coxj1ieos0LVuBpVkypVXaqQVbEGgaAoYuM9EhpVJAW6uAs1bcXHRy/LyI7xo7TE7xZZ7osaSstME3RTLqVIxwDjtF5TWWdvrMqU5cbITz+T72VWPpu0uPTt9I6mtRlfdW1Lg77SRDhVkwAX6+PgapMXhprdcL1ZgxtNItxsouF2vQNu1UbCrZoQuFEzDa5Vj4er1Y/ClZpRcLX6YRisehCuVT4I1yp+/FsABitGw0DFWLhaMRGuVE2DyxWz4EJZMJwqDoIDH02HmpcnwIeFj8BT/h9AAvNPX8qWH37JWcf9BgWBmkbV6oa0Q9PlcgSAoolVqirVyLLQ8B0A6g1NKHO71bVxca7n0lNiEvPz0yK/yWj+Xt6gsae/pLcUkIL8BVkhXq/7HY4jj3AUdl5jiYN+hS3PiZGeeSrPw65cnvhU6buZPc3rM0b2bk+FI+WJcKYuHi41xsBAsweGWgy43qzAjSYObjWRcKfBAbfrIuFmTRBcq5wMAxWPw5Wq0XCl+mG4Wv0QDFb9GIYqfwzXKx6E6xUPwfWKUXC96lG4VjUOBionwUDANZ0NF0qD4eS22bDvw+lQ/fIEWDXvEXgm9oeQwv/Lr1THg3dFbOLHKBA0DKYCtaHImlQpa2KVosn3SJFrVVlqUGWhIQAAkgC3ujbeb7yQmuTPyMtKIvLyEv6vEbHH4/mHv6SUBACYN2/e+PjE2CWqKjQILH1Y4agej0Q3pLqEdxelGN7XFkanr1nubyh9O+ZXjWv80LHZO3JopxeOl7vhTLUBF2sVuFwrwNUaCoZqnHC9xg7D1RFwvWo2DJRPhMvlj8Llyke+AeBBGKz6EVyr+hEMVz0IN6pGwY2q0TBc/Shcrx4Lg1UTYLBqKlytnAWXyoLg1I4g6Fk7ExremAIbl44beSXjUcg1Hv65hx51SiUmDchc2BFdI2t1Q9ylqGK1okrV/wYARar/9wCYL90rUyazubm54/6AGYK/WD9R4IXRIANyzUy3tlES+Q6Zo3oMnuqM1ejSDDfz5rw4an5RDvP6W0+w5za8IMCuN0RoWCmNtK+TRg5skeBwsQD9JSycKnHC2Z12uLjLApd3hcGV8llwuXwyXK4YC5erxnwHgB8GALhR/SDcrB4FN6oRAGNgqPoxGEBSUDURrlZNh6uVs+HCrmA4ujkYOlfNhvJXZk6kFfYAACAASURBVI6sfGIaLIkf/+tE+fH9BjP5OKoNqxLeqqpMjazxtYom1CqqWKeoYr2sCg2q+q0E8PWGyldGu5RNfq/+enKib15uVoJeWJgWXFSU9O105V/9BABAIpaenc77Y6NXyIrYyHNUn8yRfW6e6PSKWGucFNGQpIauXxATtnF5VtSZtxbafrOhiIAdLxNQ9QY10vQ+NbJnFQHdq23QszYSjmwMg5PbQuDczllwqXwaXKmaCFdqHg8Y4IHqh2Go+kEYRsyvfQhu1T4MN2pGwXD1aBiqHgMDVY/BQPV4GKyZCkM1s+BqVQic3TkXjmwOh7aV4VD8YujIa/mzIc87ucfDT25T2NmnJC6yV5adbai7WlWFakkVGiSZb0GGWFXFGmSA73lCQrWpy9u9Xv39uETz6bQ0f1J+fjL2xBO/bWG/fyBkz8ueFp8Y+wQSXY6l+3mKPKOwxBGDcRw2yfBTHjq4P0EIqss0gjY/GT+3eXla2NCKvIjPVz1pgfVPR41sK4oYKXtpLtS9HgJt782G/atnwrEtM+BM6TS4VDkZrtSMh4Hax+Ba3RgYrhsNN+segVt1o+BW7Si4WTsKbtSNget1j8IgclXrxsJQ3US4Xj8drtcGw0BVOJzbZYXezQ6ofcc+smZZBDydFnQ1yZhWYnAzD4t0yGmUlVVVukHTuXLUoi7LXLOi8LW6Lpbqulyqq2KFrglVyBV1Ratr/H791cREz7ycnHj1ySdTp/2BbSt/WXc0LS0hVte1nSxDn+JI8rzMUkdMjul2s/gBNxvV6+PCemL5kLZEKagsUw/aVugJrlwaF3R6efLsL1/PmgnvFU6D9UumQukLU6HxrSmwb8006C+eCufKpsKVmskwVD8RbjZNgDvN4+F2w+Nwu/5RuF03Gm7VjoFb9Y/CjYaxcK1+HAwFaCIM10+Dm/XBMFwXAYPVDji5k4DOtQSUvobDm4sssCAxpNYnzahWmJlnZS7sqKIQjbrJlao6V6FobID5Lpe0yeNWNroMZZuuyzuRt2S6lE1ur7bKH2u8kJzhTy0sTI74Tgf1/TmovJaZmcmZprYFAcBQ1AWZ4w64ZKnWqwjVXolu8PCOPR4m4qCPDT0Yw8/pTBBDatLkWaW5+vQ9C9wT7zwbNw5WpI8dWfPEONj10kRo+2AqHEZSUDYDrtZOg2sNU+FW81S42zIF7jROhDv1Y+FW7WNwoxoFZo/B9bqxcA2lKuonwrX6yTDcMAPuNIXAbZTGrsfgUiUNfcUctKziRra9QsNL+ZaBdPesDSY//ZDMhJxCpVFNIyt1na4wda7U5RI2R7uU9R63ts7lUjYZLmWbYcrFukvearjFLS6f8l5csmdhYW6KI/NPabD6c0tB7rz0OR6P6z2Op/tYmjwtCUKXoSoV0Ypc7pb5GhdPtposvs/N2Q54WMs+Lxu5L46f053AzmhPYSd25ciP3l3iHQ2vZz06svnZCdD03gzoQ7agcg5crZ8N1xpnwI3GaXC7aSrcapgCt2onwPWqsTBQNgYulY6GS7seg8sVE2Cgegpcq50ON+tnw53GuXC3wQK3G3C4VsvDuQoFDm3Toe4DBVY+Q379REpodYwyfZfKzDwrsaH9qmzfY2pklcvktnpcwga3KW4xXfJW05S36i5lK2K+ZsrbNVMs1d3SZpSGQfspFi1a9L//UI8Hdcnl5ub+05/TO/pmYCNvTFxCzDOywrewHHVEFLkOTZVqNFWs0RW+1lTYWpdMNbpkuiFaIhs8krPZx9vaYpi5PTHktP4kZkx/nvrwVy+kjIG1T02GhveD4fD2CLhQEwEDjXNgqGEWDDdMh5sN0+Bm7TS4UT0ZrpaOg7Nbx8DxDQ/DsQ2PwMkt4+D8zqkwUDELhmvmwu26cLhTZ4U7DU641SDCUJ0JZyo80LUxeqTkDQlenme7lOUPWu0RZ3ZIVNA5hQk/akiOJrfBbHO7+M2mLuzUEbNNeTtivu5WNqsuaZtsCGWKKe6M9hs/SctMdqUtSPvRHwjA91BrC6or/znTGL+dE0N2wDTlYl6g9qJ+fVlmmpF3gYybYbAlLoPbYRp8iUtjy90yU+eRiAYfH9XhpWadjKXGHsmSx9xcnjIO1jw1faThgzA4vMMK52usMNAYDtcaguBGw0y4WT8ThmtmwGDZFDi/bRwcXTMaet5/CPa/NwoOfjgW+jdMhXPFQXC1NBSGKyLgZqUVbtc44U69CDcbXXC5xgN9OzzQ8KEOq19gv3ou31qV6Ar5UGODj0nUnHOqELUvWnOWu0x2u65zOzWDL9Fd0jbdJW3W3eoGzaVsUlDcYIo7XV79g6SU+MzMgoJJfwS/vp+UlPQ//tybUr5xSVPn+mPdr8oa14CqYxzqB1LJJs1kSgwPt9GM5jcZJl+sqUylIbFN0TLd4BFtrV46+KifnnQwUxl/dHnaVFi7bM5IwwcW6NuOwblqOww0RsC1xjlwszEYbtYFw7XKmXCpeAr0rxkPB94eDe2vPgxtL4+C9hVjYd/bk+Hwqplwam0IXNwcCle3RcG1nQ4YruTgWo0OlypdcKTEBXvWu0bK3nXBO8ukQwUpjmc8cmijRIVcRtU6XbI2mxpZZppssekWNxpueQMyvgEA3MpG1S0XK8gmeLTV/kTvssx5qfh9K1F+F4AFC9J+lJQSm6m7+B1oHwMrOA6JCrFbc7PFhodba3j4DbqL36oa3C4NqSSFqfLIjgYvN2e/n5vamWVM3vN8xszfbCwKh8aVDujb7oRz1RgMNVrhRnMY3G4MhZs1c2FwZxCcXTcVDr01DtpfGA2NTz0MdYtHQf1Tj0HLsxOg/YUpsO/V6XDozVlw9P05cGp1FJzdTMK5HTKc2qFD3zYXdG3yjzSuSYANK3yHns4T5sdoUZtkas4Vnpp7UROse02VqEEAuN3SWle0sj4AgEvZrCE74FK2atHKJgSAN9b9Elp38yeOMv15o2SUeMrISWDcPvk9AQ3i8dghNEinm+x2l0daa7ilDbpL2qQb0jZdF3a6DabErWDV0fzcvT5hyp4MY1LL81mzvtywPAqaPnRC3w4KLtRSgZaU2y0WuFUfAUNloXBhUzAce2c6dD8/ERoXPgoV2aOgLOMRKM96DKpyx0F1/gSoKRwP9YsmQtNT06Dt+WDo/IkN9q1kYf9qFbrWuUc6NiZA/dr0rza9nlT73DwtI96wfSTTcy8KZNgVhbce0GVng4FUpkdcZ0ZL6xHjFVPeKRtSmWpKJTqSCq/+vj/WVZSUmpCQn585/YH7fO6lJhamT41JMJ+VNaYRzQrICtmCkl3oBhmmvMVwqZsN5Fu7lM1uU9ji0rEKU5zT5RWntGaYE5uKsmZ+uT4AAAVHd/JwuUGAW7sZuNOCwXCNFS4Xh8PJD0Kg58WZ0LZwElSlPw47Y0ZDie9R2BkzFkpjx8OOmLGwxTcaNsU8AhsTxsCm9AmwrWAW7HzKAmXPU1C2QoayN7yw9fX486uWx7y2JFOJjVOxHQoVdl6iIs6qoqPLVMkaZK8Mt7BZM4UtyPBKGl8rqly9pIsVhlvd4PYZb8ckeJYmp8UlZeWlEQUFBQ/ddwAWLlz4YGKyN0s3+F2iSHUiQ2wYcolhqsWaoZZopr7dcBmbXS51s9slbXbpxE6XPLfNK01tSXNNaliWOeOLdUUWaPqQHTlWpsFAkwm3WhW42cTAYDkOp9dHQe/robBnyUyoy5wMu2InwA7XOCgxJsJOYxKUGJNgszoWPhJGwTvMD2AF/c/wMvev8JI6Cl7xTYAViTNhRXr41yuysauv5HFbl6Xy8zI9zpc8grVLJSPOK4y135SczS6dLTVNvlh3iVsVg9vFq0wzaqsXFLZF0oVqpI6ifca7MQmeZ5JSYtOys1PE+fPnfzvOdP8OUkPpWQm6yyWtV2SmBZX4UBSJmK8aapmqG7s0wygxTaMYBTjRLnqrS41o8EjTm1JcE6ufTp/12ernrNDwoTTSX+GFqy2xMNzigYEaGc5so6D3XRu0LpsLVdnToSRuChS7p8B2fTqUarOhVJ0NJcpM2CJMho+oMfC67QewLPQfYeGcv4O80H+EnKh/giz7j0YynKN/mkZNPJ7KzmhM4uc2+JiIXp0IP6cSUed0zt7j0siqaJPb5HYLG3WT2y6rTN23AyhCYK5BqNVMtdjtMT7y+10r4pP8hRnZqdo3zbt/kF6/N7ARiAf+/CczNxH3eLX3VeSGKmwAAN1QdwQA0IwyVdd3obSFacpb3C5qm1uNqPcoM5pSXFNKn84IHlrzHAb1H2ojR8rj4VJzKgy2JMH5img4tJaHlpdssDM/CDbETII1+iTYoE2HHfpcKDcjoVwLh3IlFHZKQbCZmwLvYWPghbB/gYWz/gHSp/4dxE/9e/BO+8cR18x/HXGHjILo8PEjpmXaZ6ZjzjWdiDxnMPYjLhFvd6t0pdtgNyMANIMtERWqCY3UfgNAi6yJNZou7tRMuTg6Wl0TE+N+EU1U/qGrDVDkjGrKfwmVFUA/Z17aDH+ssUJRmEZZppsNQ9wRCOMNdYdm6qWqoe7SNKXcNOXtpsGUGEpUo0cJaklwzdiwND1038pnyZGalebIgR0JIydrM0fO1mWNHNkeP9LyljSyZUEEvOObCiv4x+EnzHhYKcwe2aZboNyNQ6WJQZVugyo9Csq0MNgizIL38YmwPGwUFMz8F0ia8r/AN/mfIHr6Q+AJHgvusKlfu63Bt71k5HEPh3d6BaLFIxAtbplodKt0RSAWMNlSWaUb7rXXU7tlla2TNb5S0YXAegRV4ytRzig+3rckNzcz6g9pVUdLQBYtyh2HCjZ/EQDQG8QnepboOleBsoy6zu8yTKnYMNUtulvfrLv0bbqh7DDd8hbDYEp02drikoLbE9xBqxZnRm15/1n24+oPY6CrOH2kryIPDpflQdvqBNi6jINX44JHFtOPjzwRNRqetY2HN+kg2KA6oNRNQ6WbhloXBY3RJDR4nFAT7YDtagSspGfD8qjxUBA8ZiRt9qMjSSGTfpMYNvtn8dawgXjCdiSRw3fHy2RVrExXeiWiwSU421wy2WhqdKWuUVWKStVJCtWEmK/oaDcFV4V2VCBARIVqV1Suzucz3s7MTHYVFRX9X93Re1OSC370l0rg/Z/saGZsbHS0skZV6WpV5Wo0TSgzXdomt9dcZXrcq0yv+aHbp610ufnNmmpv1qU53fGukLVPpNteee85tb38w+Sfthfnf9FZPO+LhtVZv1z/nHn3xWTLmVx6wlBS6MNfpAaPhvlhEz97Hgv5xfu8A7YaLJS5hZE6jwjNPh5a/Bw0+Rmo8VKwTXfAe0wYPGeb9cX88JlD2RHBw2mWsMvJdsvZRNLRG8/iHbE80ewXiAafTNZ5JKreLZONukw0axLZpKlkg6IxtarGViJSdK4aRfhIKu5tWWGa3W55XWJaTE7O75krRoEaioBR3uiv0lWHBjni413LDBe/Q1boFlXlG5AEeH2ut7yx3hUev+dVj9981eWVPlRVvE4TwvfGmBFbC1IdBT952nyz+P30hvqNC7oqP8rrWPd8XOmyFPL9VGp6t3vOo782Z4yG2NkTICt01t3F1tBDLxG2CysF5qtiQ4IKtzJS55GgwcNDo5eHOh8PZdEMbNAIeIO1fr4MizxUaI04nmmNvJBss15IwGxnYpy24x7KcczLOvb5JKreq1BVKF+FJiY10dmhyVSzotwDQEO3X2Xr0LQP8vJEiWpHkmG4pM1ov0RGTgrzH93uJUsy/xXtxkOPf2nef1MrTvpBWlpcvNsjr5NkuhVtydIMudjtNd9x+zyveWI9r3pizVdNr7RK14lqVYps9+mROzNiHQuKntASV62If37jm5lvffhi0vLlmVJBEje3Qgub+BthxmMgz5wA/jmzvsqICr9aYLMcW2yz7n2ZwA6tEthfbTdkKHOJI9XRAtR5Baj1SVDhFWGri4X3JOKLFyjHoYV2W2eOzXoqxW49m4jbTvkx2xkPbj0bTdmPeHhnh1ckml0C1q5z2H5dcHZqCtmkaWwV0veohUVWmEZBpvegJU+STLepOldtuKXN3ljzpbTMBF/B4vTHfpcpqHKIuun+attyUY0gNzfFEROjvIH+YKQvNVModXm0jwyv8QGKIhEZHnmtZjBlmorVR+u2nYlex+t5aVzssnmqa/lCM25xppCUolvX6NZZP2eCJgE9e8qIEho84rdYhtNw8lAWRhzKtzpOPmGzdb9AEO3v8szdLboAO90SVHrlkUqvMlLqlmCLySEAfo0AWIzZWvMc1qPpDsuJZNx+NI6wH/ER9n4Pae93U45jLspxRGfsRzTW0YuadXWFqtV1pgI1bqHbjy6TJFGBdZiyTLcGCjgueavXb76akh6fmL8wf7qz6E9cRfBnNsaT4+LMZ1GVSZLpFk0XylEyCxFKbOnR6nqUmtBMocQ06VKXSWz3RWPrE2OwN9LiicWZsfiSZJd1jYcO7xejgr5k5s4GLmwOqFbLT/0k1ZvESC1pNN+ajtF9OTbn8YU2bG+RE2t9i6OvrFOFr7e7FdjhUmCbIcJ6jYV3BOLzFyj7ocV4VGu+I+pohiPyRDJuPZZA2A/7ScdhD2E/buK2CzpuvawS1rMa5+j7FgBNpWuQ3g/sJ0JMD3SBU7vRz6rKNOimuN0XY7yWkOpPzSlMDysoivuX+w4AynsnJ3vyTTdfjLZbIR36bV7dcGv3QHDLGwzkDbm5LS4Xs81tkCUeA9vhN6wlPt1a4RWjWl205aiCRV0XLZG/4KOiPpftzmE3xffGc2pdkmCWp7BaY5qT259pdZ4qsDqOPe3AWl5jqP0fiNzwaln45WqF/2KVwn75pkjefpHG9j7pjGzJs4f3p9lCzyfaw8/HYJZzHtx6zo1bzxq47bKGWa/oCADGcVjj8W5VQuO0ZAtitijTe75luqqw9SjOQRKuGnyZ26e9F5/iL0zNTaVzFiY/Xnq/l3MjY5SaGuN3uYUNyJdG3gMqbqB8kBmtrzE92mrTo61D82ZoO4nh4reZGlNmas4qQ3XUmYqtKVrCGnwiU+fluTadoE/ydudtzk7eFQnhvMmbe+LkmOIUJXZ9Ch9dloJLB1It1MXcKOfZxTZnx3InVf8qy7a+KQr73pT43tcltqOIcdYswqL25NpCTydb5gzFRoXe9ljCb7ttUcMmbrtsOu3nDAI7pdP4MZXB+1CnnyIQ+2SBDMw7f6N2WhSFrVVVrhoBgOwAUkNInfriXM+lZCV6sxdlz0ZezwP3++TkJDBen/quojJ1ssahCLLUcKtbXB7jI2QP7gGgBZJzqPSHqlCGzlQYKlFjKM46n87siDeVNQmasTFaUHYLOHuVtDKfkZhwS2Tch71KwvZkd8braa70n6SKsduTnNq+dJtwItfCnJhvpfuWOOiWZwm2fDnD7XiWprYvJbHKQiyyJ8My90piRPDH3og5vzAjQz8zrFG3DdxxySDxEy7a2WewxIFAmz1H9sgCsV8SyL1oG6MsUa0owESutaKwdTIyxsgVVZgWlB/yxZmvJKbFpWfmpjhycu7vBt5vijQpM+MSzGc1gy+TVaYBBTCaIZe43NpaV7S+BmVGAxJhKlvvRcviDl3nSg2NrnSpTIVP57cmuo2VCYb7I4+k14qkdAa385/abfIvCCL6kianVMV7C15O8y9YlObOW54up6xNo/0NaQ69N9Minsm10KcLbfTheQ66az5GduQ7HAeybVEnUyLDrsdFzP3EExH6CzMq/Ge63XrDcGLnXRRxzMWS+1FzmS5SHapAdaoi3aHI9B5VoZtUFIyhmADZA4lqQ9u60FocUaI7NJew3evXfhKX5J+fmZOmol1DRUUPfP++AoD83tTU2GSXS94gyXQzuimqIVUitWO41A16gPFqMWJ+AABT3G6YQjEqBZqGUOIzlU1xLteHcS7vGrfirhBpsw/H5JuRFuUrmyP6Di+k7PG5F76RGvd0bkbcU1lZ3oWLM/Xcd9LZxPJUPHpfqk3pz7QJxzMd3JEsjOnNwsi+DDvWj2KAWEvUsMcSdcewWm5rmOOKQRCnTJo6ZPJ0p0tkWw2JbdEktjUwKyYzzarC1mkaV4VuP7IByA0VOOdhjnMeEUW6C/3N0T79rdgk/yJUK84pzAlOfTL1nx+43yczL9XqizHeQB4EmqaUZK4Z9digwEwzle26qWz/LgCaKQUkATVCeUxti9c01/lNzzq35i1WBN9ukjQvRNn0zyNtns8oNuWQaS78MC7umYWpsc9lZMY8k5PhXfxUup7/TqqQuj2NialNI6N3Z5BGawYtt2RQYms6ye5JIeh9CbjzmBfDzhkO7KqGYxc0kjxhMlSPKbDtiPmGzDZqEtekoUYtmUUgNCgqXY/0PQJDEql2kSP7eBbv53myB8UJ0T793bjkmHnpWcl63vzM0PnzM0cX3UeXNCAFixcXPBaf6HtCUbl6jif7BJHuUjWhElWWNPNew1Og8wARahU3pRIVVZ50qcLUlZ0ew9ziMTwbos2Y9boau4thfH1Wh+tnEdbozzEy+bSszN/u9T9dlBD3XEFK7DN5Kf6nFqVGL3ohVc//IEVK35QiJJSm8t6KNN5VkcYbFemCVp7CSTWJNNfhI6ijBuY8rzidF1WSOKOzVO89APiWAPMlrgkxH03MIO/nngGmm3SFrVNEZo/IUz0CSxwTOOIwmpNAdi020b8gPStdz8vLDEVDLPd9sBst7Q50zhniLpYjDqMBb7Tr89uhCF0X74HwLfNNqQSV/lDLuKYrpaZhFLsNzwaPO3a1rsdv5XjfXrvDdTfK6v4CJxIvi3J+lcfz1Cvx8UWFifFF+UkxTy2NdS182y/nFPuElDofE9fmZzztsbTZGseZ9fGCWRXHqzV+VmyPJpl+DScuizg+IDqJizJN92s8162Lwh5N5ls0hW/8DgB7JIlpVyS6TZWZ3WiOLAAAQxzjOfKIKLJ7kBTHxPmeS8tM8yAA7m1h/xvYuJiamcihVZeBzYoceUiSuVZF4esVNAakCWUBEAI59nsAKIa0C7V/aKZaYhjGtmjTu/4eALFbOcHb5cCMWxar63Mcjx0UxJzG6OgnfxIXt2xeYtyyeT7Pk69pYnaNSMb3s47oIdZm3Obtyk0Jly8blHrUzWh73Yy8V6P4ozJGXhEc2C0Ww25zOH5dIMlzMkcfknm2W5H4NlRQCsyNyVyzLDN7JJHuQhsaA24pTx4QObJXZMnDPEceFQVmH/o80V7jg+TkhNyCgmxLUVHRX6bo8seezNxUHK0F5tCCP47sk2V2jyILjZoi1WqaWK7r4i6k878FQP2WXMoOzdSKTdO90eX2rTUMfzHPe7qduHHNZjM+wzDfDYFL7XK75q2Mi1myNNb/5DJdy91KE3GnHRbz17YIGezhAmARHDijuC8pO3+Xw7kBAeeucA7qBmXDf0ZZbJ9TNttnlMPxMeMkBnmGOS7yTI8kcR2yzLbcY/7/AUAUqH0iTx68R1SPxFG9IksdETjqkCRwezU0VxzjeTE7PV1ZuDDzwQf+Fk5WVpId+fwIAJ6jemWJa1MkoUmTpVpDl3YF6sYGYrZUrJnidsUlbldMebtiSDsUUylVdG2n7nJt0wxPiSS520hSP485tLuYw32HoWJPaHJmmddV+K7bVbBS4lNaMZvrp5EREoSHcSMR4exIZAQN1kgabBb6a4eV+HWALNhXDotjBIuygdNq+4Jw2D+lcPwGS1HnOI45jJiJJFVUuN2BR4ntEARmH89TBwSePCjx1AGZZ7oVnt4nseRhgSFO8gx5QpL4DpdLX5+cGJ9fmJMT/B8l4FDh5q/aS4Q8IbdXXyWIzD6Bp3tk8VsJEKtMXS5FzEcgBGyBK2ALilVTLkYASIZYIaOpFV0r1QyzRFHNepbVjxC4OoQ7tI9JzDUkMLE9KCZQpZQahoo5abXIX0REcBARxUGkhYMoCz1isdAjVgs1YrESgMhqwcBmcYDdYgPMavvS6bB/SuLYTYYiLvIsfYzn6QOCyHaJEtchiEwnLzBoMex+9HuRpw/IItutiuweVWC6kB3gKOc5lnKeEwR2n2GoJTExnteystKjvzNT/G82bf1VbQPyif2x0S9LKt+M/nhJYtuRbkVfmoAACBTuNalMNYQyNaD7BeQhbUck62JVAABTK9UN9zZNc5cJgtFFUco5zCHdcTrkn9K4fpWjPUdZOrrfiWm3LVH8SFQUC1FW9mubnfuV3cH+zOFgPnU46J/ZHdTPbHbqM7vd+Su7Dfu13Wb/ArPbfkk4bJ+QTscwRRKXWIY8xXHMEZ5negNMF5i9nED38Dzdg55LgSl6plMV2Q6Jo/ZzjPMkQ+EXWZo4LcvCbtQp7na7ViYkxC1E24b/AwD+aue3Zcrk5Lgsw1C2iSLbhURZktlWXRcDXhCaQkQTKorK1yNSDaFSMwOF71I0+CFraqVuGDtMV/R6w/BskWVXI8OoRwmnMOywcb/AbNwvcYf4MeaQPrbZ+F9ZLAxYrcxXdgf3Ke4UrhOkcJmihPMUJZ6haP40RfNnKIq5SBDUoNPpvOV02m8TuOMGSeADNEVcZGjyDMsQJ1mW7Od4+hDHU70cTx1C39AnCNR+9Bkkke2WkFRwVB9DO88ylPMcUq9Imr1e833ULR4b630hOzuduu/fR4PKcDk5qaTP534D6VNWoA+KEtuOdk0YKCjThDI0lRIYlFb5BjSzFYgFDKkMDc9pmlZumq6tLrdnLQJB1127BEHdRxL8gN1KfWGNIsFqIb+2WuivrDbqC6uN/rXDwX5CEMIATYuneU7pE3n5gCDIeyVJ7hBFqZvnhYMsyx6nKOoiReFXA0Q6L9MUeR612HMMeeIbAPq+AaAXARCQAp7uQeNYHEce5ljyOAIAPSLbhr4Sy++P/sn/X92VxshxFWEJcSn8In9ASPwKEOUP/Ihw7Dn6eN3vvX7dPdMzszs9Mz0997hnGU6Q+wAACuhJREFUx7vxxo5t7CSwcrgicmEFIiVAIEIk2CQmCZtsHO/hK47t9fq2gy9ibGMUriCCyPEDo+/NGKxIHCFIu7RU6tlZrVaqqlfHV6+qSsXc3UE4eGcU1VPz3VP894QM60HclDVO0dZqkd3pjP0ErqfgGribtp5Ky0Y5axyUlj274mnXdcZTKXdz7y5R7pHsQP67npd9zHFSW4nOzsZj2tuLFyUvL74peXnJEvWvS2L6W/EE+aOmsoumIY5b3N1rWc5223ambDs1advOpC3sGcuydlFG56hBThCinTQM7efQfGaSo8w0DzJqznFuzMJk4sRKB8zIvitMlyfE1I7hM77DaUilxLOYK1Hwc/eVSgNfq1SKt3a7TTY2z2Pw5T/dsGHDh1qtSiHtiSdNUzuKI43PAOO8rLMRn+ETUrJl1Bp3XGvCdq3nZbN0yn0ad4mQE2QyuUezWe+HrutOEMJOJuLqX5aA+XCqMeXNeFx/PZk0fgvhMCrmhOXuAPOFENO2bU+BhBDbLIvtpsyYo5QcoSY5BpLMZ8ZBzsz9Fmd7QJybe6HxIEb1OTDdIOopoitnYXYsZsxB8+HLsEjUz3kPF/K5+4Pi4J24vt5fBCF7CBD54DTM27ibbrdhItoxqHrCpNphdCIie8RJSEl/YG+GECAA4fBpYbMZdC26rv0zz3OfTKdTT3ietzGT8R53XWeCUnZYVbTfxGPKGxBEIqG9lkxqf1AU/VVC6CnGrFnbtreB+UJYM0JY07YtJvFGtCJNCyMHwHTGTNABMJ8zNssZ24/vsYEVjDYN7WWYGoMoZ3Qt+UuiJc4bRD0juLkv6zkbMdQpDIt3hMHgWFAc/Gq5nP9ivV5ud7tL1asE8MEwDD8yH5tU+3OGEBdnHsIJMAz1BPwBmA5BwOTIU+CJJ+GIhUOnLWFstx1zynHphOzjlYmb81Q67fzUccQWy+J7CCEnNU2/oKraRVXVLimK8qqmahcNg5xgnM1yi+8Sgu0Ew+E8IVQQwsl+YjjHKTnAmbG/x3w6C2H0+t3Uk0RLniN64gLRk69A66H9BlFO43c4DbZg2zDWrF4tjTablWarXu6Uy4XVlUppNX6GALBd6io+zJ8ZWrt27UfL5fzt3CKz2LrBLWOPjWzT5RMQgJexfwLMKOVZT2PJGzYjORKHQbcNfzYFcjDRxHoOAhDC2mFZfC+l5iHTNI4Top/Sdf0sHKkJc8LprGXR3X0bLt9cmDsBCAIWwT4z01SPIXwEwQeYRDtJNOWcpiYu6Vr8V7qWuEiIchZOmTNywOLGXmGZiIJmHIdvyXruJj8/8EAYFtfUasWbq2FxBZiPpdKddiMLpVsQ1bErD8Z+YfFPb3+YelwmNg6dhumR90g9SZvSQExTvWsgEIAUgkv72AwHRLDVsfmUI/i0LdhOzoxZxshBTskhzsjBXtRiImp5CZGLTKwssptbuiyiUKoeMYzky6apnDSIdhoRkK4p53Ut/mslGXtNSS7+k67FLkEwCDnR7wY7n/Xcx9A96eezD2JOBiKeQmHwPoy3xEibUiF7D6ZrYWv3quXdz+KKzoIA5K4M/Ot2WzcM5NPfMal2CNuuTQBZNp2BAGQ27Dkb5TvrbEp5fDNg7J4AjC1yohWE4NCtPYyebwE5Npu0hbkDkUiPjF0Ax6CtIM71WRBj6pxpJo8amPyO4eMk/gohybOEKKchBCkIknxF1+IXDJI8B43HvCCsRQez4VyLfu7uoJhfXykXbofWB4F/h+8P3DuY8x4eyKUeQQTUaITDIyOdeL8jcsE8Vxr6rq3Ww5FUWjwD5l8RAKIfWSdIXfVO8Wd6mm9udRwyKYcCuvR5DFhKuWw87ViAi7divJgkh20FOTadRKYqGNlnSbRSO0ipcsg0k8cJif1C12+6oGmLL8k5R0byDE6Ozc1dLv4+ZT0nuzs9Z5PvZ75VLhdur9SCW8OwuC4M/DuDIL++UimsrlaDFRjkF4b+OoScQXHg62E4OIaFoMuWNZV5n7L7ry5twTHl/ewDXJCXKNWOcMvYJRMwl0/APDkuUEhpdl5wbHMKGLxrkylX6NMojKcd9pznsvGUbW5xLGO7I+g2MB4FFCkEQbcJy3jRkg5WO8SpepjT5GFmxE8Y2uJzRFt8XteXnCckcYpzfR+GcsgQMp99oBj4d4WBfwfGFbfb1erSpc2BqFUvVKulLm5BB4G/rlYLhmu1YKheL48i1q/Xw5EoqueXLYsSuPl8L64n9k/8Qnv6p2DZp6A10H5NT5xHSNpjPJ9AZGQ7bEo45jR8g5zhJoxpyXyhb3NtMoNarWubUzYnO23UFyQZQCdftLmx16b6AU61I8xUjnKqHsEJEFSds6g6h7fg6j5AyymXPYtE0Pez30ToGAb+WK0WrEH4CMZ3Om0vilr5RiOstlqVWrNZqcC2R616Dg4W44yxg7gz0lm0vNX62LxXv96NGSoW8+uJoZyOJ256HQ5ZAFtx6At9AUwK25zBbQNZhRL/wOJtS9/dw+KNvRbT96MkCC2XlSlTOyxRSV05S4lyhpnqccHJfluQnQ6wJ9caz6bFpjxsdSF3f9+crIRGI3qphoUvIIKBGYmiZqbdrpYwqA8RDX5esWLkc7jtsHLl8GdGR4euR1fM2JhEO9+JdC7Yp3+FfezDQVhcQwz11JLY5y9jGZxJ1WPYA2Y75pTtcODvM8DgIQCcAjARTOec7JeRDiAAqh3umRjtEGP6QQ7NN/Uj3NQPI7aXiKVrjecy9uMDA94jft57sOTn7g6D/PpapXgrYnZoNkxNs1lZWq+WRlDNajSqVYzl7HTa2Xa74UdR0xjtgNkyg8XShvdD2y/PJ8T8Xv1Ao1EdFA7bHk/c9OdYfNEbqpa4SMFMYe60HT7VS5joNnkKsCnPMlAMkZkrBGCZMtyctSU2b253bD6J6VaYdDuQSf1IRi6w6cXcXYhUKuXS6jAM1lTKhbXlUuG2alhYVQuLy6vV0gjsOQZPYYtqtxuxbjfSsVkbGo4LVv8GOvj/YPpVTz8c7X6yXMl/CUUa7KPERm1s1japdkQmTcLcgUIITsWVROpKMQTmyhV8Ou2ICWTSiM2h4QU/t6FUyH8ZjK7Vyrdg3jM0u92ulaUzjeoFZKeoVtWr0oHeUqmUVjYaYXdINtp1b0AhfUxeJX/vXSx9yGFBCqg35GN4+BOVWvlmaHtSif0+Fl/0dlKJ/Y4YyhkgpjKB6glgTw9KYDOOY014nrsxl/N+kM8PfLtQyN9TLPpfCcNgDIyvN2FCahGoVqsM4R1FrWBoqO0OD3e04eFoSbe7NAaQLIpaVm95c6TcHEXX/RNN/68ZOK/A27txyOVKYTXj5GAsvujNWHzRW4oafxVYkcxiBd3JBYNZmgQGlM1mvu/7+W+Uy6XbGrXa8matNtRoVBvNZq3eajUa7WazDqZXq+VRUKVSvqVer7ajqOssX7780/05bxgr+b7+Xsdr3hG9/C9t+dU7Zhakj5CF6VXLln08CPOrbJvNaCRxTtMTFxCa9tHQLXKInmdvzuUyj/q+f18YBOvq9Wqn3W6W2+32IOCNdrudbbXqeXzXbNabEEK73UAcX+x0OnR0dPR6OP/58nmYJ7Gi1br2xujGDyzUyOga3KnMDXrfw3ZsCdBl7R/L5r6BzENI3FBRCwJ/PTS71arXWlE9j1tozaiZiaKmA3OydGip6HRaFG2jURRdB5teq4Hx81sWRHEepdn/pD31b6z/bhRQkGzgAAAAAElFTkSuQmCC"
};
function K({ name: e, size: t = 18 }) {
	return /* @__PURE__ */ v("img", {
		src: Le[e],
		alt: "",
		draggable: !1,
		className: "inline-block flex-none object-contain",
		style: {
			width: `calc(${t} * var(--gz-icon-unit, 1px))`,
			height: `calc(${t} * var(--gz-icon-unit, 1px))`
		}
	});
}
var Re = ({ color: e, size: t }) => /* @__PURE__ */ v(K, {
	name: e,
	size: t
});
function ze({ e, small: t }) {
	let n = e.on === "file" ? "file" : e.on === "pick" || e.on === "pick2" ? "pick" : "build", r = e.on === "pick2" || e.on === "build2" ? e.colors : e.on === "pick" || e.on === "build" ? [e.color] : [];
	return /* @__PURE__ */ y("span", {
		className: "gz-card__cause",
		children: [
			/* @__PURE__ */ v(K, {
				name: n,
				size: t ? 16 : 22
			}),
			r.length > 0 && /* @__PURE__ */ v("span", {
				className: "gz-card__condition",
				children: r.map((e) => /* @__PURE__ */ v(Re, {
					color: e,
					size: t ? 8 : 12
				}, e))
			}),
			e.on === "buildArchive" && /* @__PURE__ */ v("span", {
				className: "gz-card__condition",
				children: /* @__PURE__ */ v(K, {
					name: "file",
					size: t ? 9 : 12
				})
			}),
			e.on === "buildTier2" && /* @__PURE__ */ v("span", {
				className: "gz-card__condition font-mono text-[10px] leading-none font-black",
				children: "Ⅱ"
			})
		]
	});
}
function Be({ fx: e, small: t }) {
	let n = e.startsWith("draw") ? "draw" : e.startsWith("pick") ? "pickEffect" : e.startsWith("vp") ? "vp" : e === "file" ? "file" : e === "research" ? "research" : "build", r = e === "draw3" ? 3 : e === "pick2" || e === "vp2" ? 2 : null;
	return /* @__PURE__ */ y("span", {
		className: "gz-card__result relative inline-flex flex-none items-center",
		children: [
			/* @__PURE__ */ v(K, {
				name: n,
				size: t ? 17 : 23
			}),
			r && /* @__PURE__ */ y("span", {
				className: "absolute -right-1.5 -bottom-1 rounded-sm bg-surface px-px font-mono text-[9px] leading-3 font-black text-ink",
				children: ["×", r]
			}),
			e === "freeBuild1" && /* @__PURE__ */ v("span", {
				className: "font-mono text-[9px] font-black",
				children: "Ⅰ"
			})
		]
	});
}
function Ve({ e, small: t }) {
	let n = t ? 11 : 16, r = e.conv === "anyToAny" ? ["any"] : e.conv === "pairDouble" ? e.pair ?? [] : [e.color ?? "any"], i = e.conv === "toAny" || e.conv === "anyToAny" || e.conv === "oneOrTwoToAny" ? ["any"] : e.conv === "pairDouble" ? e.pair ?? [] : [e.color ?? "any"];
	return /* @__PURE__ */ y("span", {
		className: "gz-card__conversion inline-flex min-w-0 items-center gap-px",
		children: [
			r.map((e, t) => /* @__PURE__ */ v(Re, {
				color: e,
				size: n
			}, `${e}${t}`)),
			/* @__PURE__ */ v(K, {
				name: "convert",
				size: t ? 12 : 15
			}),
			e.conv !== "pairDouble" && i.map((e, t) => /* @__PURE__ */ v(Re, {
				color: e,
				size: n
			}, `${e}${t}`)),
			(e.conv === "double" || e.conv === "pairDouble") && /* @__PURE__ */ v("span", {
				className: "font-mono text-[9px] font-black",
				children: "×2"
			}),
			e.conv === "oneOrTwoToAny" && /* @__PURE__ */ v("span", {
				className: "font-mono text-[9px] font-black",
				children: "≤2"
			})
		]
	});
}
function He({ e, small: t }) {
	let n = t ? 14 : 21;
	if ("add" in e && e.add) {
		let t = [];
		return e.add.storage && t.push({
			icon: "storage",
			n: e.add.storage
		}), e.add.file && t.push({
			icon: "file",
			n: e.add.file
		}), e.add.research && t.push({
			icon: "research",
			n: e.add.research
		}), /* @__PURE__ */ v("span", {
			className: "gz-card__upgrade inline-flex items-center gap-0.5",
			children: t.map(({ icon: e, n: t }) => /* @__PURE__ */ y("span", {
				className: "inline-flex flex-col items-center",
				children: [/* @__PURE__ */ v(K, {
					name: e,
					size: n
				}), /* @__PURE__ */ y("span", {
					className: "font-mono text-[9px] leading-[9px] font-black",
					children: ["+", t]
				})]
			}, e))
		});
	}
	return "ban" in e && e.ban ? /* @__PURE__ */ y("span", {
		className: "gz-card__upgrade inline-flex items-center",
		children: [/* @__PURE__ */ v(K, {
			name: e.ban === "file" ? "file" : "research",
			size: n
		}), /* @__PURE__ */ v("span", {
			className: "font-mono text-sm font-black text-danger",
			children: "×"
		})]
	}) : "discount" in e && e.discount ? /* @__PURE__ */ y("span", {
		className: "gz-card__upgrade inline-flex items-center gap-px",
		children: [
			/* @__PURE__ */ v(K, {
				name: "build",
				size: n
			}),
			/* @__PURE__ */ v("span", {
				className: "font-mono text-[10px] font-black",
				children: "−1"
			}),
			e.discount === "tier2" ? /* @__PURE__ */ v("span", {
				className: "font-mono text-[10px] font-black",
				children: "Ⅱ"
			}) : /* @__PURE__ */ v(K, {
				name: e.discount === "archive" ? "file" : "research",
				size: t ? 11 : 16
			})
		]
	}) : /* @__PURE__ */ y("span", {
		className: "gz-card__upgrade inline-flex items-center gap-px",
		children: [
			/* @__PURE__ */ v(K, {
				name: "vp",
				size: n
			}),
			/* @__PURE__ */ v("span", {
				className: "font-mono text-[9px] font-black",
				children: "/"
			}),
			/* @__PURE__ */ v(K, {
				name: "award" in e && e.award === "perEnergy" ? "storage" : "vp",
				size: t ? 12 : 19
			})
		]
	});
}
function Ue({ def: e, small: t }) {
	let n = e.effect;
	return n.kind === "converter" ? /* @__PURE__ */ v(Ve, {
		e: n,
		small: t
	}) : n.kind === "upgrade" ? /* @__PURE__ */ v(He, {
		e: n,
		small: t
	}) : /* @__PURE__ */ y("span", {
		className: "gz-card__trigger",
		children: [/* @__PURE__ */ v(ze, {
			e: n,
			small: t
		}), /* @__PURE__ */ v(Be, {
			fx: n.fx,
			small: t
		})]
	});
}
var We = {
	k: "#3f3f46",
	b: "#2563eb",
	r: "#dc2626",
	y: "#eab308"
};
function q({ id: e, w: t = 58, h: n = 76, dim: r = !1, fill: i = !1, adaptive: a = !1, variant: o = "market" }) {
	let s = I(e), c = o === "market" && (a || i || n < 65), l = s.color ? We[s.color] : "#78716c";
	return /* @__PURE__ */ y("span", {
		className: `gz-card gz-card--${o}${a ? " gz-card--adaptive" : ""} relative flex-none overflow-hidden rounded border border-ink bg-gz-paper ${i ? "block size-full" : "inline-flex"} ${r ? "opacity-45" : ""}`,
		style: i ? void 0 : {
			width: t,
			height: n
		},
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("span", {
			className: "gz-card__stripe absolute inset-y-0 left-0 w-1",
			style: { backgroundColor: l }
		}), /* @__PURE__ */ y("span", {
			className: "gz-card__body flex size-full min-w-0 flex-col pl-1",
			children: [/* @__PURE__ */ v("span", {
				className: "gz-card__main flex min-h-0 flex-1 items-center justify-center overflow-hidden px-px",
				children: /* @__PURE__ */ v(Ue, {
					def: s,
					small: c
				})
			}), o === "market" ? /* @__PURE__ */ y("span", {
				className: "gz-card__foot flex h-4 items-center justify-between border-t border-ink/20 pr-0.5 font-mono text-[9px] leading-none font-black tabular-nums",
				children: [/* @__PURE__ */ y("span", {
					className: "gz-card__cost inline-flex items-center gap-px",
					children: [/* @__PURE__ */ v(Re, {
						color: s.color ?? "any",
						size: 11
					}), s.cost]
				}), /* @__PURE__ */ y("span", { children: ["★", s.vp === "award" ? "✳" : s.vp] })]
			}) : /* @__PURE__ */ v("span", {
				className: "gz-card__built-foot h-1.5 border-t border-ink/15",
				style: { backgroundColor: `${l}22` }
			})]
		})]
	});
}
//#endregion
//#region src/games/gizmos/card.tsx
function J({ color: e, size: t = 16 }) {
	return /* @__PURE__ */ v(K, {
		name: e,
		size: t
	});
}
function Ge({ w: e = 34, h: t = 44, tier: n }) {
	return /* @__PURE__ */ v("span", {
		className: "inline-flex flex-none items-center justify-center rounded border-2 border-gz-brass bg-gz-board",
		style: {
			width: e,
			height: t
		},
		"aria-hidden": !0,
		children: n ? /* @__PURE__ */ v("span", {
			className: "font-mono text-sm leading-none font-black text-gz-paper",
			children: [
				"Ⅰ",
				"Ⅱ",
				"Ⅲ"
			][n - 1]
		}) : /* @__PURE__ */ v("span", {
			className: "grid place-items-center rounded-sm bg-gz-paper p-0.5",
			children: /* @__PURE__ */ v(K, {
				name: "upgrade",
				size: Math.min(e, t) * .5
			})
		})
	});
}
//#endregion
//#region src/games/gizmos/view-player.tsx
function Ke(e) {
	for (let t = e.parentElement; t; t = t.parentElement) if (/(auto|scroll)/.test(window.getComputedStyle(t).overflowY)) return t;
	return null;
}
var Y = {
	k: "games.gizmos.energyK",
	b: "games.gizmos.energyB",
	r: "games.gizmos.energyR",
	y: "games.gizmos.energyY"
}, qe = {
	draw1: "games.gizmos.fxDraw1",
	draw3: "games.gizmos.fxDraw3",
	pick1: "games.gizmos.fxPick1",
	pick2: "games.gizmos.fxPick2",
	vp1: "games.gizmos.fxVp1",
	vp2: "games.gizmos.fxVp2",
	file: "games.gizmos.fxFile",
	research: "games.gizmos.fxResearch",
	freeBuild1: "games.gizmos.fxFreeBuild1"
};
function X(e, t) {
	let n = e.effect;
	if (e.tier === 0) return `${t("games.gizmos.startCard")}:${t("games.gizmos.trigFile")} → ${t("games.gizmos.fxDraw1")}`;
	if (n.kind === "trigger") {
		let e;
		return e = n.on === "file" ? t("games.gizmos.trigFile") : n.on === "pick" ? t("games.gizmos.trigPick", { c: t(Y[n.color]) }) : n.on === "pick2" ? t("games.gizmos.trigPick2", {
			c1: t(Y[n.colors[0]]),
			c2: t(Y[n.colors[1]])
		}) : n.on === "build" ? t("games.gizmos.trigBuild", { c: t(Y[n.color]) }) : n.on === "build2" ? t("games.gizmos.trigBuild2", {
			c1: t(Y[n.colors[0]]),
			c2: t(Y[n.colors[1]])
		}) : n.on === "buildArchive" ? t("games.gizmos.trigBuildArchive") : t("games.gizmos.trigBuildTier2"), `${e} → ${t(qe[n.fx])}`;
	}
	if (n.kind === "converter") return n.conv === "toAny" && n.color ? t("games.gizmos.convToAny", { c: t(Y[n.color]) }) : n.conv === "anyToAny" ? t("games.gizmos.convAnyToAny") : n.conv === "double" && n.color ? t("games.gizmos.convDouble", { c: t(Y[n.color]) }) : n.conv === "oneOrTwoToAny" && n.color ? t("games.gizmos.convOneOrTwo", { c: t(Y[n.color]) }) : n.conv === "pairDouble" && n.pair ? t("games.gizmos.convPair", {
		c1: t(Y[n.pair[0]]),
		c2: t(Y[n.pair[1]])
	}) : "";
	if ("add" in n && n.add) {
		let e = [];
		return n.add.storage && e.push(t("games.gizmos.upgStorage", { n: n.add.storage })), n.add.file && e.push(t("games.gizmos.upgFile", { n: n.add.file })), n.add.research && e.push(t("games.gizmos.upgResearch", { n: n.add.research })), e.join(" · ");
	}
	return "ban" in n && n.ban ? t(n.ban === "file" ? "games.gizmos.upgBanFile" : "games.gizmos.upgBanResearch") : "discount" in n && n.discount ? t(n.discount === "tier2" ? "games.gizmos.upgDiscTier2" : n.discount === "archive" ? "games.gizmos.upgDiscArchive" : "games.gizmos.upgDiscResearch") : "award" in n && n.award ? t(n.award === "perEnergy" ? "games.gizmos.upgAwardEnergy" : "games.gizmos.upgAwardVp") : "";
}
function Je(e) {
	return /* @__PURE__ */ v(Xe, {
		pub: e.public,
		priv: e.private,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ye({ pub: e, members: t, myRid: n, shownRid: r, text: i, myTurn: a, onSeat: o }) {
	let s = u(), c = l((e) => e.locale);
	return f(a, d), /* @__PURE__ */ y("div", {
		className: "gz-header",
		children: [/* @__PURE__ */ y("div", {
			role: "status",
			className: "gz-phase",
			children: [
				/* @__PURE__ */ v("span", {
					className: "gz-phase__seal",
					"aria-hidden": !0,
					children: "⚙"
				}),
				/* @__PURE__ */ v("span", {
					className: "gz-phase__text",
					children: i
				}),
				e.lastLap && /* @__PURE__ */ v("span", {
					className: "gz-phase__lap",
					children: s("games.gizmos.lastLap")
				})
			]
		}), /* @__PURE__ */ v("div", {
			className: "gz-seats",
			children: t.map((t) => {
				let i = e.players.find((e) => e.rid === t.rid), a = i ? B(i.built, i.storage.length, i.vp) + i.vp : 0;
				return /* @__PURE__ */ y("button", {
					type: "button",
					className: `gz-seat ${r === t.rid ? "gz-seat--shown" : ""} ${e.turn === t.rid && e.phase !== "done" ? "gz-seat--turn" : ""}`,
					onClick: () => o(t.rid),
					children: [/* @__PURE__ */ v(h, {
						m: t,
						myRid: n,
						action: null,
						anchorName: `seat:${t.rid}`,
						box: "size-8",
						img: "size-7"
					}), /* @__PURE__ */ y("span", {
						className: "gz-seat__info",
						children: [/* @__PURE__ */ v("span", {
							className: "gz-seat__name",
							children: g(t, c)
						}), /* @__PURE__ */ y("span", {
							className: "gz-seat__stats",
							children: [
								"★",
								a,
								" · ",
								/* @__PURE__ */ v(J, {
									color: "any",
									size: 10
								}),
								i?.storage.length ?? 0,
								" · ▣",
								i?.built.length ?? 0
							]
						})]
					})]
				}, t.rid);
			})
		})]
	});
}
function Xe({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = u(), o = (e) => n.find((t) => t.rid === e)?.name ?? e, c = e.players.find((e) => e.rid === r), l = e.turn === r && e.phase !== "done", d = c ? R(c.built) : {
		storage: 5,
		file: 1,
		research: 3
	}, f = c ? le(c.built) : {
		file: !1,
		research: !1
	}, [h, g] = s(null), [b, x] = s(null), [S, C] = s(!1), [w, T] = s(null), E = `${e.phase}:${e.turn}:${e.pending?.map((e) => `${e.cardId}:${e.left}`).join("|") ?? ""}:${e.research?.tier ?? 0}`, [ee, te] = s(E);
	ee !== E && (te(E), x(null), C(!1), T(null));
	let D = h ?? r, O = e.players.find((e) => e.rid === D), k = e.phase === "research" && l ? t?.researchCards ?? null : null, A = a("games.gizmos.waitTurn", { name: o(e.turn) });
	l && (A = e.phase === "research" ? a("games.gizmos.researchPrompt") : e.pending && e.pending.length > 0 ? a("games.gizmos.comboStatus", { n: e.pending.length }) : a("games.gizmos.myTurn"));
	let j = /* @__PURE__ */ v(Ye, {
		pub: e,
		members: n,
		myRid: r,
		shownRid: D,
		text: A,
		myTurn: l,
		onSeat: (e) => g(e === r ? null : e)
	}), M = w ? I(w) : null, N = M && M.effect.kind === "trigger" ? M.effect.fx : null, P = w ?? e.pending?.[0]?.cardId, F = P ? I(P) : null, ne = (e.pending?.findIndex((e) => e.cardId === P) ?? -1) + 1, re = l && N !== null && (N === "pick1" || N === "pick2"), ie = l && N === "file", ae = l && N === "freeBuild1", L = b ? I(b.cardId) : null, oe = (t) => {
		if (D !== r) {
			x({
				cardId: t,
				from: "built"
			});
			return;
		}
		if (l && e.pending?.some((e) => e.cardId === t)) {
			let e = I(t).effect;
			if (e.kind === "trigger" && (e.fx === "draw1" || e.fx === "draw3" || e.fx === "vp1" || e.fx === "vp2")) {
				i({
					type: "resolve",
					cardId: t
				});
				return;
			}
			x(null), T(w === t ? null : t);
			return;
		}
		x({
			cardId: t,
			from: "built"
		});
	}, se = (t) => {
		if (l && e.phase === "action") {
			if (re && w) {
				i({
					type: "resolve",
					cardId: w,
					index: t
				}), T(null);
				return;
			}
			e.pending || i({
				type: "pick",
				index: t
			});
		}
	}, ce = (t, n) => {
		let r = e.market[t][n];
		if (r) {
			if (ie && w) {
				i({
					type: "resolve",
					cardId: w,
					target: r
				}), T(null);
				return;
			}
			if (ae && w) {
				I(r).tier === 1 && (i({
					type: "resolve",
					cardId: w,
					target: r
				}), T(null));
				return;
			}
			x({
				cardId: r,
				from: "market"
			});
		}
	}, z = "btn-quiet h-11 flex-none px-3 text-xs", B = null;
	b && L && !S ? B = /* @__PURE__ */ y("div", {
		className: "flex h-full items-center gap-1.5 overflow-x-auto",
		children: [
			b.from === "market" && l && e.phase === "action" && !e.pending && !f.file && /* @__PURE__ */ v("button", {
				type: "button",
				className: z,
				disabled: (c?.archive.length ?? 0) >= d.file,
				onClick: () => {
					i({
						type: "file",
						cardId: b.cardId
					}), x(null);
				},
				children: a("games.gizmos.actFile")
			}),
			(b.from === "market" || b.from === "archive" || b.from === "research") && l && (e.phase === "action" || e.phase === "research") && !e.pending && /* @__PURE__ */ y("button", {
				type: "button",
				className: "btn-base h-11 flex-none px-3 text-xs",
				onClick: () => C(!0),
				children: [
					a("games.gizmos.actBuild"),
					" (",
					c ? Ee(c.built, b.cardId, b.from === "archive", b.from === "research") : L.cost,
					")"
				]
			}),
			b.from === "research" && l && e.phase === "research" && (c?.archive.length ?? 0) < d.file && /* @__PURE__ */ v("button", {
				type: "button",
				className: z,
				onClick: () => {
					i({
						type: "researchTake",
						mode: "file",
						cardId: b.cardId
					}), x(null);
				},
				children: a("games.gizmos.actFile")
			}),
			/* @__PURE__ */ v("button", {
				type: "button",
				className: z,
				onClick: () => x(null),
				children: a("games.gizmos.cancel")
			})
		]
	}) : l && e.phase === "action" && (B = e.pending && e.pending.length > 0 ? /* @__PURE__ */ y("div", {
		className: "flex h-full items-center gap-1.5 overflow-x-auto",
		children: [N === "research" ? [
			1,
			2,
			3
		].map((t) => /* @__PURE__ */ v("button", {
			type: "button",
			className: z,
			disabled: e.deckCounts[t - 1] === 0,
			onClick: () => {
				i({
					type: "resolve",
					cardId: w,
					tier: t
				}), T(null);
			},
			children: a("games.gizmos.tierLabel", { n: t })
		}, t)) : /* @__PURE__ */ y("div", {
			className: "gz-footer__pending min-w-0 flex-1",
			children: [/* @__PURE__ */ v("span", {
				className: "gz-footer__pending-marker",
				children: ne
			}), /* @__PURE__ */ y("span", {
				className: "min-w-0",
				children: [/* @__PURE__ */ v("strong", { children: F ? X(F, a) : a("games.gizmos.pendingPrompt") }), /* @__PURE__ */ v("small", { children: a(w ? N === "pick1" || N === "pick2" ? "games.gizmos.pickPrompt" : N === "file" ? "games.gizmos.filePrompt" : N === "freeBuild1" ? "games.gizmos.buildFreePrompt" : "games.gizmos.pendingPrompt" : "games.gizmos.pendingPrompt") })]
			})]
		}), /* @__PURE__ */ v("button", {
			type: "button",
			className: `${z} text-danger`,
			onClick: () => i({ type: "skipTriggers" }),
			children: a("games.gizmos.skipTriggers")
		})]
	}) : /* @__PURE__ */ y("div", {
		className: "flex h-full items-center gap-1.5 overflow-x-auto",
		children: [/* @__PURE__ */ y("span", {
			className: "flex-none text-[11px] font-bold opacity-70",
			children: [a("games.gizmos.actResearch"), ":"]
		}), [
			1,
			2,
			3
		].map((t) => /* @__PURE__ */ y("button", {
			type: "button",
			className: z,
			disabled: f.research || e.deckCounts[t - 1] === 0,
			onClick: () => i({
				type: "research",
				tier: t
			}),
			children: [a("games.gizmos.tierLabel", { n: t }), /* @__PURE__ */ v("span", {
				className: "ml-1 font-mono tabular-nums opacity-70",
				children: e.deckCounts[t - 1]
			})]
		}, t))]
	}));
	let V = /* @__PURE__ */ y(_, { children: [k && !S && /* @__PURE__ */ y("div", {
		className: "gz-overlay gz-research pointer-events-auto mx-2 rounded-xl border-2 border-ink bg-surface p-2",
		children: [
			/* @__PURE__ */ v("p", {
				className: "mb-1 text-xs font-extrabold",
				children: a("games.gizmos.researchTitle", { n: e.research?.tier ?? 1 })
			}),
			/* @__PURE__ */ v("div", {
				className: "flex gap-1.5 overflow-x-auto pb-1",
				children: k.map((e) => /* @__PURE__ */ y("button", {
					type: "button",
					"aria-label": X(I(e), a),
					className: "relative flex-none rounded",
					onClick: () => x({
						cardId: e,
						from: "research"
					}),
					children: [/* @__PURE__ */ v("span", {
						className: "gz-research-card",
						children: /* @__PURE__ */ v(q, {
							id: e,
							fill: !0,
							adaptive: !0
						})
					}), /* @__PURE__ */ v(m, { radius: 3 })]
				}, e))
			}),
			/* @__PURE__ */ v("button", {
				type: "button",
				className: "btn-quiet mt-1 h-11 w-full text-xs",
				onClick: () => i({
					type: "researchTake",
					mode: "none"
				}),
				children: a("games.gizmos.researchNone")
			})
		]
	}), b && L && S && c && /* @__PURE__ */ v(lt, {
		def: L,
		me: c,
		used: e.used,
		effCost: Ee(c.built, b.cardId, b.from === "archive", b.from === "research"),
		onCancel: () => C(!1),
		onConfirm: (e) => {
			b.from === "research" ? i({
				type: "researchTake",
				mode: "build",
				cardId: b.cardId,
				pay: e
			}) : i({
				type: "build",
				cardId: b.cardId,
				from: b.from === "archive" ? "archive" : "market",
				pay: e
			}), C(!1), x(null);
		}
	})] }), ue = l && e.phase === "action" && (re || !e.pending) && (re || (c ? c.storage.length < d.storage : !1)), H = l && e.phase === "action" && !e.pending, U = (t, n) => c ? De(c, t, n, !1, e.used) !== null : !1, de = /* @__PURE__ */ v("div", {
		className: "gz-footer",
		children: B ?? /* @__PURE__ */ y("div", {
			className: "gz-footer__hint",
			children: [/* @__PURE__ */ v("strong", { children: a("games.gizmos.engineTitle") }), /* @__PURE__ */ v("span", { children: A })]
		})
	});
	return /* @__PURE__ */ v("div", {
		className: "gz-screen h-full",
		children: /* @__PURE__ */ v(p, {
			adaptive: !0,
			className: "gz-layout",
			scroll: !1,
			banner: j,
			actions: de,
			actionsHeight: "gz-actions",
			overlay: V,
			children: /* @__PURE__ */ y("div", {
				className: "gz-table",
				children: [/* @__PURE__ */ y("div", {
					className: "gz-market-side",
					children: [/* @__PURE__ */ v(Ze, {
						row: e.row,
						supplyCount: e.supplyCount,
						canPick: ue,
						highlight: re,
						onPick: se
					}), /* @__PURE__ */ v(et, {
						pub: e,
						onCard: ce,
						highlight: ie ? "any" : ae ? "t1" : null,
						hint: H ? (e) => U(e, !1) : void 0
					})]
				}), O && /* @__PURE__ */ v(st, {
					t: a,
					p: O,
					used: e.used,
					isMe: D === r,
					pending: D === r && l ? e.pending : null,
					pendSel: w,
					detail: L ? X(L, a) : F ? X(F, a) : null,
					detailCard: L ?? F,
					isPendingDetail: !L && !!F,
					hintArchive: H && D === r ? (e) => U(e, !0) : void 0,
					onCard: (e, t) => t === "built" ? oe(e) : x({
						cardId: e,
						from: t
					})
				})]
			})
		})
	});
}
function Ze({ row: e, supplyCount: t, canPick: n, highlight: r, onPick: i }) {
	let a = u(), { ref: o } = c("supply");
	return /* @__PURE__ */ y("div", {
		className: "gz-energy-row flex flex-none items-center gap-1.5",
		children: [/* @__PURE__ */ v("div", {
			className: "gz-energy-track flex min-w-0 flex-1 items-center justify-around rounded-xl border-2 border-gz-brass bg-gz-board px-1 py-1 wide:py-0",
			children: e.map((e, t) => /* @__PURE__ */ v(Qe, {
				index: t,
				color: e,
				canPick: n,
				highlight: r,
				onPick: i
			}, t))
		}), /* @__PURE__ */ y("span", {
			ref: o,
			"data-gizmos-anchor": "supply",
			className: "gz-supply flex h-11 w-[90px] flex-none items-center justify-center gap-1 rounded-lg border-2 border-gz-brass bg-gz-board px-1 text-center font-mono text-[9px] leading-3 font-bold tabular-nums text-gz-paper",
			children: [/* @__PURE__ */ v(K, {
				name: "draw",
				size: 22
			}), /* @__PURE__ */ v("span", { children: a("games.gizmos.supplyCount", { n: t }) })]
		})]
	});
}
function Qe({ index: e, color: t, canPick: n, highlight: r, onPick: i }) {
	let a = u(), { ref: o } = c(`energy:${e}`);
	return /* @__PURE__ */ y("button", {
		ref: o,
		"data-gizmos-anchor": `energy:${e}`,
		type: "button",
		"aria-label": a(Y[t]),
		className: "gz-energy-slot relative grid size-11 flex-none place-items-center rounded-full border border-gz-brass/60 bg-gz-well",
		onClick: () => n && i(e),
		children: [/* @__PURE__ */ v(J, {
			color: t,
			size: 28
		}), r && /* @__PURE__ */ v(m, { radius: 999 })]
	});
}
function $e({ tier: e, count: t }) {
	let n = u(), { ref: r } = c(`deck:${e}`);
	return /* @__PURE__ */ y("div", {
		ref: r,
		"data-gizmos-anchor": `deck:${e}`,
		className: "gz-deck flex w-9 flex-none flex-col items-center gap-0.5",
		children: [/* @__PURE__ */ v(Ge, {
			w: 23,
			h: 27,
			tier: e
		}), /* @__PURE__ */ v("span", {
			className: "font-mono text-[9px] font-bold tabular-nums opacity-70",
			children: n("games.gizmos.deckCount", { n: t })
		})]
	});
}
function et({ pub: e, onCard: t, highlight: n, hint: r }) {
	let i = u();
	return /* @__PURE__ */ y("div", {
		className: "gz-market flex flex-none flex-col gap-1 wide:gap-0.5",
		children: [/* @__PURE__ */ y("div", {
			className: "gz-market__heading",
			children: [/* @__PURE__ */ v("strong", { children: i("games.gizmos.marketTitle") }), /* @__PURE__ */ v("span", { children: i("games.gizmos.marketLegend") })]
		}), [
			2,
			1,
			0
		].map((i) => /* @__PURE__ */ y("div", {
			className: "gz-market__shelf flex items-center gap-1 rounded-md border border-ink/50 bg-gz-wood p-0.5 shadow-[inset_0_-3px_0_var(--color-gz-brass)] wide:py-0",
			children: [/* @__PURE__ */ v($e, {
				tier: i + 1,
				count: e.deckCounts[i]
			}), /* @__PURE__ */ v("div", {
				className: "grid min-w-0 flex-1 gap-0.5",
				style: { gridTemplateColumns: `repeat(${se[i]}, minmax(0, 1fr))` },
				children: Array.from({ length: se[i] }, (a, o) => {
					let s = e.market[i][o], c = n === "any" || n === "t1" && s !== null && I(s).tier === 1 || s !== null && (r?.(s) ?? !1);
					return /* @__PURE__ */ v(tt, {
						tier: i,
						slot: o,
						id: s,
						hl: c,
						onCard: t
					}, o);
				})
			})]
		}, i))]
	});
}
function tt({ tier: e, slot: t, id: n, hl: r, onCard: i }) {
	let a = u(), { ref: o } = c(`m${e + 1}-${t}`);
	return n ? /* @__PURE__ */ y("button", {
		ref: o,
		"data-gizmos-anchor": `m${e + 1}-${t}`,
		type: "button",
		"aria-label": X(I(n), a),
		className: "gz-market-card relative mx-auto block h-11 w-full max-w-[68px] rounded",
		onClick: () => i(e, t),
		children: [/* @__PURE__ */ v(q, {
			id: n,
			fill: !0,
			adaptive: !0
		}), r && /* @__PURE__ */ v(m, { radius: 3 })]
	}) : /* @__PURE__ */ v("span", { className: "gz-market-card gz-market-card--empty mx-auto block h-11 w-full max-w-[68px] rounded border-2 border-dashed border-ink/20" });
}
var nt = [
	{
		key: "file",
		icon: "file",
		label: "games.gizmos.actFile"
	},
	{
		key: "pick",
		icon: "pick",
		label: "games.gizmos.actPick"
	},
	{
		key: "build",
		icon: "build",
		label: "games.gizmos.actBuild"
	},
	{
		key: "converter",
		icon: "convert",
		label: "games.gizmos.columnConvert"
	},
	{
		key: "upgrade",
		icon: "upgrade",
		label: "games.gizmos.columnUpgrade"
	}
];
function rt(e) {
	let t = I(e).effect;
	return t.kind === "trigger" ? t.on === "file" ? "file" : t.on === "pick" || t.on === "pick2" ? "pick" : "build" : t.kind;
}
function it({ id: e, rid: t, hint: n, onClick: r }) {
	let i = u(), { ref: a } = c(`archive:${t}:${e}`);
	return /* @__PURE__ */ y("button", {
		ref: a,
		"data-gizmos-anchor": `archive:${t}:${e}`,
		type: "button",
		"aria-label": X(I(e), i),
		className: "gz-archive-card relative grid size-11 flex-none place-items-center rounded",
		onClick: r,
		children: [/* @__PURE__ */ v(q, {
			id: e,
			w: 34,
			h: 42,
			adaptive: !0
		}), n && /* @__PURE__ */ v(m, { radius: 3 })]
	});
}
function at({ id: e, rid: t, used: n, pending: r, remaining: i, selected: a, order: o, onClick: s }) {
	let l = u(), { ref: d } = c(`built:${t}:${e}`);
	return /* @__PURE__ */ y("button", {
		ref: d,
		"data-gizmos-anchor": `built:${t}:${e}`,
		type: "button",
		"aria-label": `${X(I(e), l)}${r ? ` · ${l("games.gizmos.pendingOrdinal", { n: r })}` : n ? ` · ${l("games.gizmos.usedCard")}` : ""}`,
		"aria-pressed": a,
		className: `gz-built-card relative block w-full flex-none rounded text-left ${a ? "gz-built-card--selected" : r === 1 ? "gz-built-card--next" : r ? "gz-built-card--pending" : ""}`,
		style: { zIndex: a ? 30 : o + 1 },
		onClick: s,
		children: [
			/* @__PURE__ */ v(q, {
				id: e,
				fill: !0,
				adaptive: !0,
				variant: "built",
				dim: n && !r
			}),
			r > 0 && /* @__PURE__ */ y("span", {
				className: "gz-pending-badge absolute grid h-4 min-w-4 place-items-center rounded-full border border-ink bg-amber-300 px-0.5 font-mono text-[9px] leading-none font-black text-ink",
				children: [r, i > 1 ? `×${i}` : ""]
			}),
			n && r === 0 && /* @__PURE__ */ v("span", {
				className: "gz-used-badge absolute rounded-tl bg-ink px-0.5 text-[10px] leading-3 font-bold text-surface",
				children: "✓"
			})
		]
	});
}
function ot({ root: e, rid: t, pending: n }) {
	let [r, a] = s([]);
	return i(() => {
		if (!n?.length) return;
		let r = 0, i = null, o = null, s = () => {
			let r = e.current;
			if (!r) return;
			let i = r.getBoundingClientRect(), s = o?.getBoundingClientRect();
			if (!s) return;
			let c = {
				top: Math.max(s.top, i.top),
				bottom: Math.min(s.bottom, i.bottom)
			};
			if (c.bottom <= c.top) {
				a([]);
				return;
			}
			let l = Array.from(r.querySelectorAll("[data-gizmos-anchor]"));
			a(n.map(({ cardId: e }) => {
				let n = l.find((n) => n.dataset.gizmosAnchor === `built:${t}:${e}`), r = n?.closest(".gz-column");
				if (!n || !r) return null;
				let a = n.getBoundingClientRect();
				return {
					x: r.getBoundingClientRect().right - i.left + 4,
					y: Math.max(c.top + 9, Math.min(a.top + Math.min(20, a.height / 2), c.bottom - 9)) - i.top,
					hidden: a.bottom <= c.top || a.top >= c.bottom
				};
			}));
		}, c = () => {
			let t = e.current;
			if (!t) {
				r = window.requestAnimationFrame(c);
				return;
			}
			i?.disconnect(), o?.removeEventListener("scroll", s), o = Ke(t), s(), i = new ResizeObserver(s), i.observe(t), o && i.observe(o), o?.addEventListener("scroll", s);
		};
		return r = window.requestAnimationFrame(c), window.addEventListener("resize", c), () => {
			window.cancelAnimationFrame(r), i?.disconnect(), o?.removeEventListener("scroll", s), window.removeEventListener("resize", c);
		};
	}, [
		e,
		t,
		n
	]), !n || n.length < 2 || r.length < 2 ? null : /* @__PURE__ */ v("svg", {
		className: "gz-combo-trace",
		"aria-hidden": !0,
		children: r.slice(1).map((e, t) => {
			let n = r[t];
			if (!n || !e) return null;
			let i = `M ${n.x} ${n.y} C ${n.x + 5} ${(n.y + e.y) / 2}, ${e.x + 5} ${(n.y + e.y) / 2}, ${e.x} ${e.y}`, a = e.y < n.y ? 1 : -1, o = `M ${e.x - 4} ${e.y + a * 8} L ${e.x} ${e.y + a * 2} L ${e.x + 4} ${e.y + a * 8}`;
			return /* @__PURE__ */ y("g", { children: [
				/* @__PURE__ */ v("path", {
					d: i,
					className: "gz-combo-trace__under"
				}),
				/* @__PURE__ */ v("path", {
					d: i,
					className: "gz-combo-trace__line"
				}),
				/* @__PURE__ */ v("path", {
					d: o,
					className: "gz-combo-trace__arrow"
				}),
				n.hidden && /* @__PURE__ */ y("g", {
					className: "gz-combo-trace__offscreen",
					children: [/* @__PURE__ */ v("circle", {
						cx: n.x,
						cy: n.y,
						r: "7"
					}), /* @__PURE__ */ v("text", {
						x: n.x,
						y: n.y + 3,
						children: t + 1
					})]
				}),
				e.hidden && /* @__PURE__ */ y("g", {
					className: "gz-combo-trace__offscreen",
					children: [/* @__PURE__ */ v("circle", {
						cx: e.x,
						cy: e.y,
						r: "7"
					}), /* @__PURE__ */ v("text", {
						x: e.x,
						y: e.y + 3,
						children: t + 2
					})]
				})
			] }, t);
		})
	});
}
function st({ t: e, p: t, used: n, isMe: r, pending: a, pendSel: s, detail: l, detailCard: u, isPendingDetail: d, hintArchive: f, onCard: p }) {
	let m = R(t.built), { ref: h } = c(`storage:${t.rid}`), { ref: g } = c(`vp:${t.rid}`), _ = o(null), b = a?.[0]?.cardId;
	return i(() => {
		let e = _.current, n = Array.from(e?.querySelectorAll("[data-gizmos-anchor]") ?? []).find((e) => e.dataset.gizmosAnchor === `built:${t.rid}:${b}`), r = n ? Ke(n) : null;
		if (!n || !r) return;
		let i = n.getBoundingClientRect(), a = r.getBoundingClientRect();
		i.top < a.top ? r.scrollTop -= a.top - i.top + 4 : i.bottom > a.bottom && (r.scrollTop += i.bottom - a.bottom + 4);
	}, [b, t.rid]), /* @__PURE__ */ y("div", {
		className: "gz-dashboard",
		children: [/* @__PURE__ */ y("div", {
			className: "gz-resources flex h-[51px] flex-none items-center gap-1 rounded-lg border-2 border-gz-brass bg-gz-paper px-1 text-ink",
			children: [
				/* @__PURE__ */ v("span", {
					className: "gz-resources__label text-[10px] font-bold",
					children: e("games.gizmos.storageLabel")
				}),
				/* @__PURE__ */ y("span", {
					ref: h,
					"data-gizmos-anchor": `storage:${t.rid}`,
					className: "gz-resources__storage flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto",
					children: [t.storage.map((e, t) => /* @__PURE__ */ v(J, {
						color: e,
						size: 21
					}, t)), Array.from({ length: Math.max(0, m.storage - t.storage.length) }, (e, t) => /* @__PURE__ */ v("svg", {
						width: 21,
						height: 21,
						viewBox: "0 0 16 16",
						"aria-hidden": !0,
						className: "flex-none",
						children: /* @__PURE__ */ v("circle", {
							cx: 8,
							cy: 8,
							r: 6.2,
							fill: "none",
							stroke: "var(--color-ink)",
							strokeWidth: 1.4,
							strokeDasharray: "2.6 2",
							opacity: .35
						})
					}, `e${t}`))]
				}),
				/* @__PURE__ */ y("span", {
					className: "gz-resources__count font-mono text-[10px] font-bold tabular-nums",
					children: [
						t.storage.length,
						"/",
						m.storage
					]
				}),
				/* @__PURE__ */ v("span", { className: "gz-resources__divider h-8 w-px flex-none bg-ink/20" }),
				/* @__PURE__ */ y("span", {
					className: "gz-resources__archive flex w-[87px] flex-none items-center gap-0.5 overflow-x-auto",
					"aria-label": e("games.gizmos.archiveLabel"),
					children: [/* @__PURE__ */ y("span", {
						className: "gz-resources__archive-label",
						children: [
							/* @__PURE__ */ v(K, {
								name: "file",
								size: 13
							}),
							e("games.gizmos.archiveLabel"),
							/* @__PURE__ */ y("b", { children: [
								t.archive.length,
								"/",
								m.file
							] })
						]
					}), t.archive.map((e) => /* @__PURE__ */ v(it, {
						id: e,
						rid: t.rid,
						hint: f?.(e) ?? !1,
						onClick: () => p(e, "archive")
					}, e))]
				}),
				/* @__PURE__ */ y("span", {
					ref: g,
					"data-gizmos-anchor": `vp:${t.rid}`,
					className: "gz-resources__vp inline-flex flex-none items-center gap-0.5 font-mono text-[10px] font-bold tabular-nums",
					children: [/* @__PURE__ */ v(K, {
						name: "vp",
						size: 17
					}), t.vp]
				})
			]
		}), /* @__PURE__ */ y("div", {
			ref: _,
			className: "gz-engine relative flex min-h-0 flex-1 flex-col rounded-xl border-2 border-gz-brass bg-gz-board p-1.5 shadow-[inset_0_0_0_2px_var(--color-gz-well)]",
			children: [
				/* @__PURE__ */ y("div", {
					className: "gz-engine__heading flex h-5 flex-none items-center justify-between gap-1 px-1 text-gz-paper",
					children: [/* @__PURE__ */ v("strong", { children: e("games.gizmos.engineTitle") }), /* @__PURE__ */ y("span", { children: [a?.length ? `${e("games.gizmos.pendingCount", { n: a.length })} · ` : "", e("games.gizmos.engineCount", { n: t.built.length })] })]
				}),
				/* @__PURE__ */ y("div", {
					className: "gz-engine__detail h-10 flex-none rounded border border-gz-brass bg-gz-paper px-1.5 py-1 text-ink",
					children: [/* @__PURE__ */ y("div", {
						className: "flex h-3 items-center justify-between gap-1 text-[10px] font-extrabold",
						children: [/* @__PURE__ */ y("span", {
							className: "flex-none",
							children: [
								e(l ? d ? "games.gizmos.pendingDetail" : "games.gizmos.selectedEffect" : "games.gizmos.engineTitle"),
								" · ",
								u ? u.tier === 0 ? e("games.gizmos.startCard") : `${e("games.gizmos.tierLabel", { n: u.tier })} ★${u.vp === "award" ? "✳" : u.vp}` : t.built.length
							]
						}), a && a.length > 0 && /* @__PURE__ */ v("span", {
							className: "flex min-w-0 items-center justify-end gap-px overflow-x-auto font-mono",
							children: a.map((e, t) => /* @__PURE__ */ y("span", {
								className: "inline-flex flex-none items-center gap-px",
								children: [
									t > 0 && /* @__PURE__ */ v("span", { children: "→" }),
									/* @__PURE__ */ v("span", {
										className: "rounded-full bg-amber-300 px-0.5 text-ink",
										children: t + 1
									}),
									/* @__PURE__ */ v(K, {
										name: nt.find((t) => t.key === rt(e.cardId))?.icon ?? "build",
										size: 12
									})
								]
							}, e.cardId))
						})]
					}), /* @__PURE__ */ v("p", {
						className: "truncate text-[11px] leading-4 font-bold",
						children: l ?? e(a?.length ? "games.gizmos.pendingPrompt" : "games.gizmos.engineHint")
					})]
				}),
				/* @__PURE__ */ v("div", {
					className: "gz-columns grid min-h-0 flex-1 grid-cols-5 gap-1.5",
					children: nt.map((i) => {
						let o = t.built.filter((e) => rt(e) === i.key);
						return /* @__PURE__ */ y("div", {
							className: "gz-column flex min-h-0 min-w-0 flex-col rounded-md border border-gz-brass/60 bg-gz-well p-0.5",
							children: [/* @__PURE__ */ y("span", {
								className: "gz-column__heading flex h-7 flex-none items-center justify-center gap-px rounded-sm border border-gz-brass bg-gz-paper text-[10px] font-extrabold text-ink",
								children: [/* @__PURE__ */ v("span", {
									className: "gz-column__icon",
									children: /* @__PURE__ */ v(K, {
										name: i.icon,
										size: 17
									})
								}), e(i.label)]
							}), /* @__PURE__ */ v("div", {
								className: "gz-column__cards",
								children: o.map((e, i) => {
									let o = a?.findIndex((t) => t.cardId === e) ?? -1;
									return /* @__PURE__ */ v(at, {
										id: e,
										rid: t.rid,
										used: r && n.includes(e),
										pending: o + 1,
										remaining: o >= 0 ? a?.[o].left ?? 1 : 0,
										selected: s === e,
										order: i,
										onClick: () => p(e, "built")
									}, e);
								})
							})]
						}, i.key);
					})
				}),
				/* @__PURE__ */ v(ot, {
					root: _,
					rid: t.rid,
					pending: a
				})
			]
		})]
	});
}
function ct(e, t) {
	let n = e[t.marble];
	if (!n) return null;
	for (let e of t.chain) {
		let t = I(e.conv).effect;
		if (t.kind !== "converter") return null;
		if (t.conv === "toAny" || t.conv === "oneOrTwoToAny") {
			if (t.color !== n) return null;
			n = e.to;
		} else if (t.conv === "anyToAny") n = e.to;
		else if (t.conv === "double") {
			if (t.color !== n || e.to !== n) return null;
		} else if (!t.pair?.includes(n) || e.to !== n) return null;
	}
	return n;
}
function lt({ def: e, me: t, used: n, effCost: r, onConfirm: i, onCancel: a }) {
	let o = u(), [c, l] = s([]), [d, f] = s(null), p = new Set(c.map((e) => e.marble)), m = (e) => {
		p.has(e) || c.length >= r || l([...c, {
			marble: e,
			chain: []
		}]);
	}, h = (e) => {
		let t = c[e].marble;
		l(c.filter((e) => e.marble !== t)), f(null);
	}, g = (e) => {
		let t = I(e).effect;
		if (t.kind !== "converter") return 0;
		if (t.conv === "double") {
			let t = /* @__PURE__ */ new Set();
			for (let n of c) n.chain.forEach((r, i) => {
				r.conv === e && t.add(`${n.marble}:${n.chain.slice(0, i + 1).map((e) => e.conv).join(",")}`);
			});
			return t.size;
		}
		let n = 0;
		for (let t of c) for (let r of t.chain) r.conv === e && (n += 1);
		return n;
	}, _ = (e) => {
		let t = I(e).effect;
		return t.kind === "converter" && (t.conv === "oneOrTwoToAny" || t.conv === "pairDouble") ? 2 : 1;
	}, b = t.built.filter((e) => I(e).effect.kind === "converter" && !n.includes(e) && g(e) < _(e)), x = (e) => ct(t.storage, e), S = (e, t) => {
		let n = I(e).effect;
		if (n.kind !== "converter") return !1;
		let r = x(t);
		return r ? n.conv === "anyToAny" ? !0 : n.conv === "toAny" || n.conv === "oneOrTwoToAny" || n.conv === "double" ? n.color === r : !!n.pair?.includes(r) : !1;
	}, C = (e, t, n) => {
		let i = c[e], a = I(t).effect;
		if (a.kind !== "converter") return;
		let o = x(i);
		if (!o) return;
		let s = {
			conv: t,
			to: n ?? o
		};
		if (a.conv === "double" || a.conv === "pairDouble") {
			if (c.length + 1 > r) return;
			let t = c.filter((t, n) => n !== e);
			t.push({
				marble: i.marble,
				chain: [...i.chain, s]
			}, {
				marble: i.marble,
				chain: [...i.chain, s]
			}), l(t);
		} else l(c.map((t, n) => n === e ? {
			...t,
			chain: [...t.chain, s]
		} : t));
		f(null);
	}, w = c.map((e) => x(e)), T = c.length === r && w.every((t) => t !== null && (e.any || t === e.color));
	return /* @__PURE__ */ y("div", {
		className: "gz-overlay gz-payment pointer-events-auto mx-2 rounded-xl border-2 border-ink bg-surface p-2",
		children: [
			/* @__PURE__ */ y("p", {
				className: "text-xs font-extrabold",
				children: [r === 0 ? o("games.gizmos.freeBuildLabel") : o("games.gizmos.payTitle", { n: r }), /* @__PURE__ */ v("span", {
					className: "ml-1.5 font-normal opacity-70",
					children: e.any ? o("games.gizmos.payNeedAny") : o("games.gizmos.payNeedColor", { c: o(Y[e.color ?? "k"]) })
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "mt-1 flex items-center gap-1 overflow-x-auto",
				children: [/* @__PURE__ */ v("span", {
					className: "flex-none text-[10px] font-bold opacity-70",
					children: o("games.gizmos.payPickMarble")
				}), t.storage.map((e, t) => /* @__PURE__ */ v("button", {
					type: "button",
					"aria-label": o(Y[e]),
					className: `grid size-9 flex-none place-items-center rounded-full ${p.has(t) ? "opacity-30" : "ring-1 ring-ink/30"}`,
					onClick: () => m(t),
					children: /* @__PURE__ */ v(J, {
						color: e,
						size: 20
					})
				}, t))]
			}),
			c.map((e, n) => /* @__PURE__ */ y("div", {
				className: "mt-1 flex items-center gap-1 overflow-x-auto",
				children: [
					/* @__PURE__ */ v(J, {
						color: t.storage[e.marble],
						size: 18
					}),
					e.chain.map((e, t) => /* @__PURE__ */ y("span", {
						className: "flex-none rounded border border-ink/40 px-1 font-mono text-[9px] leading-4",
						children: ["→", o(Y[e.to])]
					}, t)),
					/* @__PURE__ */ y("span", {
						className: "flex-none font-mono text-[10px] font-bold",
						children: ["=", w[n] ? o(Y[w[n]]) : "?"]
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet h-7 flex-none px-1.5 text-[10px]",
						onClick: () => f(d === n ? null : n),
						children: "⚙"
					}),
					/* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet h-7 flex-none px-1.5 text-[10px] text-danger",
						onClick: () => h(n),
						children: o("games.gizmos.payRemove")
					})
				]
			}, `${e.marble}:${e.chain.length}:${n}`)),
			d !== null && c[d] && /* @__PURE__ */ y("div", {
				className: "mt-1 flex flex-wrap items-center gap-1 rounded-lg border border-ink/20 p-1",
				children: [b.filter((e) => S(e, c[d])).map((e) => {
					let t = I(e).effect;
					return t.kind === "converter" ? t.conv === "double" || t.conv === "pairDouble" ? /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet h-8 px-1.5 text-[10px]",
						onClick: () => C(d, e, null),
						children: X(I(e), o)
					}, e) : /* @__PURE__ */ y("span", {
						className: "inline-flex items-center gap-0.5 rounded border border-ink/30 px-1 py-0.5",
						children: [/* @__PURE__ */ y("span", {
							className: "text-[9px]",
							children: [X(I(e), o), ":"]
						}), [
							"k",
							"b",
							"r",
							"y"
						].map((t) => /* @__PURE__ */ v("button", {
							type: "button",
							"aria-label": o(Y[t]),
							onClick: () => C(d, e, t),
							children: /* @__PURE__ */ v(J, {
								color: t,
								size: 14
							})
						}, t))]
					}, e) : null;
				}), b.filter((e) => S(e, c[d])).length === 0 && /* @__PURE__ */ v("span", {
					className: "text-[10px] opacity-60",
					children: o("games.gizmos.payConvertHint")
				})]
			}),
			/* @__PURE__ */ y("div", {
				className: "mt-1.5 flex gap-1.5",
				children: [/* @__PURE__ */ v("button", {
					type: "button",
					className: "btn-quiet h-11 flex-1 text-xs",
					onClick: a,
					children: o("games.gizmos.cancel")
				}), /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-base h-11 flex-1 text-xs",
					disabled: !T,
					onClick: () => i(c),
					children: [o("games.gizmos.confirmBuild"), !T && r > 0 ? `(${o("games.gizmos.payShort", { n: r - c.length })})` : ""]
				})]
			})
		]
	});
}
//#endregion
//#region src/games/gizmos/bot.ts
var ut = [
	"k",
	"b",
	"r",
	"y"
];
function Z(e) {
	let t = I(e), n = t.vp === "award" ? 4 : t.vp * 2, r = t.effect;
	if (r.kind === "trigger") {
		let e = {
			draw1: 1,
			draw3: 2.5,
			pick1: 1.5,
			pick2: 2.5,
			vp1: 1.5,
			vp2: 2.5,
			file: 1.5,
			research: 1.5,
			freeBuild1: 2
		}[r.fx];
		n += e;
	} else r.kind === "upgrade" ? "add" in r && r.add ? n += (r.add.storage ?? 0) * 1.5 + (r.add.file ?? 0) * 2 + (r.add.research ?? 0) : "ban" in r ? --n : "discount" in r ? n += 1.5 : "award" in r && (n += 2) : n += {
		toAny: 2,
		anyToAny: 2.5,
		double: 2.5,
		oneOrTwoToAny: 2,
		pairDouble: 2
	}[r.conv];
	return n;
}
function dt(e, t) {
	let n = null;
	for (let r of ["market", "archive"]) {
		let i = r === "market" ? e.market.flat().filter((e) => e !== null) : t.archive;
		for (let a of i) {
			let i = De(t, a, r === "archive", !1, e.used);
			if (!i) continue;
			let o = Z(a);
			(!n || o > n.v) && (n = {
				cardId: a,
				from: r,
				pay: i,
				v: o
			});
		}
	}
	return n;
}
function ft(e, t) {
	let n = R(t.built);
	if (t.storage.length >= n.storage || e.row.length === 0) return -1;
	let r = null, i = 0;
	for (let n of e.market.flat().filter((e) => e !== null)) {
		let e = I(n);
		if (e.any || !e.color) continue;
		let a = Ee(t.built, n, !1, !1);
		t.storage.filter((t) => t === e.color).length < a && Z(n) > i && (i = Z(n), r = e.color);
	}
	if (r) {
		let t = e.row.indexOf(r);
		if (t >= 0) return t;
	}
	let a = ut.map((e) => t.storage.filter((t) => t === e).length), o = ut[a.indexOf(Math.min(...a))], s = e.row.indexOf(o);
	return s >= 0 ? s : 0;
}
var pt = (e, t) => {
	let n = e.public;
	if (n.phase === "done" || n.turn !== t.rid) return null;
	let r = n.players.find((e) => e.rid === t.rid);
	if (!r) return null;
	let i = R(r.built), a = le(r.built), o = t.difficulty === "weak", s = (e) => Math.floor(Math.random() * e);
	if (n.phase === "research") {
		let t = e.private?.researchCards ?? [];
		if (t.length === 0) return { action: {
			type: "researchTake",
			mode: "none"
		} };
		let s = [...t].sort((e, t) => Z(t) - Z(e));
		if (!o) for (let e of s) {
			let t = De(r, e, !1, !0, n.used);
			if (t) return { action: {
				type: "researchTake",
				mode: "build",
				cardId: e,
				pay: t
			} };
		}
		return !a.file && r.archive.length < i.file ? { action: {
			type: "researchTake",
			mode: "file",
			cardId: s[0]
		} } : { action: {
			type: "researchTake",
			mode: "none"
		} };
	}
	if (n.pending && n.pending.length > 0) {
		let e = n.pending[0], t = I(e.cardId).effect;
		if (t.kind !== "trigger") return { action: { type: "skipTriggers" } };
		if (t.fx === "pick1" || t.fx === "pick2") {
			if (r.storage.length >= i.storage || n.row.length === 0) return { action: { type: "skipTriggers" } };
			let t = o ? s(n.row.length) : ft(n, r);
			return t >= 0 ? { action: {
				type: "resolve",
				cardId: e.cardId,
				index: t
			} } : { action: { type: "skipTriggers" } };
		}
		if (t.fx === "file") {
			if (a.file || r.archive.length >= i.file) return { action: { type: "skipTriggers" } };
			let t = n.market.flat().filter((e) => e !== null);
			if (t.length === 0) return { action: { type: "skipTriggers" } };
			let c = o ? t[s(t.length)] : t.sort((e, t) => Z(t) - Z(e))[0];
			return { action: {
				type: "resolve",
				cardId: e.cardId,
				target: c
			} };
		}
		if (t.fx === "research") {
			if (a.research) return { action: { type: "skipTriggers" } };
			let t = [
				1,
				2,
				3
			].filter((e) => n.deckCounts[e - 1] > 0);
			return t.length === 0 ? { action: { type: "skipTriggers" } } : { action: {
				type: "resolve",
				cardId: e.cardId,
				tier: o ? t[s(t.length)] : t[t.length - 1]
			} };
		}
		if (t.fx === "freeBuild1") {
			let t = n.market[0].filter((e) => e !== null);
			if (t.length === 0) return { action: { type: "skipTriggers" } };
			let r = o ? t[s(t.length)] : t.sort((e, t) => Z(t) - Z(e))[0];
			return { action: {
				type: "resolve",
				cardId: e.cardId,
				target: r
			} };
		}
		return { action: {
			type: "resolve",
			cardId: e.cardId
		} };
	}
	if (o) {
		let e = [], t = n.row.length && r.storage.length < i.storage ? s(n.row.length) : -1;
		t >= 0 && e.push({
			type: "pick",
			index: t
		});
		let o = n.market.flat().filter((e) => e !== null);
		if (!a.file && r.archive.length < i.file && o.length && e.push({
			type: "file",
			cardId: o[s(o.length)]
		}), !a.research) {
			let t = [
				1,
				2,
				3
			].filter((e) => n.deckCounts[e - 1] > 0);
			t.length && e.push({
				type: "research",
				tier: t[s(t.length)]
			});
		}
		let c = dt(n, r);
		return c && e.push({
			type: "build",
			cardId: c.cardId,
			from: c.from,
			pay: c.pay
		}), e.length ? { action: e[s(e.length)] } : null;
	}
	let c = dt(n, r);
	if (c && (Z(c.cardId) >= 3 || r.storage.length >= i.storage - 1)) return { action: {
		type: "build",
		cardId: c.cardId,
		from: c.from,
		pay: c.pay
	} };
	let l = ft(n, r);
	if (l >= 0) return { action: {
		type: "pick",
		index: l
	} };
	if (c) return { action: {
		type: "build",
		cardId: c.cardId,
		from: c.from,
		pay: c.pay
	} };
	if (!a.research) {
		let e = [
			3,
			2,
			1
		].filter((e) => n.deckCounts[e - 1] > 0);
		if (e.length) return { action: {
			type: "research",
			tier: e[0]
		} };
	}
	if (!a.file && r.archive.length < i.file) {
		let e = n.market.flat().filter((e) => e !== null);
		if (e.length) return { action: {
			type: "file",
			cardId: e.sort((e, t) => Z(t) - Z(e))[0]
		} };
	}
	return null;
};
//#endregion
//#region src/games/gizmos/fx.tsx
function mt(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Q(e, t) {
	let n = e.anchor(t);
	if (!n) return null;
	let r = Array.from(document.querySelectorAll("[data-gizmos-anchor]")).find((e) => e.dataset.gizmosAnchor === t);
	if (!r) return null;
	let i = r.getBoundingClientRect(), a = Math.max(0, i.left), o = Math.max(0, i.top), s = Math.min(window.innerWidth, i.right), c = Math.min(window.innerHeight, i.bottom);
	for (let e = r.parentElement; e; e = e.parentElement) {
		let t = window.getComputedStyle(e);
		if (!/(auto|scroll|hidden|clip)/.test(`${t.overflowX} ${t.overflowY}`)) continue;
		let n = e.getBoundingClientRect();
		a = Math.max(a, n.left + e.clientLeft), o = Math.max(o, n.top + e.clientTop), s = Math.min(s, n.left + e.clientLeft + e.clientWidth), c = Math.min(c, n.top + e.clientTop + e.clientHeight);
	}
	return s <= a || c <= o ? null : n;
}
function $(e, t, n) {
	let r = typeof n.sourceCardId == "string" ? n.sourceCardId : typeof n.cardId == "string" ? n.cardId : null;
	return t && r ? Q(e, `built:${t}:${r}`) : null;
}
function ht(e, t, n, r) {
	return t ? Q(e, r ? `${n}:${t}:${r}` : `${n}:${t}`) ?? mt(e, t) : null;
}
function gt(e, t, n = 0) {
	let r = t ? Q(e, `storage:${t}`) : null, i = r ?? mt(e, t);
	if (!i) return null;
	if (!r) return {
		x: i.x + (i.w - 22) / 2,
		y: i.y + (i.h - 22) / 2,
		w: 22,
		h: 22
	};
	let a = Array.from(document.querySelectorAll("[data-gizmos-anchor]")).find((e) => e.dataset.gizmosAnchor === `storage:${t}`), o = a?.querySelectorAll("img"), s = o?.item(o.length - 1 - n);
	if (s && a) {
		let e = a.getBoundingClientRect(), t = s.getBoundingClientRect();
		return {
			x: i.x + t.left - e.left,
			y: i.y + t.top - e.top,
			w: t.width,
			h: t.height
		};
	}
	return {
		x: i.x + (i.w - 22) / 2,
		y: i.y + (i.h - 22) / 2,
		w: 22,
		h: 22
	};
}
function _t(e, t) {
	return typeof t.tier != "number" || typeof t.slot != "number" ? null : Q(e, `m${t.tier}-${t.slot}`);
}
function vt({ from: e, to: t }) {
	let n = e.x + e.w / 2, r = e.y + e.h / 2, i = t.x + t.w / 2, a = t.y + t.h / 2, o = Math.max(n, i) + 35, s = `M ${n} ${r} C ${o} ${r + 38}, ${o} ${a - 38}, ${i} ${a}`;
	return /* @__PURE__ */ y("svg", {
		className: "gz-fx-trail absolute inset-0 size-full overflow-visible",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("path", {
			d: s,
			className: "gz-fx-trail__glow"
		}), /* @__PURE__ */ v("path", {
			d: s,
			className: "gz-fx-trail__line"
		})]
	});
}
var yt = {
	build(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string") return null;
		let r = ht(t, e.rid, "built", n.cardId);
		if (!r) return null;
		let i = _t(t, n), a = $(t, e.rid, { sourceCardId: n.sourceCardId }), o = t.queued > 0;
		return i ? {
			ms: o ? 350 : 620,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 260 : 480
			}), /* @__PURE__ */ v(x, {
				from: i,
				to: r,
				ms: o ? 260 : 480,
				children: /* @__PURE__ */ v(q, {
					id: n.cardId,
					w: i.w,
					h: i.h,
					adaptive: !0
				})
			})] })
		} : {
			ms: o ? 300 : 500,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 280 : 460
			}), /* @__PURE__ */ v(S, {
				at: r,
				ms: o ? 280 : 460
			})] })
		};
	},
	file(e, t) {
		let n = e.data;
		if (typeof n?.cardId != "string") return null;
		let r = ht(t, e.rid, "archive", n.cardId);
		if (!r) return null;
		let i = _t(t, n), a = $(t, e.rid, { sourceCardId: n.sourceCardId }), o = t.queued > 0;
		return i ? {
			ms: o ? 350 : 620,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 260 : 480
			}), /* @__PURE__ */ v(x, {
				from: i,
				to: r,
				ms: o ? 260 : 480,
				children: /* @__PURE__ */ v(q, {
					id: n.cardId,
					w: i.w,
					h: i.h,
					adaptive: !0
				})
			})] })
		} : {
			ms: o ? 300 : 500,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 280 : 460
			}), /* @__PURE__ */ v(S, {
				at: r,
				ms: o ? 280 : 460
			})] })
		};
	},
	pick(e, t) {
		let n = e.data;
		if (typeof n?.index != "number") return null;
		let r = Q(t, `energy:${n.index}`), i = gt(t, e.rid);
		if (!i) return null;
		let a = $(t, e.rid, { sourceCardId: n.sourceCardId }), o = t.queued > 0;
		return r ? {
			ms: o ? 300 : 520,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 220 : 420
			}), /* @__PURE__ */ v(x, {
				from: r,
				to: i,
				ms: o ? 220 : 420,
				children: /* @__PURE__ */ v(J, {
					color: n.color ?? "k",
					size: Math.min(i.w, i.h)
				})
			})] })
		} : {
			ms: o ? 300 : 500,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: o ? 280 : 460
			}), /* @__PURE__ */ v(S, {
				at: i,
				ms: o ? 280 : 460
			})] })
		};
	},
	draw(e, t) {
		let n = e.data;
		if (!Array.isArray(n?.colors)) return null;
		let r = Q(t, "supply"), i = gt(t, e.rid);
		if (!i) return null;
		let a = $(t, e.rid, n), o = n.colors, s = o.map((n, r) => gt(t, e.rid, o.length - r - 1) ?? i), c = t.queued > 0;
		return r ? {
			ms: c ? 300 + o.length * 60 : 500 + o.length * 120,
			node: /* @__PURE__ */ y(_, { children: [
				a && /* @__PURE__ */ v(S, {
					at: a,
					ms: c ? 220 : 420
				}),
				/* @__PURE__ */ v(vt, {
					from: r,
					to: i
				}),
				o.map((e, t) => /* @__PURE__ */ v(x, {
					from: r,
					to: s[t],
					ms: c ? 220 : 420,
					delay: t * (c ? 60 : 120),
					children: /* @__PURE__ */ v(J, {
						color: e,
						size: Math.min(s[t].w, s[t].h)
					})
				}, t))
			] })
		} : {
			ms: c ? 300 : 500,
			node: /* @__PURE__ */ y(_, { children: [a && /* @__PURE__ */ v(S, {
				at: a,
				ms: c ? 280 : 460
			}), /* @__PURE__ */ v(S, {
				at: i,
				ms: c ? 280 : 460
			})] })
		};
	},
	vp(e, t) {
		let n = e.data;
		if (typeof n?.n != "number") return null;
		let r = ht(t, e.rid, "vp");
		if (!r) return null;
		let i = $(t, e.rid, n);
		return {
			ms: 700,
			node: /* @__PURE__ */ y(_, { children: [i && /* @__PURE__ */ v(S, {
				at: i,
				ms: 500
			}), /* @__PURE__ */ v(b, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ y("span", {
					className: "rounded-md border-2 border-ink bg-done-soft px-1.5 py-0.5 font-mono text-xs font-extrabold tabular-nums text-done-ink shadow-[2px_2px_0_var(--color-ink)]",
					children: [
						"+",
						n.n,
						"★"
					]
				})
			})] })
		};
	},
	research(e, t) {
		let n = e.data;
		if (typeof n?.tier != "number" || typeof n?.count != "number") return null;
		let r = Q(t, `deck:${n.tier}`) ?? mt(t, e.rid);
		if (!r) return null;
		let i = $(t, e.rid, { sourceCardId: n.sourceCardId });
		return {
			ms: 700,
			node: /* @__PURE__ */ y(_, { children: [i && /* @__PURE__ */ v(S, {
				at: i,
				ms: 500
			}), /* @__PURE__ */ v(b, {
				at: r,
				ms: 700,
				children: /* @__PURE__ */ y("span", {
					className: "rounded-md border-2 border-ink bg-surface px-1.5 py-0.5 font-mono text-xs font-extrabold tabular-nums shadow-[2px_2px_0_var(--color-ink)]",
					children: [
						"🔍",
						n.tier,
						"-",
						n.count
					]
				})
			})] })
		};
	}
};
//#endregion
//#region src/games/gizmos/endgame-review.tsx
function bt({ board: e, renderResult: t, ...n }) {
	let i = u(), [c, l] = s(!0), [d, f] = s(null), p = o(null), m = o(null), h = o(null);
	r(() => {
		if (!d) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let g = (e) => {
		f(null), l(e), requestAnimationFrame(() => (e ? p : m).current?.focus({ preventScroll: !0 }));
	}, _ = a(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), b = {
		...n,
		..._
	};
	return /* @__PURE__ */ y("div", {
		className: "gizmos-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ v("div", {
				className: "gizmos-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ v("div", {
				className: "gizmos-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ y("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "gizmos-endgame-panel",
					"aria-label": i("session.result.title"),
					children: [
						/* @__PURE__ */ y("header", {
							className: "gizmos-endgame-heading",
							children: [/* @__PURE__ */ y("div", {
								className: "gizmos-endgame-brand",
								children: [/* @__PURE__ */ v("span", {
									"aria-hidden": "true",
									children: V.icon
								}), i(V.nameKey)]
							}), /* @__PURE__ */ v("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": i("games.gizmos.reviewHide"),
								title: i("games.gizmos.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ v(T, { size: 19 })
							})]
						}),
						/* @__PURE__ */ v("div", {
							className: "gizmos-endgame-result",
							inert: d !== null,
							children: t(b)
						}),
						d && /* @__PURE__ */ y("div", {
							className: "gizmos-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ v("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: i(d.label === "again" ? "games.gizmos.reviewConfirmAgain" : "games.gizmos.reviewConfirmLobby")
							}), /* @__PURE__ */ v("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: i("games.gizmos.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ v("div", {
				className: "gizmos-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ y("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ v(E, { size: 18 }),
						i("games.gizmos.reviewShow"),
						/* @__PURE__ */ v(C, { size: 18 })
					]
				})
			})
		]
	});
}
function xt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: c, renderRowExtra: d, summary: f, navigation: p, content: m, afterRanking: h, scoreUnit: b, rankOf: x }) {
	let S = u(), C = l((e) => e.locale), [E, te] = s({}), D = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? g(n, C) : e;
	}, O = (t, n) => x?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), k = e.ranking.some((t) => e.scores?.[t] !== void 0), A = (t, n) => /* @__PURE__ */ y("div", {
		className: "gizmos-score-identity",
		children: [
			/* @__PURE__ */ y("span", {
				className: "gizmos-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ v("span", {
					"aria-label": S("games.gizmos.reviewWinner"),
					children: "♛ "
				}), k && O(t, n)]
			}),
			/* @__PURE__ */ y("span", {
				className: "gizmos-score-name",
				children: [D(t), t === r && /* @__PURE__ */ v("small", { children: S("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ y("small", {
				className: "gizmos-score-autopilot",
				children: [
					/* @__PURE__ */ v(w, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), j = (t) => e.ranking.map((n) => /* @__PURE__ */ v("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ y("div", {
		className: "gizmos-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ v(ee, {}),
			p,
			/* @__PURE__ */ y("div", {
				className: "gizmos-score-body",
				children: [
					f && /* @__PURE__ */ v("div", {
						className: "gizmos-score-summary",
						children: f
					}),
					i !== void 0 && /* @__PURE__ */ v("p", {
						className: "gizmos-score-hints",
						children: S("session.hint.usedCount", { n: i })
					}),
					m ?? (c?.length ? /* @__PURE__ */ v("div", {
						className: "gizmos-score-table-scroll",
						children: /* @__PURE__ */ y("table", {
							className: "gizmos-score-table",
							"aria-label": S(V.nameKey),
							children: [
								/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { scope: "col" }), /* @__PURE__ */ v(_, { children: e.ranking.map((t, n) => /* @__PURE__ */ v("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: A(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ v("tbody", { children: c.map((e, t) => /* @__PURE__ */ y(n, { children: [/* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ y("button", {
										type: "button",
										"aria-expanded": !!E[t],
										onClick: () => te((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ v(T, { size: 15 }), e.label]
									}) : e.label
								}), j(e)] }), E[t] && e.details?.map((e, t) => /* @__PURE__ */ y("tr", {
									className: "gizmos-score-sub",
									children: [/* @__PURE__ */ v("th", {
										scope: "row",
										children: e.label
									}), j(e)]
								}, t))] }, t)) }),
								k && /* @__PURE__ */ v("tfoot", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", {
									scope: "row",
									children: S("games.gizmos.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ v("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ v("ol", {
						className: "gizmos-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ y("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ y("div", {
								className: "gizmos-score-rankline",
								children: [A(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ y("strong", {
									className: "gizmos-score-points",
									children: [e.scores[t], b && /* @__PURE__ */ v("small", { children: b })]
								})]
							}), d?.(t)]
						}, t))
					})),
					h,
					!!c?.length && d && /* @__PURE__ */ v("div", {
						className: "gizmos-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ y("details", { children: [/* @__PURE__ */ v("summary", { children: D(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ y("footer", {
				className: "gizmos-score-actions",
				children: [
					o && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: S("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ v("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: S("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ v("p", { children: S("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/gizmos/game-over.tsx
function St({ hintCount: e, result: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	return /* @__PURE__ */ v(xt, {
		hintCount: e,
		result: t,
		members: n,
		myRid: r,
		accent: V.accent,
		onPlayAgain: i,
		onBackToLobby: a
	});
}
function Ct(e) {
	return /* @__PURE__ */ v(bt, {
		...e,
		board: /* @__PURE__ */ v(Je, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ v(St, { ...e })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/gizmos/entry.tsx
var wt = {
	definition: Ie,
	View: Je,
	bot: pt,
	fx: yt,
	OverView: Ct,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "爆珠发明",
			desc: "取能、归档、建造、研究,连锁触发你的发明引擎",
			rules: "目标:用能量弹珠建造发明,触发连锁效果;总分最高者胜。\n准备:\n· 三个等级牌堆摆开三行展示区;从分配器中滚出 6 颗能量弹珠，组成能量行。\n· 每名玩家获得 1 张起始发明。该发明的效果是：执行归档行动时，随机抽取 1 颗能量弹珠。\n流程:每回合从四个动作中选一个执行。\n· 归档：从展示区领取 1 张发明牌，放入自己的存档区。初始存档上限为 1 张。\n· 取能：从能量行领取 1 颗能量弹珠，放入自己的储能环。初始储能上限为 5 颗。\n· 建造：选择展示区或自己存档区中的 1 张发明牌，支付费用并完成建造；支付的能量弹珠退回分配器。\n· 研究：选择一个等级的发明牌堆，抽取 3 张牌。可以建造或归档其中 1 张，将其余牌放回该牌堆底。\n· 已经建造的转换器可以改变能量颜色，或将一份能量转换为两份能量。每个转换器每回合最多使用一次。\n· 执行行动时，会触发对应类型的已建发明。可以自行决定这些效果的结算顺序，每张发明牌每回合最多触发一次。\n结束：有玩家建造了自己的第 4 张三级发明，或第 16 张发明后，完成当前一轮，再进行终局计分。\n· 将卡牌上标示的分数与分数标记相加，得到总分。总分相同时，依次比较已建造的发明数量和剩余能量数量，较多的玩家获胜。",
			myTurn: "轮到你:四选一行动",
			waitTurn: "等待 {{name}} 行动…",
			lastLap: "最后一轮",
			researchPrompt: "研究:建造或归档 1 张,或全部放回牌堆底",
			pendingPrompt: "选择要激活的发明效果,或跳过",
			comboStatus: "连锁待结算 · {{n}} 项效果",
			pickPrompt: "取能:从能量行取 1 颗",
			filePrompt: "归档:从展示区选 1 张",
			buildFreePrompt: "免费建造:从展示区选 1 张 1 级卡",
			researchPickPrompt: "研究:选择一个牌堆",
			actFile: "归档",
			actPick: "取能",
			actBuild: "建造",
			actResearch: "研究",
			skipTriggers: "跳过剩余效果",
			cancel: "取消",
			confirmBuild: "确认建造",
			storageLabel: "储能",
			archiveLabel: "存档",
			builtLabel: "已激活",
			engineTitle: "我的发明引擎",
			engineCount: "已建 {{n}}/16",
			pendingCount: "待结算 {{n}}",
			marketTitle: "发明展示区",
			marketLegend: "图标:条件 › 结果",
			engineHint: "点市场卡归档或建造，点能量珠取能",
			selectedEffect: "选中牌说明",
			pendingDetail: "当前牌说明",
			pendingOrdinal: "待激活第 {{n}} 项",
			usedCard: "本回合已使用",
			columnConvert: "转换",
			columnUpgrade: "升级",
			vpLabel: "分标记",
			scoreLabel: "总分",
			deckCount: "余 {{n}}",
			supplyCount: "分配器余 {{n}}",
			tierLabel: "{{n}} 级",
			cardCount: "{{n}} 张",
			energyK: "电池",
			energyB: "原子",
			energyR: "热力",
			energyY: "电力",
			energyAny: "任意",
			fxDraw1: "随机抽取 1 颗能量",
			fxDraw3: "随机抽取 3 颗能量",
			fxPick1: "取能 1 次",
			fxPick2: "取能 2 次",
			fxVp1: "获得 1 个分标记",
			fxVp2: "获得 2 个分标记",
			fxFile: "归档 1 次",
			fxResearch: "研究 1 次",
			fxFreeBuild1: "免费建造 1 张 1 级卡",
			trigFile: "归档时",
			trigPick: "取{{c}}时",
			trigPick2: "取{{c1}}或{{c2}}时",
			trigBuild: "建造{{c}}卡时",
			trigBuild2: "建造{{c1}}或{{c2}}卡时",
			trigBuildArchive: "从存档建造时",
			trigBuildTier2: "建造 2 级卡时",
			convToAny: "{{c}} → 任意色",
			convAnyToAny: "任意色 → 任意色",
			convDouble: "{{c}} → 2 颗{{c}}",
			convOneOrTwo: "1-2 颗{{c}} → 同数任意色",
			convPair: "{{c1}}、{{c2}}各 1 颗 → 各 2 颗",
			upgStorage: "储能上限增加 {{n}}",
			upgFile: "存档上限增加 {{n}}",
			upgResearch: "研究多抽 {{n}} 张",
			upgBanFile: "本局禁用归档",
			upgBanResearch: "本局禁用研究",
			upgDiscTier2: "建造 2 级卡费用减少 1",
			upgDiscArchive: "从存档建造费用减少 1",
			upgDiscResearch: "研究中建造费用减少 1",
			upgAwardEnergy: "终局:每颗储能能量 +1 分",
			upgAwardVp: "终局:每个分标记 +1 分",
			startCard: "起始发明",
			payTitle: "支付 {{n}} 颗能量",
			payNeedColor: "需全部转为{{c}}",
			payNeedAny: "任意颜色组合",
			payPickMarble: "点选储能能量",
			payConvertHint: "点选转换器可变色或一变二",
			payConvertTo: "转为",
			payRemove: "移除",
			payShort: "还差 {{n}} 颗",
			freeBuildLabel: "免费建造",
			researchTitle: "研究:{{n}} 级牌堆",
			researchBuild: "建造",
			researchFile: "归档",
			researchNone: "全部放回",
			errNotYourTurn: "还没轮到你",
			errBanned: "该动作已被你的发明禁用",
			errArchiveFull: "存档已满",
			errStorageFull: "储能环已满",
			errBadPay: "能量支付不合法",
			errBadCard: "无效的卡牌",
			errBadPick: "无效的取能",
			errDeckEmpty: "该牌堆已空",
			errPending: "请先处理待激活的效果",
			errNoPending: "没有可跳过的效果"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Gizmos",
			desc: "Pick, file, build and research — chain your engine of inventions",
			rules: "Goal: spend energy marbles to build Gizmos and chain effects; most points win.\nSetup:\n· Arrange the three decks into three display rows and reveal six energy marbles in the energy row.\n· Each player starts with one Gizmo whose effect lets them draw one random energy marble whenever they File.\nPlay: on your turn, perform exactly one of four actions.\n· File: take one card from the display and place it in your archive. The archive initially holds one card.\n· Pick: take one marble from the energy row and put it in your storage, which initially holds up to five marbles.\n· Build: pay to build 1 card from the display or your archive.\n· Research: draw three cards from one deck. Build or File one of them, then return the others.\n· Built converters recolor or duplicate energy, each once per turn.\n· Actions trigger the matching Gizmos you have built. Resolve their effects in any order; each Gizmo can trigger at most once per turn.\nEnd: when a player builds their fourth level-3 Gizmo or their sixteenth Gizmo in total, finish the current round and score the game.\n· Add the points printed on your built Gizmos to your victory-point tokens. Break ties by the number of built Gizmos, then by remaining energy marbles.",
			myTurn: "Your turn: pick one of four actions",
			waitTurn: "Waiting for {{name}}…",
			lastLap: "Final round",
			researchPrompt: "Research: build or file 1 card, or return all",
			pendingPrompt: "Activate a Gizmo effect, or skip the rest",
			comboStatus: "Combo · {{n}} pending",
			pickPrompt: "Pick: take 1 marble from the energy row",
			filePrompt: "File: choose 1 card from the display",
			buildFreePrompt: "Free build: choose a level-1 card from the display",
			researchPickPrompt: "Research: choose a deck",
			actFile: "File",
			actPick: "Pick",
			actBuild: "Build",
			actResearch: "Research",
			skipTriggers: "Skip remaining effects",
			cancel: "Cancel",
			confirmBuild: "Build",
			storageLabel: "Storage",
			archiveLabel: "Archive",
			builtLabel: "Built",
			engineTitle: "Invention engine",
			engineCount: "Built {{n}}/16",
			pendingCount: "{{n}} pending",
			marketTitle: "Invention display",
			marketLegend: "Icons: trigger › effect",
			engineHint: "Tap a market card to file or build; tap a marble to pick",
			selectedEffect: "Selected card",
			pendingDetail: "Current effect",
			pendingOrdinal: "Pending effect {{n}}",
			usedCard: "Used this turn",
			columnConvert: "Convert",
			columnUpgrade: "Upgrade",
			vpLabel: "VP tokens",
			scoreLabel: "Score",
			deckCount: "{{n}} left",
			supplyCount: "{{n}} in dispenser",
			tierLabel: "Level {{n}}",
			cardCount: "{{n}} cards",
			energyK: "Battery",
			energyB: "Atomic",
			energyR: "Heat",
			energyY: "Electric",
			energyAny: "Any",
			fxDraw1: "Draw 1 random energy",
			fxDraw3: "Draw 3 random energy",
			fxPick1: "Pick 1 energy",
			fxPick2: "Pick 2 energy",
			fxVp1: "Gain 1 VP token",
			fxVp2: "Gain 2 VP tokens",
			fxFile: "File 1 card",
			fxResearch: "Research once",
			fxFreeBuild1: "Build a level-1 card for free",
			trigFile: "When you file",
			trigPick: "When you pick {{c}}",
			trigPick2: "When you pick {{c1}} or {{c2}}",
			trigBuild: "When you build {{c}}",
			trigBuild2: "When you build {{c1}} or {{c2}}",
			trigBuildArchive: "When you build from archive",
			trigBuildTier2: "When you build a level-2 card",
			convToAny: "{{c}} → any color",
			convAnyToAny: "Any color → any color",
			convDouble: "{{c}} → two {{c}}",
			convOneOrTwo: "1-2 {{c}} → that many of any color",
			convPair: "One {{c1}} and one {{c2}} → two of each",
			upgStorage: "Storage cap increased by {{n}}",
			upgFile: "Archive cap increased by {{n}}",
			upgResearch: "Research draws {{n}} more",
			upgBanFile: "Filing is banned this game",
			upgBanResearch: "Research is banned this game",
			upgDiscTier2: "Level-2 cards cost 1 less",
			upgDiscArchive: "Building from archive costs 1 less",
			upgDiscResearch: "Building from research costs 1 less",
			upgAwardEnergy: "Endgame: +1 point per stored energy",
			upgAwardVp: "Endgame: +1 point per VP token",
			startCard: "Starting Gizmo",
			payTitle: "Pay {{n}} energy",
			payNeedColor: "All must become {{c}}",
			payNeedAny: "Any mix of colors",
			payPickMarble: "Tap stored energy",
			payConvertHint: "Tap a converter to recolor or double",
			payConvertTo: "into",
			payRemove: "Remove",
			payShort: "{{n}} more needed",
			freeBuildLabel: "Free build",
			researchTitle: "Research: level {{n}} deck",
			researchBuild: "Build",
			researchFile: "File",
			researchNone: "Return all",
			errNotYourTurn: "Not your turn",
			errBanned: "That action is banned by your Gizmo",
			errArchiveFull: "Archive is full",
			errStorageFull: "Storage ring is full",
			errBadPay: "Invalid payment",
			errBadCard: "Invalid card",
			errBadPick: "Invalid pick",
			errDeckEmpty: "That deck is empty",
			errPending: "Resolve pending effects first",
			errNoPending: "Nothing to skip"
		}
	}
};
//#endregion
export { wt as default };
