import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useState as n } from "react";
import { useFxAnchor as r } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as i, useT as a } from "@bgparty/sdk/i18n";
import { IconClose as o, IconHistory as s, IconRecenter as c } from "@bgparty/sdk/icons";
import { SheetView as l } from "@bgparty/sdk/sheet-view";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { seatName as d } from "@bgparty/sdk/ui/player-strip";
import { Fragment as f, jsx as p, jsxs as m } from "react/jsx-runtime";
import { Floater as h, FlySprite as g } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as _ } from "@bgparty/sdk/confirm-button";
import { GameOverChime as v } from "@bgparty/sdk/ui/game-over-screen";
//#region src/games/summy/meta.ts
var y = {
	id: "summy",
	tier: "alpha",
	mechanics: ["tile-placement", "hand-management"],
	interactionTags: [],
	nameKey: "games.summy.name",
	descKey: "games.summy.desc",
	rulesKey: "games.summy.rules",
	icon: "🧮",
	iconImg: "games/summy.webp",
	minPlayers: 2,
	maxPlayers: 2,
	bestPlayers: [2],
	accent: "#c1622c",
	releasedAt: "2026-11-03T02:26:53+08:00",
	search: {
		py: "",
		init: ""
	},
	hotseat: "cover",
	rulesUrl: { en: "https://www.cwali.nl/summy/summy.htm" }
}, b = (e, t) => `${e},${t}`, x = (e) => e === "*" ? "×" : e === "/" ? "÷" : e === "-" ? "−" : e, S = {
	0: "#8b89d9",
	1: "#f093d7",
	2: "#c99a7d",
	3: "#f49642",
	4: "#c5dc4d",
	5: "#7dce64",
	6: "#76d8e4",
	7: "#ed6554",
	8: "#f2dd55",
	9: "#cf66ba",
	"+": "#e4e1d8",
	"-": "#e4e1d8",
	"*": "#bcbdbb",
	"/": "#bcbdbb",
	"=": "#f2efdf"
}, C = () => [
	...Array.from({ length: 10 }, (e, t) => [
		,
		,
		,
		,
		,
		,
	].fill(String(t))).flat(),
	...[
		"+",
		"-",
		"*",
		"/"
	].flatMap((e) => [
		,
		,
		,
		,
		,
	].fill(e)),
	...Array(14).fill("=")
], w = (e, t) => t === 0n ? e < 0n ? -e : e : w(t, e % t), T = (e, t = 1n) => {
	let n = w(e, t);
	return {
		n: e / n,
		d: t / n
	};
}, E = (e, t, n) => T(e.n * t.d + (n ? -1n : 1n) * t.n * e.d, e.d * t.d);
function D(e) {
	if (e.length > 94 || !/^(0|[1-9]\d*)([+*/-](0|[1-9]\d*))+=(0|[1-9]\d*)$/.test(e)) return null;
	let [t, n] = e.split("="), r = t.match(/\d+|[+*/-]/g), i = T(0n), a = T(BigInt(r[0])), o = !1;
	for (let e = 1; e < r.length; e += 2) {
		let t = r[e], n = BigInt(r[e + 1]);
		if (t === "*") a = T(a.n * n, a.d);
		else if (t === "/") {
			if (n === 0n) return null;
			a = T(a.n, a.d * n);
		} else i = E(i, a, o), a = T(n), o = t === "-";
	}
	return i = E(i, a, o), i.n === BigInt(n) * i.d ? [...e].reduce((e, t) => e + (/\d/.test(t) ? Number(t) : 0), 0) : null;
}
function O(e, t, n, r) {
	let { tiles: i, axis: a } = r;
	if (!i.length || i.length > 8 || new Set(i.map((e) => e.index)).size !== i.length || i.some((e) => !n[e.index])) return "hand";
	if (new Set(i.map((e) => b(e.x, e.y))).size !== i.length) return "occupied";
	if (i.some((e) => a === "h" ? e.y !== i[0].y : e.x !== i[0].x)) return "line";
	let o = new Map(e.map((e) => [b(e.x, e.y), e])), s = new Set(t.map((e) => b(e.x, e.y)));
	if (i.some((e) => o.has(b(e.x, e.y)))) return "occupied";
	if (i.some((e) => s.has(b(e.x, e.y)))) return "endpoint";
	let c = i.map((e) => ({
		x: e.x,
		y: e.y,
		symbol: n[e.index]
	}));
	for (let e of c) o.set(b(e.x, e.y), e);
	let l = +(a === "h"), u = +(a === "v"), d = i.reduce((e, t) => (a === "h" ? e.x < t.x : e.y < t.y) ? e : t), f = d.x, p = d.y;
	for (; o.has(b(f - l, p - u));) f -= l, p -= u;
	d = {
		...d,
		x: f,
		y: p
	};
	let m = [];
	for (; o.has(b(f, p));) m.push(o.get(b(f, p))), f += l, p += u;
	if (c.some((e) => !m.some((t) => t.x === e.x && t.y === e.y))) return "line";
	if (m.length === c.length) return "connected";
	let h = D(m.map((e) => e.symbol).join(""));
	return h === null ? "equation" : {
		cells: m,
		fresh: c,
		points: h,
		ends: [{
			x: d.x - l,
			y: d.y - u
		}, {
			x: f,
			y: p
		}]
	};
}
//#endregion
//#region src/games/summy/schema.ts
var k = t.enum([
	"0",
	"1",
	"2",
	"3",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"+",
	"-",
	"*",
	"/",
	"="
]), A = t.int().min(-94).max(94), j = t.object({
	x: A,
	y: A,
	symbol: k
}), M = t.object({
	x: A,
	y: A,
	index: t.int().min(0).max(7)
}), N = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		axis: t.enum(["h", "v"]),
		tiles: t.array(M).min(1).max(8)
	}),
	t.object({
		type: t.literal("discard"),
		indices: t.array(t.int().min(0).max(7)).min(1).max(8)
	}),
	t.object({ type: t.literal("pass") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), P = t.object({
	cells: t.array(j),
	by: t.string(),
	points: t.int().nonnegative(),
	turn: t.int().positive()
}), F = t.object({
	by: t.string(),
	kind: t.enum([
		"place",
		"discard",
		"pass"
	]),
	text: t.string(),
	points: t.int().nonnegative(),
	count: t.int().nonnegative(),
	turn: t.int().positive()
}), I = t.object({
	phase: t.enum([
		"play",
		"settle",
		"done"
	]),
	turn: t.string(),
	turnNumber: t.int().positive(),
	board: t.array(j).max(94),
	blocked: t.array(t.object({
		x: A,
		y: A
	})),
	sums: t.array(P),
	log: t.array(F),
	stockCount: t.int().nonnegative(),
	passes: t.int().nonnegative(),
	discardedCount: t.int().nonnegative(),
	players: t.array(t.object({
		rid: t.string(),
		score: t.int().nonnegative(),
		handCount: t.int().min(0).max(8)
	}))
}), L = t.object({ hand: t.array(k).max(8) });
function R(t, n, r) {
	let i = C();
	i.splice(i.indexOf("="), 1);
	let a = 0;
	for (let t = i.length - 1; t > 0; t--) {
		let n = e(r, a++, t + 1);
		[i[t], i[n]] = [i[n], i[t]];
	}
	let o = Object.fromEntries(n.map((e) => [e, i.splice(0, 8)])), s = (e) => o[e].filter((e) => /^\d$/.test(e)).map(Number).sort((e, t) => e - t), c = [...n].sort((e, t) => {
		let n = s(e), r = s(t);
		for (let e = 0; e < Math.max(n.length, r.length); e++) {
			let t = (n[e] ?? 10) - (r[e] ?? 10);
			if (t) return t;
		}
		return 0;
	});
	return { state: {
		players: [...n],
		hands: o,
		stock: i,
		discarded: [],
		board: [{
			x: 0,
			y: 0,
			symbol: "="
		}],
		blocked: [],
		sums: [],
		log: [],
		scores: Object.fromEntries(n.map((e) => [e, 0])),
		turnIdx: n.indexOf(c[0]),
		turnNumber: 1,
		passes: 0,
		phase: "play",
		step: "action",
		seed: r,
		cursor: a
	} };
}
function z(e) {
	e.phase = e.stock.length === 0 && e.passes >= e.players.length ? "done" : "play", e.turnIdx = (e.turnIdx + 1) % e.players.length, e.turnNumber++;
}
function B(e, t, { by: n }) {
	if (t.type === "tick") {
		if (n !== "$engine" || e.phase !== "settle") return { code: "games.summy.errorTurn" };
		let t = structuredClone(e), r = t.players[t.turnIdx];
		if (t.step === "action") {
			let e = t.hands[r].length, n = t.stock.splice(0, Math.min(8 - e, t.stock.length));
			if (t.hands[r].push(...n), t.step = "refill", n.length) return {
				state: t,
				fx: [{
					kind: "refill",
					rid: r,
					data: { count: n.length },
					for: [r],
					secret: { cards: n.map((t, n) => ({
						symbol: t,
						index: e + n
					})) }
				}]
			};
		}
		return z(t), { state: t };
	}
	if (e.phase !== "play" || e.players[e.turnIdx] !== n) return { code: "games.summy.errorTurn" };
	let r = e.hands[n], i;
	if (t.type === "place") {
		if (i = O(e.board, e.blocked, r, t), typeof i == "string") return { code: {
			line: "games.summy.errorLine",
			occupied: "games.summy.errorOccupied",
			hand: "games.summy.errorHand",
			connected: "games.summy.errorConnected",
			equation: "games.summy.errorEquation",
			endpoint: "games.summy.errorEndpoint"
		}[i] };
	} else if (t.type === "discard") {
		if (!t.indices.length || new Set(t.indices).size !== t.indices.length || t.indices.some((e) => !r[e])) return { code: "games.summy.errorHand" };
	} else if (e.stock.length || r.length) return { code: "games.summy.errorPass" };
	let a = structuredClone(e), o = [], s = [], c = 0, l = "";
	return t.type === "place" && i && typeof i != "string" ? (s = t.tiles.map((e) => e.index), c = i.points, l = i.cells.map((e) => e.symbol).join(""), a.board.push(...i.fresh), a.blocked.push(...i.ends), a.sums.push({
		cells: i.cells,
		points: c,
		by: n,
		turn: e.turnNumber
	}), a.scores[n] += c, a.passes = 0, o.push({
		kind: "place",
		rid: n,
		data: {
			tiles: i.fresh,
			points: c
		},
		for: [n],
		secret: { indices: s }
	})) : (s = t.type === "discard" ? t.indices : [], a.discarded.push(...s.map((e) => r[e])), a.passes = e.stock.length === 0 ? e.passes + 1 : 0, s.length && o.push({
		kind: "discard",
		rid: n,
		data: { count: s.length },
		for: [n],
		secret: { indices: s }
	})), a.hands[n] = r.filter((e, t) => !s.includes(t)), a.log.push({
		by: n,
		kind: t.type,
		text: l,
		points: c,
		count: s.length,
		turn: e.turnNumber
	}), a.phase = "settle", a.step = "action", {
		state: a,
		fx: o
	};
}
function V(e, t) {
	return {
		public: {
			phase: e.phase,
			turn: e.players[e.turnIdx],
			turnNumber: e.turnNumber,
			board: e.board,
			blocked: e.blocked,
			sums: e.sums,
			log: e.log,
			stockCount: e.stock.length,
			passes: e.passes,
			discardedCount: e.discarded.length,
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				handCount: e.hands[t].length
			}))
		},
		private: { hand: e.hands[t] ?? [] }
	};
}
function H(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]);
	return {
		phase: e.phase,
		winner: t.filter((n) => e.scores[n] === e.scores[t[0]]),
		ranking: t,
		scores: { ...e.scores }
	};
}
var U = {
	meta: y,
	schemas: {
		action: N,
		publicView: I,
		privateView: L
	},
	saveCompatibility: { version: "1" },
	setup: R,
	reduce: B,
	viewFor: V,
	status: H,
	nextTickIn: (e) => e.phase === "settle" ? e.step === "action" ? 420 : 360 : null
};
//#endregion
//#region src/games/summy/placement.ts
function W(e) {
	return e.length < 2 ? null : e.every((t) => t.y === e[0].y) ? "h" : e.every((t) => t.x === e[0].x) ? "v" : null;
}
function G(e, t, n) {
	let r = W(n);
	return (r ? [r] : ["h", "v"]).map((r) => {
		let i = {
			type: "place",
			axis: r,
			tiles: n
		};
		return {
			action: i,
			checked: O(e.board, e.blocked, t, i)
		};
	}).reduce((e, t) => typeof t.checked != "string" && (typeof e.checked == "string" || t.checked.points > e.checked.points) ? t : e);
}
//#endregion
//#region src/games/summy/tile.tsx
function K({ symbol: e, selected: t = !1, back: n = !1 }) {
	return /* @__PURE__ */ m("svg", {
		viewBox: "0 0 64 68",
		width: "100%",
		height: "100%",
		"aria-hidden": "true",
		className: "summy-tile-art",
		children: [
			/* @__PURE__ */ p("rect", {
				x: "1",
				y: "6",
				width: "62",
				height: "61",
				rx: "4",
				fill: "#a87c4c"
			}),
			/* @__PURE__ */ p("rect", {
				x: "1",
				y: "1",
				width: "62",
				height: "61",
				rx: "4",
				fill: "#e6c79b",
				stroke: "#9d784e",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ p("path", {
				d: "M4 59h55M6 63h49M4 11h3M57 30h4",
				stroke: "#b48f62",
				strokeWidth: ".7",
				opacity: ".65"
			}),
			!n && e ? /* @__PURE__ */ m(f, { children: [
				/* @__PURE__ */ p("rect", {
					x: "5",
					y: "5",
					width: "54",
					height: "51",
					rx: "1",
					fill: S[e],
					stroke: "#fff",
					strokeOpacity: ".2"
				}),
				/* @__PURE__ */ p("text", {
					x: "32",
					y: "43",
					textAnchor: "middle",
					fontSize: "43",
					fontWeight: "800",
					fontFamily: "Arial, sans-serif",
					fill: "#211d19",
					children: x(e)
				}),
				(e === "6" || e === "9") && /* @__PURE__ */ p("path", {
					d: "M23 49h18",
					stroke: "#211d19",
					strokeWidth: "2"
				})
			] }) : /* @__PURE__ */ p("path", {
				d: "M10 16c15-7 26 8 44-1M8 32c20-8 27 7 48-2M11 48c17-5 28 5 43-2",
				fill: "none",
				stroke: "#bc9566",
				strokeWidth: "1.5"
			}),
			t && /* @__PURE__ */ p("rect", {
				x: "2",
				y: "2",
				width: "60",
				height: "63",
				rx: "4",
				fill: "none",
				stroke: "#fff",
				strokeWidth: "3"
			})
		]
	});
}
//#endregion
//#region src/games/summy/view-player.tsx
var q = 72, J = {
	line: "errorLine",
	occupied: "errorOccupied",
	hand: "errorHand",
	connected: "errorConnected",
	equation: "errorEquation",
	endpoint: "errorEndpoint"
};
function Y({ cell: e, x: t, y: n }) {
	let { ref: i, hidden: a } = r(`summy-cell:${e.x},${e.y}`);
	return /* @__PURE__ */ p("foreignObject", {
		x: t + 4,
		y: n + 2,
		width: 64,
		height: 68,
		pointerEvents: "none",
		children: /* @__PURE__ */ p("div", {
			ref: i,
			style: {
				width: 64,
				height: 68,
				visibility: a ? "hidden" : void 0
			},
			children: /* @__PURE__ */ p(K, { symbol: e.symbol })
		})
	});
}
function X({ pub: e, hand: t = [], draft: n = [], selected: r = null, active: i = !1, fit: o = 0, onCell: s }) {
	let c = a(), u = W(n), d = [...e.board, ...n.map((e) => ({
		...e,
		symbol: t[e.index]
	}))], f = Math.floor(Math.min(-4, ...d.map((e) => e.x - 1)) / 4) * 4, h = Math.floor(Math.min(-4, ...d.map((e) => e.y - 1)) / 4) * 4, g = Math.ceil(Math.max(4, ...d.map((e) => e.x + 1)) / 4) * 4, _ = Math.ceil(Math.max(4, ...d.map((e) => e.y + 1)) / 4) * 4, v = (e, t) => ({
		x: (e - f) * q,
		y: (t - h) * q,
		w: q,
		h: q
	}), y = new Set(e.board.map((e) => b(e.x, e.y))), S = new Set(e.blocked.map((e) => b(e.x, e.y))), C = new Set(n.map((e) => b(e.x, e.y))), w = [];
	if (i) for (let e = h; e <= _; e++) for (let t = f; t <= g; t++) {
		let i = b(t, e);
		if (C.has(i)) {
			w.push({
				key: i,
				rect: v(t, e)
			});
			continue;
		}
		r === null || Math.abs(t) > 93 || Math.abs(e) > 93 || y.has(i) || S.has(i) || n.length && (u === "h" ? e !== n[0].y : (u === "v" || e !== n[0].y) && t !== n[0].x) || w.push({
			key: i,
			rect: v(t, e)
		});
	}
	let T = n[0], E = [];
	if (T && r !== null && i) for (let e of w) C.has(e.key) || E.push(/* @__PURE__ */ p("rect", {
		x: e.rect.x + 4,
		y: e.rect.y + 4,
		width: 64,
		height: 64,
		rx: 4,
		fill: "none",
		stroke: "#eee1c8",
		strokeWidth: 1.5,
		strokeDasharray: "5 5",
		pointerEvents: "none",
		children: /* @__PURE__ */ p("animate", {
			attributeName: "stroke-dashoffset",
			from: "0",
			to: "-20",
			dur: "1s",
			repeatCount: "indefinite"
		})
	}, e.key));
	let D = w.map((e) => ({
		...e,
		rect: {
			x: e.rect.x + 14,
			y: e.rect.y + 14,
			w: e.rect.w - 28,
			h: e.rect.h - 28
		}
	}));
	return /* @__PURE__ */ m(l, {
		sheetW: (g - f + 1) * q,
		sheetH: (_ - h + 1) * q,
		fitKey: `${f}:${h}:${g}:${_}:${o}`,
		eligible: D,
		onTapEligible: s,
		readOnly: !i,
		highlight: "off",
		children: [
			i && r !== null && w.map((e) => /* @__PURE__ */ p("rect", {
				x: e.rect.x + 5,
				y: e.rect.y + 5,
				width: 62,
				height: 62,
				rx: 4,
				fill: "#e9d5b0",
				fillOpacity: .035,
				stroke: "#e9d5b0",
				strokeOpacity: .15,
				strokeWidth: 1,
				pointerEvents: "none"
			}, e.key)),
			e.blocked.map((e) => {
				let t = v(e.x, e.y);
				return /* @__PURE__ */ m("g", {
					opacity: .4,
					pointerEvents: "none",
					children: [/* @__PURE__ */ p("title", { children: c("games.summy.blocked") }), /* @__PURE__ */ p("path", {
						d: `M${t.x + 29} ${t.y + 29}l14 14m0-14l-14 14`,
						stroke: "#c6af91",
						strokeWidth: 2
					})]
				}, b(e.x, e.y));
			}),
			e.board.map((e) => {
				let t = v(e.x, e.y);
				return /* @__PURE__ */ p(Y, {
					cell: e,
					x: t.x,
					y: t.y
				}, b(e.x, e.y));
			}),
			n.map((e) => {
				let n = v(e.x, e.y);
				return /* @__PURE__ */ m("g", {
					opacity: .8,
					pointerEvents: "none",
					children: [
						/* @__PURE__ */ p("title", { children: c("games.summy.draft", { symbol: x(t[e.index]) }) }),
						/* @__PURE__ */ p("foreignObject", {
							x: n.x + 4,
							y: n.y + 2,
							width: 64,
							height: 68,
							children: /* @__PURE__ */ p("div", {
								style: {
									width: 64,
									height: 68
								},
								children: /* @__PURE__ */ p(K, { symbol: t[e.index] })
							})
						}),
						/* @__PURE__ */ p("rect", {
							x: n.x + 2,
							y: n.y,
							width: 68,
							height: 71,
							rx: 4,
							fill: "none",
							stroke: "#fff",
							strokeWidth: 2,
							strokeDasharray: "5 4"
						})
					]
				}, b(e.x, e.y));
			}),
			E
		]
	});
}
function Z({ rid: e, index: t, symbol: n, selected: i, used: o, disabled: s, onClick: c }) {
	let l = a(), { ref: u, hidden: d } = r(`summy-slot:${e}:${t}`);
	return /* @__PURE__ */ p("button", {
		ref: u,
		type: "button",
		className: "summy-hand-tile",
		"data-selected": i,
		"data-used": o,
		disabled: s || !n || o,
		onClick: c,
		"aria-pressed": i,
		"aria-label": n ? l("games.summy.tile", { symbol: x(n) }) : l("games.summy.emptySlot"),
		children: n && /* @__PURE__ */ p("span", {
			style: { visibility: o || d ? "hidden" : void 0 },
			children: /* @__PURE__ */ p(K, {
				symbol: n,
				selected: i
			})
		})
	});
}
function ee({ rid: e, name: t, score: n, current: i, me: o, count: s }) {
	let c = a(), { ref: l } = r(`summy-seat:${e}`), { ref: u } = r(`summy-score:${e}`);
	return /* @__PURE__ */ m("div", {
		ref: l,
		className: "summy-seat",
		"data-current": i,
		children: [
			/* @__PURE__ */ m("span", {
				title: t,
				children: [t, o && /* @__PURE__ */ p("small", { children: c("lobby.you") })]
			}),
			/* @__PURE__ */ p("strong", {
				ref: u,
				children: n
			}),
			/* @__PURE__ */ p("small", { children: c("games.summy.handN", { n: s }) })
		]
	});
}
function te({ public: e, private: t, members: l, myRid: f, send: h }) {
	let g = e, _ = t?.hand ?? [], v = a(), y = i((e) => e.locale), S = (e) => {
		let t = l.find((t) => t.rid === e);
		return t ? d(t, y) : e;
	}, C = g.phase === "play" && g.turn === f, [w, T] = n([]), [E, D] = n(null), [O, k] = n(!1), [A, j] = n([]), [M, N] = n(!1), [P, F] = n(0), I = `${f}:${g.turnNumber}:${g.phase}`, [L, R] = n(I);
	I !== L && (R(I), T([]), D(null), j([]), k(!1));
	let { ref: z } = r(`summy-hand:${f}`), { ref: B } = r("summy-stock"), { ref: V } = r("summy-discards"), { action: H, checked: U } = G(g, _, w), W = w.length ? U : null, K = () => {
		T([]), D(null), j([]);
	}, q = O ? v("games.summy.discardN", { n: A.length }) : W && typeof W != "string" ? v("games.summy.preview", {
		sum: W.cells.map((e) => x(e.symbol)).join(""),
		n: W.points
	}) : W ? v(`games.summy.${J[W]}`) : C ? v("games.summy.selectTile") : g.phase === "settle" ? v("games.summy.settling") : g.phase === "done" ? v("games.summy.finished") : v("games.summy.turn", { name: S(g.turn) });
	return /* @__PURE__ */ m("div", {
		className: "summy-root",
		children: [/* @__PURE__ */ p("div", {
			inert: M,
			style: { height: "100%" },
			children: /* @__PURE__ */ p(u, {
				adaptive: !0,
				scroll: !1,
				className: "summy-screen",
				actionsHeight: "summy-action-height",
				banner: /* @__PURE__ */ m("header", {
					className: "summy-header",
					children: [/* @__PURE__ */ p("b", {
						className: "summy-brand",
						children: "SUMMY"
					}), /* @__PURE__ */ p("div", {
						className: "summy-seats",
						children: g.players.map((e) => /* @__PURE__ */ p(ee, {
							rid: e.rid,
							name: S(e.rid),
							score: e.score,
							count: e.handCount,
							me: e.rid === f,
							current: g.phase !== "done" && e.rid === g.turn
						}, e.rid))
					})]
				}),
				actions: /* @__PURE__ */ m("div", {
					className: "summy-actions",
					children: [
						/* @__PURE__ */ p("p", {
							className: "summy-preview",
							role: "status",
							title: q,
							children: q
						}),
						/* @__PURE__ */ p("div", {
							ref: z,
							className: "summy-hand",
							"aria-label": v("games.summy.hand"),
							children: Array.from({ length: 8 }, (e, t) => /* @__PURE__ */ p(Z, {
								rid: f,
								index: t,
								symbol: _[t],
								selected: O ? A.includes(t) : E === t,
								used: w.some((e) => e.index === t),
								disabled: !C,
								onClick: () => {
									O ? j(A.includes(t) ? A.filter((e) => e !== t) : [...A, t]) : D(E === t ? null : t);
								}
							}, t))
						}),
						/* @__PURE__ */ m("div", {
							className: "summy-buttons",
							children: [
								/* @__PURE__ */ p("button", {
									type: "button",
									disabled: !C,
									onClick: () => {
										K(), k(!O);
									},
									children: v(O ? "games.summy.cancel" : "games.summy.discard")
								}),
								w.length > 0 && /* @__PURE__ */ p("button", {
									type: "button",
									disabled: !C,
									onClick: K,
									children: v("games.summy.clear")
								}),
								!_.length && !g.stockCount ? /* @__PURE__ */ p("button", {
									type: "button",
									className: "summy-primary",
									disabled: !C,
									onClick: () => h({ type: "pass" }),
									children: v("games.summy.pass")
								}) : /* @__PURE__ */ p("button", {
									type: "button",
									className: "summy-primary",
									disabled: !C || (O ? !A.length : !W || typeof W == "string"),
									onClick: () => h(O ? {
										type: "discard",
										indices: A
									} : H),
									children: O ? v("games.summy.discardN", { n: A.length }) : v("games.summy.confirm")
								})
							]
						})
					]
				}),
				children: /* @__PURE__ */ m("div", {
					className: "summy-table",
					children: [/* @__PURE__ */ m("div", {
						className: "summy-table-tools",
						children: [/* @__PURE__ */ m("div", {
							className: "summy-supply",
							children: [/* @__PURE__ */ p("span", {
								ref: B,
								children: v("games.summy.stock", { n: g.stockCount })
							}), /* @__PURE__ */ p("span", {
								ref: V,
								children: v("games.summy.discarded", { n: g.discardedCount })
							})]
						}), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": v("games.summy.fit"),
							title: v("games.summy.fit"),
							onClick: () => F(P + 1),
							children: /* @__PURE__ */ p(c, { size: 20 })
						}), /* @__PURE__ */ p("button", {
							type: "button",
							"aria-label": v("games.summy.history"),
							title: v("games.summy.history"),
							onClick: () => N(!0),
							children: /* @__PURE__ */ p(s, { size: 20 })
						})] })]
					}), /* @__PURE__ */ p("div", {
						className: "summy-board",
						children: /* @__PURE__ */ p(X, {
							pub: g,
							hand: _,
							draft: w,
							selected: O ? null : E,
							active: C && !O,
							fit: P,
							onCell: (e) => {
								let t = w.find((t) => b(t.x, t.y) === e);
								if (t) {
									T(w.filter((e) => e !== t)), D(t.index);
									return;
								}
								if (E === null) return;
								let [n, r] = e.split(",").map(Number);
								T([...w, {
									x: n,
									y: r,
									index: E
								}]), D(null);
							}
						})
					})]
				})
			})
		}), M && /* @__PURE__ */ p("div", {
			className: "summy-shade",
			children: /* @__PURE__ */ m("section", {
				className: "summy-history",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": v("games.summy.history"),
				children: [/* @__PURE__ */ m("header", { children: [/* @__PURE__ */ p("h2", { children: v("games.summy.history") }), /* @__PURE__ */ p("button", {
					type: "button",
					"aria-label": v("games.summy.close"),
					onClick: () => N(!1),
					children: /* @__PURE__ */ p(o, {})
				})] }), /* @__PURE__ */ p("div", {
					className: "summy-history-list",
					children: g.log.length ? g.log.map((e) => /* @__PURE__ */ p("p", { children: e.kind === "place" ? v("games.summy.logPlace", {
						name: S(e.by),
						sum: e.text.replaceAll("*", "×").replaceAll("/", "÷").replaceAll("-", "−"),
						n: e.points
					}) : e.kind === "discard" ? v("games.summy.logDiscard", {
						name: S(e.by),
						n: e.count
					}) : v("games.summy.logPass", { name: S(e.by) }) }, e.turn)) : /* @__PURE__ */ p("p", { children: v("games.summy.noHistory") })
				})]
			})
		})]
	});
}
//#endregion
//#region src/games/summy/bot.ts
var Q = /* @__PURE__ */ new Map();
function ne(e) {
	let t = Q.get(e);
	if (t) return t;
	let n = /* @__PURE__ */ new Set();
	for (let t = 0; t <= e; t++) for (let e = 0; e <= 9; e++) for (let [r, i] of [
		["+", t + e],
		["-", t - e],
		["*", t * e],
		["/", e ? t / e : -1]
	]) Number.isInteger(i) && i >= 0 && n.add(`${t}${r}${e}=${i}`);
	let r = [...n].filter((e) => D(e) !== null);
	return Q.set(e, r), r;
}
function re(e, t, n = 0, r = 19) {
	let i = new Map(e.board.map((e) => [b(e.x, e.y), e.symbol])), a = new Set(e.blocked.map((e) => b(e.x, e.y))), o = /* @__PURE__ */ new Map();
	t.forEach((e, t) => o.set(e, [...o.get(e) ?? [], t]));
	let s = null, c = -Infinity, l = /* @__PURE__ */ new Set();
	for (let u of ne(r)) for (let r of e.board) for (let d = 0; d < u.length; d++) if (u[d] === r.symbol) for (let f of ["h", "v"]) {
		let p = +(f === "h"), m = +(f === "v"), h = r.x - d * p, g = r.y - d * m, _ = `${h}:${g}:${f}:${u}`;
		if (l.has(_) || (l.add(_), i.has(b(h - p, g - m)) || i.has(b(h + u.length * p, g + u.length * m)))) continue;
		let v = /* @__PURE__ */ new Map(), y = [], x = !0;
		for (let e = 0; e < u.length; e++) {
			let t = h + e * p, n = g + e * m, r = b(t, n), s = i.get(r);
			if (s) {
				if (s !== u[e]) {
					x = !1;
					break;
				}
				continue;
			}
			if (Math.abs(t) > 93 || Math.abs(n) > 93 || a.has(r)) {
				x = !1;
				break;
			}
			let c = v.get(u[e]) ?? 0, l = o.get(u[e])?.[c];
			if (l === void 0) {
				x = !1;
				break;
			}
			v.set(u[e], c + 1), y.push({
				x: t,
				y: n,
				index: l
			});
		}
		if (!x || y.length === 0) continue;
		let S = {
			type: "place",
			axis: f,
			tiles: y
		}, C = O(e.board, e.blocked, t, S);
		if (typeof C == "string") continue;
		let w = t.filter((e, t) => !y.some((e) => e.index === t)), T = w.filter((e) => "+-*/".includes(e)).length, E = w.filter((e) => /^\d$/.test(e)).length, D = Math.min(T, 2) * .7 + Math.min(E, 4) * .3 - Math.max(0, T - 2), k = C.points + y.length * .01 + D * n;
		k > c && (s = S, c = k);
	}
	if (s) return s;
	if (!t.length) return { type: "pass" };
	let u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Map();
	for (let e = 0; e < t.length; e++) {
		let n = d.get(t[e]) ?? 0;
		n === 0 && t[e] !== "=" && u.add(e), d.set(t[e], n + 1);
	}
	let f = t.map((e, t) => t).filter((e) => !u.has(e));
	return f.length || (f = t.map((e, t) => t).filter((e) => t[e] === "0" || t[e] === "1" || t[e] === "/")), f.length || (f = [0]), {
		type: "discard",
		indices: f
	};
}
var ie = (e, t) => e.public.phase !== "play" || e.public.turn !== t.rid || !e.private ? null : { action: re(e.public, e.private.hand, 0, t.difficulty === "weak" ? 9 : 19) }, ae = (e, t, n) => {
	if (e.type === "tick") return n("games.summy.waiting");
	if (e.type === "pass") return n("games.summy.pass");
	if (e.type === "discard") return n("games.summy.discardN", { n: e.indices.length });
	let r = O(t.public.board, t.public.blocked, t.private?.hand ?? [], e);
	return typeof r == "string" ? n("games.summy.place") : n("games.summy.hint", {
		sum: r.cells.map((e) => e.symbol === "*" ? "×" : e.symbol === "/" ? "÷" : e.symbol).join(""),
		n: r.points
	});
}, $ = (e, t = 36, n = 38) => ({
	x: e.x + (e.w - t) / 2,
	y: e.y + (e.h - n) / 2,
	w: t,
	h: n
}), oe = {
	place(e, t) {
		if (t.queued) return null;
		let n = e.data, r = e.secret?.indices, i = [], a = n.tiles.flatMap((n, a) => {
			let o = `summy-cell:${n.x},${n.y}`, s = t.anchor(o), c = r ? t.anchor(`summy-slot:${e.rid}:${r[a]}`) : t.anchor(`summy-seat:${e.rid}`);
			if (!s || !c) return [];
			i.push(o);
			let l = r ? c : $(c);
			return [/* @__PURE__ */ p(g, {
				from: l,
				to: s,
				ms: 360,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: l.w,
						height: l.h
					},
					children: /* @__PURE__ */ p(K, { symbol: n.symbol })
				})
			}, a)];
		}), o = t.anchor(`summy-score:${e.rid}`);
		return o && a.push(/* @__PURE__ */ p(h, {
			at: o,
			ms: 420,
			children: /* @__PURE__ */ m("span", {
				className: "summy-fx-score",
				children: ["+", n.points]
			})
		}, "score")), {
			ms: 420,
			node: a,
			hide: i
		};
	},
	discard(e, t) {
		if (t.queued) return null;
		let n = t.anchor(`summy-hand:${e.rid}`) ?? t.anchor(`summy-seat:${e.rid}`), r = t.anchor("summy-discards");
		if (!n || !r) return null;
		let i = e.data, a = e.secret?.indices;
		return {
			ms: 420,
			node: Array.from({ length: i.count }, (i, o) => /* @__PURE__ */ p(g, {
				from: $(a ? t.anchor(`summy-slot:${e.rid}:${a[o]}`) ?? n : n),
				to: $(r),
				ms: 360,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 36,
						height: 38
					},
					children: /* @__PURE__ */ p(K, { back: !0 })
				})
			}, o))
		};
	},
	refill(e, t) {
		if (t.queued) return null;
		let n = t.anchor("summy-stock");
		if (!n) return null;
		let r = e.secret, i = r?.cards ?? Array.from({ length: e.data.count }, (e, t) => ({
			index: t,
			symbol: void 0
		})), a = [], o = i.flatMap((i, o) => {
			let s = `summy-slot:${e.rid}:${i.index}`, c = (r ? t.anchor(s) : null) ?? t.anchor(`summy-seat:${e.rid}`);
			return c ? (r && a.push(s), [/* @__PURE__ */ p(g, {
				from: $(n),
				to: r ? c : $(c),
				ms: 320,
				children: /* @__PURE__ */ p("div", {
					style: {
						width: 36,
						height: 38
					},
					children: /* @__PURE__ */ p(K, {
						symbol: i.symbol,
						back: !r
					})
				})
			}, o)]) : [];
		});
		return o.length ? {
			ms: 360,
			node: o,
			hide: a
		} : null;
	}
};
//#endregion
//#region src/games/summy/game-over.tsx
function se({ public: e, result: t, members: r, myRid: l, hintCount: f, onPlayAgain: h, onBackToLobby: g }) {
	let y = e, b = a(), S = i((e) => e.locale), [C, w] = n(!0), [T, E] = n(0), D = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? d(t, S) : e;
	};
	return /* @__PURE__ */ m("div", {
		className: "summy-final",
		children: [
			/* @__PURE__ */ p(v, {}),
			/* @__PURE__ */ p("div", {
				inert: C,
				style: { height: "100%" },
				children: /* @__PURE__ */ p(u, {
					adaptive: !0,
					scroll: !1,
					className: "summy-screen",
					actionsHeight: "summy-review-actions",
					banner: /* @__PURE__ */ m("header", {
						className: "summy-header",
						children: [/* @__PURE__ */ p("b", {
							className: "summy-brand",
							children: "SUMMY"
						}), /* @__PURE__ */ p("div", {
							className: "summy-seats",
							children: y.players.map((e) => /* @__PURE__ */ m("div", {
								className: "summy-seat",
								children: [/* @__PURE__ */ p("span", {
									title: D(e.rid),
									children: D(e.rid)
								}), /* @__PURE__ */ p("strong", { children: e.score })]
							}, e.rid))
						})]
					}),
					actions: /* @__PURE__ */ p("div", {
						className: "summy-review-actions",
						children: /* @__PURE__ */ p("button", {
							type: "button",
							className: "summy-show-result",
							onClick: () => w(!0),
							children: b("games.summy.showResult")
						})
					}),
					children: /* @__PURE__ */ m("div", {
						className: "summy-table",
						children: [/* @__PURE__ */ m("div", {
							className: "summy-table-tools",
							children: [/* @__PURE__ */ p("span", { children: b("games.summy.finished") }), /* @__PURE__ */ m("div", { children: [/* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": b("games.summy.fit"),
								onClick: () => E(T + 1),
								children: /* @__PURE__ */ p(c, { size: 20 })
							}), /* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": b("games.summy.history"),
								onClick: () => w(!0),
								children: /* @__PURE__ */ p(s, { size: 20 })
							})] })]
						}), /* @__PURE__ */ p("div", {
							className: "summy-board",
							children: /* @__PURE__ */ p(X, {
								pub: y,
								fit: T
							})
						})]
					})
				})
			}),
			/* @__PURE__ */ p("div", {
				className: "summy-shade summy-result-shade",
				hidden: !C,
				children: /* @__PURE__ */ m("section", {
					className: "summy-result-panel",
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "summy-result-title",
					children: [
						/* @__PURE__ */ m("header", {
							className: "summy-result-heading",
							children: [/* @__PURE__ */ p("h1", {
								id: "summy-result-title",
								children: b("games.summy.resultTitle")
							}), /* @__PURE__ */ p("button", {
								type: "button",
								"aria-label": b("games.summy.review"),
								onClick: () => w(!1),
								children: /* @__PURE__ */ p(o, {})
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "summy-result-scroll",
							children: [
								/* @__PURE__ */ p("p", {
									className: "summy-result-winner",
									children: t.winner.length > 1 ? b("games.summy.tied") : b("games.summy.winner", { name: D(t.winner[0]) })
								}),
								/* @__PURE__ */ p("div", {
									className: "summy-result-scores",
									children: t.ranking.map((e) => {
										let n = y.sums.filter((t) => t.by === e), r = t.autopilot?.[e];
										return /* @__PURE__ */ m("article", {
											className: "summy-result-person",
											"data-winner": t.winner.includes(e),
											children: [
												/* @__PURE__ */ m("h2", { children: [
													D(e),
													" ",
													e === l && /* @__PURE__ */ p("small", { children: b("lobby.you") })
												] }),
												/* @__PURE__ */ p("span", { children: b("games.summy.resultTotal") }),
												/* @__PURE__ */ p("strong", { children: t.scores?.[e] ?? 0 }),
												/* @__PURE__ */ p("span", { children: b("games.summy.equations", { n: n.length }) }),
												/* @__PURE__ */ p("span", { children: b("games.summy.best", { n: Math.max(0, ...n.map((e) => e.points)) }) }),
												r !== void 0 && r > 0 && /* @__PURE__ */ p("small", { children: b("session.autopilot.share", { n: Math.round(r * 100) }) })
											]
										}, e);
									})
								}),
								f !== void 0 && /* @__PURE__ */ p("p", { children: b("session.hint.usedCount", { n: f }) }),
								/* @__PURE__ */ m("section", {
									className: "summy-result-detail",
									children: [/* @__PURE__ */ p("h2", { children: b("games.summy.history") }), y.sums.length ? y.sums.map((e) => /* @__PURE__ */ m("p", { children: [
										/* @__PURE__ */ p("span", { children: D(e.by) }),
										/* @__PURE__ */ p("code", { children: e.cells.map((e) => x(e.symbol)).join("") }),
										/* @__PURE__ */ p("b", { children: b("games.summy.points", { n: e.points }) })
									] }, e.turn)) : /* @__PURE__ */ p("p", { children: b("games.summy.noHistory") })]
								})
							]
						}),
						/* @__PURE__ */ m("footer", {
							className: "summy-result-actions",
							children: [
								/* @__PURE__ */ p("button", {
									type: "button",
									onClick: () => w(!1),
									children: b("games.summy.review")
								}),
								h && /* @__PURE__ */ p(_, {
									label: b("session.result.playAgain"),
									confirmLabel: b("games.summy.confirmAgain"),
									onConfirm: h,
									className: "summy-result-restart"
								}),
								g && /* @__PURE__ */ p(_, {
									label: b("session.result.backToLobby"),
									confirmLabel: b("games.summy.confirmBack"),
									onConfirm: g
								}),
								!h && !g && /* @__PURE__ */ p("p", { children: b("session.result.waitHost") })
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/summy/entry.tsx
var ce = {
	definition: U,
	View: te,
	bot: ie,
	describe: ae,
	fx: oe,
	OverView: se,
	locales: {
		zh: {
			confirmAgain: "确认再来一局",
			confirmBack: "确认返回大厅",
			emptySlot: "空手牌位",
			handN: "{{n}} 块",
			settling: "木块落定，正在补牌",
			finished: "对局结束",
			name: "Summy",
			desc: "彩色木块拼算式，借用桌上的数字争取高分。",
			rules: "目标：两方轮流拼出算式，总分最高的一方获胜。每个席位代表一方，可由同席成员共同讨论。\n配件与准备：\n共有 94 块：数字 0 至 9 各 6 块，加、减、乘、除各 5 块，等号 14 块。桌面中央先放一个等号，其余 93 块洗混，每方秘密取得 8 块。比较起手的数字块，最小数字较小的一方先手；相同则比较次小数字。\n回合：\n每回合二选一：用手中 1 至 8 块拼出一个算式，或秘密弃掉任意数量的手中木块。弃块直接移出游戏，不放回库存。行动后从库存补至 8 块；库存不足时取完为止。\n摆放：\n新算式必须至少借用桌上已有的一块，沿横向从左往右或纵向从上往下读取。已放置的木块不能移动、删除或重排。相邻的平行木块不必另成算式。每个算式首尾外侧一格必须为空，并在整局中保持为空；这两格会标记为不可摆放。\n算式：\n每个算式恰有一个等号。等号前至少有两个数和一个运算符，等号后只能有一个数。数可以由多个数字块组成，多位数不得以 0 开头。先乘除、后加减；同一优先级按从左往右的顺序计算。允许中间结果为分数，例如 3 除以 2 再乘以 4 等于 6。\n计分与结束：\n新算式中全部数字的数值相加就是本次得分，包括借用的数字。例如 8 乘以 15 等于 120 获得 17 分。库存为空后，连续两方均不拼出算式时结束，总分高者获胜；同分则并列。余下手牌不扣分。\n操作：\n先选手牌木块，再点桌面空格预摆。摆放方向会根据预摆木块的位置自动识别；点预摆块可取回。预览显示算式与得分，确认后落位。拖动桌面可平移，滚轮或双指可缩放。弃块模式中点选手牌后确认。",
			turn: "{{name}}的回合",
			yourTurn: "轮到你了",
			stock: "库存 {{n}}",
			discarded: "已弃 {{n}}",
			points: "{{n}} 分",
			hand: "手牌",
			place: "摆放算式",
			confirm: "确认摆放",
			clear: "取回木块",
			discard: "弃块",
			discardN: "弃掉 {{n}} 块",
			cancel: "取消",
			pass: "结束回合",
			selectTile: "选择一块手牌，再点空格摆放",
			waiting: "等待对方行动",
			horizontal: "横向",
			vertical: "纵向",
			blocked: "算式首尾保留空格",
			cell: "第 {{x}} 列，第 {{y}} 行",
			tile: "木块 {{symbol}}",
			draft: "取回预摆木块 {{symbol}}",
			preview: "{{sum}} · {{n}} 分",
			hint: "摆出 {{sum}}，获得 {{n}} 分",
			fit: "查看全桌",
			history: "算式记录",
			close: "关闭",
			noHistory: "尚无行动记录",
			logPlace: "{{name}}：{{sum}}，获得 {{n}} 分",
			logDiscard: "{{name}}弃掉 {{n}} 块",
			logPass: "{{name}}结束回合",
			errorTurn: "现在不能行动。",
			errorLine: "木块须沿同一横行或纵列连续摆放。",
			errorOccupied: "这个位置已有木块。",
			errorHand: "请选择仍在手中的木块。",
			errorConnected: "新算式须借用桌上至少一块木块。",
			errorEquation: "请组成有效算式：先乘除、后加减，等号后只有一个数。",
			errorEndpoint: "已有算式首尾外侧的空格不能放木块。",
			errorPass: "手中还有木块时，请拼出算式或选择弃块。",
			resultTitle: "算式拼成，分数揭晓",
			winner: "{{name}}获胜",
			tied: "双方并列",
			resultTotal: "总分",
			equations: "完成 {{n}} 个算式",
			best: "最高单次 {{n}} 分",
			review: "回看算式桌",
			showResult: "查看结算"
		},
		en: {
			confirmAgain: "Confirm new game",
			confirmBack: "Confirm return to lobby",
			emptySlot: "Empty hand slot",
			handN: "Tiles: {{n}}",
			settling: "Tiles settling and refilling",
			finished: "Game over",
			name: "Summy",
			desc: "Build equations with colourful wooden tiles and share the numbers on the table.",
			rules: "Goal: Two sides take turns building equations. The highest total score wins. Each seat represents one side and may be shared by a team.\nContents and setup:\n94 tiles: six of each digit 0–9, five of each operator +, −, ×, ÷, and fourteen equals signs. Put one equals sign in the centre, shuffle the other 93 tiles and secretly deal eight to each side. The side with the lowest digit starts; compare the next-lowest digits to break ties.\nYour turn:\nEither use 1–8 hand tiles to build one equation, or secretly discard any number of your tiles. Discards leave the game permanently. Then refill your hand to eight, or take all remaining tiles if fewer are available.\nPlacement:\nEach new equation must reuse at least one tile already on the table. Read horizontally left to right or vertically top to bottom. Placed tiles cannot move, change or be removed. Parallel adjacent tiles do not have to form equations. The spaces immediately before and after each equation must stay empty for the entire game; these spaces are marked as blocked.\nEquations:\nUse exactly one equals sign. Before it, include at least two numbers and one operator; after it, include one number only. Numbers may have multiple digits but may not have leading zeroes. Multiply and divide before adding and subtracting. Evaluate equal-precedence operators from left to right. Intermediate fractions are allowed, for example 3÷2×4=6.\nScoring and ending:\nScore the sum of all digits in your new equation, including reused digits. For example, 8×15=120 scores 17 points. Once the stock is empty, the game ends when both sides consecutively fail to build an equation. Highest score wins; equal scores share victory. Remaining hand tiles incur no penalty.\nControls:\nSelect a hand tile, then tap an empty table space to preview it. The direction follows the positions of your draft tiles automatically; tap a draft tile to take it back. Confirm after checking the equation and score. Drag to pan, and use the wheel or pinch to zoom. In discard mode, select hand tiles and confirm.",
			turn: "{{name}}’s turn",
			yourTurn: "Your turn",
			stock: "Stock {{n}}",
			discarded: "Discarded {{n}}",
			points: "{{n}} pts",
			hand: "Your tiles",
			place: "Build equation",
			confirm: "Place tiles",
			clear: "Take back tiles",
			discard: "Discard",
			discardN: "Discard tiles ({{n}})",
			cancel: "Cancel",
			pass: "End turn",
			selectTile: "Select a tile, then tap an empty space",
			waiting: "Waiting for the other side",
			horizontal: "Across",
			vertical: "Down",
			blocked: "Reserved space at the end of an equation",
			cell: "Column {{x}}, row {{y}}",
			tile: "Tile {{symbol}}",
			draft: "Take back draft tile {{symbol}}",
			preview: "{{sum}} · {{n}} pts",
			hint: "Place {{sum}} for {{n}} pts",
			fit: "View table",
			history: "Equation record",
			close: "Close",
			noHistory: "No moves yet",
			logPlace: "{{name}}: {{sum}}, {{n}} pts",
			logDiscard: "{{name}} discarded tiles: {{n}}",
			logPass: "{{name}} ended their turn",
			errorTurn: "You cannot act now.",
			errorLine: "Place tiles in one continuous row or column.",
			errorOccupied: "A tile already occupies this space.",
			errorHand: "Select tiles still in your hand.",
			errorConnected: "Reuse at least one tile already on the table.",
			errorEquation: "Build a valid equation: multiply and divide first, with a single number after the equals sign.",
			errorEndpoint: "The spaces immediately before and after an existing equation must stay empty.",
			errorPass: "Build an equation or discard while you still have tiles.",
			resultTitle: "Equations complete, scores revealed",
			winner: "{{name}} wins",
			tied: "A shared victory",
			resultTotal: "Total score",
			equations: "Equations completed: {{n}}",
			best: "Best equation: {{n}} pts",
			review: "Review the table",
			showResult: "Show results"
		}
	}
};
//#endregion
export { ce as default };
