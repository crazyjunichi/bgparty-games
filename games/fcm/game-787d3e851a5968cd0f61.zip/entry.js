import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o } from "react";
import { useFxAnchor as s } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { IconBack as u, IconBot as d, IconExpand as f, IconLog as p, IconRecenter as m, IconRotate as h } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { PhaseBanner as _ } from "@bgparty/sdk/ui/phase-banner";
import { PlayerStrip as v, seatName as y } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as ee } from "@bgparty/sdk/ui/game-screen";
import { Fragment as te, jsx as b, jsxs as x } from "react/jsx-runtime";
import { Floater as S, PulseBox as ne } from "@bgparty/sdk/fx/primitives";
import { Confetti as C } from "@bgparty/sdk/ui/confetti";
import { OptionSwitch as w } from "@bgparty/sdk/ui/game-options";
//#region src/games/fcm/data.ts
var T = [
	"burger",
	"pizza",
	"beer",
	"lemonade",
	"soda"
], re = [
	"beer",
	"lemonade",
	"soda"
], E = (e) => e, D = {
	billboard: 0,
	mailbox: 1,
	airplane: 2,
	radio: 3
}, O = {
	kitchen_trainee: E({
		id: "kitchen_trainee",
		nameKey: "games.fcm.emp.kitchen_trainee",
		count: 12,
		salary: !1,
		recruitable: !0,
		produce: {
			choice: ["burger", "pizza"],
			n: 1
		},
		trainsTo: ["burger_cook", "pizza_cook"]
	}),
	errand_boy: E({
		id: "errand_boy",
		nameKey: "games.fcm.emp.errand_boy",
		count: 12,
		salary: !1,
		recruitable: !0,
		buyer: { kind: "anyDrink" },
		trainsTo: ["cart_operator"]
	}),
	marketing_trainee: E({
		id: "marketing_trainee",
		nameKey: "games.fcm.emp.marketing_trainee",
		count: 12,
		salary: !1,
		recruitable: !0,
		marketer: {
			maxType: "billboard",
			range: 2,
			maxDuration: 2
		},
		trainsTo: ["campaign_manager"]
	}),
	recruiting_girl: E({
		id: "recruiting_girl",
		nameKey: "games.fcm.emp.recruiting_girl",
		count: 12,
		salary: !1,
		recruitable: !0,
		recruit: 1,
		trainsTo: ["recruiting_manager"]
	}),
	trainer: E({
		id: "trainer",
		nameKey: "games.fcm.emp.trainer",
		count: 12,
		salary: !1,
		recruitable: !0,
		train: 1,
		trainsTo: ["coach"]
	}),
	pricing_manager: E({
		id: "pricing_manager",
		nameKey: "games.fcm.emp.pricing_manager",
		count: 12,
		salary: !1,
		recruitable: !0,
		priceMod: -1
	}),
	waitress: E({
		id: "waitress",
		nameKey: "games.fcm.emp.waitress",
		count: 12,
		salary: !1,
		recruitable: !0
	}),
	management_trainee: E({
		id: "management_trainee",
		nameKey: "games.fcm.emp.management_trainee",
		count: 18,
		salary: !1,
		recruitable: !0,
		slots: 2,
		trainsTo: [
			"junior_vp",
			"luxuries_manager",
			"new_business_dev"
		]
	}),
	burger_cook: E({
		id: "burger_cook",
		nameKey: "games.fcm.emp.burger_cook",
		count: 6,
		salary: !0,
		produce: {
			good: "burger",
			n: 3
		},
		trainsTo: ["burger_chef"]
	}),
	pizza_cook: E({
		id: "pizza_cook",
		nameKey: "games.fcm.emp.pizza_cook",
		count: 6,
		salary: !0,
		produce: {
			good: "pizza",
			n: 3
		},
		trainsTo: ["pizza_chef"]
	}),
	cart_operator: E({
		id: "cart_operator",
		nameKey: "games.fcm.emp.cart_operator",
		count: 6,
		salary: !0,
		buyer: {
			kind: "road",
			range: 2,
			perSource: 2
		},
		trainsTo: ["truck_driver"]
	}),
	truck_driver: E({
		id: "truck_driver",
		nameKey: "games.fcm.emp.truck_driver",
		count: 6,
		salary: !0,
		buyer: {
			kind: "road",
			range: 3,
			perSource: 3
		},
		trainsTo: ["zeppelin_pilot"]
	}),
	campaign_manager: E({
		id: "campaign_manager",
		nameKey: "games.fcm.emp.campaign_manager",
		count: 6,
		salary: !0,
		marketer: {
			maxType: "mailbox",
			range: 3,
			maxDuration: 3
		},
		trainsTo: ["brand_manager"]
	}),
	brand_manager: E({
		id: "brand_manager",
		nameKey: "games.fcm.emp.brand_manager",
		count: 6,
		salary: !0,
		marketer: {
			maxType: "airplane",
			range: Infinity,
			maxDuration: 4
		},
		trainsTo: ["brand_director"]
	}),
	junior_vp: E({
		id: "junior_vp",
		nameKey: "games.fcm.emp.junior_vp",
		count: 6,
		salary: !0,
		slots: 3,
		trainsTo: [
			"coach",
			"vp",
			"recruiting_manager",
			"discount_manager",
			"local_manager"
		]
	}),
	vp: E({
		id: "vp",
		nameKey: "games.fcm.emp.vp",
		count: 6,
		salary: !0,
		slots: 4,
		trainsTo: [
			"senior_vp",
			"guru",
			"regional_manager"
		]
	}),
	senior_vp: E({
		id: "senior_vp",
		nameKey: "games.fcm.emp.senior_vp",
		count: 6,
		salary: !0,
		slots: 5,
		trainsTo: [
			"executive_vp",
			"cfo",
			"hr_director"
		]
	}),
	local_manager: E({
		id: "local_manager",
		nameKey: "games.fcm.emp.local_manager",
		count: 6,
		salary: !0,
		placeRestaurant: {
			range: 3,
			move: !1,
			immediate: !1
		},
		trainsTo: ["regional_manager"]
	}),
	new_business_dev: E({
		id: "new_business_dev",
		nameKey: "games.fcm.emp.new_business_dev",
		count: 6,
		salary: !0,
		placeHouse: !0
	}),
	discount_manager: E({
		id: "discount_manager",
		nameKey: "games.fcm.emp.discount_manager",
		count: 6,
		salary: !0,
		priceMod: -3
	}),
	coach: E({
		id: "coach",
		nameKey: "games.fcm.emp.coach",
		count: 6,
		salary: !0,
		train: 2,
		trainsTo: ["guru"]
	}),
	recruiting_manager: E({
		id: "recruiting_manager",
		nameKey: "games.fcm.emp.recruiting_manager",
		count: 6,
		salary: !0,
		recruit: 2,
		trainsTo: ["hr_director"]
	}),
	burger_chef: E({
		id: "burger_chef",
		nameKey: "games.fcm.emp.burger_chef",
		count: 3,
		salary: !0,
		topPosition: !0,
		produce: {
			good: "burger",
			n: 8
		}
	}),
	pizza_chef: E({
		id: "pizza_chef",
		nameKey: "games.fcm.emp.pizza_chef",
		count: 3,
		salary: !0,
		topPosition: !0,
		produce: {
			good: "pizza",
			n: 8
		}
	}),
	zeppelin_pilot: E({
		id: "zeppelin_pilot",
		nameKey: "games.fcm.emp.zeppelin_pilot",
		count: 3,
		salary: !0,
		topPosition: !0,
		buyer: {
			kind: "fly",
			range: 4,
			perSource: 2
		}
	}),
	brand_director: E({
		id: "brand_director",
		nameKey: "games.fcm.emp.brand_director",
		count: 3,
		salary: !0,
		topPosition: !0,
		marketer: {
			maxType: "radio",
			range: Infinity,
			maxDuration: 5
		}
	}),
	executive_vp: E({
		id: "executive_vp",
		nameKey: "games.fcm.emp.executive_vp",
		count: 3,
		salary: !0,
		topPosition: !0,
		slots: 10
	}),
	cfo: E({
		id: "cfo",
		nameKey: "games.fcm.emp.cfo",
		count: 3,
		salary: !0,
		topPosition: !0,
		cfo: !0
	}),
	regional_manager: E({
		id: "regional_manager",
		nameKey: "games.fcm.emp.regional_manager",
		count: 3,
		salary: !0,
		topPosition: !0,
		placeRestaurant: {
			range: Infinity,
			move: !0,
			immediate: !0
		}
	}),
	hr_director: E({
		id: "hr_director",
		nameKey: "games.fcm.emp.hr_director",
		count: 3,
		salary: !0,
		topPosition: !0,
		recruit: 4
	}),
	guru: E({
		id: "guru",
		nameKey: "games.fcm.emp.guru",
		count: 3,
		salary: !0,
		topPosition: !0,
		train: 3
	}),
	luxuries_manager: E({
		id: "luxuries_manager",
		nameKey: "games.fcm.emp.luxuries_manager",
		count: 3,
		salary: !0,
		topPosition: !0,
		priceMod: 10
	})
}, ie = Object.keys(O);
ie.filter((e) => O[e].topPosition);
var ae = ie.filter((e) => O[e].recruitable), oe = [
	{
		id: "first_hire_3",
		nameKey: "games.fcm.ms.first_hire_3",
		descKey: "games.fcm.msd.first_hire_3"
	},
	{
		id: "first_train",
		nameKey: "games.fcm.ms.first_train",
		descKey: "games.fcm.msd.first_train"
	},
	{
		id: "first_billboard",
		nameKey: "games.fcm.ms.first_billboard",
		descKey: "games.fcm.msd.first_billboard"
	},
	{
		id: "first_throw",
		nameKey: "games.fcm.ms.first_throw",
		descKey: "games.fcm.msd.first_throw"
	},
	{
		id: "first_burger_produced",
		nameKey: "games.fcm.ms.first_burger_produced",
		descKey: "games.fcm.msd.first_burger_produced"
	},
	{
		id: "first_pizza_produced",
		nameKey: "games.fcm.ms.first_pizza_produced",
		descKey: "games.fcm.msd.first_pizza_produced"
	},
	{
		id: "first_burger_marketed",
		nameKey: "games.fcm.ms.first_burger_marketed",
		descKey: "games.fcm.msd.first_burger_marketed"
	},
	{
		id: "first_pizza_marketed",
		nameKey: "games.fcm.ms.first_pizza_marketed",
		descKey: "games.fcm.msd.first_pizza_marketed"
	},
	{
		id: "first_drink_marketed",
		nameKey: "games.fcm.ms.first_drink_marketed",
		descKey: "games.fcm.msd.first_drink_marketed"
	},
	{
		id: "first_waitress",
		nameKey: "games.fcm.ms.first_waitress",
		descKey: "games.fcm.msd.first_waitress"
	},
	{
		id: "first_20_cash",
		nameKey: "games.fcm.ms.first_20_cash",
		descKey: "games.fcm.msd.first_20_cash"
	},
	{
		id: "first_errand_boy",
		nameKey: "games.fcm.ms.first_errand_boy",
		descKey: "games.fcm.msd.first_errand_boy"
	},
	{
		id: "first_cart_operator",
		nameKey: "games.fcm.ms.first_cart_operator",
		descKey: "games.fcm.msd.first_cart_operator"
	},
	{
		id: "first_airplane",
		nameKey: "games.fcm.ms.first_airplane",
		descKey: "games.fcm.msd.first_airplane"
	},
	{
		id: "first_radio",
		nameKey: "games.fcm.ms.first_radio",
		descKey: "games.fcm.msd.first_radio"
	},
	{
		id: "first_lower_prices",
		nameKey: "games.fcm.ms.first_lower_prices",
		descKey: "games.fcm.msd.first_lower_prices"
	},
	{
		id: "first_100_cash",
		nameKey: "games.fcm.ms.first_100_cash",
		descKey: "games.fcm.msd.first_100_cash"
	},
	{
		id: "first_20_salary",
		nameKey: "games.fcm.ms.first_20_salary",
		descKey: "games.fcm.msd.first_20_salary"
	}
], k = () => {
	let e = [];
	for (let t = 0; t < 5; t++) e.push([t, 2]), e.push([2, t]);
	return e;
}, A = () => {
	let e = [];
	for (let t = 0; t < 5; t++) e.push([2, t]);
	for (let t = 2; t < 5; t++) e.push([t, 2]);
	return e;
}, se = () => {
	let e = [];
	for (let t = 0; t < 5; t++) e.push([2, t]);
	for (let t = 0; t <= 2; t++) e.push([t, 2]);
	return e;
}, j = () => {
	let e = [];
	for (let t = 0; t < 5; t++) e.push([t, 2]);
	for (let t = 0; t <= 2; t++) e.push([2, t]);
	return e;
}, M = () => [
	[0, 2],
	[0, 3],
	[0, 4],
	[1, 4],
	[2, 4],
	[2, 0],
	[3, 0],
	[4, 0],
	[4, 1],
	[4, 2]
], ce = [
	{
		letter: "A",
		roads: k(),
		house: {
			num: 2,
			anchor: [0, 3]
		},
		drinks: []
	},
	{
		letter: "B",
		roads: k(),
		house: {
			num: 4,
			anchor: [0, 3]
		},
		drinks: []
	},
	{
		letter: "C",
		roads: (() => {
			let e = [];
			for (let t = 0; t < 5; t++) e.push([0, t]), e.push([4, t]), e.push([t, 0]), e.push([t, 4]);
			return e;
		})(),
		house: {
			num: 5,
			anchor: [1, 2]
		},
		drinks: []
	},
	{
		letter: "D",
		roads: [
			[0, 2],
			[0, 3],
			[0, 4],
			[1, 4],
			[2, 4],
			[3, 4],
			[4, 4],
			[4, 3],
			[4, 2]
		],
		house: {
			num: 7,
			anchor: [1, 2]
		},
		drinks: []
	},
	{
		letter: "E",
		roads: M(),
		house: {
			num: 8,
			anchor: [2, 1]
		},
		drinks: [{
			good: "beer",
			at: [1, 3]
		}]
	},
	{
		letter: "F",
		roads: se(),
		house: {
			num: 10,
			anchor: [0, 0]
		},
		drinks: []
	},
	{
		letter: "G",
		roads: k(),
		house: {
			num: 12,
			anchor: [0, 0]
		},
		drinks: []
	},
	{
		letter: "H",
		roads: j(),
		house: {
			num: 13,
			anchor: [2, 3]
		},
		drinks: []
	},
	{
		letter: "I",
		roads: A(),
		house: {
			num: 15,
			anchor: [0, 0]
		},
		drinks: []
	},
	{
		letter: "J",
		roads: M(),
		house: {
			num: 16,
			anchor: [1, 1]
		},
		drinks: []
	},
	{
		letter: "K",
		roads: [
			[0, 0],
			[0, 1],
			[0, 2],
			[1, 0],
			[2, 0],
			[3, 0],
			[4, 0],
			[4, 1],
			[4, 2]
		],
		house: {
			num: 18,
			anchor: [1, 1]
		},
		drinks: []
	},
	{
		letter: "L",
		roads: se(),
		drinks: [{
			good: "lemonade",
			at: [3, 3]
		}]
	},
	{
		letter: "M",
		roads: M(),
		drinks: [{
			good: "lemonade",
			at: [1, 3]
		}, {
			good: "soda",
			at: [3, 1]
		}]
	},
	{
		letter: "N",
		roads: j(),
		drinks: [{
			good: "beer",
			at: [3, 1]
		}]
	},
	{
		letter: "O",
		roads: k(),
		drinks: [{
			good: "beer",
			at: [4, 3]
		}]
	},
	{
		letter: "P",
		roads: k(),
		drinks: [{
			good: "beer",
			at: [0, 1]
		}, {
			good: "lemonade",
			at: [3, 4]
		}]
	},
	{
		letter: "Q",
		roads: A(),
		drinks: [{
			good: "soda",
			at: [1, 3]
		}]
	},
	{
		letter: "R",
		roads: k(),
		drinks: [{
			good: "soda",
			at: [1, 3]
		}]
	},
	{
		letter: "S",
		roads: k(),
		drinks: [{
			good: "beer",
			at: [1, 4]
		}, {
			good: "soda",
			at: [4, 1]
		}]
	},
	{
		letter: "T",
		roads: k(),
		drinks: [{
			good: "lemonade",
			at: [1, 3]
		}]
	}
], le = [
	1,
	3,
	6,
	9,
	11,
	14,
	17,
	19
], ue = [
	{
		num: 1,
		type: "radio"
	},
	{
		num: 2,
		type: "radio"
	},
	{
		num: 3,
		type: "radio"
	},
	{
		num: 4,
		type: "airplane"
	},
	{
		num: 5,
		type: "airplane"
	},
	{
		num: 6,
		type: "airplane"
	},
	{
		num: 7,
		type: "mailbox"
	},
	{
		num: 8,
		type: "mailbox"
	},
	{
		num: 9,
		type: "mailbox"
	},
	{
		num: 10,
		type: "mailbox"
	},
	{
		num: 11,
		type: "billboard"
	},
	{
		num: 12,
		type: "billboard"
	},
	{
		num: 13,
		type: "billboard"
	},
	{
		num: 14,
		type: "billboard"
	},
	{
		num: 15,
		type: "billboard"
	},
	{
		num: 16,
		type: "billboard"
	}
], de = {
	4: 1,
	5: 3,
	6: 5
}, fe = {
	2: {
		tiles: [3, 3],
		topCopies: 1,
		billboardsRemoved: [
			12,
			15,
			16
		],
		bankPerPlayer: 50
	},
	3: {
		tiles: [3, 4],
		topCopies: 1,
		billboardsRemoved: [15, 16],
		bankPerPlayer: 50
	},
	4: {
		tiles: [4, 4],
		topCopies: 2,
		billboardsRemoved: [16],
		bankPerPlayer: 50
	},
	5: {
		tiles: [5, 4],
		topCopies: 3,
		billboardsRemoved: [],
		bankPerPlayer: 50
	}
}, pe = [
	100,
	200,
	300
], me = {
	100: 2,
	200: 3,
	300: 4
}, N = (e, t) => `${e},${t}`;
function P(e, t, n) {
	switch (n & 3) {
		case 1: return [t, 4 - e];
		case 2: return [4 - e, 4 - t];
		case 3: return [4 - t, e];
		default: return [e, t];
	}
}
var F = (e) => e.tw * 5, I = (e) => e.th * 5, he = (e, t, n) => t >= 0 && n >= 0 && t < e.tw && n < e.th ? e.tiles[n * e.tw + t] : null;
function L(e, t, n) {
	let r = Math.floor(t / 5), i = Math.floor(n / 5), a = he(e, r, i);
	if (!a) return !1;
	let o = ce[a.tile], [s, c] = P(n - i * 5, t - r * 5, 4 - a.rot & 3);
	return o.roads.some(([e, t]) => e === s && t === c);
}
function ge(e, t, n) {
	let r = e.tiles[n * e.tw + t], i = ce[r.tile], a = t * 5, o = n * 5;
	return {
		roads: i.roads.map(([e, t]) => {
			let [n, i] = P(e, t, r.rot);
			return [a + i, o + n];
		}),
		drinks: i.drinks.map((e) => {
			let [t, n] = P(e.at[0], e.at[1], r.rot);
			return {
				good: e.good,
				at: [a + n, o + t]
			};
		})
	};
}
function _e(e) {
	let t = [];
	for (let n = 0; n < e.th; n++) for (let r = 0; r < e.tw; r++) for (let i of ge(e, r, n).drinks) t.push({
		good: i.good,
		x: i.at[0],
		y: i.at[1]
	});
	return t;
}
var ve = [
	[1, 0],
	[-1, 0],
	[0, 1],
	[0, -1]
];
function R(e, t, n = Infinity) {
	let r = /* @__PURE__ */ new Map(), i = [];
	for (let [n, a] of t) {
		if (!L(e, n, a)) continue;
		let t = N(n, a);
		r.has(t) || (r.set(t, 0), i.push([n, a]));
	}
	let a = 0;
	for (; a < i.length;) {
		let [t, o] = i[a++], s = r.get(N(t, o));
		for (let [c, l] of ve) {
			let u = t + c, d = o + l;
			if (!L(e, u, d)) continue;
			let f = Math.floor(u / 5) !== Math.floor(t / 5) || Math.floor(d / 5) !== Math.floor(o / 5), p = s + +!!f;
			if (p > n) continue;
			let m = N(u, d), h = r.get(m);
			h !== void 0 && h <= p || (r.set(m, p), f ? i.push([u, d]) : i.splice(a, 0, [u, d]));
		}
	}
	return r;
}
function ye(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let [r, i] of t) for (let [t, a] of ve) {
		let o = r + t, s = i + a;
		L(e, o, s) && n.set(N(o, s), [o, s]);
	}
	return [...n.values()];
}
function be(e, t, n) {
	let r = /* @__PURE__ */ new Set(), i = [[t, n]];
	for (; i.length;) {
		let [t, n] = i.pop(), a = N(t, n);
		if (!r.has(a) && !(t < 0 || n < 0 || t >= F(e) || n >= I(e)) && !L(e, t, n)) {
			r.add(a);
			for (let [e, r] of ve) i.push([t + e, n + r]);
		}
	}
	return r;
}
function xe(e, t, n) {
	let r = Math.floor(t / 5), i = Math.floor(n / 5), a = /* @__PURE__ */ new Set();
	for (let t = -1; t <= 1; t++) for (let n = -1; n <= 1; n++) if (he(e, r + n, i + t)) for (let e = 0; e < 5; e++) for (let o = 0; o < 5; o++) a.add(N((r + n) * 5 + o, (i + t) * 5 + e));
	return a;
}
function Se(e, t, n, r) {
	let i = F(e), a = I(e), o = /* @__PURE__ */ new Set(), s = Math.floor(r / 2);
	if (t === "N" || t === "S") {
		if (n - s < 0 || n + s >= i) return null;
		for (let e = n - s; e <= n + s; e++) for (let t = 0; t < a; t++) o.add(N(e, t));
	} else {
		if (n - s < 0 || n + s >= a) return null;
		for (let e = n - s; e <= n + s; e++) for (let t = 0; t < i; t++) o.add(N(t, e));
	}
	return o;
}
function Ce(e, t, n) {
	let r = /* @__PURE__ */ new Set();
	for (let [i, a] of ve) {
		let o = t + i, s = n + a;
		o >= 0 && s >= 0 && o < F(e) && s < I(e) && r.add(N(o, s));
	}
	return r;
}
//#endregion
//#region src/games/fcm/meta.ts
var z = {
	id: "fcm",
	tier: "beta",
	mechanics: ["engine-building"],
	interactionTags: [],
	nameKey: "games.fcm.name",
	descKey: "games.fcm.desc",
	rulesKey: "games.fcm.rules",
	icon: "🍔",
	iconImg: "games/fcm.webp",
	rulesUrl: { en: "https://www.qugs.org/rules/r175914.pdf" },
	minPlayers: 2,
	maxPlayers: 5,
	bestPlayers: [3, 4],
	accent: "#c43931",
	releasedAt: "2026-09-17",
	search: {
		py: "kuai can lian suo da heng",
		init: "kclsdh"
	},
	hotseat: "cover"
}, we = t.enum([
	"burger",
	"pizza",
	"beer",
	"lemonade",
	"soda"
]), Te = t.string().min(1), Ee = t.enum([
	"N",
	"E",
	"S",
	"W"
]), De = t.enum(/* @__PURE__ */ "kitchen_trainee.errand_boy.marketing_trainee.recruiting_girl.trainer.pricing_manager.waitress.management_trainee.burger_cook.pizza_cook.cart_operator.truck_driver.campaign_manager.brand_manager.junior_vp.vp.senior_vp.local_manager.new_business_dev.discount_manager.coach.recruiting_manager.burger_chef.pizza_chef.zeppelin_pilot.brand_director.executive_vp.cfo.regional_manager.hr_director.guru.luxuries_manager".split(".")), Oe = t.enum([
	"first_hire_3",
	"first_train",
	"first_billboard",
	"first_throw",
	"first_burger_produced",
	"first_pizza_produced",
	"first_burger_marketed",
	"first_pizza_marketed",
	"first_drink_marketed",
	"first_waitress",
	"first_20_cash",
	"first_errand_boy",
	"first_cart_operator",
	"first_airplane",
	"first_radio",
	"first_lower_prices",
	"first_100_cash",
	"first_20_salary"
]), ke = t.object({ intro: t.boolean() }).prefault({ intro: !1 }), Ae = t.union([t.object({
	kind: t.literal("cell"),
	x: t.int().nonnegative(),
	y: t.int().nonnegative()
}), t.object({
	kind: t.literal("edge"),
	edge: Ee,
	index: t.int().nonnegative()
})]), je = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("placeFirstRestaurant"),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		dir: Ee
	}),
	t.object({ type: t.literal("passFirstRestaurant") }),
	t.object({
		type: t.literal("chooseReserve"),
		value: t.union([
			t.literal(100),
			t.literal(200),
			t.literal(300)
		])
	}),
	t.object({
		type: t.literal("submitStructure"),
		cards: t.array(Te)
	}),
	t.object({
		type: t.literal("chooseOrder"),
		position: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("recruit"),
		emp: De
	}),
	t.object({
		type: t.literal("train"),
		uid: Te,
		to: De
	}),
	t.object({
		type: t.literal("marketing"),
		uid: Te,
		tile: t.int().min(1).max(16),
		placement: Ae,
		good: we,
		duration: t.int().min(1).max(5)
	}),
	t.object({
		type: t.literal("produce"),
		uid: Te,
		good: we.optional()
	}),
	t.object({
		type: t.literal("buyDrinks"),
		uid: Te,
		good: we.optional(),
		sources: t.array(t.tuple([t.int().nonnegative(), t.int().nonnegative()])).optional(),
		tiles: t.array(t.tuple([t.int().nonnegative(), t.int().nonnegative()])).optional()
	}),
	t.object({
		type: t.literal("placeHouse"),
		num: t.int(),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		rot: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("placeGarden"),
		houseId: t.string(),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		rot: t.union([
			t.literal(0),
			t.literal(1),
			t.literal(2),
			t.literal(3)
		])
	}),
	t.object({
		type: t.literal("placeRestaurant"),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		dir: Ee
	}),
	t.object({
		type: t.literal("moveRestaurant"),
		index: t.int().nonnegative(),
		x: t.int().nonnegative(),
		y: t.int().nonnegative(),
		dir: Ee
	}),
	t.object({ type: t.literal("finishWorking") }),
	t.object({ type: t.literal("nextSub") }),
	t.object({
		type: t.literal("paydaySubmit"),
		fire: t.array(Te)
	}),
	t.object({
		type: t.literal("freezerKeep"),
		keep: t.array(we)
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), Me = t.tuple([t.int(), t.int()]), Ne = t.object({
	id: t.string(),
	num: t.int(),
	cells: t.array(Me),
	garden: t.array(Me).nullable(),
	demand: t.array(we)
}), Pe = t.object({
	owner: t.int().nonnegative(),
	x: t.int().nonnegative(),
	y: t.int().nonnegative(),
	dir: Ee,
	comingSoon: t.boolean()
}), B = t.object({
	num: t.int(),
	type: t.enum([
		"billboard",
		"mailbox",
		"airplane",
		"radio"
	]),
	owner: t.int().nonnegative(),
	placement: Ae,
	good: we,
	tokensLeft: t.int().nonnegative(),
	eternal: t.boolean()
}), Fe = t.object({
	rid: t.string(),
	brand: t.int().nonnegative(),
	cash: t.int(),
	structure: t.array(t.object({
		uid: t.string(),
		emp: De
	})),
	beach: t.array(t.object({
		uid: t.string(),
		emp: De
	})),
	busy: t.array(t.object({
		uid: t.string(),
		emp: De
	})),
	milestones: t.array(Oe),
	stock: t.record(t.string(), t.int().nonnegative()),
	freezer: t.array(we),
	unitPrice: t.int(),
	ceoSlots: t.int().min(1),
	waitressCount: t.int().nonnegative()
}), V = t.object({
	phase: t.enum([
		"setupRestaurants",
		"setupReserve",
		"restructuring",
		"orderDraft",
		"working",
		"dinnertime",
		"payday",
		"marketing",
		"cleanup",
		"done"
	]),
	round: t.int().min(1),
	intro: t.boolean(),
	board: t.object({
		tw: t.int().min(1),
		th: t.int().min(1),
		tiles: t.array(t.object({
			tile: t.int().nonnegative(),
			rot: t.union([
				t.literal(0),
				t.literal(1),
				t.literal(2),
				t.literal(3)
			])
		}))
	}),
	houses: t.array(Ne),
	restaurants: t.array(Pe),
	campaigns: t.array(B),
	players: t.array(Fe),
	supply: t.record(t.string(), t.int().nonnegative()),
	marketingPool: t.array(t.int()),
	bank: t.int(),
	bankBroken: t.int().min(0).max(2),
	milestoneState: t.record(t.string(), t.object({
		claimedBy: t.array(t.string()),
		closed: t.boolean()
	})),
	active: t.string().nullable(),
	orderDraft: t.object({
		chooser: t.string(),
		taken: t.record(t.string(), t.string())
	}).nullable(),
	turnOrder: t.array(t.string()),
	prevOrder: t.array(t.string()),
	waiting: t.array(t.string()),
	working: t.object({
		sub: t.enum([
			"recruit",
			"train",
			"market",
			"produce",
			"build",
			"restaurant",
			"done"
		]),
		recruitsLeft: t.int().nonnegative(),
		trainSteps: t.record(t.string(), t.int().nonnegative()),
		trainedBy: t.record(t.string(), t.string()),
		marketeersLeft: t.array(t.string()),
		producersLeft: t.array(t.string()),
		buyersLeft: t.array(t.string()),
		nbdLeft: t.int().nonnegative(),
		restaurantActions: t.array(t.string())
	}).nullable(),
	dinner: t.object({
		current: t.string().nullable(),
		log: t.array(t.object({
			houseId: t.string(),
			winner: t.string().nullable(),
			revenue: t.int().nonnegative()
		}))
	}).nullable(),
	salaryDue: t.record(t.string(), t.int().nonnegative()),
	winner: t.string().nullable()
}), Ie = t.object({
	myReserve: t.union([
		t.literal(100),
		t.literal(200),
		t.literal(300)
	]).nullable(),
	knownReserves: t.record(t.string(), t.union([
		t.literal(100),
		t.literal(200),
		t.literal(300)
	]))
}), H = {
	N: [0, -1],
	E: [1, 0],
	S: [0, 1],
	W: [-1, 0]
}, Le = [
	"recruit",
	"train",
	"market",
	"produce",
	"build",
	"restaurant"
], U = (e) => ({ code: e });
function Re(t, n) {
	for (let r = t.length - 1; r > 0; r--) {
		let i = e(n.seed, n.rngCursor, r + 1);
		n.rngCursor++;
		let a = t[r];
		t[r] = t[i], t[i] = a;
	}
}
var ze = (e, t) => e.players.findIndex((e) => e.rid === t);
function Be(e, t) {
	let n = t.filter((e) => O[e].slots), r = n.reduce((e, t) => e + (O[t].slots ?? 0), 0);
	return n.length <= e.ceoSlots && t.length <= e.ceoSlots + r;
}
function Ve(e) {
	let t = 10;
	for (let n of e.structure) {
		let r = e.cards.find((e) => e.uid === n);
		r && (t += O[r.emp].priceMod ?? 0);
	}
	return e.milestones.includes("first_lower_prices") && --t, t;
}
function W(e) {
	return e.ceoCfo ? !0 : e.structure.some((t) => {
		let n = e.cards.find((e) => e.uid === t);
		return n ? !!O[n.emp].cfo : !1;
	});
}
var G = (e) => e.structure.filter((t) => e.cards.find((e) => e.uid === t)?.emp === "waitress").length;
function K(e, t, n, r) {
	if (e.config.intro) return;
	let i = e.milestoneState[n];
	if (i.closed || i.claimedBy.includes(t)) return;
	let a = e.players[ze(e, t)];
	i.claimedBy.push(t), a.milestones.push(n), e.claimedThisTurn.includes(n) || e.claimedThisTurn.push(n), r.push({
		kind: "milestone",
		data: {
			rid: t,
			id: n
		}
	});
	let o = (t, n) => {
		for (let r = 0; r < n && e.supply[t] > 0; r++) e.supply[t]--, a.cards.push({
			uid: `c${e.uidNext++}`,
			emp: t
		});
	};
	n === "first_hire_3" && o("management_trainee", 2), n === "first_burger_produced" && o("burger_cook", 1), n === "first_pizza_produced" && o("pizza_cook", 1);
}
function q(e, t) {
	if (e.bankBroken++, t.push({
		kind: "bankBreak",
		data: { n: e.bankBroken }
	}), e.bankBroken === 1) {
		for (let t of e.players) t.reserve && (e.bank += t.reserve);
		let t = e.players.filter((e) => e.reserve).map((e) => me[e.reserve]), n = (e) => t.filter((t) => t === e).length, r = Math.max(n(2), n(3), n(4));
		e.ceoSlots = [
			4,
			3,
			2
		].find((e) => n(e) === r) ?? 3;
	}
}
function He(e, t, n, r) {
	n <= 0 || (e.bank < n && e.bankBroken === 0 && q(e, r), e.bank < n && e.bankBroken === 1 && q(e, r), e.bank -= n, e.players[t].cash += n);
}
function Ue(e) {
	let [t, n] = H[e.dir];
	return [e.x + t, e.y + n];
}
function We(e, t) {
	let n = e.players[t], r = n.structure.some((e) => {
		let t = n.cards.find((t) => t.uid === e);
		return t ? !!O[t.emp].placeRestaurant : !1;
	}), i = [];
	for (let n of e.restaurants) if (!(n.owner !== t || n.comingSoon)) {
		if (r) for (let t of [
			"N",
			"E",
			"S",
			"W"
		]) {
			let [r, a] = H[t];
			L(e.board, n.x + r, n.y + a) && i.push([n.x + r, n.y + a]);
		}
		else {
			let [t, r] = Ue(n);
			L(e.board, t, r) && i.push([t, r]);
		}
	}
	return i;
}
function J(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.houses) {
		for (let [e, r] of n.cells) t.add(N(e, r));
		for (let [e, r] of n.garden ?? []) t.add(N(e, r));
	}
	for (let n of e.restaurants) t.add(N(n.x, n.y));
	for (let n of e.campaigns) n.placement.kind === "cell" && t.add(N(n.placement.x, n.placement.y));
	for (let n of _e(e.board)) t.add(N(n.x, n.y));
	return t;
}
function Y(e, t, n) {
	return t < 0 || n < 0 || t >= F(e.board) || n >= I(e.board) || L(e.board, t, n) ? !1 : !J(e).has(N(t, n));
}
function Ge(e, t) {
	let n;
	if (t.placement.kind === "edge") {
		let r = Se(e.board, t.placement.edge, t.placement.index, de[t.num] ?? 1);
		if (!r) return [];
		n = r;
	} else n = t.type === "billboard" ? Ce(e.board, t.placement.x, t.placement.y) : t.type === "mailbox" ? be(e.board, t.placement.x, t.placement.y) : xe(e.board, t.placement.x, t.placement.y);
	return e.houses.filter((e) => [...e.cells, ...e.garden ?? []].some(([e, t]) => n.has(N(e, t))));
}
function Ke(e, t, n) {
	let [r, i] = [
		[0, 1],
		[-1, 0],
		[0, -1],
		[1, 0]
	][n & 3];
	return {
		house: [[e, t]],
		garden: [[e + r, t + i]]
	};
}
function qe(t, n, r) {
	let i = n.length, a = fe[i], o = {
		seed: r,
		rngCursor: 0,
		players: n.map((e, t) => ({
			rid: e,
			brand: t,
			cash: 0,
			cards: [],
			structure: [],
			busy: [],
			milestones: [],
			stock: {
				burger: 0,
				pizza: 0,
				beer: 0,
				lemonade: 0,
				soda: 0
			},
			freezer: [],
			reserve: null,
			ceoCfo: !1,
			ceoCfoPending: !1,
			salaryDiscount: 0
		})),
		config: t,
		phase: "setupRestaurants",
		round: 1,
		board: {
			tw: a.tiles[0],
			th: a.tiles[1],
			tiles: []
		},
		houses: [],
		restaurants: [],
		campaigns: [],
		supply: Object.fromEntries(Object.values(O).map((e) => [e.id, e.topPosition ? Math.min(e.count, a.topCopies) : e.count])),
		marketingPool: ue.filter((e) => !a.billboardsRemoved.includes(e.num)).map((e) => e.num),
		bank: (t.intro ? 75 : a.bankPerPlayer) * i,
		bankBroken: 0,
		ceoSlots: 3,
		milestoneState: Object.fromEntries([
			"first_hire_3",
			"first_train",
			"first_billboard",
			"first_throw",
			"first_burger_produced",
			"first_pizza_produced",
			"first_burger_marketed",
			"first_pizza_marketed",
			"first_drink_marketed",
			"first_waitress",
			"first_20_cash",
			"first_errand_boy",
			"first_cart_operator",
			"first_airplane",
			"first_radio",
			"first_lower_prices",
			"first_100_cash",
			"first_20_salary"
		].map((e) => [e, {
			claimedBy: [],
			closed: !1
		}])),
		claimedThisTurn: [],
		prevOrder: [],
		turnOrder: [],
		placeQueue: [],
		passedThisSetup: [],
		placeRound2: !1,
		waiting: [],
		draft: null,
		working: null,
		dinner: null,
		uidNext: 1,
		winner: null,
		beatMs: 700
	}, s = ce.map((e, t) => t);
	Re(s, o);
	let c = a.tiles[0] * a.tiles[1];
	o.board.tiles = s.slice(0, c).map((t) => ({
		tile: t,
		rot: e(o.seed, o.rngCursor++, 4)
	}));
	let l = n.map((e, t) => t);
	Re(l, o), o.prevOrder = l.map((e) => n[e]), o.turnOrder = [...o.prevOrder];
	for (let e = 0; e < o.board.th; e++) for (let t = 0; t < o.board.tw; t++) {
		let n = o.board.tiles[e * o.board.tw + t], r = ce[n.tile];
		if (!r.house) continue;
		let i = [];
		for (let [a, o] of [
			[0, 0],
			[0, 1],
			[1, 0],
			[1, 1]
		]) {
			let [s, c] = P(r.house.anchor[0] + a, r.house.anchor[1] + o, n.rot);
			i.push([t * 5 + c, e * 5 + s]);
		}
		o.houses.push({
			id: `p${r.house.num}`,
			num: r.house.num,
			cells: i,
			garden: null,
			demand: [],
			printed: !0
		});
	}
	return o.placeQueue = l.slice().reverse(), { state: o };
}
function X(e) {
	if (e.phase = "restructuring", e.waiting = e.players.map((e) => e.rid), e.round === 1) {
		for (let t of e.players) t.structure = [];
		e.waiting = [], Je(e);
	}
}
function Je(e) {
	e.phase = "orderDraft";
	let t = (t) => {
		let n = t.structure.map((e) => t.cards.find((t) => t.uid === e).emp), r = n.reduce((e, t) => e + (O[t].slots ?? 0), 0);
		return e.ceoSlots + r - n.length + (t.milestones.includes("first_airplane") ? 2 : 0);
	};
	e.draft = {
		choosers: e.players.map((e, t) => t).sort((n, r) => {
			let i = t(e.players[r]) - t(e.players[n]);
			return i === 0 ? e.prevOrder.indexOf(e.players[n].rid) - e.prevOrder.indexOf(e.players[r].rid) : i;
		}),
		taken: {}
	};
}
function Ye(e) {
	let t = {}, n = {}, r = [], i = [], a = [], o = 0, s = [];
	for (let c of e.structure) {
		let l = O[e.cards.find((e) => e.uid === c).emp];
		l.recruit && (t[c] = l.recruit), l.train && (n[c] = l.train), l.marketer && r.push(c), l.produce && i.push(c), l.buyer && a.push(c), l.placeHouse && o++, l.placeRestaurant && s.push(c);
	}
	return {
		sub: "recruit",
		recruitsLeft: 1 + Object.values(t).reduce((e, t) => e + t, 0),
		ceoFreeUsed: !1,
		recruitByCard: t,
		trainSteps: n,
		trainedBy: {},
		marketeers: r,
		producers: i,
		buyers: a,
		nbdLeft: o,
		restaurantCards: s,
		hired: 0
	};
}
function Xe(e, t, n) {
	if (t >= e.turnOrder.length) {
		$e(e, n);
		return;
	}
	let r = ze(e, e.turnOrder[t]);
	e.working = {
		player: r,
		w: Ye(e.players[r])
	};
}
function Ze(e, t) {
	e.phase = "working", e.draft = null, Xe(e, 0, t);
}
function Qe(e, t) {
	let n = e.working, r = e.players[n.player];
	r.salaryDiscount = Object.values(n.w.recruitByCard).reduce((e, t) => e + t, 0) * 5;
	let i = e.turnOrder.indexOf(r.rid) + 1;
	e.working = null, Xe(e, i, t);
}
function $e(e, t) {
	e.phase = "dinnertime", e.working = null;
	let n = [...e.houses].sort((e, t) => e.num - t.num).map((e) => e.id);
	e.dinner = {
		queue: n,
		log: []
	}, n.length || tt(e, t);
}
function et(e, t) {
	let n = e.dinner, r = n.queue.shift();
	if (r === void 0) return;
	let i = e.houses.find((e) => e.id === r);
	if (n.log.push({
		houseId: r,
		winner: null,
		revenue: 0
	}), !i.demand.length) return;
	let a = ye(e.board, [...i.cells, ...i.garden ?? []]);
	if (!a.length) return;
	let o = R(e.board, a), s = /* @__PURE__ */ new Map();
	for (let e of i.demand) s.set(e, (s.get(e) ?? 0) + 1);
	let c = [];
	for (let t = 0; t < e.players.length; t++) {
		let n = e.players[t], r = !0;
		for (let [e, t] of s) if (n.stock[e] + n.freezer.filter((t) => t === e).length < t) {
			r = !1;
			break;
		}
		if (!r) continue;
		let i = Infinity;
		for (let [n, r] of We(e, t)) {
			let e = o.get(N(n, r));
			e !== void 0 && e < i && (i = e);
		}
		i !== Infinity && c.push({
			pi: t,
			dist: i,
			price: Ve(n)
		});
	}
	if (!c.length) return;
	c.sort((t, n) => {
		let r = t.price + t.dist - (n.price + n.dist);
		if (r !== 0) return r;
		let i = G(e.players[n.pi]) - G(e.players[t.pi]);
		return i === 0 ? e.turnOrder.indexOf(e.players[t.pi].rid) - e.turnOrder.indexOf(e.players[n.pi].rid) : i;
	});
	let l = c[0], u = e.players[l.pi], d = i.garden ? 2 : 1, f = 0;
	for (let e of i.demand) {
		if (u.stock[e] > 0) u.stock[e]--;
		else {
			let t = u.freezer.indexOf(e);
			t >= 0 && u.freezer.splice(t, 1);
		}
		let t = 0;
		e === "burger" && u.milestones.includes("first_burger_marketed") && (t = 5), e === "pizza" && u.milestones.includes("first_pizza_marketed") && (t = 5), e !== "burger" && e !== "pizza" && u.milestones.includes("first_drink_marketed") && (t = 5), f += l.price * d + t;
	}
	W(u) && (f = Math.ceil(f * 1.5)), i.demand = [], He(e, l.pi, f, t), n.log[n.log.length - 1] = {
		houseId: r,
		winner: u.rid,
		revenue: f
	}, t.push({
		kind: "sale",
		data: {
			houseId: r,
			rid: u.rid,
			amount: f,
			goods: [...s.entries()]
		}
	}), u.cash >= 20 && K(e, u.rid, "first_20_cash", t);
}
function tt(e, t) {
	for (let n = 0; n < e.players.length; n++) {
		let r = e.players[n], i = G(r);
		i > 0 && (He(e, n, i * (r.milestones.includes("first_waitress") ? 5 : 3), t), r.cash >= 20 && K(e, r.rid, "first_20_cash", t));
	}
	for (let n of e.players) n.cash < 100 || (K(e, n.rid, "first_100_cash", t), n.milestones.includes("first_100_cash") && !n.ceoCfo && (n.ceoCfoPending = !0));
	if (e.dinner = null, e.bankBroken >= 2 || e.config.intro && e.bankBroken >= 1) {
		nt(e);
		return;
	}
	if (e.config.intro) {
		it(e, t);
		return;
	}
	e.phase = "payday", e.waiting = e.players.map((e) => e.rid);
}
function nt(e) {
	e.phase = "done", e.winner = rt(e)[0].rid;
}
function rt(e) {
	return [...e.players].sort((t, n) => n.cash === t.cash ? e.turnOrder.indexOf(t.rid) - e.turnOrder.indexOf(n.rid) : n.cash - t.cash);
}
function it(e, t) {
	e.phase = "marketing";
	let n = [...e.campaigns].sort((e, t) => e.num - t.num);
	for (let r of n) {
		let n = e.players[r.owner], i = r.type === "radio" && n.milestones.includes("first_radio") ? 2 : 1;
		for (let t of Ge(e, r)) {
			let e = (t.garden ? 5 : 3) - t.demand.length;
			for (let n = 0; n < Math.min(i, e); n++) t.demand.push(r.good);
		}
		t.push({
			kind: "campaign",
			data: {
				num: r.num,
				good: r.good,
				rid: n.rid
			}
		}), r.eternal || (r.tokensLeft--, r.tokensLeft <= 0 && (e.campaigns = e.campaigns.filter((e) => e !== r), e.marketingPool.push(r.num), n.busy = n.busy.filter((e) => e.campaign !== r.num)));
	}
	at(e, t);
}
function at(e, t) {
	e.phase = "cleanup";
	let n = [];
	for (let r of e.players) {
		let i = Object.values(r.stock).reduce((e, t) => e + t, 0);
		if (i !== 0) {
			if (!r.milestones.includes("first_throw")) {
				for (let e of Object.keys(r.stock)) r.stock[e] = 0;
				K(e, r.rid, "first_throw", t);
			} else if (i <= 10 - r.freezer.length) for (let e of Object.keys(r.stock)) {
				for (let t = 0; t < r.stock[e]; t++) r.freezer.push(e);
				r.stock[e] = 0;
			}
			else n.push(r.rid);
		}
	}
	if (n.length) {
		e.waiting = n;
		return;
	}
	ot(e);
}
function ot(e) {
	for (let t of e.players) t.structure = [], t.ceoCfoPending &&= (t.ceoCfo = !0, !1);
	for (let t of e.restaurants) t.comingSoon = !1;
	for (let t of e.claimedThisTurn) e.milestoneState[t].closed = !0;
	e.claimedThisTurn = [], e.prevOrder = [...e.turnOrder], e.round++, X(e);
}
function st(e, t) {
	if (e === t) return 0;
	let n = /* @__PURE__ */ new Map([[e, 0]]), r = [e];
	for (; r.length;) {
		let e = r.shift();
		for (let i of O[e].trainsTo ?? []) if (!n.has(i)) {
			if (n.set(i, n.get(e) + 1), i === t) return n.get(i);
			r.push(i);
		}
	}
	return -1;
}
function ct(e, t, n) {
	if (e.config.intro) return 0;
	let r = t.milestones.includes("first_billboard"), i = 0;
	for (let e of t.cards) n.has(e.uid) || O[e.emp].salary && (r && O[e.emp].marketer || i++);
	let a = (t.milestones.includes("first_train") ? 15 : 0) + t.salaryDiscount;
	return Math.max(0, i * 5 - a);
}
function lt(e, t, n, r) {
	if (t.milestones.includes("first_100_cash")) {
		let e = t.cards.find((e) => O[e.emp].cfo);
		e && n.add(e.uid);
	}
	let i = ct(e, t, n);
	for (let r of t.cards) n.has(r.uid) && e.supply[r.emp]++;
	t.cards = t.cards.filter((e) => !n.has(e.uid)), t.structure = t.structure.filter((e) => !n.has(e)), t.busy = t.busy.filter((e) => !n.has(e.uid)), t.cash -= i, e.bank += i, i >= 20 && K(e, t.rid, "first_20_salary", r), t.cash >= 20 && K(e, t.rid, "first_20_cash", r);
}
function ut(e) {
	if (!e.placeQueue.length) {
		if (e.passedThisSetup.length) {
			let t = e.prevOrder;
			e.placeQueue = e.passedThisSetup.sort((n, r) => t.indexOf(e.players[n].rid) - t.indexOf(e.players[r].rid)), e.passedThisSetup = [], e.placeRound2 = !0;
			return;
		}
		if (e.config.intro) {
			X(e);
			return;
		}
		e.phase = "setupReserve", e.waiting = e.players.map((e) => e.rid);
	}
}
function dt(e, t, n) {
	let r = structuredClone(e), i = [];
	if (t.type === "tick") return r.phase === "dinnertime" && r.dinner ? (et(r, i), r.dinner && !r.dinner.queue.length && tt(r, i), {
		state: r,
		fx: i
	}) : { state: r };
	let a = ze(r, n.by);
	if (a < 0) return U("games.fcm.errNotPlayer");
	let o = r.players[a];
	switch (t.type) {
		case "placeFirstRestaurant": {
			if (r.phase !== "setupRestaurants" || r.placeQueue[0] !== a) return U("games.fcm.errNotYourTurn");
			let { x: e, y: n, dir: o } = t;
			if (!Y(r, e, n)) return U("games.fcm.errCellBlocked");
			let [s, c] = H[o];
			if (!L(r.board, e + s, n + c)) return U("games.fcm.errNoRoad");
			let l = Math.floor((e + s) / 5), u = Math.floor((n + c) / 5);
			for (let e of r.restaurants) {
				let [t, n] = Ue(e);
				if (Math.floor(t / 5) === l && Math.floor(n / 5) === u) return U("games.fcm.errSameEntranceTile");
			}
			return r.restaurants.push({
				owner: a,
				x: e,
				y: n,
				dir: o,
				comingSoon: !1
			}), r.placeQueue.shift(), ut(r), {
				state: r,
				fx: i
			};
		}
		case "passFirstRestaurant": return r.phase !== "setupRestaurants" || r.placeQueue[0] !== a ? U("games.fcm.errNotYourTurn") : r.placeRound2 ? U("games.fcm.errMustPlace") : (r.passedThisSetup.push(r.placeQueue.shift()), ut(r), {
			state: r,
			fx: i
		});
		case "chooseReserve": return r.phase !== "setupReserve" || !r.waiting.includes(n.by) ? U("games.fcm.errNotYourTurn") : (o.reserve = t.value, r.waiting = r.waiting.filter((e) => e !== n.by), r.waiting.length || X(r), {
			state: r,
			fx: i
		});
		case "submitStructure": {
			if (r.phase !== "restructuring" || !r.waiting.includes(n.by)) return U("games.fcm.errNotYourTurn");
			if (new Set(t.cards).size !== t.cards.length) return U("games.fcm.errBadCard");
			let e = [];
			for (let n of t.cards) {
				let t = o.cards.find((e) => e.uid === n);
				if (!t || o.busy.some((e) => e.uid === n)) return U("games.fcm.errBadCard");
				e.push(t.emp);
			}
			return Be(r, e) ? (o.structure = t.cards, r.waiting = r.waiting.filter((e) => e !== n.by), e.includes("waitress") && K(r, n.by, "first_waitress", i), e.includes("errand_boy") && K(r, n.by, "first_errand_boy", i), e.includes("cart_operator") && K(r, n.by, "first_cart_operator", i), e.some((e) => (O[e].priceMod ?? 0) < 0) && K(r, n.by, "first_lower_prices", i), r.waiting.length || Je(r), {
				state: r,
				fx: i
			}) : U("games.fcm.errSlotsOverflow");
		}
		case "chooseOrder": {
			if (r.phase !== "orderDraft" || !r.draft || r.players[r.draft.choosers[0]].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = t.position;
			if (e < 0 || e >= r.players.length || r.draft.taken[e]) return U("games.fcm.errBadPosition");
			if (r.draft.taken[e] = n.by, r.draft.choosers.shift(), !r.draft.choosers.length) {
				let e = [];
				for (let t = 0; t < r.players.length; t++) e[t] = r.draft.taken[t];
				r.turnOrder = e, Ze(r, i);
			}
			return {
				state: r,
				fx: i
			};
		}
		case "nextSub": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = Le.indexOf(r.working.w.sub);
			return e < Le.length - 1 && (r.working.w.sub = Le[e + 1]), { state: r };
		}
		case "recruit": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "recruit" || e.recruitsLeft <= 0) return U("games.fcm.errNoAction");
			if (!O[t.emp].recruitable) return U("games.fcm.errNotRecruitable");
			if (r.supply[t.emp] <= 0) return U("games.fcm.errSupplyEmpty");
			if (r.supply[t.emp]--, o.cards.push({
				uid: `c${r.uidNext++}`,
				emp: t.emp
			}), e.recruitsLeft--, !e.ceoFreeUsed) e.ceoFreeUsed = !0;
			else {
				let t = Object.keys(e.recruitByCard).find((t) => e.recruitByCard[t] > 0);
				t && e.recruitByCard[t]--;
			}
			return e.hired++, e.hired >= 3 && K(r, n.by, "first_hire_3", i), e.recruitsLeft <= 0 && (e.sub = "train"), {
				state: r,
				fx: i
			};
		}
		case "train": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "train") return U("games.fcm.errNoAction");
			let a = o.cards.find((e) => e.uid === t.uid);
			if (!a || o.structure.includes(a.uid) || o.busy.some((e) => e.uid === a.uid)) return U("games.fcm.errBadCard");
			let s = st(a.emp, t.to);
			if (s < 1) return U("games.fcm.errBadTrain");
			if (r.supply[t.to] <= 0) return U("games.fcm.errSupplyEmpty");
			if (O[t.to].topPosition && o.cards.some((e) => e.emp === t.to)) return U("games.fcm.errTopDup");
			let c;
			if (o.milestones.includes("first_20_salary")) c = Object.keys(e.trainSteps).filter((t) => e.trainSteps[t] > 0);
			else if (e.trainedBy[a.uid]) c = e.trainSteps[e.trainedBy[a.uid]] > 0 ? [e.trainedBy[a.uid]] : [];
			else {
				let t = Object.entries(e.trainSteps).filter(([, e]) => e > 0).sort((e, t) => t[1] - e[1]);
				c = t.length ? [t[0][0]] : [];
			}
			if (c.reduce((t, n) => t + e.trainSteps[n], 0) < s) return U("games.fcm.errNoTrainSteps");
			let l = s;
			for (let t of c) {
				let n = Math.min(l, e.trainSteps[t]);
				if (e.trainSteps[t] -= n, l -= n, !l) break;
			}
			return e.trainedBy[a.uid] = c[0], r.supply[a.emp]++, r.supply[t.to]--, a.emp = t.to, K(r, n.by, "first_train", i), Object.values(e.trainSteps).every((e) => e <= 0) && (e.sub = "market"), {
				state: r,
				fx: i
			};
		}
		case "marketing": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "market") return U("games.fcm.errNoAction");
			let s = o.cards.find((e) => e.uid === t.uid);
			if (!s || !e.marketeers.includes(t.uid)) return U("games.fcm.errBadCard");
			let c = O[s.emp].marketer, l = ue.find((e) => e.num === t.tile);
			if (!l || !r.marketingPool.includes(t.tile)) return U("games.fcm.errBadTile");
			if (D[l.type] > D[c.maxType]) return U("games.fcm.errBadCampaignType");
			let u = o.milestones.includes("first_billboard");
			if (!u && t.duration > c.maxDuration) return U("games.fcm.errBadDuration");
			if (l.type === "airplane") {
				if (t.placement.kind !== "edge" || !Se(r.board, t.placement.edge, t.placement.index, de[t.tile] ?? 1)) return U("games.fcm.errBadPlacement");
			} else {
				if (t.placement.kind !== "cell") return U("games.fcm.errBadPlacement");
				let { x: e, y: n } = t.placement;
				if (!Y(r, e, n)) return U("games.fcm.errCellBlocked");
				let i = Object.values(H).map(([t, r]) => N(e + t, n + r));
				if (c.range === Infinity) {
					if (!Object.values(H).some(([t, i]) => L(r.board, e + t, n + i))) return U("games.fcm.errNoRoad");
				} else {
					let e = R(r.board, We(r, a), c.range);
					if (!i.some((t) => e.has(t))) return U("games.fcm.errOutOfRange");
				}
			}
			return r.marketingPool = r.marketingPool.filter((e) => e !== t.tile), r.campaigns.push({
				num: t.tile,
				type: l.type,
				owner: a,
				placement: t.placement,
				good: t.good,
				tokensLeft: u ? 1 : t.duration,
				eternal: u
			}), o.busy.push({
				uid: t.uid,
				campaign: t.tile
			}), e.marketeers = e.marketeers.filter((e) => e !== t.uid), l.type === "billboard" && K(r, n.by, "first_billboard", i), l.type === "airplane" && K(r, n.by, "first_airplane", i), l.type === "radio" && K(r, n.by, "first_radio", i), t.good === "burger" ? K(r, n.by, "first_burger_marketed", i) : t.good === "pizza" ? K(r, n.by, "first_pizza_marketed", i) : K(r, n.by, "first_drink_marketed", i), e.marketeers.length || (e.sub = "produce"), {
				state: r,
				fx: i
			};
		}
		case "produce": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "produce") return U("games.fcm.errNoAction");
			let a = o.cards.find((e) => e.uid === t.uid);
			if (!a || !e.producers.includes(t.uid)) return U("games.fcm.errBadCard");
			let s = O[a.emp].produce, c, l;
			if ("choice" in s) {
				if (!t.good || !s.choice.includes(t.good)) return U("games.fcm.errBadGood");
				c = t.good, l = s.n;
			} else c = s.good, l = s.n;
			return o.stock[c] += l, e.producers = e.producers.filter((e) => e !== t.uid), c === "burger" && K(r, n.by, "first_burger_produced", i), c === "pizza" && K(r, n.by, "first_pizza_produced", i), !e.producers.length && !e.buyers.length && (e.sub = "build"), {
				state: r,
				fx: i
			};
		}
		case "buyDrinks": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "produce") return U("games.fcm.errNoAction");
			let s = o.cards.find((e) => e.uid === t.uid);
			if (!s || !e.buyers.includes(t.uid)) return U("games.fcm.errBadCard");
			let c = O[s.emp].buyer, l = +!!o.milestones.includes("first_errand_boy");
			if (c.kind === "anyDrink") {
				if (!t.good || t.good === "burger" || t.good === "pizza") return U("games.fcm.errBadGood");
				o.stock[t.good] += 1 + l;
			} else if (c.kind === "road") {
				let e = c.range + +!!o.milestones.includes("first_cart_operator"), n = R(r.board, We(r, a), e), i = t.sources ?? [];
				if (!i.length) return U("games.fcm.errNoSource");
				let s = _e(r.board);
				for (let [e, t] of i) {
					let r = s.find((n) => n.x === e && n.y === t);
					if (!r) return U("games.fcm.errNoSource");
					if (!Object.values(H).some(([r, i]) => n.has(N(e + r, t + i)))) return U("games.fcm.errOutOfRange");
					o.stock[r.good] += c.perSource + l;
				}
			} else {
				let e = t.tiles ?? [];
				if (!e.length || e.length > c.range + 1) return U("games.fcm.errBadPlacement");
				let n = e.map(([e, t]) => `${e},${t}`);
				if (new Set(n).size !== n.length || !e.every(([e, t]) => e >= 0 && t >= 0 && e < r.board.tw && t < r.board.th) || !new Set(r.restaurants.filter((e) => e.owner === a && !e.comingSoon).map((e) => `${Math.floor(e.x / 5)},${Math.floor(e.y / 5)}`)).has(n[0])) return U("games.fcm.errBadPlacement");
				for (let t = 1; t < e.length; t++) if (Math.abs(e[t][0] - e[t - 1][0]) + Math.abs(e[t][1] - e[t - 1][1]) !== 1) return U("games.fcm.errBadPlacement");
				let i = _e(r.board);
				for (let [t, n] of e) for (let e of i) Math.floor(e.x / 5) === t && Math.floor(e.y / 5) === n && (o.stock[e.good] += c.perSource + l);
			}
			return e.buyers = e.buyers.filter((e) => e !== t.uid), !e.producers.length && !e.buyers.length && (e.sub = "build"), {
				state: r,
				fx: i
			};
		}
		case "placeHouse": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "build" || e.nbdLeft <= 0) return U("games.fcm.errNoAction");
			if (!le.includes(t.num) || r.houses.some((e) => e.num === t.num)) return U("games.fcm.errBadHouse");
			let a = Ke(t.x, t.y, t.rot);
			for (let [e, t] of [...a.house, ...a.garden]) if (!Y(r, e, t)) return U("games.fcm.errCellBlocked");
			return ye(r.board, a.house).length ? (r.houses.push({
				id: `n${t.num}`,
				num: t.num,
				cells: a.house,
				garden: a.garden,
				demand: [],
				printed: !1
			}), e.nbdLeft--, e.nbdLeft || (e.sub = "restaurant"), {
				state: r,
				fx: i
			}) : U("games.fcm.errNoRoad");
		}
		case "placeGarden": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "build" || e.nbdLeft <= 0) return U("games.fcm.errNoAction");
			let a = r.houses.find((e) => e.id === t.houseId);
			if (!a || !a.printed || a.garden) return U("games.fcm.errBadHouse");
			let o = t.rot % 2 == 0 ? [[t.x, t.y], [t.x, t.y + 1]] : [[t.x, t.y], [t.x + 1, t.y]];
			for (let [e, t] of o) if (!Y(r, e, t)) return U("games.fcm.errCellBlocked");
			let s = new Set(a.cells.map(([e, t]) => N(e, t)));
			return o.filter(([e, t]) => Object.values(H).some(([n, r]) => s.has(N(e + n, t + r)))).length === 2 ? (a.garden = o, e.nbdLeft--, e.nbdLeft || (e.sub = "restaurant"), {
				state: r,
				fx: i
			}) : U("games.fcm.errBadPlacement");
		}
		case "placeRestaurant": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "restaurant" || !e.restaurantCards.length) return U("games.fcm.errNoAction");
			if (r.restaurants.filter((e) => e.owner === a).length >= 3) return U("games.fcm.errTooMany");
			let s = e.restaurantCards.find((e) => O[o.cards.find((t) => t.uid === e).emp].placeRestaurant.immediate) ?? e.restaurantCards[0], c = O[o.cards.find((e) => e.uid === s).emp].placeRestaurant, { x: l, y: u, dir: d } = t;
			if (!Y(r, l, u)) return U("games.fcm.errCellBlocked");
			let [f, p] = H[d];
			return L(r.board, l + f, u + p) ? c.range !== Infinity && !R(r.board, We(r, a), c.range).has(N(l + f, u + p)) ? U("games.fcm.errOutOfRange") : (r.restaurants.push({
				owner: a,
				x: l,
				y: u,
				dir: d,
				comingSoon: !c.immediate
			}), e.restaurantCards = e.restaurantCards.filter((e) => e !== s), {
				state: r,
				fx: i
			}) : U("games.fcm.errNoRoad");
		}
		case "moveRestaurant": {
			if (!r.working || r.players[r.working.player].rid !== n.by) return U("games.fcm.errNotYourTurn");
			let e = r.working.w;
			if (e.sub !== "restaurant") return U("games.fcm.errNoAction");
			let s = e.restaurantCards.find((e) => O[o.cards.find((t) => t.uid === e).emp].placeRestaurant.move);
			if (!s) return U("games.fcm.errNoAction");
			let c = r.restaurants.filter((e) => e.owner === a)[t.index];
			if (!c) return U("games.fcm.errBadPlacement");
			let { x: l, y: u, dir: d } = t, f = {
				x: c.x,
				y: c.y
			};
			c.x = -1, c.y = -1;
			let p = Y(r, l, u);
			if (c.x = f.x, c.y = f.y, !p) return U("games.fcm.errCellBlocked");
			let [m, h] = H[d];
			return L(r.board, l + m, u + h) ? (c.x = l, c.y = u, c.dir = d, c.comingSoon = !1, e.restaurantCards = e.restaurantCards.filter((e) => e !== s), {
				state: r,
				fx: i
			}) : U("games.fcm.errNoRoad");
		}
		case "finishWorking": return !r.working || r.players[r.working.player].rid !== n.by ? U("games.fcm.errNotYourTurn") : (Qe(r, i), {
			state: r,
			fx: i
		});
		case "paydaySubmit": {
			if (r.phase !== "payday" || !r.waiting.includes(n.by)) return U("games.fcm.errNotYourTurn");
			let e = new Set(t.fire);
			for (let t of e) if (!o.cards.some((e) => e.uid === t)) return U("games.fcm.errBadCard");
			if ([...e].filter((e) => o.busy.some((t) => t.uid === e)).length) {
				let e = new Set(o.cards.filter((e) => O[e.emp].salary && !o.busy.some((t) => t.uid === e.uid)).map((e) => e.uid));
				if (o.cash >= ct(r, o, e)) return U("games.fcm.errCannotFireBusy");
			}
			let a = ct(r, o, e);
			return o.cash < a ? U("games.fcm.errMustFire") : (lt(r, o, e, i), r.waiting = r.waiting.filter((e) => e !== n.by), r.waiting.length || it(r, i), {
				state: r,
				fx: i
			});
		}
		case "freezerKeep": {
			if (r.phase !== "cleanup" || !r.waiting.includes(n.by)) return U("games.fcm.errNotYourTurn");
			let e = 10 - o.freezer.length;
			if (t.keep.length > e) return U("games.fcm.errFreezerFull");
			let a = /* @__PURE__ */ new Map();
			for (let e of t.keep) a.set(e, (a.get(e) ?? 0) + 1);
			for (let [e, t] of a) if (o.stock[e] < t) return U("games.fcm.errBadGood");
			for (let e of Object.keys(o.stock)) o.stock[e] = 0;
			for (let e of t.keep) o.freezer.push(e);
			return r.waiting = r.waiting.filter((e) => e !== n.by), r.waiting.length || ot(r), {
				state: r,
				fx: i
			};
		}
	}
	return U("games.fcm.errBadPhase");
}
function ft(e, t) {
	let n = (t) => ({
		rid: t.rid,
		brand: t.brand,
		cash: t.cash,
		structure: t.structure.map((e) => ({
			uid: e,
			emp: t.cards.find((t) => t.uid === e).emp
		})),
		beach: t.cards.filter((e) => !t.structure.includes(e.uid) && !t.busy.some((t) => t.uid === e.uid)).map((e) => ({
			uid: e.uid,
			emp: e.emp
		})),
		busy: t.busy.map((e) => ({
			uid: e.uid,
			emp: t.cards.find((t) => t.uid === e.uid)?.emp ?? "waitress"
		})),
		milestones: t.milestones,
		stock: t.stock,
		freezer: t.freezer,
		unitPrice: Ve(t),
		ceoSlots: e.ceoSlots,
		waitressCount: G(t)
	}), r = {};
	if (e.phase === "payday") for (let t of e.players) r[t.rid] = ct(e, t, /* @__PURE__ */ new Set());
	let i = ze(e, t), a = {};
	if (i >= 0) {
		let n = e.players[i];
		if (n.reserve && (a[t] = n.reserve), n.milestones.includes("first_20_cash") || e.bankBroken >= 1) for (let t of e.players) t.reserve && (a[t.rid] = t.reserve);
	}
	return {
		public: {
			phase: e.phase,
			round: e.round,
			intro: e.config.intro,
			board: e.board,
			houses: e.houses.map((e) => ({
				id: e.id,
				num: e.num,
				cells: e.cells,
				garden: e.garden,
				demand: e.demand
			})),
			restaurants: e.restaurants.map((e) => ({
				owner: e.owner,
				x: e.x,
				y: e.y,
				dir: e.dir,
				comingSoon: e.comingSoon
			})),
			campaigns: e.campaigns.map((e) => ({
				num: e.num,
				type: e.type,
				owner: e.owner,
				placement: e.placement,
				good: e.good,
				tokensLeft: e.tokensLeft,
				eternal: e.eternal
			})),
			players: e.players.map(n),
			supply: e.supply,
			marketingPool: e.marketingPool,
			bank: e.bank,
			bankBroken: e.bankBroken,
			milestoneState: e.milestoneState,
			active: e.phase === "setupRestaurants" && e.placeQueue.length ? e.players[e.placeQueue[0]].rid : e.phase === "working" && e.working ? e.players[e.working.player].rid : null,
			orderDraft: e.phase === "orderDraft" && e.draft ? {
				chooser: e.players[e.draft.choosers[0]].rid,
				taken: Object.fromEntries(Object.entries(e.draft.taken).map(([e, t]) => [e, t]))
			} : null,
			turnOrder: e.turnOrder,
			prevOrder: e.prevOrder,
			waiting: e.waiting,
			working: e.working ? {
				sub: e.working.w.sub,
				recruitsLeft: e.working.w.recruitsLeft,
				trainSteps: e.working.w.trainSteps,
				trainedBy: e.working.w.trainedBy,
				marketeersLeft: e.working.w.marketeers,
				producersLeft: e.working.w.producers,
				buyersLeft: e.working.w.buyers,
				nbdLeft: e.working.w.nbdLeft,
				restaurantActions: e.working.w.restaurantCards
			} : null,
			dinner: e.dinner ? {
				current: e.dinner.queue[0] ?? null,
				log: e.dinner.log
			} : null,
			salaryDue: r,
			winner: e.winner
		},
		private: {
			myReserve: i >= 0 ? e.players[i].reserve : null,
			knownReserves: a
		}
	};
}
function pt(e) {
	if (e.phase !== "done" || !e.winner) return { phase: e.phase };
	let t = rt(e);
	return {
		phase: "done",
		winner: [e.winner],
		ranking: t.map((e) => e.rid),
		scores: Object.fromEntries(e.players.map((e) => [e.rid, e.cash]))
	};
}
var mt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: z,
	schemas: {
		action: je,
		publicView: V,
		privateView: Ie,
		config: ke
	},
	setup: qe,
	reduce: dt,
	viewFor: ft,
	status: pt,
	nextTickIn: (e) => e.phase === "dinnertime" && e.dinner && e.dinner.queue.length ? e.beatMs : null
}, Z = {
	burger: "🍔",
	pizza: "🍕",
	beer: "🍺",
	lemonade: "🍋",
	soda: "🥤"
}, ht = {
	billboard: "🪧",
	mailbox: "📬",
	airplane: "✈️",
	radio: "📻"
}, gt = {
	N: "M0,-12 L9,6 L-9,6 Z",
	S: "M0,12 L9,-6 L-9,-6 Z",
	E: "M12,0 L-6,9 L-6,-9 Z",
	W: "M-12,0 L6,9 L6,-9 Z"
}, _t = [
	"★",
	"◆",
	"▲",
	"●",
	"✦"
];
function vt({ tile: e }) {
	let t = ce[e], n = new Set(t.roads.map(([e, t]) => `${e},${t}`)), r = (e, t) => n.has(`${e},${t}`);
	return /* @__PURE__ */ x("g", { children: [
		/* @__PURE__ */ b("rect", {
			width: 220,
			height: 220,
			fill: "#f2dfbd"
		}),
		/* @__PURE__ */ b("rect", {
			width: 220,
			height: 220,
			fill: "url(#fcm-paper)"
		}),
		Array.from({ length: 25 }, (e, t) => {
			let n = Math.floor(t / 5), i = t % 5;
			return r(n, i) ? null : /* @__PURE__ */ b("rect", {
				x: i * 44 + 3,
				y: n * 44 + 3,
				width: 38,
				height: 38,
				fill: "none",
				stroke: "#bd9f77",
				strokeOpacity: ".38",
				strokeWidth: "1"
			}, `lot${t}`);
		}),
		t.roads.map(([e, t], n) => {
			let i = t * 44, a = e * 44, o = r(e, t - 1) || r(e, t + 1), s = r(e - 1, t) || r(e + 1, t);
			return /* @__PURE__ */ x("g", { children: [
				/* @__PURE__ */ b("rect", {
					x: i,
					y: a,
					width: 44,
					height: 44,
					fill: "#92beb5"
				}),
				!r(e - 1, t) && e > 0 && /* @__PURE__ */ b("path", {
					d: `M${i},${a + 2}h44`,
					stroke: "#fff0d0",
					strokeWidth: "3"
				}),
				!r(e + 1, t) && e < 4 && /* @__PURE__ */ b("path", {
					d: `M${i},${a + 44 - 2}h44`,
					stroke: "#fff0d0",
					strokeWidth: "3"
				}),
				!r(e, t - 1) && t > 0 && /* @__PURE__ */ b("path", {
					d: `M${i + 2},${a}v44`,
					stroke: "#fff0d0",
					strokeWidth: "3"
				}),
				!r(e, t + 1) && t < 4 && /* @__PURE__ */ b("path", {
					d: `M${i + 44 - 2},${a}v44`,
					stroke: "#fff0d0",
					strokeWidth: "3"
				}),
				o && /* @__PURE__ */ b("path", {
					d: `M${i + 5},${a + 22}h34`,
					stroke: "#fff3d7",
					strokeWidth: "1.5",
					strokeDasharray: "7 6",
					opacity: ".9"
				}),
				s && /* @__PURE__ */ b("path", {
					d: `M${i + 22},${a + 5}v34`,
					stroke: "#fff3d7",
					strokeWidth: "1.5",
					strokeDasharray: "7 6",
					opacity: ".9"
				})
			] }, `road${n}`);
		}),
		/* @__PURE__ */ b("path", {
			d: "M0 .8H220V220H0Z",
			fill: "none",
			stroke: "#896e56",
			strokeWidth: "1.6"
		}),
		/* @__PURE__ */ x("text", {
			x: 8,
			y: 212,
			fill: "#9b785c",
			fontFamily: "Trebuchet MS, sans-serif",
			fontSize: "10",
			fontWeight: "900",
			letterSpacing: "2",
			children: [t.letter, " / CITY"]
		}),
		t.drinks.map((e, t) => /* @__PURE__ */ x("g", {
			transform: `translate(${e.at[1] * 44 + 22}, ${e.at[0] * 44 + 22})`,
			children: [
				/* @__PURE__ */ b("circle", {
					r: 18,
					fill: "#f4c565",
					stroke: "#303331",
					strokeWidth: "2.5"
				}),
				/* @__PURE__ */ b("circle", {
					r: 14,
					fill: "none",
					stroke: "#fff3d7",
					strokeWidth: "1",
					strokeDasharray: "3 3"
				}),
				/* @__PURE__ */ b("text", {
					y: 8,
					textAnchor: "middle",
					fontSize: 23,
					children: Z[e.good]
				})
			]
		}, `drink${t}`))
	] });
}
function yt(e, t) {
	if (t.w === 0) return {
		cx: 0,
		cy: 0,
		s: 1
	};
	let n = F(e) * 44, r = I(e) * 44, i = Math.min(t.w / (n + 44), t.h / (r + 44));
	return {
		cx: n / 2,
		cy: r / 2,
		s: i
	};
}
function bt({ board: e, pub: t, colorOfOwner: n, hotspots: s, ghostCells: c, restaurantGhost: l, highlightCells: u, fitKey: d, onTapCell: f, onTapHouse: p }) {
	let m = a(null), [h, g] = o({
		w: 0,
		h: 0
	}), [_, v] = o(null), y = a({
		cx: 0,
		cy: 0,
		s: 1
	});
	r(() => {
		let e = m.current, t = new ResizeObserver(() => g({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []);
	let ee = `${d}:${e.tw}x${e.th}:${h.w}x${h.h}`, [te, S] = o("");
	te !== ee && h.w > 0 && (S(ee), v(yt(e, h)));
	let ne = _ ?? yt(e, h);
	r(() => {
		y.current = ne;
	}), r(() => {
		let t = m.current, n = (n) => {
			n.preventDefault();
			let r = t.getBoundingClientRect(), i = y.current, a = n.deltaY < 0 ? 1.15 : 1 / 1.15, o = Math.min(Math.max(i.s * a, yt(e, h).s), 3), s = n.clientX - r.left - r.width / 2, c = n.clientY - r.top - r.height / 2, l = i.cx + s / i.s, u = i.cy + c / i.s, d = {
				s: o,
				cx: l - s / o,
				cy: u - c / o
			};
			y.current = d, v(d);
		};
		return t.addEventListener("wheel", n, { passive: !1 }), () => t.removeEventListener("wheel", n);
	}, [e, h]);
	let C = a(/* @__PURE__ */ new Map()), w = a(0), T = a(0), re = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), C.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), C.current.size === 1 && (w.current = 0), C.current.size === 2) {
			let [e, t] = [...C.current.values()];
			T.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, E = (t) => {
		let n = C.current.get(t.pointerId);
		if (!n) return;
		let r = m.current.getBoundingClientRect();
		if (C.current.size === 1) {
			let e = t.clientX - n.x, r = t.clientY - n.y;
			w.current += Math.abs(e) + Math.abs(r);
			let i = y.current, a = {
				...i,
				cx: i.cx - e / i.s,
				cy: i.cy - r / i.s
			};
			y.current = a, v(a);
		} else if (C.current.size === 2) {
			C.current.set(t.pointerId, {
				x: t.clientX,
				y: t.clientY
			});
			let [n, i] = [...C.current.values()], a = Math.hypot(n.x - i.x, n.y - i.y);
			if (T.current > 0 && a > 0) {
				let t = y.current, o = Math.min(Math.max(t.s * a / T.current, yt(e, h).s), 3), s = (n.x + i.x) / 2 - r.left - r.width / 2, c = (n.y + i.y) / 2 - r.top - r.height / 2, l = t.cx + s / t.s, u = t.cy + c / t.s, d = {
					s: o,
					cx: l - s / o,
					cy: u - c / o
				};
				y.current = d, v(d);
			}
			T.current = a, w.current = 99;
			return;
		}
		C.current.set(t.pointerId, {
			x: t.clientX,
			y: t.clientY
		});
	}, D = i(() => {
		let e = /* @__PURE__ */ new Map();
		for (let n of t.houses) for (let [t, r] of [...n.cells, ...n.garden ?? []]) e.set(N(t, r), n.id);
		return e;
	}, [t.houses]), O = (t) => {
		let n = C.current.size === 1 && w.current < 10;
		if (C.current.delete(t.pointerId), T.current = 0, !n) return;
		let r = m.current.getBoundingClientRect(), i = y.current, a = i.cx + (t.clientX - r.left - r.width / 2) / i.s, o = i.cy + (t.clientY - r.top - r.height / 2) / i.s, c = Math.floor(a / 44), l = Math.floor(o / 44);
		if (!(c < 0 || l < 0 || c >= F(e) || l >= I(e))) {
			if (p && D.has(N(c, l))) {
				p(D.get(N(c, l)));
				return;
			}
			if (s && !s.has(N(c, l))) {
				let e = [...s].map((e) => {
					let [t, n] = e.split(",").map(Number);
					return {
						hx: t,
						hy: n,
						distance: Math.hypot((t + .5) * 44 - a, (n + .5) * 44 - o) * i.s
					};
				}).sort((e, t) => e.distance - t.distance)[0];
				e && e.distance <= 22 && f?.(e.hx, e.hy);
				return;
			}
			f?.(c, l);
		}
	}, ie = F(e) * 44, ae = I(e) * 44, oe = (s?.size ?? 0) > 30;
	return /* @__PURE__ */ b("div", {
		ref: m,
		className: "relative h-full w-full overflow-hidden",
		children: /* @__PURE__ */ x("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: re,
			onPointerMove: E,
			onPointerUp: O,
			onPointerCancel: O,
			children: [/* @__PURE__ */ x("defs", { children: [/* @__PURE__ */ x("pattern", {
				id: "fcm-paper",
				width: "20",
				height: "20",
				patternUnits: "userSpaceOnUse",
				children: [/* @__PURE__ */ b("circle", {
					cx: "3",
					cy: "5",
					r: ".7",
					fill: "#927554",
					opacity: ".26"
				}), /* @__PURE__ */ b("circle", {
					cx: "15",
					cy: "13",
					r: ".5",
					fill: "#927554",
					opacity: ".2"
				})]
			}), /* @__PURE__ */ x("pattern", {
				id: "fcm-garden",
				width: "10",
				height: "10",
				patternUnits: "userSpaceOnUse",
				patternTransform: "rotate(45)",
				children: [/* @__PURE__ */ b("rect", {
					width: "10",
					height: "10",
					fill: "#bcd2a0"
				}), /* @__PURE__ */ b("path", {
					d: "M0 0V10",
					stroke: "#739379",
					strokeWidth: "2",
					opacity: ".4"
				})]
			})] }), /* @__PURE__ */ x("g", {
				transform: `translate(${h.w / 2 - ne.cx * ne.s}, ${h.h / 2 - ne.cy * ne.s}) scale(${ne.s})`,
				children: [
					e.tiles.map((t, n) => {
						let r = n % e.tw, i = Math.floor(n / e.tw);
						return /* @__PURE__ */ b("g", {
							transform: `translate(${r * 5 * 44}, ${i * 5 * 44})`,
							children: /* @__PURE__ */ b("g", {
								transform: `rotate(${t.rot * 90}, 110, 110)`,
								children: /* @__PURE__ */ b(vt, { tile: t.tile })
							})
						}, n);
					}),
					t.houses.map((e) => {
						let t = e.cells.map(([e]) => e), n = e.cells.map(([, e]) => e), r = Math.min(...t) * 44, i = Math.min(...n) * 44, a = (Math.max(...t) - Math.min(...t) + 1) * 44, o = (Math.max(...n) - Math.min(...n) + 1) * 44, s = u && e.cells.some(([e, t]) => u.has(N(e, t)));
						return /* @__PURE__ */ x("g", { children: [
							e.garden?.map(([e, t], n) => /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("rect", {
								x: e * 44 + 3,
								y: t * 44 + 3,
								width: 38,
								height: 38,
								fill: "url(#fcm-garden)",
								stroke: "#3e6257",
								strokeWidth: 2
							}), /* @__PURE__ */ b("text", {
								x: e * 44 + 22,
								y: t * 44 + 22 + 6,
								textAnchor: "middle",
								fontSize: 18,
								children: "✿"
							})] }, `g${n}`)),
							/* @__PURE__ */ b("rect", {
								x: r + 2,
								y: i + 2,
								width: a - 4,
								height: o - 4,
								fill: "#f8ebcc",
								stroke: s ? "#b63831" : "#765d47",
								strokeWidth: s ? 4 : 2
							}),
							a >= 88 && o >= 88 ? /* @__PURE__ */ b("image", {
								href: "/games/fcm/art/sample-house.webp",
								x: r,
								y: i - 10,
								width: a,
								height: o + 10,
								preserveAspectRatio: "xMidYMid meet"
							}) : /* @__PURE__ */ x("g", { children: [
								/* @__PURE__ */ b("path", {
									d: `M${r + 5} ${i + 16}L${r + a / 2} ${i + 3}L${r + a - 5} ${i + 16}Z`,
									fill: "#a94b43",
									stroke: "#2e302d",
									strokeWidth: "2"
								}),
								/* @__PURE__ */ b("rect", {
									x: r + 7,
									y: i + 16,
									width: a - 14,
									height: o - 23,
									fill: "#f5d59c",
									stroke: "#2e302d",
									strokeWidth: "2"
								}),
								/* @__PURE__ */ b("rect", {
									x: r + 12,
									y: i + 20,
									width: a - 24,
									height: 8,
									fill: "#9fcac1",
									stroke: "#2e302d",
									strokeWidth: "1.5"
								})
							] }),
							/* @__PURE__ */ b("rect", {
								x: r + a / 2 - 14,
								y: i + o - 18,
								width: 28,
								height: 16,
								rx: 2,
								fill: "#fff6dc",
								stroke: "#2e302d",
								strokeWidth: "2"
							}),
							/* @__PURE__ */ x("text", {
								x: r + a / 2,
								y: i + o - 6,
								textAnchor: "middle",
								fontSize: 12,
								fontWeight: 900,
								fill: "#272724",
								children: ["#", e.num]
							}),
							e.demand.map((e, t) => /* @__PURE__ */ x("g", {
								transform: `translate(${r + 7 + t % 4 * 20}, ${i - 14 - Math.floor(t / 4) * 19})`,
								children: [/* @__PURE__ */ b("rect", {
									x: -2,
									y: -14,
									width: 19,
									height: 18,
									rx: 2,
									fill: "#fff6dc",
									stroke: "#272724",
									strokeWidth: "1.4"
								}), /* @__PURE__ */ b("text", {
									x: 7,
									y: 0,
									textAnchor: "middle",
									fontSize: 14,
									children: Z[e]
								})]
							}, t))
						] }, e.id);
					}),
					t.restaurants.map((e, r) => {
						let i = n(e.owner), a = t.players[e.owner]?.brand ?? 0;
						return /* @__PURE__ */ x("g", {
							transform: `translate(${e.x * 44}, ${e.y * 44})`,
							opacity: e.comingSoon ? .7 : 1,
							children: [
								/* @__PURE__ */ b("rect", {
									x: 2,
									y: 2,
									width: 40,
									height: 40,
									rx: 3,
									fill: "#fff2d5",
									stroke: "#2e302d",
									strokeWidth: "2.5"
								}),
								a === 0 ? /* @__PURE__ */ b("image", {
									href: "/games/fcm/art/sample-restaurant.webp",
									x: -9,
									y: -13,
									width: 62,
									height: 62,
									preserveAspectRatio: "xMidYMid meet"
								}) : /* @__PURE__ */ x("g", { children: [
									/* @__PURE__ */ b("path", {
										d: "M3 16L22 3L41 16Z",
										fill: a % 2 ? "#b94137" : "#d9a23f",
										stroke: "#2e302d",
										strokeWidth: "2"
									}),
									/* @__PURE__ */ b("rect", {
										x: 5,
										y: 15,
										width: 34,
										height: 24,
										fill: "#f9e6bf",
										stroke: "#2e302d",
										strokeWidth: "2"
									}),
									/* @__PURE__ */ b("rect", {
										x: 5,
										y: 15,
										width: 34,
										height: 8,
										fill: i,
										stroke: "#2e302d",
										strokeWidth: "1.5"
									}),
									/* @__PURE__ */ b("path", {
										d: "M13 16v7M22 16v7M31 16v7",
										stroke: "#fff2d5",
										strokeWidth: "4"
									}),
									/* @__PURE__ */ b("rect", {
										x: 12,
										y: 25,
										width: 20,
										height: 13,
										fill: "#95c7bc",
										stroke: "#2e302d",
										strokeWidth: "1.5"
									})
								] }),
								/* @__PURE__ */ b("circle", {
									cx: 39,
									cy: 5,
									r: 9,
									fill: i,
									stroke: "#2e302d",
									strokeWidth: "2"
								}),
								/* @__PURE__ */ b("text", {
									x: 39,
									y: 9,
									textAnchor: "middle",
									fontSize: 12,
									fontWeight: 900,
									fill: "#fff",
									children: _t[a % _t.length]
								}),
								/* @__PURE__ */ x("g", {
									transform: "translate(22, 41)",
									children: [/* @__PURE__ */ b("circle", {
										r: 8,
										fill: "#fff6dd",
										stroke: "#2e302d",
										strokeWidth: "1.5"
									}), /* @__PURE__ */ b("path", {
										d: gt[e.dir],
										transform: "scale(.43)",
										fill: "#b63831"
									})]
								}),
								e.comingSoon && /* @__PURE__ */ x("g", { children: [/* @__PURE__ */ b("rect", {
									x: 3,
									y: 15,
									width: 38,
									height: 16,
									fill: "#fff3d5",
									stroke: "#2e302d",
									strokeWidth: "1.8"
								}), /* @__PURE__ */ b("text", {
									x: 22,
									y: 27,
									textAnchor: "middle",
									fontSize: 10,
									fontWeight: 900,
									fill: "#a6322e",
									children: "SOON"
								})] })
							]
						}, r);
					}),
					t.campaigns.map((e, t) => {
						let r = n(e.owner);
						if (e.placement.kind === "cell") return /* @__PURE__ */ x("g", {
							transform: `translate(${e.placement.x * 44}, ${e.placement.y * 44})`,
							children: [
								/* @__PURE__ */ b("rect", {
									x: 6,
									y: 6,
									width: 32,
									height: 32,
									rx: 8,
									fill: "var(--color-surface)",
									className: "stroke-ink",
									strokeWidth: 2.5
								}),
								/* @__PURE__ */ b("rect", {
									x: 6,
									y: 6,
									width: 32,
									height: 10,
									rx: 4,
									fill: r,
									stroke: "none"
								}),
								/* @__PURE__ */ b("text", {
									x: 22,
									y: 30,
									textAnchor: "middle",
									fontSize: 20,
									children: ht[e.type]
								}),
								/* @__PURE__ */ b("text", {
									x: 36,
									y: 38,
									textAnchor: "end",
									fontSize: 13,
									children: e.eternal ? "∞" : `${Z[e.good]}${e.tokensLeft}`
								})
							]
						}, `c${t}`);
						let { edge: i, index: a } = e.placement, o = i === "N" || i === "S", s = o ? a * 44 - 22 : i === "W" ? -35.2 : ie + 4.4, c = o ? i === "N" ? -35.2 : ae + 4.4 : a * 44 - 22;
						return /* @__PURE__ */ x("g", {
							transform: `translate(${s}, ${c})`,
							children: [/* @__PURE__ */ b("rect", {
								x: 0,
								y: 0,
								width: o ? 88 : 44 * .7,
								height: o ? 44 * .7 : 88,
								rx: 8,
								fill: r,
								className: "stroke-ink",
								strokeWidth: 2.5
							}), /* @__PURE__ */ x("text", {
								x: (o ? 88 : 44 * .7) / 2,
								y: (o ? 44 * .7 : 88) / 2 + 7,
								textAnchor: "middle",
								fontSize: 18,
								children: ["✈️", e.eternal ? "∞" : e.tokensLeft]
							})]
						}, `c${t}`);
					}),
					s && !l && [...s].map((e) => {
						let [t, n] = e.split(",").map(Number);
						return /* @__PURE__ */ x("g", {
							transform: `translate(${t * 44 + 22}, ${n * 44 + 22})`,
							children: [
								!oe && /* @__PURE__ */ b("rect", {
									x: -19,
									y: -19,
									width: 38,
									height: 38,
									rx: 3,
									fill: "none",
									stroke: "#b6483d",
									strokeWidth: 2.2,
									strokeDasharray: "6 5"
								}),
								/* @__PURE__ */ b("circle", {
									r: oe ? 6 : 10,
									fill: "#2b7771",
									stroke: "#fff4da",
									strokeWidth: oe ? 2 : 2.5
								}),
								!oe && /* @__PURE__ */ b("text", {
									y: 5,
									textAnchor: "middle",
									fill: "#fff4da",
									fontSize: 16,
									fontWeight: 900,
									children: "+"
								})
							]
						}, `s${e}`);
					}),
					c?.map(([e, t], n) => /* @__PURE__ */ b("rect", {
						x: e * 44 + 3,
						y: t * 44 + 3,
						width: 38,
						height: 38,
						rx: 3,
						fill: "#f9dfaa",
						fillOpacity: .56,
						stroke: "#b63831",
						strokeWidth: 3,
						strokeDasharray: "7 4"
					}, `gh${n}`)),
					l && /* @__PURE__ */ x("g", {
						transform: `translate(${l.x * 44}, ${l.y * 44})`,
						children: [
							/* @__PURE__ */ b("rect", {
								x: -2,
								y: -2,
								width: 48,
								height: 48,
								fill: "#fff4d8",
								fillOpacity: ".74",
								stroke: "#b63831",
								strokeWidth: 3,
								strokeDasharray: "6 4"
							}),
							/* @__PURE__ */ b("image", {
								href: "/games/fcm/art/sample-restaurant.webp",
								x: -13,
								y: -20,
								width: 70,
								height: 70,
								preserveAspectRatio: "xMidYMid meet"
							}),
							/* @__PURE__ */ x("g", {
								transform: "translate(22, 49)",
								children: [/* @__PURE__ */ b("circle", {
									r: 10,
									fill: "#fff5dd",
									stroke: "#292b2a",
									strokeWidth: 2
								}), /* @__PURE__ */ b("path", {
									d: gt[l.dir],
									transform: "scale(.54)",
									fill: "#b63831"
								})]
							})
						]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/games/fcm/view-player.tsx
var Q = {
	N: [0, -1],
	E: [1, 0],
	S: [0, 1],
	W: [-1, 0]
}, xt = [
	"N",
	"E",
	"S",
	"W"
];
function St(e) {
	return /* @__PURE__ */ b(Dt, {
		pub: e.public,
		priv: e.private ?? {
			myReserve: null,
			knownReserves: {}
		},
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function Ct(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.houses) {
		for (let [e, r] of n.cells) t.add(N(e, r));
		for (let [e, r] of n.garden ?? []) t.add(N(e, r));
	}
	for (let n of e.restaurants) t.add(N(n.x, n.y));
	for (let n of e.campaigns) n.placement.kind === "cell" && t.add(N(n.placement.x, n.placement.y));
	for (let n of _e(e.board)) t.add(N(n.x, n.y));
	return t;
}
function wt(e, t) {
	let n = e.board, r = e.players[t].structure.some((e) => O[e.emp].placeRestaurant), i = [];
	for (let a of e.restaurants) if (!(a.owner !== t || a.comingSoon)) {
		if (r) for (let e of xt) {
			let [t, r] = Q[e];
			L(n, a.x + t, a.y + r) && i.push([a.x + t, a.y + r]);
		}
		else {
			let [e, t] = Q[a.dir];
			L(n, a.x + e, a.y + t) && i.push([a.x + e, a.y + t]);
		}
	}
	return i;
}
function Tt(e, t) {
	if (e === t) return 0;
	let n = [e], r = /* @__PURE__ */ new Set([e]);
	for (let e = 1; e <= 6; e++) {
		let i = [];
		for (let a of n) for (let n of O[a].trainsTo ?? []) if (!r.has(n)) {
			if (n === t) return e;
			r.add(n), i.push(n);
		}
		n = i;
	}
	return -1;
}
function Et(e) {
	let t = O[e];
	return t.placeRestaurant ? "🏪" : t.placeHouse ? "⌂" : t.produce ? "🍳" : t.buyer ? "🛒" : t.marketer ? "📣" : t.recruit ? "👥" : t.train ? "🎓" : t.priceMod ? "＄" : t.cfo ? "◈" : e === "waitress" ? "☕" : "★";
}
function Dt({ pub: e, priv: t, members: n, myRid: r, send: a }) {
	let c = l(), u = e.board, d = e.players.findIndex((e) => e.rid === r), f = d >= 0 ? e.players[d] : null, { ref: p } = s("bank"), y = (e) => n.find((t) => t.rid === e)?.name ?? e, S = (e) => g[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % g.length].hex, ne = (t) => S(e.players[t]?.rid ?? ""), [C, w] = o(null), [E, k] = o(null), [A, se] = o(null), [j, M] = o(null), [ce, fe] = o(null), [P, he] = o(null), [ge, ve] = o(null), [ye, be] = o("house"), [xe, Ce] = o(/* @__PURE__ */ new Set()), [we, Te] = o(null), [Ee, De] = o(null), [Oe, ke] = o(0), [Ae, je] = o(!1), Me = `${e.phase}:${e.round}:${e.active}:${e.working?.sub ?? ""}:${e.waiting.includes(r)}`, [Ne, Pe] = o("");
	Ne !== Me && (Pe(Me), w(null), k(null), se(null), M(null), fe(null), he(null), ve(null), Ce(/* @__PURE__ */ new Set()), Te(null), De(null));
	let B = e.phase !== "done" && e.active === r, Fe = e.phase !== "done" && e.waiting.includes(r), V = e.working, Ie = i(() => Ct(e), [e]), H = (e, t) => e >= 0 && t >= 0 && e < F(u) && t < I(u) && !L(u, e, t) && !Ie.has(N(e, t)), Le = new Set(e.restaurants.map((e) => {
		let [t, n] = Q[e.dir];
		return N(Math.floor((e.x + t) / 5), Math.floor((e.y + n) / 5));
	})), U = V?.sub === "restaurant" && f ? V.restaurantActions.find((e) => O[f.structure.find((t) => t.uid === e)?.emp ?? "local_manager"].placeRestaurant?.immediate) ?? V.restaurantActions[0] : void 0, Re = U && f?.structure.find((e) => e.uid === U), ze = Re ? O[Re.emp].placeRestaurant?.range : void 0, Be = e.phase === "working" && ge === null && ze !== void 0 && ze !== Infinity && d >= 0 ? R(u, wt(e, d), ze) : null, Ve = (t, n) => xt.filter((r) => {
		let [i, a] = Q[r], o = t + i, s = n + a;
		return !L(u, o, s) || e.phase === "setupRestaurants" && Le.has(N(Math.floor(o / 5), Math.floor(s / 5))) ? !1 : !Be || Be.has(N(o, s));
	}), W, G, K, q, He;
	if (e.phase === "setupRestaurants" && B) {
		W = /* @__PURE__ */ new Set();
		for (let e = 0; e < I(u); e++) for (let t = 0; t < F(u); t++) H(t, e) && Ve(t, e).length && W.add(N(t, e));
		C && (G = [[C.x, C.y]]), q = (e, t) => {
			if (!W.has(N(e, t))) return;
			let n = Ve(e, t)[0];
			w({
				x: e,
				y: t,
				dir: n
			});
		};
	}
	if (e.phase === "working" && B && V) {
		if (V.sub === "market" && j?.tile != null && ue.find((e) => e.num === j.tile).type !== "airplane") {
			let t = O[f.structure.find((e) => e.uid === j.uid)?.emp ?? "marketing_trainee"].marketer, n = t.range === Infinity ? null : R(u, wt(e, d), t.range);
			W = /* @__PURE__ */ new Set();
			for (let e = 0; e < I(u); e++) for (let t = 0; t < F(u); t++) H(t, e) && xt.some((r) => {
				let [i, a] = Q[r];
				return n ? n.has(N(t + i, e + a)) : L(u, t + i, e + a);
			}) && W.add(N(t, e));
			q = (e, t) => {
				W.has(N(e, t)) && M({
					...j,
					cell: {
						x: e,
						y: t
					},
					edge: null
				});
			}, j.cell && (G = [[j.cell.x, j.cell.y]]);
		}
		if (V.sub === "produce" && P) {
			let t = f.structure.find((e) => e.uid === P.uid), n = t ? O[t.emp].buyer : void 0;
			if (n && n.kind === "road") {
				let t = R(u, wt(e, d), n.range + +!!f.milestones.includes("first_cart_operator"));
				W = new Set(_e(u).filter((e) => xt.some((n) => t.has(N(e.x + Q[n][0], e.y + Q[n][1])))).map((e) => N(e.x, e.y))), q = (e, t) => {
					if (!W.has(N(e, t))) return;
					let n = P.sources.some(([n, r]) => n === e && r === t);
					he({
						...P,
						sources: n ? P.sources.filter(([n, r]) => n !== e || r !== t) : [...P.sources, [e, t]]
					});
				};
			} else if (n && n.kind === "fly") {
				W = /* @__PURE__ */ new Set();
				let t = new Set(P.tiles.map(([e, t]) => `${e},${t}`)), r = e.restaurants.filter((e) => e.owner === d && !e.comingSoon).map((e) => [Math.floor(e.x / 5), Math.floor(e.y / 5)]);
				if (!P.tiles.length) for (let [e, t] of r) for (let n = 0; n < 5; n++) for (let r = 0; r < 5; r++) W.add(N(e * 5 + r, t * 5 + n));
				else if (P.tiles.length <= n.range) {
					let [e, n] = P.tiles[P.tiles.length - 1];
					for (let [r, i] of [
						[1, 0],
						[-1, 0],
						[0, 1],
						[0, -1]
					]) {
						let a = e + r, o = n + i;
						if (!(a < 0 || o < 0 || a >= u.tw || o >= u.th || t.has(`${a},${o}`))) for (let e = 0; e < 5; e++) for (let t = 0; t < 5; t++) W.add(N(a * 5 + t, o * 5 + e));
					}
				}
				q = (e, t) => {
					W.has(N(e, t)) && he({
						...P,
						tiles: [...P.tiles, [Math.floor(e / 5), Math.floor(t / 5)]]
					});
				};
			}
		}
		if (V.sub === "build" && V.nbdLeft > 0) {
			if (ye === "house") {
				W = /* @__PURE__ */ new Set();
				for (let e = 0; e < I(u); e++) for (let t = 0; t < F(u); t++) H(t, e) && W.add(N(t, e));
				if (q = (t, n) => {
					if (!W.has(N(t, n))) return;
					let r = E?.num ?? le.find((t) => !e.houses.some((e) => e.num === t));
					r !== void 0 && k({
						x: t,
						y: n,
						rot: E?.x === t && E?.y === n ? E.rot : 0,
						num: r
					});
				}, E) {
					let [e, t] = [
						[0, 1],
						[-1, 0],
						[0, -1],
						[1, 0]
					][E.rot];
					G = [[E.x, E.y], [E.x + e, E.y + t]];
				}
			} else if (He = (t) => {
				let n = e.houses.find((e) => e.id === t);
				n && n.garden === null && se({
					houseId: t,
					pick: null
				});
			}, A) {
				let t = e.houses.find((e) => e.id === A.houseId);
				W = /* @__PURE__ */ new Set();
				let n = new Set(t.cells.map(([e, t]) => N(e, t)));
				for (let e = 0; e < I(u); e++) for (let t = 0; t < F(u); t++) for (let r of [0, 1]) {
					let i = r === 0 ? [[t, e], [t, e + 1]] : [[t, e], [t + 1, e]];
					if (i.every(([e, t]) => H(e, t)) && i.filter(([e, t]) => xt.some((r) => n.has(N(e + Q[r][0], t + Q[r][1])))).length === 2) for (let [e, t] of i) W.add(N(e, t));
				}
				if (q = (e, t) => {
					if (W.has(N(e, t))) for (let r of [0, 1]) for (let i = 0; i < I(u); i++) for (let a = 0; a < F(u); a++) {
						let o = r === 0 ? [[a, i], [a, i + 1]] : [[a, i], [a + 1, i]];
						if (o.every(([e, t]) => H(e, t)) && o.filter(([e, t]) => xt.some((r) => n.has(N(e + Q[r][0], t + Q[r][1])))).length === 2 && o.some(([n, r]) => n === e && r === t)) {
							se({
								houseId: A.houseId,
								pick: {
									x: a,
									y: i,
									rot: r
								}
							});
							return;
						}
					}
				}, A.pick) {
					let e = A.pick;
					G = e.rot === 0 ? [[e.x, e.y], [e.x, e.y + 1]] : [[e.x, e.y], [e.x + 1, e.y]];
				}
			}
		}
		if (V.sub === "restaurant" && V.restaurantActions.length) {
			W = /* @__PURE__ */ new Set();
			for (let e = 0; e < I(u); e++) for (let t = 0; t < F(u); t++) H(t, e) && Ve(t, e).length && W.add(N(t, e));
			q = (e, t) => {
				if (!W.has(N(e, t))) return;
				let n = Ve(e, t)[0];
				w({
					x: e,
					y: t,
					dir: n
				});
			}, C && (G = [[C.x, C.y]]);
		}
	}
	if (e.phase === "dinnertime" && e.dinner?.current) {
		let t = e.houses.find((t) => t.id === e.dinner.current);
		t && (K = new Set([...t.cells, ...t.garden ?? []].map(([e, t]) => N(e, t))));
	}
	let Ue = e.active ? y(e.active) : "", We = "info", J = c(`games.fcm.phase.${e.phase}`);
	e.phase === "working" ? J = B ? `${c("games.fcm.phase.working")} · ${c(`games.fcm.sub.${V.sub}`)}` : c("games.fcm.ui.waiting") : (e.phase === "setupRestaurants" || e.phase === "orderDraft") && (J = B || e.orderDraft?.chooser === r ? J : `${J} · ${Ue || c("games.fcm.ui.waiting")}`), (B || Fe && e.phase !== "done") && (We = "accent"), e.phase === "done" && (We = "done");
	let Y = C ? Ve(C.x, C.y) : [], Ge = () => C && Y.length > 1 && w({
		...C,
		dir: Y[(Y.indexOf(C.dir) + 1) % Y.length]
	}), Ke = () => E && k({
		...E,
		rot: (E.rot + 1) % 4
	}), qe = /* @__PURE__ */ b("p", {
		className: "flex min-h-12 flex-1 items-center justify-center text-xs font-bold opacity-50",
		children: c("games.fcm.ui.waiting")
	});
	e.phase === "setupRestaurants" && B && (qe = /* @__PURE__ */ x(te, { children: [
		/* @__PURE__ */ b("button", {
			type: "button",
			"aria-label": c("games.fcm.ui.rotate"),
			disabled: Y.length < 2,
			onClick: Ge,
			className: "btn-quiet grid size-12 flex-none place-items-center",
			children: /* @__PURE__ */ b(h, {
				size: 20,
				"aria-hidden": !0
			})
		}),
		/* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => a({ type: "passFirstRestaurant" }),
			className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
			children: c("games.fcm.ui.pass")
		}),
		/* @__PURE__ */ b("button", {
			type: "button",
			disabled: !C,
			onClick: () => {
				a({
					type: "placeFirstRestaurant",
					x: C.x,
					y: C.y,
					dir: C.dir
				}), w(null);
			},
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: z.accent },
			children: c("games.fcm.ui.confirm")
		})
	] })), e.phase === "working" && B && V && (qe = /* @__PURE__ */ x(te, { children: [
		(C || E) && /* @__PURE__ */ b("button", {
			type: "button",
			"aria-label": c("games.fcm.ui.rotate"),
			disabled: !!C && Y.length < 2,
			onClick: C ? Ge : Ke,
			className: "btn-quiet grid size-12 flex-none place-items-center",
			children: /* @__PURE__ */ b(h, {
				size: 20,
				"aria-hidden": !0
			})
		}),
		V.sub !== "restaurant" && /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => a({ type: "nextSub" }),
			className: "btn-quiet min-h-12 flex-none px-3 text-xs font-bold",
			children: c("games.fcm.ui.nextSub")
		}),
		V.sub === "restaurant" && C && /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => {
				a(ge === null ? {
					type: "placeRestaurant",
					x: C.x,
					y: C.y,
					dir: C.dir
				} : {
					type: "moveRestaurant",
					index: ge,
					x: C.x,
					y: C.y,
					dir: C.dir
				}), w(null), ve(null);
			},
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: z.accent },
			children: c("games.fcm.ui.confirm")
		}),
		V.sub === "build" && E && /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => {
				a({
					type: "placeHouse",
					num: E.num,
					x: E.x,
					y: E.y,
					rot: E.rot
				}), k(null);
			},
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: z.accent },
			children: c("games.fcm.ui.confirm")
		}),
		V.sub === "build" && A?.pick && /* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => {
				a({
					type: "placeGarden",
					houseId: A.houseId,
					x: A.pick.x,
					y: A.pick.y,
					rot: A.pick.rot
				}), se(null);
			},
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: z.accent },
			children: c("games.fcm.ui.confirm")
		}),
		/* @__PURE__ */ b("button", {
			type: "button",
			onClick: () => a({ type: "finishWorking" }),
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: z.accent },
			children: c("games.fcm.ui.finishTurn")
		})
	] }));
	let X = null;
	if (e.phase === "setupReserve" && Fe && f && (X = /* @__PURE__ */ b($, {
		title: c("games.fcm.ui.chooseReserve"),
		children: /* @__PURE__ */ b("div", {
			className: "grid grid-cols-3 gap-2",
			children: pe.map((e) => /* @__PURE__ */ x("button", {
				type: "button",
				onClick: () => a({
					type: "chooseReserve",
					value: e
				}),
				className: "card min-h-12 cursor-pointer p-2 text-center",
				children: [/* @__PURE__ */ x("p", {
					className: "font-mono text-base font-black",
					children: ["$", e]
				}), /* @__PURE__ */ b("p", {
					className: "text-[10px] opacity-70",
					children: c("games.fcm.ui.reserveSlots", { n: me[e] })
				})]
			}, e))
		})
	})), e.phase === "restructuring" && Fe && f) {
		let e = f.structure.filter((e) => !f.busy.some((t) => t.uid === e.uid)).concat(f.beach), t = Ee ? new Set([...Ee].filter((t) => e.some((e) => e.uid === t))) : new Set(e.filter((e) => f.structure.some((t) => t.uid === e.uid)).map((e) => e.uid)), n = e.filter((e) => t.has(e.uid)).map((e) => e.emp), r = n.filter((e) => O[e].slots).length, i = n.reduce((e, t) => e + (O[t].slots ?? 0), 0), o = f.ceoSlots + i, s = r <= f.ceoSlots && n.length <= o, l = (e) => {
			let n = new Set(t);
			n.has(e) ? n.delete(e) : n.add(e), De(n);
		};
		X = /* @__PURE__ */ x($, {
			title: `${c("games.fcm.ui.yourStructure")} · ${c("games.fcm.ui.ceoSlots", { n: f.ceoSlots })} · ${n.length}/${o}`,
			children: [/* @__PURE__ */ b("div", {
				className: "flex flex-wrap gap-1.5",
				children: e.map((e) => /* @__PURE__ */ b(Ot, {
					emp: e.emp,
					active: t.has(e.uid),
					onClick: () => l(e.uid),
					t: c
				}, e.uid))
			}), /* @__PURE__ */ b("button", {
				type: "button",
				disabled: !s,
				onClick: () => a({
					type: "submitStructure",
					cards: e.filter((e) => t.has(e.uid)).map((e) => e.uid)
				}),
				className: "btn-base min-h-12 w-full text-sm text-white",
				style: { background: z.accent },
				children: c("games.fcm.ui.confirm")
			})]
		});
	}
	if (e.phase === "orderDraft" && e.orderDraft?.chooser === r && (X = /* @__PURE__ */ b($, {
		title: c("games.fcm.ui.chooseOrderPos"),
		children: /* @__PURE__ */ b("div", {
			className: "flex gap-2",
			children: e.players.map((t, n) => {
				let r = e.orderDraft.taken[String(n)];
				return /* @__PURE__ */ x("button", {
					type: "button",
					disabled: !!r,
					onClick: () => a({
						type: "chooseOrder",
						position: n
					}),
					className: "card min-h-12 min-w-12 flex-1 cursor-pointer p-1 text-center",
					children: [/* @__PURE__ */ b("p", {
						className: "font-mono text-lg font-black",
						children: n + 1
					}), r && /* @__PURE__ */ b("p", {
						className: "truncate text-[10px] opacity-70",
						children: y(r)
					})]
				}, n);
			})
		})
	})), e.phase === "working" && B && V && f) {
		if (V.sub === "recruit" && (X = /* @__PURE__ */ b($, {
			title: `${c("games.fcm.sub.recruit")} · ${c("games.fcm.ui.recruitsLeft", { n: V.recruitsLeft })}`,
			children: /* @__PURE__ */ b("div", {
				className: "flex flex-wrap gap-1.5",
				children: ae.filter((t) => (e.supply[t] ?? 0) > 0).map((t) => /* @__PURE__ */ x("button", {
					type: "button",
					onClick: () => a({
						type: "recruit",
						emp: t
					}),
					className: "card fcm-recruit-card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold",
					children: [
						/* @__PURE__ */ b("span", {
							className: "fcm-job-mark",
							"aria-hidden": !0,
							children: Et(t)
						}),
						/* @__PURE__ */ b("span", { children: c(O[t].nameKey) }),
						/* @__PURE__ */ x("span", {
							className: "font-mono opacity-60",
							children: ["×", e.supply[t]]
						})
					]
				}, t))
			})
		})), V.sub === "train") {
			let t = Object.values(V.trainSteps).reduce((e, t) => e + t, 0), n = f.beach.filter((e) => (O[e.emp].trainsTo ?? []).length > 0), r = ce ? f.beach.find((e) => e.uid === ce) : null, i = r ? ie.map((e) => ({
				to: e,
				steps: Tt(r.emp, e)
			})).filter((n) => n.steps >= 1 && n.steps <= t && (e.supply[n.to] ?? 0) > 0 && !(O[n.to].topPosition && f.beach.concat(f.structure).some((e) => e.emp === n.to))) : [];
			X = /* @__PURE__ */ x($, {
				title: `${c("games.fcm.sub.train")} · ${c("games.fcm.ui.trainSteps", { n: t })}`,
				children: [/* @__PURE__ */ b("div", {
					className: "flex flex-wrap gap-1.5",
					children: n.map((e) => /* @__PURE__ */ b(Ot, {
						emp: e.emp,
						active: ce === e.uid,
						onClick: () => fe(ce === e.uid ? null : e.uid),
						t: c
					}, e.uid))
				}), i.length > 0 && /* @__PURE__ */ b("div", {
					className: "flex flex-wrap gap-1.5",
					children: i.map((e) => /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => a({
							type: "train",
							uid: r.uid,
							to: e.to
						}),
						className: "card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold",
						children: [
							"→ ",
							c(O[e.to].nameKey),
							" ",
							/* @__PURE__ */ x("span", {
								className: "font-mono opacity-60",
								children: ["🎓", e.steps]
							})
						]
					}, e.to))
				})]
			});
		}
		if (V.sub === "market") {
			let t = j ? f.structure.find((e) => e.uid === j.uid) : null, n = t ? O[t.emp].marketer : null, r = n ? e.marketingPool.map((e) => ue.find((t) => t.num === e)).filter((e) => D[e.type] <= D[n.maxType]) : [], i = j?.tile == null ? null : ue.find((e) => e.num === j.tile), o = i ? i.type === "airplane" ? j.edge ? {
				kind: "edge",
				...j.edge
			} : null : j.cell ? {
				kind: "cell",
				...j.cell
			} : null : null;
			X = /* @__PURE__ */ x($, {
				title: c("games.fcm.sub.market"),
				children: [/* @__PURE__ */ b("div", {
					className: "flex flex-wrap gap-1.5",
					children: V.marketeersLeft.map((e) => {
						let t = f.structure.find((t) => t.uid === e);
						return t ? /* @__PURE__ */ b(Ot, {
							emp: t.emp,
							active: j?.uid === e,
							onClick: () => M({
								uid: e,
								tile: null,
								cell: null,
								edge: null,
								good: "burger",
								duration: 1
							}),
							t: c
						}, e) : null;
					})
				}), j && n && /* @__PURE__ */ x(te, { children: [
					/* @__PURE__ */ b("div", {
						className: "flex flex-wrap gap-1.5",
						children: r.map((e) => /* @__PURE__ */ x("button", {
							type: "button",
							onClick: () => M({
								...j,
								tile: e.num,
								cell: null,
								edge: null
							}),
							className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${j.tile === e.num ? "ring-3 ring-ink" : ""}`,
							children: [
								c(`games.fcm.ct.${e.type}`),
								" #",
								e.num
							]
						}, e.num))
					}),
					i?.type === "airplane" && /* @__PURE__ */ b("div", {
						className: "flex flex-wrap items-center gap-1.5",
						children: xt.map((e) => {
							let t = de[i.num] ?? 1, n = e === "N" || e === "S" ? F(u) : I(u), r = Array.from({ length: n }, (e, t) => t).filter((n) => Se(u, e, n, t));
							return /* @__PURE__ */ b("span", {
								className: "flex gap-1",
								children: r.map((t) => /* @__PURE__ */ x("button", {
									type: "button",
									onClick: () => M({
										...j,
										edge: {
											edge: e,
											index: t
										},
										cell: null
									}),
									className: `card min-h-11 min-w-11 cursor-pointer px-1 text-xs font-black ${j.edge?.edge === e && j.edge?.index === t ? "ring-3 ring-ink" : ""}`,
									children: [e, t]
								}, t))
							}, e);
						})
					}),
					i && /* @__PURE__ */ x("div", {
						className: "flex flex-wrap items-center gap-1.5",
						children: [
							T.map((e) => /* @__PURE__ */ b("button", {
								type: "button",
								"aria-label": c(`games.fcm.good.${e}`),
								onClick: () => M({
									...j,
									good: e
								}),
								className: `card grid size-11 cursor-pointer place-items-center text-lg ${j.good === e ? "ring-3 ring-ink" : ""}`,
								children: Z[e]
							}, e)),
							!f.milestones.includes("first_billboard") && Array.from({ length: n.maxDuration }, (e, t) => t + 1).map((e) => /* @__PURE__ */ x("button", {
								type: "button",
								onClick: () => M({
									...j,
									duration: e
								}),
								className: `card min-h-11 min-w-11 cursor-pointer px-1 font-mono text-sm font-black ${j.duration === e ? "ring-3 ring-ink" : ""}`,
								children: ["×", e]
							}, e)),
							/* @__PURE__ */ b("button", {
								type: "button",
								disabled: !o,
								onClick: () => {
									a({
										type: "marketing",
										uid: j.uid,
										tile: j.tile,
										placement: o,
										good: j.good,
										duration: j.duration
									}), M(null);
								},
								className: "btn-base min-h-11 flex-1 text-xs text-white",
								style: { background: z.accent },
								children: c("games.fcm.ui.confirm")
							})
						]
					})
				] })]
			});
		}
		if (V.sub === "produce" && (X = /* @__PURE__ */ b($, {
			title: c("games.fcm.sub.produce"),
			children: /* @__PURE__ */ x("div", {
				className: "flex flex-wrap gap-1.5",
				children: [V.producersLeft.map((e) => {
					let t = f.structure.find((t) => t.uid === e);
					if (!t) return null;
					let n = O[t.emp].produce;
					return "choice" in n ? n.choice.map((r) => /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => a({
							type: "produce",
							uid: e,
							good: r
						}),
						className: "card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold",
						children: [
							Z[r],
							"×",
							n.n,
							" ",
							c(O[t.emp].nameKey)
						]
					}, `${e}${r}`)) : /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => a({
							type: "produce",
							uid: e
						}),
						className: "card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold",
						children: [
							Z[n.good],
							"×",
							n.n,
							" ",
							c(O[t.emp].nameKey)
						]
					}, e);
				}), V.buyersLeft.map((e) => {
					let t = f.structure.find((t) => t.uid === e);
					if (!t) return null;
					let n = O[t.emp].buyer;
					if (n.kind === "anyDrink") return re.map((n) => /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => a({
							type: "buyDrinks",
							uid: e,
							good: n
						}),
						className: "card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold",
						children: [
							Z[n],
							" ",
							c(O[t.emp].nameKey)
						]
					}, `${e}${n}`));
					let r = n.kind === "road" ? P?.uid === e && P.sources.length > 0 : P?.uid === e && P.tiles.length > 0;
					return /* @__PURE__ */ x("span", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ x("button", {
							type: "button",
							onClick: () => he(P?.uid === e ? null : {
								uid: e,
								sources: [],
								tiles: []
							}),
							className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${P?.uid === e ? "ring-3 ring-ink" : ""}`,
							children: ["🛒 ", c(O[t.emp].nameKey)]
						}), r && /* @__PURE__ */ b("button", {
							type: "button",
							onClick: () => {
								a(n.kind === "road" ? {
									type: "buyDrinks",
									uid: e,
									sources: P.sources
								} : {
									type: "buyDrinks",
									uid: e,
									tiles: P.tiles
								}), he(null);
							},
							className: "btn-base min-h-11 px-3 text-xs text-white",
							style: { background: z.accent },
							children: c("games.fcm.ui.confirm")
						})]
					}, e);
				})]
			})
		})), V.sub === "build" && V.nbdLeft > 0 && (X = /* @__PURE__ */ b($, {
			title: c("games.fcm.sub.build"),
			children: /* @__PURE__ */ x("div", {
				className: "flex flex-wrap gap-1.5",
				children: [
					/* @__PURE__ */ b("button", {
						type: "button",
						onClick: () => {
							be("house"), se(null);
						},
						className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${ye === "house" ? "ring-3 ring-ink" : ""}`,
						children: c("games.fcm.ui.placeHouse")
					}),
					/* @__PURE__ */ b("button", {
						type: "button",
						onClick: () => {
							be("garden"), k(null);
						},
						className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${ye === "garden" ? "ring-3 ring-ink" : ""}`,
						children: c("games.fcm.ui.placeGarden")
					}),
					ye === "house" && le.filter((t) => !e.houses.some((e) => e.num === t)).map((e) => /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => E && k({
							...E,
							num: e
						}),
						className: `card min-h-11 min-w-11 cursor-pointer font-mono text-sm font-black ${E?.num === e ? "ring-3 ring-ink" : ""}`,
						children: ["#", e]
					}, e))
				]
			})
		})), V.sub === "restaurant" && V.restaurantActions.length > 0) {
			let t = V.restaurantActions.some((e) => O[f.structure.find((t) => t.uid === e)?.emp ?? "local_manager"].placeRestaurant?.move);
			X = /* @__PURE__ */ b($, {
				title: c("games.fcm.sub.restaurant"),
				children: /* @__PURE__ */ x("div", {
					className: "flex flex-wrap gap-1.5",
					children: [/* @__PURE__ */ b("button", {
						type: "button",
						onClick: () => ve(null),
						className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${ge === null ? "ring-3 ring-ink" : ""}`,
						children: c("games.fcm.ui.placeRestaurant")
					}), t && e.restaurants.map((e, t) => e.owner === d ? /* @__PURE__ */ x("button", {
						type: "button",
						onClick: () => ve(t),
						className: `card min-h-11 cursor-pointer px-2 py-1 text-xs font-bold ${ge === t ? "ring-3 ring-ink" : ""}`,
						children: [
							c("games.fcm.ui.moveRestaurant"),
							" #",
							t + 1
						]
					}, t) : null)]
				})
			});
		}
	}
	if (e.phase === "payday" && Fe && f) {
		let t = xe, n = e.salaryDue[r] ?? 0, i = f.milestones.includes("first_billboard"), o = (e) => !!O[e].salary && !(i && O[e].marketer), s = new Set(f.busy.map((e) => e.uid)), l = f.structure.filter((e) => !s.has(e.uid)), u = l.concat(f.beach, f.busy).filter((e) => t.has(e.uid) && o(e.emp)).length, d = Math.max(0, n - 5 * u), p = f.cash < Math.max(0, n - 5 * l.concat(f.beach).filter((e) => o(e.emp)).length), m = (e) => {
			let n = new Set(t);
			n.has(e) ? n.delete(e) : n.add(e), Ce(n);
		}, h = [
			...l.map((e) => ({
				...e,
				zone: "s"
			})),
			...f.beach.map((e) => ({
				...e,
				zone: "b"
			})),
			...f.busy.map((e) => ({
				...e,
				zone: "m"
			}))
		];
		X = /* @__PURE__ */ x($, {
			title: `${c("games.fcm.phase.payday")} · ${c("games.fcm.ui.salary", { n: d })}`,
			children: [
				/* @__PURE__ */ b("p", {
					className: "text-[10px] opacity-70",
					children: f.cash < d ? c("games.fcm.ui.mustFire") : c("games.fcm.ui.paydayHint")
				}),
				/* @__PURE__ */ b("div", {
					className: "flex flex-wrap gap-1.5",
					children: h.filter((e) => o(e.emp)).map((e) => /* @__PURE__ */ b(Ot, {
						emp: e.emp,
						active: t.has(e.uid),
						disabled: e.zone === "m" && !p && !t.has(e.uid),
						onClick: () => m(e.uid),
						t: c,
						busy: e.zone === "m"
					}, e.uid))
				}),
				/* @__PURE__ */ b("button", {
					type: "button",
					disabled: f.cash < d,
					onClick: () => a({
						type: "paydaySubmit",
						fire: [...t]
					}),
					className: "btn-base min-h-12 w-full text-sm text-white",
					style: { background: z.accent },
					children: c("games.fcm.ui.confirm")
				})
			]
		});
	}
	if (e.phase === "cleanup" && Fe && f) {
		let e = Math.max(0, 10 - f.freezer.length), t = [];
		for (let e of T) for (let n = 0; n < (f.stock[e] ?? 0); n++) t.push(e);
		let n = we ?? t.slice(0, e), r = (r) => {
			let i = t[r], a = [...n], o = a.indexOf(i), s = a.filter((e) => e === i).length, c = t.filter((e) => e === i).length;
			o >= 0 && s >= c || (o >= 0 && s > 0 && s === a.filter((e) => e === i).length ? a.splice(o, 1) : a.length < e && a.push(i), Te(a));
		};
		X = /* @__PURE__ */ x($, {
			title: c("games.fcm.ui.freezerKeep", { n: e }),
			children: [/* @__PURE__ */ b("div", {
				className: "flex flex-wrap gap-1.5",
				children: t.map((e, i) => {
					let a = n.slice(0, n.length).filter((t) => t === e).length > t.slice(0, i).filter((t) => t === e).length;
					return /* @__PURE__ */ b("button", {
						type: "button",
						"aria-label": c(`games.fcm.good.${e}`),
						onClick: () => r(i),
						className: `card grid size-11 cursor-pointer place-items-center text-lg ${a ? "ring-3 ring-ink" : "opacity-40"}`,
						children: Z[e]
					}, i);
				})
			}), /* @__PURE__ */ b("button", {
				type: "button",
				disabled: n.length > e,
				onClick: () => a({
					type: "freezerKeep",
					keep: n
				}),
				className: "btn-base min-h-12 w-full text-sm text-white",
				style: { background: z.accent },
				children: c("games.fcm.ui.confirm")
			})]
		});
	}
	let Je = C ? `${c("games.fcm.ui.selectedSite")} ${C.x + 1}–${C.y + 1} · ${c(`games.fcm.direction.${C.dir}`)}` : E ? `#${E.num} · ${E.x + 1}–${E.y + 1}` : W?.size ? c("games.fcm.ui.legalSites", { n: W.size }) : f ? `${c("games.fcm.ui.cash", { n: f.cash })} · ${T.filter((e) => (f.stock[e] ?? 0) > 0).map((e) => `${Z[e]}×${f.stock[e]}`).join("  ")}` : J;
	return /* @__PURE__ */ b("div", {
		className: "fcm-game",
		children: /* @__PURE__ */ b(ee, {
			adaptive: !0,
			scroll: !1,
			banner: /* @__PURE__ */ x(te, { children: [/* @__PURE__ */ x("header", {
				className: "fcm-top",
				children: [/* @__PURE__ */ x("div", {
					className: "fcm-marquee",
					children: [
						/* @__PURE__ */ b("span", {
							"aria-hidden": !0,
							children: "✦"
						}),
						/* @__PURE__ */ b("strong", { children: c("games.fcm.name") }),
						/* @__PURE__ */ b("span", {
							className: "fcm-round",
							children: c("games.fcm.ui.round", { n: e.round })
						})
					]
				}), /* @__PURE__ */ b(_, {
					tone: We,
					text: J,
					chip: `🏦 $${e.bank}${e.bankBroken ? ` ×${e.bankBroken}` : ""}`,
					accent: z.accent
				})]
			}), /* @__PURE__ */ b("div", {
				className: "fcm-players",
				children: /* @__PURE__ */ b(v, {
					members: n.filter((t) => e.players.some((e) => e.rid === t.rid)),
					myRid: r,
					variant: "plate",
					anchorOf: (e) => `seat:${e}`,
					action: (t) => e.active === t || e.waiting.includes(t) && e.phase !== "done" ? "pending" : null,
					status: (t) => {
						let n = e.players.find((e) => e.rid === t);
						return n ? /* @__PURE__ */ x(te, { children: [
							/* @__PURE__ */ x("span", {
								className: "fcm-stat",
								children: ["💵", /* @__PURE__ */ b("span", {
									className: "font-mono tabular-nums",
									children: n.cash
								})]
							}),
							/* @__PURE__ */ x("span", {
								className: "fcm-stat",
								children: ["🏷️", /* @__PURE__ */ x("span", {
									className: "font-mono tabular-nums",
									children: ["$", n.unitPrice]
								})]
							}),
							n.waitressCount > 0 && /* @__PURE__ */ x("span", {
								className: "fcm-stat",
								children: ["💁×", n.waitressCount]
							})
						] }) : null;
					}
				})
			})] }),
			children: /* @__PURE__ */ x("div", {
				className: "fcm-table",
				children: [/* @__PURE__ */ x("main", {
					className: "fcm-stage",
					children: [
						/* @__PURE__ */ x("div", {
							className: "fcm-map-head",
							children: [/* @__PURE__ */ x("span", { children: ["★ ", c("games.fcm.ui.district")] }), /* @__PURE__ */ x("button", {
								type: "button",
								onClick: () => je((e) => !e),
								"aria-expanded": Ae,
								children: [
									Ae ? "×" : "▤",
									" ",
									c("games.fcm.ui.archive")
								]
							})]
						}),
						/* @__PURE__ */ x("div", {
							className: "fcm-board-frame",
							children: [
								/* @__PURE__ */ b(bt, {
									board: u,
									pub: e,
									colorOfOwner: ne,
									hotspots: W,
									ghostCells: G,
									restaurantGhost: C,
									highlightCells: K,
									fitKey: String(Oe),
									onTapCell: q,
									onTapHouse: He
								}),
								/* @__PURE__ */ x("span", {
									className: "fcm-board-overprint",
									children: [
										"✦ ",
										c("games.fcm.ui.cityAtlas"),
										/* @__PURE__ */ x("b", { children: ["NO. ", String(e.round).padStart(2, "0")] })
									]
								}),
								/* @__PURE__ */ x("span", {
									ref: p,
									className: "fcm-bank",
									children: [
										"🏦 $",
										e.bank,
										e.bankBroken > 0 && /* @__PURE__ */ x("span", { children: [" ×", e.bankBroken] })
									]
								}),
								/* @__PURE__ */ b("span", {
									className: "fcm-board-map-hint",
									children: c("games.fcm.ui.mapHint")
								}),
								/* @__PURE__ */ b("button", {
									type: "button",
									"aria-label": c("games.fcm.ui.recenter"),
									onClick: () => ke((e) => e + 1),
									className: "fcm-recenter",
									children: /* @__PURE__ */ b(m, {
										size: 20,
										"aria-hidden": !0
									})
								}),
								e.phase === "dinnertime" && e.dinner && /* @__PURE__ */ b("div", {
									className: "fcm-dinner-log",
									"aria-live": "polite",
									children: e.dinner.log.slice(-3).map((t, n) => {
										let r = e.houses.find((e) => e.id === t.houseId);
										return /* @__PURE__ */ x("p", { children: [
											"#",
											r?.num ?? "?",
											" ",
											t.winner ? c("games.fcm.ui.dinnerSale", {
												name: y(t.winner),
												n: t.revenue
											}) : c("games.fcm.ui.dinnerNone")
										] }, `${t.houseId}-${n}`);
									})
								})
							]
						}),
						/* @__PURE__ */ x("div", {
							className: "fcm-map-caption",
							children: [/* @__PURE__ */ x("span", { children: ["▸ ", Je] }), /* @__PURE__ */ b("span", {
								"aria-hidden": !0,
								children: "● ◌"
							})]
						}),
						Ae && /* @__PURE__ */ x("section", {
							className: "fcm-archive",
							"aria-label": c("games.fcm.ui.archive"),
							children: [
								/* @__PURE__ */ x("div", {
									className: "fcm-archive-head",
									children: [/* @__PURE__ */ b("strong", { children: c("games.fcm.ui.archive") }), /* @__PURE__ */ b("button", {
										type: "button",
										onClick: () => je(!1),
										"aria-label": c("games.fcm.ui.close"),
										children: "×"
									})]
								}),
								f && /* @__PURE__ */ x("div", {
									className: "fcm-archive-group",
									children: [
										/* @__PURE__ */ b("h3", { children: c("games.fcm.ui.companyDesk") }),
										/* @__PURE__ */ x("p", {
											className: "fcm-archive-stats",
											children: [
												"💵 $",
												f.cash,
												" · 🏷️ $",
												f.unitPrice,
												" · 🧊 ",
												f.freezer.length,
												t.myReserve ? ` · 🂠 $${t.myReserve}` : ""
											]
										}),
										/* @__PURE__ */ x("div", {
											className: "fcm-archive-chips",
											children: [
												f.structure.map((e) => /* @__PURE__ */ b("span", { children: c(O[e.emp].nameKey) }, e.uid)),
												f.busy.map((e) => /* @__PURE__ */ x("span", { children: ["📣 ", c(O[e.emp].nameKey)] }, e.uid)),
												f.beach.map((e) => /* @__PURE__ */ x("span", { children: ["◌ ", c(O[e.emp].nameKey)] }, e.uid)),
												T.filter((e) => (f.stock[e] ?? 0) > 0).map((e) => /* @__PURE__ */ x("span", { children: [
													Z[e],
													" ×",
													f.stock[e]
												] }, e))
											]
										})
									]
								}),
								/* @__PURE__ */ x("div", {
									className: "fcm-archive-group",
									children: [/* @__PURE__ */ b("h3", { children: c("games.fcm.ui.milestones") }), /* @__PURE__ */ b("div", {
										className: "fcm-archive-chips",
										children: oe.map((t) => {
											let n = e.milestoneState[t.id], i = (n?.claimedBy.length ?? 0) > 0;
											return /* @__PURE__ */ x("span", {
												title: c(t.descKey),
												className: i ? "is-claimed" : "is-locked",
												children: [
													i ? "★" : "◇",
													" ",
													c(t.nameKey),
													n?.claimedBy.includes(r) ? " ✓" : ""
												]
											}, t.id);
										})
									})]
								})
							]
						})
					]
				}), /* @__PURE__ */ x("aside", {
					className: "fcm-desk safe-b",
					children: [
						/* @__PURE__ */ x("div", {
							className: "fcm-desk-label",
							children: [/* @__PURE__ */ x("span", { children: ["◆ ", c("games.fcm.ui.companyDesk")] }), /* @__PURE__ */ b("span", { children: J })]
						}),
						/* @__PURE__ */ x("div", {
							className: "fcm-desk-scroll",
							children: [
								/* @__PURE__ */ x("div", {
									className: "fcm-desk-card",
									children: [
										/* @__PURE__ */ b("img", {
											src: "/games/fcm/art/sample-employee.webp",
											alt: ""
										}),
										/* @__PURE__ */ x("div", { children: [
											/* @__PURE__ */ b("small", { children: c("games.fcm.ui.currentAction") }),
											/* @__PURE__ */ b("strong", { children: J }),
											/* @__PURE__ */ b("span", { children: Je })
										] }),
										/* @__PURE__ */ b("b", { children: String(e.round).padStart(2, "0") })
									]
								}),
								X,
								f && /* @__PURE__ */ x("section", {
									className: "fcm-company",
									children: [[
										{
											label: "games.fcm.ui.yourStructure",
											cards: f.structure.filter((e) => !f.busy.some((t) => t.uid === e.uid))
										},
										{
											label: "games.fcm.ui.beach",
											cards: f.beach
										},
										{
											label: "games.fcm.ui.busy",
											cards: f.busy
										}
									].filter((e) => e.cards.length > 0).map((e) => /* @__PURE__ */ x("div", {
										className: "fcm-company-group",
										children: [/* @__PURE__ */ b("h3", { children: c(e.label) }), /* @__PURE__ */ b("div", {
											className: "fcm-roster",
											children: e.cards.map((e) => /* @__PURE__ */ x("span", {
												className: "fcm-roster-card",
												children: [/* @__PURE__ */ b("span", {
													className: "fcm-job-mark",
													"aria-hidden": !0,
													children: Et(e.emp)
												}), /* @__PURE__ */ b("span", { children: c(O[e.emp].nameKey) })]
											}, e.uid))
										})]
									}, e.label)), T.some((e) => (f.stock[e] ?? 0) > 0) && /* @__PURE__ */ x("div", {
										className: "fcm-company-group",
										children: [/* @__PURE__ */ b("h3", { children: c("games.fcm.ui.stock") }), /* @__PURE__ */ b("div", {
											className: "fcm-stock",
											children: T.filter((e) => (f.stock[e] ?? 0) > 0).map((e) => /* @__PURE__ */ x("span", { children: [
												Z[e],
												" ",
												/* @__PURE__ */ x("b", {
													className: "font-mono tabular-nums",
													children: ["×", f.stock[e]]
												})
											] }, e))
										})]
									})]
								})
							]
						}),
						/* @__PURE__ */ b("div", {
							className: "fcm-actions",
							children: qe
						})
					]
				})]
			})
		})
	});
}
function $({ title: e, children: t }) {
	return /* @__PURE__ */ x("div", {
		className: "fcm-sheet",
		children: [/* @__PURE__ */ x("p", {
			className: "fcm-sheet-title",
			children: ["◆ ", e]
		}), t]
	});
}
function Ot({ emp: e, active: t, disabled: n, busy: r, onClick: i, t: a }) {
	let o = O[e], s = [];
	return o.slots && s.push(`▣${o.slots}`), o.recruit && s.push(`👤+${o.recruit}`), o.train && s.push(`🎓${o.train}`), o.produce && s.push("choice" in o.produce ? `${Z[o.produce.choice[0]]}/${Z[o.produce.choice[1]]}×${o.produce.n}` : `${Z[o.produce.good]}×${o.produce.n}`), o.buyer && s.push("🛒"), o.marketer && s.push("📣"), o.priceMod && s.push(o.priceMod < 0 ? `💲${o.priceMod}` : `💲+${o.priceMod}`), o.cfo && s.push("💰½"), o.placeHouse && s.push("🏠"), o.placeRestaurant && s.push("🍔+"), o.salary && s.push("💵5"), /* @__PURE__ */ x("button", {
		type: "button",
		disabled: n,
		onClick: i,
		className: `card fcm-emp-chip min-h-11 min-w-16 cursor-pointer px-1.5 py-1 text-left ${t ? "ring-3 ring-ink" : ""} ${n ? "opacity-40" : ""} ${r ? "border-dashed" : ""}`,
		children: [/* @__PURE__ */ b("span", {
			className: "fcm-job-mark",
			"aria-hidden": !0,
			children: Et(e)
		}), /* @__PURE__ */ x("span", {
			className: "fcm-emp-copy",
			children: [/* @__PURE__ */ b("span", { children: a(o.nameKey) }), s.length > 0 && /* @__PURE__ */ b("small", { children: s.join(" ") })]
		})]
	});
}
//#endregion
//#region src/games/fcm/bot.ts
var kt = {
	N: [0, -1],
	E: [1, 0],
	S: [0, 1],
	W: [-1, 0]
};
function At(e) {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e;
}
var jt = (e, t) => e.players.findIndex((e) => e.rid === t);
function Mt(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e.houses) {
		for (let [e, r] of n.cells) t.add(N(e, r));
		for (let [e, r] of n.garden ?? []) t.add(N(e, r));
	}
	for (let n of e.restaurants) t.add(N(n.x, n.y));
	for (let n of e.campaigns) n.placement.kind === "cell" && t.add(N(n.placement.x, n.placement.y));
	let n = e.board;
	for (let e of _e(n)) t.add(N(e.x, e.y));
	return t;
}
function Nt(e, t) {
	let n = e.board, r = e.players[t].structure.some((e) => O[e.emp].placeRestaurant), i = [];
	for (let a of e.restaurants) if (!(a.owner !== t || a.comingSoon)) {
		if (r) for (let e of [
			"N",
			"E",
			"S",
			"W"
		]) {
			let [t, r] = kt[e];
			L(n, a.x + t, a.y + r) && i.push([a.x + t, a.y + r]);
		}
		else {
			let [e, t] = kt[a.dir];
			L(n, a.x + e, a.y + t) && i.push([a.x + e, a.y + t]);
		}
	}
	return i;
}
function Pt(e, t, n, r, i) {
	let a = e.board, o = Mt(e), s = n === Infinity ? null : R(a, Nt(e, t), n), c = F(a), l = I(a), u = null;
	for (let t = 0; t < l; t++) for (let n = 0; n < c; n++) {
		if (L(a, n, t) || o.has(N(n, t)) || i && !i(n, t) || !Object.values(kt).map(([e, r]) => [n + e, t + r]).some(([e, t]) => s ? s.has(N(e, t)) : L(a, e, t))) continue;
		let c = 0;
		if (r) for (let r of e.houses) [...r.cells, ...r.garden ?? []].some(([e, r]) => Math.abs(e - n) + Math.abs(r - t) === 1) && c++;
		(!u || c > u.score) && (u = {
			x: n,
			y: t,
			score: c
		});
	}
	return u;
}
function Ft(e) {
	return O[e].trainsTo ?? [];
}
function It(e, t) {
	let n = e.players[t], r = n.ceoSlots, i = [], a = [], o = (e) => {
		let t = O[e];
		return t.slots ? "mgr" : t.recruit ? "rec" : t.train ? "trn" : t.marketer ? "mkt" : t.produce ? "prod" : t.buyer ? "buy" : "misc";
	}, s = (e) => a.filter((t) => o(t) === e).length, c = (t) => {
		let n = O[t];
		switch (o(t)) {
			case "mgr": return 100 + (n.slots ?? 0) - 30 * Math.max(0, s("mgr") - 2);
			case "mkt": return s("mkt") === 0 ? d : 72;
			case "prod": return s("prod") === 0 ? f : 70;
			case "buy": return s("buy") === 0 ? p : 68;
			case "rec": return 82 - 12 * Math.max(0, s("rec") - 2);
			case "trn": return (e.intro ? 88 : 78) - 15 * Math.max(0, s("trn") - 1);
			default: return (n.priceMod ?? 0) < 0 ? 60 : n.cfo ? 58 : t === "waitress" ? 55 : 40;
		}
	}, l = (e) => {
		let t = [...a, e], n = t.filter((e) => O[e].slots), i = n.reduce((e, t) => e + (O[t].slots ?? 0), 0);
		return n.length <= r && t.length <= r + i;
	}, u = [...n.beach], d = e.intro ? 80 : 95, f = e.intro ? 96 : 93, p = e.intro ? 94 : 91;
	for (;;) {
		let e = -1, t = -Infinity;
		for (let n = 0; n < u.length; n++) {
			let r = c(u[n].emp);
			r > t && l(u[n].emp) && (t = r, e = n);
		}
		if (e < 0) break;
		i.push(u[e].uid), a.push(u[e].emp), u.splice(e, 1);
	}
	return i;
}
function Lt(e, t) {
	let n = e.players[t], r = [
		"burger",
		"pizza",
		"beer",
		"lemonade",
		"soda"
	], i = (e) => (n.stock[e] ?? 0) + n.freezer.filter((t) => t === e).length, a = r.filter((e) => i(e) >= 3).sort((e, t) => i(t) - i(e));
	if (a.length) return a[0];
	for (let e of n.structure) {
		let t = O[e.emp].produce;
		if (t && !("choice" in t)) return t.good;
	}
	let o = "lemonade", s = 0;
	for (let e of r) {
		let t = n.stock[e] ?? 0;
		t > s && (s = t, o = e);
	}
	return o;
}
function Rt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.houses) for (let e of n.demand) t.set(e, (t.get(e) ?? 0) + 1);
	return t;
}
function zt(e, t, n) {
	let r = t.placement.kind === "edge" ? Se(e, t.placement.edge, t.placement.index, de[t.num] ?? 1) : t.type === "billboard" ? Ce(e, t.placement.x, t.placement.y) : t.type === "mailbox" ? be(e, t.placement.x, t.placement.y) : xe(e, t.placement.x, t.placement.y);
	return !!r && [...n.cells, ...n.garden ?? []].some(([e, t]) => r.has(N(e, t)));
}
function Bt(e) {
	let t = {
		burger: 0,
		pizza: 0,
		beer: 0,
		lemonade: 0,
		soda: 0
	};
	for (let n of e.structure) {
		let e = O[n.emp];
		if (e.produce) {
			if ("choice" in e.produce) for (let n of e.produce.choice) t[n] = Math.max(t[n], e.produce.n ?? 1);
			else t[e.produce.good] += e.produce.n ?? 1;
		}
		if (e.buyer?.kind === "anyDrink") for (let e of [
			"beer",
			"lemonade",
			"soda"
		]) t[e] += 1;
		if (e.buyer?.kind === "road") for (let e of [
			"beer",
			"lemonade",
			"soda"
		]) t[e] = Math.max(t[e], 3);
	}
	return t;
}
function Vt(e, t) {
	let n = Rt(e), r = [
		"beer",
		"lemonade",
		"soda"
	].filter((e) => (n.get(e) ?? 0) > 0).sort((e, t) => (n.get(t) ?? 0) - (n.get(e) ?? 0));
	if (r.length) return r[0];
	for (let n of e.campaigns) if (n.owner === t && (n.good === "beer" || n.good === "lemonade" || n.good === "soda")) return n.good;
	return "soda";
}
var Ht = [
	"recruiting_girl",
	"trainer",
	"kitchen_trainee",
	"marketing_trainee",
	"errand_boy",
	"waitress",
	"pricing_manager",
	"management_trainee"
], Ut = [
	"recruiting_girl",
	"errand_boy",
	"trainer",
	"kitchen_trainee",
	"marketing_trainee",
	"waitress",
	"pricing_manager",
	"management_trainee"
], Wt = [
	"errand_boy",
	"kitchen_trainee",
	"marketing_trainee"
];
function Gt(e, t, n) {
	let r = e.public, i = r.working, a = r.players[t], o = r.board;
	if (i.sub === "recruit") {
		if (i.recruitsLeft > 0) {
			let e = n ? Wt : r.intro ? Ut : Ht;
			for (let t of e) if ((r.supply[t] ?? 0) > 0 && O[t].recruitable) return {
				type: "recruit",
				emp: t
			};
		}
		return { type: "nextSub" };
	}
	if (i.sub === "train") {
		if (!n) {
			let e = a.milestones.includes("first_20_salary"), t = Math.max(0, ...Object.values(i.trainSteps)), n = Object.values(i.trainSteps).reduce((e, t) => e + t, 0);
			for (let [o, s] of [
				["kitchen_trainee", "burger_cook"],
				["marketing_trainee", "campaign_manager"],
				["management_trainee", "junior_vp"],
				["errand_boy", "cart_operator"],
				["trainer", "coach"],
				["recruiting_girl", "recruiting_manager"],
				["burger_cook", "burger_chef"],
				["pizza_cook", "pizza_chef"]
			]) {
				let c = a.beach.find((e) => e.emp === o);
				if (!c || (r.supply[s] ?? 0) <= 0 || !Ft(o).includes(s) || O[s].topPosition && [
					...a.beach,
					...a.structure,
					...a.busy
				].some((e) => e.emp === s)) continue;
				let l = i.trainedBy[c.uid];
				if (!((e ? n : l ? i.trainSteps[l] ?? 0 : t) < 1)) return {
					type: "train",
					uid: c.uid,
					to: s
				};
			}
		}
		return { type: "nextSub" };
	}
	if (i.sub === "market") {
		let e = i.marketeersLeft[0];
		if (e === void 0) return { type: "nextSub" };
		let s = a.structure.find((t) => t.uid === e);
		if (!s) return { type: "nextSub" };
		let c = O[s.emp].marketer, l = a.milestones.includes("first_throw"), u = Bt(a), d = (e) => (a.stock[e] ?? 0) + a.freezer.filter((t) => t === e).length, f = (e, t) => t.length > 0 && (l || t.some((t) => t.demand.length + r.campaigns.filter((e) => zt(o, e, t)).length + 1 <= d(e) + u[e])), p = [...r.marketingPool].map((e) => ue.find((t) => t.num === e)).filter((e) => D[e.type] <= D[c.maxType]).sort((e, t) => D[t.type] - D[e.type] || e.num - t.num), m = [
			"burger",
			"pizza",
			"beer",
			"lemonade",
			"soda"
		], h = () => m.sort((e, t) => d(t) + u[t] - (d(e) + u[e]))[0], g = l ? c.maxDuration : 1, _ = n && l ? [
			"lemonade",
			"soda",
			"beer"
		][At(3)] : l ? Lt(r, t) : h();
		for (let i of p) {
			if (i.type === "airplane") {
				let t = de[i.num] ?? 1, n = F(o), a = I(o), s = Math.floor(t / 2), c = null, l = (e, t) => {
					let i = /* @__PURE__ */ new Set();
					if (e === "N" || e === "S") for (let e = t - s; e <= t + s; e++) for (let t = 0; t < a; t++) i.add(N(e, t));
					else for (let e = t - s; e <= t + s; e++) for (let t = 0; t < n; t++) i.add(N(t, e));
					let o = r.houses.filter((e) => e.cells.some(([e, t]) => i.has(N(e, t)))).length;
					(!c || o > c.score) && (c = {
						edge: e,
						index: t,
						score: o
					});
				};
				for (let e = s; e < n - s; e++) l("N", e);
				for (let e = s; e < a - s; e++) l("E", e);
				if (c && c.score > 0) {
					let t = c;
					return {
						type: "marketing",
						uid: e,
						tile: i.num,
						placement: {
							kind: "edge",
							edge: t.edge,
							index: t.index
						},
						good: _,
						duration: g
					};
				}
				continue;
			}
			let a = (e, t) => {
				let n = i.type === "billboard" ? Ce(o, e, t) : i.type === "mailbox" ? be(o, e, t) : xe(o, e, t);
				return r.houses.filter((e) => [...e.cells, ...e.garden ?? []].some(([e, t]) => n.has(N(e, t))));
			}, s = Pt(r, t, c.range, !n, l ? void 0 : (e, t) => f(_, a(e, t)));
			if (s && f(_, a(s.x, s.y))) return {
				type: "marketing",
				uid: e,
				tile: i.num,
				placement: {
					kind: "cell",
					x: s.x,
					y: s.y
				},
				good: _,
				duration: g
			};
		}
		return { type: "nextSub" };
	}
	if (i.sub === "produce") {
		let e = i.producersLeft[0];
		if (e !== void 0) {
			let t = a.structure.find((t) => t.uid === e), n = t ? O[t.emp].produce : void 0;
			if (n && "choice" in n) {
				let t = Rt(r);
				return {
					type: "produce",
					uid: e,
					good: [...n.choice].sort((e, n) => (t.get(n) ?? 0) - (t.get(e) ?? 0))[0] ?? n.choice[0]
				};
			}
			return {
				type: "produce",
				uid: e
			};
		}
		let n = i.buyersLeft[0];
		if (n !== void 0) {
			let e = a.structure.find((e) => e.uid === n), i = e ? O[e.emp].buyer : void 0;
			if (!i) return { type: "nextSub" };
			if (i.kind === "anyDrink") return {
				type: "buyDrinks",
				uid: n,
				good: Vt(r, t)
			};
			if (i.kind === "road") {
				let e = R(o, Nt(r, t), i.range), a = _e(o).filter((t) => Object.values(kt).some(([n, r]) => e.has(N(t.x + n, t.y + r)))).slice(0, 4).map((e) => [e.x, e.y]);
				return a.length ? {
					type: "buyDrinks",
					uid: n,
					sources: a
				} : { type: "nextSub" };
			}
			let s = r.restaurants.find((e) => e.owner === t && !e.comingSoon);
			if (!s) return { type: "nextSub" };
			let c = [Math.floor(s.x / 5), Math.floor(s.y / 5)], l = (e, t) => e >= 0 && t >= 0 && e < o.tw && t < o.th && _e(o).some((n) => Math.floor(n.x / 5) === e && Math.floor(n.y / 5) === t), u = [c], d = /* @__PURE__ */ new Set([`${c[0]},${c[1]}`]);
			for (; u.length < i.range + 1;) {
				let [e, t] = u[u.length - 1], n = [
					[1, 0],
					[-1, 0],
					[0, 1],
					[0, -1]
				].map(([n, r]) => [e + n, t + r]).find(([e, t]) => !d.has(`${e},${t}`) && l(e, t));
				if (!n) break;
				d.add(`${n[0]},${n[1]}`), u.push(n);
			}
			return u.some(([e, t]) => l(e, t)) ? {
				type: "buyDrinks",
				uid: n,
				tiles: u
			} : { type: "nextSub" };
		}
		return { type: "nextSub" };
	}
	if (i.sub === "build") {
		if (!n && i.nbdLeft > 0) {
			let e = le.find((e) => !r.houses.some((t) => t.num === e)), n = e === void 0 ? null : Pt(r, t, Infinity, !1);
			if (e !== void 0 && n && ye(o, [[n.x, n.y]]).length) {
				let t = Mt(r);
				for (let r of [
					0,
					3,
					2,
					1
				]) {
					let [i, a] = [
						[0, 1],
						[-1, 0],
						[0, -1],
						[1, 0]
					][r], s = n.x + i, c = n.y + a;
					if (!(s < 0 || c < 0 || s >= F(o) || c >= I(o)) && !(L(o, s, c) || t.has(N(s, c)))) return {
						type: "placeHouse",
						num: e,
						x: n.x,
						y: n.y,
						rot: r
					};
				}
			}
		}
		return { type: "nextSub" };
	}
	if (i.restaurantActions.length) {
		let e = r.restaurants.filter((e) => e.owner === t).length;
		if (!n && e < 3) {
			let e = Pt(r, t, i.restaurantActions.some((e) => {
				let t = a.structure.find((t) => t.uid === e);
				return t ? !!O[t.emp].placeRestaurant?.immediate : !1;
			}) ? Infinity : 3, !1);
			if (e) for (let t of [
				"N",
				"E",
				"S",
				"W"
			]) {
				let [n, r] = kt[t];
				if (L(o, e.x + n, e.y + r)) return {
					type: "placeRestaurant",
					x: e.x,
					y: e.y,
					dir: t
				};
			}
		}
	}
	return { type: "finishWorking" };
}
var Kt = (e, t) => {
	let n = e.public, r = jt(n, t.rid);
	if (r < 0) return null;
	let i = t.difficulty === "weak", a = n.players[r], o = n.board;
	switch (n.phase) {
		case "setupRestaurants": {
			if (n.active !== t.rid) return null;
			let e = Mt(n), r = null;
			for (let t = 0; t < I(o); t++) for (let a = 0; a < F(o); a++) if (!(L(o, a, t) || e.has(N(a, t)))) for (let e of [
				"N",
				"E",
				"S",
				"W"
			]) {
				let [s, c] = kt[e];
				if (!L(o, a + s, t + c)) continue;
				let l = Math.floor((a + s) / 5), u = Math.floor((t + c) / 5);
				if (n.restaurants.some((e) => Math.floor((e.x + kt[e.dir][0]) / 5) === l && Math.floor((e.y + kt[e.dir][1]) / 5) === u)) continue;
				let d = 0;
				for (let e of n.restaurants) d += Math.abs(e.x - a) + Math.abs(e.y - t);
				i && (d = At(50)), (!r || d > r.score) && (r = {
					x: a,
					y: t,
					dir: e,
					score: d
				});
			}
			return r ? { action: {
				type: "placeFirstRestaurant",
				x: r.x,
				y: r.y,
				dir: r.dir
			} } : { action: { type: "passFirstRestaurant" } };
		}
		case "setupReserve": return n.waiting.includes(t.rid) ? { action: {
			type: "chooseReserve",
			value: i ? [
				100,
				200,
				300
			][At(3)] : 200
		} } : null;
		case "restructuring": return n.waiting.includes(t.rid) ? { action: {
			type: "submitStructure",
			cards: It(n, r)
		} } : null;
		case "orderDraft": {
			if (n.orderDraft?.chooser !== t.rid) return null;
			let e = n.players.length, r = (i ? [...Array(e).keys()].reverse() : [...Array(e).keys()]).find((e) => !n.orderDraft.taken[String(e)]);
			return r === void 0 ? null : { action: {
				type: "chooseOrder",
				position: r
			} };
		}
		case "working": return n.active !== t.rid || !n.working ? null : { action: Gt(e, r, i) };
		case "payday": {
			if (!n.waiting.includes(t.rid)) return null;
			let e = n.salaryDue[t.rid] ?? 0;
			if (a.cash >= e) return { action: {
				type: "paydaySubmit",
				fire: []
			} };
			let r = a.milestones.includes("first_billboard"), i = (e) => !!O[e].salary && !(r && O[e].marketer), o = (e) => {
				let t = O[e];
				return t.slots ? 100 : t.recruit || t.train ? 80 : t.produce || t.marketer ? 60 : t.buyer ? 55 : 30;
			}, s = new Set(a.busy.map((e) => e.uid)), c = [...a.beach, ...a.structure].filter((e) => !s.has(e.uid) && i(e.emp)).sort((e, t) => o(e.emp) - o(t.emp)), l = Math.max(0, e - 5 * c.length), u = a.cash < l, d = [], f = e;
			for (let e of c) {
				if (!u && a.cash >= f) break;
				d.push(e.uid), f -= 5;
			}
			if (u) for (let e of a.busy) {
				if (a.cash >= f) break;
				i(e.emp) && (d.push(e.uid), f -= 5);
			}
			return { action: {
				type: "paydaySubmit",
				fire: d
			} };
		}
		case "cleanup": {
			if (!n.waiting.includes(t.rid)) return null;
			let e = 10 - a.freezer.length, r = Rt(n), i = [];
			for (let e of [
				"burger",
				"pizza",
				"beer",
				"lemonade",
				"soda"
			]) for (let t = 0; t < (a.stock[e] ?? 0); t++) i.push(e);
			return i.sort((e, t) => (r.get(t) ?? 0) - (r.get(e) ?? 0)), { action: {
				type: "freezerKeep",
				keep: i.slice(0, Math.max(0, e))
			} };
		}
		default: return null;
	}
}, qt = {
	billboard: "games.fcm.ct.billboard",
	mailbox: "games.fcm.ct.mailbox",
	airplane: "games.fcm.ct.airplane",
	radio: "games.fcm.ct.radio"
}, Jt = (e, t, n) => {
	let r = (e) => {
		for (let r of t.public.players) {
			let t = [
				...r.structure,
				...r.beach,
				...r.busy
			].find((t) => t.uid === e);
			if (t) return n(O[t.emp].nameKey);
		}
		return e;
	};
	switch (e.type) {
		case "placeFirstRestaurant":
		case "placeRestaurant": return n("games.fcm.act.restaurant");
		case "moveRestaurant": return n("games.fcm.act.move");
		case "passFirstRestaurant": return n("games.fcm.act.pass");
		case "chooseReserve": return n("games.fcm.act.reserve", { n: e.value });
		case "submitStructure": return n("games.fcm.act.structure", { n: e.cards.length });
		case "chooseOrder": return n("games.fcm.act.order", { n: e.position + 1 });
		case "recruit": return n("games.fcm.act.recruit", { name: n(O[e.emp].nameKey) });
		case "train": return n("games.fcm.act.train", {
			from: r(e.uid),
			to: n(O[e.to].nameKey)
		});
		case "marketing": {
			let t = ue.find((t) => t.num === e.tile);
			return n("games.fcm.act.marketing", {
				type: t ? n(qt[t.type]) : `#${e.tile}`,
				good: n(`games.fcm.good.${e.good}`),
				n: e.duration
			});
		}
		case "produce": return n("games.fcm.act.produce", { name: r(e.uid) });
		case "buyDrinks": return n("games.fcm.act.buy");
		case "placeHouse": return n("games.fcm.act.house");
		case "placeGarden": return n("games.fcm.act.garden");
		case "finishWorking": return n("games.fcm.act.finish");
		case "nextSub": return n("games.fcm.act.next");
		case "paydaySubmit": return n("games.fcm.act.payday", { n: e.fire.length });
		case "freezerKeep": return n("games.fcm.act.freezer");
		case "tick": return "";
	}
}, Yt = {
	milestone(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ b(S, {
				at: n,
				ms: 900,
				children: /* @__PURE__ */ b("span", {
					className: "font-black text-done-ink",
					children: "🏆"
				})
			})
		} : null;
	},
	bankBreak(e, t) {
		let n = t.anchor("bank");
		return n ? {
			ms: 900,
			node: /* @__PURE__ */ b(ne, {
				at: n,
				ms: 800
			})
		} : null;
	},
	sale(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.amount != "number" ? null : {
			ms: 900,
			node: /* @__PURE__ */ b(S, {
				at: r,
				ms: 900,
				children: /* @__PURE__ */ x("span", {
					className: "font-mono font-black text-done-ink",
					children: ["+$", n.amount]
				})
			})
		};
	},
	campaign(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ b(S, {
				at: n,
				ms: 700,
				children: /* @__PURE__ */ b("span", { children: "📣" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/fcm/endgame-review.tsx
function Xt({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, d] = o(!0), [m, h] = o(null), g = a(null), _ = a(null), v = a(null);
	r(() => {
		if (!m) return;
		v.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => h(null), 5e3);
		return () => clearTimeout(e);
	}, [m]);
	let y = (e) => {
		h(null), d(e), requestAnimationFrame(() => (e ? g : _).current?.focus({ preventScroll: !0 }));
	}, ee = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => h({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => h({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => h({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), te = {
		...n,
		...ee
	};
	return /* @__PURE__ */ x("div", {
		className: "fcm-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ b("div", {
				className: "fcm-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ b("div", {
				className: "fcm-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ x("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), y(!1));
					},
					className: "fcm-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ x("header", {
							className: "fcm-endgame-heading",
							children: [/* @__PURE__ */ x("div", {
								className: "fcm-endgame-brand",
								children: [/* @__PURE__ */ b("span", {
									"aria-hidden": "true",
									children: z.icon
								}), s(z.nameKey)]
							}), /* @__PURE__ */ b("button", {
								type: "button",
								ref: g,
								className: "btn-quiet",
								"aria-label": s("games.fcm.reviewHide"),
								title: s("games.fcm.reviewHide"),
								onClick: () => y(!1),
								children: /* @__PURE__ */ b(f, { size: 19 })
							})]
						}),
						/* @__PURE__ */ b("div", {
							className: "fcm-endgame-result",
							inert: m !== null,
							children: t(te)
						}),
						m && /* @__PURE__ */ x("div", {
							className: "fcm-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || h(null);
							},
							children: [/* @__PURE__ */ b("button", {
								type: "button",
								ref: v,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = m.run;
									h(null), e();
								},
								children: s(m.label === "again" ? "games.fcm.reviewConfirmAgain" : "games.fcm.reviewConfirmLobby")
							}), /* @__PURE__ */ b("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									h(null), g.current?.focus({ preventScroll: !0 });
								},
								children: s("games.fcm.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ b("div", {
				className: "fcm-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ x("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => y(!0),
					children: [
						/* @__PURE__ */ b(p, { size: 18 }),
						s("games.fcm.reviewShow"),
						/* @__PURE__ */ b(u, { size: 18 })
					]
				})
			})
		]
	});
}
function Zt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: p, summary: m, navigation: h, content: g, afterRanking: _, scoreUnit: v, rankOf: ee }) {
	let S = l(), ne = c((e) => e.locale), [w, T] = o({}), re = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? y(n, ne) : e;
	}, E = (t, n) => ee?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), D = e.ranking.some((t) => e.scores?.[t] !== void 0), O = (t, n) => /* @__PURE__ */ x("div", {
		className: "fcm-score-identity",
		children: [
			/* @__PURE__ */ x("span", {
				className: "fcm-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ b("span", {
					"aria-label": S("games.fcm.reviewWinner"),
					children: "♛ "
				}), D && E(t, n)]
			}),
			/* @__PURE__ */ x("span", {
				className: "fcm-score-name",
				children: [re(t), t === r && /* @__PURE__ */ b("small", { children: S("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ x("small", {
				className: "fcm-score-autopilot",
				children: [
					/* @__PURE__ */ b(d, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), ie = (t) => e.ranking.map((n) => /* @__PURE__ */ b("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ x("div", {
		className: "fcm-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ b(C, {}),
			h,
			/* @__PURE__ */ x("div", {
				className: "fcm-score-body",
				children: [
					m && /* @__PURE__ */ b("div", {
						className: "fcm-score-summary",
						children: m
					}),
					i !== void 0 && /* @__PURE__ */ b("p", {
						className: "fcm-score-hints",
						children: S("session.hint.usedCount", { n: i })
					}),
					g ?? (u?.length ? /* @__PURE__ */ b("div", {
						className: "fcm-score-table-scroll",
						children: /* @__PURE__ */ x("table", {
							className: "fcm-score-table",
							"aria-label": S(z.nameKey),
							children: [
								/* @__PURE__ */ b("thead", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", { scope: "col" }), /* @__PURE__ */ b(te, { children: e.ranking.map((t, n) => /* @__PURE__ */ b("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: O(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ b("tbody", { children: u.map((e, t) => /* @__PURE__ */ x(n, { children: [/* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ x("button", {
										type: "button",
										"aria-expanded": !!w[t],
										onClick: () => T((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ b(f, { size: 15 }), e.label]
									}) : e.label
								}), ie(e)] }), w[t] && e.details?.map((e, t) => /* @__PURE__ */ x("tr", {
									className: "fcm-score-sub",
									children: [/* @__PURE__ */ b("th", {
										scope: "row",
										children: e.label
									}), ie(e)]
								}, t))] }, t)) }),
								D && /* @__PURE__ */ b("tfoot", { children: /* @__PURE__ */ x("tr", { children: [/* @__PURE__ */ b("th", {
									scope: "row",
									children: S("games.fcm.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ b("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ b("ol", {
						className: "fcm-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ x("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ x("div", {
								className: "fcm-score-rankline",
								children: [O(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ x("strong", {
									className: "fcm-score-points",
									children: [e.scores[t], v && /* @__PURE__ */ b("small", { children: v })]
								})]
							}), p?.(t)]
						}, t))
					})),
					_,
					!!u?.length && p && /* @__PURE__ */ b("div", {
						className: "fcm-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ x("details", { children: [/* @__PURE__ */ b("summary", { children: re(e) }), p(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ x("footer", {
				className: "fcm-score-actions",
				children: [
					s && /* @__PURE__ */ b("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: S("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ b("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: S("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ b("p", { children: S("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/fcm/game-over.tsx
function Qt(e) {
	return /* @__PURE__ */ b(Zt, {
		...e,
		accent: z.accent
	});
}
function $t(e) {
	return /* @__PURE__ */ b(Xt, {
		...e,
		board: /* @__PURE__ */ b(St, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ b(Qt, { ...e })
	});
}
//#endregion
//#region src/games/fcm/options.tsx
function en({ value: e, onChange: t }) {
	let n = l(), r = ke.safeParse(e), i = r.success ? r.data : ke.parse(void 0);
	return /* @__PURE__ */ b(w, {
		checked: i.intro,
		label: n("games.fcm.optIntro"),
		accent: z.accent,
		onChange: () => t({ intro: !i.intro })
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/fcm/entry.tsx
var tn = {
	definition: mt,
	View: St,
	bot: Kt,
	describe: Jt,
	fx: Yt,
	OverView: $t,
	Options: en,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "快餐连锁大亨",
			desc: "招聘员工、培训晋升、营销造势、开店抢客:最狠的快餐资本局",
			rules: "目标:银行第二次破产后的晚餐结束时,现金最多者胜。\n每回合 7 阶段:\n· 重组——把员工安排进组织架构,受 CEO 槽位限制,经理只管一层。\n· 定序——上岗卡少者先选回合顺序。\n· 工作——按顺序执行员工行动:招聘(CEO 免费 1 次)、培训(换高级卡)。\n· 工作还包括:营销(制造需求)、生产与采购(备货)、建房、开餐厅。\n· 晚餐——按房屋编号结算:能供全部需求且「单价+距离」最小的连锁店成交。\n· 晚餐平局先比女侍数量,再比回合顺序;花园房单价翻倍;CFO 收入增加 50%。\n· 发薪——每张带工资图标的卡付 $5,可先解雇。\n· 营销——进行中的营销按板号升序给覆盖房屋加需求。\n· 清理——未售食饮丢弃,冷冻柜最多存 10 件。\n里程碑:首个达成某项的玩家获得永久增益,同回合达成者都有份。\n银行第一次破产:翻开储备卡补充银行,并投票决定 CEO 槽位数。",
			good: {
				burger: "汉堡",
				pizza: "披萨",
				beer: "啤酒",
				lemonade: "柠檬水",
				soda: "汽水"
			},
			emp: {
				kitchen_trainee: "厨房学徒",
				errand_boy: "跑腿小弟",
				marketing_trainee: "营销学徒",
				recruiting_girl: "招聘女郎",
				trainer: "培训师",
				pricing_manager: "定价经理",
				waitress: "女侍",
				management_trainee: "管理培训生",
				burger_cook: "汉堡厨师",
				pizza_cook: "披萨厨师",
				cart_operator: "餐车操作员",
				truck_driver: "卡车司机",
				campaign_manager: "营销经理",
				brand_manager: "品牌经理",
				junior_vp: "初级副总裁",
				vp: "副总裁",
				senior_vp: "高级副总裁",
				local_manager: "地方经理",
				new_business_dev: "新业务拓展",
				discount_manager: "折扣经理",
				coach: "教练",
				recruiting_manager: "招聘经理",
				burger_chef: "汉堡大厨",
				pizza_chef: "披萨大厨",
				zeppelin_pilot: "飞艇驾驶员",
				brand_director: "品牌总监",
				executive_vp: "执行副总裁",
				cfo: "首席财务官",
				regional_manager: "区域经理",
				hr_director: "人力总监",
				guru: "培训大师",
				luxuries_manager: "奢侈品经理"
			},
			ms: {
				first_hire_3: "招兵买马",
				first_train: "首开培训",
				first_billboard: "首块广告牌",
				first_throw: "忍痛丢弃",
				first_burger_produced: "汉堡出炉",
				first_pizza_produced: "披萨出炉",
				first_burger_marketed: "汉堡营销",
				first_pizza_marketed: "披萨营销",
				first_drink_marketed: "饮品营销",
				first_waitress: "女侍上岗",
				first_20_cash: "小有积蓄",
				first_errand_boy: "跑腿上岗",
				first_cart_operator: "餐车上岗",
				first_airplane: "空中广告",
				first_radio: "电台广告",
				first_lower_prices: "价格战",
				first_100_cash: "百元大亨",
				first_20_salary: "高薪养士"
			},
			msd: {
				first_hire_3: "单回合招聘 3 人:获得 2 张管理培训生",
				first_train: "首个完成培训:每次发薪时工资总额少付 $15",
				first_billboard: "首个放置广告牌:营销员免付工资,自己的营销永不过期",
				first_throw: "首个丢弃食饮:获得冷冻柜(存 10 件)",
				first_burger_produced: "首个生产汉堡:获得 1 张汉堡厨师",
				first_pizza_produced: "首个生产披萨:获得 1 张披萨厨师",
				first_burger_marketed: "首个营销汉堡:汉堡每件 +$5",
				first_pizza_marketed: "首个营销披萨:披萨每件 +$5",
				first_drink_marketed: "首个营销饮品:饮品每件 +$5",
				first_waitress: "首个上岗女侍:女侍小费 $3→$5",
				first_20_cash: "首个持有 $20:可查看扣置的储备卡",
				first_errand_boy: "首个上岗跑腿小弟:采购饮品时每个饮品源多得 1 件",
				first_cart_operator: "首个上岗餐车操作员:采购饮品的可达距离 +1",
				first_airplane: "首个放飞机广告:定序 +2 虚拟空槽",
				first_radio: "首个放电台广告:电台每房放 2 个需求",
				first_lower_prices: "首个降价上岗:单价永久 -$1",
				first_100_cash: "首个持有 $100:CEO 视同 CFO(须解雇 CFO)",
				first_20_salary: "首个实付工资 ≥$20:同一回合可对同一名员工使用多个培训师"
			},
			brand: {
				b0: "金薯条",
				b1: "汉堡山",
				b2: "披萨港",
				b3: "汽水站",
				b4: "烤鸡舍"
			},
			direction: {
				N: "朝北 ↑",
				E: "朝东 →",
				S: "朝南 ↓",
				W: "朝西 ←"
			},
			optIntro: "入门模式",
			optIntroDesc: "不用储备卡/里程碑/工资,银行 $75/人,破一次即结束",
			phase: {
				setupRestaurants: "放置起始餐厅",
				setupReserve: "选择储备卡",
				restructuring: "重组架构",
				orderDraft: "定序",
				working: "工作中",
				dinnertime: "晚餐时间",
				payday: "发薪日",
				marketing: "营销结算",
				cleanup: "清理",
				done: "已结束"
			},
			sub: {
				recruit: "招聘",
				train: "培训",
				market: "营销",
				produce: "生产",
				build: "建房",
				restaurant: "开餐厅",
				done: "完成"
			},
			ui: {
				district: "中央街区 / 城市沙盘",
				archive: "公司档案",
				companyDesk: "公司工作台",
				currentAction: "当前行动 / COMPANY DESK",
				legalSites: "{{n}} 个可选落点 · 点击地图",
				selectedSite: "已选地块",
				recenter: "重置地图视角",
				close: "关闭",
				cash: "现金 ${{n}}",
				cityAtlas: "CITY ATLAS / 街区图册",
				mapHint: "拖动地图 · 双指缩放",
				rotate: "旋转入口或建筑",
				round: "第 {{n}} 回合",
				bank: "银行 ${{n}}",
				bankBroken: "银行第 {{n}} 次破产!",
				supply: "供应堆",
				pass: "跳过",
				confirm: "确认",
				finishTurn: "结束行动",
				nextSub: "跳过本项",
				fire: "解雇",
				salary: "工资 ${{n}}",
				paydayHint: "点选要解雇的员工,再确认发薪",
				mustFire: "现金不足,必须解雇更多员工",
				chooseReserve: "选择一张储备卡(银行首次破产时加入银行,并投票 CEO 槽位)",
				reserveSlots: "{{n}} 槽",
				chooseOrderPos: "选择你的回合位置",
				waiting: "等待其他玩家…",
				yourStructure: "组织架构",
				beach: "沙滩(未上岗)",
				busy: "营销中",
				unitPrice: "单价 ${{n}}",
				waitresses: "女侍 ×{{n}}",
				stock: "库存",
				freezer: "冷冻柜 {{n}}/10",
				freezerKeep: "冷冻柜装不下:选择要保留的 {{n}} 件",
				milestones: "里程碑",
				placeRestaurant: "点选空地放餐厅,入口朝路",
				moveRestaurant: "点选空地搬迁餐厅",
				placeHouse: "点选空地放置带花园的新房屋",
				placeGarden: "给印刷房屋加建花园",
				pickGood: "选择品类",
				pickDuration: "持续 {{n}} 回合",
				eternal: "永恒",
				comingSoon: "待开业",
				dinnerSale: "{{name}} 卖出 ${{n}}",
				dinnerNone: "无人问津",
				tips: "女侍小费 +${{n}}",
				ceoSlots: "CEO 槽位 {{n}}",
				recruitsLeft: "还可招聘 {{n}} 人",
				trainSteps: "培训步数 {{n}}",
				demand: "需求",
				intro: "入门模式"
			},
			errNotPlayer: "你不在本局中",
			errNotYourTurn: "还没轮到你",
			errCellBlocked: "该格被占用或不可用",
			errNoRoad: "必须贴着道路",
			errSameEntranceTile: "起始餐厅入口不能与别人同板块",
			errMustPlace: "第二轮必须放置",
			errBadCard: "无效的卡牌",
			errSlotsOverflow: "超出组织架构容量",
			errBadPosition: "该位置已被选",
			errNoAction: "当前没有可用行动",
			errNotRecruitable: "该员工不可招聘",
			errSupplyEmpty: "供应堆已空",
			errBadTrain: "无法培训到该岗位",
			errTopDup: "1x 顶岗每人限一张",
			errNoTrainSteps: "培训步数不足",
			errBadTile: "该营销板不可用",
			errBadCampaignType: "该营销员做不了这类营销",
			errBadDuration: "时长超出上限",
			errBadPlacement: "落点不合法",
			errOutOfRange: "超出范围",
			errBadGood: "无效的品类",
			errNoSource: "没有可选的饮品源",
			errBadHouse: "无效的房屋",
			errTooMany: "最多 3 家餐厅",
			errCannotFireBusy: "营销中的员工只有资不抵债才可解雇",
			errMustFire: "现金不够发工资,必须继续解雇",
			errFreezerFull: "冷冻柜装不下这么多",
			errBadPhase: "当前阶段不能这么做",
			ct: {
				billboard: "广告牌",
				mailbox: "信箱",
				airplane: "飞机",
				radio: "电台"
			},
			act: {
				restaurant: "开一家新餐厅",
				move: "搬迁餐厅",
				pass: "跳过起始放置",
				reserve: "选择 ${{n}} 储备卡",
				structure: "上岗 {{n}} 名员工",
				order: "选第 {{n}} 顺位",
				recruit: "招聘 {{name}}",
				train: "培训 {{from}} → {{to}}",
				marketing: "投放{{type}}广告:{{good}} ×{{n}} 回合",
				produce: "让 {{name}} 生产",
				buy: "采购饮品",
				house: "建新房屋",
				garden: "加建花园",
				finish: "结束行动",
				next: "跳过本项",
				payday: "发薪(解雇 {{n}} 人)",
				freezer: "整理冷冻柜"
			}
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Food Chain Magnate",
			desc: "Hire, train, market, and open restaurants: the cutthroat fast-food capitalism game",
			rules: "Goal: when dinnertime ends after the bank breaks for the second time, most cash wins.\nEach round has 7 phases:\n· Restructuring — assign staff into your org, limited by CEO slots; managers report only to the CEO.\n· Order of Business — fewest staffed cards picks turn order first.\n· Working — in turn order, run your staff: recruit (CEO hires 1 free), train (swap into better cards).\n· Working also covers: market (create demand), produce and buy drinks (stock up), build houses, open restaurants.\n· Dinnertime — resolve houses by number: the chain that can fulfill all demand at the lowest price+distance sells.\n· Dinner ties go to more waitresses, then turn order; gardens double unit price; the CFO adds 50% revenue.\n· Payday — pay $5 per card with a salary icon; you may fire first.\n· Marketing — running campaigns add demand to covered houses in ascending tile order.\n· Cleanup — unsold food and drinks are discarded; the freezer keeps up to 10.\nMilestones: the first player to achieve each gets a permanent bonus; everyone achieving it the same round gets it too.\nFirst bank break: reveal reserve cards to refill the bank and vote on CEO slots.",
			good: {
				burger: "Burger",
				pizza: "Pizza",
				beer: "Beer",
				lemonade: "Lemonade",
				soda: "Soda"
			},
			emp: {
				kitchen_trainee: "Kitchen Trainee",
				errand_boy: "Errand Boy",
				marketing_trainee: "Marketing Trainee",
				recruiting_girl: "Recruiting Girl",
				trainer: "Trainer",
				pricing_manager: "Pricing Manager",
				waitress: "Waitress",
				management_trainee: "Management Trainee",
				burger_cook: "Burger Cook",
				pizza_cook: "Pizza Cook",
				cart_operator: "Cart Operator",
				truck_driver: "Truck Driver",
				campaign_manager: "Campaign Manager",
				brand_manager: "Brand Manager",
				junior_vp: "Junior VP",
				vp: "VP",
				senior_vp: "Senior VP",
				local_manager: "Local Manager",
				new_business_dev: "New Business Dev",
				discount_manager: "Discount Manager",
				coach: "Coach",
				recruiting_manager: "Recruiting Manager",
				burger_chef: "Burger Chef",
				pizza_chef: "Pizza Chef",
				zeppelin_pilot: "Zeppelin Pilot",
				brand_director: "Brand Director",
				executive_vp: "Executive VP",
				cfo: "CFO",
				regional_manager: "Regional Manager",
				hr_director: "HR Director",
				guru: "Guru",
				luxuries_manager: "Luxuries Manager"
			},
			ms: {
				first_hire_3: "Hiring Spree",
				first_train: "First Training",
				first_billboard: "First Billboard",
				first_throw: "First Throwaway",
				first_burger_produced: "First Burgers",
				first_pizza_produced: "First Pizzas",
				first_burger_marketed: "Burger Ads",
				first_pizza_marketed: "Pizza Ads",
				first_drink_marketed: "Drink Ads",
				first_waitress: "First Waitress",
				first_20_cash: "First $20",
				first_errand_boy: "First Errand Boy",
				first_cart_operator: "First Cart Operator",
				first_airplane: "First Airplane",
				first_radio: "First Radio",
				first_lower_prices: "Price War",
				first_100_cash: "First $100",
				first_20_salary: "Big Payrolls"
			},
			msd: {
				first_hire_3: "Recruit 3 in one round: gain 2 Management Trainees",
				first_train: "First to finish a training: pay $15 less total salary each payday",
				first_billboard: "First billboard placed: marketeers need no salary, your campaigns never expire",
				first_throw: "First to discard food/drink: gain the freezer (holds 10)",
				first_burger_produced: "First burger production: gain 1 Burger Cook",
				first_pizza_produced: "First pizza production: gain 1 Pizza Cook",
				first_burger_marketed: "First burger campaign: +$5 per burger",
				first_pizza_marketed: "First pizza campaign: +$5 per pizza",
				first_drink_marketed: "First drink campaign: +$5 per drink",
				first_waitress: "First waitress staffed: tips $3 → $5",
				first_20_cash: "First to hold $20: may peek at reserve cards",
				first_errand_boy: "First Errand Boy staffed: get +1 item per source when buying drinks",
				first_cart_operator: "First Cart Operator staffed: +1 reach when buying drinks",
				first_airplane: "First airplane campaign: +2 virtual empty slots in ordering",
				first_radio: "First radio campaign: radio places 2 demands per house",
				first_lower_prices: "First price cut staffed: -$1 unit price forever",
				first_100_cash: "First to hold $100: CEO counts as CFO (must fire CFO)",
				first_20_salary: "First to pay $20+ salaries: multiple trainers may train the same employee in one turn"
			},
			brand: {
				b0: "Golden Fries",
				b1: "Burger Hill",
				b2: "Pizza Port",
				b3: "Soda Stop",
				b4: "Roast Roost"
			},
			direction: {
				N: "North ↑",
				E: "East →",
				S: "South ↓",
				W: "West ←"
			},
			optIntro: "Intro mode",
			optIntroDesc: "No reserves/milestones/salaries, $75 per player, ends at first bank break",
			phase: {
				setupRestaurants: "Place starter restaurants",
				setupReserve: "Choose reserve cards",
				restructuring: "Restructuring",
				orderDraft: "Order of business",
				working: "Working 9-5",
				dinnertime: "Dinnertime",
				payday: "Payday",
				marketing: "Marketing campaigns",
				cleanup: "Cleanup",
				done: "Finished"
			},
			sub: {
				recruit: "Recruit",
				train: "Train",
				market: "Marketing",
				produce: "Produce",
				build: "Build",
				restaurant: "Restaurants",
				done: "Done"
			},
			ui: {
				district: "Central District / City Board",
				archive: "Company File",
				companyDesk: "Company Desk",
				currentAction: "CURRENT ACTION / COMPANY DESK",
				legalSites: "{{n}} available sites · tap the map",
				selectedSite: "Selected lot",
				recenter: "Recenter map",
				close: "Close",
				cash: "Cash ${{n}}",
				cityAtlas: "CITY ATLAS / DISTRICT MAP",
				mapHint: "Drag to pan · Pinch to zoom",
				rotate: "Rotate entrance or building",
				round: "Round {{n}}",
				bank: "Bank ${{n}}",
				bankBroken: "Bank break #{{n}}!",
				supply: "Supply",
				pass: "Pass",
				confirm: "Confirm",
				finishTurn: "Finish",
				nextSub: "Skip",
				fire: "Fire",
				salary: "Salaries ${{n}}",
				paydayHint: "Tap staff to fire, then confirm payday",
				mustFire: "Not enough cash — you must fire more staff",
				chooseReserve: "Pick a reserve card (joins the bank at first break; votes on CEO slots)",
				reserveSlots: "{{n}} slots",
				chooseOrderPos: "Pick your turn order slot",
				waiting: "Waiting for other players…",
				yourStructure: "Org structure",
				beach: "Beach (idle)",
				busy: "Marketing",
				unitPrice: "Price ${{n}}",
				waitresses: "Waitresses ×{{n}}",
				stock: "Stock",
				freezer: "Freezer {{n}}/10",
				freezerKeep: "Freezer is full: pick {{n}} items to keep",
				milestones: "Milestones",
				placeRestaurant: "Tap an empty lot; entrance must face a road",
				moveRestaurant: "Tap an empty lot to move the restaurant",
				placeHouse: "Tap an empty lot for a new house with garden",
				placeGarden: "Add a garden to a printed house",
				pickGood: "Pick a good",
				pickDuration: "Lasts {{n}} rounds",
				eternal: "Eternal",
				comingSoon: "Opening soon",
				dinnerSale: "{{name}} sold ${{n}}",
				dinnerNone: "No sale",
				tips: "Waitress tips +${{n}}",
				ceoSlots: "CEO slots {{n}}",
				recruitsLeft: "{{n}} hires left",
				trainSteps: "{{n}} training steps",
				demand: "Demand",
				intro: "Intro mode"
			},
			errNotPlayer: "You are not in this game",
			errNotYourTurn: "Not your turn",
			errCellBlocked: "That cell is blocked",
			errNoRoad: "Must touch a road",
			errSameEntranceTile: "Starter entrances cannot share a tile",
			errMustPlace: "You must place in the second round",
			errBadCard: "Invalid card",
			errSlotsOverflow: "Org structure over capacity",
			errBadPosition: "That slot is taken",
			errNoAction: "No action available now",
			errNotRecruitable: "That employee cannot be recruited",
			errSupplyEmpty: "Supply is empty",
			errBadTrain: "Cannot train into that job",
			errTopDup: "Only one 1x top-position card each",
			errNoTrainSteps: "Not enough training steps",
			errBadTile: "That campaign tile is unavailable",
			errBadCampaignType: "This marketeer cannot run that campaign type",
			errBadDuration: "Duration over the limit",
			errBadPlacement: "Invalid placement",
			errOutOfRange: "Out of range",
			errBadGood: "Invalid good",
			errNoSource: "No drink source available",
			errBadHouse: "Invalid house",
			errTooMany: "At most 3 restaurants",
			errCannotFireBusy: "Busy marketeers can only be fired when insolvent",
			errMustFire: "Cannot afford salaries — fire more staff",
			errFreezerFull: "The freezer cannot hold that much",
			errBadPhase: "Not allowed in this phase",
			ct: {
				billboard: "billboard",
				mailbox: "mailbox",
				airplane: "airplane",
				radio: "radio"
			},
			act: {
				restaurant: "Open a new restaurant",
				move: "Move a restaurant",
				pass: "Pass on initial placement",
				reserve: "Take the ${{n}} reserve card",
				structure: "Staff {{n}} employees",
				order: "Take turn slot #{{n}}",
				recruit: "Recruit {{name}}",
				train: "Train {{from}} → {{to}}",
				marketing: "Run a {{type}} campaign: {{good}} ×{{n}} rounds",
				produce: "Produce with {{name}}",
				buy: "Buy drinks",
				house: "Build a house",
				garden: "Add a garden",
				finish: "Finish working",
				next: "Skip this step",
				payday: "Payday (fire {{n}})",
				freezer: "Tidy the freezer"
			}
		}
	}
};
//#endregion
export { tn as default };
