import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { botAvatarOf as o } from "@bgparty/sdk/lobby";
import { AVATARS as s } from "@bgparty/sdk/avatars";
import { useFxAnchor as c } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as l } from "@bgparty/sdk/fx/delta-number";
import { avatarNameAt as u, useI18nSettings as d, useT as f } from "@bgparty/sdk/i18n";
import { IconBell as p, IconBot as m, IconDisconnected as h } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as g } from "@bgparty/sdk/player-colors";
import { GameScreen as _ } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { botPersonality as x } from "@bgparty/sdk/bot-personality";
import { Floater as S, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { playBell as w } from "@bgparty/sdk/sfx";
import { Confetti as T } from "@bgparty/sdk/ui/confetti";
import { seatName as E } from "@bgparty/sdk/ui/player-strip";
//#region src/games/durian/cards.ts
var D = [
	"cherry",
	"banana",
	"grape",
	"durian"
], O = {
	cherry: "🍓",
	banana: "🍌",
	grape: "🍇",
	durian: "🍍"
}, k = [
	[
		"cherry",
		3,
		"banana",
		1
	],
	[
		"cherry",
		2,
		"banana",
		3
	],
	[
		"cherry",
		3,
		"grape",
		1
	],
	[
		"cherry",
		2,
		"grape",
		3
	],
	[
		"cherry",
		3,
		"durian",
		1
	],
	[
		"cherry",
		2,
		"durian",
		1
	],
	[
		"banana",
		3,
		"cherry",
		1
	],
	[
		"banana",
		2,
		"cherry",
		3
	],
	[
		"banana",
		2,
		"grape",
		2
	],
	[
		"banana",
		2,
		"durian",
		1
	],
	[
		"grape",
		3,
		"cherry",
		1
	],
	[
		"grape",
		2,
		"cherry",
		3
	],
	[
		"grape",
		2,
		"banana",
		2
	],
	[
		"grape",
		2,
		"durian",
		1
	],
	[
		"durian",
		3,
		"cherry",
		1
	],
	[
		"durian",
		2,
		"cherry",
		1
	],
	[
		"durian",
		2,
		"banana",
		1
	],
	[
		"durian",
		2,
		"grape",
		1
	]
].flatMap(([e, t, n, r]) => Array.from({ length: r }, () => ({
	multi: {
		fruit: e,
		count: t
	},
	single: {
		fruit: n,
		count: 1
	}
}))).map((e, t) => ({
	id: t + 1,
	...e
})), A = new Map(k.map((e) => [e.id, e])), j = /* @__PURE__ */ new Map([
	[29, "ignoreTriple"],
	[30, "nothing"],
	[31, "infinityBanana"]
]), M = Array.from({ length: 31 }, (e, t) => t + 1);
function N(e) {
	return A.get(e) ?? null;
}
function P(e) {
	return j.get(e) ?? null;
}
function F(e) {
	let t = A.get(e);
	return t ? [t.multi, t.single] : [];
}
function I(e, t) {
	let n = A.get(e);
	if (!n) throw Error(`order 只能是水果牌: ${e}`);
	return t === 0 ? n.multi : n.single;
}
//#endregion
//#region src/games/durian/meta.ts
var L = {
	id: "durian",
	tier: "released",
	mechanics: ["deduction", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.durian.name",
	descKey: "games.durian.desc",
	rulesKey: "games.durian.rules",
	icon: "🔔",
	iconImg: "games/durian.webp",
	minPlayers: 3,
	maxPlayers: 7,
	bestPlayers: [
		5,
		6,
		7
	],
	accent: "#65a30d",
	releasedAt: "2026-09-11",
	search: {
		py: "liu lian wang fan",
		init: "llwf"
	},
	hotseat: "cover"
}, R = t.int().min(1).max(31), te = t.discriminatedUnion("type", [
	t.object({ type: t.literal("draw") }),
	t.object({
		type: t.literal("orient"),
		side: t.union([t.literal(0), t.literal(1)])
	}),
	t.object({
		type: t.literal("flipOrder"),
		index: t.int().nonnegative()
	}),
	t.object({ type: t.literal("ring") }),
	t.object({ type: t.literal("confirm") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), z = t.string(), ne = t.object({
	id: R,
	side: t.union([t.literal(0), t.literal(1)]),
	flipped: t.boolean()
}), re = t.object({
	round: t.int().min(1),
	phase: t.enum([
		"choose",
		"orient",
		"flip",
		"ringing",
		"reveal",
		"done"
	]),
	activeRid: z,
	deckCount: t.int().nonnegative(),
	orders: t.array(ne),
	gorillaAside: t.array(R),
	anger: t.record(z, t.array(t.int())),
	pending: R.nullable(),
	inventory: t.record(z, R).nullable(),
	confirmed: t.array(z),
	lastRing: t.object({
		by: z,
		bust: t.boolean(),
		penalized: z,
		value: t.int(),
		exhausted: t.boolean().optional()
	}).nullable()
}), ie = t.object({ others: t.record(z, R) }), ae = 12e3;
function oe(e, t) {
	return (e.anger[t] ?? []).reduce((e, t) => e + t, 0);
}
function se(t) {
	let n = M.slice(), r = t.rngCursor;
	for (let i = n.length - 1; i > 0; --i) {
		let a = e(t.seed, r, i + 1);
		r += 1, [n[i], n[a]] = [n[a], n[i]];
	}
	for (let e of t.players) t.inventory[e] = n.pop();
	if (P(n[n.length - 1]) !== null) {
		let i = n.map((e, t) => P(e) === null ? t : -1).filter((e) => e >= 0), a = i[e(t.seed, r, i.length)];
		r += 1, [n[n.length - 1], n[a]] = [n[a], n[n.length - 1]];
	}
	return t.rngCursor = r, t.deck = n, t.orders = [], t.gorillaAside = [], t.pending = null, t.lastRing = null, t.confirmed = [], t.phase = "choose", t.players.map((e, t) => ({
		kind: "deal",
		rid: e,
		...t > 0 ? { with: !0 } : {}
	}));
}
function B(e) {
	e.activeIdx = (e.activeIdx + 1) % e.players.length;
}
function ce(e) {
	return e.players.some((t) => oe(e, t) >= 7);
}
function le(e) {
	let t = Object.values(e.inventory), n = t.some((e) => P(e) === "ignoreTriple"), r = t.some((e) => P(e) === "infinityBanana"), i = {
		cherry: 0,
		banana: 0,
		grape: 0,
		durian: 0
	}, a = {
		cherry: 0,
		banana: 0,
		grape: 0,
		durian: 0
	};
	for (let e of t) for (let t of F(e)) i[t.fruit] += t.count;
	for (let t of e.orders) {
		let e = I(t.id, t.side);
		e.count === 3 && n || e.fruit === "banana" && r || (a[e.fruit] += e.count);
	}
	return D.some((e) => a[e] > i[e]);
}
function ue(e, t, n) {
	let r = {
		players: t,
		inventory: {},
		deck: [],
		orders: [],
		gorillaAside: [],
		pending: null,
		activeIdx: 0,
		round: 1,
		anger: Object.fromEntries(t.map((e) => [e, []])),
		confirmed: [],
		phase: "choose",
		beatMs: 0,
		rngCursor: 0,
		seed: n,
		lastRing: null
	};
	return {
		state: r,
		fx: se(r)
	};
}
function de(e, t) {
	e.anger[t] = [...e.anger[t], e.round];
}
function fe(e) {
	return e.beatMs = 0, ce(e) ? (e.phase = "done", []) : (e.activeIdx = (e.players.indexOf(e.lastRing?.penalized ?? e.players[e.activeIdx]) + 1) % e.players.length, e.round += 1, se(e));
}
function pe(e, t, n) {
	let r = e.players[e.activeIdx];
	if (t.type === "tick") {
		if (e.phase === "ringing" && e.lastRing) {
			let t = e.lastRing, n = structuredClone(e);
			return de(n, t.penalized), n.phase = "reveal", n.beatMs = ae, {
				state: n,
				fx: [{
					kind: "penalty",
					rid: t.penalized,
					data: {
						value: t.value,
						bust: t.bust
					}
				}]
			};
		}
		if (e.phase !== "reveal") return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return {
			state: t,
			fx: fe(t)
		};
	}
	if (t.type === "confirm") {
		if (e.phase !== "reveal" || e.confirmed.includes(n.by)) return {
			state: e,
			fx: []
		};
		let t = structuredClone(e);
		return t.confirmed.push(n.by), t.confirmed.length < t.players.length ? {
			state: t,
			fx: []
		} : {
			state: t,
			fx: fe(t)
		};
	}
	if (n.by !== r) return { code: "games.durian.errNotYourTurn" };
	if (t.type === "ring") {
		if (e.phase !== "choose") return { code: "games.durian.errNotYourTurn" };
		if (e.orders.length === 0) return { code: "games.durian.errNoOrders" };
		let t = structuredClone(e), r = le(t), i = r ? t.players[(t.activeIdx - 1 + t.players.length) % t.players.length] : n.by;
		return t.lastRing = {
			by: n.by,
			bust: r,
			penalized: i,
			value: t.round
		}, t.confirmed = [], t.phase = "ringing", t.beatMs = 760, {
			state: t,
			fx: [{
				kind: "ring",
				rid: n.by
			}]
		};
	}
	if (t.type === "draw") {
		if (e.phase !== "choose") return { code: "games.durian.errNotYourTurn" };
		let t = structuredClone(e);
		if (t.deck.length === 0) return de(t, n.by), t.lastRing = {
			by: n.by,
			bust: !0,
			penalized: n.by,
			value: t.round,
			exhausted: !0
		}, t.confirmed = [], t.phase = "reveal", t.beatMs = ae, {
			state: t,
			fx: [{
				kind: "penalty",
				rid: n.by,
				data: {
					value: t.round,
					bust: !0
				}
			}]
		};
		let r = t.deck.pop(), i = [{
			kind: "draw",
			rid: n.by,
			data: { id: r }
		}];
		return P(r) === null ? (t.pending = r, t.phase = "orient") : t.orders.some((e) => !e.flipped) ? (t.pending = r, t.phase = "flip") : (t.gorillaAside.push(r), B(t)), {
			state: t,
			fx: i
		};
	}
	if (t.type === "orient") {
		if (e.phase !== "orient" || e.pending === null) return { code: "games.durian.errNotYourTurn" };
		let r = structuredClone(e), i = r.pending;
		return r.orders = [...r.orders, {
			id: i,
			side: t.side,
			flipped: !1
		}], r.pending = null, r.phase = "choose", B(r), {
			state: r,
			fx: [{
				kind: "order",
				rid: n.by,
				data: {
					id: i,
					side: t.side,
					index: r.orders.length - 1
				}
			}]
		};
	}
	if (e.phase !== "flip" || e.pending === null) return { code: "games.durian.errNotYourTurn" };
	let i = e.orders[t.index];
	if (!i || i.flipped) return { code: "games.durian.errBadOrder" };
	let a = structuredClone(e), o = a.orders[t.index];
	return o.side = +(o.side === 0), o.flipped = !0, a.gorillaAside.push(a.pending), a.pending = null, a.phase = "choose", B(a), {
		state: a,
		fx: [{
			kind: "flip",
			rid: n.by,
			data: { index: t.index }
		}]
	};
}
function me(e, t) {
	let n = e.phase === "reveal" || e.phase === "done", r = {};
	if (!n) for (let n of e.players) n !== t && e.inventory[n] !== void 0 && (r[n] = e.inventory[n]);
	return {
		public: {
			round: e.round,
			phase: e.phase,
			activeRid: e.players[e.activeIdx],
			deckCount: e.deck.length,
			orders: e.orders,
			gorillaAside: e.gorillaAside,
			anger: e.anger,
			pending: e.pending,
			inventory: n ? e.inventory : null,
			confirmed: e.confirmed,
			lastRing: e.phase === "ringing" ? null : e.lastRing
		},
		private: { others: r }
	};
}
function he(e) {
	if (e.phase !== "done") return { phase: e.phase };
	let t = (t) => oe(e, t), n = [...e.players].sort((e, n) => t(e) - t(n)), r = t(n[0]);
	return {
		phase: "done",
		winner: n.filter((e) => t(e) === r),
		ranking: n,
		scores: Object.fromEntries(e.players.map((e) => [e, t(e)]))
	};
}
function ge(e) {
	return e.phase === "ringing" || e.phase === "reveal" ? e.beatMs : null;
}
var _e = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: L,
	schemas: {
		action: te,
		publicView: re,
		privateView: ie
	},
	setup: ue,
	reduce: pe,
	viewFor: me,
	status: he,
	nextTickIn: ge
};
//#endregion
//#region src/games/durian/durian-icon.tsx
function ve({ size: e = 16, color: t = "var(--color-ink)", outline: n, innerColor: r, className: i }) {
	return /* @__PURE__ */ b("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: i,
		children: [/* @__PURE__ */ b("g", {
			fill: t,
			stroke: n,
			strokeWidth: n ? 2.5 : void 0,
			strokeLinejoin: "round",
			children: [/* @__PURE__ */ y("path", { d: "M30 14 C29 8 32 5 35.5 5.5 C34 9 33.8 11 34.2 14 Z" }), /* @__PURE__ */ y("path", { d: "M32 15 L36.6 20.7 L43.8 18.8 L44.1 26.2 L51 28.8 L47 35 L51 41.2 L44.1 43.8 L43.8 51.2 L36.6 49.3 L32 55 L27.4 49.3 L20.2 51.2 L19.9 43.8 L13 41.2 L17 35 L13 28.8 L19.9 26.2 L20.2 18.8 L27.4 20.7 Z" })]
		}), r && /* @__PURE__ */ y("circle", {
			cx: "32",
			cy: "35",
			r: "12.5",
			fill: r
		})]
	});
}
//#endregion
//#region src/games/durian/fruit-icon.tsx
function ye() {
	return /* @__PURE__ */ b("g", { children: [
		/* @__PURE__ */ y("path", {
			d: "M32 3 C30.5 7 30.5 9.5 31.5 12.5 L32.5 12.5 C33.5 9.5 33.5 7 32 3 Z",
			fill: "#2e8b3f"
		}),
		/* @__PURE__ */ y("path", {
			d: "M14 22 C18 13 25 10 32 10 C39 10 46 13 50 22 C45.5 19 41.5 19.5 39.5 24 L32 14 L24.5 24 C22.5 19.5 18.5 19 14 22 Z",
			fill: "#34a04a"
		}),
		/* @__PURE__ */ y("path", {
			d: "M32 15 C19 15 10 24 10 34 C10 46 23 55 32 57.5 C41 55 54 46 54 34 C54 24 45 15 32 15 Z",
			fill: "#f5536b"
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: "22",
			cy: "28",
			rx: "4.5",
			ry: "6.5",
			fill: "#ffffff",
			opacity: "0.3",
			transform: "rotate(-18 22 28)"
		}),
		/* @__PURE__ */ b("g", {
			fill: "#ffe08a",
			children: [
				/* @__PURE__ */ y("ellipse", {
					cx: "24",
					cy: "30",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "32",
					cy: "29",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "40",
					cy: "30",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "20",
					cy: "38",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "28",
					cy: "38",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "36",
					cy: "38",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "44",
					cy: "38",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "26",
					cy: "47",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "33",
					cy: "47",
					rx: "1.8",
					ry: "2.6"
				}),
				/* @__PURE__ */ y("ellipse", {
					cx: "40",
					cy: "47",
					rx: "1.8",
					ry: "2.6"
				})
			]
		})
	] });
}
function be() {
	return /* @__PURE__ */ b("g", { children: [
		/* @__PURE__ */ y("path", {
			d: "M20 15 C23 37 35 52 54 48",
			stroke: "#ffd23f",
			strokeWidth: "17",
			strokeLinecap: "round",
			fill: "none"
		}),
		/* @__PURE__ */ y("path", {
			d: "M23 21 C26 38 37 48 50 45.5",
			stroke: "#f0ad1f",
			strokeWidth: "4.5",
			strokeLinecap: "round",
			fill: "none",
			opacity: "0.7"
		}),
		/* @__PURE__ */ y("circle", {
			cx: "19.5",
			cy: "14.5",
			r: "4.5",
			fill: "#a0622d"
		}),
		/* @__PURE__ */ y("circle", {
			cx: "54",
			cy: "48.5",
			r: "4.5",
			fill: "#a0622d"
		})
	] });
}
function xe() {
	return /* @__PURE__ */ b("g", { children: [
		/* @__PURE__ */ y("path", {
			d: "M32.5 20 C33.5 14 35.5 9.5 39 5.5",
			stroke: "#7a4f2b",
			strokeWidth: "3.2",
			strokeLinecap: "round",
			fill: "none"
		}),
		/* @__PURE__ */ y("path", {
			d: "M39 11 C43 4 51 3.5 56.5 8.5 C52.5 15 44 16.5 39 11 Z",
			fill: "#3fae62"
		}),
		[
			[27, [
				16,
				27.3,
				38.7,
				50
			]],
			[37, [
				21,
				32,
				44
			]],
			[46.5, [27, 39]],
			[55, [33]]
		].flatMap(([e, t], n) => t.map((t, r) => /* @__PURE__ */ y("circle", {
			cx: t,
			cy: e,
			r: "7.8",
			fill: (n + r) % 2 == 0 ? "#a25ee0" : "#8b48cf"
		}, `${n}-${r}`))),
		/* @__PURE__ */ b("g", {
			fill: "#ffffff",
			opacity: "0.35",
			children: [
				/* @__PURE__ */ y("circle", {
					cx: "13.8",
					cy: "24.8",
					r: "2.2"
				}),
				/* @__PURE__ */ y("circle", {
					cx: "25.1",
					cy: "24.8",
					r: "2.2"
				}),
				/* @__PURE__ */ y("circle", {
					cx: "18.8",
					cy: "34.8",
					r: "2.2"
				}),
				/* @__PURE__ */ y("circle", {
					cx: "29.8",
					cy: "34.8",
					r: "2.2"
				}),
				/* @__PURE__ */ y("circle", {
					cx: "24.8",
					cy: "44.3",
					r: "2.2"
				})
			]
		})
	] });
}
function Se() {
	return /* @__PURE__ */ b("g", { children: [
		/* @__PURE__ */ y("path", {
			d: "M30 12 C29 7 32 4 35.5 4.5 C34 8 33.8 10 34.2 12.5 Z",
			fill: "#7a4f2b"
		}),
		/* @__PURE__ */ y("path", {
			d: "M32 11 L37.05 16.16 L44 14.2 L45.79 21.21 L52.8 23 L50.84 29.95 L56 35 L50.84 40.05 L52.8 47 L45.79 48.79 L44 55.8 L37.05 53.84 L32 59 L26.95 53.84 L20 55.8 L18.21 48.79 L11.2 47 L13.16 40.05 L8 35 L13.16 29.95 L11.2 23 L18.21 21.21 L20 14.2 L26.95 16.16 Z",
			fill: "#6fa833"
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: "32",
			cy: "36",
			rx: "14",
			ry: "13.5",
			fill: "#a9cf5e"
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: "26",
			cy: "29",
			rx: "3.5",
			ry: "5",
			fill: "#ffffff",
			opacity: "0.35",
			transform: "rotate(-20 26 29)"
		}),
		/* @__PURE__ */ b("g", {
			fill: "#5c8a2a",
			children: [
				/* @__PURE__ */ y("path", { d: "M32 26 L34.5 30.5 L29.5 30.5 Z" }),
				/* @__PURE__ */ y("path", { d: "M23.5 33 L28.5 35.5 L24.5 39 Z" }),
				/* @__PURE__ */ y("path", { d: "M40.5 33 L39.5 39 L35.5 35.5 Z" }),
				/* @__PURE__ */ y("path", { d: "M26.5 44 L31.5 43 L29.5 48 Z" }),
				/* @__PURE__ */ y("path", { d: "M37.5 44 L34.5 48 L32.5 43 Z" })
			]
		})
	] });
}
var Ce = {
	cherry: ye,
	banana: be,
	grape: xe,
	durian: Se
};
function V({ fruit: e, size: t = 18, className: n }) {
	let r = Ce[e];
	return /* @__PURE__ */ y("svg", {
		width: t,
		height: t,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ y(r, {})
	});
}
//#endregion
//#region src/games/durian/card.tsx
var H = {
	cherry: "games.durian.fruitCherry",
	banana: "games.durian.fruitBanana",
	grape: "games.durian.fruitGrape",
	durian: "games.durian.fruitDurian"
}, we = {
	ignoreTriple: "games.durian.gorillaIgnoreTriple",
	nothing: "games.durian.gorillaNothing",
	infinityBanana: "games.durian.gorillaInfinityBanana"
}, Te = {
	ignoreTriple: "#14b8a6",
	nothing: "#7c3aed",
	infinityBanana: "#e11d48"
};
function Ee({ half: e, big: t }) {
	let n = f();
	if (t) return /* @__PURE__ */ y("span", {
		role: "img",
		"aria-label": n(H[e.fruit], { n: e.count }),
		className: "durian-fruit-choice inline-flex items-center justify-center gap-0.5 leading-none",
		children: Array.from({ length: e.count }, (t, n) => /* @__PURE__ */ y(V, {
			fruit: e.fruit,
			size: 23
		}, n))
	});
	let r = e.count === 1 ? [1] : e.count === 2 ? [2] : [2, 1], i = e.count === 1 ? 20 : 16;
	return /* @__PURE__ */ y("span", {
		role: "img",
		"aria-label": n(H[e.fruit], { n: e.count }),
		className: "inline-flex flex-col items-center justify-center leading-none",
		children: r.map((t, n) => /* @__PURE__ */ y("span", {
			className: `inline-flex items-center justify-center leading-none ${n > 0 ? "-mt-1" : ""}`,
			children: Array.from({ length: t }, (t, n) => /* @__PURE__ */ y(V, {
				fruit: e.fruit,
				size: i
			}, n))
		}, n))
	});
}
function U({ half: e }) {
	let t = f();
	return /* @__PURE__ */ b("span", {
		role: "img",
		"aria-label": t(H[e.fruit], { n: e.count }),
		className: "durian-fruit-count inline-flex min-w-0 items-center justify-center gap-1 leading-none",
		children: [/* @__PURE__ */ y(V, {
			fruit: e.fruit,
			size: 18
		}), /* @__PURE__ */ y("span", {
			"aria-hidden": !0,
			className: "durian-fruit-number font-display text-[22px] font-extrabold tabular-nums",
			children: e.count
		})]
	});
}
function De({ kind: e, small: t }) {
	return e === "infinityBanana" ? /* @__PURE__ */ b("span", {
		"aria-hidden": !0,
		className: `durian-gorilla-symbol durian-gorilla-symbol--infinity ${t ? "durian-gorilla-symbol--small" : ""} inline-flex items-center gap-px leading-none`,
		children: [/* @__PURE__ */ y(V, {
			fruit: "banana",
			size: t ? 13 : 17
		}), /* @__PURE__ */ y("span", {
			className: `font-display font-extrabold ${t ? "text-sm" : "text-lg"}`,
			children: "∞"
		})]
	}) : e === "ignoreTriple" ? /* @__PURE__ */ y("span", {
		"aria-hidden": !0,
		className: `durian-gorilla-symbol durian-gorilla-symbol--triple ${t ? "durian-gorilla-symbol--small" : ""} inline-flex items-center gap-px font-extrabold leading-none ${t ? "text-[10px]" : "text-sm"}`,
		children: "●●●✕"
	}) : /* @__PURE__ */ y("span", {
		"aria-hidden": !0,
		className: `durian-gorilla-symbol durian-gorilla-symbol--zero ${t ? "durian-gorilla-symbol--small" : ""} font-display font-extrabold tabular-nums ${t ? "text-sm" : "text-base"}`,
		children: "0"
	});
}
function W({ kind: e, compact: t }) {
	let n = f();
	return /* @__PURE__ */ b("span", {
		role: "img",
		"aria-label": n(we[e]),
		className: "durian-gorilla-face flex h-full w-full items-center justify-center gap-1 text-white",
		style: { background: Te[e] },
		children: [!t && /* @__PURE__ */ y("span", {
			"aria-hidden": !0,
			className: "durian-gorilla-portrait text-base",
			children: "🦍"
		}), /* @__PURE__ */ y(De, {
			kind: e,
			small: t
		})]
	});
}
function G({ wide: e }) {
	return /* @__PURE__ */ b("span", {
		className: `durian-card-back ${e ? "durian-card-back--wide" : ""} relative grid flex-none place-items-center overflow-hidden border-2 border-ink ${e ? "h-[30px] w-full rounded-md" : "size-7 rounded-md shadow-[3px_3px_0_var(--color-ink)]"}`,
		style: { background: L.accent },
		children: [/* @__PURE__ */ y("svg", {
			className: "absolute inset-0 size-full",
			viewBox: "0 0 44 64",
			preserveAspectRatio: "none",
			"aria-hidden": !0,
			children: /* @__PURE__ */ y("path", {
				d: "M-10 16 L54 -12 M-10 36 L54 8 M-10 56 L54 28 M-10 76 L54 48",
				stroke: "#ffffff",
				strokeWidth: 5,
				opacity: .14,
				fill: "none"
			})
		}), /* @__PURE__ */ y(ve, {
			size: e ? 34 : 25,
			className: "durian-back-icon",
			color: "#65a30d",
			outline: "var(--color-ink)",
			innerColor: "#a9cf5e"
		})]
	});
}
function Oe({ cardId: e, faceDown: t }) {
	let n = f();
	if (t || e === null) return /* @__PURE__ */ y("span", {
		role: "img",
		"aria-label": n("games.durian.myInventoryAria"),
		className: "durian-inventory-card block w-full flex-none",
		children: /* @__PURE__ */ y(G, { wide: !0 })
	});
	let r = P(e);
	if (r !== null) return /* @__PURE__ */ y("span", {
		className: "durian-inventory-card block w-full flex-none overflow-hidden rounded-md border-2 border-ink",
		children: /* @__PURE__ */ y(W, { kind: r })
	});
	let i = N(e);
	return i ? /* @__PURE__ */ b("span", {
		className: "durian-inventory-card flex w-full flex-none items-center rounded-md border-2 border-ink bg-surface",
		children: [
			/* @__PURE__ */ y("span", {
				className: "durian-inventory-left flex flex-1 basis-0 justify-center",
				children: /* @__PURE__ */ y(U, { half: i.multi })
			}),
			/* @__PURE__ */ y("span", {
				"aria-hidden": !0,
				className: "durian-card-divider my-1 w-0.5 self-stretch rounded-full bg-ink/25"
			}),
			/* @__PURE__ */ y("span", {
				className: "flex flex-1 basis-0 justify-center",
				children: /* @__PURE__ */ y(U, { half: i.single })
			})
		]
	}) : null;
}
function K({ order: e }) {
	let t = f(), n = N(e.id);
	if (!n) return null;
	let r = [n.multi, n.single], i = r[+(e.side === 0)], a = r[e.side];
	return /* @__PURE__ */ b("span", {
		"aria-label": e.flipped ? t("games.durian.orderFlippedAria") : void 0,
		className: "durian-order-tile relative inline-flex w-full flex-none items-stretch overflow-visible rounded-md border-2 border-ink bg-surface",
		children: [/* @__PURE__ */ b("span", {
			className: "card-flip-in flex flex-1 items-stretch",
			children: [
				/* @__PURE__ */ y("span", {
					className: "durian-order-left flex flex-1 basis-0 items-center justify-center",
					children: /* @__PURE__ */ y(U, { half: i })
				}),
				/* @__PURE__ */ y("span", {
					"aria-hidden": !0,
					className: "durian-card-divider my-1 w-0.5 self-stretch rounded-full bg-ink/25"
				}),
				/* @__PURE__ */ y("span", {
					role: "group",
					"aria-label": t("games.durian.effective"),
					className: "durian-order-right relative flex flex-1 basis-0 items-center justify-center rounded-r-sm bg-info-soft",
					children: /* @__PURE__ */ y(U, { half: a })
				})
			]
		}, e.side), e.flipped && /* @__PURE__ */ y("span", {
			"aria-hidden": !0,
			className: "durian-order-flipped absolute -top-1.5 -right-1.5 grid size-4 place-items-center rounded-full border border-ink bg-warn text-[9px] leading-none font-bold text-white",
			children: "↻"
		})]
	});
}
//#endregion
//#region src/games/durian/view-player.tsx
function ke(e, t, n, r) {
	let i = {
		columns: 1,
		rows: Math.max(1, n),
		height: 60,
		unit: 0
	};
	for (let a = 1; a <= Math.min(4, Math.max(1, n)); a += 1) {
		let o = Math.max(1, Math.ceil(n / a)), s = (e - (a - 1) * r) / a, c = (t - (o - 1) * r) / o, l = Math.min((s - 8) / 96, (c - 6) / 30);
		l > i.unit && (i = {
			columns: a,
			rows: o,
			height: Math.max(60, Math.min(c, s / 2.6)),
			unit: l
		});
	}
	return i;
}
function Ae(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(je, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function je({ pub: e, priv: t, members: o, myRid: s, send: l }) {
	let u = f(), m = d((e) => e.locale), h = (e) => {
		let t = o.find((t) => t.rid === e);
		return t ? Ne(t, m) : e;
	}, { ref: g } = c("table"), { ref: x } = c("orders"), { ref: S } = c("deck"), C = i(null), [w, T] = a(1);
	r(() => {
		let t = C.current;
		if (!t) return;
		let n = () => {
			let n = getComputedStyle(t);
			if (n.getPropertyValue("--durian-large").trim() === "1") {
				let r = t.clientWidth - parseFloat(n.paddingLeft) - parseFloat(n.paddingRight), i = t.clientHeight - parseFloat(n.paddingTop) - parseFloat(n.paddingBottom), a = parseFloat(n.rowGap), o = ke(r, i, e.orders.length, a), s = (r - (o.columns - 1) * a) / o.columns;
				t.style.setProperty("--durian-order-columns", `${o.columns}`), t.style.setProperty("--durian-order-row-height", `${o.height}px`), t.style.setProperty("--durian-order-unit", `${Math.max(1, Math.min((s - 8) / 96, (o.height - 6) / 28))}px`), T(o.rows);
				return;
			}
			t.style.removeProperty("--durian-order-columns"), t.style.removeProperty("--durian-order-row-height"), t.style.removeProperty("--durian-order-unit"), n = getComputedStyle(t);
			let r = parseFloat(n.gridAutoRows), i = parseFloat(n.rowGap), a = t.clientHeight - parseFloat(n.paddingTop) - parseFloat(n.paddingBottom), o = Math.max(1, Math.floor((a + i) / (r + i))), s = Number(n.getPropertyValue("--durian-order-columns"));
			T(Math.max(o, Math.ceil(e.orders.length / s)));
		};
		n();
		let r = new ResizeObserver(n);
		return r.observe(t), () => {
			r.disconnect(), t.style.removeProperty("--durian-order-columns"), t.style.removeProperty("--durian-order-row-height"), t.style.removeProperty("--durian-order-unit");
		};
	}, [e.orders.length]), n(() => {
		let e = C.current;
		e && (e.scrollTop = e.scrollHeight);
	}, [e.orders.length, w]);
	let E = e.activeRid === s && (e.phase === "choose" || e.phase === "orient" || e.phase === "flip"), D = e.phase === "reveal" || e.phase === "done", O = o.filter((t) => e.anger[t.rid] !== void 0), k = e.phase === "flip" && e.pending !== null ? P(e.pending) : null, A, j, M;
	return e.phase === "reveal" && e.lastRing ? (A = e.lastRing.bust ? "warn" : "info", j = e.lastRing.exhausted ? u("games.durian.revealExhausted", {
		name: h(e.lastRing.penalized),
		value: e.lastRing.value
	}) : e.lastRing.bust ? u("games.durian.revealBust", {
		name: h(e.lastRing.penalized),
		value: e.lastRing.value
	}) : u("games.durian.revealOk", {
		name: h(e.lastRing.penalized),
		value: e.lastRing.value
	}), M = u("games.durian.confirmWait", {
		n: e.confirmed.length,
		total: O.length
	})) : e.phase === "ringing" ? (A = "info", j = u("games.durian.auditing")) : e.phase === "orient" ? (A = E ? "accent" : "info", j = E ? u("games.durian.orientPrompt") : u("games.durian.orientWaiting", { name: h(e.activeRid) })) : e.phase === "flip" ? (A = E ? "accent" : "info", j = E ? u("games.durian.flipPrompt") : u("games.durian.flipWaiting", { name: h(e.activeRid) })) : (A = E ? "accent" : "info", j = E ? u("games.durian.yourTurn") : u("games.durian.waiting", { name: h(e.activeRid) })), /* @__PURE__ */ y("div", {
		className: "durian-screen h-full",
		children: /* @__PURE__ */ y(_, {
			adaptive: !0,
			className: "durian-adaptive",
			banner: /* @__PURE__ */ y("div", {
				className: "durian-banner",
				children: /* @__PURE__ */ y(ee, {
					tone: A,
					text: j,
					sub: M,
					chip: u("games.durian.roundShort", { n: e.round }),
					accent: L.accent
				})
			}),
			actionsHeight: "durian-action-slot h-[66px] wide:h-[60px]",
			scroll: !1,
			actions: /* @__PURE__ */ y("div", {
				className: `durian-actions ${e.phase === "reveal" ? "durian-actions--reveal" : ""}`,
				children: e.phase === "reveal" ? /* @__PURE__ */ b("div", {
					className: "durian-reveal-actions",
					children: [e.inventory && /* @__PURE__ */ y(Ie, { pub: e }), e.confirmed.includes(s) ? /* @__PURE__ */ y("div", {
						"aria-hidden": !0,
						className: "durian-action-wait",
						children: "✓"
					}) : /* @__PURE__ */ y("button", {
						type: "button",
						onClick: () => l({ type: "confirm" }),
						className: "durian-main-action durian-confirm",
						children: u("games.durian.confirm")
					})]
				}) : e.phase === "orient" && e.pending !== null ? /* @__PURE__ */ y(Fe, {
					pub: e,
					myTurn: E,
					send: l
				}) : e.phase === "choose" && E ? /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("button", {
					type: "button",
					onClick: () => l({ type: "draw" }),
					className: "durian-main-action durian-draw",
					children: u("games.durian.draw")
				}), /* @__PURE__ */ b("button", {
					type: "button",
					"aria-label": u("games.durian.ringAria"),
					disabled: e.orders.length === 0,
					onClick: () => l({ type: "ring" }),
					className: "durian-main-action durian-ring",
					children: [/* @__PURE__ */ y(p, {
						size: 28,
						"aria-hidden": !0
					}), u("games.durian.ring")]
				})] }) : /* @__PURE__ */ y("div", {
					"aria-hidden": !0,
					className: "durian-action-wait",
					children: e.phase === "flip" ? "↻" : e.phase === "ringing" ? /* @__PURE__ */ y(p, { size: 28 }) : "…"
				})
			}),
			children: /* @__PURE__ */ b("div", {
				ref: g,
				className: "durian-table",
				children: [/* @__PURE__ */ b("section", {
					className: "durian-seats",
					children: [
						/* @__PURE__ */ y("div", {
							className: "durian-seats-title",
							children: /* @__PURE__ */ y("span", {
								className: "durian-stall-label",
								children: u("games.durian.standingCards")
							})
						}),
						/* @__PURE__ */ y("ul", {
							className: "durian-seat-grid",
							style: { "--durian-seat-rows": Math.max(1, Math.ceil(O.length / 2)) },
							children: O.map((n, r) => /* @__PURE__ */ y(Pe, {
								m: n,
								locale: m,
								centered: O.length % 2 == 1 && r === O.length - 1,
								isMe: n.rid === s,
								active: e.activeRid === n.rid && !D,
								rang: D && e.lastRing?.by === n.rid,
								penalty: D && e.lastRing?.penalized === n.rid ? e.lastRing.value : null,
								confirmedSeat: e.phase === "reveal" && e.confirmed.includes(n.rid),
								cardId: D ? e.inventory?.[n.rid] ?? null : n.rid === s ? null : t?.others[n.rid] ?? null,
								anger: e.anger[n.rid],
								youLabel: u("lobby.you"),
								offlineLabel: u("lobby.offline"),
								botLabel: u("lobby.bot"),
								rangLabel: u("games.durian.rangAria"),
								confirmedLabel: u("games.durian.confirmedAria")
							}, n.rid))
						}),
						/* @__PURE__ */ y("div", {
							className: "durian-wide-label",
							children: u("games.durian.standingCards")
						})
					]
				}), /* @__PURE__ */ b("section", {
					ref: x,
					className: "durian-orders",
					children: [/* @__PURE__ */ b("div", {
						className: "durian-orders-head",
						children: [
							/* @__PURE__ */ y("h2", { children: u("games.durian.ordersTitle") }),
							k && /* @__PURE__ */ y("span", {
								className: "durian-gorilla-aside block size-7 flex-none overflow-hidden rounded border border-ink",
								children: /* @__PURE__ */ y(W, {
									kind: k,
									compact: !0
								})
							}),
							e.gorillaAside.map((e) => {
								let t = P(e);
								return t ? /* @__PURE__ */ y("span", {
									className: "durian-gorilla-aside block size-7 flex-none overflow-hidden rounded border border-ink opacity-65",
									children: /* @__PURE__ */ y(W, {
										kind: t,
										compact: !0
									})
								}, e) : null;
							}),
							/* @__PURE__ */ y("span", {
								className: "durian-deck-label",
								children: u("games.durian.deck")
							}),
							/* @__PURE__ */ b("div", {
								className: "durian-deck",
								children: [/* @__PURE__ */ y("span", {
									ref: S,
									className: "inline-flex",
									children: /* @__PURE__ */ y(G, {})
								}), /* @__PURE__ */ b("span", {
									className: "durian-deck-count font-mono text-xs font-extrabold tabular-nums",
									children: ["×", e.deckCount]
								})]
							})
						]
					}), /* @__PURE__ */ y("ul", {
						ref: C,
						className: "durian-order-grid",
						style: { gridTemplateRows: `repeat(${w}, var(--durian-order-row-height))` },
						children: e.orders.map((t, n) => /* @__PURE__ */ y(Me, {
							order: t,
							index: n,
							canFlip: e.phase === "flip" && E && !t.flipped,
							send: l
						}, n))
					})]
				})]
			})
		})
	});
}
function Me({ order: e, index: t, canFlip: n, send: r }) {
	let i = f(), { ref: a, hidden: o } = c(`order:${t}`);
	return /* @__PURE__ */ y("li", {
		ref: a,
		className: `relative min-w-0 ${o ? "invisible" : ""}`,
		children: n ? /* @__PURE__ */ y("button", {
			type: "button",
			"aria-label": i("games.durian.flipAria", { n: t + 1 }),
			onClick: () => r({
				type: "flipOrder",
				index: t
			}),
			className: "durian-flip-target",
			children: /* @__PURE__ */ y(K, { order: e })
		}) : /* @__PURE__ */ y(K, { order: e })
	});
}
function Ne(e, t) {
	return o(e.rid) === null ? e.name : u(t, e.avatar);
}
function Pe({ m: e, locale: t, centered: n, isMe: r, active: i, rang: a, penalty: u, confirmedSeat: d, cardId: f, anger: p, youLabel: _, offlineLabel: ee, botLabel: v, rangLabel: x, confirmedLabel: S }) {
	let { ref: C } = c(`seat:${e.rid}`), { ref: w } = c(`inv:${e.rid}`), T = g[e.colorIndex % g.length], E = o(e.rid) !== null, D = p.reduce((e, t) => e + t, 0), O = f !== null && P(f) !== null;
	return /* @__PURE__ */ b("li", {
		className: `durian-seat ${n ? "durian-seat--centered" : ""} ${e.online ? "" : "durian-seat--offline"} ${i ? "durian-seat--active" : ""} ${r ? "durian-seat--self" : ""} ${O ? "durian-seat--gorilla" : ""}`,
		children: [/* @__PURE__ */ b("span", {
			className: "durian-seat-head",
			children: [
				/* @__PURE__ */ b("span", {
					ref: C,
					className: "relative flex-none rounded-full",
					children: [
						e.online ? E ? /* @__PURE__ */ y("span", {
							role: "img",
							"aria-label": v,
							className: "absolute -top-1 -right-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-warn-soft text-warn-ink",
							children: /* @__PURE__ */ y(m, {
								size: 10,
								"aria-hidden": !0
							})
						}) : null : /* @__PURE__ */ y("span", {
							role: "img",
							"aria-label": ee,
							className: "absolute -top-1 -right-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-ink text-surface",
							children: /* @__PURE__ */ y(h, {
								size: 10,
								"aria-hidden": !0
							})
						}),
						a && /* @__PURE__ */ y("span", {
							role: "img",
							"aria-label": x,
							className: "absolute -bottom-1 -left-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-surface text-[9px] leading-none",
							children: "🔔"
						}),
						d && /* @__PURE__ */ y("span", {
							role: "img",
							"aria-label": S,
							className: "absolute -bottom-1 -right-1 z-20 grid size-4 place-items-center rounded-full border-2 border-ink bg-done-soft text-[9px] leading-none font-extrabold text-done-ink",
							children: "✓"
						}),
						/* @__PURE__ */ y("span", {
							className: "durian-seat-avatar",
							style: { backgroundColor: T.hex },
							children: /* @__PURE__ */ y("img", {
								src: s[e.avatar % s.length],
								alt: "",
								draggable: !1,
								className: "size-3 object-contain"
							})
						})
					]
				}),
				/* @__PURE__ */ b("span", {
					className: "durian-seat-name",
					children: [Ne(e, t), r && /* @__PURE__ */ b("span", {
						className: "ml-0.5 opacity-60",
						children: [
							"(",
							_,
							")"
						]
					})]
				}),
				D > 0 && /* @__PURE__ */ b("span", {
					className: "durian-anger flex flex-none items-center gap-0.5 rounded border border-ink bg-danger-soft px-1 text-[10px] leading-3 font-bold text-danger",
					children: [/* @__PURE__ */ y("span", {
						"aria-hidden": !0,
						children: "😡"
					}), /* @__PURE__ */ y(l, {
						value: D,
						className: "font-mono tabular-nums"
					})]
				})
			]
		}), /* @__PURE__ */ b("div", {
			ref: w,
			className: `durian-seat-inventory ${u === null ? "" : "rounded-md ring-2 ring-danger"}`,
			children: [/* @__PURE__ */ y(Oe, {
				cardId: f,
				faceDown: f === null
			}), u !== null && /* @__PURE__ */ b("span", {
				className: "durian-penalty absolute -top-2 -right-2 z-10 flex items-center gap-0.5 rounded-md border-2 border-ink bg-danger-soft px-1 text-[10px] leading-3.5 font-extrabold text-danger",
				children: [/* @__PURE__ */ y("span", {
					"aria-hidden": !0,
					children: "😡"
				}), /* @__PURE__ */ b("span", {
					className: "font-mono tabular-nums",
					children: ["+", u]
				})]
			})]
		})]
	});
}
function Fe({ pub: e, myTurn: t, send: n }) {
	let r = f(), i = e.pending === null ? null : N(e.pending);
	if (!i) return null;
	let a = [i.multi, i.single];
	return /* @__PURE__ */ y("div", {
		className: "durian-orient flex h-full w-full items-center justify-center gap-2",
		children: a.map((e, i) => t ? /* @__PURE__ */ y("button", {
			type: "button",
			"aria-label": r("games.durian.orientAria", { n: i + 1 }),
			onClick: () => n({
				type: "orient",
				side: i
			}),
			className: "grid h-full min-w-0 flex-1 place-items-center rounded-md border-2 border-ink bg-info-soft shadow-[2px_2px_0_var(--color-ink)] active:translate-y-0.5 active:shadow-none",
			children: /* @__PURE__ */ y(Ee, {
				half: e,
				big: !0
			})
		}, i) : /* @__PURE__ */ y("span", {
			className: "grid h-full min-w-0 flex-1 place-items-center rounded-md border-2 border-ink bg-surface",
			children: /* @__PURE__ */ y(Ee, {
				half: e,
				big: !0
			})
		}, i))
	});
}
function Ie({ pub: e }) {
	let t = f(), n = Object.values(e.inventory ?? {}), r = n.some((e) => P(e) === "ignoreTriple"), i = n.some((e) => P(e) === "infinityBanana"), a = {
		cherry: 0,
		banana: 0,
		grape: 0,
		durian: 0
	}, o = { ...a }, s = { ...a };
	for (let e of n) for (let t of F(e)) o[t.fruit] += t.count;
	for (let t of e.orders) {
		let e = I(t.id, t.side);
		e.count === 3 && r || e.fruit === "banana" && i || (s[e.fruit] += e.count);
	}
	return /* @__PURE__ */ y("ul", {
		className: "durian-checklist flex h-[18px] w-full flex-none items-center justify-around gap-0.5 overflow-hidden rounded-md border border-ink bg-surface px-1 wide:h-12 wide:min-w-0 wide:flex-1",
		children: D.map((e) => {
			let n = s[e] > o[e];
			return /* @__PURE__ */ b("li", {
				className: `flex min-w-0 items-center gap-0.5 text-xs leading-4 font-bold ${n ? "text-danger" : ""}`,
				children: [
					/* @__PURE__ */ y(V, {
						fruit: e,
						size: 14
					}),
					/* @__PURE__ */ b("span", {
						className: "font-mono tabular-nums",
						children: [
							s[e],
							"/",
							o[e]
						]
					}),
					/* @__PURE__ */ y("span", {
						"aria-hidden": !0,
						children: n ? "✗" : "✓"
					}),
					/* @__PURE__ */ y("span", {
						className: "sr-only",
						children: t(n ? "games.durian.fruitBust" : "games.durian.fruitOk")
					})
				]
			}, e);
		})
	});
}
//#endregion
//#region src/games/durian/bot.ts
function Le(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function q() {
	return crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] / 4294967295;
}
function Re(e, t) {
	return e.inventory ? Object.values(e.inventory) : Object.values(t?.others ?? {});
}
function ze(e, t) {
	let n = /* @__PURE__ */ new Set();
	for (let r of Re(e, t)) n.add(r);
	for (let t of e.orders) n.add(t.id);
	for (let t of e.gorillaAside) n.add(t);
	return e.pending !== null && n.add(e.pending), M.filter((e) => !n.has(e));
}
function Be(e, t, n, r) {
	let i = Re(e, t), a = n === null ? i : [...i, n], o = a.some((e) => P(e) === "ignoreTriple"), s = a.some((e) => P(e) === "infinityBanana"), c = {
		cherry: 0,
		banana: 0,
		grape: 0,
		durian: 0
	}, l = {
		cherry: 0,
		banana: 0,
		grape: 0,
		durian: 0
	};
	for (let e of a) for (let t of F(e)) c[t.fruit] += t.count;
	let u = e.orders.map((e) => I(e.id, e.side));
	r && u.push(r);
	for (let e of u) e.count === 3 && o || e.fruit === "banana" && s || (l[e.fruit] += e.count);
	return {
		stock: c,
		required: l
	};
}
function Ve(e) {
	return D.some((t) => e.required[t] > e.stock[t]);
}
function J(e, t, n = null) {
	let r = ze(e, t);
	if (!r.length) return 0;
	let i = 0;
	for (let a of r) Ve(Be(e, t, a, n)) && (i += 1);
	return i / r.length;
}
function He(e, t, n) {
	let r = ze(e, t);
	if (!r.length) return n;
	let i = 0;
	for (let a of r) {
		if (P(a) !== null) {
			i += n;
			continue;
		}
		let r = F(a);
		i += Math.min(J(e, t, r[0]), J(e, t, r[1]));
	}
	return i / r.length;
}
var Ue = (e, t) => {
	let n = e.public, r = e.private;
	if (n.phase === "reveal") return n.confirmed.includes(t.rid) ? null : { action: { type: "confirm" } };
	if (n.activeRid !== t.rid) return null;
	if (n.phase === "flip") {
		let e = n.orders.map((e, t) => e.flipped ? -1 : t).filter((e) => e >= 0);
		if (!e.length) return null;
		let i = x(o(t.rid));
		if (t.difficulty === "weak" || q() < i.noise * .2) return { action: {
			type: "flipOrder",
			index: Le(e)
		} };
		let a = e[0], s = Infinity;
		for (let t of e) {
			let e = We(n, r, t);
			e < s && (s = e, a = t);
		}
		return { action: {
			type: "flipOrder",
			index: a
		} };
	}
	if (n.phase === "orient") {
		let e = n.pending !== null && !P(n.pending) ? F(n.pending) : null;
		if (!e) return null;
		if (t.difficulty === "weak") return { action: {
			type: "orient",
			side: Le([0, 1])
		} };
		let i = x(o(t.rid)), a = J(n, r, e[0]), s = J(n, r, e[1]), c = (q() - .5) * i.noise * .3;
		if (a + c < s) return { action: {
			type: "orient",
			side: 0
		} };
		if (s + c < a) return { action: {
			type: "orient",
			side: 1
		} };
		let l = e[0].count >= e[1].count ? 0 : 1;
		return { action: {
			type: "orient",
			side: q() < i.greed ? l : 1 - l
		} };
	}
	if (n.phase !== "choose") return null;
	if (!n.orders.length) return { action: { type: "draw" } };
	if (t.difficulty === "weak") return q() < .25 ? { action: { type: "ring" } } : { action: { type: "draw" } };
	let i = x(o(t.rid)), a = J(n, r), s = a - (1 - a), c = He(n, r, a), l = Object.entries(n.anger).map(([e, t]) => [e, t.reduce((e, t) => e + t, 0)]), u = l.find(([e]) => e === t.rid)?.[1] ?? 0, d = Math.min(...l.map(([, e]) => e)), f = Math.max(...l.map(([, e]) => e)), p = f > d ? (u - d) / (f - d) : .5;
	return s + (c - .5) * .5 + (i.risk - .5) * .15 + (.5 - i.patience) * .1 + i.compete * (p - .5) * .15 + (q() - .5) * i.noise * .15 > 0 ? { action: { type: "ring" } } : { action: { type: "draw" } };
};
function We(e, t, n) {
	return J({
		...e,
		orders: e.orders.map((e, t) => t === n ? {
			...e,
			side: +(e.side === 0)
		} : e)
	}, t);
}
var Ge = (e, t, n) => e.type === "draw" ? n("games.durian.draw") : e.type === "ring" ? n("games.durian.ringAria") : e.type === "confirm" ? n("games.durian.confirm") : e.type === "orient" ? n("games.durian.orientAria", { n: e.side + 1 }) : e.type === "flipOrder" ? n("games.durian.flipAria", { n: e.index + 1 }) : "", Y = {
	cherry: "草莓",
	banana: "香蕉",
	grape: "葡萄",
	durian: "榴莲"
}, Ke = {
	ignoreTriple: "猩猩大哥:作废所有「3 个一组」的订单面",
	nothing: "猩猩二哥:什么效果都没有",
	infinityBanana: "猩猩小弟:香蕉订单全免"
}, X = (e, t) => {
	let n = I(e, t);
	return `${O[n.fruit]}${Y[n.fruit]}×${n.count}`;
}, Z = (e) => {
	let t = P(e);
	return t ? `#${e} ${Ke[t]}` : N(e) ? `#${e}[多果面 ${X(e, 0)} / 单果面 ${X(e, 1)}]` : `#${e}`;
}, qe = {
	needsAction(e, t) {
		let n = e.public;
		return n.phase === "reveal" ? !n.confirmed.includes(t.rid) : n.phase === "ringing" || n.phase === "done" ? !1 : n.activeRid === t.rid;
	},
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.round} 轮。规则:轮流当店长——draw 抽一张牌(水果牌选一面放上订单,猩猩牌翻一张已有订单的面),或 ring 摇铃结算:全员立牌(整牌两面都计入库存)能否满足订单(只计生效面);爆单罚上一位行动者,没爆罚摇铃者,罚分=当前轮次号,罚分少者胜。关键:你看不见自己的立牌,只看得见别人的。`, `订单(生效面): ${n.orders.map((e, t) => `${t}:${X(e.id, e.side)}${e.flipped ? "(本轮已被猩猩翻过)" : ""}`).join(" | ") || "(尚无)"}`], i = /* @__PURE__ */ new Map();
		for (let e of n.orders) {
			let t = I(e.id, e.side);
			i.set(t.fruit, (i.get(t.fruit) ?? 0) + t.count);
		}
		r.push(`订单总需求(未计猩猩减免): ${[...i].map(([e, t]) => `${Y[e]}×${t}`).join(", ") || "无"}`);
		let a = e.private?.others ?? {};
		r.push(`你看得见的立牌: ${Object.entries(a).map(([e, t]) => `${e}=${Z(t)}`).join("; ") || "(无)"};你自己的立牌你看不见`);
		let o = /* @__PURE__ */ new Map();
		for (let e of Object.values(a)) {
			let t = N(e);
			if (t) for (let e of [t.multi, t.single]) o.set(e.fruit, (o.get(e.fruit) ?? 0) + e.count);
		}
		return r.push(`已知库存合计(不含你的立牌): ${[...o].map(([e, t]) => `${Y[e]}×${t}`).join(", ") || "无"}`), n.gorillaAside.length && r.push(`本轮置旁的猩猩: ${n.gorillaAside.map(Z).join("; ")}`), r.push(`各人罚分: ${Object.entries(n.anger).map(([e, n]) => `${e === t.rid ? "你" : e}=${n.reduce((e, t) => e + t, 0)}`).join(", ")};牌堆剩 ${n.deckCount}`), n.phase === "reveal" ? r.push(`结算揭晓: ${n.lastRing ? n.lastRing.bust ? "爆单了" : "没爆,冤枉" : ""}。输出 confirm 确认进入下一轮。`) : n.activeRid === t.rid && (n.phase === "choose" ? r.push("轮到你:draw 抽牌 / ring 摇铃结算。") : n.phase === "orient" && n.pending != null ? r.push(`你抽到了 ${Z(n.pending)}。选一面放上订单:orient(side=0 多果面 / 1 单果面)。`) : n.phase === "flip" && n.pending != null && r.push(`你抽到了 ${Z(n.pending)}。必须翻一张已有订单的面:flipOrder(index=订单序号)。`)), r.join("\n");
	},
	actionJsonSchema: { oneOf: [
		{
			type: "object",
			properties: { type: { const: "draw" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "orient" },
				side: {
					type: "integer",
					enum: [0, 1]
				}
			},
			required: ["type", "side"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: {
				type: { const: "flipOrder" },
				index: {
					type: "integer",
					minimum: 0
				}
			},
			required: ["type", "index"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "ring" } },
			required: ["type"],
			additionalProperties: !1
		},
		{
			type: "object",
			properties: { type: { const: "confirm" } },
			required: ["type"],
			additionalProperties: !1
		}
	] },
	parseAction(e, t, n) {
		let r = te.safeParse(e);
		if (!r.success) return null;
		let i = r.data;
		if (i.type === "tick") return null;
		let a = t.public;
		if (i.type === "confirm") return a.phase === "reveal" && !a.confirmed.includes(n.rid) ? i : null;
		if (a.activeRid !== n.rid) return null;
		switch (i.type) {
			case "draw": return a.phase === "choose" ? i : null;
			case "ring": return a.phase === "choose" && a.orders.length > 0 ? i : null;
			case "orient": return a.phase === "orient" && a.pending != null ? i : null;
			case "flipOrder": {
				let e = a.orders[i.index];
				return a.phase === "flip" && a.pending != null && e && !e.flipped ? i : null;
			}
		}
	}
}, Je = 28, Ye = 28;
function Q(e, t, n) {
	let r = e.anchor("table");
	return r ? {
		x: r.x + r.w / 2 - t / 2,
		y: r.y + r.h / 2 - n / 2,
		w: t,
		h: n
	} : null;
}
function Xe() {
	return /* @__PURE__ */ y("span", {
		className: "durian-fx-back",
		children: /* @__PURE__ */ y(G, { wide: !0 })
	});
}
function $({ from: e, to: t, ms: n, children: a }) {
	let o = i(null);
	r(() => {
		let r = o.current;
		if (!r) return;
		let i = t.x - e.x, a = t.y - e.y, s = e.w / Math.max(1, t.w), c = e.h / Math.max(1, t.h), l = r.animate([
			{ transform: `translate(0px, 0px) scale(${s}, ${c})` },
			{
				transform: `translate(${i * .55}px, ${a * .55 - 14}px) scale(${(s + 1) / 2}, ${(c + 1) / 2})`,
				offset: .55
			},
			{ transform: `translate(${i}px, ${a}px) scale(1, 1)` }
		], {
			duration: n,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		});
		return () => l.cancel();
	}, [
		e,
		t,
		n
	]);
	let s = Math.max(.5, Math.min((t.w - 8) / 96, (t.h - 6) / 28));
	return /* @__PURE__ */ y("span", {
		ref: o,
		className: "durian-fx-piece",
		style: {
			left: e.x,
			top: e.y,
			width: t.w,
			height: t.h,
			"--durian-piece-unit": `${s}px`
		},
		children: a
	});
}
var Ze = {
	deal(e, t) {
		let n = t.anchor("deck") ?? Q(t, Je, Ye), r = e.rid ? t.anchor(`inv:${e.rid}`) : null;
		return !n || !r ? null : {
			ms: 340,
			node: /* @__PURE__ */ y($, {
				from: n,
				to: r,
				ms: 320,
				children: /* @__PURE__ */ y(Xe, {})
			})
		};
	},
	draw(e, t) {
		let n = t.anchor("deck"), r = (e.rid ? t.anchor(`seat:${e.rid}`) : null) ?? Q(t, Je, Ye);
		return !n || !r ? null : {
			ms: 320,
			node: /* @__PURE__ */ y($, {
				from: n,
				to: r,
				ms: 300,
				children: /* @__PURE__ */ y(Xe, {})
			})
		};
	},
	order(e, t) {
		let n = e.data;
		if (typeof n?.id != "number" || n.side !== 0 && n.side !== 1 || typeof n.index != "number") return null;
		let r = e.rid ? t.anchor(`seat:${e.rid}`) : null, i = t.anchor(`order:${n.index}`);
		if (!i) return null;
		let a = r ?? Q(t, i.w, i.h) ?? i;
		return {
			ms: 400,
			hide: [`order:${n.index}`],
			node: /* @__PURE__ */ y($, {
				from: a,
				to: i,
				ms: 380,
				children: /* @__PURE__ */ y(K, { order: {
					id: n.id,
					side: n.side,
					flipped: !1
				} })
			})
		};
	},
	flip(e, t) {
		let n = e.data, r = typeof n?.index == "number" ? t.anchor(`order:${n.index}`) : null;
		return r ? {
			ms: 800,
			node: /* @__PURE__ */ y(C, {
				at: r,
				ms: 800
			})
		} : null;
	},
	ring(e, t) {
		w();
		let n = t.anchor("table"), r = n ? Math.max(64, Math.min(n.w * .18, n.h * .24)) : 64, i = Q(t, r, r);
		return i ? {
			ms: 760,
			node: /* @__PURE__ */ y("span", {
				className: "absolute grid place-items-center",
				style: {
					left: i.x,
					top: i.y,
					width: i.w,
					height: i.h
				},
				children: /* @__PURE__ */ y("span", {
					"aria-hidden": !0,
					className: "bell-ring",
					style: {
						fontSize: r * .75,
						lineHeight: 1
					},
					children: "🔔"
				})
			})
		} : {
			ms: 760,
			node: null
		};
	},
	penalty(e, t) {
		let n = e.data, r = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return !r || typeof n?.value != "number" ? null : {
			ms: 1100,
			node: /* @__PURE__ */ y(S, {
				at: r,
				ms: 1e3,
				children: /* @__PURE__ */ b("span", {
					className: "inline-flex items-center gap-0.5 text-danger",
					style: { fontSize: Math.max(16, Math.min(r.w, r.h) * .7) },
					children: [
						"+",
						n.value,
						/* @__PURE__ */ y("span", {
							"aria-hidden": !0,
							children: "😡"
						})
					]
				})
			})
		};
	}
};
//#endregion
//#region src/games/durian/game-over.tsx
function Qe({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = f(), s = d((e) => e.locale), c = t, l = Object.keys(c.anger), u = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? E(t, s) : e;
	}, p = (e) => g[(n.find((t) => t.rid === e)?.colorIndex ?? l.indexOf(e)) % g.length].hex, m = (t) => e.scores?.[t] ?? (c.anger[t] ?? []).reduce((e, t) => e + t, 0), h = c.lastRing, _ = h ? o(h.exhausted ? "games.durian.revealExhausted" : h.bust ? "games.durian.revealBust" : "games.durian.revealOk", {
		name: u(h.penalized),
		value: h.value
	}) : null;
	return /* @__PURE__ */ y("div", {
		className: "durian-over",
		style: { "--durian-result-players": e.ranking.length },
		children: /* @__PURE__ */ b("div", {
			className: "durian-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ y(T, {}),
				/* @__PURE__ */ b("header", {
					className: "durian-over-heading",
					children: [/* @__PURE__ */ y("span", {
						className: "durian-over-brand",
						"aria-hidden": !0,
						children: /* @__PURE__ */ y(ve, {
							size: 40,
							color: "white"
						})
					}), /* @__PURE__ */ b("div", { children: [/* @__PURE__ */ y("span", { children: o("games.durian.name") }), /* @__PURE__ */ y("h1", { children: o("session.result.title") })] })]
				}),
				/* @__PURE__ */ b("div", {
					className: "durian-over-content",
					children: [/* @__PURE__ */ b("section", {
						className: "durian-over-ranks",
						children: [/* @__PURE__ */ y("h2", { children: o("games.durian.angerTotal") }), /* @__PURE__ */ y("ol", {
							className: "durian-over-rank-list",
							children: e.ranking.map((t) => {
								let n = e.winner.includes(t), i = c.anger[t] ?? [], a = e.ranking.findIndex((e) => m(e) === m(t)) + 1;
								return /* @__PURE__ */ b("li", {
									className: `durian-over-rank ${n ? "durian-over-rank--winner" : ""}`,
									children: [
										/* @__PURE__ */ y("span", {
											className: "durian-over-place font-mono tabular-nums",
											style: { background: p(t) },
											children: a
										}),
										/* @__PURE__ */ b("strong", {
											className: "durian-over-name",
											title: u(t),
											children: [u(t), t === r && /* @__PURE__ */ b("small", { children: [
												" (",
												o("lobby.you"),
												")"
											] })]
										}),
										/* @__PURE__ */ b("span", {
											className: "durian-over-total font-mono tabular-nums",
											children: [/* @__PURE__ */ y("span", {
												"aria-hidden": !0,
												children: "😡"
											}), m(t)]
										}),
										/* @__PURE__ */ y("div", {
											className: "durian-over-history",
											"aria-label": o("games.durian.penaltyHistory"),
											children: i.length ? i.map((e, t) => /* @__PURE__ */ b("span", {
												className: "font-mono tabular-nums",
												"aria-label": o("games.durian.penaltyRound", {
													n: e,
													value: e
												}),
												children: ["+", e]
											}, t)) : /* @__PURE__ */ y("span", {
												className: "durian-over-unpunished",
												children: o("games.durian.noPenalties")
											})
										}),
										n && /* @__PURE__ */ y("span", {
											className: "durian-over-winner",
											role: "img",
											"aria-label": o("games.durian.winnerAria"),
											children: "★"
										})
									]
								}, t);
							})
						})]
					}), /* @__PURE__ */ b("section", {
						className: "durian-over-audit",
						children: [/* @__PURE__ */ y("h2", { children: o("games.durian.finalRound", { n: c.round }) }), /* @__PURE__ */ b("div", {
							className: "durian-over-audit-scroll",
							children: [
								_ && /* @__PURE__ */ y("p", {
									className: `durian-over-event ${h?.bust || h?.exhausted ? "durian-over-event--bust" : ""}`,
									children: _
								}),
								c.inventory && /* @__PURE__ */ y("div", {
									className: "durian-over-check",
									children: /* @__PURE__ */ y(Ie, { pub: c })
								}),
								c.inventory && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ y("h3", { children: o("games.durian.standingCards") }), /* @__PURE__ */ y("ul", {
									className: "durian-over-inventories",
									children: l.filter((e) => c.inventory?.[e] !== void 0).map((e) => /* @__PURE__ */ b("li", { children: [/* @__PURE__ */ b("span", {
										className: "durian-over-inventory-name",
										children: [
											/* @__PURE__ */ y("span", { style: { background: p(e) } }),
											/* @__PURE__ */ y("strong", {
												title: u(e),
												children: u(e)
											}),
											h?.by === e && /* @__PURE__ */ y("span", {
												"aria-label": o("games.durian.rangAria"),
												children: "🔔"
											})
										]
									}), /* @__PURE__ */ y("div", {
										className: "durian-over-inventory-piece",
										children: /* @__PURE__ */ y(Oe, { cardId: c.inventory[e] })
									})] }, e))
								})] }),
								c.gorillaAside.length > 0 && /* @__PURE__ */ b("div", {
									className: "durian-over-aside",
									children: [/* @__PURE__ */ y("h3", { children: o("games.durian.gorillaAsideTitle") }), c.gorillaAside.map((e) => {
										let t = P(e);
										return t ? /* @__PURE__ */ y("span", {
											className: "durian-over-gorilla",
											children: /* @__PURE__ */ y(W, {
												kind: t,
												compact: !0
											})
										}, e) : null;
									})]
								}),
								c.orders.length > 0 && /* @__PURE__ */ b("div", {
									className: "durian-over-order-area",
									children: [/* @__PURE__ */ b("h3", { children: [
										o("games.durian.ordersTitle"),
										" ",
										/* @__PURE__ */ y("span", {
											className: "font-mono tabular-nums",
											children: c.orders.length
										})
									] }), /* @__PURE__ */ y("ol", {
										className: "durian-over-orders",
										children: c.orders.map((e, t) => /* @__PURE__ */ y("li", { children: /* @__PURE__ */ y(K, { order: e }) }, t))
									})]
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ b("div", {
					className: "durian-over-actions",
					children: [
						i && /* @__PURE__ */ y("button", {
							type: "button",
							className: "btn-base text-white",
							style: { background: L.accent },
							onClick: i,
							children: o("session.result.playAgain")
						}),
						a && /* @__PURE__ */ y("button", {
							type: "button",
							className: "btn-quiet",
							onClick: a,
							children: o("session.result.backToLobby")
						}),
						!i && !a && /* @__PURE__ */ y("p", { children: o("session.result.waitHost") })
					]
				})
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/durian/entry.tsx
var $e = {
	definition: _e,
	View: Ae,
	bot: Ue,
	describe: Ge,
	llm: qe,
	fx: Ze,
	OverView: Qe,
	locales: {
		zh: {
			name: "榴莲忘贩",
			desc: "看得见别人的立牌,看不见自己的:接单,还是摇铃?",
			rules: "目标:有人愤怒值达到 7 时游戏结束,愤怒值最低的人获胜。\n准备:\n· 每人立起一张牌,牌面朝向其他所有人,只有自己看不到。\n流程(轮到你,二选一):\n· 接单:抽一张牌,选择其中半边作为新订单;抽到猩猩则改为翻开一张旧订单的另一面。\n· 摇铃:叫经理来对账,结束本轮。\n对账:\n· 把所有人的立牌相加作为库存,与全部订单逐种水果对比。\n· 任一水果的需求量超过库存 = 爆单,罚上一位行动的人。\n· 没有超卖 = 冤枉经理,罚摇铃的人。\n· 牌堆抽空时接单视同爆单,罚自己。\n猩猩立牌特效:🍌∞ 香蕉不限量;●●●✕ 三个一组的订单作废;0 无任何效果。\n罚分:每次被罚的愤怒值等于当前轮次号,越晚罚得越重。",
			roundShort: "第 {{n}} 轮",
			yourTurn: "轮到你",
			waiting: "等 {{name}} 行动…",
			orientPrompt: "选订单面",
			orientWaiting: "等 {{name}} 选订单面…",
			flipPrompt: "翻一张旧订单",
			flipWaiting: "{{name}} 抽到了猩猩…",
			revealBust: "爆单!{{name}} 愤怒 +{{value}}",
			revealOk: "冤枉经理!{{name}} 愤怒 +{{value}}",
			revealExhausted: "牌堆空了,{{name}} 愤怒 +{{value}}",
			confirm: "继续",
			confirmWait: "已确认 {{n}}/{{total}}",
			rangAria: "摇了铃",
			confirmedAria: "已确认",
			draw: "接一单",
			ring: "摇铃",
			effective: "生效",
			standingCards: "全员立牌",
			ordersTitle: "本轮订单",
			deck: "牌堆",
			auditing: "经理正在对账…",
			ringAria: "摇铃叫经理对账",
			orientAria: "选第 {{n}} 面",
			flipAria: "翻第 {{n}} 张订单",
			fruitCherry: "{{n}} 个樱桃",
			fruitBanana: "{{n}} 根香蕉",
			fruitGrape: "{{n}} 串葡萄",
			fruitDurian: "{{n}} 个榴莲",
			gorillaIgnoreTriple: "猩猩:三个一组的订单作废",
			gorillaNothing: "猩猩:白板",
			gorillaInfinityBanana: "猩猩:香蕉管够",
			myInventoryAria: "你的立牌(只有别人看得见)",
			orderFlippedAria: "被猩猩翻过的订单",
			fruitBust: "超卖",
			fruitOk: "够卖",
			angerTotal: "累计愤怒值",
			penaltyHistory: "受罚记录",
			penaltyRound: "第 {{n}} 轮：+{{value}}",
			noPenalties: "未受罚",
			finalRound: "末轮对账 · 第 {{n}} 轮",
			gorillaAsideTitle: "置旁猩猩",
			winnerAria: "获胜",
			errNotYourTurn: "现在轮不到你",
			errNoOrders: "还没有订单,不能摇铃",
			errBadOrder: "这张订单不能翻"
		},
		en: {
			name: "Durian",
			desc: "You see everyone's card but your own: take an order, or ring the bell?",
			rules: "Goal: when anyone reaches 7 anger, the game ends and the least angry player wins.\nSetup:\n· Each player stands one card upright, facing everyone else — only you cannot see your own.\nOn your turn, choose one:\n· Take an order: draw a card and choose which half of it becomes the new order; drawing a gorilla instead flips an old order to its other side.\n· Ring the bell: call the manager for an audit, ending the round.\nThe audit:\n· All standing cards are added up as stock and compared fruit by fruit against every order.\n· Any fruit oversold = a bust: the player who acted before you is punished.\n· Nothing oversold = a false alarm: you are punished.\n· Taking an order from an empty deck counts as a bust you caused yourself.\nGorilla standing cards: 🍌∞ bananas never run out; ●●●✕ orders of exactly three are void; 0 has no effect.\nPenalty: each punishment adds anger equal to the current round number — later mistakes cost more.",
			roundShort: "Round {{n}}",
			yourTurn: "Your turn",
			waiting: "Waiting for {{name}}…",
			orientPrompt: "Pick an order side",
			orientWaiting: "Waiting for {{name}} to pick a side…",
			flipPrompt: "Flip an old order",
			flipWaiting: "{{name}} drew a gorilla…",
			revealBust: "Bust! {{name}} anger +{{value}}",
			revealOk: "False alarm! {{name}} anger +{{value}}",
			revealExhausted: "Deck ran out, {{name}} anger +{{value}}",
			confirm: "Continue",
			confirmWait: "{{n}}/{{total}} confirmed",
			rangAria: "rang the bell",
			confirmedAria: "confirmed",
			draw: "Take order",
			ring: "Ring bell",
			effective: "Active",
			standingCards: "Standing cards",
			ordersTitle: "Orders this round",
			deck: "Deck",
			auditing: "The manager is auditing…",
			ringAria: "Ring the bell for an audit",
			orientAria: "Pick side {{n}}",
			flipAria: "Flip order {{n}}",
			fruitCherry: "{{n}} cherries",
			fruitBanana: "{{n}} bananas",
			fruitGrape: "{{n}} grapes",
			fruitDurian: "{{n}} durians",
			gorillaIgnoreTriple: "Gorilla: sets of three are void",
			gorillaNothing: "Gorilla: no effect",
			gorillaInfinityBanana: "Gorilla: unlimited bananas",
			myInventoryAria: "Your standing card (only others can see it)",
			orderFlippedAria: "Order flipped by a gorilla",
			fruitBust: "oversold",
			fruitOk: "in stock",
			angerTotal: "Total anger",
			penaltyHistory: "Penalties",
			penaltyRound: "Round {{n}}: +{{value}}",
			noPenalties: "No penalties",
			finalRound: "Final audit · Round {{n}}",
			gorillaAsideTitle: "Gorillas set aside",
			winnerAria: "Winner",
			errNotYourTurn: "Not your turn",
			errNoOrders: "No orders yet, cannot ring",
			errBadOrder: "That order cannot be flipped"
		}
	}
};
//#endregion
export { $e as default };
