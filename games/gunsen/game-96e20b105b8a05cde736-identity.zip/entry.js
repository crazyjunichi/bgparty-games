import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as l } from "@bgparty/sdk/fx/anchors";
import { GameScreen as u } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as ee } from "@bgparty/sdk/ui/phase-banner";
import { seatName as te } from "@bgparty/sdk/ui/player-strip";
import { DeltaNumber as ne } from "@bgparty/sdk/fx/delta-number";
import { Fragment as d, jsx as f, jsxs as p } from "react/jsx-runtime";
import { SheetFxProbe as re, SheetView as m } from "@bgparty/sdk/sheet-view";
import { Floater as h, FlySprite as g, PulseBox as _ } from "@bgparty/sdk/fx/primitives";
import { Confetti as ie } from "@bgparty/sdk/ui/confetti";
//#region src/games/gunsen/data.ts
var v = [
	"expand",
	"armory",
	"recruit",
	"influence"
], y = [
	"koku",
	"wood",
	"influence"
], b = [
	"#ba8c22",
	"#78b8ce",
	"#8f6caa",
	"#a32d36",
	"#4c8860",
	"#c65b36",
	"#263d65"
], x = (e, t, n, r, i = [], a = {}, o = [], s = 1) => ({
	id: e,
	column: t,
	base: n,
	extra: r,
	effects: i,
	stats: a,
	cost: o,
	costN: s
}), S = (e, t) => ({
	kind: "gain",
	resource: e,
	n: t
}), ae = [
	x(1, "expand", 5, 3, [S("koku", 1)], { reroll: 1 }),
	x(3, "expand", 3, 2, [S("koku", 2)], {}, ["influence", "wood"]),
	x(5, "expand", 3, 2, [S("wood", 2)], {}, ["influence", "koku"]),
	x(7, "expand", 4, 2, [S("wood", 1)], { armor: 1 }),
	x(10, "armory", 4, 3, [], {
		blood: 1,
		roll: 1
	}),
	x(12, "armory", 2, 1, [], {
		armor: 1,
		reroll: 1
	}),
	x(14, "armory", 2, 1, [], { keep: 1 }, [...y], 2),
	x(16, "armory", 3, 2, [], { strength: 1 }, [...y]),
	x(18, "influence", 7, 4, [S("influence", 1)]),
	x(20, "influence", 4, 2, [S("influence", 2)], {}, ["wood", "koku"]),
	x(22, "recruit", 7, 4, [{
		kind: "recruit",
		n: 1
	}]),
	x(24, "recruit", 4, 2, [{
		kind: "recruit",
		n: 2
	}], {}, [...y])
], oe = [
	{
		column: "any",
		effects: [],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "any",
		effects: [
			S("influence", 1),
			S("koku", 1),
			S("wood", 1)
		],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "influence",
		effects: [{
			kind: "deferred",
			mode: "diplomacy"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "any",
		effects: [S("wood", 2), {
			kind: "move",
			n: 1,
			mode: "tower"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "recruit",
		effects: [{
			kind: "recruit",
			n: 2,
			mode: "troopOrBuilding"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "expand",
		effects: [S("koku", 1), {
			kind: "move",
			n: 1
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "any",
		effects: [{
			kind: "kill",
			n: 1,
			mode: "assassination"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "influence",
		effects: [{
			kind: "deferred",
			mode: "conscription"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "any",
		effects: [],
		stats: {
			strength: 1,
			blood: 1,
			armor: 1
		},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "recruit",
		effects: [{
			kind: "dragonSpeed",
			n: 1
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "recruit",
		effects: [{
			kind: "tempest",
			n: 2
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "influence",
		effects: [S("wood", 2), {
			kind: "kill",
			n: 1,
			mode: "highGround"
		}],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "any",
		effects: [],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	},
	{
		column: "expand",
		effects: [
			S("wood", 1),
			S("koku", 1),
			{ kind: "buildingMove" }
		],
		stats: {},
		cost: [],
		costN: 0,
		base: 0,
		extra: 0
	}
];
ae.push(...oe.map((e, t) => ({
	...e,
	id: 26 + t
})));
var C = Object.fromEntries(ae.map((e) => [e.id, e])), se = [
	2,
	5,
	4,
	4,
	2,
	2,
	2,
	4,
	4,
	4,
	4,
	2,
	4,
	3,
	3,
	3,
	3,
	3,
	3,
	4,
	3,
	4,
	3,
	4,
	3,
	3,
	3
], w = [
	"Ikoma Tsanuri",
	"Matsu Gohei",
	"Matsu Tsuko",
	"Asahina Takako",
	"Daidoji Uji",
	"Doji Hotaru",
	"Moto Chagatai",
	"Utaku Kamoko",
	"Shinjo Altansarnai",
	"Bayushi Aramoro",
	"Bayushi Kachiko",
	"Yogo Kikuyo",
	"Togashi Mitsu",
	"Togashi Yokuni",
	"Mirumoto Hitomi",
	"Isawa Tadaka",
	"Kaito Kosori",
	"Shiba Tsukune",
	"Yasuki Taka",
	"Hida O-Ushi",
	"Hida Kisada",
	"The Shahadet",
	"Toturi the Black",
	"Yoritomo"
], ce = [
	{
		roll: 2,
		blood: 1
	},
	{ blood: 1 },
	{ strength: 2 },
	{ roll: -1 },
	{
		blood: 1,
		roll: 1
	},
	{
		strength: 1,
		reroll: 1
	},
	{ strength: 1 },
	{ blood: 1 },
	{},
	{ strength: 1 },
	{},
	{},
	{ roll: 1 },
	{},
	{
		strength: 1,
		armor: 2
	},
	{ armor: 1 },
	{},
	{
		keep: 1,
		blood: 1
	},
	{},
	{ blood: 1 },
	{
		reroll: 1,
		armor: 2
	},
	{ strength: 1 },
	{},
	{ strength: 3 }
], T = [
	{
		strength: 3,
		blood: 0,
		armor: 0
	},
	{
		strength: 2,
		blood: 1,
		armor: 0
	},
	{
		strength: 2,
		blood: 0,
		armor: 0
	},
	{
		strength: 1,
		blood: 0,
		armor: 1
	},
	{
		strength: 0,
		blood: 0,
		armor: 2
	},
	{
		strength: 0,
		blood: 1,
		armor: 0
	},
	{
		strength: 0,
		blood: 2,
		armor: 0
	},
	{
		strength: 1,
		blood: 1,
		armor: 0
	}
];
function le(e) {
	let t = [];
	return (e <= 3 ? [
		[
			4,
			6,
			8
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			2,
			4,
			6,
			8,
			10
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		]
	] : [
		[
			4,
			6,
			8
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			2,
			4,
			6,
			8,
			10
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			0,
			2,
			4,
			6,
			8,
			10,
			12
		],
		[
			1,
			3,
			5,
			7,
			9,
			11
		],
		[
			4,
			6,
			8
		]
	]).forEach((n, r) => n.forEach((n) => {
		let i = "plain", a = 2;
		(r % 2 == 1 && (n === 3 || n === 9) || (r === 2 || r === 6) && n === 6) && (i = "village"), ((r === 2 || r === 6) && n === 4 || r === 4 && n === 10) && (i = "shrine"), ((r === 2 || r === 6) && n === 8 || r === 4 && n === 2) && (i = "tower"), r === 4 && n === 6 && (i = "city"), ((r === 0 || r === 8) && n === 6 || (r === 2 || r === 6) && (n === 0 || n === 12)) && (i = "fort", e <= 3 && r === 0 && (a = 3), e > 3 && r === 2 && n === 12 && (a = 6), e > 3 && r === 6 && n === 12 && (a = 5)), t.push({
			id: `${r}.${n}`,
			q: r,
			t: n,
			kind: i,
			min: a
		});
	})), t;
}
function E(e, t) {
	return e.q === t.q ? Math.abs(e.t - t.t) === 2 : Math.abs(e.q - t.q) === 1 && Math.abs(e.t - t.t) === 1;
}
function D(e, t) {
	return Math.max(Math.abs(e.q - t.q), (Math.abs(e.q - t.q) + Math.abs(e.t - t.t)) / 2);
}
//#endregion
//#region src/games/gunsen/meta.ts
var ue = {
	id: "gunsen",
	tier: "alpha",
	mechanics: [
		"area-control",
		"engine-building",
		"drafting",
		"dice-rolling",
		"grid-movement"
	],
	interactionTags: [],
	nameKey: "games.gunsen.name",
	descKey: "games.gunsen.desc",
	rulesKey: "games.gunsen.rules",
	icon: "🏯",
	iconImg: "games/gunsen.webp",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/14883905504746083967/3F624DBA5882616B20D3666F5F307E1168F085DF/" },
	minPlayers: 2,
	maxPlayers: 6,
	accent: "#9e332c",
	releasedAt: "2026-11-04T21:55:35+08:00",
	search: {
		py: "junshanlanbochengzhizhan",
		init: "jslbczz"
	},
	hotseat: "cover"
}, de = t.discriminatedUnion("type", [t.object({
	type: t.literal("act"),
	id: t.string().min(1).max(800)
}).strict(), t.object({
	type: t.literal("tick"),
	now: t.number().finite()
}).strict()]), O = t.object({
	koku: t.number(),
	wood: t.number(),
	influence: t.number()
}), fe = t.object({
	rid: t.string(),
	clan: t.number(),
	fort: t.string(),
	resources: O,
	columns: t.object({
		expand: t.array(t.number()),
		armory: t.array(t.number()),
		recruit: t.array(t.number()),
		influence: t.array(t.number())
	}),
	nobles: t.array(t.number()),
	heroes: t.array(t.number()),
	retired: t.array(t.number()),
	specials: t.array(t.number()),
	tactics: t.array(t.number()),
	buildings: t.array(t.string()),
	villages: t.array(t.enum([
		"koku",
		"wood",
		"influence",
		"troop"
	])),
	achievements: t.array(t.string()),
	goals: t.array(t.number()),
	heroTokens: t.record(t.string(), t.number()),
	reserve: t.number()
}), pe = t.object({
	id: t.string(),
	q: t.number(),
	t: t.number(),
	kind: t.enum([
		"plain",
		"village",
		"shrine",
		"tower",
		"city",
		"fort"
	]),
	min: t.number(),
	shrine: t.string(),
	village: t.boolean(),
	armies: t.record(t.string(), t.number()),
	heroes: t.record(t.string(), t.array(t.number())),
	building: t.object({
		owner: t.string(),
		kind: t.enum(["unique", "camp"])
	}).nullable(),
	fort: t.string()
}), me = t.object({
	strength: t.number(),
	blood: t.number(),
	armor: t.number(),
	roll: t.number(),
	keep: t.number(),
	reroll: t.number()
}), he = t.object({
	space: t.string(),
	attacker: t.string(),
	defender: t.string(),
	stage: t.string(),
	initial: t.record(t.string(), t.number()),
	stats: t.record(t.string(), me),
	dice: t.record(t.string(), t.array(t.number())),
	kept: t.record(t.string(), t.array(t.number())),
	disabled: t.array(t.number()),
	rerolls: t.record(t.string(), t.number()),
	changed: t.array(t.string()),
	double: t.record(t.string(), t.number()),
	militia: t.record(t.string(), t.number()),
	forced: t.string(),
	winner: t.string(),
	loser: t.string(),
	kills: t.record(t.string(), t.number()),
	earlyKills: t.record(t.string(), t.number())
}), ge = t.object({
	id: t.string(),
	key: t.string(),
	params: t.record(t.string(), t.union([t.string(), t.number()])),
	group: t.string(),
	space: t.string(),
	card: t.number(),
	hero: t.number(),
	n: t.number(),
	value: t.number()
}), _e = t.object({
	phase: t.string(),
	active: t.string(),
	acting: t.string(),
	turn: t.number(),
	serial: t.number(),
	players: t.array(fe),
	map: t.array(pe),
	market: t.array(t.number()),
	deckCount: t.number(),
	upgrades: t.record(t.string(), t.string()),
	cityOpen: t.boolean(),
	prompt: t.string(),
	battle: he.nullable(),
	log: t.array(t.object({
		key: t.string(),
		rid: t.string(),
		params: t.record(t.string(), t.union([t.string(), t.number()]))
	})),
	winner: t.string()
}), ve = t.object({
	choices: t.array(ge),
	tactics: t.array(t.number())
}), k = {
	effect: 440,
	move: 650,
	roll: 950,
	kills: 800,
	result: 950
}, ye = /* @__PURE__ */ new Set([
	"start",
	"deferred",
	"turnBattle",
	"battlePrepare",
	"battleAbilities",
	"roll",
	"battleTotals",
	"battleKills",
	"battleOutcome",
	"battleEnd",
	"endEffects",
	"claimTerritories",
	"endTurn",
	"activateCard"
]), A = (e, t, n = {}) => ({
	kind: e,
	rid: t,
	...n
}), j = (e, t) => e.players.find((e) => e.rid === t), M = (e, t) => e.map.find((e) => e.id === t), N = (e, t) => e.map.reduce((e, n) => e + (n.armies[t] ?? 0), 0), P = (e, t) => e.armies[t] ?? 0, be = (e, t, n) => {
	let r = e.players.filter((e) => P(t, e.rid) > 0);
	return r.findIndex((e) => e.rid === n) * 78 - (r.length > 1 ? 35 : 0);
}, F = (e, t) => Object.keys(e.armies).filter((n) => n !== t && e.armies[n] > 0), xe = (e, t) => P(e, t) > 0 && F(e, t).length === 0;
function I(e) {
	let t = Object.keys(e.armies).filter((t) => e.armies[t] > 0);
	return t.length === 1 ? t[0] : t.length === 0 ? e.building?.owner ?? "" : "";
}
var Se = (e, t, n) => e.map.some((r) => r.building?.kind === "unique" && j(e, r.building.owner).clan === n && I(r) === t), L = (e, t, n) => j(e, t).tactics.includes(n), R = (e, t, n) => M(e, n).heroes[t] ?? [], z = (e, t, n, r = []) => n.fort === t || n.building?.kind === "camp" ? 15 : 5 + (L(e, t, 13) ? 2 : 0) + ([...R(e, t, n.id), ...r].includes(22) ? 2 : 0), Ce = (e, t, n) => n.fort === t ? 24 : L(e, t, 12) ? 2 : 1, we = (e, t, n = "", r = "") => e.map.filter((i) => r ? i.id === r : n === "existingArmy" ? P(i, t) > 0 : n === "troopOrBuilding" ? P(i, t) > 0 || !!i.building && I(i) === t : i.fort === t || i.building && I(i) === t || n === "army" && P(i, t) > 0 ? !0 : L(e, t, 5) && !i.fort && !F(i, t).length && e.map.some((e) => (e.fort === t || e.building && I(e) === t) && E(i, e))).filter((n) => P(n, t) < z(e, t, n));
function B(t, n, r) {
	let i = [...n];
	for (let n = i.length - 1; n > 0; n--) {
		let a = e(r, t.rngCursor++, n + 1);
		[i[n], i[a]] = [i[a], i[n]];
	}
	return i;
}
function Te(e, t) {
	for (; e.market.length < 5 && (e.deck.length || (e.deck = B(e, e.discard, t), e.discard = []), e.deck.length);) e.market.push(e.deck.pop());
}
function V(e, ...t) {
	e.tasks.unshift(...t);
}
function H(e, t, n, r = {}) {
	e.log.push({
		key: t,
		rid: n,
		params: r
	}), e.log.length > 180 && e.log.shift();
}
function U(e, t, n, r) {
	j(e, t).resources[n] += r, t === e.active && n === "influence" && (e.influenceGained += r);
}
function W(e, t, n, r) {
	return r = Math.max(0, Math.min(r, 15 - N(e, t), z(e, t, n) - P(n, t))), n.armies[t] = P(n, t) + r, r;
}
function G(e, t, n, r) {
	for (let r of e.map) r.heroes[t] = (r.heroes[t] ?? []).filter((e) => e !== n);
	if (r) {
		let i = M(e, r);
		i.heroes[t] = [...i.heroes[t] ?? [], n];
	}
}
function K(e, t, n = "0,0,0") {
	n.split(",").forEach((n, r) => j(e, t).resources[y[r]] -= Number(n));
}
function q(e, t, n) {
	let r = j(e, t), i = y.flatMap((e) => Array.from({ length: n[e] ?? 0 }, () => e)), a = [[
		0,
		0,
		0
	]];
	for (let n of i) {
		let i = [y.map((e) => +(e === n))];
		n !== "influence" && L(e, t, 6) && i.push([
			0,
			0,
			1
		]), n !== "koku" && L(e, t, 15) && i.push([
			2,
			0,
			0
		]), a = a.flatMap((e) => i.map((t) => t.map((t, n) => t + e[n]))).filter((e) => e.every((e, t) => e <= r.resources[y[t]])), a = [...new Map(a.map((e) => [e.join(","), e])).values()];
	}
	return a.map((e) => e.join(","));
}
var Ee = (e, t, n, r) => {
	let i = [], a = (e, t, r) => {
		if (!e) {
			i.push(r);
			return;
		}
		for (let i = t; i < n.length; i++) a(e - 1, i, {
			...r,
			[n[i]]: (r[n[i]] ?? 0) + 1
		});
	};
	return a(r, 0, {}), [...new Set(i.flatMap((n) => q(e, t, n)))];
};
function De(e, t, n) {
	let r = {
		phase: "setup",
		active: "",
		turn: 1,
		serial: 0,
		seed: n,
		players: [],
		map: [],
		deck: [],
		discard: [],
		market: [],
		privateTactics: {},
		villages: {},
		upgrades: {
			expand: "",
			armory: "",
			recruit: "",
			influence: ""
		},
		cityOpen: !1,
		tasks: [],
		battle: null,
		movementEnded: !1,
		influenceGained: 0,
		deferred: [],
		rngCursor: 0,
		winner: "",
		log: [],
		beatMs: k.effect
	}, i = B(r, t, n), a = B(r, Array.from({ length: 13 }, (e, t) => t), n);
	r.players = i.map((e, t) => ({
		rid: e,
		clan: -1,
		fort: "",
		resources: {
			koku: t === 0 ? 3 : 4,
			wood: t >= 3 ? 2 : 1,
			influence: t === 5 ? 2 : 1
		},
		columns: {
			expand: [],
			armory: [],
			recruit: [],
			influence: []
		},
		nobles: [],
		heroes: [],
		retired: [],
		specials: [],
		tactics: [],
		buildings: [],
		villages: [],
		achievements: [],
		goals: [],
		heroTokens: {},
		reserve: 15
	}));
	for (let e of r.players) r.privateTactics[e.rid] = a.splice(0, 2);
	let o = B(r, [
		"armory",
		"recruit",
		"influence"
	], n), s = B(r, [
		"koku",
		"koku",
		"koku",
		"wood",
		"wood",
		"wood",
		"influence",
		"influence",
		"influence",
		"troop",
		"troop",
		"troop"
	], n);
	return r.map = le(t.length).map((e) => ({
		...e,
		shrine: e.kind === "shrine" ? o.pop() : "",
		village: e.kind === "village",
		armies: {},
		heroes: {},
		building: null,
		fort: ""
	})), r.map.filter((e) => e.village).forEach((e) => r.villages[e.id] = s.pop()), r.deck = B(r, ae.filter((e) => e.id < 26).flatMap((e) => Array.from({ length: e.base + (t.length >= 5 ? e.extra : 0) }, () => e.id)), n), Te(r, n), r.active = i[0], r.tasks = i.flatMap((e) => [A("clan", e), A("fort", e)]), r.tasks.push(A("start", i[0])), {
		state: r,
		fx: []
	};
}
var Oe = (e) => Array.from({ length: 1 << e }, (e, t) => t), ke = (e) => e.toString(2).replaceAll("0", "").length;
function Ae(e, t) {
	return e.map.filter((n) => (n.fort === t || xe(n, t)) && R(e, t, n.id).length < Ce(e, t, n));
}
function J(e, t, n) {
	let r = j(e, t);
	r.achievements.includes(n) || (r.achievements.push(n), H(e, "achievement", t, { achievement: n }));
}
function je(e, t, n, r = !1) {
	let i = j(e, t), a = e.map.filter((n) => xe(n, t) && (!e.battle || n.id !== e.battle.space)), o = M(e, i.fort), s = (e) => P(e, t), c = (e) => a.some((t) => t.kind === e && s(t) >= 2 && a.filter((e) => E(t, e) && s(e) >= 2).length >= 2);
	switch (n) {
		case 0: return N(e, t) === 15 && !(e.battle && P(M(e, e.battle.space), t) > 0);
		case 2: return a.filter((e) => s(e) >= 2 && D(e, o) >= 4).length >= 2;
		case 3: return r && t === e.active && i.resources.koku >= 8;
		case 5: return c("village");
		case 6: return a.reduce((e, t) => e + s(t), 0) >= 9 && !e.map.some((e) => (e.fort || e.building) && s(e) > 0);
		case 8: return a.filter((n) => s(n) >= 2 && e.map.some((e) => (e.fort && e.fort !== t || e.building && e.building.owner !== t) && (e.id === n.id || E(n, e)))).length >= 3;
		case 10: return c("tower");
		case 11: return a.filter((e) => e.kind === "village" && s(e) >= 3).length >= 2;
		case 12:
		case 19: return c("shrine");
		case 13: return a.filter((e) => e.id !== i.fort).length >= 6;
		case 15: {
			let t = /* @__PURE__ */ new Set([i.fort]), n = !0;
			for (; n;) {
				n = !1;
				for (let r of a) !t.has(r.id) && e.map.some((e) => t.has(e.id) && E(r, e)) && (t.add(r.id), n = !0);
			}
			return a.some((e) => e.kind === "city" && t.has(e.id));
		}
		case 16: return r && t === e.active && i.resources.wood >= 7;
		case 20: return a.filter((e) => e.building && s(e) >= 3).length >= 2;
		default: return !1;
	}
}
function Me(e, t = !1) {
	if (e.phase === "setup" || e.winner) return;
	for (let n of e.players) if (n.reserve = 15 - N(e, n.rid), n.buildings.length === 2 && J(e, n.rid, "buildings"), n.tactics.length === 3 && J(e, n.rid, "tactics"), n.nobles.length === 3 && J(e, n.rid, "nobles"), n.villages.length === 3 && J(e, n.rid, "villages"), e.map.filter((t) => t.kind === "shrine" && t.id !== e.battle?.space && xe(t, n.rid)).length >= 2 && J(e, n.rid, "shrines"), e.map.some((e) => e.kind === "city" && P(e, n.rid) > 0) || (n.achievements = n.achievements.filter((e) => e !== "holdCity")), n.goals.length < 2 && !e.tasks.some((e) => e.kind === "goal" && e.rid === n.rid)) {
		let r = [
			0,
			1,
			2
		].map((e) => n.clan * 3 + e).filter((r) => !n.goals.includes(r) && je(e, n.rid, r, t));
		r.length && V(e, A("goal", n.rid, { mode: r.join(",") }));
	}
	let n = e.players.filter((e) => e.achievements.length >= 7);
	n.length && (e.winner = n.find((t) => t.rid === e.active)?.rid ?? n[0].rid, e.phase = "done", e.tasks = [], H(e, "victory", e.winner));
}
function Ne(e, t, n) {
	let r = [...j(e, t).columns[n]].reverse().map((e) => A("activateCard", t, {
		card: e,
		col: n
	}));
	return n === "expand" && r.push(A("expandGain", t), A("build", t), A("buyTactic", t)), n === "recruit" && r.push(A("recruit", t, { n: e.upgrades.recruit === t ? 2 : 1 })), n === "influence" && r.push(A("gain", t, {
		mode: "influence",
		n: e.upgrades.influence === t ? 2 : 1
	})), n !== "expand" && r.push(A("move", t, {
		n: 1,
		col: n
	}), A("extraMove", t, { col: n })), (n === "armory" && L(e, t, 0) || (n === "recruit" || n === "influence") && L(e, t, 2)) && r.push(A("move", t, {
		n: 1,
		col: n
	})), r.push(A("deferred", t)), r;
}
function Pe(e, t, n, r) {
	return A(e.kind, t, {
		n: e.n,
		col: n,
		mode: e.resource ?? e.mode,
		card: r
	});
}
function Fe(e, t, n, r, i) {
	return !(n.kind === "fort" && n.fort !== t || P(n, t) + r > z(e, t, n, i) || R(e, t, n.id).length + i.length > Ce(e, t, n) || n.kind === "city" && !e.cityOpen && r + Object.values(j(e, t).columns).flat().reduce((e, t) => e + (C[t].stats.strength ?? 0), 0) + i.reduce((e, t) => e + (ce[t].strength ?? 0), 0) < 5);
}
function Ie(e, t) {
	return Se(e, t, 3) ? ["0,0,0"] : q(e, t, { influence: 1 });
}
function Le(e, t, n, r, i) {
	let a = [];
	for (let o of e.map) if (o.id !== n.id && Fe(e, t.rid, o, r, i)) {
		if (t.mode === "tower") {
			o.kind === "tower" && a.push({
				dest: o,
				mode: "orderTower",
				pay: "0,0,0"
			});
			continue;
		}
		if (t.mode === "afterTower") {
			if ((n.fort === t.rid || n.kind === "tower") && (o.fort === t.rid || o.kind === "tower")) for (let n of Ie(e, t.rid)) a.push({
				dest: o,
				mode: "afterTower",
				pay: n
			});
			continue;
		}
		if (E(n, o) && a.push({
			dest: o,
			mode: "normal",
			pay: "0,0,0"
		}), t.mode !== "mustNormal" && t.mode !== "kamokoStep" && (n.fort === t.rid || n.kind === "tower") && (o.fort === t.rid || o.kind === "tower") && Re(e, t, n, o, r, i)) for (let n of Ie(e, t.rid)) a.push({
			dest: o,
			mode: "beforeTower",
			pay: n
		});
		if (n.building?.kind === "unique" && j(e, n.building.owner).clan === 2 && I(n) === t.rid && !Object.values(o.armies).some((e) => e > 0)) for (let n of q(e, t.rid, { koku: 1 })) a.push({
			dest: o,
			mode: "stable",
			pay: n
		});
	}
	return a;
}
function Re(e, t, n, r, i, a) {
	if (F(r, t.rid).length) return !0;
	let o = structuredClone(e);
	return M(o, n.id).armies[t.rid] -= i, M(o, r.id).armies[t.rid] = P(r, t.rid) + i, a.forEach((e) => G(o, t.rid, e, r.id)), o.tasks = [A("move", t.rid, {
		mode: "mustNormal",
		space: t.space ? r.id : void 0
	})], qe(o).some((e) => e.command.op === "selectArmy");
}
var Y = (e, t) => e.battle ? R(e, t, e.battle.space).filter((t) => !e.battle.disabled.includes(t)) : [];
function ze(e, t, n, r, i) {
	let a = e.battle;
	if (!a) return;
	let o = j(e, t.rid), s = M(e, a.space), c = Y(e, t.rid);
	if (t.kind === "moto" && (o.heroes.includes(6) && !R(e, t.rid, a.space).includes(6) && R(e, t.rid, a.space).length === 0 && n("moto", "bringMoto", {}, { hero: 6 }), i()), t.kind === "aramoro" && (r("protectHero", "protectHero", q(e, t.rid, { influence: 1 })), n("disableHeroes", "disableHeroes")), t.kind === "heroAbility") {
		c.includes(13) && s.kind !== "city" && n("yokuni", "sacrificeYokuni", {}, {
			hero: 13,
			value: 5
		});
		for (let n of [15, 18]) c.includes(n) && !((t.mask ?? 0) & 1 << n) && r("heroToken", "empowerHero", q(e, t.rid, n === 15 ? { influence: 1 } : { koku: 1 }), { n }, { hero: n });
		i();
	}
	if (t.kind === "militia") {
		if (L(e, t.rid, 21) && o.villages.length) for (let t of e.map.filter((e) => e.kind === "village" && !e.village && !Object.values(e.armies).some((e) => e > 0))) for (let e = 0; e < o.villages.length; e++) n("militia", "returnVillage", {
			a: t.id,
			n: e
		}, {
			space: t.id,
			params: { resource: o.villages[e] },
			value: 1
		});
		i();
	}
	if (t.kind === "reroll") {
		let e = a.dice[t.rid] ?? [];
		if ((a.rerolls[t.rid] ?? 0) > 0) for (let t = 1; t < 1 << e.length; t++) n("reroll", "rerollDice", { mask: t }, {
			params: { dice: e.map((e, n) => t & 1 << n ? n + 1 : 0).filter(Boolean).join(",") },
			n: t
		});
		n("finishReroll", "keepDice");
	}
	if (t.kind === "keep") {
		let e = a.dice[t.rid] ?? [], r = Math.min(a.stats[t.rid].keep, e.length);
		for (let t of Oe(e.length).filter((e) => ke(e) === r)) n("keep", "keepTheseDice", { mask: t }, {
			params: { dice: e.map((e, n) => t & 1 << n ? n + 1 : 0).filter(Boolean).join(",") },
			n: t
		});
	}
	if (t.kind === "strategize") {
		for (let e = 0; e < (a.kept[t.rid] ?? []).length; e++) for (let t = 0; t < 8; t++) n("strategize", "changeDie", {
			x: e,
			n: t
		}, {
			n: t,
			params: {
				die: e + 1,
				face: t
			}
		});
		i();
	}
	if (t.kind === "double" && (a.kept[t.rid] ?? []).forEach((e, t) => n("double", "doubleDie", { n: t }, { params: { die: t + 1 } })), t.kind === "rebirth") for (let r of we(e, t.rid).filter((e) => e.fort === t.rid || e.building)) n("rebirth", "rebirthAt", { a: r.id }, {
		space: r.id,
		value: 2
	});
	if (t.kind === "battleReward" && (n("battleAchievement", "claimAttack", {}, { value: o.achievements.includes("attack2") ? 0 : 8 }), o.goals.length < 2)) for (let r of Be(e, t.rid).filter((e) => !o.goals.includes(e))) n("battleGoal", "claimGoal", { n: r }, {
		n: r,
		params: { goal: r },
		value: 9
	});
	if (t.kind === "steal" && (j(e, a.loser).villages.forEach((e, t) => n("steal", "stealVillage", { n: t }, { params: { resource: e } })), (!He(e, a.winner) || !j(e, a.loser).villages.length) && i()), t.kind === "retreat") {
		let r = P(s, t.rid), i = R(e, t.rid, a.space);
		for (let o of e.map.filter((e) => e.id !== a.space && (e.fort === t.rid || e.building && I(e) === t.rid))) P(o, t.rid) + r <= z(e, t.rid, o, i) && R(e, t.rid, o.id).length + i.length <= Ce(e, t.rid, o) && n("retreat", "retreatTo", { a: o.id }, { space: o.id });
	}
}
function Be(e, t) {
	let n = e.battle, r = j(e, t), i = M(e, n.space), a = n.winner === t, o = n.initial[t], s = Object.values(n.initial).reduce((e, t) => e + t, 0), c = [];
	return a && r.clan === 0 && e.map.some((e) => e.kind === "city" && E(i, e)) && c.push(1), a && r.clan === 1 && e.map.some((e) => e.kind === "city" && E(i, e)) && c.push(4), a && r.clan === 2 && ![
		"city",
		"shrine",
		"tower"
	].includes(i.kind) && c.push(7), !a && n.loser === t && r.clan === 3 && o > n.initial[t === n.attacker ? n.defender : n.attacker] && c.push(9), !n.winner && n.loser !== t && r.clan === 4 && c.push(14), a && r.clan === 5 && s <= 6 && c.push(17), a && r.clan === 6 && o <= 3 && c.push(18), c;
}
function Ve(e, t) {
	let n = e.battle, r = M(e, n.space), i = j(e, t), a = Y(e, t), o = {
		strength: P(r, t),
		blood: 0,
		armor: 0,
		roll: e.upgrades.armory === t ? 4 : 3,
		keep: 2,
		reroll: 0
	}, s = (e) => {
		for (let t of Object.keys(e)) o[t] += e[t] ?? 0;
	};
	for (let e of Object.values(i.columns).flat()) s(C[e].stats);
	for (let e of a) s(ce[e]);
	t === n.defender && r.kind === "city" && s({
		armor: 1,
		blood: 1
	}), L(e, t, 1) && o.keep++, L(e, t, 19) && o.roll--, L(e, t, 25) && [
		"shrine",
		"tower",
		"city"
	].includes(r.kind) && (o.roll += 2), Se(e, t, 6) && (o.reroll += e.map.filter((e) => e.building && I(e) === t).length), Object.values(i.columns).flat().includes(38) && t === n.defender && (o.strength += 2), a.includes(11) && t === n.attacker && (o.strength += 2), a.includes(16) && (r.kind === "shrine" || e.map.some((e) => e.kind === "shrine" && E(r, e))) && s({
		strength: 2,
		blood: 1
	});
	for (let e of [15, 18]) a.includes(e) && (o.strength += i.heroTokens[String(e)] ?? 0);
	return a.includes(19) && n.initial[t] < n.initial[t === n.attacker ? n.defender : n.attacker] && (o.strength += P(r, t)), o.strength += n.militia[t] ?? 0, o.roll = Math.max(0, Math.min(6, o.roll)), o.keep = Math.max(0, o.keep), o;
}
function He(e, t) {
	return !!t && P(M(e, e.battle.space), t) > 0;
}
function Ue(e) {
	let t = e.battle, n = M(e, t.space), r = [t.attacker, t.defender];
	for (let i of r) {
		let r = i === t.attacker ? t.defender : t.attacker, a = Y(e, r), o = Y(e, i).includes(11) && i === t.attacker ? 0 : t.stats[r].blood, s = a.includes(1) ? 0 : t.stats[i].armor;
		t.kills[i] = Math.min(P(n, i), Math.max(0, o - s));
	}
	let i = r.some((t) => Y(e, t).includes(4));
	for (let a of r) n.armies[a] = P(n, a) - t.kills[a], i && (t.stats[a].strength -= t.kills[a] * (Y(e, a).includes(19) && t.initial[a] < t.initial[a === t.attacker ? t.defender : t.attacker] ? 2 : 1));
}
function We(e, t, n) {
	let r = M(e, t.from), i = M(e, n.a), a = R(e, t.rid, r.id).filter((e, n) => (t.mask ?? 0) & 1 << n), o = t.n;
	if (K(e, t.rid, n.pay), r.armies[t.rid] -= o, i.armies[t.rid] = P(i, t.rid) + o, a.forEach((n) => G(e, t.rid, n, i.id)), H(e, "moved", t.rid, {
		from: r.id,
		to: i.id,
		n: o
	}), F(i, t.rid).length ? (e.movementEnded = !0, e.battle = {
		space: i.id,
		attacker: t.rid,
		defender: F(i, t.rid)[0],
		stage: "pending",
		initial: {},
		stats: {},
		dice: {},
		kept: {},
		disabled: [],
		rerolls: {},
		changed: [],
		double: {},
		militia: {},
		forced: "",
		winner: "",
		loser: "",
		kills: {},
		earlyKills: {}
	}) : i.kind === "city" && !e.cityOpen && (e.cityOpen = !0, e.movementEnded = !0), !e.movementEnded) {
		if (n.b === "beforeTower") V(e, A("move", t.rid, {
			col: t.col,
			space: t.space ? i.id : void 0,
			mode: "mustNormal"
		}));
		else if (n.b !== "afterTower" && n.b !== "orderTower") {
			let n = [];
			a.includes(7) && t.mode !== "kamokoStep" && n.push(A("kamoko", t.rid, {
				space: i.id,
				n: o,
				movingHeroes: a,
				maxTroops: o,
				col: t.col
			})), t.mode !== "mustNormal" && t.mode !== "kamokoStep" && n.push(A("move", t.rid, {
				mode: "afterTower",
				col: t.col
			})), V(e, ...n);
		}
	}
	L(e, t.rid, 11) && V(e, A("plow", t.rid, { space: i.id }));
}
function Ge(e) {
	let t = e.battle, n = M(e, t.space), r = t.forced || (t.stats[t.attacker].strength >= t.stats[t.defender].strength ? t.attacker : t.defender);
	t.loser = r === t.attacker ? t.defender : t.attacker, t.winner = He(e, r) ? r : "", t.stage = "result";
	let i = [];
	for (let n of [t.attacker, t.defender]) {
		let r = j(e, n), a = Be(e, n).filter((e) => !r.goals.includes(e));
		t.winner === n && t.attacker === n ? i.push(A("battleReward", n)) : a.length && r.goals.length < 2 && i.push(A("goal", n, { mode: a.join(",") }));
		let o = n === t.attacker ? t.defender : t.attacker, s = (t.kills[o] ?? 0) + (t.earlyKills[o] ?? 0);
		L(e, n, 4) && U(e, n, "koku", s), Object.values(r.columns).flat().includes(26) && s > 0 && i.push(A("recruit", n, { n: s }));
	}
	t.winner && i.push(A("steal", t.winner)), P(n, t.loser) > 0 && i.push(A("retreat", t.loser));
	for (let r of [t.attacker, t.defender]) {
		if (P(n, r) === 0) for (let t of R(e, r, n.id)) i.push(A("rescueHero", r, { hero: t }));
		Y(e, r).includes(2) && P(n, r) > 0 && r !== t.loser && i.push(A("tsuko", r, { hero: 2 }));
	}
	i.push(A("battleEnd", t.attacker)), V(e, ...i), H(e, "battleResult", t.winner || r, {
		winner: t.winner,
		attacker: t.stats[t.attacker].strength,
		defender: t.stats[t.defender].strength
	});
}
function Ke(t, n, r) {
	let i = j(t, n.rid), a = t.battle;
	switch (n.kind) {
		case "start":
			t.phase = "turns", t.active = n.rid, V(t, A("draft", n.rid));
			break;
		case "deferred":
			if (n.card !== void 0) {
				t.deferred.push(n.card);
				break;
			}
			for (let e of t.deferred) {
				e === 28 && U(t, n.rid, "koku", t.influenceGained), e === 33 && t.influenceGained && V(t, A("recruit", n.rid, { n: t.influenceGained }));
				for (let t of v) i.columns[t] = i.columns[t].filter((t) => t !== e);
			}
			t.deferred = [];
			break;
		case "turnBattle":
			a && (a.stage = "preparation", V(t, A("moto", a.defender), A("moto", a.attacker), A("battlePrepare", a.attacker)));
			break;
		case "battlePrepare":
			if (a) {
				let e = M(t, a.space);
				a.initial = {
					[a.attacker]: P(e, a.attacker),
					[a.defender]: P(e, a.defender)
				};
				let n = [a.defender, a.attacker], r = [];
				for (let e of n) R(t, e, a.space).includes(9) && r.push(A("aramoro", e === a.attacker ? a.defender : a.attacker));
				r.push(...n.flatMap((e) => [A("heroAbility", e), A("militia", e)]), A("battleAbilities", a.attacker)), V(t, ...r);
			}
			break;
		case "battleAbilities":
			if (a) {
				let e = M(t, a.space), n = {
					[a.attacker]: 0,
					[a.defender]: 0
				};
				for (let e of [a.attacker, a.defender]) {
					let r = e === a.attacker ? a.defender : a.attacker, i = Y(t, e);
					i.includes(8) && e === a.attacker && n[r]++, i.includes(10) && n[r]++, i.includes(21) && a.initial[e] < a.initial[r] && (n[r] += 2);
				}
				if (!a.forced) for (let t of [a.attacker, a.defender]) a.earlyKills[t] = Math.min(P(e, t), n[t]), e.armies[t] -= a.earlyKills[t];
				for (let n of [a.attacker, a.defender]) {
					let r = Y(t, n);
					r.includes(22) && W(t, n, e, 1), r.includes(10) && (W(t, n, e, 1), G(t, n, 10, j(t, n).fort));
				}
				for (let e of [a.attacker, a.defender]) a.stats[e] = Ve(t, e), a.rerolls[e] = a.stats[e].reroll;
				a.forced ? (a.kills = {
					[a.attacker]: 0,
					[a.defender]: 0
				}, V(t, A("battleOutcome", a.attacker))) : V(t, A("roll", a.defender), A("roll", a.attacker), A("battleTotals", a.attacker)), a.stage = "dice";
			}
			return { kind: "battleStart" };
		case "roll": return a && (a.dice[n.rid] = Array.from({ length: a.stats[n.rid].roll }, () => e(r, t.rngCursor++, 8)), V(t, A("reroll", n.rid))), {
			kind: "roll",
			data: { dice: a?.dice[n.rid] ?? [] }
		};
		case "battleTotals":
			if (a) {
				for (let e of [a.attacker, a.defender]) for (let [t, n] of (a.kept[e] ?? []).entries()) {
					let r = T[n], i = a.double[e] === t ? 2 : 1;
					for (let t of [
						"strength",
						"blood",
						"armor"
					]) a.stats[e][t] += r[t] * i;
				}
				for (let e of [a.attacker, a.defender]) Y(t, e).includes(12) && (a.stats[e].strength += a.stats[e === a.attacker ? a.defender : a.attacker].blood);
				V(t, A("battleKills", a.attacker));
			}
			break;
		case "battleKills":
			if (a) {
				Ue(t), a.stage = "kills";
				let e = [];
				for (let n of [a.attacker, a.defender]) L(t, n, 23) && a.kills[n] && e.push(A("rebirth", n, { n: a.kills[n] }));
				e.push(A("battleOutcome", a.attacker)), V(t, ...e);
			}
			return {
				kind: "kills",
				data: { kills: a?.kills ?? {} }
			};
		case "battleOutcome": return a && Ge(t), {
			kind: "battleResult",
			data: { winner: a?.winner ?? "" }
		};
		case "battleEnd":
			t.battle = null;
			break;
		case "endEffects":
			for (let e of t.map) {
				if (I(e) !== n.rid || e.building?.kind !== "unique") continue;
				let r = j(t, e.building.owner).clan;
				r === 0 && W(t, n.rid, e, 1), r === 1 && U(t, n.rid, "koku", 2);
			}
			i.heroes.includes(23) && V(t, A("yoritomo", n.rid)), Me(t, !0);
			break;
		case "claimTerritories":
			for (let e of t.map.filter((e) => xe(e, n.rid))) {
				if (e.village) {
					let r = t.villages[e.id];
					r === "troop" ? W(t, n.rid, M(t, i.fort), 1) : U(t, n.rid, r, 1), i.villages.length < 3 && i.villages.push(r), e.village = !1, delete t.villages[e.id], H(t, "villageClaimed", n.rid, {
						resource: r,
						space: e.id
					});
				}
				e.kind === "shrine" && (t.upgrades[e.shrine] = n.rid), e.kind === "city" && (t.upgrades.expand = n.rid, J(t, n.rid, "city"), J(t, n.rid, "holdCity"));
			}
			Me(t, !0);
			break;
		case "endTurn":
			for (let e of t.players) W(t, e.rid, M(t, e.fort), Math.max(0, 3 - N(t, e.rid)));
			Te(t, r), t.active = t.players[(t.players.findIndex((e) => e.rid === t.active) + 1) % t.players.length].rid, t.turn++, t.movementEnded = !1, t.influenceGained = 0, t.deferred = [], V(t, A("draft", t.active));
			break;
		case "activateCard": break;
		default: throw Error(`Unresolved manual Gunsen task: ${n.kind}`);
	}
	return {
		kind: "effect",
		data: {
			task: n.kind,
			space: n.space ?? "",
			n: n.n ?? 0
		}
	};
}
function qe(e) {
	let t = e.tasks[0];
	if (!t || e.winner) return [];
	let n = j(e, t.rid), r = [], i = (n, i, a = {}, o = {}) => {
		let s = {
			op: n,
			...a
		};
		r.push({
			id: `${e.serial}:${JSON.stringify(s)}`,
			key: i,
			params: {},
			group: t.kind,
			space: "",
			card: -1,
			hero: -1,
			n: 0,
			value: 0,
			...o,
			command: s
		});
	}, a = () => i("skip", "skip", {}, { value: -4 }), o = (e, t, n, r = {}, a = {}) => n.forEach((n) => i(e, t, {
		...r,
		pay: n
	}, {
		...a,
		params: {
			...a.params,
			pay: n
		}
	}));
	if (t.kind === "clan") for (let t = 0; t < 7; t++) e.players.some((e) => e.clan === t) || i("clan", "chooseClan", { n: t }, {
		n: t,
		params: { clan: t }
	});
	if (t.kind === "fort" && e.map.filter((t) => t.kind === "fort" && t.min <= e.players.length && !t.fort).forEach((e) => i("fort", "chooseFort", { a: e.id }, { space: e.id })), t.kind === "draft" || t.kind === "nobleDraft") {
		e.market.forEach((n, r) => {
			let i = C[n];
			o("draft", "takeOrder", Ee(e, t.rid, i.cost, i.cost.length ? i.costN : 0), { n: r }, { card: n });
		});
		let n = !r.length && [...e.deck, ...e.discard].every((n) => {
			let r = C[n];
			return !Ee(e, t.rid, r.cost, r.cost.length ? r.costN : 0).length;
		});
		if (t.kind === "draft" && n) for (let e of v) i("place", "activateExhausted", { col: e }, { params: { column: e } });
		else t.kind === "draft" && (v.some((t) => e.market.filter((e) => C[e].column === t).length >= 4) || e.market.filter((e) => C[e].cost.length).length >= 4) && i("clear", "clearRow");
	}
	if (t.kind === "place" || t.kind === "anyColumn") {
		let r = C[t.card ?? 1];
		for (let n of v) (t.kind === "anyColumn" || t.mode === "any" || r.column === n || r.column === "any" || Se(e, t.rid, 4)) && i("place", "activateColumn", { col: n }, {
			card: t.card ?? -1,
			params: { column: n }
		});
		if (t.kind === "place" && !t.mode) for (let r = 1; r <= 3; r++) !n.nobles.includes(r) && (r !== 2 || [
			0,
			1,
			2
		].some((e) => !n.heroes.includes(n.clan * 3 + e) && !n.retired.includes(n.clan * 3 + e))) && (r !== 3 || n.specials.length < 2) && o("noble", "useNoble", q(e, t.rid, { influence: r }).filter((n) => {
			if (r !== 1) return !0;
			let i = structuredClone(e);
			return K(i, t.rid, n), e.market.some((e) => {
				let n = C[e];
				return Ee(i, t.rid, n.cost, n.cost.length ? n.costN : 0).length > 0;
			});
		}), { n: r }, {
			n: r,
			params: { n: r }
		});
	}
	if (t.kind === "activateCard" && C[t.card].effects.length && (i("useCard", "useOrder", {}, { card: t.card }), a()), t.kind === "gain" && (i("gain", "gainResource", {}, { params: {
		resource: t.mode,
		n: t.n ?? 1
	} }), a()), t.kind === "expandGain") {
		if (e.upgrades.expand === t.rid) i("expandBoth", "gainBoth");
		else for (let e of ["koku", "wood"]) i("gainOne", "gainResource", { a: e }, { params: {
			resource: e,
			n: 1
		} });
		a();
	}
	if (t.kind === "recruit") {
		if (N(e, t.rid) < 15) for (let n of we(e, t.rid, t.mode, t.space)) i("recruit", "recruitAt", { a: n.id }, {
			space: n.id,
			n: 1,
			value: 2
		});
		a();
	}
	if (t.kind === "dragonSpeed") {
		for (let n of e.map.filter((e) => P(e, t.rid) > 0)) i("dragonArmy", "chooseDragonArmy", { a: n.id }, {
			space: n.id,
			n: P(n, t.rid),
			value: 2
		});
		a();
	}
	if (t.kind === "build") {
		for (let r of ["unique", "camp"]) if (!n.buildings.includes(r)) for (let n of e.map) n.kind !== "fort" && !n.building && !n.village && (n.kind === "plain" || n.kind === "village") && !F(n, t.rid).length && e.map.some((e) => (P(e, t.rid) > 0 || e.fort === t.rid) && (n.id === e.id || E(n, e))) && o("build", "buildAt", q(e, t.rid, { wood: r === "unique" ? 3 : 2 }), {
			a: n.id,
			b: r
		}, {
			space: n.id,
			params: { building: r },
			value: 3
		});
		a();
	}
	if (t.kind === "buyTactic") {
		if (n.tactics.length < 3) for (let r of [
			...e.privateTactics[t.rid],
			13 + n.clan * 2,
			14 + n.clan * 2
		].filter((e) => !n.tactics.includes(e))) o("buyTactic", "buyTactic", q(e, t.rid, { koku: Math.max(0, se[r] - +!!Se(e, t.rid, 5)) }), { n: r }, {
			card: r,
			params: { tactic: r },
			value: 3
		});
		a();
	}
	if (t.kind === "hero" || t.kind === "mercenary") {
		let o = t.kind === "hero" ? [
			n.clan * 3,
			n.clan * 3 + 1,
			n.clan * 3 + 2
		] : [
			21,
			22,
			23
		];
		for (let n of o.filter((t) => !e.players.some((e) => e.heroes.includes(t) || e.retired.includes(t)))) for (let r of Ae(e, t.rid)) i("hero", "recruitHero", {
			n,
			a: r.id
		}, {
			hero: n,
			space: r.id,
			value: 4
		});
		r.length || a();
	}
	if (t.kind === "special") {
		for (let e of [26 + n.clan * 2, 27 + n.clan * 2].filter((e) => !n.specials.includes(e))) for (let t of v) (C[e].column === "any" || C[e].column === t) && i("special", "addSpecial", {
			n: e,
			col: t
		}, {
			card: e,
			params: { column: t }
		});
		r.length || a();
	}
	if (t.kind === "move" || t.kind === "moveArmy") {
		if (!e.movementEnded) for (let n of e.map.filter((e) => P(e, t.rid) > 0 && (!t.space || t.space === e.id))) {
			let r = R(e, t.rid, n.id);
			for (let a = 1; a <= Math.min(P(n, t.rid), t.maxTroops ?? 15); a++) for (let o of Oe(r.length)) {
				let s = r.filter((e, t) => o & 1 << t);
				(a !== P(n, t.rid) || n.fort === t.rid || s.length === r.length) && (P(n, t.rid) - a > z(e, t.rid, {
					...n,
					heroes: {
						...n.heroes,
						[t.rid]: r.filter((e) => !s.includes(e))
					}
				}) || t.movingHeroes && s.some((e) => !t.movingHeroes.includes(e)) || (t.mode !== "kamokoStep" || s.includes(7)) && Le(e, t, n, a, s).length && i("selectArmy", "selectArmy", {
					a: n.id,
					n: a,
					mask: o
				}, {
					space: n.id,
					n: a,
					params: {
						n: a,
						heroes: s.join(",")
					}
				}));
			}
		}
		(t.mode !== "mustNormal" || !r.length) && a();
	}
	if (t.kind === "destination") {
		let n = M(e, t.from), r = R(e, t.rid, n.id).filter((e, n) => (t.mask ?? 0) & 1 << n);
		for (let i of Le(e, t, n, t.n, r)) o("move", "moveTo", [i.pay], {
			a: i.dest.id,
			b: i.mode
		}, {
			space: i.dest.id,
			n: t.n,
			params: { mode: i.mode }
		});
		i("cancelMove", "cancel");
	}
	if (t.kind === "extraMove") {
		if (!e.movementEnded) {
			let n = t.col === "armory" ? "koku" : t.col === "recruit" ? "influence" : "wood";
			o("extraMove", "buyMovement", Ee(e, t.rid, L(e, t.rid, 17) ? [...y] : [n], 1), {}, { value: -1 });
		}
		a();
	}
	if (t.kind === "kamoko" && (e.movementEnded || i("kamoko", "extraStep"), a()), t.kind === "plow") {
		let n = M(e, t.space);
		for (let e = 1; e <= P(n, t.rid); e++) for (let t of ["koku", "wood"]) i("plow", "retireTroops", {
			a: t,
			n: e
		}, {
			n: e,
			params: {
				n: e,
				resource: t
			}
		});
		a();
	}
	if (t.kind === "kill") {
		for (let n of e.map) if (t.mode === "assassination" && [
			"shrine",
			"village",
			"city"
		].includes(n.kind) || t.mode === "highGround" && e.map.some((e) => e.building && I(e) === t.rid && E(n, e))) for (let e of Object.keys(n.armies).filter((e) => n.armies[e] > 0)) i("kill", "killAt", {
			a: n.id,
			b: e
		}, {
			space: n.id,
			params: { player: e },
			value: e === t.rid ? -6 : 1
		});
		a();
	}
	if (t.kind === "buildingMove") {
		for (let n of e.map.filter((n) => n.building && I(n) === t.rid && P(n, t.rid) <= z(e, t.rid, {
			...n,
			building: null
		}))) for (let r of e.map.filter((e) => e.id !== n.id && xe(e, t.rid) && ![
			"shrine",
			"fort",
			"city"
		].includes(e.kind) && !e.building)) i("buildingMove", "moveBuilding", {
			a: n.id,
			b: r.id
		}, { space: r.id });
		a();
	}
	if (t.kind === "tempest") {
		for (let r of n.heroes) {
			let n = e.map.find((n) => R(e, t.rid, n.id).includes(r));
			if (!(P(n, t.rid) > z(e, t.rid, {
				...n,
				heroes: {
					...n.heroes,
					[t.rid]: R(e, t.rid, n.id).filter((e) => e !== r)
				}
			}))) for (let n of Ae(e, t.rid).filter((n) => P(n, t.rid) > 0 && !R(e, t.rid, n.id).includes(r))) i("tempest", "moveHero", {
				n: r,
				a: n.id
			}, {
				hero: r,
				space: n.id
			});
		}
		a();
	}
	if (t.kind === "goal") for (let e of (t.mode ?? "").split(",").map(Number).filter((e) => !n.goals.includes(e))) i("goal", "claimGoal", { n: e }, {
		n: e,
		params: { goal: e },
		value: 10
	});
	if (t.kind === "yoritomo" && (o("payYoritomo", "payYoritomo", q(e, t.rid, { koku: 1 }), {}, { hero: 23 }), i("discardYoritomo", "discardYoritomo", {}, {
		hero: 23,
		value: -4
	})), t.kind === "rescueHero" || t.kind === "tsuko") for (let n of e.map.filter((e) => e.fort === t.rid || e.building && I(e) === t.rid && P(e, t.rid) > 0)) R(e, t.rid, n.id).length < Ce(e, t.rid, n) && i("rescueHero", "moveHero", {
		a: n.id,
		n: t.hero
	}, {
		space: n.id,
		hero: t.hero
	});
	return ze(e, t, i, o, a), r;
}
function Je(t, n, r, i) {
	let a = j(t, n.rid), o = t.battle;
	switch (r.op) {
		case "skip": break;
		case "clan":
			a.clan = r.n;
			break;
		case "fort": {
			a.fort = r.a;
			let e = M(t, r.a);
			e.fort = n.rid;
			let i = t.players.findIndex((e) => e.rid === n.rid);
			W(t, n.rid, e, i < 2 ? 3 : i < 4 ? 4 : 5);
			break;
		}
		case "clear":
			t.discard.push(...t.market), t.market = [], Te(t, i), V(t, n);
			break;
		case "draft": {
			let e = t.market.splice(r.n, 1)[0];
			return K(t, n.rid, r.pay), V(t, A("place", n.rid, {
				card: e,
				mode: n.kind === "nobleDraft" ? "any" : ""
			})), H(t, "orderTaken", n.rid, { card: e }), {
				kind: "draft",
				data: { card: e }
			};
		}
		case "place": {
			n.card !== void 0 && a.columns[r.col].push(n.card);
			let e = Ne(t, n.rid, r.col);
			return (n.kind === "draft" || n.kind === "place" && !n.mode) && e.push(A("turnBattle", n.rid), A("endEffects", n.rid), A("claimTerritories", n.rid), A("endTurn", n.rid)), V(t, ...e), H(t, "columnActivated", n.rid, { column: r.col }), {
				kind: "orderPlaced",
				data: {
					card: n.card ?? -1,
					column: r.col
				}
			};
		}
		case "noble":
			K(t, n.rid, r.pay), a.nobles.push(r.n), V(t, ...r.n === 1 ? [A("nobleDraft", n.rid)] : r.n === 2 ? [A("hero", n.rid), A("anyColumn", n.rid)] : [A("special", n.rid)], A("turnBattle", n.rid), A("endEffects", n.rid), A("claimTerritories", n.rid), A("endTurn", n.rid));
			break;
		case "useCard":
			V(t, ...C[n.card].effects.map((e) => Pe(e, n.rid, n.col, n.card)));
			break;
		case "gain": return U(t, n.rid, n.mode, n.n ?? 1), H(t, "gained", n.rid, {
			resource: n.mode,
			n: n.n ?? 1
		}), {
			kind: "gain",
			data: {
				resource: n.mode,
				n: n.n ?? 1
			}
		};
		case "gainOne":
			U(t, n.rid, r.a, 1);
			break;
		case "expandBoth":
			U(t, n.rid, "koku", 1), U(t, n.rid, "wood", 1);
			break;
		case "recruit": {
			let e = M(t, r.a);
			return W(t, n.rid, e, 1), (n.n ?? 1) > 1 && V(t, {
				...n,
				n: n.n - 1
			}), H(t, "recruited", n.rid, {
				n: 1,
				space: e.id
			}), {
				kind: "recruit",
				data: {
					space: e.id,
					n: 1
				}
			};
		}
		case "build": return K(t, n.rid, r.pay), M(t, r.a).building = {
			owner: n.rid,
			kind: r.b
		}, a.buildings.push(r.b), V(t, n), H(t, "built", n.rid, {
			building: r.b,
			space: r.a
		}), {
			kind: "build",
			data: {
				space: r.a,
				building: r.b
			}
		};
		case "buyTactic": {
			K(t, n.rid, r.pay), a.tactics.push(r.n), t.privateTactics[n.rid] = t.privateTactics[n.rid].filter((e) => e !== r.n), Se(t, n.rid, 5) && U(t, n.rid, "influence", 1);
			let e = [];
			r.n === 3 && e.push(A("special", n.rid, { mode: "noActivation" })), r.n === 7 && e.push(A("recruit", n.rid, {
				mode: "army",
				n: 3
			})), r.n >= 8 && r.n <= 10 && e.push(A("mercenary", n.rid)), r.n >= 14 && r.n % 2 == 0 && e.push(A("hero", n.rid)), V(t, ...e, n), H(t, "tacticBought", n.rid, { tactic: r.n });
			break;
		}
		case "hero":
			a.heroes.push(r.n), G(t, n.rid, r.n, r.a), H(t, "heroRecruited", n.rid, {
				hero: r.n,
				space: r.a
			});
			break;
		case "special":
			a.specials.push(r.n), a.columns[r.col].push(r.n), n.mode !== "noActivation" && V(t, ...Ne(t, n.rid, r.col));
			break;
		case "selectArmy":
			V(t, A("destination", n.rid, {
				from: r.a,
				n: r.n,
				mask: r.mask,
				col: n.col,
				mode: n.mode,
				space: n.space,
				movingHeroes: n.movingHeroes,
				maxTroops: n.maxTroops
			}));
			break;
		case "dragonArmy":
			V(t, A("recruit", n.rid, {
				n: 1,
				space: r.a
			}), A("move", n.rid, {
				n: 1,
				space: r.a,
				col: n.col
			}));
			break;
		case "cancelMove":
			V(t, A("move", n.rid, {
				mode: n.mode,
				col: n.col,
				space: n.space,
				movingHeroes: n.movingHeroes,
				maxTroops: n.maxTroops
			}));
			break;
		case "move": {
			let e = P(M(t, r.a), n.rid), i = be(t, M(t, n.from), n.rid);
			return We(t, n, r), {
				kind: "move",
				data: {
					from: n.from,
					space: r.a,
					n: n.n,
					toBefore: e,
					fromOffset: i,
					player: n.rid,
					clan: a.clan
				}
			};
		}
		case "kamoko":
			V(t, A("move", n.rid, {
				mode: "kamokoStep",
				col: n.col,
				space: n.space,
				movingHeroes: n.movingHeroes,
				maxTroops: n.maxTroops
			}));
			break;
		case "extraMove":
			K(t, n.rid, r.pay), V(t, A("move", n.rid, {
				n: 1,
				col: n.col
			}), n);
			break;
		case "plow":
			M(t, n.space).armies[n.rid] -= r.n, U(t, n.rid, r.a, r.n);
			break;
		case "kill":
			M(t, r.a).armies[r.b]--, H(t, "troopKilled", n.rid, {
				space: r.a,
				player: r.b
			});
			break;
		case "buildingMove":
			M(t, r.b).building = M(t, r.a).building, M(t, r.a).building = null;
			break;
		case "tempest":
			G(t, n.rid, r.n, r.a), V(t, A("recruit", n.rid, {
				space: r.a,
				n: 2
			}));
			break;
		case "goal":
		case "battleGoal":
			a.goals.push(r.n), J(t, n.rid, `goal${r.n}`);
			break;
		case "payYoritomo":
			K(t, n.rid, r.pay);
			break;
		case "discardYoritomo":
			a.heroes = a.heroes.filter((e) => e !== 23), G(t, n.rid, 23, "");
			break;
		case "rescueHero":
			G(t, n.rid, r.n, r.a);
			break;
		case "moto":
			G(t, n.rid, 6, o.space);
			break;
		case "protectHero":
			K(t, n.rid, r.pay);
			break;
		case "disableHeroes":
			o.disabled.push(...R(t, n.rid, o.space));
			break;
		case "yokuni":
			a.retired.push(13), a.heroes = a.heroes.filter((e) => e !== 13), G(t, n.rid, 13, ""), o.forced = n.rid;
			break;
		case "heroToken":
			K(t, n.rid, r.pay), a.heroTokens[String(r.n)] = (a.heroTokens[String(r.n)] ?? 0) + 1, V(t, {
				...n,
				mask: (n.mask ?? 0) | 1 << r.n
			});
			break;
		case "militia": {
			let e = a.villages.splice(r.n, 1)[0];
			M(t, r.a).village = !0, t.villages[r.a] = e, o.militia[n.rid] = (o.militia[n.rid] ?? 0) + 1, V(t, n);
			break;
		}
		case "reroll": return o.dice[n.rid] = o.dice[n.rid].map((n, a) => r.mask & 1 << a ? e(i, t.rngCursor++, 8) : n), o.rerolls[n.rid]--, V(t, n), {
			kind: "roll",
			data: { dice: o.dice[n.rid] }
		};
		case "finishReroll":
			V(t, A("keep", n.rid));
			break;
		case "keep": {
			o.kept[n.rid] = o.dice[n.rid].filter((e, t) => r.mask & 1 << t);
			let e = [];
			L(t, n.rid, 19) && o.kept[n.rid].length && e.push(A("strategize", n.rid)), Y(t, n.rid).includes(3) && o.kept[n.rid].length && e.push(A("double", n.rid)), V(t, ...e);
			break;
		}
		case "strategize":
			o.kept[n.rid][r.x] = r.n, o.changed.push(n.rid);
			break;
		case "double":
			o.double[n.rid] = r.n;
			break;
		case "rebirth": {
			let e = M(t, r.a), i = W(t, n.rid, e, 1);
			o.kills[n.rid] -= i, i && (n.n ?? 1) > 1 && V(t, {
				...n,
				n: n.n - 1
			});
			break;
		}
		case "battleAchievement":
			a.achievements.includes("attack1") ? J(t, n.rid, "attack2") : J(t, n.rid, "attack1");
			break;
		case "steal": {
			let e = j(t, o.loser).villages.splice(r.n, 1)[0];
			e === "troop" ? W(t, n.rid, M(t, a.fort), 1) : U(t, n.rid, e, 1), a.villages.length < 3 && a.villages.push(e);
			break;
		}
		case "retreat": {
			let e = M(t, o.space), i = M(t, r.a), s = P(e, n.rid), c = P(i, n.rid), l = be(t, e, n.rid);
			i.armies[n.rid] = c + s, e.armies[n.rid] = 0;
			for (let r of [...R(t, n.rid, e.id)]) G(t, n.rid, r, i.id);
			return H(t, "retreated", n.rid, { space: i.id }), {
				kind: "move",
				data: {
					from: e.id,
					space: i.id,
					n: s,
					toBefore: c,
					fromOffset: l,
					player: n.rid,
					clan: a.clan
				}
			};
		}
	}
	return {
		kind: "effect",
		data: {
			task: r.op,
			space: r.a ?? "",
			n: r.n ?? 0
		}
	};
}
function Ye(e) {
	for (let t of e.map) for (let [n, r] of Object.entries(t.heroes)) if (r.length && !P(t, n) && t.fort !== n && t.id !== e.battle?.space) for (let t of r) e.tasks.some((e) => e.kind === "rescueHero" && e.hero === t) || V(e, A("rescueHero", n, { hero: t }));
}
function Xe(e, t, n) {
	if (e.winner) return { code: "games.gunsen.errDone" };
	let r = e.tasks[0], i = qe(e);
	if (!r) return { code: "games.gunsen.errAction" };
	if (t.type === "tick" && i.length) return {
		state: e,
		fx: []
	};
	if (t.type === "tick" && !ye.has(r.kind)) return { code: "games.gunsen.errAction" };
	let a = t.type === "act" ? i.find((e) => e.id === t.id) : void 0;
	if (t.type === "act" && (n.by !== r.rid || !a)) return { code: "games.gunsen.errAction" };
	let o = structuredClone(e);
	o.tasks.shift(), o.serial++;
	let s = a ? Je(o, r, a.command, o.seed) : Ke(o, r, o.seed);
	return o.beatMs = s.kind === "roll" ? k.roll : s.kind === "move" ? k.move : s.kind === "kills" ? k.kills : s.kind === "battleResult" ? k.result : k.effect, Ye(o), Me(o), {
		state: o,
		fx: [{
			kind: s.kind,
			rid: r.rid,
			data: s.data ?? {}
		}]
	};
}
function Ze(e, t) {
	let n = e.tasks[0]?.rid ?? "", r = qe(e);
	return structuredClone({
		public: {
			phase: e.phase,
			active: e.active,
			acting: n,
			turn: e.turn,
			serial: e.serial,
			players: e.players.map((t) => ({
				...t,
				reserve: 15 - N(e, t.rid)
			})),
			map: e.map,
			market: e.market,
			deckCount: e.deck.length,
			upgrades: e.upgrades,
			cityOpen: e.cityOpen,
			prompt: r[0]?.key === "activateExhausted" ? "exhausted" : e.tasks[0]?.kind ?? "done",
			battle: e.battle,
			log: e.log,
			winner: e.winner
		},
		private: {
			choices: n === t ? r.map(({ id: e, key: t, params: n, group: r, space: i, card: a, hero: o, n: s, value: c }) => ({
				id: e,
				key: t,
				params: n,
				group: r,
				space: i,
				card: a,
				hero: o,
				n: s,
				value: c
			})) : [],
			tactics: e.privateTactics[t] ?? []
		}
	});
}
var Qe = {
	meta: ue,
	saveCompatibility: { version: "1" },
	schemas: {
		action: de,
		publicView: _e,
		privateView: ve
	},
	setup: De,
	reduce: Xe,
	viewFor: Ze,
	status(e) {
		if (!e.winner) return { phase: e.phase };
		let t = [...e.players].sort((t, n) => Number(n.rid === e.winner) - Number(t.rid === e.winner) || n.achievements.length - t.achievements.length).map((e) => e.rid);
		return {
			phase: "done",
			winner: [e.winner],
			ranking: t,
			scores: Object.fromEntries(e.players.map((e) => [e.rid, e.achievements.length]))
		};
	},
	nextTickIn(e) {
		return e.tasks.length && !e.winner && ye.has(e.tasks[0].kind) && !qe(e).length ? e.beatMs : null;
	}
}, $e = [
	"games.gunsen.clan0",
	"games.gunsen.clan1",
	"games.gunsen.clan2",
	"games.gunsen.clan3",
	"games.gunsen.clan4",
	"games.gunsen.clan5",
	"games.gunsen.clan6"
], et = [
	"games.gunsen.goal0",
	"games.gunsen.goal1",
	"games.gunsen.goal2",
	"games.gunsen.goal3",
	"games.gunsen.goal4",
	"games.gunsen.goal5",
	"games.gunsen.goal6",
	"games.gunsen.goal7",
	"games.gunsen.goal8",
	"games.gunsen.goal9",
	"games.gunsen.goal10",
	"games.gunsen.goal11",
	"games.gunsen.goal12",
	"games.gunsen.goal13",
	"games.gunsen.goal14",
	"games.gunsen.goal15",
	"games.gunsen.goal16",
	"games.gunsen.goal17",
	"games.gunsen.goal18",
	"games.gunsen.goal19",
	"games.gunsen.goal20"
], tt = [
	"games.gunsen.goalText0",
	"games.gunsen.goalText1",
	"games.gunsen.goalText2",
	"games.gunsen.goalText3",
	"games.gunsen.goalText4",
	"games.gunsen.goalText5",
	"games.gunsen.goalText6",
	"games.gunsen.goalText7",
	"games.gunsen.goalText8",
	"games.gunsen.goalText9",
	"games.gunsen.goalText10",
	"games.gunsen.goalText11",
	"games.gunsen.goalText12",
	"games.gunsen.goalText13",
	"games.gunsen.goalText14",
	"games.gunsen.goalText15",
	"games.gunsen.goalText16",
	"games.gunsen.goalText17",
	"games.gunsen.goalText18",
	"games.gunsen.goalText19",
	"games.gunsen.goalText20"
], nt = /* @__PURE__ */ "games.gunsen.tactic0,games.gunsen.tactic1,games.gunsen.tactic2,games.gunsen.tactic3,games.gunsen.tactic4,games.gunsen.tactic5,games.gunsen.tactic6,games.gunsen.tactic7,games.gunsen.tactic8,games.gunsen.tactic9,games.gunsen.tactic10,games.gunsen.tactic11,games.gunsen.tactic12,games.gunsen.tactic13,games.gunsen.tactic14,games.gunsen.tactic15,games.gunsen.tactic16,games.gunsen.tactic17,games.gunsen.tactic18,games.gunsen.tactic19,games.gunsen.tactic20,games.gunsen.tactic21,games.gunsen.tactic22,games.gunsen.tactic23,games.gunsen.tactic24,games.gunsen.tactic25,games.gunsen.tactic26".split(","), rt = /* @__PURE__ */ "games.gunsen.tacticText0,games.gunsen.tacticText1,games.gunsen.tacticText2,games.gunsen.tacticText3,games.gunsen.tacticText4,games.gunsen.tacticText5,games.gunsen.tacticText6,games.gunsen.tacticText7,games.gunsen.tacticText8,games.gunsen.tacticText9,games.gunsen.tacticText10,games.gunsen.tacticText11,games.gunsen.tacticText12,games.gunsen.tacticText13,games.gunsen.tacticText14,games.gunsen.tacticText15,games.gunsen.tacticText16,games.gunsen.tacticText17,games.gunsen.tacticText18,games.gunsen.tacticText19,games.gunsen.tacticText20,games.gunsen.tacticText21,games.gunsen.tacticText22,games.gunsen.tacticText23,games.gunsen.tacticText24,games.gunsen.tacticText25,games.gunsen.tacticText26".split(","), it = [
	"games.gunsen.heroText0",
	"games.gunsen.heroText1",
	"games.gunsen.heroText2",
	"games.gunsen.heroText3",
	"games.gunsen.heroText4",
	"games.gunsen.heroText5",
	"games.gunsen.heroText6",
	"games.gunsen.heroText7",
	"games.gunsen.heroText8",
	"games.gunsen.heroText9",
	"games.gunsen.heroText10",
	"games.gunsen.heroText11",
	"games.gunsen.heroText12",
	"games.gunsen.heroText13",
	"games.gunsen.heroText14",
	"games.gunsen.heroText15",
	"games.gunsen.heroText16",
	"games.gunsen.heroText17",
	"games.gunsen.heroText18",
	"games.gunsen.heroText19",
	"games.gunsen.heroText20",
	"games.gunsen.heroText21",
	"games.gunsen.heroText22",
	"games.gunsen.heroText23"
], at = [
	"games.gunsen.building0",
	"games.gunsen.building1",
	"games.gunsen.building2",
	"games.gunsen.building3",
	"games.gunsen.building4",
	"games.gunsen.building5",
	"games.gunsen.building6"
], ot = [
	"games.gunsen.buildingText0",
	"games.gunsen.buildingText1",
	"games.gunsen.buildingText2",
	"games.gunsen.buildingText3",
	"games.gunsen.buildingText4",
	"games.gunsen.buildingText5",
	"games.gunsen.buildingText6"
], st = {
	move: "games.gunsen.move",
	prompt_gain: "games.gunsen.prompt_gain",
	name: "games.gunsen.name",
	desc: "games.gunsen.desc",
	rules: "games.gunsen.rules",
	koku: "games.gunsen.koku",
	wood: "games.gunsen.wood",
	influence: "games.gunsen.influence",
	troop: "games.gunsen.troop",
	strength: "games.gunsen.strength",
	blood: "games.gunsen.blood",
	armor: "games.gunsen.armor",
	roll: "games.gunsen.roll",
	keep: "games.gunsen.keep",
	reroll: "games.gunsen.reroll",
	expand: "games.gunsen.expand",
	armory: "games.gunsen.armory",
	recruit: "games.gunsen.recruit",
	plain: "games.gunsen.plain",
	village: "games.gunsen.village",
	shrine: "games.gunsen.shrine",
	tower: "games.gunsen.tower",
	city: "games.gunsen.city",
	fort: "games.gunsen.fort",
	unique: "games.gunsen.unique",
	camp: "games.gunsen.camp",
	close: "games.gunsen.close",
	inspect: "games.gunsen.inspect",
	confirm: "games.gunsen.confirm",
	cancel: "games.gunsen.cancel",
	skip: "games.gunsen.skip",
	resolving: "games.gunsen.resolving",
	waiting: "games.gunsen.waiting",
	turn: "games.gunsen.turn",
	orders: "games.gunsen.orders",
	clanBoard: "games.gunsen.clanBoard",
	cards: "games.gunsen.cards",
	goals: "games.gunsen.goals",
	tactics: "games.gunsen.tactics",
	heroes: "games.gunsen.heroes",
	buildings: "games.gunsen.buildings",
	specials: "games.gunsen.specials",
	history: "games.gunsen.history",
	map: "games.gunsen.map",
	overview: "games.gunsen.overview",
	achievements: "games.gunsen.achievements",
	reserve: "games.gunsen.reserve",
	unclaimed: "games.gunsen.unclaimed",
	cost: "games.gunsen.cost",
	free: "games.gunsen.free",
	detail: "games.gunsen.detail",
	victory: "games.gunsen.victory",
	again: "games.gunsen.again",
	lobby: "games.gunsen.lobby",
	review: "games.gunsen.review",
	showResults: "games.gunsen.showResults",
	privateTactics: "games.gunsen.privateTactics",
	chooseTarget: "games.gunsen.chooseTarget",
	army: "games.gunsen.army",
	heroCount: "games.gunsen.heroCount",
	none: "games.gunsen.none",
	used: "games.gunsen.used",
	battle: "games.gunsen.battle",
	attacker: "games.gunsen.attacker",
	defender: "games.gunsen.defender",
	dice: "games.gunsen.dice",
	tokens: "games.gunsen.tokens",
	upgrades: "games.gunsen.upgrades",
	nobles: "games.gunsen.nobles",
	score: "games.gunsen.score",
	errAction: "games.gunsen.errAction",
	errDone: "games.gunsen.errDone",
	clan0: "games.gunsen.clan0",
	clan1: "games.gunsen.clan1",
	clan2: "games.gunsen.clan2",
	clan3: "games.gunsen.clan3",
	clan4: "games.gunsen.clan4",
	clan5: "games.gunsen.clan5",
	clan6: "games.gunsen.clan6",
	chooseClan: "games.gunsen.chooseClan",
	chooseFort: "games.gunsen.chooseFort",
	takeOrder: "games.gunsen.takeOrder",
	clearRow: "games.gunsen.clearRow",
	activateColumn: "games.gunsen.activateColumn",
	useNoble: "games.gunsen.useNoble",
	useOrder: "games.gunsen.useOrder",
	gainBoth: "games.gunsen.gainBoth",
	gainResource: "games.gunsen.gainResource",
	recruitAt: "games.gunsen.recruitAt",
	chooseDragonArmy: "games.gunsen.chooseDragonArmy",
	buildAt: "games.gunsen.buildAt",
	buyTactic: "games.gunsen.buyTactic",
	recruitHero: "games.gunsen.recruitHero",
	addSpecial: "games.gunsen.addSpecial",
	selectArmy: "games.gunsen.selectArmy",
	moveTo: "games.gunsen.moveTo",
	buyMovement: "games.gunsen.buyMovement",
	extraStep: "games.gunsen.extraStep",
	retireTroops: "games.gunsen.retireTroops",
	killAt: "games.gunsen.killAt",
	moveBuilding: "games.gunsen.moveBuilding",
	moveHero: "games.gunsen.moveHero",
	claimGoal: "games.gunsen.claimGoal",
	bringMoto: "games.gunsen.bringMoto",
	protectHero: "games.gunsen.protectHero",
	disableHeroes: "games.gunsen.disableHeroes",
	sacrificeYokuni: "games.gunsen.sacrificeYokuni",
	empowerHero: "games.gunsen.empowerHero",
	returnVillage: "games.gunsen.returnVillage",
	rerollDice: "games.gunsen.rerollDice",
	keepDice: "games.gunsen.keepDice",
	keepTheseDice: "games.gunsen.keepTheseDice",
	changeDie: "games.gunsen.changeDie",
	doubleDie: "games.gunsen.doubleDie",
	rebirthAt: "games.gunsen.rebirthAt",
	claimAttack: "games.gunsen.claimAttack",
	stealVillage: "games.gunsen.stealVillage",
	retreatTo: "games.gunsen.retreatTo",
	payYoritomo: "games.gunsen.payYoritomo",
	discardYoritomo: "games.gunsen.discardYoritomo",
	prompt_clan: "games.gunsen.prompt_clan",
	prompt_fort: "games.gunsen.prompt_fort",
	prompt_draft: "games.gunsen.prompt_draft",
	prompt_exhausted: "games.gunsen.prompt_exhausted",
	activateExhausted: "games.gunsen.activateExhausted",
	prompt_nobleDraft: "games.gunsen.prompt_nobleDraft",
	prompt_place: "games.gunsen.prompt_place",
	prompt_anyColumn: "games.gunsen.prompt_anyColumn",
	prompt_activateCard: "games.gunsen.prompt_activateCard",
	prompt_expandGain: "games.gunsen.prompt_expandGain",
	prompt_recruit: "games.gunsen.prompt_recruit",
	prompt_dragonSpeed: "games.gunsen.prompt_dragonSpeed",
	prompt_build: "games.gunsen.prompt_build",
	prompt_buyTactic: "games.gunsen.prompt_buyTactic",
	prompt_hero: "games.gunsen.prompt_hero",
	prompt_mercenary: "games.gunsen.prompt_mercenary",
	prompt_special: "games.gunsen.prompt_special",
	prompt_move: "games.gunsen.prompt_move",
	prompt_moveArmy: "games.gunsen.prompt_moveArmy",
	prompt_destination: "games.gunsen.prompt_destination",
	prompt_extraMove: "games.gunsen.prompt_extraMove",
	prompt_kamoko: "games.gunsen.prompt_kamoko",
	prompt_plow: "games.gunsen.prompt_plow",
	prompt_kill: "games.gunsen.prompt_kill",
	prompt_buildingMove: "games.gunsen.prompt_buildingMove",
	prompt_tempest: "games.gunsen.prompt_tempest",
	prompt_goal: "games.gunsen.prompt_goal",
	prompt_moto: "games.gunsen.prompt_moto",
	prompt_aramoro: "games.gunsen.prompt_aramoro",
	prompt_heroAbility: "games.gunsen.prompt_heroAbility",
	prompt_militia: "games.gunsen.prompt_militia",
	prompt_reroll: "games.gunsen.prompt_reroll",
	prompt_keep: "games.gunsen.prompt_keep",
	prompt_strategize: "games.gunsen.prompt_strategize",
	prompt_double: "games.gunsen.prompt_double",
	prompt_rebirth: "games.gunsen.prompt_rebirth",
	prompt_battleReward: "games.gunsen.prompt_battleReward",
	prompt_steal: "games.gunsen.prompt_steal",
	prompt_retreat: "games.gunsen.prompt_retreat",
	prompt_rescueHero: "games.gunsen.prompt_rescueHero",
	prompt_tsuko: "games.gunsen.prompt_tsuko",
	prompt_yoritomo: "games.gunsen.prompt_yoritomo",
	achievement_attack1: "games.gunsen.achievement_attack1",
	achievement_attack2: "games.gunsen.achievement_attack2",
	achievement_buildings: "games.gunsen.achievement_buildings",
	achievement_tactics: "games.gunsen.achievement_tactics",
	achievement_nobles: "games.gunsen.achievement_nobles",
	achievement_villages: "games.gunsen.achievement_villages",
	achievement_shrines: "games.gunsen.achievement_shrines",
	achievement_city: "games.gunsen.achievement_city",
	achievement_holdCity: "games.gunsen.achievement_holdCity",
	order26: "games.gunsen.order26",
	orderText26: "games.gunsen.orderText26",
	order27: "games.gunsen.order27",
	orderText27: "games.gunsen.orderText27",
	order28: "games.gunsen.order28",
	orderText28: "games.gunsen.orderText28",
	order29: "games.gunsen.order29",
	orderText29: "games.gunsen.orderText29",
	order30: "games.gunsen.order30",
	orderText30: "games.gunsen.orderText30",
	order31: "games.gunsen.order31",
	orderText31: "games.gunsen.orderText31",
	order32: "games.gunsen.order32",
	orderText32: "games.gunsen.orderText32",
	order33: "games.gunsen.order33",
	orderText33: "games.gunsen.orderText33",
	order34: "games.gunsen.order34",
	orderText34: "games.gunsen.orderText34",
	order35: "games.gunsen.order35",
	orderText35: "games.gunsen.orderText35",
	order36: "games.gunsen.order36",
	orderText36: "games.gunsen.orderText36",
	order37: "games.gunsen.order37",
	orderText37: "games.gunsen.orderText37",
	order38: "games.gunsen.order38",
	orderText38: "games.gunsen.orderText38",
	order39: "games.gunsen.order39",
	orderText39: "games.gunsen.orderText39",
	tactic0: "games.gunsen.tactic0",
	tacticText0: "games.gunsen.tacticText0",
	tactic1: "games.gunsen.tactic1",
	tacticText1: "games.gunsen.tacticText1",
	tactic2: "games.gunsen.tactic2",
	tacticText2: "games.gunsen.tacticText2",
	tactic3: "games.gunsen.tactic3",
	tacticText3: "games.gunsen.tacticText3",
	tactic4: "games.gunsen.tactic4",
	tacticText4: "games.gunsen.tacticText4",
	tactic5: "games.gunsen.tactic5",
	tacticText5: "games.gunsen.tacticText5",
	tactic6: "games.gunsen.tactic6",
	tacticText6: "games.gunsen.tacticText6",
	tactic7: "games.gunsen.tactic7",
	tacticText7: "games.gunsen.tacticText7",
	tactic8: "games.gunsen.tactic8",
	tacticText8: "games.gunsen.tacticText8",
	tactic9: "games.gunsen.tactic9",
	tacticText9: "games.gunsen.tacticText9",
	tactic10: "games.gunsen.tactic10",
	tacticText10: "games.gunsen.tacticText10",
	tactic11: "games.gunsen.tactic11",
	tacticText11: "games.gunsen.tacticText11",
	tactic12: "games.gunsen.tactic12",
	tacticText12: "games.gunsen.tacticText12",
	tactic13: "games.gunsen.tactic13",
	tacticText13: "games.gunsen.tacticText13",
	tactic14: "games.gunsen.tactic14",
	tacticText14: "games.gunsen.tacticText14",
	tactic15: "games.gunsen.tactic15",
	tacticText15: "games.gunsen.tacticText15",
	tactic16: "games.gunsen.tactic16",
	tacticText16: "games.gunsen.tacticText16",
	tactic17: "games.gunsen.tactic17",
	tacticText17: "games.gunsen.tacticText17",
	tactic18: "games.gunsen.tactic18",
	tacticText18: "games.gunsen.tacticText18",
	tactic19: "games.gunsen.tactic19",
	tacticText19: "games.gunsen.tacticText19",
	tactic20: "games.gunsen.tactic20",
	tacticText20: "games.gunsen.tacticText20",
	tactic21: "games.gunsen.tactic21",
	tacticText21: "games.gunsen.tacticText21",
	tactic22: "games.gunsen.tactic22",
	tacticText22: "games.gunsen.tacticText22",
	tactic23: "games.gunsen.tactic23",
	tacticText23: "games.gunsen.tacticText23",
	tactic24: "games.gunsen.tactic24",
	tacticText24: "games.gunsen.tacticText24",
	tactic25: "games.gunsen.tactic25",
	tacticText25: "games.gunsen.tacticText25",
	tactic26: "games.gunsen.tactic26",
	tacticText26: "games.gunsen.tacticText26",
	heroText0: "games.gunsen.heroText0",
	heroText1: "games.gunsen.heroText1",
	heroText2: "games.gunsen.heroText2",
	heroText3: "games.gunsen.heroText3",
	heroText4: "games.gunsen.heroText4",
	heroText5: "games.gunsen.heroText5",
	heroText6: "games.gunsen.heroText6",
	heroText7: "games.gunsen.heroText7",
	heroText8: "games.gunsen.heroText8",
	heroText9: "games.gunsen.heroText9",
	heroText10: "games.gunsen.heroText10",
	heroText11: "games.gunsen.heroText11",
	heroText12: "games.gunsen.heroText12",
	heroText13: "games.gunsen.heroText13",
	heroText14: "games.gunsen.heroText14",
	heroText15: "games.gunsen.heroText15",
	heroText16: "games.gunsen.heroText16",
	heroText17: "games.gunsen.heroText17",
	heroText18: "games.gunsen.heroText18",
	heroText19: "games.gunsen.heroText19",
	heroText20: "games.gunsen.heroText20",
	heroText21: "games.gunsen.heroText21",
	heroText22: "games.gunsen.heroText22",
	heroText23: "games.gunsen.heroText23",
	goal0: "games.gunsen.goal0",
	goalText0: "games.gunsen.goalText0",
	goal1: "games.gunsen.goal1",
	goalText1: "games.gunsen.goalText1",
	goal2: "games.gunsen.goal2",
	goalText2: "games.gunsen.goalText2",
	goal3: "games.gunsen.goal3",
	goalText3: "games.gunsen.goalText3",
	goal4: "games.gunsen.goal4",
	goalText4: "games.gunsen.goalText4",
	goal5: "games.gunsen.goal5",
	goalText5: "games.gunsen.goalText5",
	goal6: "games.gunsen.goal6",
	goalText6: "games.gunsen.goalText6",
	goal7: "games.gunsen.goal7",
	goalText7: "games.gunsen.goalText7",
	goal8: "games.gunsen.goal8",
	goalText8: "games.gunsen.goalText8",
	goal9: "games.gunsen.goal9",
	goalText9: "games.gunsen.goalText9",
	goal10: "games.gunsen.goal10",
	goalText10: "games.gunsen.goalText10",
	goal11: "games.gunsen.goal11",
	goalText11: "games.gunsen.goalText11",
	goal12: "games.gunsen.goal12",
	goalText12: "games.gunsen.goalText12",
	goal13: "games.gunsen.goal13",
	goalText13: "games.gunsen.goalText13",
	goal14: "games.gunsen.goal14",
	goalText14: "games.gunsen.goalText14",
	goal15: "games.gunsen.goal15",
	goalText15: "games.gunsen.goalText15",
	goal16: "games.gunsen.goal16",
	goalText16: "games.gunsen.goalText16",
	goal17: "games.gunsen.goal17",
	goalText17: "games.gunsen.goalText17",
	goal18: "games.gunsen.goal18",
	goalText18: "games.gunsen.goalText18",
	goal19: "games.gunsen.goal19",
	goalText19: "games.gunsen.goalText19",
	goal20: "games.gunsen.goal20",
	goalText20: "games.gunsen.goalText20",
	building0: "games.gunsen.building0",
	buildingText0: "games.gunsen.buildingText0",
	building1: "games.gunsen.building1",
	buildingText1: "games.gunsen.buildingText1",
	building2: "games.gunsen.building2",
	buildingText2: "games.gunsen.buildingText2",
	building3: "games.gunsen.building3",
	buildingText3: "games.gunsen.buildingText3",
	building4: "games.gunsen.building4",
	buildingText4: "games.gunsen.buildingText4",
	building5: "games.gunsen.building5",
	buildingText5: "games.gunsen.buildingText5",
	building6: "games.gunsen.building6",
	buildingText6: "games.gunsen.buildingText6",
	campText: "games.gunsen.campText",
	nobleText1: "games.gunsen.nobleText1",
	nobleText2: "games.gunsen.nobleText2",
	nobleText3: "games.gunsen.nobleText3",
	log_achievement: "games.gunsen.log_achievement",
	log_victory: "games.gunsen.log_victory",
	log_gained: "games.gunsen.log_gained",
	log_moved: "games.gunsen.log_moved",
	log_orderTaken: "games.gunsen.log_orderTaken",
	log_columnActivated: "games.gunsen.log_columnActivated",
	log_recruited: "games.gunsen.log_recruited",
	log_built: "games.gunsen.log_built",
	log_tacticBought: "games.gunsen.log_tacticBought",
	log_heroRecruited: "games.gunsen.log_heroRecruited",
	log_troopKilled: "games.gunsen.log_troopKilled",
	log_battleResult: "games.gunsen.log_battleResult",
	log_villageClaimed: "games.gunsen.log_villageClaimed",
	log_retreated: "games.gunsen.log_retreated"
};
function X(e, t) {
	let n = st[e];
	return n ? t(n) : String(e);
}
function ct(e, t, n = {}) {
	let r = { ...e.params };
	for (let e of [
		"column",
		"resource",
		"building"
	]) r[e] !== void 0 && (r[e] = X(r[e], t));
	r.clan !== void 0 && (r.clan = t($e[Number(r.clan)])), r.tactic !== void 0 && (r.tactic = t(nt[Number(r.tactic)])), r.player !== void 0 && (r.player = n[String(r.player)] ?? r.player);
	let i = t(st[e.key], r);
	e.space && (i += " · " + e.space), e.hero >= 0 && (i = w[e.hero] + " · " + i), e.params.heroes && (i += " · " + t("games.gunsen.heroCount", { heroes: String(e.params.heroes).split(",").map((e) => w[Number(e)]).join(", ") }));
	let a = typeof e.params.pay == "string" ? e.params.pay.split(",").map((e, n) => Number(e) ? e + " " + X(y[n], t) : "").filter(Boolean).join(" + ") : "";
	return a && (i += " · " + t("games.gunsen.cost", { cost: a })), i;
}
function lt(e, t) {
	return e.startsWith("goal") ? t(et[Number(e.slice(4))]) : X("achievement_" + e, t);
}
//#endregion
//#region src/games/gunsen/pieces.tsx
var ut = {
	expand: "#a48766",
	armory: "#3f6590",
	recruit: "#d6a02c",
	influence: "#793e77"
};
function dt(e) {
	return { "--gn-clan": b[e] ?? "#51483e" };
}
function Z({ id: e, size: t = 24, die: n = !1 }) {
	let r = s();
	if ([
		"koku",
		"wood",
		"influence",
		"troop",
		"strength",
		"blood",
		"armor",
		"roll",
		"keep",
		"reroll",
		"move"
	].includes(e)) return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 48 48",
		width: t,
		height: t,
		role: "img",
		"aria-label": X(e, r),
		className: "gn-token",
		children: /* @__PURE__ */ f("image", {
			href: `games/gunsen/live/${n ? "die" : "icon"}-${e}.svg`,
			width: "48",
			height: "48"
		})
	});
	let i;
	switch (e) {
		case "shrine":
			i = /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("path", {
				d: "M4 10q20 8 40 0l-1 7H5Z",
				fill: "#ad443d",
				stroke: "#533a2c",
				strokeWidth: "2"
			}), /* @__PURE__ */ f("path", {
				d: "M9 25h30M13 16l-1 29m23-29 1 29",
				stroke: "#634633",
				strokeWidth: "5"
			})] });
			break;
		case "tower":
		case "fort":
		case "city":
		case "unique":
		case "camp":
			i = /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: e === "camp" ? "m4 41 20-31 20 31ZM24 10v31" : "M12 19h24v24H12ZM16 5h16v14H16Z",
					fill: e === "camp" ? "#c0ad7e" : "#f1e7cb",
					stroke: "#4b493b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: e === "camp" ? "M6 41h36" : "M5 21 13 13h22l8 8ZM10 8 17 2h14l7 6ZM8 35h32",
					fill: "#365959",
					stroke: "#35433b",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: "M21 33h7v10",
					fill: "#534632"
				})
			] });
			break;
		case "village":
			i = /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("path", {
					d: "M3 27 12 18l9 8v15H4Zm17-8L32 7l13 13v23H21Z",
					fill: "#e3d9b9",
					stroke: "#504631",
					strokeWidth: "2"
				}),
				/* @__PURE__ */ f("path", {
					d: "m1 27 11-12 12 12M18 20 32 4l15 16",
					fill: "#8f8e6a",
					stroke: "#504631",
					strokeWidth: "3"
				}),
				/* @__PURE__ */ f("path", {
					d: "M29 30h7v13",
					fill: "#594d35"
				})
			] });
			break;
		default: i = /* @__PURE__ */ f("path", {
			d: "m24 5 5 12 14 1-11 9 4 14-12-8-12 8 4-14-11-9 14-1Z",
			fill: "#d3aa4b",
			stroke: "#675237",
			strokeWidth: "2"
		});
	}
	return /* @__PURE__ */ f("svg", {
		viewBox: "0 0 48 48",
		width: t,
		height: t,
		role: "img",
		"aria-label": X(e, r),
		className: "gn-token",
		children: i
	});
}
function ft({ n: e, color: t }) {
	return /* @__PURE__ */ p("svg", {
		viewBox: "-4 -4 112 69",
		width: "100%",
		height: "100%",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ f("rect", {
				x: "-4",
				y: "-4",
				width: "112",
				height: "69",
				rx: "9",
				fill: t,
				stroke: "#fff0d2",
				strokeWidth: "5"
			}),
			/* @__PURE__ */ f("image", {
				href: "games/gunsen/live/icon-troop.svg",
				x: "0",
				y: "0",
				width: "50",
				height: "58"
			}),
			/* @__PURE__ */ f("text", {
				x: "75",
				y: "45",
				textAnchor: "middle",
				fontSize: "48",
				fontWeight: "800",
				fill: "#fff9e7",
				children: e
			})
		]
	});
}
function pt({ stats: e }) {
	return /* @__PURE__ */ f("span", {
		className: "gn-stat-line",
		children: Object.entries(e).filter(([, e]) => e).map(([e, t]) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { id: e }), /* @__PURE__ */ f("b", { children: t })] }, e))
	});
}
function Q({ id: e, compact: t = !1 }) {
	let n = s(), r = C[e];
	return r ? /* @__PURE__ */ p("div", {
		className: "gn-order",
		"data-compact": t,
		style: { "--gn-order": r.column === "any" ? "#596760" : ut[r.column] },
		children: [
			/* @__PURE__ */ p("div", {
				className: "gn-order-effects",
				children: [
					r.effects.filter((e) => !["deferred", "buildingMove"].includes(e.kind)).map((e, t) => /* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { id: e.resource ?? ([
						"recruit",
						"dragonSpeed",
						"tempest"
					].includes(e.kind) ? "troop" : e.kind === "kill" ? "blood" : "move") }), /* @__PURE__ */ f("b", { children: e.n ?? 1 })] }, t)),
					/* @__PURE__ */ f(pt, { stats: r.stats }),
					e === 26 && /* @__PURE__ */ f(Z, { id: "troop" }),
					e === 28 || e === 33 ? /* @__PURE__ */ p(d, { children: [
						/* @__PURE__ */ f(Z, { id: "influence" }),
						/* @__PURE__ */ f("span", { children: "→" }),
						/* @__PURE__ */ f(Z, { id: e === 28 ? "koku" : "troop" })
					] }) : null,
					e === 38 && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f(Z, { id: "strength" }), /* @__PURE__ */ f("b", { children: "2" })] })
				]
			}),
			/* @__PURE__ */ f("b", {
				className: "gn-order-name",
				children: X(e >= 26 ? `order${e}` : r.column, n)
			}),
			/* @__PURE__ */ f("div", {
				className: "gn-order-cost",
				children: !!r.cost.length && /* @__PURE__ */ p(d, { children: [r.costN > 1 && /* @__PURE__ */ p("b", { children: [r.costN, "×"] }), r.cost.map((e, t) => /* @__PURE__ */ p("span", { children: [t > 0 && /* @__PURE__ */ f("i", { children: "/" }), /* @__PURE__ */ f(Z, {
					id: e,
					size: 18
				})] }, e))] })
			})
		]
	}) : null;
}
function mt({ id: e }) {
	let t = s();
	return /* @__PURE__ */ p("article", {
		className: "gn-hero-card",
		style: dt(Math.floor(e / 3)),
		children: [
			/* @__PURE__ */ f("h3", { children: w[e] }),
			/* @__PURE__ */ f("img", {
				src: `games/gunsen/live/hero-${e}.svg`,
				alt: w[e]
			}),
			/* @__PURE__ */ f(pt, { stats: ce[e] }),
			/* @__PURE__ */ f("p", { children: t(it[e]) })
		]
	});
}
function ht({ id: e }) {
	let t = s();
	return /* @__PURE__ */ p("article", {
		className: "gn-text-card",
		children: [/* @__PURE__ */ p("h3", { children: [
			/* @__PURE__ */ f(Z, { id: "koku" }),
			/* @__PURE__ */ f("b", { children: se[e] }),
			t(nt[e])
		] }), /* @__PURE__ */ f("p", { children: t(rt[e]) })]
	});
}
function gt({ id: e, claimed: t = !1 }) {
	let n = s();
	return /* @__PURE__ */ p("article", {
		className: "gn-text-card",
		"data-claimed": t,
		children: [/* @__PURE__ */ p("h3", { children: [/* @__PURE__ */ f(Z, { id: "goal" }), n(et[e])] }), /* @__PURE__ */ f("p", { children: n(tt[e]) })]
	});
}
function _t({ clan: e, camp: t = !1 }) {
	let n = s();
	return /* @__PURE__ */ p("article", {
		className: "gn-text-card",
		children: [/* @__PURE__ */ p("h3", { children: [
			/* @__PURE__ */ f(Z, { id: "wood" }),
			/* @__PURE__ */ f("b", { children: t ? 2 : 3 }),
			n(t ? "games.gunsen.camp" : at[e])
		] }), /* @__PURE__ */ f("p", { children: n(t ? "games.gunsen.campText" : ot[e]) })]
	});
}
function vt({ values: e }) {
	let t = s();
	return /* @__PURE__ */ f("div", {
		className: "gn-resources",
		children: y.map((n) => /* @__PURE__ */ p("span", {
			title: X(n, t),
			children: [/* @__PURE__ */ f(Z, { id: n }), /* @__PURE__ */ f("b", { children: /* @__PURE__ */ f(ne, { value: e[n] }) })]
		}, n))
	});
}
function yt({ face: e, index: t, selected: n = !1 }) {
	let r = T[e];
	return /* @__PURE__ */ p("span", {
		className: "gn-die",
		"data-selected": n,
		children: [t !== void 0 && /* @__PURE__ */ f("small", { children: t + 1 }), Object.entries(r).map(([e, t]) => Array.from({ length: t }, (t, n) => /* @__PURE__ */ f(Z, {
			id: e,
			size: 19,
			die: !0
		}, `${e}-${n}`)))]
	});
}
//#endregion
//#region src/games/gunsen/board-view.tsx
var bt = (e, t) => ({
	x: 340 + e * 292,
	y: 255 + t * 167.5
});
function xt({ rid: e, space: t, n, color: r }) {
	let { ref: i, hidden: a } = l(`army:${e}:${t}`);
	return /* @__PURE__ */ f("foreignObject", {
		x: "-4",
		y: "-4",
		width: "112",
		height: "69",
		children: /* @__PURE__ */ f("div", {
			ref: i,
			style: {
				width: "100%",
				height: "100%",
				visibility: a ? "hidden" : void 0
			},
			children: /* @__PURE__ */ f(ft, {
				n,
				color: r
			})
		})
	});
}
function St({ pub: e, choices: t = [], names: n, onSpace: r, fitKey: i = "map" }) {
	let a = s(), o = e.players.length <= 3, c = new Set(t.filter((e) => e.space).map((e) => e.space));
	return /* @__PURE__ */ p(m, {
		sheetW: o ? 2120 : 2880,
		sheetH: 2460,
		fitKey: i,
		clampToSheet: !0,
		highlight: "off",
		eligible: e.map.map((e) => {
			let t = bt(e.q, e.t);
			return {
				key: e.id,
				rect: {
					x: t.x - 135,
					y: t.y - 130,
					w: 270,
					h: 260
				}
			};
		}),
		onTapEligible: r,
		readOnly: !r,
		children: [
			/* @__PURE__ */ f("rect", {
				width: o ? 2120 : 2880,
				height: "2460",
				fill: "#e6dcc2"
			}),
			/* @__PURE__ */ f("image", {
				href: `games/gunsen/live/map-${o ? "small" : "large"}.svg`,
				x: "120",
				y: "80",
				width: o ? 2e3 : 2760,
				height: "2380",
				preserveAspectRatio: "none"
			}),
			e.map.map((t) => {
				let { x: r, y: i } = bt(t.q, t.t), o = e.players.filter((e) => (t.armies[e.rid] ?? 0) > 0), s = c.has(t.id), l = e.battle?.space === t.id, u = [
					[193, 0],
					[96.5, 167],
					[-96.5, 167],
					[-193, 0],
					[-96.5, -167],
					[96.5, -167]
				].map(([e, t]) => `${r + e},${i + t}`).join(" ");
				return /* @__PURE__ */ p("g", {
					className: "gn-map-hex",
					children: [
						/* @__PURE__ */ f("polygon", {
							points: u,
							fill: s ? "#fff0bb" : "#fff8e4",
							fillOpacity: s ? .58 : .08,
							stroke: l ? "#b62b2c" : s ? "#714422" : "#796d52",
							strokeWidth: l ? 12 : s ? 8 : 2,
							strokeOpacity: l || s ? 1 : .3
						}),
						s && /* @__PURE__ */ f("polygon", {
							points: u,
							fill: "none",
							stroke: "#fff8db",
							strokeWidth: "5",
							strokeDasharray: "14 14",
							pointerEvents: "none",
							children: /* @__PURE__ */ f("animate", {
								attributeName: "stroke-dashoffset",
								from: "0",
								to: "-28",
								dur: "1s",
								repeatCount: "indefinite"
							})
						}),
						t.kind === "shrine" && /* @__PURE__ */ p("g", {
							transform: `translate(${r - 50} ${i - 112})`,
							children: [
								/* @__PURE__ */ f("path", {
									d: "M-7 3q60 22 120 0l-4 19H-4Z",
									fill: "#a9443a",
									stroke: "#654131",
									strokeWidth: "4"
								}),
								/* @__PURE__ */ f("path", {
									d: "M4 48h94M18 22l-2 74m68-74 2 74",
									stroke: "#72523a",
									strokeWidth: "10"
								}),
								/* @__PURE__ */ f("rect", {
									x: "24",
									y: "23",
									width: "50",
									height: "30",
									rx: "4",
									fill: "#eee4cd"
								}),
								/* @__PURE__ */ f("text", {
									x: "49",
									y: "45",
									textAnchor: "middle",
									fontSize: "25",
									fill: "#5b3d2e",
									children: X(t.shrine, a)
								})
							]
						}),
						t.kind === "tower" && /* @__PURE__ */ p("g", {
							transform: `translate(${r - 44} ${i - 122})`,
							children: [
								/* @__PURE__ */ f("path", {
									d: "M16 23h56v83H16Z",
									fill: "#d8cfaf",
									stroke: "#4b5042",
									strokeWidth: "5"
								}),
								/* @__PURE__ */ f("path", {
									d: "M1 24 20 5h48l19 19ZM9 66h70",
									fill: "#40615c",
									stroke: "#3d4d3f",
									strokeWidth: "6"
								}),
								/* @__PURE__ */ f("path", {
									d: "M29 42h30M29 80h30",
									stroke: "#605744",
									strokeWidth: "7"
								})
							]
						}),
						t.kind === "city" && /* @__PURE__ */ f("text", {
							x: r,
							y: i - 98,
							textAnchor: "middle",
							className: "gn-map-label",
							children: a("games.gunsen.city")
						}),
						t.kind === "fort" && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("rect", {
							x: r - 117,
							y: i - 126,
							width: "234",
							height: "42",
							rx: "6",
							fill: t.fort ? b[e.players.find((e) => e.rid === t.fort).clan] : "#665b49"
						}), /* @__PURE__ */ p("text", {
							x: r,
							y: i - 96,
							textAnchor: "middle",
							fontSize: "28",
							fill: "#fff9e5",
							children: [t.fort ? n[t.fort] : a("games.gunsen.fort"), t.min > e.players.length ? " ×" : ""]
						})] }),
						t.village && /* @__PURE__ */ p("g", {
							transform: `translate(${r + 70} ${i + 28})`,
							children: [/* @__PURE__ */ f("circle", {
								r: "33",
								fill: "#bdab76",
								stroke: "#594d35",
								strokeWidth: "4"
							}), /* @__PURE__ */ f("path", {
								d: "m-19 5 19-19L19 5v17h-38Z",
								fill: "#f4e9c7",
								stroke: "#564d38",
								strokeWidth: "4"
							})]
						}),
						t.building && /* @__PURE__ */ p("g", {
							transform: `translate(${r - 80} ${i + 30})`,
							children: [/* @__PURE__ */ f("circle", {
								r: "34",
								fill: b[e.players.find((e) => e.rid === t.building.owner).clan],
								stroke: "#f3e8cb",
								strokeWidth: "5"
							}), /* @__PURE__ */ f("path", {
								d: t.building.kind === "camp" ? "M-22 18 0-21 22 18ZM0-21v39" : "M-19 0 0-20 19 0M-15-1v24h30V-1",
								fill: "#efe3c3",
								stroke: "#55472c",
								strokeWidth: "4"
							})]
						}),
						o.map((e, s) => /* @__PURE__ */ p("g", {
							transform: `translate(${r - 54 + s * 78 - (o.length > 1 ? 35 : 0)} ${i - 16})`,
							children: [
								/* @__PURE__ */ f(xt, {
									rid: e.rid,
									space: t.id,
									n: t.armies[e.rid],
									color: b[e.clan]
								}),
								/* @__PURE__ */ p("text", {
									x: "50",
									y: "92",
									textAnchor: "middle",
									fontSize: "25",
									className: "gn-map-name",
									children: [
										n[e.rid],
										" · ",
										a($e[e.clan])
									]
								}),
								(t.heroes[e.rid] ?? []).map((e, t) => /* @__PURE__ */ p("g", { children: [
									/* @__PURE__ */ f("image", {
										href: `games/gunsen/live/hero-${e}.svg`,
										x: t * 59,
										y: "-67",
										width: "54",
										height: "54",
										preserveAspectRatio: "xMidYMid slice"
									}),
									/* @__PURE__ */ f("title", { children: w[e] }),
									/* @__PURE__ */ f("rect", {
										x: t * 59,
										y: "-67",
										width: "54",
										height: "54",
										fill: "none",
										stroke: "#e3bd64",
										strokeWidth: "4"
									})
								] }, e))
							]
						}, e.rid)),
						/* @__PURE__ */ f("text", {
							x: r,
							y: i + 141,
							textAnchor: "middle",
							fontSize: "25",
							fill: "#5b523e",
							children: t.id
						}),
						/* @__PURE__ */ f(re, {
							name: `space:${t.id}`,
							r: {
								x: r - 58,
								y: i - 20,
								w: 112,
								h: 69
							}
						})
					]
				}, t.id);
			})
		]
	});
}
//#endregion
//#region src/games/gunsen/view-player.tsx
function Ct({ title: e, close: t, children: r }) {
	let a = s(), o = i(null), c = i(null);
	return n(() => (c.current = document.activeElement, o.current?.focus(), () => c.current?.focus()), []), /* @__PURE__ */ f("div", {
		className: "gn-modal",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": e,
		tabIndex: -1,
		ref: o,
		onKeyDown: (e) => {
			if (e.key === "Escape" && (e.stopPropagation(), t()), e.key === "Tab") {
				let t = o.current?.querySelectorAll("button:not(:disabled),a[href]"), n = t?.[0], r = t?.[t.length - 1];
				n && r && (document.activeElement === o.current || e.shiftKey && document.activeElement === n || !e.shiftKey && document.activeElement === r) && (e.preventDefault(), (e.shiftKey ? r : n).focus());
			}
		},
		children: /* @__PURE__ */ p("section", {
			className: "gn-dialog",
			children: [/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", { children: e }), /* @__PURE__ */ f("button", {
				className: "gn-button",
				onClick: t,
				children: a("games.gunsen.close")
			})] }), /* @__PURE__ */ f("div", {
				className: "gn-dialog-scroll",
				children: r
			})]
		})
	});
}
function wt({ id: e, slot: t, onClick: n }) {
	let { ref: r, hidden: i } = l(`market:${t}`);
	return /* @__PURE__ */ f("button", {
		ref: r,
		style: { visibility: i ? "hidden" : void 0 },
		className: "gn-market-card",
		onClick: n,
		children: /* @__PURE__ */ f(Q, { id: e })
	});
}
function Tt({ c: e }) {
	return /* @__PURE__ */ p(d, { children: [
		e.card >= 0 && [
			"draft",
			"nobleDraft",
			"special",
			"activateCard"
		].includes(e.group) && /* @__PURE__ */ f(Q, {
			id: e.card,
			compact: !0
		}),
		e.hero >= 0 && /* @__PURE__ */ f("img", {
			className: "gn-choice-portrait",
			src: `games/gunsen/live/hero-${e.hero}.svg`,
			alt: w[e.hero]
		}),
		e.group === "strategize" && /* @__PURE__ */ f(yt, { face: e.n })
	] });
}
function Et({ pub: e, names: t }) {
	let n = s(), { ref: r } = l("battle"), i = e.battle;
	return i ? /* @__PURE__ */ p("div", {
		ref: r,
		className: "gn-battle",
		children: [/* @__PURE__ */ p("h3", { children: [
			n("games.gunsen.battle"),
			" · ",
			i.space
		] }), /* @__PURE__ */ f("div", {
			className: "gn-battle-sides",
			children: [i.defender, i.attacker].map((e) => /* @__PURE__ */ p("div", { children: [
				/* @__PURE__ */ f("b", { children: t[e] }),
				/* @__PURE__ */ f("small", { children: n(e === i.attacker ? "games.gunsen.attacker" : "games.gunsen.defender") }),
				i.stats[e] && /* @__PURE__ */ f(pt, { stats: {
					strength: i.stats[e].strength,
					blood: i.stats[e].blood,
					armor: i.stats[e].armor
				} }),
				/* @__PURE__ */ f("div", {
					className: "gn-dice-row",
					children: (i.dice[e] ?? []).map((e, t) => /* @__PURE__ */ f(yt, {
						face: e,
						index: t
					}, t))
				}),
				!!i.kept[e]?.length && /* @__PURE__ */ f("div", {
					className: "gn-dice-row gn-kept",
					children: i.kept[e].map((e, t) => /* @__PURE__ */ f(yt, {
						face: e,
						selected: !0
					}, t))
				})
			] }, e))
		})]
	}) : null;
}
function Dt(e) {
	c();
	let t = s(), n = o((e) => e.locale), r = e.public, i = e.private, { ref: ne } = l("clan-board"), { ref: re } = l("market"), m = Object.fromEntries(r.players.map((t) => {
		let r = e.members.find((e) => e.rid === t.rid);
		return [t.rid, r ? te(r, n) : t.rid];
	})), [h, g] = a(""), [_, ie] = a({
		serial: -1,
		space: ""
	}), [y, b] = a(""), [x, S] = a(!1), [ae, oe] = a(!0), [se, ce] = a(0), [T, le] = a(e.myRid), E = i?.choices ?? [], D = E.find((e) => e.id === h), ue = r.acting === e.myRid && E.length > 0, de = _.serial === r.serial && _.space ? E.filter((e) => e.space === _.space || !e.space && ["skip", "cancel"].includes(e.key)) : E, O = r.players.find((e) => e.rid === T) ?? r.players.find((t) => t.rid === e.myRid) ?? r.players[0], fe = st[`prompt_${r.prompt}`], pe = ue ? t(fe || "games.gunsen.chooseTarget") : t("games.gunsen.waiting", { name: m[r.acting] ?? "" }), me = () => {
		D && (e.send({
			type: "act",
			id: D.id
		}), g(""));
	}, he = (e) => {
		E.some((t) => t.space === e) ? (ie({
			serial: r.serial,
			space: e
		}), g("")) : b(`space:${e}`);
	}, ge = () => b(""), _e = /* @__PURE__ */ p("div", {
		className: "gn-clan-board",
		style: dt(O.clan),
		children: [
			/* @__PURE__ */ p("header", { children: [/* @__PURE__ */ f("h2", { children: O.clan >= 0 ? t($e[O.clan]) : m[O.rid] }), /* @__PURE__ */ f("b", { children: t("games.gunsen.score", { n: O.achievements.length }) })] }),
			/* @__PURE__ */ f(vt, { values: O.resources }),
			/* @__PURE__ */ p("div", {
				className: "gn-board-meta",
				children: [/* @__PURE__ */ p("span", { children: [/* @__PURE__ */ f(Z, { id: "troop" }), t("games.gunsen.reserve", { n: O.reserve })] }), /* @__PURE__ */ p("span", { children: [
					t("games.gunsen.tokens"),
					" ",
					O.villages.length,
					"/3"
				] })]
			}),
			/* @__PURE__ */ f("div", {
				className: "gn-columns",
				children: v.map((e) => /* @__PURE__ */ p("section", {
					style: { "--gn-column": ut[e] },
					children: [
						/* @__PURE__ */ p("h3", { children: [X(e, t), r.upgrades[e] === O.rid && /* @__PURE__ */ f("span", {
							className: "gn-upgrade",
							children: "◆"
						})] }),
						/* @__PURE__ */ f("div", {
							className: "gn-column-cards",
							children: O.columns[e].map((e, t) => /* @__PURE__ */ f("button", {
								className: "gn-column-card",
								onClick: () => b(`order:${e}`),
								children: /* @__PURE__ */ f(Q, {
									id: e,
									compact: !0
								})
							}, `${e}-${t}`))
						}),
						/* @__PURE__ */ f("div", {
							className: "gn-column-base",
							children: e === "expand" ? /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f(Z, { id: "koku" }),
								/* @__PURE__ */ f("b", { children: r.upgrades.expand === O.rid ? "+" : "/" }),
								/* @__PURE__ */ f(Z, { id: "wood" })
							] }) : e === "armory" ? /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f(Z, { id: "roll" }),
								/* @__PURE__ */ f("b", { children: r.upgrades.armory === O.rid ? 4 : 3 }),
								/* @__PURE__ */ f(Z, { id: "keep" }),
								/* @__PURE__ */ f("b", { children: "2" })
							] }) : /* @__PURE__ */ p(d, { children: [
								/* @__PURE__ */ f(Z, { id: e === "recruit" ? "troop" : "influence" }),
								/* @__PURE__ */ f("b", { children: r.upgrades[e] === O.rid ? 2 : 1 }),
								/* @__PURE__ */ f(Z, { id: "move" })
							] })
						})
					]
				}, e))
			}),
			/* @__PURE__ */ f("div", {
				className: "gn-nobles",
				children: [
					1,
					2,
					3
				].map((e) => /* @__PURE__ */ p("button", {
					className: "gn-noble",
					"data-used": O.nobles.includes(e),
					onClick: () => b(`noble:${e}`),
					children: [
						/* @__PURE__ */ f(Z, {
							id: "influence",
							size: 20
						}),
						/* @__PURE__ */ f("b", { children: e }),
						/* @__PURE__ */ f("span", { children: O.nobles.includes(e) ? t("games.gunsen.used") : t("games.gunsen.nobles") })
					]
				}, e))
			}),
			/* @__PURE__ */ f("div", {
				className: "gn-board-links",
				children: [
					"cards",
					"goals",
					"achievements"
				].map((e) => /* @__PURE__ */ f("button", {
					className: "gn-button",
					onClick: () => b(e),
					children: X(e, t)
				}, e))
			}),
			/* @__PURE__ */ f("div", {
				className: "gn-owned-heroes",
				children: O.heroes.map((e) => /* @__PURE__ */ p("button", {
					onClick: () => b(`hero:${e}`),
					children: [/* @__PURE__ */ f("img", {
						src: `games/gunsen/live/hero-${e}.svg`,
						alt: w[e]
					}), /* @__PURE__ */ f("span", { children: w[e] })]
				}, e))
			})
		]
	}), ve = /* @__PURE__ */ f("div", {
		className: "gn-choice-list",
		children: de.map((e) => /* @__PURE__ */ p("button", {
			className: "gn-choice",
			"data-selected": D?.id === e.id,
			onClick: () => g(e.id),
			"aria-pressed": D?.id === e.id,
			children: [/* @__PURE__ */ f(Tt, { c: e }), /* @__PURE__ */ f("span", { children: ct(e, t, m) })]
		}, e.id))
	}), k = null;
	if (y) {
		let n, a = X(y, t);
		if (y.startsWith("order:")) {
			let e = Number(y.slice(6)), r = C[e];
			a = X(e >= 26 ? `order${e}` : r.column, t), n = /* @__PURE__ */ p("div", {
				className: "gn-inspect-order",
				children: [/* @__PURE__ */ f(Q, { id: e }), /* @__PURE__ */ f("p", { children: e >= 26 ? X(`orderText${e}`, t) : /* @__PURE__ */ f(pt, { stats: r.stats }) })]
			});
		} else if (y.startsWith("hero:")) {
			let e = Number(y.slice(5));
			a = w[e], n = /* @__PURE__ */ f(mt, { id: e });
		} else if (y.startsWith("noble:")) {
			let e = Number(y.slice(6));
			a = t("games.gunsen.nobles"), n = /* @__PURE__ */ f("p", { children: X(`nobleText${e}`, t) });
		} else if (y.startsWith("space:")) {
			let e = r.map.find((e) => e.id === y.slice(6));
			a = `${X(e.kind, t)} · ${e.id}`, n = /* @__PURE__ */ p("div", {
				className: "gn-space-info",
				children: [
					r.players.filter((t) => e.armies[t.rid]).map((n) => /* @__PURE__ */ p("div", {
						style: dt(n.clan),
						children: [
							/* @__PURE__ */ p("h3", { children: [
								m[n.rid],
								" · ",
								t($e[n.clan])
							] }),
							/* @__PURE__ */ f("p", { children: t("games.gunsen.army", { n: e.armies[n.rid] }) }),
							(e.heroes[n.rid] ?? []).map((e) => /* @__PURE__ */ f(mt, { id: e }, e))
						]
					}, n.rid)),
					e.building && /* @__PURE__ */ f(_t, {
						clan: r.players.find((t) => t.rid === e.building.owner).clan,
						camp: e.building.kind === "camp"
					}),
					e.kind === "shrine" && /* @__PURE__ */ p("p", { children: [
						t("games.gunsen.upgrades"),
						" · ",
						X(e.shrine, t)
					] })
				]
			});
		} else n = y === "goals" ? /* @__PURE__ */ f("div", {
			className: "gn-card-grid",
			children: O.clan >= 0 && [
				0,
				1,
				2
			].map((e) => /* @__PURE__ */ f(gt, {
				id: O.clan * 3 + e,
				claimed: O.goals.includes(O.clan * 3 + e)
			}, e))
		}) : y === "achievements" ? /* @__PURE__ */ f("ol", {
			className: "gn-achievement-list",
			children: O.achievements.map((e) => /* @__PURE__ */ p("li", { children: [/* @__PURE__ */ f(Z, { id: "goal" }), lt(e, t)] }, e))
		}) : y === "history" ? /* @__PURE__ */ f("ol", {
			className: "gn-log",
			children: [...r.log].reverse().map((e, n) => {
				let r = { ...e.params };
				for (let e of [
					"resource",
					"column",
					"building"
				]) r[e] !== void 0 && (r[e] = X(r[e], t));
				return r.achievement &&= lt(String(r.achievement), t), r.tactic !== void 0 && (r.tactic = X(`tactic${r.tactic}`, t)), r.hero !== void 0 && (r.hero = w[Number(r.hero)]), /* @__PURE__ */ p("li", { children: [
					/* @__PURE__ */ f("b", { children: m[e.rid] }),
					" · ",
					X(`log_${e.key}`, (e, n) => t(e, n ?? r))
				] }, n);
			})
		}) : /* @__PURE__ */ f("div", {
			className: "gn-card-grid",
			children: O.clan >= 0 && /* @__PURE__ */ p(d, { children: [
				/* @__PURE__ */ f("h3", { children: t("games.gunsen.heroes") }),
				[
					0,
					1,
					2
				].map((e) => /* @__PURE__ */ f(mt, { id: O.clan * 3 + e }, e)),
				/* @__PURE__ */ f("h3", { children: t("games.gunsen.tactics") }),
				[
					13 + O.clan * 2,
					14 + O.clan * 2,
					...O.tactics.filter((e) => e < 13)
				].map((e) => /* @__PURE__ */ f(ht, { id: e }, e)),
				O.rid === e.myRid && /* @__PURE__ */ p(d, { children: [/* @__PURE__ */ f("h3", { children: t("games.gunsen.privateTactics") }), i?.tactics.map((e) => /* @__PURE__ */ f(ht, { id: e }, e))] }),
				/* @__PURE__ */ f("h3", { children: t("games.gunsen.specials") }),
				[26 + O.clan * 2, 27 + O.clan * 2].map((e) => /* @__PURE__ */ p("article", {
					className: "gn-text-card",
					children: [/* @__PURE__ */ f(Q, { id: e }), /* @__PURE__ */ f("p", { children: X(`orderText${e}`, t) })]
				}, e)),
				/* @__PURE__ */ f("h3", { children: t("games.gunsen.buildings") }),
				/* @__PURE__ */ f(_t, { clan: O.clan }),
				/* @__PURE__ */ f(_t, {
					clan: O.clan,
					camp: !0
				})
			] })
		});
		k = /* @__PURE__ */ f(Ct, {
			title: a,
			close: ge,
			children: n
		});
	}
	return /* @__PURE__ */ f(u, {
		adaptive: !0,
		scroll: !1,
		className: "gn-screen",
		actionsHeight: "gn-actions-height",
		banner: /* @__PURE__ */ p("div", {
			className: "gn-heading",
			children: [/* @__PURE__ */ p("div", {
				className: "gn-heading-title",
				children: [/* @__PURE__ */ f("b", { children: t("games.gunsen.name") }), /* @__PURE__ */ f("button", {
					className: "gn-button",
					onClick: () => b("history"),
					children: t("games.gunsen.history")
				})]
			}), /* @__PURE__ */ f(ee, {
				tone: ue ? "accent" : "info",
				accent: "#913b32",
				text: pe,
				chip: t("games.gunsen.turn", { n: r.turn })
			})]
		}),
		actions: /* @__PURE__ */ p("div", {
			className: "gn-actions",
			children: [/* @__PURE__ */ p("div", {
				className: "gn-action-heading",
				children: [
					/* @__PURE__ */ f("strong", { children: D ? ct(D, t, m) : pe }),
					_.serial === r.serial && _.space && /* @__PURE__ */ f("button", {
						className: "gn-button",
						onClick: () => ie({
							serial: -1,
							space: ""
						}),
						children: t("games.gunsen.cancel")
					}),
					/* @__PURE__ */ f("button", {
						className: "gn-confirm",
						disabled: !D,
						onClick: me,
						children: t("games.gunsen.confirm")
					})
				]
			}), ue ? ve : /* @__PURE__ */ f("div", {
				className: "gn-waiting",
				children: t("games.gunsen.resolving")
			})]
		}),
		overlay: k,
		children: /* @__PURE__ */ p("div", {
			className: "gn-table",
			inert: !!k,
			children: [
				/* @__PURE__ */ p("div", {
					ref: re,
					className: "gn-market",
					children: [/* @__PURE__ */ f("span", {
						className: "gn-section-label",
						children: t("games.gunsen.orders")
					}), /* @__PURE__ */ f("div", {
						className: "gn-market-row",
						children: r.market.map((e, t) => /* @__PURE__ */ f(wt, {
							id: e,
							slot: t,
							onClick: () => {
								let t = E.find((t) => t.card === e && ["draft", "nobleDraft"].includes(t.group));
								t ? (g(t.id), ie({
									serial: -1,
									space: ""
								})) : b(`order:${e}`);
							}
						}, `${t}:${e}`))
					})]
				}),
				/* @__PURE__ */ f("div", {
					className: "gn-player-row",
					children: r.players.map((e) => /* @__PURE__ */ p("button", {
						className: "gn-player",
						"data-active": e.rid === r.active,
						style: dt(e.clan),
						onClick: () => {
							le(e.rid), S(!0);
						},
						children: [
							/* @__PURE__ */ f("i", {}),
							/* @__PURE__ */ f("span", { children: m[e.rid] }),
							/* @__PURE__ */ p("b", { children: [e.achievements.length, "/7"] })
						]
					}, e.rid))
				}),
				/* @__PURE__ */ p("div", {
					className: "gn-main",
					children: [/* @__PURE__ */ p("section", {
						className: "gn-map-area",
						children: [
							/* @__PURE__ */ p("div", {
								className: "gn-map-toolbar",
								children: [
									/* @__PURE__ */ f("button", {
										className: "gn-button",
										onClick: () => ce((e) => e + 1),
										children: t("games.gunsen.overview")
									}),
									/* @__PURE__ */ f("button", {
										className: "gn-button gn-open-board",
										onClick: () => S((e) => !e),
										children: t("games.gunsen.clanBoard")
									}),
									r.battle && /* @__PURE__ */ f("button", {
										className: "gn-button",
										onClick: () => oe((e) => !e),
										children: t("games.gunsen.battle")
									})
								]
							}),
							/* @__PURE__ */ f(St, {
								pub: r,
								choices: E,
								names: m,
								onSpace: he,
								fitKey: String(se)
							}),
							ae && /* @__PURE__ */ f(Et, {
								pub: r,
								names: m
							})
						]
					}), /* @__PURE__ */ p("aside", {
						ref: ne,
						className: "gn-sidebar",
						"data-open": x,
						children: [x && /* @__PURE__ */ f("button", {
							className: "gn-button gn-close-board",
							onClick: () => S(!1),
							children: t("games.gunsen.close")
						}), _e]
					})]
				})
			]
		})
	});
}
//#endregion
//#region src/games/gunsen/bot.ts
function Ot(e) {
	let t = 2166136261;
	for (let n of e) t = Math.imul(t ^ n.charCodeAt(0), 16777619);
	return t >>> 0;
}
function kt(e, t) {
	return e.armies[t] ?? 0;
}
function $(e, t, n) {
	let r = e.players.find((e) => e.rid === n), i = kt(t, n), a = Object.entries(t.armies).filter(([e]) => e !== n).reduce((e, [, t]) => e + t, 0);
	if (t.kind === "fort") return -2;
	let o = t.village ? r.villages.length < 3 ? 9 : 4 : 0;
	return t.kind === "shrine" && (o += i ? 1 : (r.achievements.includes("shrines") ? 7 : 12) + (e.map.filter((e) => e.kind === "shrine" && kt(e, n) > 0).length === 1 ? 5 : 0)), t.kind === "city" && (o += i ? 8 : 20 + (r.achievements.length >= 5 ? 16 : 0) + (r.achievements.includes("city") ? 0 : 5)), t.building && t.building.owner !== n && (o += 7), a && (o += 2), i && (o -= 3), o;
}
function At(e, t, n, r) {
	let i = Object.entries(t.armies).filter(([e]) => e !== n).reduce((e, [, t]) => e + t, 0), a = $(e, t, n);
	i && r < i ? a -= (i - r) * 5 + 4 : i && (a += Math.min(4, r - i));
	let o = e.map.filter((t) => t.kind !== "fort" && !kt(t, n) && $(e, t, n) >= 7);
	return o.length && (a += Math.max(...o.map((r) => $(e, r, n) / (D(t, r) + 1))) * .65), (t.kind === "plain" || t.kind === "village" && !t.village) && (a += 1), a;
}
function jt(e, t, n) {
	let r = t.players.find((e) => e.rid === n), i = JSON.parse(e.id.slice(e.id.indexOf(":") + 1)), a = t.map.find((t) => t.id === e.space), o = e.value, s = 15 - r.reserve, c = r.buildings.length < 2 ? 5 - (r.buildings.includes("unique") ? 3 : r.buildings.includes("camp") ? 2 : 0) : 0;
	switch (i.op) {
		case "clan": return Ot(n + t.serial) % 7 === e.n ? 2 : 1;
		case "fort": return 2 + Ot(e.id) % 100 / 100;
		case "clear": return -4;
		case "draft": {
			let t = C[e.card], n = t.column;
			o = 4 + (n === "expand" ? r.buildings.length < 2 || r.tactics.length < 3 ? 3 : -3 : n === "influence" ? r.nobles.length < 3 ? 4 : 2 : n === "recruit" ? 2 : 1), n !== "any" && (n !== "expand" || r.buildings.length < 2 || r.tactics.length < 3) && (o += Math.min(4, r.columns[n].length) * .5), r.resources.wood < c && t.effects.some((e) => e.resource === "wood") && (o += 3), r.resources.influence < 3 && t.effects.some((e) => e.resource === "influence") && (o += 3), r.reserve < 4 && n === "recruit" && (o -= 3), r.resources.koku < 4 && t.effects.some((e) => e.resource === "koku") && (o += 3), r.resources.wood >= 2 && r.buildings.length < 2 && n === "expand" && (o += 3), r.resources.koku >= 3 && r.tactics.length < 3 && n === "expand" && (o += 3);
			break;
		}
		case "noble": return 7 + r.nobles.length * 2 + (i.n === 2 ? 2 : 0);
		case "place": return (i.col === "expand" ? 1 + (r.resources.wood >= 2 && r.buildings.length < 2 ? 7 : 0) + (r.resources.koku >= 2 && r.tactics.length < 3 ? 6 : 0) : i.col === "influence" ? 6 + (r.nobles.length < 3 && r.resources.influence < 6 ? 4 : 0) : i.col === "recruit" ? 5 + (s < 8 ? 4 : r.reserve > 3 ? 2 : 0) : 6) + (i.col === "expand" && r.buildings.length >= 2 && r.tactics.length >= 3 ? 0 : Math.min(4, r.columns[i.col].length) * .5);
		case "useCard": return 5;
		case "gain": return 6;
		case "gainOne": return i.a === "wood" ? r.resources.wood < c ? 6 : r.resources.wood < 3 ? 4 : 2 : r.resources.koku < 5 ? 5 : 3;
		case "expandBoth": return 8;
		case "recruit": return a ? 4 + $(t, a, n) * .1 + (a.fort ? s < 9 ? 2 : -1 : 2) : 4;
		case "build": return 9 + +(i.b === "camp") + (a && kt(a, n) ? 2 : 0) + r.buildings.length * 3;
		case "buyTactic": return 9 + r.tactics.length * 2 + +!![
			1,
			2,
			6,
			12,
			14,
			16,
			18,
			20,
			22,
			24,
			26
		].includes(i.n ?? -1);
		case "hero": return 9 + (a?.fort ? 0 : 3);
		case "special": return 8 + (i.col === "expand" ? 2 : 0);
		case "selectArmy": {
			if (!a) return -2;
			let s = kt(a, n), c = s - e.n, l = (a.heroes[n] ?? []).filter((e, t) => (i.mask ?? 0) & 1 << t), u = t.map.filter((e) => E(a, e) && (e.kind !== "fort" || e.fort === n));
			o = u.length ? Math.max(...u.map((r) => At(t, r, n, e.n))) : -5, o += Math.min(e.n, 5) * .4 + l.length * .5, c === 0 && a.kind === "city" ? o -= 20 : c === 0 && a.kind === "shrine" ? o -= r.achievements.includes("shrines") ? 5 : 12 : c === 0 && a.building ? o -= 5 : c === 0 && a.village && (o -= 9), a.fort && (t.prompt === "move" || t.prompt === "moveArmy") && (o += 1), e.n === 1 && s > 2 && u.some((e) => e.kind === "shrine" || e.village) && (o -= 2);
			break;
		}
		case "move":
			o = a ? At(t, a, n, e.n) : -3, i.b === "beforeTower" && (o += 2);
			break;
		case "extraMove": return r.resources.influence > 2 || r.resources.koku > 5 || r.resources.wood > c + 2 ? .5 : -5;
		case "cancelMove": return -100;
		case "kamoko": return 3;
		case "plow": return s - (i.n ?? 0) >= 8 && !a?.village && a?.kind === "plain" ? i.a === "wood" && r.resources.wood < c ? 2 : -3 : -10;
		case "kill": return i.b === n ? -12 : 4;
		case "buildingMove": return -6;
		case "tempest": return a ? 3 + $(t, a, n) * .2 : 1;
		case "moto":
		case "protectHero": return 6;
		case "disableHeroes": return -3;
		case "heroToken": return r.resources.koku > 3 || r.resources.influence > 2 ? 4 : -1;
		case "yokuni": return t.battle && t.battle.initial[n] < t.battle.initial[n === t.battle.attacker ? t.battle.defender : t.battle.attacker] ? 5 : -2;
		case "militia": return r.villages.length >= 3 && r.achievements.includes("villages") ? 1 : -5;
		case "reroll": {
			let e = (t.battle?.dice[n] ?? []).reduce((e, t, n) => t === 4 || t === 5 ? e | 1 << n : e, 0);
			return i.mask === e && e > 0 ? 5 : -3;
		}
		case "finishReroll": return 1;
		case "keep": return (t.battle?.dice[n] ?? []).reduce((e, t, n) => {
			let r = T[t];
			return e + ((i.mask ?? 0) & 1 << n ? r.strength * 1.15 + r.blood + r.armor * .7 : 0);
		}, 0);
		case "strategize": {
			let e = T[i.n], r = T[t.battle.kept[n][i.x]];
			return e.strength * 1.15 + e.blood + e.armor * .7 - r.strength * 1.15 - r.blood - r.armor * .7;
		}
		case "double": {
			let e = T[t.battle.kept[n][i.n]];
			return e.strength * 1.15 + e.blood + e.armor * .7;
		}
		case "battleGoal":
		case "goal": return 12;
		case "battleAchievement": return r.achievements.includes("attack2") ? -5 : 11;
		case "rebirth": return 5;
		case "retreat": return a?.fort ? 3 : 6;
		case "rescueHero": return a?.fort ? 2 : 5;
		case "steal": return 5;
		case "payYoritomo": return 2;
		case "discardYoritomo": return -2;
		case "skip": return [
			"build",
			"buyTactic",
			"extraMove"
		].includes(t.prompt) ? -.5 : -3;
	}
	return typeof e.params.pay == "string" && (o -= e.params.pay.split(",").reduce((e, t) => e + Number(t), 0) * .4), o;
}
function Mt(e = !0) {
	return (t, n) => {
		let r = t.private?.choices ?? [];
		return !r.length || t.public.acting !== n.rid ? null : { action: {
			type: "act",
			id: r.map((r) => ({
				c: r,
				score: n.difficulty === "weak" ? Ot(r.id + t.public.turn) % 100 : e ? jt(r, t.public, n.rid) + Ot(r.id) % 100 / 1e3 : r.value + (r.key === "skip" ? -2 : Ot(r.id) % 10 / 10)
			})).sort((e, t) => t.score - e.score)[0].c.id
		} };
	};
}
var Nt = Mt(), Pt = (e, t, n) => {
	let r = e.type === "act" ? t.private?.choices.find((t) => t.id === e.id) : void 0;
	return r ? ct(r, n) : n("games.gunsen.resolving");
};
//#endregion
//#region src/games/gunsen/fx.tsx
function Ft({ dice: e }) {
	let t = i(null);
	return r(() => {
		let e = Array.from(t.current?.children ?? []).map((e, t) => e.animate([
			{
				transform: "translateY(-14px) rotate(-28deg)",
				opacity: 0
			},
			{
				transform: "translateY(3px) rotate(17deg)",
				opacity: 1,
				offset: .45
			},
			{
				transform: "translateY(-5px) rotate(-8deg)",
				offset: .7
			},
			{ transform: "translateY(0) rotate(0deg)" }
		], {
			duration: 700,
			delay: t * 28,
			easing: "ease-out",
			fill: "both"
		}));
		return () => e.forEach((e) => e.cancel());
	}, []), /* @__PURE__ */ f("div", {
		ref: t,
		className: "gn-fx-dice",
		children: e.map((e, t) => /* @__PURE__ */ f(yt, { face: e }, t))
	});
}
function It({ name: e }) {
	let t = s();
	return /* @__PURE__ */ f("span", {
		className: "gn-fx-caption",
		children: e ? t("games.gunsen.battleWon", { name: e }) : t("games.gunsen.noBattleWinner")
	});
}
var Lt = {
	draft(e, t) {
		let n = e.data, r = t.anchor("market");
		return r ? {
			ms: k.effect,
			node: /* @__PURE__ */ f(h, {
				at: r,
				ms: k.effect,
				children: /* @__PURE__ */ f("div", {
					className: "gn-fx-order",
					children: /* @__PURE__ */ f(Q, {
						id: n.card,
						compact: !0
					})
				})
			})
		} : null;
	},
	orderPlaced(e, t) {
		let n = t.anchor("clan-board");
		return n ? {
			ms: k.effect,
			node: /* @__PURE__ */ f(_, {
				at: n,
				ms: k.effect
			})
		} : null;
	},
	move(e, t) {
		let n = e.data, r = t.anchor(`space:${n.from}`), i = t.anchor(`army:${n.player}:${n.space}`) ?? t.anchor(`space:${n.space}`);
		if (!r || !i) return null;
		let a = {
			...r,
			x: r.x + (n.fromOffset ?? 0) * r.w / 112
		}, o = b[n.clan] ?? "#51483e", s = t.queued === 0 ? [`army:${n.player}:${n.space}`] : [];
		return {
			ms: k.move,
			hide: s,
			node: /* @__PURE__ */ p(d, { children: [s.length > 0 && !!n.toBefore && /* @__PURE__ */ f("div", {
				style: {
					position: "absolute",
					left: i.x,
					top: i.y,
					width: i.w,
					height: i.h
				},
				children: /* @__PURE__ */ f(ft, {
					n: n.toBefore,
					color: o
				})
			}), /* @__PURE__ */ f(g, {
				from: a,
				to: i,
				ms: k.move - 80,
				children: /* @__PURE__ */ f("div", {
					style: {
						width: a.w,
						height: a.h
					},
					children: /* @__PURE__ */ f(ft, {
						n: n.n,
						color: o
					})
				})
			})] })
		};
	},
	recruit(e, t) {
		let n = e.data, r = t.anchor(`space:${n.space}`);
		return r ? {
			ms: k.effect,
			node: /* @__PURE__ */ f(h, {
				at: r,
				ms: k.effect,
				children: /* @__PURE__ */ p("span", {
					className: "gn-fx-caption",
					children: [
						/* @__PURE__ */ f(Z, { id: "troop" }),
						"+",
						n.n
					]
				})
			})
		} : null;
	},
	build(e, t) {
		let n = e.data, r = t.anchor(`space:${n.space}`);
		return r ? {
			ms: k.effect,
			node: /* @__PURE__ */ f(_, {
				at: r,
				ms: k.effect
			})
		} : null;
	},
	battleStart(e, t) {
		let n = t.anchor("battle");
		return n ? {
			ms: k.effect,
			node: /* @__PURE__ */ f(_, {
				at: n,
				ms: k.effect
			})
		} : null;
	},
	roll(e, t) {
		let n = e.data, r = t.anchor("battle");
		return r ? {
			ms: k.roll,
			node: /* @__PURE__ */ f("div", {
				className: "gn-fx-roll",
				style: {
					left: r.x,
					top: r.y,
					width: r.w
				},
				children: /* @__PURE__ */ f(Ft, { dice: n.dice })
			})
		} : null;
	},
	kills(e, t) {
		let n = e.data, r = t.anchor("battle");
		return r ? {
			ms: k.kills,
			node: /* @__PURE__ */ f(h, {
				at: r,
				ms: k.kills,
				children: /* @__PURE__ */ p("span", {
					className: "gn-fx-caption gn-fx-loss",
					children: [/* @__PURE__ */ f(Z, { id: "blood" }), Object.entries(n.kills).filter(([, e]) => e > 0).map(([e, n]) => /* @__PURE__ */ p("span", { children: [
						t.member(e)?.name ?? e,
						" −",
						n
					] }, e))]
				})
			})
		} : null;
	},
	battleResult(e, t) {
		let n = e.data, r = t.anchor("battle");
		return r ? {
			ms: k.result,
			node: /* @__PURE__ */ f(h, {
				at: r,
				ms: k.result,
				children: /* @__PURE__ */ f(It, { name: n.winner ? t.member(n.winner)?.name ?? n.winner : "" })
			})
		} : null;
	}
};
//#endregion
//#region src/games/gunsen/game-over.tsx
function Rt({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: c }) {
	let l = s(), u = o((e) => e.locale), ee = t, [ne, d] = a(!1), [re, m] = a(""), h = Object.fromEntries(ee.players.map((e) => {
		let t = n.find((t) => t.rid === e.rid);
		return [e.rid, t ? te(t, u) : e.rid];
	})), g = e.winner[0];
	return /* @__PURE__ */ p("div", {
		className: "gn-result",
		children: [
			!!g && /* @__PURE__ */ f(ie, {}),
			/* @__PURE__ */ f("h1", { children: g ? l("games.gunsen.victory", { name: h[g] }) : l("session.result.title") }),
			/* @__PURE__ */ p("div", {
				className: "gn-result-actions",
				children: [
					/* @__PURE__ */ f("button", {
						className: "gn-button",
						onClick: () => d((e) => !e),
						children: l(ne ? "games.gunsen.showResults" : "games.gunsen.review")
					}),
					i && /* @__PURE__ */ f("button", {
						className: "gn-confirm",
						onClick: () => m("again"),
						children: l("games.gunsen.again")
					}),
					c && /* @__PURE__ */ f("button", {
						className: "gn-button",
						onClick: () => m("lobby"),
						children: l("games.gunsen.lobby")
					}),
					!i && !c && /* @__PURE__ */ f("span", { children: l("session.result.waitHost") })
				]
			}),
			re && /* @__PURE__ */ p("div", {
				className: "gn-result-confirm",
				role: "alertdialog",
				"aria-label": l("games.gunsen.confirmLeave"),
				children: [
					/* @__PURE__ */ f("p", { children: l("games.gunsen.confirmLeave") }),
					/* @__PURE__ */ f("button", {
						className: "gn-confirm",
						autoFocus: !0,
						onClick: () => {
							re === "again" ? i?.() : c?.();
						},
						children: l(re === "again" ? "games.gunsen.again" : "games.gunsen.lobby")
					}),
					/* @__PURE__ */ f("button", {
						className: "gn-button",
						onClick: () => m(""),
						children: l("games.gunsen.cancel")
					})
				]
			}),
			ne ? /* @__PURE__ */ f("div", {
				className: "gn-result-map",
				children: /* @__PURE__ */ f(St, {
					pub: ee,
					names: h,
					fitKey: "result"
				})
			}) : /* @__PURE__ */ f("div", {
				className: "gn-result-grid",
				children: e.ranking.map((t, n) => {
					let i = ee.players.find((e) => e.rid === t);
					return /* @__PURE__ */ p("section", {
						className: "gn-result-player",
						style: dt(i.clan),
						"data-winner": e.winner.includes(t),
						children: [
							/* @__PURE__ */ p("h2", { children: [
								n + 1,
								". ",
								h[t],
								" ",
								t === r && /* @__PURE__ */ f("small", { children: l("lobby.you") })
							] }),
							/* @__PURE__ */ p("p", { children: [
								l($e[i.clan]),
								" · ",
								l("games.gunsen.score", { n: i.achievements.length })
							] }),
							/* @__PURE__ */ f(vt, { values: i.resources }),
							/* @__PURE__ */ f("ol", {
								className: "gn-achievement-list",
								children: i.achievements.map((e) => /* @__PURE__ */ p("li", { children: [/* @__PURE__ */ f(Z, { id: "goal" }), lt(e, l)] }, e))
							})
						]
					}, t);
				})
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/gunsen/entry.tsx
var zt = {
	definition: Qe,
	View: Dt,
	bot: Nt,
	describe: Pt,
	fx: Lt,
	OverView: Rt,
	locales: {
		zh: {
			name: "军扇：兰波城之战",
			desc: "七大氏族争夺都城，构筑指令，争取七项成就",
			rules: "目标：\n率先获得7项成就。成就包括两次进攻胜利、两个不同的氏族目标、建造两栋建筑、购买三张战术牌、用完三个贵族行动、同时控制两座神社、首次占领都城、持有三个村庄标记，以及持续控制都城。只有持续控制都城的成就会失去。\n准备：\n按随机确定的玩家顺序选择氏族和适用的堡垒位置。每个氏族有15名士兵、3位英雄、2张氏族战术牌、2张私密中立战术牌、2张特殊指令牌和3张目标牌。按人数使用小版图或大版图，并调整指令牌库。\n回合：\n· 从5张公开指令牌中选择1张并支付费用。若其中至少4张同色，或至少4张需要支付费用，可以在选牌前弃置整行并重新补牌。将所选牌放到同色指令列，从新到旧激活该列全部指令，再执行氏族板上的行动；可以跳过指令和板上行动。红底战斗图标在所有列持续生效。\n· 扩张列获得1枚钱币或1份木材，然后可以建造建筑、购买战术牌。\n·  征募列招募1名士兵并移动1次。\n·  影响列获得1点影响力并移动1次。\n·  军备列提供战斗时基础掷3枚骰子、保留2枚的能力，并允许移动1次。\n· 购买额外移动时，军备列支付钱币，征募列支付影响力，影响列支付木材。\n贵族：\n· 可以将所选指令牌面朝下覆盖一个未使用的贵族行动，另行支付对应费用。\n· 支付1点影响力：再选择一张指令牌并支付其费用，将其放在任意列并激活。\n·  支付2点影响力：招募一位氏族英雄并激活任意列。\n·  支付3点影响力：放置一张氏族特殊指令牌并激活其列。\n· 每项贵族行动每局只能使用一次。\n移动：\n每次将一支军队的部分或全部士兵移动到相邻领地，可以拆分或合并军队。普通领地内每个氏族最多有5名士兵，堡垒和营地不受此上限限制。只能进入自己的堡垒。英雄必须随军移动，堡垒外通常每格最多有1位己方英雄。每次移动只能在之前或之后传送一次，可以支付1点影响力，在自己的堡垒与瞭望塔之间或不同瞭望塔之间传送军队。首支进入都城的军队必须具有至少5点军力，并结束本回合的全部移动；之后进入都城不再要求5点军力。进入敌军所在领地立即触发战斗并终止本回合全部移动，但仍须完成指令列内的其他效果。\n建筑与战术：\n激活扩张列时，可以分别支付3份木材和2份木材建造独有建筑和营地。建造地点必须有己方军队、与己方军队相邻，或与自己的堡垒相邻，且不能有敌军、板块或标记。没有军队的建筑归原建造者控制；敌军占领建筑时，可以使用其效果。每人最多购买3张战术牌。未购买的中立战术牌只向本人显示。\n战斗：\n先处理战斗开始时的能力，再由防守方掷骰、重掷并选留，最后由进攻方处理骰子。最多掷6枚骰子。敌方杀伤减去己方护甲决定士兵损失；通常士兵损失不降低已经计算的军力。军力相同时，按进攻方军力较高处理。军力较高的一方必须仍有士兵存活，才算获胜并取得奖励；否则本次战斗没有胜者，另一方仍须撤退。胜者从败方选择一个村庄标记，并获得标记奖励；败军一起撤退到自己的堡垒或一栋己方控制的建筑。进攻胜利最多提供两项成就，部分氏族目标必须与进攻胜利成就二选一。\n回合结束：\n处理建筑和英雄效果，收取己方控制的村庄标记及其隐藏奖励，最多持有3个村庄标记。控制神社可以取得对应升级，升级保留到其他玩家取得它。占领都城可以取得扩张升级和相关成就。所有玩家中，若有玩家在版图上的士兵不足3名，该玩家向自己的堡垒补充士兵，直到版图上共有3名士兵。最后补足公开指令牌，再轮到下一位玩家。\n升级：\n· 军备列改为掷4枚骰子、保留2枚。\n·  征募列招募2名士兵。\n·  影响列获得2点影响力。\n·  扩张列同时获得1枚钱币和1份木材。\n· 各氏族卡牌的完整能力可以在对局内查看。\n数字版补充规则：\n官方规则未说明全部可流通指令均无法支付的情况。仅当当前玩家无法支付公开行、牌堆和弃牌堆中任意一张指令的费用时（反复清行也无法取得指令），本回合不获得新的指令牌，直接选择一列进行激活；这次不能使用贵族行动，其余流程照常。",
			koku: "钱币",
			wood: "木材",
			influence: "影响力",
			troop: "士兵",
			move: "移动",
			strength: "军力",
			blood: "杀伤",
			armor: "护甲",
			roll: "掷骰",
			keep: "保留",
			reroll: "重掷",
			expand: "扩张",
			armory: "军备",
			recruit: "征募",
			plain: "领地",
			village: "村庄",
			shrine: "神社",
			tower: "瞭望塔",
			city: "都城",
			fort: "堡垒",
			unique: "氏族建筑",
			camp: "营地",
			close: "关闭",
			inspect: "查看",
			confirm: "确认行动",
			cancel: "取消",
			skip: "跳过此项",
			resolving: "正在结算",
			waiting: "等待 {{name}}",
			turn: "第 {{n}} 回合",
			orders: "公开指令",
			clanBoard: "氏族主板",
			cards: "氏族卡牌",
			goals: "氏族目标",
			tactics: "战术",
			heroes: "英雄",
			buildings: "建筑",
			specials: "特殊指令",
			history: "战报",
			map: "战场",
			overview: "全景",
			achievements: "成就",
			reserve: "预备兵 {{n}}",
			unclaimed: "尚未取得",
			cost: "支付 {{cost}}",
			free: "免费",
			detail: "{{name}}：{{text}}",
			victory: "{{name}} 获胜",
			again: "再来一局",
			lobby: "返回大厅",
			review: "回看战场",
			showResults: "查看成就",
			privateTactics: "你的未购买战术",
			chooseTarget: "选择行动目标",
			army: "{{n}} 名士兵",
			heroCount: "携带英雄：{{heroes}}",
			none: "无",
			used: "已使用",
			battle: "战斗",
			attacker: "进攻方",
			defender: "防守方",
			dice: "战斗骰",
			tokens: "村庄标记",
			upgrades: "升级",
			nobles: "贵族行动",
			score: "{{n}} / 7 项成就",
			errAction: "此行动当前不可执行",
			errDone: "本局已经结束",
			battleWon: "{{name}}赢得战斗",
			noBattleWinner: "本次战斗无胜者",
			confirmLeave: "确认离开本局结算？",
			prompt_gain: "获得资源或跳过此效果",
			clan0: "狮氏族",
			clan1: "鹤氏族",
			clan2: "独角兽氏族",
			clan3: "蝎氏族",
			clan4: "龙氏族",
			clan5: "凤凰氏族",
			clan6: "蟹氏族",
			chooseClan: "选择{{clan}}",
			chooseFort: "在此建立堡垒",
			takeOrder: "选择这张指令",
			clearRow: "清行并重新发牌",
			activateColumn: "激活{{column}}列",
			useNoble: "使用第 {{n}} 项贵族行动",
			useOrder: "执行这张指令",
			gainBoth: "获得1枚钱币和1份木材",
			gainResource: "获得 {{n}} {{resource}}",
			recruitAt: "在此招募1名士兵",
			chooseDragonArmy: "选择招募与移动的军队",
			buildAt: "在此建造{{building}}",
			buyTactic: "购买{{tactic}}",
			recruitHero: "招募这名英雄",
			addSpecial: "加入{{column}}列",
			selectArmy: "移动 {{n}} 名士兵",
			moveTo: "移动到这里",
			buyMovement: "购买1次额外移动",
			extraStep: "随 Kamoko 再移动1格",
			retireTroops: "退回 {{n}} 名士兵，获得 {{n}} {{resource}}",
			killAt: "击杀 {{player}} 的1名士兵",
			moveBuilding: "将建筑移到这里",
			moveHero: "将英雄移到这里",
			claimGoal: "完成氏族目标",
			bringMoto: "让 Moto Chagatai 前来参战",
			protectHero: "支付影响力，保留英雄能力",
			disableHeroes: "放弃本战英雄能力",
			sacrificeYokuni: "永久移除 Yokuni，立即赢得此战",
			empowerHero: "支付资源，永久增加1军力",
			returnVillage: "放回村庄标记，本战增加1军力",
			rerollDice: "重掷第 {{dice}} 枚骰子",
			keepDice: "结束重掷，选择保留骰",
			keepTheseDice: "保留第 {{dice}} 枚骰子",
			changeDie: "将第 {{die}} 枚骰子改为此面",
			doubleDie: "将第 {{die}} 枚骰子符号翻倍",
			rebirthAt: "将损失的士兵转移到这里",
			claimAttack: "获得进攻胜利成就",
			stealVillage: "偷取{{resource}}村庄标记",
			retreatTo: "撤退到这里",
			payYoritomo: "支付1枚钱币，保留 Yoritomo",
			discardYoritomo: "弃置 Yoritomo",
			prompt_clan: "选择氏族",
			prompt_fort: "选择堡垒位置",
			prompt_draft: "选择一张指令",
			prompt_exhausted: "指令已耗尽，选择一列激活",
			activateExhausted: "不拿新牌，激活{{column}}列",
			prompt_nobleDraft: "为贵族行动再选一张指令",
			prompt_place: "放置指令或使用贵族行动",
			prompt_anyColumn: "选择要激活的列",
			prompt_activateCard: "执行或跳过指令",
			prompt_expandGain: "选择扩张收益",
			prompt_recruit: "选择招募地点",
			prompt_dragonSpeed: "招募后移动这支军队",
			prompt_build: "建造氏族建筑或营地",
			prompt_buyTactic: "购买战术",
			prompt_hero: "选择英雄与加入地点",
			prompt_mercenary: "选择佣兵与加入地点",
			prompt_special: "选择特殊指令与列",
			prompt_move: "选择要移动的军队",
			prompt_moveArmy: "选择要移动的军队",
			prompt_destination: "选择移动目的地",
			prompt_extraMove: "购买移动或结束移动",
			prompt_kamoko: "使用 Kamoko 的额外移动",
			prompt_plow: "将士兵转为资源",
			prompt_kill: "选择击杀目标",
			prompt_buildingMove: "移动己方控制的建筑",
			prompt_tempest: "移动英雄并在当地招募士兵",
			prompt_goal: "选择完成的氏族目标",
			prompt_moto: "决定是否让 Moto 前来参战",
			prompt_aramoro: "应对 Aramoro 的封锁",
			prompt_heroAbility: "使用开战英雄能力",
			prompt_militia: "使用民兵战术",
			prompt_reroll: "选择要重掷的骰子",
			prompt_keep: "选择要保留的骰子",
			prompt_strategize: "改变一枚保留骰的面",
			prompt_double: "选择符号翻倍的骰子",
			prompt_rebirth: "转移因杀伤损失的士兵",
			prompt_battleReward: "选择战斗成就",
			prompt_steal: "偷取一个村庄标记",
			prompt_retreat: "选择败军撤退地点",
			prompt_rescueHero: "安置失去军队的英雄",
			prompt_tsuko: "让 Tsuko 返回堡或建筑",
			prompt_yoritomo: "支付 Yoritomo 的维持费用",
			achievement_attack1: "第一次进攻胜利",
			achievement_attack2: "第二次进攻胜利",
			achievement_buildings: "建造两栋建筑",
			achievement_tactics: "购买三张战术",
			achievement_nobles: "用完三个贵族行动",
			achievement_villages: "持有三个村庄标记",
			achievement_shrines: "同时控制两座神社",
			achievement_city: "首次占领都城",
			achievement_holdCity: "持续控制都城",
			order26: "狮之牙",
			orderText26: "每在战斗中击杀1名士兵，招募1名士兵。",
			order27: "富蛙之城",
			orderText27: "获得1点影响力、1枚钱币和1份木材。",
			order28: "外交",
			orderText28: "收集其他资源后，本次激活每获得1点影响力，额外获得1枚钱币，然后弃置本牌。",
			order29: "御座所",
			orderText29: "获得2份木材。可将一支军队移动到任意瞭望塔。",
			order30: "动员",
			orderText30: "在有己方军队或己方控制的建筑的格子招募2名士兵。",
			order31: "疾驰",
			orderText31: "获得1枚钱币并移动1次。",
			order32: "暗杀",
			orderText32: "击杀位于村庄、神社或都城的1名士兵。",
			order33: "征召",
			orderText33: "收集其他资源后，本次激活每获得1点影响力，招募1名士兵，然后弃置本牌。",
			order34: "龙之力",
			orderText34: "战斗军力、杀伤、护甲各增加1。",
			order35: "龙之速",
			orderText35: "在一支己方军队所在格招募1名士兵，再获得1次仅用于这支军队的移动。",
			order36: "风之暴",
			orderText36: "将一位已招募英雄移到有己方军队的格子，并在那里招募2名士兵。",
			order37: "制高点",
			orderText37: "获得2份木材。击杀邻接任意己方控制的建筑的1名士兵。",
			order38: "铁壳",
			orderText38: "防守时军力增加2。",
			order39: "建筑大师",
			orderText39: "获得1份木材和1枚钱币。可将一栋己方控制的建筑移到己方控制的且没有神社、建筑、堡垒或都城的格子。",
			tactic0: "侵略",
			tacticText0: "激活军备列后，获得1次移动。",
			tactic1: "决心",
			tacticText1: "每场战斗多保留1枚骰子。",
			tactic2: "强行军",
			tacticText2: "激活征募或影响列后，获得1次移动。",
			tactic3: "革新",
			tacticText3: "将一张特殊指令放到匹配列，不激活。",
			tactic4: "掠夺",
			tacticText4: "每在战斗中击杀1名士兵，获得1枚钱币。",
			tactic5: "机动",
			tacticText5: "可在自己的堡垒或己方控制的建筑的相邻领地招兵，不能有敌军。",
			tactic6: "贵族谈判",
			tacticText6: "支付钱或木材时可用影响力替代。",
			tactic7: "私军",
			tacticText7: "在自己的堡垒、己方控制的建筑或己方军队所在格招募3名士兵。",
			tactic8: "佣兵",
			tacticText8: "招募一位尚可用的佣兵英雄。",
			tactic9: "佣兵",
			tacticText9: "招募一位尚可用的佣兵英雄。",
			tactic10: "佣兵",
			tacticText10: "招募一位尚可用的佣兵英雄。",
			tactic11: "铸剑为犁",
			tacticText11: "移动一支军队后，可退回任意数量的当地士兵，每退回1名获得1枚钱币或1份木材。",
			tactic12: "协力",
			tacticText12: "堡外每格可同时有两位英雄。",
			tactic13: "密集阵形",
			tacticText13: "普通领地的军队上限增加2。",
			tactic14: "英雄之旅",
			tacticText14: "招募一位氏族英雄。",
			tactic15: "经济战",
			tacticText15: "可用2枚钱币代替1份木材或1点影响力。",
			tactic16: "英雄之旅",
			tacticText16: "招募一位氏族英雄。",
			tactic17: "沙漠之力",
			tacticText17: "可用任意资源购买额外移动。",
			tactic18: "英雄之旅",
			tacticText18: "招募一位氏族英雄。",
			tactic19: "谋略",
			tacticText19: "少掷1枚骰子，选留后可将其中1枚改为任意面。",
			tactic20: "英雄之旅",
			tacticText20: "招募一位氏族英雄。",
			tactic21: "民兵",
			tacticText21: "开战前可把村庄标记放回无人的村庄格，每个标记使本战军力增加1。",
			tactic22: "英雄之旅",
			tacticText22: "招募一位氏族英雄。",
			tactic23: "重生",
			tacticText23: "敌方杀伤不会杀死你的士兵；将这些士兵转移到自己的堡垒或己方控制的建筑。",
			tactic24: "英雄之旅",
			tacticText24: "招募一位氏族英雄。",
			tactic25: "攻城战",
			tacticText25: "在神社、瞭望塔或都城战斗时，多掷2枚骰子。",
			tactic26: "英雄之旅",
			tacticText26: "招募一位氏族英雄。",
			heroText0: "多掷2枚骰子，杀伤增加1。",
			heroText1: "杀伤增加1，忽略敌方护甲。",
			heroText2: "军力增加2；战后必须返回自己的堡垒或己方控制的建筑。",
			heroText3: "少掷1枚骰子，选留后将其中1枚骰子的符号翻倍。",
			heroText4: "多掷1枚骰子，杀伤增加1；双方先结算兵损，再计算士兵军力。",
			heroText5: "军力增加1，可额外重掷1次。",
			heroText6: "军力增加1；己方军队战斗开始之前，可将此英雄移去参战，目的地不能已有己方英雄。",
			heroText7: "杀伤增加1；每次随军移动可额外移动1格。",
			heroText8: "进攻开战时击杀1名敌方士兵。",
			heroText9: "军力增加1；先封锁敌方英雄战斗能力，除非对方支付1点影响力。Moto的事前移动和Toturi的容量加成不受影响。",
			heroText10: "开战时击杀1名敌方士兵，在当地招募1名士兵，然后返回自己的堡垒。遵守军队上限。",
			heroText11: "进攻时军力增加2，并忽略敌方全部杀伤。",
			heroText12: "多掷1枚骰子；双方骰子处理完后，敌方每有1杀伤，己方军力增加1。",
			heroText13: "开战时可永久移除此英雄，立即无杀伤赢得此战；都城不可使用，正常结算胜负奖励。",
			heroText14: "军力增加1，护甲增加2。",
			heroText15: "护甲增加1；开战时可支付1点影响力放在此卡上，永久保留，每枚提供1军力。",
			heroText16: "在神社或邻神社战场，军力增加2，杀伤增加1。",
			heroText17: "多保留1枚骰子，杀伤增加1。",
			heroText18: "开战时可支付1枚钱币放在此卡上，永久保留，每枚提供1军力。",
			heroText19: "杀伤增加1；若开战时己方士兵少于敌方士兵，每名己方士兵提供2军力。",
			heroText20: "可额外重掷1次，护甲增加2。",
			heroText21: "军力增加1；开战时己方士兵少于敌方士兵，击杀2名敌方士兵。",
			heroText22: "开战时在当地招募1名士兵；当地军队上限增加2。",
			heroText23: "军力增加3；每个己方回合末支付1枚钱币，否则弃置此英雄。",
			goal0: "狮之骄傲",
			goalText0: "包括堡垒在内，版图上有15名己方士兵。",
			goal1: "天子右手",
			goalText1: "在都城相邻领地赢得战斗。进攻时与进攻胜利成就二选一。",
			goal2: "赤备传人",
			goalText2: "控制两个离自己的堡垒至少4步的领地，每格至少2名士兵。",
			goal3: "金鹤",
			goalText3: "回合末持有至少8枚钱币。",
			goal4: "天子左手",
			goalText4: "在都城相邻领地赢得战斗。进攻时与进攻胜利成就二选一。",
			goal5: "鹤之翼",
			goalText5: "控制一个村庄领地及其相邻的两个领地，每格至少2名士兵。",
			goal6: "生于马背",
			goalText6: "版图上至少9名士兵，任何堡垒或建筑都没有己方士兵。",
			goal7: "扫荡沙风",
			goalText7: "在都城、神社、瞭望塔以外的领地赢得战斗。进攻时与进攻胜利成就二选一。",
			goal8: "新条之迅",
			goalText8: "控制三个与敌堡或敌方建筑相邻或重合的领地，每格至少2名士兵。",
			goal9: "贝司之暗笑",
			goalText9: "开战时己方士兵多于敌方士兵，却输掉战斗。",
			goal10: "蝎之刺",
			goalText10: "控制一个瞭望塔及其相邻的两个领地，每格至少2名士兵。",
			goal11: "阴谋之网",
			goalText11: "控制两个村庄领地，每格至少3名士兵。",
			goal12: "龙之爪",
			goalText12: "控制一个神社及其相邻的两个领地，每格至少2名士兵。",
			goal13: "龙之盘",
			goalText13: "自己的堡垒以外，六个不同领地有己方士兵。",
			goal14: "龙之心",
			goalText14: "军力胜过对方，却因没有士兵存活而不算获胜。",
			goal15: "和平缔造者",
			goalText15: "己方控制的领地连通自己的堡垒和都城。",
			goal16: "大地复苏",
			goalText16: "回合末持有至少7份木材。",
			goal17: "凤凰之翼",
			goalText17: "开战时双方合计不超过6名士兵，且赢得战斗。进攻时与进攻胜利成就二选一。",
			goal18: "蟹之钳",
			goalText18: "开战时己方士兵不超过3名士兵，且赢得战斗。进攻时与进攻胜利成就二选一。",
			goal19: "六乡守卫者",
			goalText19: "控制一个神社及其相邻的两个领地，每格至少2名士兵。",
			goal20: "蟹之壳",
			goalText20: "控制两栋氏族建筑，每格至少3名士兵。",
			building0: "兵营",
			buildingText0: "回合末在当地招募1名士兵。",
			building1: "市场",
			buildingText1: "回合末获得2枚钱币。",
			building2: "马厩",
			buildingText2: "从这里移动军队时，可支付1枚钱币，移动到任意空领地。",
			building3: "茶屋",
			buildingText3: "塔间传送不需支付影响力。",
			building4: "道场",
			buildingText4: "所选指令可放入任意列。",
			building5: "藏书楼",
			buildingText5: "购买战术少支付1枚钱币，购买后获得1点影响力。",
			building6: "要塞",
			buildingText6: "每控制一栋氏族建筑，每场战斗可额外重掷1次。",
			campText: "可在这里招募、撤退，士兵数量不受普通上限限制。",
			nobleText1: "支付1点影响力：再选一张指令并支付其费用，放任意列并激活。",
			nobleText2: "支付2点影响力：招募氏族英雄并激活任意列。",
			nobleText3: "支付3点影响力：放置一张氏族特殊指令并激活其列。",
			log_achievement: "取得成就：{{achievement}}",
			log_victory: "完成七项成就",
			log_gained: "获得 {{n}} {{resource}}",
			log_moved: "{{n}} 名士兵从 {{from}} 移动到 {{to}}",
			log_orderTaken: "选择了一张指令",
			log_columnActivated: "激活{{column}}列",
			log_recruited: "在 {{space}} 招募 {{n}} 名士兵",
			log_built: "在 {{space}} 建造{{building}}",
			log_tacticBought: "购买{{tactic}}",
			log_heroRecruited: "招募 {{hero}}",
			log_troopKilled: "击杀 {{space}} 的1名士兵",
			log_battleResult: "战斗军力：进攻方 {{attacker}}，防守方 {{defender}}",
			log_villageClaimed: "在 {{space}} 获得{{resource}}村庄标记",
			log_retreated: "撤退到 {{space}}"
		},
		en: {
			name: "Gunsen: The Battle for Toshi Ranbo",
			desc: "Draft orders, lead the Great Clans, and claim seven achievements",
			rules: "Goal: be first to claim seven achievements: two attacking wins, two different clan goals, building both buildings, buying three tactics, using all three nobles, controlling two shrines at once, first claiming Toshi Ranbo, holding three village tokens, and maintaining control of Toshi Ranbo. Only the last achievement can be lost.\nSetup: choose clans and eligible forts in randomly determined player order. Each clan has 15 troops, three heroes, two clan tactics, two private neutral tactics, two special orders, and three goals. Use the correct map and order deck for the player count.\nTurn: choose one of five faceup orders and pay its cost. Before choosing, you may clear the row if at least four orders share a color or at least four have a cost. Add the card to its matching column, activate orders from newest to oldest, then perform printed actions. Effects may be skipped. Red combat symbols apply across all columns and are not gained resources.\n· Expand gains one koku or wood, builds, and buys tactics.\n· Recruit recruits one troop and moves once.\n· Influence gains one influence and moves once.\n· Armory provides the base roll three, keep two, and moves once.\n· Extra movement costs koku in Armory, Influence in Recruit, or wood in Influence.\nNobles: cover an unused noble spot with the chosen order and pay for one of these actions:\n· Pay one influence to take another order, pay its cost, place it in any column and activate that column.\n· Pay two influence to recruit a clan hero and activate any column.\n· Pay three influence to add a clan special order and activate its matching column.\nEach noble can be used once per game.\nMovement: move any part of an army one adjacent territory, splitting or combining armies. Normally at most five troops per clan occupy a territory; forts and camps are unlimited. Only your own fort can be entered. Heroes travel with troops, normally at most one per territory outside your fort. Once per movement, either before or after it, spend one influence to transport an army between your fort and a tower, or between different towers. First entry to Toshi Ranbo needs at least five army strength and ends all movement; later entry has no strength threshold. Entering an enemy army triggers battle and ends all movement for the turn, but finish remaining column effects first.\nBuildings and tactics: during Expand, spend three wood for the unique building and two for the camp. Build with or adjacent to your army, or adjacent to your fort, without enemies, tiles, or tokens. Empty buildings belong to their builder; occupying enemies control and use them. Buy at most three tactics. Unbought neutral tactics remain private.\nBattle: resolve start abilities, then the defender rolls, rerolls, and keeps dice, followed by the attacker. Roll at most six dice. Blood minus opposing armor causes troop losses; losses normally do not reduce strength already counted. Ties use the attacker branch. The higher side needs surviving troops to win and earn rewards; otherwise it earns nothing and the other side still retreats. A winner steals a village token and gains its reward. The losing army retreats together to its fort or a controlled building. Attacking victories can earn two achievements; some clan goals must be chosen instead of an attacking achievement.\nEnd of turn: resolve building and hero effects, collect occupied village tokens and their hidden rewards, keeping at most three tokens. Occupied shrines grant matching upgrades; keep an upgrade until an opponent claims it. Claiming Toshi Ranbo grants its upgrade and achievements. Any player with fewer than three troops on the board recruits at their fort until they have three. Refill the order row, then the next player acts.\nUpgrades:\n· Armory lets you roll four dice and keep two.\n· Recruit lets you recruit two troops.\n· Influence gives you two influence.\n· Expand gives you both one koku and one wood.\nFull clan card abilities are available during play.\nDigital supplement: the official rules do not cover a situation where no circulating order is affordable. Only when the active player cannot afford any order in the row, deck, or discard pile (clearing repeatedly cannot provide an order), skip taking a new card and activate any one column. No noble action is available this time; all other turn steps apply normally.",
			koku: "Koku",
			wood: "Wood",
			influence: "Influence",
			troop: "Troop",
			move: "Movement",
			strength: "Strength",
			blood: "Blood",
			armor: "Armor",
			roll: "Roll",
			keep: "Keep",
			reroll: "Reroll",
			expand: "Expand",
			armory: "Armory",
			recruit: "Recruit",
			plain: "Territory",
			village: "Village",
			shrine: "Shrine",
			tower: "Watchtower",
			city: "Toshi Ranbo",
			fort: "Fort",
			unique: "Unique building",
			camp: "Camp",
			close: "Close",
			inspect: "Inspect",
			confirm: "Confirm action",
			cancel: "Cancel",
			skip: "Skip this effect",
			resolving: "Resolving",
			waiting: "Waiting for {{name}}",
			turn: "Turn {{n}}",
			orders: "Order row",
			clanBoard: "Clan board",
			cards: "Clan cards",
			goals: "Clan goals",
			tactics: "Tactics",
			heroes: "Heroes",
			buildings: "Buildings",
			specials: "Special orders",
			history: "Chronicle",
			map: "Battlefield",
			overview: "Fit map",
			achievements: "Achievements",
			reserve: "Reserve {{n}}",
			unclaimed: "Unclaimed",
			cost: "Pay {{cost}}",
			free: "Free",
			detail: "{{name}}: {{text}}",
			victory: "{{name}} wins",
			again: "Play again",
			lobby: "Back to lobby",
			review: "Review battlefield",
			showResults: "Show achievements",
			privateTactics: "Your unbought tactics",
			chooseTarget: "Choose an action target",
			army: "{{n}} troops",
			heroCount: "With heroes: {{heroes}}",
			none: "None",
			used: "Used",
			battle: "Battle",
			attacker: "Attacker",
			defender: "Defender",
			dice: "Battle dice",
			tokens: "Village tokens",
			upgrades: "Upgrades",
			nobles: "Noble actions",
			score: "{{n}} / 7 achievements",
			errAction: "That action is not available",
			errDone: "This game has ended",
			battleWon: "{{name}} wins the battle",
			noBattleWinner: "No winner in this battle",
			confirmLeave: "Leave this game’s results?",
			prompt_gain: "Gain resources or skip this effect",
			clan0: "Lion Clan",
			clan1: "Crane Clan",
			clan2: "Unicorn Clan",
			clan3: "Scorpion Clan",
			clan4: "Dragon Clan",
			clan5: "Phoenix Clan",
			clan6: "Crab Clan",
			chooseClan: "Choose {{clan}}",
			chooseFort: "Place your fort here",
			takeOrder: "Take this order",
			clearRow: "Clear and refill the row",
			activateColumn: "Activate {{column}}",
			useNoble: "Use noble action {{n}}",
			useOrder: "Use this order",
			gainBoth: "Gain one koku and one wood",
			gainResource: "Gain {{n}} {{resource}}",
			recruitAt: "Recruit one troop here",
			chooseDragonArmy: "Choose the army to recruit with and move",
			buildAt: "Build {{building}} here",
			buyTactic: "Buy {{tactic}}",
			recruitHero: "Recruit this hero",
			addSpecial: "Add to {{column}}",
			selectArmy: "Move {{n}} troops",
			moveTo: "Move here",
			buyMovement: "Buy one extra movement",
			extraStep: "Move one extra territory with Kamoko",
			retireTroops: "Retire {{n}} troops for {{n}} {{resource}}",
			killAt: "Kill one troop of {{player}}",
			moveBuilding: "Move the building here",
			moveHero: "Move this hero here",
			claimGoal: "Claim this clan goal",
			bringMoto: "Bring Moto Chagatai into battle",
			protectHero: "Pay influence to retain hero abilities",
			disableHeroes: "Forgo hero abilities for this battle",
			sacrificeYokuni: "Remove Yokuni permanently to win this battle",
			empowerHero: "Pay to add one permanent strength",
			returnVillage: "Return a village token for one strength this battle",
			rerollDice: "Reroll dice {{dice}}",
			keepDice: "Finish rerolling",
			keepTheseDice: "Keep dice {{dice}}",
			changeDie: "Change die {{die}} to this face",
			doubleDie: "Double the symbols on die {{die}}",
			rebirthAt: "Relocate a lost troop here",
			claimAttack: "Claim an attacking victory achievement",
			stealVillage: "Steal the {{resource}} village token",
			retreatTo: "Retreat here",
			payYoritomo: "Pay one koku to keep Yoritomo",
			discardYoritomo: "Discard Yoritomo",
			prompt_clan: "Choose your clan",
			prompt_fort: "Choose a fort location",
			prompt_draft: "Choose an order",
			prompt_exhausted: "Orders exhausted: choose a column",
			activateExhausted: "Take no new card; activate {{column}}",
			prompt_nobleDraft: "Choose another order for your noble",
			prompt_place: "Place your order or use a noble",
			prompt_anyColumn: "Choose a column to activate",
			prompt_activateCard: "Use or skip the order",
			prompt_expandGain: "Choose the Expand resource",
			prompt_recruit: "Choose where to recruit",
			prompt_dragonSpeed: "Recruit, then move that army",
			prompt_build: "Build a unique building or camp",
			prompt_buyTactic: "Buy tactics",
			prompt_hero: "Choose a hero and destination",
			prompt_mercenary: "Choose a mercenary and destination",
			prompt_special: "Choose a special order and column",
			prompt_move: "Choose an army to move",
			prompt_moveArmy: "Choose an army to move",
			prompt_destination: "Choose a destination",
			prompt_extraMove: "Buy movement or finish moving",
			prompt_kamoko: "Use Kamoko’s extra movement",
			prompt_plow: "Retire troops for resources",
			prompt_kill: "Choose a troop to kill",
			prompt_buildingMove: "Move a controlled building",
			prompt_tempest: "Move a hero and recruit there",
			prompt_goal: "Claim a clan goal",
			prompt_moto: "Decide whether Moto joins the battle",
			prompt_aramoro: "Respond to Aramoro",
			prompt_heroAbility: "Use a start-of-battle ability",
			prompt_militia: "Use Militia",
			prompt_reroll: "Choose dice to reroll",
			prompt_keep: "Choose dice to keep",
			prompt_strategize: "Change one kept die",
			prompt_double: "Choose a die to double",
			prompt_rebirth: "Relocate troops lost to blood",
			prompt_battleReward: "Choose the battle achievement",
			prompt_steal: "Steal a village token",
			prompt_retreat: "Choose where the losing army retreats",
			prompt_rescueHero: "Relocate a stranded hero",
			prompt_tsuko: "Return Tsuko to a fort or building",
			prompt_yoritomo: "Pay Yoritomo’s upkeep",
			achievement_attack1: "First attacking victory",
			achievement_attack2: "Second attacking victory",
			achievement_buildings: "Build two buildings",
			achievement_tactics: "Buy three tactics",
			achievement_nobles: "Use all three nobles",
			achievement_villages: "Hold three village tokens",
			achievement_shrines: "Control two shrines",
			achievement_city: "First claim of Toshi Ranbo",
			achievement_holdCity: "Maintain control of Toshi Ranbo",
			order26: "Lion’s Fang",
			orderText26: "Recruit one troop for each troop you kill in battle.",
			order27: "City of the Rich Frog",
			orderText27: "Gain one influence, one koku, and one wood.",
			order28: "Diplomacy",
			orderText28: "After collecting other resources, gain one koku per influence gained during this activation, then discard this order.",
			order29: "Otosan Uchi",
			orderText29: "Gain two wood. Move an army to any watchtower.",
			order30: "Mobilize",
			orderText30: "Recruit two troops in a territory with your troops or a controlled building.",
			order31: "Gallop",
			orderText31: "Gain one koku and one movement.",
			order32: "Assassination",
			orderText32: "Kill one troop in a village, shrine, or Toshi Ranbo territory.",
			order33: "Conscription",
			orderText33: "After collecting other resources, recruit one troop per influence gained during this activation, then discard this order.",
			order34: "Dragon’s Strength",
			orderText34: "Gain one strength, one blood, and one armor in battle.",
			order35: "Dragon’s Speed",
			orderText35: "Recruit one troop with an army, then gain one movement for that army.",
			order36: "Tempest of Air",
			orderText36: "Move a recruited hero to a territory with your army and recruit two troops there.",
			order37: "High Ground",
			orderText37: "Gain two wood. Kill one troop adjacent to any building you control.",
			order38: "Iron Shell",
			orderText38: "Gain two strength when defending.",
			order39: "Master Builders",
			orderText39: "Gain one wood and one koku. Move a controlled building to a controlled territory without a shrine, building, fort, or Toshi Ranbo.",
			tactic0: "Aggression",
			tacticText0: "After activating Armory, gain one movement.",
			tactic1: "Determination",
			tacticText1: "Keep one extra die in battle.",
			tactic2: "Forced March",
			tacticText2: "After activating Recruit or Influence, gain one movement.",
			tactic3: "Innovation",
			tacticText3: "Add a clan special order to its matching column without activating.",
			tactic4: "Looting",
			tacticText4: "Gain one koku per troop you kill in battle.",
			tactic5: "Mobility",
			tacticText5: "Recruit adjacent to your fort or a controlled building, without enemy troops.",
			tactic6: "Noble Negotiations",
			tacticText6: "Influence can replace koku or wood when paying.",
			tactic7: "Private Army",
			tacticText7: "Recruit three troops at your fort, a controlled building, or your army.",
			tactic8: "Mercenary",
			tacticText8: "Recruit an available mercenary hero.",
			tactic9: "Mercenary",
			tacticText9: "Recruit an available mercenary hero.",
			tactic10: "Mercenary",
			tacticText10: "Recruit an available mercenary hero.",
			tactic11: "Swords to Plowshares",
			tacticText11: "After moving an army, retire any number of its troops for one koku or wood each.",
			tactic12: "Teamwork",
			tacticText12: "You may have two heroes per territory outside your fort.",
			tactic13: "Close Formation",
			tacticText13: "Increase normal army capacity by two.",
			tactic14: "Hero’s Journey",
			tacticText14: "Recruit a clan hero.",
			tactic15: "Economic Warfare",
			tacticText15: "Two koku can replace one wood or influence.",
			tactic16: "Hero’s Journey",
			tacticText16: "Recruit a clan hero.",
			tactic17: "Desert Power",
			tacticText17: "Buy extra movement with any resource.",
			tactic18: "Hero’s Journey",
			tacticText18: "Recruit a clan hero.",
			tactic19: "Strategize",
			tacticText19: "Roll one fewer die; after keeping, change one kept die to any face.",
			tactic20: "Hero’s Journey",
			tacticText20: "Recruit a clan hero.",
			tactic21: "Militia",
			tacticText21: "Before battle, return village tokens to unoccupied village territories for one strength each in this battle.",
			tactic22: "Hero’s Journey",
			tacticText22: "Recruit a clan hero.",
			tactic23: "Rebirth",
			tacticText23: "Blood does not kill your troops; send them to your fort or a building you control instead.",
			tactic24: "Hero’s Journey",
			tacticText24: "Recruit a clan hero.",
			tactic25: "Siege Warfare",
			tacticText25: "Roll two extra dice in shrines, watchtowers, or Toshi Ranbo.",
			tactic26: "Hero’s Journey",
			tacticText26: "Recruit a clan hero.",
			heroText0: "Roll two extra dice and gain one blood.",
			heroText1: "Gain one blood and ignore opposing armor.",
			heroText2: "Gain two strength. After battle, return to your fort or a controlled building.",
			heroText3: "Roll one fewer die; double the symbols on one kept die.",
			heroText4: "Roll one extra die and gain one blood. Both sides suffer blood losses before counting troop strength.",
			heroText5: "Gain one strength and one reroll.",
			heroText6: "Gain one strength. Before any battle with your troops, move this hero there if you have no hero there.",
			heroText7: "Gain one blood. Move one extra territory each time this army moves.",
			heroText8: "When attacking, kill one enemy troop at battle start.",
			heroText9: "Gain one strength. Negate enemy hero combat abilities unless their owner pays one influence. Moto’s pre-battle movement and Toturi’s capacity bonus are unaffected.",
			heroText10: "At battle start, kill one enemy troop, recruit one troop here within capacity, then return this hero to your fort.",
			heroText11: "When attacking, gain two strength and ignore all opposing blood.",
			heroText12: "Roll one extra die. After all dice, gain one strength for each opposing blood.",
			heroText13: "At battle start, permanently remove this hero to win instantly with no kills. Cannot be used at Toshi Ranbo. Resolve normal victory rewards.",
			heroText14: "Gain one strength and two armor.",
			heroText15: "Gain one armor. At battle start, pay one influence onto this card permanently; each adds one strength.",
			heroText16: "Gain two strength and one blood in or adjacent to a shrine.",
			heroText17: "Keep one extra die and gain one blood.",
			heroText18: "At battle start, pay one koku onto this card permanently; each adds one strength.",
			heroText19: "Gain one blood. If outnumbered at battle start, each troop counts as two strength.",
			heroText20: "Gain one reroll and two armor.",
			heroText21: "Gain one strength. If outnumbered at battle start, kill two enemy troops.",
			heroText22: "Recruit one troop here at battle start. Local army capacity increases by two.",
			heroText23: "Gain three strength. At the end of each of your turns, pay one koku or discard this hero.",
			goal0: "Lion’s Pride",
			goalText0: "Have all fifteen troops on the board, including your fort.",
			goal1: "Right Hand of the Emperor",
			goalText1: "Win in a territory adjacent to Toshi Ranbo; when attacking, choose this goal or an attacking achievement.",
			goal2: "Scions of Akodo",
			goalText2: "Control two territories at least four steps from your fort, each with at least two troops.",
			goal3: "Golden Crane",
			goalText3: "End your turn with at least eight koku.",
			goal4: "Left Hand of the Emperor",
			goalText4: "Win adjacent to Toshi Ranbo; when attacking, choose this goal or an attacking achievement.",
			goal5: "Wings of the Crane",
			goalText5: "Control a village territory and two adjacent territories, with at least two troops each.",
			goal6: "Born in the Saddle",
			goalText6: "Have at least nine troops on the board, with none at any fort or building.",
			goal7: "Scouring Desert Wind",
			goalText7: "Win outside Toshi Ranbo, shrines, and towers; when attacking, choose this goal or an attacking achievement.",
			goal8: "Shinjo’s Swiftness",
			goalText8: "Control three territories in or adjacent to enemy forts or buildings, with at least two troops each.",
			goal9: "Bayushi’s Hidden Smile",
			goalText9: "Lose a battle after starting with more troops than your opponent.",
			goal10: "Sting of the Scorpion",
			goalText10: "Control a watchtower and two adjacent territories, with at least two troops each.",
			goal11: "Web of Intrigues",
			goalText11: "Control two village territories with at least three troops each.",
			goal12: "Claws of the Dragon",
			goalText12: "Control a shrine and two adjacent territories, with at least two troops each.",
			goal13: "Coils of the Dragon",
			goalText13: "Have troops in six different territories outside your fort.",
			goal14: "Heart of the Dragon",
			goalText14: "Have higher strength but no surviving troops, so the battle does not count as won.",
			goal15: "Forgers of the Peace",
			goalText15: "Connect your fort to Toshi Ranbo through controlled territories.",
			goal16: "Restoration of Earth",
			goalText16: "End your turn with at least seven wood.",
			goal17: "Wings of the Phoenix",
			goalText17: "Win a battle that began with at most six troops in total; when attacking, choose this goal or an attacking achievement.",
			goal18: "Claw of the Crab",
			goalText18: "Win a battle that began with at most three of your troops; when attacking, choose this goal or an attacking achievement.",
			goal19: "Defenders of Rokugan",
			goalText19: "Control a shrine and two adjacent territories, with at least two troops each.",
			goal20: "Shell of the Crab",
			goalText20: "Control two clan buildings with at least three troops each.",
			building0: "Barracks",
			buildingText0: "Recruit one troop here at the end of your turn.",
			building1: "Marketplace",
			buildingText1: "Gain two koku at the end of your turn.",
			building2: "Stable",
			buildingText2: "When moving from here, pay one koku to move to any empty territory.",
			building3: "Tea House",
			buildingText3: "Watchtower transport costs no influence.",
			building4: "Dojo",
			buildingText4: "Place chosen orders in any column.",
			building5: "Library",
			buildingText5: "Tactics cost one less koku; gain one influence when buying one.",
			building6: "Fortifications",
			buildingText6: "Gain one reroll in battle per clan building you control.",
			campText: "Recruit and retreat here without the normal troop limit.",
			nobleText1: "Pay one influence: take another order, pay its cost, place it in any column and activate.",
			nobleText2: "Pay two influence: recruit a clan hero and activate any column.",
			nobleText3: "Pay three influence: add a clan special order and activate its column.",
			log_achievement: "Claimed: {{achievement}}",
			log_victory: "Claimed seven achievements",
			log_gained: "Gained {{n}} {{resource}}",
			log_moved: "Moved {{n}} troops from {{from}} to {{to}}",
			log_orderTaken: "Took an order",
			log_columnActivated: "Activated {{column}}",
			log_recruited: "Recruited {{n}} troops at {{space}}",
			log_built: "Built {{building}} at {{space}}",
			log_tacticBought: "Bought {{tactic}}",
			log_heroRecruited: "Recruited {{hero}}",
			log_troopKilled: "Killed one troop at {{space}}",
			log_battleResult: "Battle strength: attacker {{attacker}}, defender {{defender}}",
			log_villageClaimed: "Claimed a {{resource}} village token at {{space}}",
			log_retreated: "Retreated to {{space}}"
		}
	}
};
//#endregion
export { zt as default };
