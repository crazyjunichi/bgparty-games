import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { Fragment as n, useEffect as r, useMemo as i, useRef as a, useState as o, useSyncExternalStore as s } from "react";
import { useI18nSettings as c, useT as l } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as u } from "@bgparty/sdk/player-colors";
import { GameScreen as d } from "@bgparty/sdk/ui/game-screen";
import { seatName as f } from "@bgparty/sdk/ui/player-strip";
import { Fragment as p, jsx as m, jsxs as h } from "react/jsx-runtime";
import { IconBack as g, IconBot as _, IconExpand as v, IconLog as y } from "@bgparty/sdk/icons";
import { Confetti as b } from "@bgparty/sdk/ui/confetti";
import { OptionSection as x, OptionSwitch as S } from "@bgparty/sdk/ui/game-options";
//#region src/games/kanban/data.ts
var C = [
	2,
	3,
	4,
	5,
	6
], w = [
	3,
	3,
	3,
	4,
	4
], T = {
	11: [{ to: 21 }],
	21: [{ to: 22 }],
	12: [{ to: 22 }],
	13: [{ to: 23 }],
	23: [{ to: 32 }],
	14: [{ to: 24 }],
	25: [{ to: 24 }],
	15: [{ to: 25 }],
	22: [{ to: 23 }, { to: 31 }],
	24: [{ to: 23 }, { to: 33 }],
	31: [{ exit: 1 }, { to: 32 }],
	33: [{ exit: 1 }, { to: 32 }],
	32: [{ exit: 2 }]
}, E = [
	4,
	1,
	0,
	2,
	3
], D = {
	4: 11,
	1: 12,
	0: 13,
	2: 14,
	3: 15
}, ee = (e) => e <= 3 ? 9 : 10, O = (e) => e <= 3 ? [1] : [1, 6], k = [
	1,
	2,
	2,
	3
], A = { kind: "none" }, j = (e) => ({
	kind: "pp",
	n: e
}), M = {
	kind: "book",
	n: 1
}, N = [
	[
		A,
		A,
		A,
		j(4),
		j(3),
		M
	],
	[
		A,
		A,
		A,
		j(3),
		j(2),
		M
	],
	[
		A,
		A,
		A,
		j(2),
		A,
		M
	],
	[
		A,
		A,
		A,
		j(1),
		A,
		M
	],
	[
		A,
		A,
		A,
		A,
		A,
		M
	]
], P = [
	[
		{ bank: 1 },
		{ book: 1 },
		{ voucher: 1 },
		{}
	],
	[
		{ pp: 3 },
		{ bank: 1 },
		{ book: 1 },
		{ voucher: 1 }
	],
	[
		{
			pp: 2,
			speech: !0
		},
		{
			bank: 1,
			speech: !0
		},
		{
			pp: 1,
			speech: !0
		},
		{ speech: !0 }
	],
	[
		{ pp: 4 },
		{ bank: 2 },
		{ book: 2 },
		{ voucher: 2 }
	],
	[
		{
			pp: 2,
			speech: !0
		},
		{
			bank: 1,
			speech: !0
		},
		{
			pp: 1,
			speech: !0
		},
		{ speech: !0 }
	],
	[
		{ pp: 5 },
		{ pp: 3 },
		{ pp: 1 }
	]
], F = [
	[
		0,
		0,
		3,
		5,
		1,
		2
	],
	[
		4,
		4,
		3,
		5,
		1,
		2
	],
	[
		0,
		0,
		3,
		5,
		4,
		2
	],
	[
		2,
		2,
		3,
		5,
		4,
		1
	],
	[
		4,
		4,
		3,
		5,
		0,
		1
	],
	[
		2,
		2,
		3,
		5,
		1,
		0
	],
	[
		2,
		2,
		3,
		5,
		4,
		0
	],
	[
		1,
		1,
		3,
		5,
		2,
		4
	],
	[
		1,
		1,
		3,
		5,
		2,
		0
	],
	[
		0,
		0,
		3,
		5,
		1,
		4
	],
	[
		1,
		1,
		3,
		5,
		4,
		0
	],
	[
		4,
		4,
		3,
		5,
		0,
		2
	]
], te = [
	3,
	3,
	2,
	1,
	1
], ne = [
	{ kind: "speech" },
	{
		kind: "bank",
		n: 2
	},
	{
		kind: "book",
		n: 2
	},
	{
		kind: "parts",
		n: 2
	},
	{ kind: "lock" }
], I = [
	{ kind: "none" },
	{
		kind: "parts",
		n: 1
	},
	{
		kind: "book",
		n: 1
	},
	{
		kind: "bank",
		n: 1
	},
	{ kind: "speech" }
], re = [
	"upgrade",
	"train2",
	"shift5",
	"immunity",
	"design",
	"doubleScore",
	"speech"
], L = [
	{
		pp: 2,
		max: 3,
		kind: { t: "cars" }
	},
	{
		pp: 3,
		max: 3,
		kind: { t: "models" }
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "modelCars",
			m: 2
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "modelCars",
			m: 0
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "modelCars",
			m: 4
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "modelCars",
			m: 3
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "modelCars",
			m: 1
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 1
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 4
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 2
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 5
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 3
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "partUpgrades",
			p: 0
		}
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "upgrades" }
	},
	{
		pp: 4,
		max: 2,
		kind: { t: "tested" }
	},
	{
		pp: 2,
		max: 3,
		kind: {
			t: "parts2",
			ps: [1, 4]
		}
	},
	{
		pp: 2,
		max: 3,
		kind: {
			t: "parts2",
			ps: [2, 5]
		}
	},
	{
		pp: 2,
		max: 3,
		kind: {
			t: "parts2",
			ps: [0, 3]
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "garagePair",
			g: [0, 1]
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "garagePair",
			g: [1, 2]
		}
	},
	{
		pp: 4,
		max: 2,
		kind: {
			t: "garagePair",
			g: [3, 4]
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "cert",
			d: 0
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "cert",
			d: 1
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "cert",
			d: 2
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "cert",
			d: 3
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "cert",
			d: 4
		}
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "designs" }
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "books" }
	},
	{
		pp: 3,
		max: 3,
		kind: { t: "certs" }
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "vouchers" }
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "banked" }
	},
	{
		pp: 3,
		max: 3,
		kind: { t: "speech" }
	},
	{
		pp: 2,
		max: 3,
		kind: { t: "chargers" }
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "chargerRow",
			row: 0
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "chargerRow",
			row: 1
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "chargerRow",
			row: 2
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "chargerRow",
			row: 3
		}
	},
	{
		pp: 4,
		max: 1,
		kind: {
			t: "chargerRow",
			row: 4
		}
	}
], ie = [
	[
		{
			pp: 7,
			all: [{
				t: "sameModelCars",
				n: 3
			}]
		},
		{
			pp: 6,
			all: [{
				t: "distinctPartUpgrades",
				n: 3
			}]
		},
		{
			pp: 8,
			all: [{
				t: "certs",
				n: 5
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "cars",
				n: 5
			}]
		},
		{
			pp: 6,
			all: [{
				t: "upgrades",
				n: 4
			}]
		},
		{
			pp: 7,
			all: [{
				t: "certs",
				n: 4
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "distinctModels",
				n: 4
			}]
		},
		{
			pp: 7,
			all: [{
				t: "samePartUpgrades",
				n: 3
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [2, 1]
			}]
		}
	],
	[
		{
			pp: 7,
			all: [{
				t: "modelCars",
				m: 3,
				n: 2
			}]
		},
		{
			pp: 8,
			all: [{
				t: "upgrades",
				n: 5
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [4, 4]
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "modelCars",
				m: 4,
				n: 2
			}]
		},
		{
			pp: 7,
			all: [{
				t: "partUpgrades",
				p: 2,
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [0, 3]
			}]
		}
	],
	[
		{
			pp: 6,
			all: [{
				t: "banked",
				n: 7
			}]
		},
		{
			pp: 8,
			all: [{
				t: "books",
				n: 3
			}]
		},
		{
			pp: 7,
			all: [{
				t: "experts",
				n: 2
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "modelCars",
				m: 0,
				n: 2
			}]
		},
		{
			pp: 7,
			all: [{
				t: "partUpgrades",
				p: 1,
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [0, 1]
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "modelCars",
				m: 1,
				n: 2
			}]
		},
		{
			pp: 7,
			all: [{
				t: "partUpgrades",
				p: 3,
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [2, 3]
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "modelCars",
				m: 2,
				n: 2
			}]
		},
		{
			pp: 7,
			all: [{
				t: "partUpgrades",
				p: 4,
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [1, 3]
			}]
		}
	],
	[
		{
			pp: 7,
			all: [{
				t: "sameModelCars",
				n: 3
			}]
		},
		{
			pp: 7,
			all: [{
				t: "tested",
				n: 5
			}]
		},
		{
			pp: 7,
			all: [{
				t: "certsMax",
				n: 3
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "distinctModels",
				n: 5
			}]
		},
		{
			pp: 8,
			all: [{
				t: "testedParts",
				n: 5
			}]
		},
		{
			pp: 8,
			all: [{
				t: "expertsMax",
				n: 1
			}]
		}
	],
	[
		{
			pp: 6,
			all: [{
				t: "banked",
				n: 7
			}]
		},
		{
			pp: 8,
			all: [{
				t: "chargers",
				n: 4
			}]
		},
		{
			pp: 7,
			all: [{
				t: "experts",
				n: 2
			}]
		}
	],
	[
		{
			pp: 8,
			all: [{
				t: "distinctModels",
				n: 4
			}]
		},
		{
			pp: 7,
			all: [{
				t: "samePartUpgrades",
				n: 3
			}]
		},
		{
			pp: 6,
			all: [{
				t: "certPair",
				ds: [2, 2]
			}, {
				t: "chargerRow",
				row: 0
			}]
		}
	],
	[
		{
			pp: 7,
			all: [{
				t: "vouchers",
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "chargerRow",
				row: 1
			}, {
				t: "chargerRow",
				row: 3
			}]
		},
		{
			pp: 8,
			all: [{
				t: "certs",
				n: 5
			}]
		}
	],
	[
		{
			pp: 7,
			all: [{
				t: "books",
				n: 2
			}]
		},
		{
			pp: 6,
			all: [{
				t: "chargerRow",
				row: 2
			}, {
				t: "chargerRow",
				row: 4
			}]
		},
		{
			pp: 8,
			all: [{
				t: "speechBoard",
				n: 2
			}]
		}
	]
], R = (e) => Math.floor(e / 7), z = (e) => {
	let t = e % 7;
	return t === 0 ? null : t - 1;
}, B = [
	2,
	3,
	4,
	5
], V = {
	id: "kanban",
	tier: "beta",
	mechanics: ["worker-placement", "engine-building"],
	interactionTags: [],
	nameKey: "games.kanban.name",
	descKey: "games.kanban.desc",
	rulesKey: "games.kanban.rules",
	icon: "🏭",
	iconImg: "games/kanban.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/kanban/en.pdf" },
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3],
	accent: "#0d9488",
	releasedAt: "2026-10-07",
	search: {
		py: "kan ban dian dong qi che",
		init: "kbddqc"
	},
	hotseat: "cover"
}, H = t.int().min(0).max(3), U = t.int().min(0).max(4), W = t.int().min(0).max(5), G = t.int().min(0).max(4), ae = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("inductCert"),
		space: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("inductTake"),
		part: W,
		design: t.discriminatedUnion("kind", [t.object({
			kind: t.literal("display"),
			row: t.int().min(0).max(1),
			col: t.int().min(0).max(3)
		}), t.object({
			kind: t.literal("stack"),
			stack: t.enum([
				"firstTop",
				"firstBottom",
				"central"
			])
		})])
	}),
	t.object({
		type: t.literal("pickSpecialGarage"),
		tile: t.int().min(0).max(6)
	}),
	t.object({
		type: t.literal("selectDept"),
		dept: G,
		station: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("useBanked"),
		n: t.int().min(1).max(3)
	}),
	t.object({
		type: t.literal("train"),
		dept: G
	}),
	t.object({
		type: t.literal("homework"),
		dept: G,
		n: t.int().min(1).max(5)
	}),
	t.object({
		type: t.literal("takeDesign"),
		row: t.int().min(0).max(1),
		col: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("takeAdvancedDesign"),
		stack: t.enum([
			"firstTop",
			"firstBottom",
			"central"
		])
	}),
	t.object({
		type: t.literal("kanbanOrder"),
		cardId: t.int().nonnegative(),
		side: t.int().min(0).max(1)
	}),
	t.object({
		type: t.literal("collectParts"),
		part: W,
		count: t.int().min(1).max(4)
	}),
	t.object({ type: t.literal("takeVoucher") }),
	t.object({
		type: t.literal("providePart"),
		model: U,
		source: t.enum(["part", "voucher"]),
		part: W
	}),
	t.object({
		type: t.literal("carMove"),
		to: t.int().nullable(),
		exit: t.union([t.literal(1), t.literal(2)]).nullable()
	}),
	t.object({
		type: t.literal("claimCar"),
		trackIdx: t.int().min(0).max(3),
		designId: t.int().nonnegative(),
		garage: t.int().min(0).max(4),
		tile: t.int().min(0).max(3).optional(),
		lockChoice: t.tuple([t.int().min(0).max(3), t.int().min(0).max(3)]).optional(),
		gainParts: t.array(W).max(2).optional()
	}),
	t.object({
		type: t.literal("upgradeDesign"),
		designId: t.int().nonnegative(),
		source: t.enum([
			"part",
			"voucher",
			"supply"
		]),
		space: t.int().min(0).max(5),
		double: t.boolean()
	}),
	t.object({
		type: t.literal("recycle"),
		give: W,
		take: W
	}),
	t.object({
		type: t.literal("charge"),
		row: t.int().min(0).max(4)
	}),
	t.object({
		type: t.literal("adminTarget"),
		dept: G
	}),
	t.object({ type: t.literal("sgActivate") }),
	t.object({
		type: t.literal("flipGarageTile"),
		garage: t.int().min(0).max(3),
		lockChoice: t.tuple([t.int().min(0).max(3), t.int().min(0).max(3)]).optional(),
		gainParts: t.array(W).max(2).optional()
	}),
	t.object({ type: t.literal("endWork") }),
	t.object({
		type: t.literal("chooseCertSpace"),
		space: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("chooseAward"),
		award: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("meetPlay"),
		cardId: t.int().nonnegative(),
		speak: t.boolean()
	}),
	t.object({
		type: t.literal("meetSpeak"),
		goalIdx: t.int().nonnegative(),
		source: t.enum(["board", "tile"])
	}),
	t.object({ type: t.literal("meetPass") }),
	t.object({
		type: t.literal("meetContribute"),
		cardId: t.int().nonnegative()
	}),
	t.object({
		type: t.literal("claimFinal"),
		achievements: t.array(t.int().min(0).max(2)).max(3)
	})
]), oe = t.object({
	niceSandra: t.boolean().prefault(!1),
	planner: t.boolean().prefault(!1),
	expertTuning: t.boolean().prefault(!1),
	delayedTuning: t.boolean().prefault(!1),
	speedcharger: t.boolean().prefault(!1),
	specialGarage: t.boolean().prefault(!1)
}).default({
	niceSandra: !1,
	planner: !1,
	expertTuning: !1,
	delayedTuning: !1,
	speedcharger: !1,
	specialGarage: !1
}), se = t.object({
	tile: t.int(),
	flipped: t.boolean(),
	placedTurn: t.int()
}).nullable(), ce = t.object({
	rid: t.string(),
	seat: H,
	pp: t.int(),
	books: t.int().nonnegative(),
	vouchers: t.int().nonnegative(),
	banked: t.int().min(0).max(10),
	pendBooks: t.int().nonnegative(),
	pendVouchers: t.int().nonnegative(),
	pendBanked: t.int().nonnegative(),
	speechBoard: t.int().nonnegative(),
	speechBeside: t.int().nonnegative(),
	genericBeside: t.int().nonnegative(),
	training: t.array(t.int().min(0).max(5)),
	certs: t.array(t.boolean()),
	certSection: t.int().min(0).max(5),
	certSpace: t.int().min(-1).max(3),
	parts: t.array(W),
	designs: t.array(t.int()),
	upgraded: t.array(t.int()),
	doubleUsed: t.boolean(),
	garages: t.array(U.nullable()),
	garageTiles: t.array(se),
	tilePool: t.array(t.int()),
	special: t.object({
		tile: t.int(),
		activated: t.boolean(),
		pending: t.string().nullable(),
		speechOn: t.boolean(),
		speechGeneric: t.boolean()
	}).nullable(),
	perfCount: t.int().nonnegative(),
	kanbanCount: t.int().nonnegative(),
	chargeRows: t.array(t.boolean()),
	dept: G.nullable(),
	station: t.int().nullable(),
	finalClaimed: t.array(t.int())
}), le = t.object({
	phase: t.enum([
		"inductCert",
		"inductTake",
		"specialGarage",
		"select",
		"work",
		"meeting",
		"meetingContribute",
		"finalGoals",
		"over"
	]),
	day: t.int(),
	week: t.int(),
	cycle: t.int(),
	turnSeq: t.int(),
	meetingPending: t.boolean(),
	config: oe,
	players: t.array(ce),
	warehouses: t.array(t.int()),
	recycle: t.array(W),
	carSupply: t.array(t.int()),
	cars: t.record(t.string(), U),
	asmParts: t.array(t.array(W)),
	upgrades: t.array(t.array(W.nullable())),
	upVal: t.array(t.int()),
	doubled: t.array(t.boolean()),
	testQueue: t.array(U),
	pace: t.int(),
	demand: t.array(t.object({
		model: U,
		tokens: t.int()
	})),
	display: t.array(t.array(t.int().nullable())),
	stackCounts: t.object({
		firstTop: t.int(),
		firstBottom: t.int(),
		central: t.int()
	}),
	perfDeckCount: t.int(),
	kanbanDeckCount: t.int(),
	factory: t.array(t.object({
		kind: t.enum([
			"cars",
			"certs",
			"upgrades"
		]),
		threshold: t.int(),
		tokens: t.int()
	})),
	awardSpeech: t.array(t.boolean()),
	tableGoals: t.array(t.int()),
	finalGoal: t.int(),
	chargerSupply: t.int(),
	sandra: t.object({
		dept: G,
		desk: t.boolean(),
		station: t.int().nullable()
	}),
	current: H.nullable(),
	work: t.object({
		shiftsLeft: t.int(),
		baseShifts: t.int(),
		bankedUsed: t.int(),
		adminTarget: G.nullable(),
		kanbanUsed: t.boolean(),
		voucherUsed: t.boolean(),
		chargeUsed: t.boolean(),
		claimed: t.int(),
		speedRdUsed: t.boolean()
	}).nullable(),
	branch: t.object({
		pos: t.int(),
		options: t.array(t.object({
			to: t.int().nullable(),
			exit: t.union([t.literal(1), t.literal(2)]).nullable()
		}))
	}).nullable(),
	prompt: t.discriminatedUnion("kind", [t.object({
		kind: t.literal("certSpace"),
		seat: H,
		section: t.int()
	}), t.object({
		kind: t.literal("award"),
		seat: H,
		dept: G
	})]).nullable(),
	meeting: t.object({
		current: H,
		played: t.array(t.boolean()),
		goals: t.array(t.object({
			card: t.int(),
			tokens: t.array(t.object({
				seat: H,
				generic: t.boolean()
			}).nullable())
		}))
	}).nullable(),
	contribute: t.array(t.boolean()).nullable(),
	finalQueue: t.array(H),
	result: t.object({
		scores: t.array(t.int()),
		ranking: t.array(t.array(H))
	}).nullable()
}), ue = t.object({
	seat: H,
	perfHand: t.array(t.int()),
	kanbanHand: t.array(t.int()),
	awardOptions: t.array(t.int()).nullable()
}), K = (e) => ({ code: e }), q = (e) => ({ state: e });
function J(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; n--) {
		let i = e(t.seed, t.cursor++, n + 1);
		[r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
var de = (e, t) => e.players.findIndex((e) => e.rid === t), Y = (e) => e.garages.filter((e) => e !== null), fe = (e) => e.certs.filter(Boolean).length, pe = (e) => 3 + +!!e.certs[2], me = (e) => 3 + +!!e.certs[3], he = (e) => 4 + +!!e.certs[4], ge = (e) => e.upgraded.filter((t) => Y(e).includes(R(t))), _e = (e) => [...Array(e.n).keys()].sort((t, n) => {
	let r = e.players[t], i = e.players[n];
	return i.certSection - r.certSection || i.certSpace - r.certSpace;
});
function ve(e) {
	let t = e.players.filter((e) => e.dept !== null).map((e) => ({
		who: e.seat,
		dept: e.dept,
		station: e.station
	}));
	return e.day >= 2 && t.push({
		who: "sandra",
		dept: e.sandra.dept,
		station: e.sandra.desk ? 2 : e.sandra.station
	}), t.sort((e, t) => e.dept - t.dept || e.station - t.station), t.map((e) => e.who);
}
function ye(e) {
	e.speechBeside > 0 && e.speechBoard < he(e) ? (e.speechBeside--, e.speechBoard++) : e.genericBeside++;
}
function be(e, t) {
	let n = e.warehouses[t] + e.recycle.filter((e) => e === t).length;
	for (let r of e.asmParts) n += r.filter((e) => e === t).length;
	for (let r of e.upgrades) n += r.filter((e) => e === t).length;
	for (let r of e.players) n += r.parts.filter((e) => e === t).length;
	return 10 - n;
}
function xe(e, t, n) {
	let r = n === "cars" ? Y(t).length : n === "certs" ? fe(t) : t.upgraded.length;
	for (let i of e.factory) i.kind === n && i.tokens > 0 && r >= i.threshold && (i.tokens--, ye(t));
}
function Se(t, n, r) {
	let i = n.length, a = {
		v: 1,
		seed: r,
		cursor: 0,
		n: i,
		turnSeq: 0,
		config: t,
		phase: "inductCert",
		day: 1,
		week: 1,
		cycle: 1,
		meetingPending: !1,
		players: n.map((e, n) => ({
			rid: e,
			seat: n,
			pp: t.niceSandra ? 0 : 15,
			books: 0,
			vouchers: 1,
			banked: 0,
			pendBooks: 0,
			pendVouchers: 0,
			pendBanked: 0,
			speechBoard: 1,
			speechBeside: 4,
			genericBeside: 0,
			training: [
				0,
				0,
				0,
				0,
				0
			],
			trainTick: [
				0,
				0,
				0,
				0,
				0
			],
			certs: [
				!1,
				!1,
				!1,
				!1,
				!1
			],
			certSection: 0,
			certSpace: -1,
			parts: [],
			designs: [],
			upgraded: [],
			doubleUsed: !1,
			garages: [
				null,
				null,
				null,
				null,
				null
			],
			garageTiles: t.delayedTuning ? [
				null,
				null,
				null,
				null,
				t.specialGarage ? null : {
					tile: 4,
					flipped: !1,
					placedTurn: 0
				}
			] : t.specialGarage ? [...[
				0,
				1,
				2,
				3
			].map((e) => ({
				tile: e,
				flipped: !1,
				placedTurn: 0
			})), null] : [
				0,
				1,
				2,
				3,
				4
			].map((e) => ({
				tile: e,
				flipped: !1,
				placedTurn: 0
			})),
			tilePool: t.delayedTuning ? [
				0,
				1,
				2,
				3
			] : [],
			special: null,
			perfHand: [],
			kanbanHand: [],
			chargeRows: [
				!1,
				!1,
				!1,
				!1,
				!1
			],
			dept: null,
			station: null,
			immunityUsed: !1,
			finalClaimed: []
		})),
		warehouses: [
			0,
			0,
			0,
			0,
			0,
			0
		],
		recycle: [],
		carSupply: [
			6,
			6,
			6,
			6,
			6
		],
		cars: {
			11: 4,
			21: 4,
			12: 1,
			22: 1,
			13: 0,
			23: 0,
			14: 2,
			24: 2,
			15: 3,
			25: 3
		},
		asmParts: [
			[],
			[],
			[],
			[],
			[]
		],
		upgrades: [
			[
				null,
				null,
				null,
				null,
				null,
				null
			],
			[
				null,
				null,
				null,
				null,
				null,
				null
			],
			[
				null,
				null,
				null,
				null,
				null,
				null
			],
			[
				null,
				null,
				null,
				null,
				null,
				null
			],
			[
				null,
				null,
				null,
				null,
				null,
				null
			]
		],
		upVal: [
			1,
			1,
			1,
			1,
			1,
			1
		],
		doubled: [
			!1,
			!1,
			!1,
			!1,
			!1,
			!1
		],
		testQueue: [],
		pace: 0,
		demand: [{
			model: 0,
			tokens: 0
		}, {
			model: 1,
			tokens: 0
		}],
		demandStack: [],
		display: [[
			null,
			null,
			null,
			null
		], [
			null,
			null,
			null,
			null
		]],
		firstTop: [],
		firstBottom: [],
		central: [],
		perfDeck: [],
		perfDiscard: [],
		kanbanDeck: [],
		factory: [],
		awardStacks: [],
		awardSpeech: [
			!0,
			!0,
			!0,
			!0,
			!0
		],
		tableGoals: [],
		finalGoal: 0,
		chargerSupply: t.speedcharger ? 3 * i + 2 : 0,
		sandra: {
			dept: 4,
			desk: !0,
			station: null
		},
		queue: [],
		work: null,
		branch: null,
		prompts: [],
		meeting: null,
		contribute: null,
		finalQueue: [],
		inductQueue: [],
		sgQueue: [],
		sgTaken: [],
		tickCounter: 0,
		result: null
	}, o = J(a, [...Array(35).keys()]);
	for (let e = 0; e < 8; e++) a.display[e % 2][3 - Math.floor(e / 2)] = o.pop();
	a.firstTop = o.splice(0, 9), a.firstBottom = o.splice(0, 9), a.central = o, a.kanbanDeck = J(a, [...Array(F.length).keys()]);
	for (let e of a.players) e.kanbanHand = [a.kanbanDeck.pop(), a.kanbanDeck.pop()];
	let s = a.kanbanDeck.pop();
	for (let e of F[s]) a.warehouses[e]++;
	a.kanbanDeck.unshift(s), a.recycle = J(a, [
		0,
		1,
		2,
		3,
		4,
		5
	]).slice(0, 3);
	let c = t.speedcharger ? L.length : 32;
	a.perfDeck = J(a, [...Array(c).keys()]);
	for (let e of a.players) e.perfHand = [
		a.perfDeck.pop(),
		a.perfDeck.pop(),
		a.perfDeck.pop()
	];
	a.tableGoals = [
		a.perfDeck.pop(),
		a.perfDeck.pop(),
		a.perfDeck.pop(),
		a.perfDeck.pop()
	];
	let l = J(a, [
		0,
		1,
		2,
		3,
		4
	]);
	a.demand = [{
		model: l[0],
		tokens: te[l[0]]
	}, {
		model: l[1],
		tokens: te[l[1]]
	}], a.demandStack = l.slice(2);
	let u = O(i);
	a.pace = u[e(a.seed, a.cursor++, u.length)];
	for (let e of [
		"cars",
		"certs",
		"upgrades"
	]) {
		let t = J(a, [...B]), [n, r] = [Math.min(t[0], t[1]), Math.max(t[0], t[1])], o = i >= 4 ? [2, 2] : i === 3 ? [2, 1] : [1, 1];
		a.factory.push({
			kind: e,
			threshold: n,
			tokens: o[0]
		}, {
			kind: e,
			threshold: r,
			tokens: o[1]
		});
	}
	for (let e = 0; e < 5; e++) {
		let e = J(a, [
			0,
			1,
			2,
			3
		]);
		a.awardStacks.push(i === 2 ? e.slice(0, 2) : e);
	}
	a.finalGoal = e(a.seed, a.cursor++, t.speedcharger ? ie.length : 11);
	let d = e(a.seed, a.cursor++, i);
	return a.inductQueue = [...Array(i).keys()].map((e) => (d + e) % i), { state: a };
}
function Ce(e) {
	for (let t = 0; t < 2; t++) {
		let n = e.display[t].filter((e) => e !== null);
		for (let r = 3; r >= 0; r--) e.display[t][r] = n.pop() ?? null;
		for (let n = 3; n >= 0; n--) {
			if (e.display[t][n] !== null) continue;
			let r = (t === 0 ? e.firstTop : e.firstBottom).pop() ?? e.central.pop();
			if (r === void 0) break;
			e.display[t][n] = r;
		}
	}
}
function we(e) {
	if (e.work = null, e.branch = null, e.day === 1) {
		e.queue = _e(e), e.phase = "select";
		return;
	}
	e.queue = ve(e), e.phase = "select", Te(e);
}
function Te(e) {
	for (; e.queue[0] === "sandra";) {
		e.queue.shift();
		for (let t = 1; t <= 5; t++) {
			let n = (e.sandra.dept + t) % 5;
			if (n === 4) {
				e.sandra = {
					dept: 4,
					desk: !0,
					station: null
				};
				break;
			}
			let r = e.players.filter((e) => e.dept === n).map((e) => e.station), i = [0, 1].find((e) => !r.includes(e));
			if (i !== void 0) {
				e.sandra = {
					dept: n,
					desk: !1,
					station: i
				};
				break;
			}
		}
	}
	e.queue.length === 0 && e.phase === "select" && Ee(e);
}
function Ee(e) {
	e.phase = "work", e.queue = ve(e), ke(e);
}
function De(e, t) {
	let n = e.players[t], r = n.dept === 4, i = r ? n.station === 0 ? 1 : 2 : n.station === 0 ? 2 : 3;
	r && e.config.speedcharger && n.chargeRows[4] && i++, e.turnSeq++, e.work = {
		shiftsLeft: i,
		baseShifts: i,
		bankedUsed: 0,
		adminTarget: null,
		kanbanUsed: !1,
		voucherUsed: !1,
		chargeUsed: !1,
		claimed: 0,
		tookDesign: !1,
		speedRdUsed: !1
	}, n.dept === 1 && Oe(e);
}
function Oe(e) {
	for (let t = 0; t < 5; t++) e.asmParts[t].length >= w[t] && (e.asmParts[t] = []);
}
function ke(e) {
	for (; e.queue.length > 0;) {
		let t = e.queue[0];
		if (t === "sandra") {
			e.queue.shift(), Me(e);
			continue;
		}
		De(e, t);
		return;
	}
	e.work = null, e.meetingPending ? Fe(e) : Ae(e);
}
function Ae(e) {
	if (e.cycle >= 2 && e.week >= 3 || e.cycle >= 3 && e.week >= 2) {
		e.phase = "finalGoals", e.finalQueue = _e(e);
		return;
	}
	e.day++, we(e);
}
var je = [
	(e) => e.upgraded.length,
	(e) => Y(e).length,
	(e) => e.parts.length,
	(e) => e.designs.length,
	(e) => fe(e)
];
function Me(e) {
	let t = e.sandra.dept, n = e.players.filter((e) => e.dept === t);
	if (n.length > 0) {
		let r = n.map((e) => e.training[t]), i = e.config.niceSandra ? Math.max(...r) : Math.min(...r);
		for (let r of n.filter((e) => e.training[t] === i)) {
			let n = je[t](r);
			e.config.niceSandra ? n >= 2 && (r.pp += Math.max(0, r.banked - 5)) : n <= 2 && (r.special?.tile === 3 && r.special.activated && !r.immunityUsed ? r.immunityUsed = !0 : r.pp = Math.max(0, r.pp - (1 + Math.max(0, 5 - r.banked))));
		}
	}
	if (t === 0) Pe(e, 1);
	else if (t === 1) e.asmParts = [
		[],
		[],
		[],
		[],
		[]
	];
	else if (t === 2) e.warehouses = e.warehouses.map((e) => Math.min(e, 1));
	else if (t === 3) {
		let t = e.n === 2 ? 8 : 4, n = [];
		for (let r = 3; r >= 0 && n.length < t; r--) for (let i = 0; i < 2; i++) {
			let a = e.display[i][r];
			a !== null && n.length < t && (n.push(a), e.display[i][r] = null);
		}
		e.central = [...J(e, n), ...e.central], Ce(e);
	} else Ne(e);
}
function Ne(e) {
	for (let t of e.players) for (let n of Y(t)) {
		let r = e.upgrades[n].filter((e) => e !== null).length, i = t.upgraded.filter((e) => R(e) === n).length;
		t.pp += r + i;
	}
	e.week = Math.min(3, e.week + 1);
}
function Pe(e, t) {
	let n = ee(e.n), r = O(e.n);
	for (let i = 0; i < t; i++) e.pace = (e.pace + 1) % n, r.includes(e.pace) && (e.meetingPending = !0);
}
function Fe(e) {
	e.phase = "meeting", e.meeting = {
		order: _e(e),
		idx: 0,
		passStreak: 0,
		played: e.players.map(() => !1),
		goals: e.tableGoals.map((e) => ({
			card: e,
			tokens: Array(L[e].max).fill(null)
		}))
	}, e.tableGoals = [];
}
function Ie(e, t) {
	switch (e.t) {
		case "cars": return Y(t).length;
		case "models": return new Set(Y(t)).size;
		case "modelCars": return Y(t).filter((t) => t === e.m).length;
		case "partUpgrades": return t.upgraded.filter((t) => z(t) === e.p).length;
		case "upgrades": return t.upgraded.length;
		case "tested": return ge(t).length;
		case "parts2": return t.parts.filter((t) => e.ps.includes(t)).length;
		case "garagePair": return e.g.filter((e) => t.garages[e] !== null).length;
		case "cert": return +!!t.certs[e.d];
		case "designs": return t.designs.length;
		case "books": return t.books;
		case "certs": return fe(t);
		case "vouchers": return t.vouchers;
		case "banked": return t.banked;
		case "speech": return t.speechBoard;
		case "chargers": return t.chargeRows.filter(Boolean).length;
		case "chargerRow": return +!!t.chargeRows[e.row];
	}
}
function Le(e, t, n) {
	let r = L[t.card], i = t.tokens.findIndex((e) => e === null), a = r.max - i;
	t.tokens[i] = {
		seat: e.seat,
		generic: n
	}, e.pp += Math.min(Ie(r.kind, e), a) * r.pp;
}
function Re(e) {
	let t = e.meeting;
	for (let n of t.goals) for (let t of n.tokens) t && !t.generic && e.players[t.seat].speechBeside++;
	for (let t of e.players) for (; t.genericBeside > 0 && t.speechBeside > 0 && t.speechBoard < he(t);) t.genericBeside--, t.speechBeside--, t.speechBoard++;
	e.perfDiscard.push(...t.goals.map((e) => e.card)), e.meeting = null, e.phase = "meetingContribute", e.contribute = e.players.map(() => !1);
}
function ze(e, t, n) {
	for (let r = 0; r < n; r++) {
		e.perfDeck.length === 0 && e.perfDiscard.length > 0 && (e.perfDeck = J(e, e.perfDiscard), e.perfDiscard = []);
		let n = e.perfDeck.pop();
		if (n === void 0) return;
		t.perfHand.push(n);
	}
}
function Be(e, t) {
	let n = Y(t);
	switch (e.t) {
		case "sameModelCars": return [
			0,
			1,
			2,
			3,
			4
		].some((t) => n.filter((e) => e === t).length >= e.n);
		case "cars": return n.length >= e.n;
		case "distinctModels": return new Set(n).size >= e.n;
		case "modelCars": return n.filter((t) => t === e.m).length >= e.n;
		case "distinctPartUpgrades": return new Set(t.upgraded.map((e) => z(e))).size >= e.n;
		case "samePartUpgrades": return [
			0,
			1,
			2,
			3,
			4,
			5
		].some((n) => t.upgraded.filter((e) => z(e) === n).length >= e.n);
		case "partUpgrades": return t.upgraded.filter((t) => z(t) === e.p).length >= e.n;
		case "upgrades": return t.upgraded.length >= e.n;
		case "tested": return ge(t).length >= e.n;
		case "testedParts": return new Set(ge(t).map((e) => z(e))).size >= e.n;
		case "certs": return fe(t) >= e.n;
		case "certsMax": return fe(t) <= e.n;
		case "certPair": return e.ds[0] === e.ds[1] ? t.certs[e.ds[0]] : t.certs[e.ds[0]] && t.certs[e.ds[1]];
		case "banked": return t.banked >= e.n;
		case "books": return t.books >= e.n;
		case "vouchers": return t.vouchers >= e.n;
		case "experts": return t.training.filter((e) => e >= 5).length >= e.n;
		case "expertsMax": return t.training.filter((e) => e >= 5).length <= e.n;
		case "chargers": return t.chargeRows.filter(Boolean).length >= e.n;
		case "chargerRow": return t.chargeRows[e.row];
		case "speechBoard": return t.speechBoard >= e.n;
	}
}
function Ve(e) {
	let t = [];
	for (let n of e.players) {
		let r = n.pp;
		r += n.banked, r += n.speechBoard + n.genericBeside + n.books + n.vouchers;
		for (let e of Y(n)) r += C[e];
		n.special?.tile === 5 && n.special.activated && n.garages[4] !== null && (r += C[n.garages[4]]);
		for (let t = 0; t < 5; t++) {
			let i = e.players.filter((e) => e.training[t] > 0).sort((e, n) => n.training[t] - e.training[t] || n.trainTick[t] - e.trainTick[t]).indexOf(n);
			i === 0 ? r += 5 : i === 1 ? r += 3 : i === 2 && (r += 1);
		}
		for (let t of ge(n)) r += e.upVal[z(t)];
		e.config.speedcharger && (r += n.chargeRows.filter(Boolean).length * Y(n).length), t.push(r);
	}
	let n = e.players.map((e, n) => ({
		seat: n,
		k: [
			t[n],
			Y(e).length,
			ge(e).length,
			e.banked
		]
	}));
	n.sort((e, t) => {
		for (let n = 0; n < 4; n++) if (t.k[n] !== e.k[n]) return t.k[n] - e.k[n];
		return 0;
	});
	let r = [];
	for (let e of n) {
		let t = r[r.length - 1], i = r.length ? n[r.flat().length - 1] : null;
		t && i && i.k.every((t, n) => t === e.k[n]) ? t.push(e.seat) : r.push([e.seat]);
	}
	for (let n = 0; n < e.n; n++) e.players[n].pp = t[n];
	e.result = {
		scores: t,
		ranking: r
	}, e.phase = "over";
}
function He(e) {
	let t = e.branch;
	for (; t.stack.length > 0;) {
		let n = t.stack[t.stack.length - 1];
		if (n.kind === "moveInto") {
			e.cars[n.to] = e.cars[n.from], delete e.cars[n.from], t.stack.pop();
			continue;
		}
		let r = T[n.pos];
		if (r.length > 1) return;
		Ue(e, r[0]);
	}
	e.branch = null;
}
function Ue(e, t) {
	let n = e.branch, r = n.stack[n.stack.length - 1];
	if (r.kind === "advance") {
		if ("exit" in t) {
			let i = e.cars[r.pos];
			delete e.cars[r.pos], n.stack.pop(), We(e, i, t.exit);
			return;
		}
		e.cars[t.to] === void 0 ? (e.cars[t.to] = e.cars[r.pos], delete e.cars[r.pos], n.stack.pop()) : (n.stack.pop(), n.stack.push({
			kind: "moveInto",
			from: r.pos,
			to: t.to
		}), n.stack.push({
			kind: "advance",
			pos: t.to
		}));
	}
}
function We(e, t, n) {
	let r = e.queue[0];
	if (typeof r != "number") return;
	let i = e.players[r];
	i.pp += n;
	let a = e.demand.find((e) => e.model === t && e.tokens > 0);
	if (a && (a.tokens--, ye(i)), e.testQueue.push(t), e.testQueue.length > 4) {
		let t = e.testQueue.shift();
		e.carSupply[t]++;
	}
}
function Ge(e, t) {
	let n = D[t];
	if (e.cars[n] === t) return n;
	let r = /* @__PURE__ */ new Map([[n, 0]]), i = [n], a = null;
	for (; i.length > 0;) {
		let n = i.shift(), o = r.get(n);
		e.cars[n] === t && (!a || o < a.d) && (a = {
			pos: n,
			d: o
		});
		for (let e of T[n] ?? []) "to" in e && !r.has(e.to) && (r.set(e.to, o + 1), i.push(e.to));
	}
	return a?.pos ?? null;
}
function Ke(e, t) {
	let n = D[t];
	e.cars[n] === void 0 && e.carSupply[t] > 0 && (e.cars[n] = t, e.carSupply[t]--);
}
function qe(e, t, n, r) {
	for (let i = 0; i < r && t.training[n] < 5; i++) {
		if (t.training[n]++, e.tickCounter++, t.trainTick[n] = e.tickCounter, t.training[n] === 3 && !t.certs[n]) {
			t.certs[n] = !0;
			let r = t.certSection + 1;
			r <= 5 && (P[r].every((t, n) => e.players.some((e) => e.certSection === r && e.certSpace === n)) || e.prompts.push({
				kind: "certSpace",
				seat: t.seat,
				section: r
			})), xe(e, t, "certs");
		}
		t.training[n] === 5 && (e.awardStacks[n].length > 0 && e.prompts.push({
			kind: "award",
			seat: t.seat,
			dept: n
		}), e.awardSpeech[n] && (e.awardSpeech[n] = !1, ye(t)));
	}
}
function Je(e, t, n) {
	let r = P[t][n];
	r.pp && (e.pp += r.pp), r.bank && (e.pendBanked += r.bank), r.book && (e.pendBooks += r.book), r.voucher && (e.pendVouchers += r.voucher), r.speech && ye(e);
}
function Ye(e, t, n, r, i) {
	let a = (n) => {
		if (!i || i.length !== n) return K("games.kanban.errBadChoice");
		if (t.parts.length + n > pe(t)) return K("games.kanban.errCapParts");
		for (let t of i) if (be(e, t) <= 0) return K("games.kanban.errSupplyEmpty");
		return t.parts.push(...i), null;
	}, o = (e) => {
		if (e === 0) ye(t);
		else if (e === 1) t.pendBanked += 2;
		else if (e === 2) t.pendBooks += 2;
		else return a(2);
		return null;
	};
	switch (n.kind) {
		case "none": return null;
		case "speech": return ye(t), null;
		case "bank": return t.pendBanked += n.n, null;
		case "book": return t.pendBooks += n.n, null;
		case "parts": return a(n.n);
		case "lock": return !r || r[0] === r[1] ? K("games.kanban.errBadChoice") : o(r[0]) || o(r[1]);
	}
}
var Xe = (e) => e.config.expertTuning ? I : ne;
function Ze(e, t, n) {
	let r = structuredClone(e), i = de(r, n.by);
	if (i < 0) return K("games.kanban.errNotYourTurn");
	let a = r.players[i];
	if (r.prompts.length > 0) {
		let e = r.prompts[0];
		if (t.type === "chooseCertSpace" && e.kind === "certSpace") {
			if (e.seat !== i) return K("games.kanban.errNotYourTurn");
			let n = P[e.section].length;
			return t.space >= n ? K("games.kanban.errBadChoice") : r.players.some((n) => n.certSection === e.section && n.certSpace === t.space) ? K("games.kanban.errOccupied") : (a.certSection = e.section, a.certSpace = t.space, Je(a, e.section, t.space), r.prompts.shift(), q(r));
		}
		if (t.type === "chooseAward" && e.kind === "award") {
			if (e.seat !== i) return K("games.kanban.errNotYourTurn");
			let n = r.awardStacks[e.dept].indexOf(t.award);
			return n < 0 ? K("games.kanban.errBadChoice") : (r.awardStacks[e.dept].splice(n, 1), t.award === 0 ? a.pp += 2 : t.award === 1 ? a.pendBanked += 1 : t.award === 2 ? a.pendBooks += 1 : a.pendVouchers += 1, r.prompts.shift(), q(r));
		}
		if (e.seat === i) return K("games.kanban.errPromptPending");
	}
	if (r.branch) {
		if (t.type !== "carMove") return K("games.kanban.errPromptPending");
		if (r.queue[0] !== i) return K("games.kanban.errNotYourTurn");
		let e = r.branch.stack[r.branch.stack.length - 1];
		if (e.kind !== "advance") return K("games.kanban.errBadPhase");
		let n = T[e.pos].find((e) => "to" in e && e.to === t.to || "exit" in e && e.exit === t.exit);
		if (!n) return K("games.kanban.errBadChoice");
		let a = r.branch.model;
		return Ue(r, n), He(r), r.branch || Ke(r, a), q(r);
	}
	switch (r.phase) {
		case "inductCert": {
			if (t.type !== "inductCert") return K("games.kanban.errBadPhase");
			if (r.inductQueue[0] !== i) return K("games.kanban.errNotYourTurn");
			if (r.players.some((e) => e.certSection === 0 && e.certSpace === t.space)) return K("games.kanban.errOccupied");
			a.certSpace = t.space;
			let e = P[0][t.space];
			return e.bank && (a.banked += e.bank), e.book && (a.books += e.book), e.voucher && (a.vouchers += e.voucher), r.inductQueue.shift(), r.inductQueue.length === 0 && (r.inductQueue = _e(r), r.phase = "inductTake"), q(r);
		}
		case "inductTake": {
			if (t.type !== "inductTake") return K("games.kanban.errBadPhase");
			if (r.inductQueue[0] !== i) return K("games.kanban.errNotYourTurn");
			if (r.warehouses[t.part] <= 0) return K("games.kanban.errSupplyEmpty");
			let e;
			if (t.design.kind === "display") {
				let n = r.display[t.design.row][t.design.col];
				if (n === null) return K("games.kanban.errNoDesign");
				r.display[t.design.row][t.design.col] = null, e = n;
			} else {
				let n = (t.design.stack === "firstTop" ? r.firstTop : t.design.stack === "firstBottom" ? r.firstBottom : r.central).pop();
				if (n === void 0) return K("games.kanban.errNoDesign");
				e = n;
			}
			return r.warehouses[t.part]--, a.parts.push(t.part), a.designs.push(e), r.inductQueue.shift(), r.inductQueue.length === 0 && (Ce(r), r.config.specialGarage ? (r.phase = "specialGarage", r.sgQueue = [..._e(r)].reverse()) : we(r)), q(r);
		}
		case "specialGarage": return t.type === "pickSpecialGarage" ? r.sgQueue[0] === i ? r.sgTaken.includes(t.tile) ? K("games.kanban.errOccupied") : r.config.niceSandra && re[t.tile] === "immunity" ? K("games.kanban.errBadChoice") : (r.sgTaken.push(t.tile), a.special = {
			tile: t.tile,
			activated: !1,
			pending: null,
			speechOn: !1,
			speechGeneric: !1
		}, r.sgQueue.shift(), r.sgQueue.length === 0 && we(r), q(r)) : K("games.kanban.errNotYourTurn") : K("games.kanban.errBadPhase");
		case "select": return t.type === "selectDept" ? r.queue[0] === i ? a.dept === t.dept ? K("games.kanban.errMustMove") : r.n === 2 && r.sandra.dept === t.dept ? K("games.kanban.errSandraDept") : r.players.some((e) => e.dept === t.dept && e.station === t.station) || !r.sandra.desk && r.sandra.dept === t.dept && r.sandra.station === t.station ? K("games.kanban.errOccupied") : (a.dept = t.dept, a.station = t.station, r.queue.shift(), Te(r), q(r)) : K("games.kanban.errNotYourTurn") : K("games.kanban.errBadPhase");
		case "work": return Qe(r, a, t);
		case "meeting": return $e(r, a, t);
		case "meetingContribute": {
			if (t.type !== "meetContribute" || r.contribute[i]) return K("games.kanban.errBadPhase");
			let e = a.perfHand.indexOf(t.cardId);
			if (e < 0) return K("games.kanban.errNoCard");
			if (a.perfHand.splice(e, 1), r.tableGoals.push(t.cardId), r.contribute[i] = !0, r.contribute.every(Boolean)) {
				for (; r.tableGoals.length < 4;) {
					r.perfDeck.length === 0 && r.perfDiscard.length > 0 && (r.perfDeck = J(r, r.perfDiscard), r.perfDiscard = []);
					let e = r.perfDeck.pop();
					if (e === void 0) break;
					r.tableGoals.push(e);
				}
				for (let e of r.players) ze(r, e, 2);
				r.meetingPending = !1, r.cycle = Math.min(3, r.cycle + 1), r.contribute = null, Ae(r);
			}
			return q(r);
		}
		case "finalGoals": {
			if (t.type !== "claimFinal") return K("games.kanban.errBadPhase");
			if (r.finalQueue[0] !== i) return K("games.kanban.errNotYourTurn");
			let e = ie[r.finalGoal];
			if (new Set(t.achievements).size !== t.achievements.length) return K("games.kanban.errBadChoice");
			let n = t.achievements.length;
			if (a.speechBoard + a.genericBeside < n) return K("games.kanban.errNoSpeech");
			for (let n of t.achievements) {
				if (a.finalClaimed.includes(n)) return K("games.kanban.errBadChoice");
				if (!e[n].all.every((e) => Be(e, a))) return K("games.kanban.errBadAchievement");
			}
			for (let e = 0; e < n; e++) a.genericBeside > 0 ? a.genericBeside-- : a.speechBoard--;
			for (let n of t.achievements) a.finalClaimed.push(n), a.pp += e[n].pp;
			return r.finalQueue.shift(), r.finalQueue.length === 0 && Ve(r), q(r);
		}
		case "over": return K("games.kanban.errBadPhase");
	}
}
function Qe(e, t, n) {
	let r = e.work;
	if (e.queue[0] !== t.seat) return K("games.kanban.errNotYourTurn");
	let i = t.dept === 4, a = (e) => t.dept === e || i && r.adminTarget === e, o = 4 + (t.special?.tile === 2 && t.special.activated ? 1 : 0);
	switch (n.type) {
		case "useBanked": return t.banked < n.n ? K("games.kanban.errNoBanked") : r.bankedUsed + n.n > 3 || r.shiftsLeft + n.n > o ? K("games.kanban.errBankMax") : (t.banked -= n.n, r.bankedUsed += n.n, r.shiftsLeft += n.n, q(e));
		case "train": {
			let i = t.special?.pending === "train2" ? -1 : t.special?.pending?.startsWith("train2b:") ? Number(t.special.pending.slice(8)) : null;
			return i === null ? r.shiftsLeft < 1 ? K("games.kanban.errNoShift") : a(n.dept) ? t.training[n.dept] >= 5 ? K("games.kanban.errBadChoice") : (r.shiftsLeft--, qe(e, t, n.dept, 1), q(e)) : K("games.kanban.errBadDept") : n.dept === i || t.training[n.dept] >= 5 ? K("games.kanban.errBadChoice") : (qe(e, t, n.dept, 1), t.special && (t.special.pending = i === -1 ? `train2b:${n.dept}` : null), q(e));
		}
		case "homework": return t.books < n.n ? K("games.kanban.errNoBook") : a(n.dept) ? t.training[n.dept] + n.n > 5 ? K("games.kanban.errBadChoice") : (t.books -= n.n, qe(e, t, n.dept, n.n), q(e)) : K("games.kanban.errBadDept");
		case "adminTarget": return i ? n.dept === 4 ? K("games.kanban.errBadChoice") : r.adminTarget === null ? (r.adminTarget = n.dept, n.dept === 1 && Oe(e), q(e)) : K("games.kanban.errBadPhase") : K("games.kanban.errAdminOnly");
		case "takeDesign": {
			let i = t.special?.pending === "design";
			if (!i) {
				if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
				if (!a(3)) return K("games.kanban.errBadDept");
			}
			if (t.designs.length >= me(t)) return K("games.kanban.errCapDesigns");
			let o = e.display[n.row][n.col];
			return o === null ? K("games.kanban.errNoDesign") : (e.display[n.row][n.col] = null, t.designs.push(o), i && t.special ? t.special.pending = null : r.shiftsLeft--, r.tookDesign = !0, n.col === 2 ? t.pendBanked++ : n.col === 3 && t.pendBooks++, q(e));
		}
		case "takeAdvancedDesign": {
			if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
			if (!a(3)) return K("games.kanban.errBadDept");
			if (!t.certs[3]) return K("games.kanban.errNeedCert");
			if (t.designs.length >= me(t)) return K("games.kanban.errCapDesigns");
			let i = n.stack === "firstTop" ? e.firstTop : n.stack === "firstBottom" ? e.firstBottom : e.central, o = i.pop();
			if (o === void 0) return K("games.kanban.errNoDesign");
			if (t.designs.push(o), r.shiftsLeft--, n.stack !== "central" && i.length === 0) {
				let t = e.central.pop();
				t !== void 0 && i.push(t);
			}
			return n.stack === "central" && e.config.speedcharger && t.chargeRows[3] && t.pendBooks++, q(e);
		}
		case "kanbanOrder": {
			if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
			if (!a(2)) return K("games.kanban.errBadDept");
			if (r.kanbanUsed) return K("games.kanban.errKanbanUsed");
			let i = t.kanbanHand.indexOf(n.cardId);
			if (i < 0) return K("games.kanban.errNoCard");
			t.kanbanHand.splice(i, 1), r.shiftsLeft--, r.kanbanUsed = !0, t.pendBanked += e.config.speedcharger && t.chargeRows[2] ? 2 : 1;
			let o = F[n.cardId], s = n.side === 0 ? o.slice(0, 4) : o.slice(4, 6);
			for (let t of s) be(e, t) > 0 && e.warehouses[t]++;
			return e.kanbanDeck.unshift(n.cardId), e.kanbanDeck.length > 0 && t.kanbanHand.push(e.kanbanDeck.pop()), q(e);
		}
		case "collectParts":
			if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
			if (!a(2)) return K("games.kanban.errBadDept");
			if (e.warehouses[n.part] < n.count) return K("games.kanban.errSupplyEmpty");
			if (t.parts.length + n.count > pe(t)) return K("games.kanban.errCapParts");
			e.warehouses[n.part] -= n.count;
			for (let e = 0; e < n.count; e++) t.parts.push(n.part);
			return r.shiftsLeft--, q(e);
		case "takeVoucher": return r.shiftsLeft < 1 ? K("games.kanban.errNoShift") : a(2) ? t.certs[2] ? r.voucherUsed ? K("games.kanban.errVoucherUsed") : (r.shiftsLeft--, r.voucherUsed = !0, t.pendVouchers++, q(e)) : K("games.kanban.errNeedCert") : K("games.kanban.errBadDept");
		case "recycle": {
			let r = t.parts.indexOf(n.give);
			if (r < 0) return K("games.kanban.errNoPart");
			let i = e.recycle.indexOf(n.take);
			return i < 0 ? K("games.kanban.errSupplyEmpty") : (t.parts.splice(r, 1), e.recycle.splice(i, 1), t.parts.push(n.take), e.recycle.push(n.give), q(e));
		}
		case "providePart": {
			if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
			if (!a(1)) return K("games.kanban.errBadDept");
			let i = n.model;
			if (e.asmParts[i].length >= w[i]) return K("games.kanban.errAsmFull");
			if (e.asmParts[i].includes(n.part)) return K("games.kanban.errPartMismatch");
			if (!(e.config.speedcharger && t.chargeRows[1])) {
				let t = e.upgrades[i].filter((e) => e !== null).filter((t) => !e.asmParts[i].includes(t));
				if (t.length > 0 && !t.includes(n.part)) return K("games.kanban.errUpgradeFirst");
			}
			if (n.source === "part") {
				let e = t.parts.indexOf(n.part);
				if (e < 0) return K("games.kanban.errNoPart");
				t.parts.splice(e, 1);
			} else {
				if (t.vouchers < 1) return K("games.kanban.errNoVoucher");
				if (be(e, n.part) <= 0) return K("games.kanban.errSupplyEmpty");
				t.vouchers--;
			}
			r.shiftsLeft--, e.asmParts[i].push(n.part);
			let o = Ge(e, i);
			return o !== null && (e.branch = {
				stack: [{
					kind: "advance",
					pos: o
				}],
				model: i
			}, He(e)), e.branch || Ke(e, i), q(e);
		}
		case "claimCar": {
			if (!a(0)) return K("games.kanban.errBadDept");
			if (n.trackIdx >= e.testQueue.length) return K("games.kanban.errNoCar");
			let i = e.testQueue[n.trackIdx], o = t.designs.indexOf(n.designId);
			if (o < 0) return K("games.kanban.errNoDesign");
			if (R(n.designId) !== i) return K("games.kanban.errDesignMismatch");
			let s = k[n.trackIdx];
			if (r.shiftsLeft < s) return K("games.kanban.errNoShift");
			if (t.garages[n.garage] !== null) return K("games.kanban.errNoGarage");
			if (n.garage === 4 && !t.certs[1]) return K("games.kanban.errGarageLocked");
			if (e.config.planner && n.garage !== t.garages.indexOf(null)) return K("games.kanban.errPlanner");
			if (e.config.delayedTuning && n.garage <= 3) {
				if (n.tile === void 0 || !t.tilePool.includes(n.tile)) return K("games.kanban.errBadTile");
				t.tilePool.splice(t.tilePool.indexOf(n.tile), 1), t.garageTiles[n.garage] = {
					tile: n.tile,
					flipped: !1,
					placedTurn: e.turnSeq
				};
			}
			r.shiftsLeft -= s, t.designs.splice(o, 1), e.central.unshift(n.designId), e.testQueue.splice(n.trackIdx, 1), t.garages[n.garage] = i, r.claimed++;
			let c = t.garageTiles[n.garage], l = e.config.specialGarage && n.garage === 4;
			if (c && !c.flipped && !l && !(e.config.delayedTuning && n.garage <= 3)) {
				let r = Ye(e, t, Xe(e)[c.tile], n.lockChoice, n.gainParts);
				if (r) return r;
				c.flipped = !0;
			}
			return xe(e, t, "cars"), q(e);
		}
		case "upgradeDesign": {
			if (r.shiftsLeft < 1) return K("games.kanban.errNoShift");
			if (!a(0)) return K("games.kanban.errBadDept");
			let i = t.designs.indexOf(n.designId);
			if (i < 0) return K("games.kanban.errNoDesign");
			let o = z(n.designId);
			if (o === null) return K("games.kanban.errDesignMismatch");
			let s = R(n.designId);
			if (e.upgrades[s][n.space] !== null) return K("games.kanban.errOccupied");
			if (n.double) {
				if (!t.certs[0]) return K("games.kanban.errNeedCert");
				if (t.doubleUsed) return K("games.kanban.errDoubleUsed");
				if (e.doubled[o]) return K("games.kanban.errDoubled");
			}
			if (n.source === "part") {
				let e = t.parts.indexOf(o);
				if (e < 0) return K("games.kanban.errNoPart");
				t.parts.splice(e, 1);
			} else if (n.source === "voucher") {
				if (t.vouchers < 1) return K("games.kanban.errNoVoucher");
				if (be(e, o) <= 0) return K("games.kanban.errSupplyEmpty");
				t.vouchers--;
			} else {
				let n = e.config.speedcharger && t.chargeRows[0] && !r.speedRdUsed, i = t.special?.pending === "upgrade";
				if (!n && !i) return K("games.kanban.errBadChoice");
				if (be(e, o) <= 0) return K("games.kanban.errSupplyEmpty");
				i && t.special ? t.special.pending = null : r.speedRdUsed = !0;
			}
			r.shiftsLeft--, e.upgrades[s][n.space] = o;
			let c = N[s][n.space];
			c.kind === "pp" ? t.pp += c.n : c.kind === "book" && (t.pendBooks += c.n);
			let l = n.double ? 2 : 1;
			return e.upVal[o] = Math.min(6, e.upVal[o] + l), n.double && (t.doubleUsed = !0, e.doubled[o] = !0, t.pp += e.upVal[o]), t.designs.splice(i, 1), t.upgraded.push(n.designId), t.pp += 2, xe(e, t, "upgrades"), q(e);
		}
		case "charge": return e.config.speedcharger ? i ? r.shiftsLeft < 1 ? K("games.kanban.errNoShift") : r.chargeUsed ? K("games.kanban.errChargeUsed") : e.chargerSupply <= 0 ? K("games.kanban.errSupplyEmpty") : t.chargeRows[n.row] ? K("games.kanban.errChargeRowFull") : (r.shiftsLeft--, r.chargeUsed = !0, e.chargerSupply--, t.chargeRows[n.row] = !0, q(e)) : K("games.kanban.errAdminOnly") : K("games.kanban.errBadPhase");
		case "sgActivate": {
			if (!e.config.specialGarage || !t.special || t.special.activated) return K("games.kanban.errBadPhase");
			if (t.garages[4] === null) return K("games.kanban.errSgNoCar");
			t.special.activated = !0;
			let n = re[t.special.tile];
			return n === "upgrade" ? t.special.pending = "upgrade" : n === "train2" ? t.special.pending = "train2" : n === "design" ? t.special.pending = "design" : n === "speech" && (t.special.speechOn = !0, t.speechBeside > 0 ? (t.speechBeside--, t.special.speechGeneric = !1) : t.speechBoard > 0 ? (t.speechBoard--, t.special.speechGeneric = !1) : t.special.speechGeneric = !0), q(e);
		}
		case "flipGarageTile": {
			if (!e.config.delayedTuning) return K("games.kanban.errBadPhase");
			let r = t.garageTiles[n.garage];
			return !r || r.flipped ? K("games.kanban.errBadTile") : r.placedTurn >= e.turnSeq ? K("games.kanban.errNotFlippable") : Ye(e, t, Xe(e)[r.tile], n.lockChoice, n.gainParts) || (r.flipped = !0, q(e));
		}
		case "endWork": {
			r.tookDesign && Ce(e);
			let n = !1;
			for (let t = 0; t < 2; t++) if (e.demand[t].tokens === 0 && e.demandStack.length > 0) {
				e.demandStack.push(e.demand[t].model);
				let r = e.demandStack.shift();
				e.demand[t] = {
					model: r,
					tokens: te[r]
				}, n = !0;
			}
			return n && (e.demandStack = J(e, e.demandStack)), r.claimed > 0 && Pe(e, r.claimed), t.banked = Math.min(10, t.banked + t.pendBanked), t.books += t.pendBooks, t.vouchers += t.pendVouchers, t.pendBanked = 0, t.pendBooks = 0, t.pendVouchers = 0, e.work = null, e.queue.shift(), ke(e), q(e);
		}
		default: return K("games.kanban.errBadPhase");
	}
}
function $e(e, t, n) {
	let r = e.meeting;
	if (r.order[r.idx] !== t.seat) return K("games.kanban.errNotYourTurn");
	let i = () => {
		r.idx = (r.idx + 1) % r.order.length;
	};
	switch (n.type) {
		case "meetPlay": {
			if (r.played[t.seat]) return K("games.kanban.errAlreadyPlayed");
			let a = t.perfHand.indexOf(n.cardId);
			if (a < 0) return K("games.kanban.errNoCard");
			t.perfHand.splice(a, 1);
			let o = {
				card: n.cardId,
				tokens: Array(L[n.cardId].max).fill(null)
			};
			if (r.goals.push(o), r.played[t.seat] = !0, n.speak) {
				if (t.speechBoard > 0) t.speechBoard--, Le(t, o, !1);
				else if (t.special?.speechOn) t.special.speechOn = !1, Le(t, o, t.special.speechGeneric);
				else return K("games.kanban.errNoSpeech");
			}
			return r.passStreak = 0, i(), q(e);
		}
		case "meetSpeak": {
			let a = r.goals[n.goalIdx];
			if (!a) return K("games.kanban.errBadChoice");
			if (a.tokens.some((e) => e?.seat === t.seat)) return K("games.kanban.errAlreadySpoken");
			if (a.tokens.every((e) => e !== null)) return K("games.kanban.errOccupied");
			if (n.source === "board") {
				if (t.speechBoard < 1) return K("games.kanban.errNoSpeech");
				t.speechBoard--, Le(t, a, !1);
			} else {
				if (!t.special?.speechOn) return K("games.kanban.errNoSpeech");
				t.special.speechOn = !1, Le(t, a, t.special.speechGeneric);
			}
			return r.passStreak = 0, i(), q(e);
		}
		case "meetPass": return r.played[t.seat] ? (r.passStreak++, i(), r.passStreak >= e.n && Re(e), q(e)) : K("games.kanban.errMustPlay");
		default: return K("games.kanban.errBadPhase");
	}
}
function et(e, t) {
	let n = de(e, t), r = n >= 0 ? e.players[n] : null, i = e.phase === "inductCert" || e.phase === "inductTake" ? e.inductQueue[0] ?? null : e.phase === "specialGarage" ? e.sgQueue[0] ?? null : e.phase === "select" || e.phase === "work" ? typeof e.queue[0] == "number" ? e.queue[0] : null : e.phase === "meeting" ? e.meeting.order[e.meeting.idx] : e.phase === "finalGoals" ? e.finalQueue[0] ?? null : null, a = e.branch?.stack[e.branch.stack.length - 1], o = {
		phase: e.phase,
		day: e.day,
		week: e.week,
		cycle: e.cycle,
		turnSeq: e.turnSeq,
		meetingPending: e.meetingPending,
		config: e.config,
		players: e.players.map((e) => ({
			rid: e.rid,
			seat: e.seat,
			pp: e.pp,
			books: e.books,
			vouchers: e.vouchers,
			banked: e.banked,
			pendBooks: e.pendBooks,
			pendVouchers: e.pendVouchers,
			pendBanked: e.pendBanked,
			speechBoard: e.speechBoard,
			speechBeside: e.speechBeside,
			genericBeside: e.genericBeside,
			training: [...e.training],
			certs: [...e.certs],
			certSection: e.certSection,
			certSpace: e.certSpace,
			parts: [...e.parts],
			designs: [...e.designs],
			upgraded: [...e.upgraded],
			doubleUsed: e.doubleUsed,
			garages: [...e.garages],
			garageTiles: e.garageTiles.map((e) => e ? { ...e } : null),
			tilePool: [...e.tilePool],
			special: e.special ? { ...e.special } : null,
			perfCount: e.perfHand.length,
			kanbanCount: e.kanbanHand.length,
			chargeRows: [...e.chargeRows],
			dept: e.dept,
			station: e.station,
			finalClaimed: [...e.finalClaimed]
		})),
		warehouses: [...e.warehouses],
		recycle: [...e.recycle],
		carSupply: [...e.carSupply],
		cars: Object.fromEntries(Object.entries(e.cars).map(([e, t]) => [e, t])),
		asmParts: e.asmParts.map((e) => [...e]),
		upgrades: e.upgrades.map((e) => [...e]),
		upVal: [...e.upVal],
		doubled: [...e.doubled],
		testQueue: [...e.testQueue],
		pace: e.pace,
		demand: e.demand.map((e) => ({ ...e })),
		display: e.display.map((e) => [...e]),
		stackCounts: {
			firstTop: e.firstTop.length,
			firstBottom: e.firstBottom.length,
			central: e.central.length
		},
		perfDeckCount: e.perfDeck.length,
		kanbanDeckCount: e.kanbanDeck.length,
		factory: e.factory.map((e) => ({ ...e })),
		awardSpeech: [...e.awardSpeech],
		tableGoals: [...e.tableGoals],
		finalGoal: e.finalGoal,
		chargerSupply: e.chargerSupply,
		sandra: {
			dept: e.sandra.dept,
			desk: e.sandra.desk,
			station: e.sandra.station
		},
		current: i,
		work: e.work ? { ...e.work } : null,
		branch: e.branch && a && a.kind === "advance" ? {
			pos: a.pos,
			options: T[a.pos].map((e) => "to" in e ? {
				to: e.to,
				exit: null
			} : {
				to: null,
				exit: e.exit
			})
		} : null,
		prompt: e.prompts[0] ?? null,
		meeting: e.meeting ? {
			current: e.meeting.order[e.meeting.idx],
			played: [...e.meeting.played],
			goals: e.meeting.goals.map((e) => ({
				card: e.card,
				tokens: e.tokens.map((e) => e ? { ...e } : null)
			}))
		} : null,
		contribute: e.contribute ? [...e.contribute] : null,
		finalQueue: [...e.finalQueue],
		result: e.result ? {
			scores: [...e.result.scores],
			ranking: e.result.ranking.map((e) => [...e])
		} : null
	}, s = e.prompts[0];
	return {
		public: o,
		private: {
			seat: n,
			perfHand: r ? [...r.perfHand] : [],
			kanbanHand: r ? [...r.kanbanHand] : [],
			awardOptions: s?.kind === "award" && s.seat === n ? [...e.awardStacks[s.dept]] : null
		}
	};
}
function tt(e) {
	if (e.phase !== "over" || !e.result) return { phase: e.phase };
	let t = e.result.ranking.flat().map((t) => e.players[t].rid);
	return {
		phase: "over",
		winner: e.result.ranking[0].map((t) => e.players[t].rid),
		ranking: t,
		scores: Object.fromEntries(e.players.map((t, n) => [t.rid, e.result.scores[n]]))
	};
}
var nt = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: V,
	schemas: {
		action: ae,
		publicView: le,
		privateView: ue,
		config: oe
	},
	setup: Se,
	reduce: Ze,
	viewFor: et,
	status: tt
}, rt = [
	"games.kanban.model0",
	"games.kanban.model1",
	"games.kanban.model2",
	"games.kanban.model3",
	"games.kanban.model4"
], it = [
	"city",
	"suv",
	"truck",
	"sport",
	"concept"
], at = [
	"games.kanban.part0",
	"games.kanban.part1",
	"games.kanban.part2",
	"games.kanban.part3",
	"games.kanban.part4",
	"games.kanban.part5"
], ot = [
	"AP",
	"BT",
	"BD",
	"DT",
	"EC",
	"MT"
], st = [
	"games.kanban.dept0",
	"games.kanban.dept1",
	"games.kanban.dept2",
	"games.kanban.dept3",
	"games.kanban.dept4"
];
function ct({ model: e, className: t = "" }) {
	return /* @__PURE__ */ m("img", {
		className: t,
		src: `./games/kanban/car-${it[e]}.webp`,
		alt: "",
		draggable: !1
	});
}
function lt({ title: e, count: t }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-section-title",
		children: [/* @__PURE__ */ m("strong", { children: e }), t !== void 0 && /* @__PURE__ */ m("span", { children: t })]
	});
}
function ut({ pub: e, t, onClaim: n }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-track",
		children: [
			/* @__PURE__ */ h("div", {
				className: "kb-track__top",
				children: [/* @__PURE__ */ m("span", { children: t("games.kanban.testTrack") }), /* @__PURE__ */ m("b", { children: e.testQueue.length.toString().padStart(2, "0") })]
			}),
			/* @__PURE__ */ m("div", {
				className: "kb-track__ring",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-track__cars",
				children: [e.testQueue.map((e, r) => {
					let i = /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(ct, { model: e }), /* @__PURE__ */ h("span", { children: [t(rt[e]), /* @__PURE__ */ m("b", { children: k[r] })] })] });
					return n ? /* @__PURE__ */ m("button", {
						className: "kb-track__car",
						type: "button",
						onClick: () => n(r),
						"aria-label": `${t(rt[e])} · ${k[r]}`,
						children: i
					}, `${r}-${e}`) : /* @__PURE__ */ m("div", {
						className: "kb-track__car",
						children: i
					}, `${r}-${e}`);
				}), e.testQueue.length === 0 && /* @__PURE__ */ m("span", {
					className: "kb-track__empty",
					children: t("games.kanban.uiTestEmpty")
				})]
			}),
			/* @__PURE__ */ h("span", {
				className: "kb-track__pace",
				children: [
					t("games.kanban.paceCar"),
					" ",
					e.pace + 1,
					"/",
					ee(e.players.length)
				]
			})
		]
	});
}
function dt({ pub: e, me: t, t: n, selectedPart: r, onPart: i, canPick: a }) {
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(lt, {
		title: n("games.kanban.warehouses"),
		count: e.warehouses.reduce((e, t) => e + t, 0)
	}), /* @__PURE__ */ m("div", {
		className: "kb-warehouse",
		children: e.warehouses.map((e, o) => {
			let s = t ? t.parts.includes(o) || t.vouchers > 0 : !1;
			return i ? /* @__PURE__ */ h("button", {
				type: "button",
				className: `kb-part ${r === o ? "is-selected" : ""}`,
				disabled: !s || (a ? !a(o) : !1),
				onClick: () => i(o),
				children: [/* @__PURE__ */ m("b", { children: ot[o] }), /* @__PURE__ */ h("span", { children: [n(at[o]), /* @__PURE__ */ m("small", { children: n("games.kanban.uiOwnedStock", {
					own: t?.parts.filter((e) => e === o).length ?? 0,
					stock: e
				}) })] })]
			}, o) : /* @__PURE__ */ h("div", {
				className: "kb-part",
				children: [/* @__PURE__ */ m("b", { children: ot[o] }), /* @__PURE__ */ h("span", { children: [n(at[o]), /* @__PURE__ */ h("small", { children: ["× ", e] })] })]
			}, o);
		})
	})] });
}
function ft({ pub: e, me: t, t: n, selectedModel: r, selectedPart: i, selectedSource: a, onModel: o, onPart: s, onSource: c }) {
	let l = r === void 0 || e.config.speedcharger && t?.chargeRows[1] ? [] : e.upgrades[r].filter((t) => t !== null && !e.asmParts[r].includes(t));
	return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--assembly",
		children: [
			/* @__PURE__ */ m(ut, {
				pub: e,
				t: n
			}),
			/* @__PURE__ */ m(lt, {
				title: n("games.kanban.uiAssemblyLanes"),
				count: E.length
			}),
			/* @__PURE__ */ m("div", {
				className: "kb-lanes",
				children: E.map((t, i) => {
					let a = e.asmParts[t], s = Object.entries(e.cars).filter(([, e]) => e === t).map(([e]) => e), c = a.length >= w[t], l = /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ h("span", {
							className: "kb-lane__name",
							children: [/* @__PURE__ */ h("small", { children: [
								String(i + 1).padStart(2, "0"),
								" / ",
								n(rt[t])
							] }), /* @__PURE__ */ m("strong", { children: n(rt[t]) })]
						}),
						/* @__PURE__ */ m(ct, {
							model: t,
							className: "kb-lane__car"
						}),
						/* @__PURE__ */ m("span", {
							className: "kb-lane__slots",
							children: Array.from({ length: w[t] }, (e, t) => /* @__PURE__ */ m("i", {
								className: a[t] === void 0 ? "" : "is-filled",
								children: a[t] === void 0 ? "+" : ot[a[t]]
							}, t))
						}),
						/* @__PURE__ */ m("b", {
							className: "kb-lane__position",
							children: s.join("·") || "—"
						})
					] });
					return o ? /* @__PURE__ */ m("button", {
						type: "button",
						className: `kb-lane ${r === t ? "is-selected" : ""}`,
						disabled: c,
						onClick: () => o(t),
						"aria-label": `${n(rt[t])} ${n("games.kanban.assemblySlots", {
							n: a.length,
							cap: w[t]
						})}`,
						children: l
					}, t) : /* @__PURE__ */ m("div", {
						className: "kb-lane",
						children: l
					}, t);
				})
			}),
			l.length > 0 && /* @__PURE__ */ h("p", {
				className: "kb-scene-note",
				children: [
					n("games.kanban.errUpgradeFirst"),
					": ",
					l.map((e) => n(at[e])).join(" · ")
				]
			}),
			/* @__PURE__ */ m(dt, {
				pub: e,
				me: t,
				t: n,
				selectedPart: i,
				onPart: s,
				canPick: (t) => r === void 0 || e.asmParts[r].length < w[r] && !e.asmParts[r].includes(t) && (l.length === 0 || l.includes(t))
			}),
			c && i !== void 0 && /* @__PURE__ */ h("div", {
				className: "kb-source-row",
				children: [/* @__PURE__ */ m("button", {
					type: "button",
					disabled: !t?.parts.includes(i),
					className: a === "part" ? "is-selected" : "",
					onClick: () => c("part"),
					children: n("games.kanban.srcPart")
				}), /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !t?.vouchers,
					className: a === "voucher" ? "is-selected" : "",
					onClick: () => c("voucher"),
					children: [
						n("games.kanban.srcVoucher"),
						" · ",
						t?.vouchers ?? 0
					]
				})]
			})
		]
	});
}
function pt({ pub: e, me: t, t: n, onClaim: r, onUpgrade: i }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--research",
		children: [
			/* @__PURE__ */ m(ut, {
				pub: e,
				t: n,
				onClaim: r
			}),
			/* @__PURE__ */ m(lt, {
				title: n("games.kanban.upgradesTitle"),
				count: t?.designs.filter((e) => e % 7 != 0).length ?? 0
			}),
			/* @__PURE__ */ m("div", {
				className: "kb-rd-grid",
				children: rt.map((t, r) => /* @__PURE__ */ h("div", {
					className: "kb-rd-model",
					children: [
						/* @__PURE__ */ m(ct, { model: r }),
						/* @__PURE__ */ m("strong", { children: n(t) }),
						/* @__PURE__ */ m("span", { children: e.upgrades[r].map((e, t) => /* @__PURE__ */ m("i", {
							className: e === null ? "" : "is-filled",
							children: e === null ? "+" : ot[e]
						}, t)) })
					]
				}, t))
			}),
			i && /* @__PURE__ */ h("button", {
				className: "kb-scene-link",
				type: "button",
				onClick: i,
				children: [n("games.kanban.upgrade"), " ›"]
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-metric-row",
				children: [/* @__PURE__ */ h("span", { children: [
					n("games.kanban.pickGarage"),
					" ",
					/* @__PURE__ */ h("b", { children: [t?.garages.filter((e) => e === null).length ?? 0, "/5"] })
				] }), /* @__PURE__ */ m("span", { children: n("games.kanban.shiftsLeft", { n: e.work?.shiftsLeft ?? 0 }) })]
			})
		]
	});
}
function mt({ pub: e, me: t, priv: n, t: r, onKanban: i }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--logistics",
		children: [
			/* @__PURE__ */ m(dt, {
				pub: e,
				me: t,
				t: r
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-conveyor",
				children: [
					/* @__PURE__ */ m("span", { children: r("games.kanban.warehouses") }),
					/* @__PURE__ */ m("i", {}),
					/* @__PURE__ */ m("b", { children: "❯ ❯ ❯" }),
					/* @__PURE__ */ m("i", {}),
					/* @__PURE__ */ m("span", { children: r("games.kanban.dept1") })
				]
			}),
			/* @__PURE__ */ m(lt, {
				title: r("games.kanban.kanbanPlay"),
				count: n?.kanbanHand.length ?? 0
			}),
			/* @__PURE__ */ m("div", {
				className: "kb-card-row",
				children: (n?.kanbanHand ?? []).map((e) => /* @__PURE__ */ h("button", {
					className: "kb-kanban-card",
					type: "button",
					disabled: !i,
					onClick: i,
					children: [
						/* @__PURE__ */ h("small", { children: ["#", String(e + 1).padStart(2, "0")] }),
						/* @__PURE__ */ m("strong", { children: F[e].slice(0, 4).map((e) => ot[e]).join(" · ") }),
						/* @__PURE__ */ m("span", { children: F[e].slice(4, 6).map((e) => ot[e]).join(" · ") })
					]
				}, e))
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-metric-row",
				children: [
					/* @__PURE__ */ h("span", { children: [
						r("games.kanban.partsHave"),
						" ",
						/* @__PURE__ */ m("b", { children: t?.parts.length ?? 0 })
					] }),
					/* @__PURE__ */ m("span", { children: r("games.kanban.vouchersHave", { n: t?.vouchers ?? 0 }) }),
					/* @__PURE__ */ h("span", { children: [
						r("games.kanban.recycleBin"),
						" ",
						/* @__PURE__ */ m("b", { children: e.recycle.length })
					] })
				]
			})
		]
	});
}
function ht({ pub: e, me: t, t: n, onTake: r }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--design",
		children: [
			/* @__PURE__ */ h("div", {
				className: "kb-design-hero",
				children: [/* @__PURE__ */ m("span", { children: "35" }), /* @__PURE__ */ h("div", { children: [
					/* @__PURE__ */ m("small", { children: n("games.kanban.dept3") }),
					/* @__PURE__ */ m("strong", { children: n("games.kanban.displayTitle") }),
					/* @__PURE__ */ h("em", { children: [
						n("games.kanban.designsHave"),
						": ",
						t?.designs.length ?? 0
					] })
				] })]
			}),
			/* @__PURE__ */ m(lt, {
				title: n("games.kanban.displayTitle"),
				count: e.display.flat().filter((e) => e !== null).length
			}),
			/* @__PURE__ */ m("div", {
				className: "kb-design-display",
				children: e.display.map((e, t) => /* @__PURE__ */ m("div", {
					className: "kb-design-row",
					children: e.map((e, i) => {
						let a = e === null ? "—" : /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m("small", { children: n(rt[R(e)]) }), /* @__PURE__ */ m("strong", { children: e % 7 == 0 ? "BASE" : ot[e % 7 - 1] })] });
						return r ? /* @__PURE__ */ m("button", {
							type: "button",
							disabled: e === null,
							onClick: () => r(t, i),
							className: "kb-design-tile",
							children: a
						}, i) : /* @__PURE__ */ m("div", {
							className: "kb-design-tile",
							children: a
						}, i);
					})
				}, t))
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-metric-row",
				children: [
					/* @__PURE__ */ h("span", { children: [
						n("games.kanban.stackFirstTop"),
						" ",
						/* @__PURE__ */ m("b", { children: e.stackCounts.firstTop })
					] }),
					/* @__PURE__ */ h("span", { children: [
						n("games.kanban.stackFirstBottom"),
						" ",
						/* @__PURE__ */ m("b", { children: e.stackCounts.firstBottom })
					] }),
					/* @__PURE__ */ h("span", { children: [
						n("games.kanban.stackCentral"),
						" ",
						/* @__PURE__ */ m("b", { children: e.stackCounts.central })
					] })
				]
			})
		]
	});
}
function gt({ pub: e, me: t, t: n, onTarget: r }) {
	return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--admin",
		children: [
			/* @__PURE__ */ h("div", {
				className: "kb-admin-hero",
				children: [/* @__PURE__ */ m("span", { children: "05" }), /* @__PURE__ */ h("div", { children: [
					/* @__PURE__ */ m("small", { children: n("games.kanban.phaseWork") }),
					/* @__PURE__ */ m("strong", { children: n("games.kanban.dept4") }),
					/* @__PURE__ */ m("em", { children: n("games.kanban.sandraAt", { dept: e.sandra.desk ? n("games.kanban.sandraDesk") : n(st[e.sandra.dept]) }) })
				] })]
			}),
			/* @__PURE__ */ m(lt, { title: n("games.kanban.adminPick") }),
			/* @__PURE__ */ m("div", {
				className: "kb-admin-grid",
				children: st.slice(0, 4).map((t, i) => /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !r || e.work?.adminTarget !== null,
					onClick: () => r?.(i),
					children: [
						/* @__PURE__ */ m("b", { children: String(i + 1).padStart(2, "0") }),
						/* @__PURE__ */ m("strong", { children: n(t) }),
						/* @__PURE__ */ m("span", { children: "❯" })
					]
				}, t))
			}),
			/* @__PURE__ */ h("div", {
				className: "kb-metric-row",
				children: [/* @__PURE__ */ m("span", { children: n("games.kanban.speechHave", {
					b: t?.speechBoard ?? 0,
					g: t?.genericBeside ?? 0
				}) }), /* @__PURE__ */ m("span", { children: n("games.kanban.bankedHave", { n: t?.banked ?? 0 }) })]
			})
		]
	});
}
function _t({ pub: e, me: t, priv: n, t: r, activeDept: i, selectedModel: a, selectedPart: o, selectedSource: s, onModel: c, onPart: l, onSource: u, onClaim: d, onUpgrade: f, onKanban: p, onTakeDesign: g, onAdminTarget: _ }) {
	if (e.phase === "work") switch (i) {
		case 0: return /* @__PURE__ */ m(pt, {
			pub: e,
			me: t,
			t: r,
			onClaim: d,
			onUpgrade: f
		});
		case 1: return /* @__PURE__ */ m(ft, {
			pub: e,
			me: t,
			t: r,
			selectedModel: a,
			selectedPart: o,
			selectedSource: s,
			onModel: c,
			onPart: l,
			onSource: u
		});
		case 2: return /* @__PURE__ */ m(mt, {
			pub: e,
			me: t,
			priv: n,
			t: r,
			onKanban: p
		});
		case 3: return /* @__PURE__ */ m(ht, {
			pub: e,
			me: t,
			t: r,
			onTake: g
		});
		case 4: return /* @__PURE__ */ m(gt, {
			pub: e,
			me: t,
			t: r,
			onTarget: _
		});
	}
	if (e.phase === "select") return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--route",
		children: [/* @__PURE__ */ h("div", {
			className: "kb-route-hero",
			children: [/* @__PURE__ */ m("b", { children: String(e.day).padStart(2, "0") }), /* @__PURE__ */ h("span", { children: [r("games.kanban.selectDeptTitle"), /* @__PURE__ */ m("small", { children: r("games.kanban.mustMoveHint") })] })]
		}), /* @__PURE__ */ m("div", {
			className: "kb-route-line",
			children: st.map((e, n) => /* @__PURE__ */ h("span", {
				className: t?.dept === n ? "is-current" : "",
				children: [/* @__PURE__ */ m("b", { children: String(n + 1).padStart(2, "0") }), r(e)]
			}, e))
		})]
	});
	if (e.phase === "inductTake") return /* @__PURE__ */ h("div", {
		className: "kb-scene",
		children: [/* @__PURE__ */ m(dt, {
			pub: e,
			me: t,
			t: r
		}), /* @__PURE__ */ h("div", {
			className: "kb-metric-row",
			children: [/* @__PURE__ */ h("span", { children: [
				r("games.kanban.displayTitle"),
				" ",
				/* @__PURE__ */ m("b", { children: e.display.flat().filter((e) => e !== null).length })
			] }), /* @__PURE__ */ h("span", { children: [
				r("games.kanban.stackCentral"),
				" ",
				/* @__PURE__ */ m("b", { children: e.stackCounts.central })
			] })]
		})]
	});
	if (e.phase === "inductCert") return /* @__PURE__ */ h("div", {
		className: "kb-scene kb-scene--induct",
		children: [/* @__PURE__ */ h("div", {
			className: "kb-cert-hero",
			children: [/* @__PURE__ */ m("span", { children: "01" }), /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: "KANBAN EV" }), /* @__PURE__ */ m("strong", { children: r("games.kanban.phaseInductCert") })] })]
		}), /* @__PURE__ */ m("div", {
			className: "kb-cert-route",
			children: st.map((e, t) => /* @__PURE__ */ h("span", { children: [/* @__PURE__ */ m("b", { children: String(t + 1).padStart(2, "0") }), r(e)] }, e))
		})]
	});
	if (e.phase === "specialGarage") return /* @__PURE__ */ m("div", {
		className: "kb-scene kb-scene--special",
		children: /* @__PURE__ */ h("div", {
			className: "kb-special-hero",
			children: [/* @__PURE__ */ m("b", { children: "05" }), /* @__PURE__ */ h("span", { children: [r("games.kanban.phaseSpecialGarage"), /* @__PURE__ */ m("small", { children: r("games.kanban.garageN", { n: 5 }) })] })]
		})
	});
	if (e.phase === "meeting" || e.phase === "meetingContribute") {
		let n = e.meeting?.goals.map((e) => e.card) ?? e.tableGoals;
		return /* @__PURE__ */ h("div", {
			className: "kb-scene kb-scene--meeting",
			children: [/* @__PURE__ */ h("div", {
				className: "kb-meeting-hero",
				children: [
					/* @__PURE__ */ m("small", { children: r("games.kanban.meetingTitle") }),
					/* @__PURE__ */ m("strong", { children: n.length }),
					/* @__PURE__ */ m("span", { children: r("games.kanban.speechHave", {
						b: t?.speechBoard ?? 0,
						g: t?.genericBeside ?? 0
					}) })
				]
			}), /* @__PURE__ */ m("div", {
				className: "kb-meeting-line",
				children: n.map((e, t) => /* @__PURE__ */ h("span", { children: [
					String(t + 1).padStart(2, "0"),
					" / ",
					e + 1
				] }, `${e}-${t}`))
			})]
		});
	}
	return e.phase === "finalGoals" ? /* @__PURE__ */ m("div", {
		className: "kb-scene kb-scene--final",
		children: /* @__PURE__ */ h("div", {
			className: "kb-final-hero",
			children: [
				/* @__PURE__ */ m("small", { children: r("games.kanban.finalTitle") }),
				/* @__PURE__ */ h("strong", { children: [t?.pp ?? 0, /* @__PURE__ */ m("em", { children: "PP" })] }),
				/* @__PURE__ */ m("span", { children: r("games.kanban.speechHave", {
					b: t?.speechBoard ?? 0,
					g: t?.genericBeside ?? 0
				}) })
			]
		})
	}) : /* @__PURE__ */ m(ft, {
		pub: e,
		me: t,
		t: r
	});
}
//#endregion
//#region src/games/kanban/view-player.tsx
var vt = "(orientation: landscape) and (min-width: 900px) and (min-height: 550px)", yt = () => window.matchMedia(vt).matches;
function bt(e) {
	let t = window.matchMedia(vt);
	return t.addEventListener("change", e), () => t.removeEventListener("change", e);
}
var X = [
	"games.kanban.dept0",
	"games.kanban.dept1",
	"games.kanban.dept2",
	"games.kanban.dept3",
	"games.kanban.dept4"
], Z = [
	"games.kanban.model0",
	"games.kanban.model1",
	"games.kanban.model2",
	"games.kanban.model3",
	"games.kanban.model4"
], Q = [
	"games.kanban.part0",
	"games.kanban.part1",
	"games.kanban.part2",
	"games.kanban.part3",
	"games.kanban.part4",
	"games.kanban.part5"
], xt = [
	"games.kanban.award0",
	"games.kanban.award1",
	"games.kanban.award2",
	"games.kanban.award3"
], St = [
	"games.kanban.sgName0",
	"games.kanban.sgName1",
	"games.kanban.sgName2",
	"games.kanban.sgName3",
	"games.kanban.sgName4",
	"games.kanban.sgName5",
	"games.kanban.sgName6"
], Ct = [
	"games.kanban.sgDesc0",
	"games.kanban.sgDesc1",
	"games.kanban.sgDesc2",
	"games.kanban.sgDesc3",
	"games.kanban.sgDesc4",
	"games.kanban.sgDesc5",
	"games.kanban.sgDesc6"
], wt = [
	"games.kanban.gtBasic0",
	"games.kanban.gtBasic1",
	"games.kanban.gtBasic2",
	"games.kanban.gtBasic3",
	"games.kanban.gtBasic4"
], Tt = [
	"games.kanban.gtExpert0",
	"games.kanban.gtExpert1",
	"games.kanban.gtExpert2",
	"games.kanban.gtExpert3",
	"games.kanban.gtExpert4"
];
function Et(e, t) {
	switch (t.t) {
		case "cars": return e("games.kanban.perfCars");
		case "models": return e("games.kanban.perfModels");
		case "modelCars": return e("games.kanban.perfModelCars", { model: e(Z[t.m]) });
		case "partUpgrades": return e("games.kanban.perfPartUpgrades", { part: e(Q[t.p]) });
		case "upgrades": return e("games.kanban.perfUpgrades");
		case "tested": return e("games.kanban.perfTested");
		case "parts2": return e("games.kanban.perfParts2", {
			a: e(Q[t.ps[0]]),
			b: e(Q[t.ps[1]])
		});
		case "garagePair": return e("games.kanban.perfGaragePair", {
			a: t.g[0] + 1,
			b: t.g[1] + 1
		});
		case "cert": return e("games.kanban.perfCert", { dept: e(X[t.d]) });
		case "designs": return e("games.kanban.perfDesigns");
		case "books": return e("games.kanban.perfBooks");
		case "certs": return e("games.kanban.perfCerts");
		case "vouchers": return e("games.kanban.perfVouchers");
		case "banked": return e("games.kanban.perfBanked");
		case "speech": return e("games.kanban.perfSpeech");
		case "chargers": return e("games.kanban.perfChargers");
		case "chargerRow": return e("games.kanban.perfChargerRow", { n: t.row + 1 });
	}
}
function Dt(e, t) {
	switch (t.t) {
		case "sameModelCars": return e("games.kanban.finSameModelCars", { n: t.n });
		case "cars": return e("games.kanban.finCars", { n: t.n });
		case "distinctModels": return e("games.kanban.finDistinctModels", { n: t.n });
		case "modelCars": return e("games.kanban.finModelCars", {
			n: t.n,
			model: e(Z[t.m])
		});
		case "distinctPartUpgrades": return e("games.kanban.finDistinctPartUpgrades", { n: t.n });
		case "samePartUpgrades": return e("games.kanban.finSamePartUpgrades", { n: t.n });
		case "partUpgrades": return e("games.kanban.finPartUpgrades", {
			n: t.n,
			part: e(Q[t.p])
		});
		case "upgrades": return e("games.kanban.finUpgrades", { n: t.n });
		case "tested": return e("games.kanban.finTested", { n: t.n });
		case "testedParts": return e("games.kanban.finTestedParts", { n: t.n });
		case "certs": return e("games.kanban.finCerts", { n: t.n });
		case "certsMax": return e("games.kanban.finCertsMax", { n: t.n });
		case "certPair": return t.ds[0] === t.ds[1] ? e("games.kanban.finCertOne", { a: e(X[t.ds[0]]) }) : e("games.kanban.finCertPair", {
			a: e(X[t.ds[0]]),
			b: e(X[t.ds[1]])
		});
		case "banked": return e("games.kanban.finBanked", { n: t.n });
		case "books": return e("games.kanban.finBooks", { n: t.n });
		case "vouchers": return e("games.kanban.finVouchers", { n: t.n });
		case "experts": return e("games.kanban.finExperts", { n: t.n });
		case "expertsMax": return e("games.kanban.finExpertsMax", { n: t.n });
		case "chargers": return e("games.kanban.finChargers", { n: t.n });
		case "chargerRow": return e("games.kanban.finChargerRow", { n: t.row + 1 });
		case "speechBoard": return e("games.kanban.finSpeechBoard", { n: t.n });
	}
}
function Ot(e, t) {
	let n = [];
	return t.pp && n.push(`${t.pp} PP`), t.bank && n.push(e("games.kanban.bankedHave", { n: t.bank })), t.book && n.push(e("games.kanban.booksHave", { n: t.book })), t.voucher && n.push(e("games.kanban.vouchersHave", { n: t.voucher })), t.speech && n.push(e("games.kanban.gtBasic0")), n.join(" + ");
}
function kt(e, t) {
	let n = z(t);
	return n === null ? e("games.kanban.designBase", { model: e(Z[R(t)]) }) : e("games.kanban.designOf", {
		model: e(Z[R(t)]),
		part: e(Q[n])
	});
}
var At = {
	inductCert: "games.kanban.phaseInductCert",
	inductTake: "games.kanban.phaseInductTake",
	specialGarage: "games.kanban.phaseSpecialGarage",
	select: "games.kanban.phaseSelect",
	work: "games.kanban.phaseWork",
	meeting: "games.kanban.phaseMeeting",
	meetingContribute: "games.kanban.phaseContribute",
	finalGoals: "games.kanban.phaseFinalGoals",
	over: "games.kanban.phaseOver"
};
function jt(e) {
	let t = e.public;
	return /* @__PURE__ */ m(Mt, {
		pub: t,
		priv: e.private,
		members: e.members,
		send: e.send
	}, `${t.phase}:${t.current}:${t.branch?.pos ?? ""}`);
}
function Mt({ pub: e, priv: t, members: n, send: r }) {
	let i = l(), a = c((e) => e.locale), [g, _] = o(null), [v, y] = o({}), [b, x] = o([]), S = s(bt, yt, () => !1), [C, T] = o({}), E = t?.seat ?? -1, D = E >= 0 ? e.players[E] : null, O = e.phase !== "over" && e.current === E, k = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? f(t, a) : e;
	}, A = (e) => u[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % u.length].hex, j = (e, t) => y((n) => ({
		...n,
		[e]: t
	})), M = (e) => {
		_(e), y({});
	}, N = (e) => {
		r(e), _(null), y({});
	}, F = i(At[e.phase]), te = e.current === null ? null : k(e.players[e.current].rid), ne = e.config.expertTuning ? Tt : wt, I = e.phase === "work" ? (D?.dept === 4 && e.work?.adminTarget !== null ? e.work?.adminTarget : D?.dept) ?? null : null, R = O && e.prompt?.seat !== E, z = e.branch?.options[v.branchIdx], B = v.dept, V = v.station, H, U = i("games.kanban.confirm"), W = F;
	if (e.branch && R) W = z ? z.exit === null ? `→ ${z.to}` : i("games.kanban.branchExit", { n: z.exit }) : i("games.kanban.branch"), z && (H = () => N({
		type: "carMove",
		to: z.to,
		exit: z.exit
	}));
	else if (e.phase === "meetingContribute" && e.contribute && !e.contribute[E]) {
		let e = v.contributeCard;
		W = e === void 0 ? i("games.kanban.contribute") : `${L[e].pp} PP × ${Et(i, L[e].kind)}`, e !== void 0 && t?.perfHand.includes(e) && (H = () => N({
			type: "meetContribute",
			cardId: e
		}));
	} else if (R) switch (e.phase) {
		case "inductCert": {
			let e = v.certSpace;
			W = e === void 0 ? F : Ot(i, P[0][e]) || i("games.kanban.certEmpty"), e !== void 0 && (H = () => N({
				type: "inductCert",
				space: e
			}));
			break;
		}
		case "inductTake": {
			let e = v.part, t = v.design;
			W = i(e === void 0 ? "games.kanban.pickPart" : Q[e]), e !== void 0 && t !== void 0 && (H = () => N({
				type: "inductTake",
				part: e,
				design: t
			}));
			break;
		}
		case "specialGarage": {
			let e = v.specialTile;
			W = e === void 0 ? F : i(St[e]), e !== void 0 && (H = () => N({
				type: "pickSpecialGarage",
				tile: e
			}));
			break;
		}
		case "select":
			W = B === void 0 || V === void 0 ? F : `${i(X[B])} · ${i("games.kanban.stationShifts", { n: B === 4 ? V + 1 : V + 2 })}`, B !== void 0 && V !== void 0 && (H = () => N({
				type: "selectDept",
				dept: B,
				station: V
			}));
			break;
		case "work":
			if (g === "provide" && I === 1) {
				let t = v.model, n = v.part, r = v.source;
				if (W = t === void 0 || n === void 0 ? i("games.kanban.pickPart") : `${i(Q[n])} → ${i(Z[t])}`, U = i(r === "voucher" ? "games.kanban.provideVoucher" : "games.kanban.provide"), t !== void 0 && n !== void 0 && r && D && e.work && e.work.shiftsLeft > 0) {
					let i = e.asmParts[t], a = e.upgrades[t].filter((e) => e !== null).filter((e) => !i.includes(e)), o = i.length < w[t] && !i.includes(n) && (e.config.speedcharger && D.chargeRows[1] || a.length === 0 || a.includes(n)), s = r === "part" ? D.parts.includes(n) : D.vouchers > 0;
					o && s && (H = () => N({
						type: "providePart",
						model: t,
						part: n,
						source: r
					}));
				}
			} else W = i("games.kanban.shiftsLeft", { n: e.work?.shiftsLeft ?? 0 }), U = i("games.kanban.endTurn"), H = () => N({ type: "endWork" });
			break;
		case "meeting":
			W = i("games.kanban.meetingTitle"), U = i("games.kanban.meetPass"), e.meeting?.played[E] && (H = () => N({ type: "meetPass" }));
			break;
		case "finalGoals": W = `${b.length} / ${(D?.speechBoard ?? 0) + (D?.genericBeside ?? 0)}`, U = i("games.kanban.finalClaim"), b.length <= (D?.speechBoard ?? 0) + (D?.genericBeside ?? 0) && (H = () => {
			N({
				type: "claimFinal",
				achievements: b
			}), x([]);
		});
	}
	return /* @__PURE__ */ m("div", {
		className: "kb-ui",
		children: /* @__PURE__ */ m(d, {
			adaptive: !0,
			scroll: !1,
			className: "kb-game",
			banner: /* @__PURE__ */ h("div", {
				className: "kb-head",
				children: [
					/* @__PURE__ */ h("div", {
						className: "kb-head__brand",
						children: [/* @__PURE__ */ h("strong", { children: ["KANBAN", /* @__PURE__ */ m("span", { children: " EV" })] }), /* @__PURE__ */ m("small", { children: "SMART FACTORY" })]
					}),
					/* @__PURE__ */ h("div", {
						className: "kb-head__score",
						children: [/* @__PURE__ */ m("small", { children: D ? k(D.rid) : "KANBAN EV" }), /* @__PURE__ */ h("strong", { children: [
							D?.pp ?? 0,
							" ",
							/* @__PURE__ */ m("em", { children: "PP" })
						] })]
					}),
					/* @__PURE__ */ h("div", {
						className: "kb-head__meta",
						children: [
							/* @__PURE__ */ h("span", { children: ["DAY ", /* @__PURE__ */ m("b", { children: String(e.day).padStart(2, "0") })] }),
							/* @__PURE__ */ m("i", {}),
							/* @__PURE__ */ h("span", { children: ["WEEK ", /* @__PURE__ */ m("b", { children: String(e.week).padStart(2, "0") })] }),
							/* @__PURE__ */ m("i", {}),
							/* @__PURE__ */ h("span", { children: ["SHIFT ", /* @__PURE__ */ m("b", { children: e.work?.shiftsLeft ?? "—" })] }),
							/* @__PURE__ */ m("i", {}),
							/* @__PURE__ */ h("span", { children: ["PACE ", /* @__PURE__ */ h("b", { children: [
								e.pace + 1,
								"/",
								ee(e.players.length)
							] })] })
						]
					}),
					/* @__PURE__ */ h("div", {
						className: "kb-head__phase",
						children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: i("games.kanban.cycle", { n: e.cycle }) }), /* @__PURE__ */ m("strong", { children: e.phase === "work" && I !== null ? i(X[I]) : F })] }), /* @__PURE__ */ m("span", {
							className: O ? "is-turn" : "",
							children: e.current === null ? i("games.kanban.turnSandra") : O ? i("games.kanban.turnYou") : i("games.kanban.turnWait", { name: te ?? "" })
						})]
					})
				]
			}),
			actionsHeight: "kb-actions-slot",
			actions: /* @__PURE__ */ h("div", {
				className: "kb-footer",
				children: [/* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("small", { children: F }), /* @__PURE__ */ m("strong", { children: W })] }), /* @__PURE__ */ h("button", {
					type: "button",
					disabled: !H,
					onClick: H,
					children: [U, /* @__PURE__ */ m("b", { children: "❯❯" })]
				})]
			}),
			overlay: /* @__PURE__ */ h(p, { children: [e.meetingPending && /* @__PURE__ */ m("div", {
				className: "kb-alert",
				children: i("games.kanban.meetingSoon")
			}), (e.prompt?.seat === E || e.branch && O) && /* @__PURE__ */ m(Nt, {
				pub: e,
				priv: t,
				seat: E,
				t: i,
				sel: v,
				pick: j,
				send: r
			})] }),
			children: /* @__PURE__ */ h("div", {
				className: "kb-scroll",
				children: [/* @__PURE__ */ h("div", {
					className: "kb-player-strip",
					children: [e.players.map((e) => /* @__PURE__ */ h("div", {
						className: "plate px-2 py-1 text-xs",
						style: e.seat === E ? { outline: `2px solid ${A(e.rid)}` } : void 0,
						children: [
							/* @__PURE__ */ m("span", {
								className: "kb-player-name font-bold",
								title: k(e.rid),
								style: { color: A(e.rid) },
								children: k(e.rid)
							}),
							/* @__PURE__ */ h("span", {
								className: "kb-player-points ml-1 font-mono tabular-nums",
								children: [e.pp, " PP"]
							}),
							e.dept !== null && /* @__PURE__ */ m("span", {
								className: "kb-player-dept ml-1 opacity-70",
								children: i(X[e.dept])
							}),
							/* @__PURE__ */ h("span", {
								className: "kb-player-resources ml-1 opacity-70",
								children: [
									i("games.kanban.bankedHave", { n: e.banked }),
									" · ",
									i("games.kanban.booksHave", { n: e.books }),
									" · ",
									i("games.kanban.vouchersHave", { n: e.vouchers })
								]
							})
						]
					}, e.seat)), /* @__PURE__ */ m("div", {
						className: "plate px-2 py-1 text-xs opacity-80",
						children: i("games.kanban.sandraAt", { dept: e.sandra.desk ? i("games.kanban.sandraDesk") : i(X[e.sandra.dept]) })
					})]
				}), /* @__PURE__ */ h("div", {
					className: "kb-workspace",
					children: [/* @__PURE__ */ h("div", {
						className: "kb-floor",
						children: [/* @__PURE__ */ m("div", {
							className: "kb-scene-block",
							children: /* @__PURE__ */ m(_t, {
								pub: e,
								me: D,
								priv: t,
								t: i,
								activeDept: I,
								selectedModel: v.model,
								selectedPart: v.part,
								selectedSource: v.source,
								onModel: R && I === 1 ? (e) => {
									g === "provide" ? j("model", e) : (_("provide"), y({ model: e }));
								} : void 0,
								onPart: R && I === 1 ? (e) => {
									_("provide"), y((t) => ({
										...g === "provide" ? t : {},
										part: e,
										source: D?.parts.includes(e) ? "part" : "voucher"
									}));
								} : void 0,
								onSource: R && I === 1 ? (e) => j("source", e) : void 0,
								onClaim: R && I === 0 ? (e) => {
									_("claim"), y({ trackIdx: e });
								} : void 0,
								onUpgrade: R && I === 0 ? () => M("upgrade") : void 0,
								onKanban: R && I === 2 ? () => M("kanban") : void 0,
								onTakeDesign: R && I === 3 && (e.work?.shiftsLeft ?? 0) > 0 && D && D.designs.length < 3 + +!!D.certs[3] ? (e, t) => r({
									type: "takeDesign",
									row: e,
									col: t
								}) : void 0,
								onAdminTarget: R && I === 4 ? (e) => r({
									type: "adminTarget",
									dept: e
								}) : void 0
							})
						}), /* @__PURE__ */ h("details", {
							className: "kb-details kb-factory-details",
							open: C.factory ?? S,
							children: [/* @__PURE__ */ h("summary", {
								onClick: (e) => {
									e.preventDefault(), T((e) => ({
										...e,
										factory: !(e.factory ?? S)
									}));
								},
								children: [
									i("games.kanban.myBoard"),
									" / ",
									i("games.kanban.warehouses"),
									" ",
									/* @__PURE__ */ m("span", { children: "＋" })
								]
							}), /* @__PURE__ */ m(Ft, {
								pub: e,
								t: i
							})]
						})]
					}), /* @__PURE__ */ h("div", {
						className: "kb-console",
						children: [/* @__PURE__ */ h("div", {
							className: "kb-decisions",
							children: [
								O && e.phase === "inductCert" && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [
										/* @__PURE__ */ m("div", {
											className: "section-label",
											children: i("games.kanban.phaseInductCert")
										}),
										/* @__PURE__ */ m("div", {
											className: "mb-1 text-xs opacity-70",
											children: i("games.kanban.certOrderHint")
										}),
										/* @__PURE__ */ m("div", {
											className: "kb-cert-options",
											children: P[0].map((t, n) => {
												let r = e.players.some((e) => e.certSection === 0 && e.certSpace === n);
												return /* @__PURE__ */ m("button", {
													type: "button",
													className: "btn-base min-h-11 px-3 text-xs",
													disabled: r,
													"aria-pressed": v.certSpace === n,
													onClick: () => j("certSpace", n),
													children: Ot(i, t) || i("games.kanban.certEmpty")
												}, n);
											})
										})
									]
								}),
								O && e.phase === "inductTake" && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [
										/* @__PURE__ */ m("div", {
											className: "section-label",
											children: i("games.kanban.phaseInductTake")
										}),
										/* @__PURE__ */ m("div", {
											className: "mb-1 text-xs",
											children: i("games.kanban.pickPart")
										}),
										/* @__PURE__ */ m("div", {
											className: "mb-2 flex flex-wrap gap-2",
											children: Q.map((t, n) => /* @__PURE__ */ h("button", {
												type: "button",
												className: "btn-base min-h-11 px-3 text-xs",
												disabled: e.warehouses[n] <= 0,
												style: v.part === n ? { outline: "2px solid currentColor" } : void 0,
												onClick: () => j("part", n),
												children: [
													i(t),
													" (",
													e.warehouses[n],
													")"
												]
											}, t))
										}),
										/* @__PURE__ */ m("div", {
											className: "mb-1 text-xs",
											children: i("games.kanban.pickDesign")
										}),
										/* @__PURE__ */ m(Pt, {
											pub: e,
											t: i,
											sel: v.design,
											onPick: (e) => j("design", e)
										})
									]
								}),
								O && e.phase === "specialGarage" && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [/* @__PURE__ */ m("div", {
										className: "section-label",
										children: i("games.kanban.phaseSpecialGarage")
									}), /* @__PURE__ */ m("div", {
										className: "kb-special-options",
										children: re.map((t, n) => {
											let r = e.players.some((e) => e.special?.tile === n), a = e.config.niceSandra && t === "immunity";
											return /* @__PURE__ */ h("button", {
												type: "button",
												className: "btn-base kb-special-option min-h-11 px-3 text-xs",
												disabled: r || a,
												"aria-pressed": v.specialTile === n,
												onClick: () => j("specialTile", n),
												children: [i(St[n]), /* @__PURE__ */ m("span", {
													className: "block opacity-70",
													children: i(Ct[n])
												})]
											}, t);
										})
									})]
								}),
								O && e.phase === "select" && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [
										/* @__PURE__ */ m("div", {
											className: "section-label",
											children: i("games.kanban.selectDeptTitle")
										}),
										/* @__PURE__ */ m("div", {
											className: "mb-1 text-xs opacity-70",
											children: i("games.kanban.mustMoveHint")
										}),
										[
											0,
											1,
											2,
											3,
											4
										].map((t) => {
											let n = e.sandra.dept === t, r = e.players.length === 2 && n, a = D?.dept === t;
											return /* @__PURE__ */ h("div", {
												className: `kb-station-row ${r || a ? "is-locked" : ""}`,
												children: [
													/* @__PURE__ */ m("b", { children: String(t + 1).padStart(2, "0") }),
													/* @__PURE__ */ h("span", { children: [i(X[t]), n && !e.sandra.desk && /* @__PURE__ */ m("small", { children: "Sandra" })] }),
													[0, 1].map((o) => {
														let s = e.players.some((e) => e.dept === t && e.station === o) || !e.sandra.desk && n && e.sandra.station === o, c = t === 4 ? o + 1 : o + 2;
														return /* @__PURE__ */ m("button", {
															type: "button",
															className: "btn-base min-h-11 px-3 text-xs",
															disabled: s || a || r,
															"aria-pressed": B === t && V === o,
															onClick: () => y({
																dept: t,
																station: o
															}),
															children: i("games.kanban.stationShifts", { n: c })
														}, o);
													})
												]
											}, t);
										})
									]
								}),
								O && e.phase === "work" && D && /* @__PURE__ */ m(It, {
									pub: e,
									me: D,
									priv: t,
									t: i,
									tool: g,
									sel: v,
									startTool: M,
									pick: j,
									fire: N,
									send: r,
									garageTileKeys: ne
								}),
								e.phase === "meeting" && e.meeting && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [
										/* @__PURE__ */ m("div", {
											className: "section-label",
											children: i("games.kanban.meetingTitle")
										}),
										e.meeting.goals.map((t, n) => {
											let a = L[t.card], o = t.tokens.some((e) => e?.seat === E), s = t.tokens.every((e) => e !== null);
											return /* @__PURE__ */ h("div", {
												className: "kb-meet-goal mb-1 flex items-center gap-2 text-xs",
												children: [
													/* @__PURE__ */ h("span", {
														className: "flex-1",
														children: [
															a.pp,
															" PP × ",
															Et(i, a.kind)
														]
													}),
													/* @__PURE__ */ m("span", {
														className: "flex gap-1",
														children: t.tokens.map((t, n) => /* @__PURE__ */ m("span", {
															className: "inline-block h-4 w-4 rounded-full border",
															style: t ? { background: t.generic ? "#94a3b8" : A(e.players[t.seat].rid) } : void 0
														}, n))
													}),
													O && !o && !s && D && D.speechBoard > 0 && /* @__PURE__ */ m("button", {
														type: "button",
														className: "btn-base min-h-11 px-3 text-xs",
														onClick: () => r({
															type: "meetSpeak",
															goalIdx: n,
															source: "board"
														}),
														children: i("games.kanban.meetSpeak")
													}),
													O && !o && !s && D?.special?.speechOn && /* @__PURE__ */ m("button", {
														type: "button",
														className: "btn-base min-h-11 px-3 text-xs",
														onClick: () => r({
															type: "meetSpeak",
															goalIdx: n,
															source: "tile"
														}),
														children: i("games.kanban.sgName6")
													})
												]
											}, n);
										}),
										O && /* @__PURE__ */ m("div", {
											className: "mt-2",
											children: /* @__PURE__ */ m("div", {
												className: "kb-perf-hand mb-1 flex flex-wrap gap-2",
												children: (t?.perfHand ?? []).map((t) => {
													let n = L[t];
													return /* @__PURE__ */ h("div", {
														className: "plate kb-perf-card p-2 text-xs",
														children: [/* @__PURE__ */ h("div", {
															className: "mb-1",
															children: [
																n.pp,
																" PP × ",
																Et(i, n.kind)
															]
														}), /* @__PURE__ */ h("div", {
															className: "flex gap-1",
															children: [/* @__PURE__ */ m("button", {
																type: "button",
																className: "btn-base min-h-11 px-2 text-xs",
																disabled: e.meeting.played[E],
																onClick: () => r({
																	type: "meetPlay",
																	cardId: t,
																	speak: !1
																}),
																children: i("games.kanban.meetPlay")
															}), /* @__PURE__ */ m("button", {
																type: "button",
																className: "btn-base min-h-11 px-2 text-xs",
																disabled: e.meeting.played[E] || D.speechBoard <= 0 && !D.special?.speechOn,
																onClick: () => r({
																	type: "meetPlay",
																	cardId: t,
																	speak: !0
																}),
																children: i("games.kanban.meetPlaySpeak")
															})]
														})]
													}, t);
												})
											})
										})
									]
								}),
								e.phase === "meetingContribute" && e.contribute && !e.contribute[E] && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [/* @__PURE__ */ m("div", {
										className: "section-label",
										children: i("games.kanban.contribute")
									}), /* @__PURE__ */ m("div", {
										className: "kb-contribute-options",
										children: (t?.perfHand ?? []).map((e) => /* @__PURE__ */ h("button", {
											type: "button",
											className: "btn-base kb-contribute-card min-h-11 px-3 text-xs",
											"aria-pressed": v.contributeCard === e,
											onClick: () => j("contributeCard", e),
											children: [
												L[e].pp,
												" PP × ",
												Et(i, L[e].kind)
											]
										}, e))
									})]
								}),
								e.phase === "meetingContribute" && e.contribute?.[E] && /* @__PURE__ */ m("div", {
									className: "plate mb-2 p-2 text-xs opacity-70",
									children: i("games.kanban.waiting")
								}),
								e.phase === "finalGoals" && /* @__PURE__ */ h("div", {
									className: "plate mb-2 p-2",
									children: [
										/* @__PURE__ */ m("div", {
											className: "section-label",
											children: i("games.kanban.finalTitle")
										}),
										ie[e.finalGoal].map((e, t) => {
											let n = D?.finalClaimed.includes(t), r = b.includes(t);
											return /* @__PURE__ */ h("div", {
												className: "kb-final-goal mb-1 flex items-center gap-2 text-xs",
												children: [
													/* @__PURE__ */ h("span", {
														className: "font-mono",
														children: [e.pp, " PP"]
													}),
													/* @__PURE__ */ m("span", {
														className: "flex-1",
														children: e.all.map((e) => Dt(i, e)).join(" + ")
													}),
													n ? /* @__PURE__ */ m("span", {
														className: "text-xs opacity-70",
														children: i("games.kanban.claimedAch")
													}) : O && /* @__PURE__ */ m("button", {
														type: "button",
														className: "btn-base min-h-11 px-3 text-xs",
														style: r ? { outline: "2px solid currentColor" } : void 0,
														onClick: () => x((e) => e.includes(t) ? e.filter((e) => e !== t) : [...e, t]),
														children: t + 1
													})
												]
											}, t);
										}),
										!O && e.finalQueue.length > 0 && /* @__PURE__ */ m("div", {
											className: "text-xs opacity-70",
											children: i("games.kanban.turnWait", { name: k(e.players[e.finalQueue[0]].rid) })
										})
									]
								})
							]
						}), D && /* @__PURE__ */ h("details", {
							className: "kb-details kb-personal-details",
							open: C.personal ?? S,
							children: [/* @__PURE__ */ h("summary", {
								onClick: (e) => {
									e.preventDefault(), T((e) => ({
										...e,
										personal: !(e.personal ?? S)
									}));
								},
								children: [
									i("games.kanban.myBoard"),
									" ",
									/* @__PURE__ */ m("span", { children: "＋" })
								]
							}), /* @__PURE__ */ h("div", {
								className: "plate mb-2 p-2",
								children: [
									/* @__PURE__ */ h("div", {
										className: "text-xs",
										children: [
											i("games.kanban.speechHave", {
												b: D.speechBoard,
												g: D.genericBeside
											}),
											" · ",
											i("games.kanban.bankedHave", { n: D.banked }),
											(D.pendBanked > 0 || D.pendBooks > 0 || D.pendVouchers > 0) && ` (+${D.pendBanked}/${D.pendBooks}/${D.pendVouchers})`
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "mt-1 flex flex-wrap gap-2 text-xs",
										children: X.map((e, t) => /* @__PURE__ */ h("span", {
											className: "plate px-1 py-0.5",
											children: [
												i(e),
												" ",
												i("games.kanban.trainLevel", { n: D.training[t] }),
												D.certs[t] ? ` · ${i("games.kanban.certified")}` : ""
											]
										}, e))
									}),
									/* @__PURE__ */ h("div", {
										className: "mt-1 text-xs",
										children: [
											i("games.kanban.partsHave"),
											": ",
											D.parts.map((e) => i(Q[e])).join(" · ") || "-"
										]
									}),
									/* @__PURE__ */ h("div", {
										className: "mt-1 text-xs",
										children: [
											i("games.kanban.designsHave"),
											": ",
											D.designs.map((e) => kt(i, e)).join(" | ") || "-"
										]
									}),
									/* @__PURE__ */ h("div", {
										className: "mt-1 text-xs",
										children: [
											i("games.kanban.upgradedHave"),
											": ",
											D.upgraded.map((e) => kt(i, e)).join(" | ") || "-"
										]
									}),
									/* @__PURE__ */ m("div", {
										className: "mt-1 flex flex-wrap gap-1 text-xs",
										children: D.garages.map((e, t) => /* @__PURE__ */ h("span", {
											className: "plate px-1 py-0.5",
											children: [
												i("games.kanban.garageN", { n: t + 1 }),
												": ",
												e === null ? "-" : i(Z[e]),
												D.garageTiles[t] ? ` [${D.garageTiles[t].flipped ? "✓" : "·"}${i(ne[D.garageTiles[t].tile])}]` : "",
												t === 4 && D.special ? ` [${i(St[D.special.tile])}${D.special.activated ? " ✓" : ""}]` : ""
											]
										}, t))
									}),
									D.tilePool.length > 0 && /* @__PURE__ */ h("div", {
										className: "mt-1 text-xs",
										children: [
											i("games.kanban.optDelayed"),
											": ",
											D.tilePool.map((e) => i(ne[e])).join(" · ")
										]
									})
								]
							})]
						})]
					})]
				})]
			})
		})
	});
}
function Nt({ pub: e, priv: t, seat: n, t: r, sel: i, pick: a, send: o }) {
	let s = e.prompt?.seat === n ? e.prompt : null;
	return s ? /* @__PURE__ */ m("div", {
		className: "kb-priority",
		children: /* @__PURE__ */ h("div", {
			className: "plate kb-prompt p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: r(s.kind === "certSpace" ? "games.kanban.certPick" : "games.kanban.awardPick")
				}),
				s.kind === "certSpace" && /* @__PURE__ */ m("div", {
					className: "mb-1 text-xs opacity-70",
					children: r("games.kanban.certOrderHint")
				}),
				/* @__PURE__ */ m("div", {
					className: "kb-priority__options",
					children: s.kind === "certSpace" ? P[s.section].map((t, n) => {
						let i = e.players.some((e) => e.certSection === s.section && e.certSpace === n);
						return /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-3 text-xs",
							disabled: i,
							onClick: () => o({
								type: "chooseCertSpace",
								space: n
							}),
							children: Ot(r, t) || r("games.kanban.certEmpty")
						}, n);
					}) : (t?.awardOptions ?? []).map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-3 text-xs",
						onClick: () => o({
							type: "chooseAward",
							award: e
						}),
						children: r(xt[e])
					}, e))
				})
			]
		})
	}) : e.branch ? /* @__PURE__ */ m("div", {
		className: "kb-priority",
		children: /* @__PURE__ */ h("div", {
			className: "plate kb-branch p-2",
			children: [/* @__PURE__ */ h("div", {
				className: "section-label",
				children: [
					r("games.kanban.branch"),
					" · ",
					e.branch.pos
				]
			}), /* @__PURE__ */ m("div", {
				className: "kb-branch-options",
				children: e.branch.options.map((e, t) => /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base kb-branch-option min-h-11 px-3 text-xs",
					"aria-pressed": i.branchIdx === t,
					onClick: () => a("branchIdx", t),
					children: e.exit === null ? `→ ${e.to}` : r("games.kanban.branchExit", { n: e.exit })
				}, t))
			})]
		})
	}) : null;
}
function Pt({ pub: e, t, sel: n, onPick: r }) {
	let i = (e) => n !== void 0 && JSON.stringify(n) === JSON.stringify(e);
	return /* @__PURE__ */ h("div", {
		className: "flex flex-wrap gap-1",
		children: [e.display.map((e, n) => e.map((e, a) => /* @__PURE__ */ m("button", {
			type: "button",
			className: "btn-base min-h-11 px-2 text-xs",
			disabled: e === null,
			style: i({
				kind: "display",
				row: n,
				col: a
			}) ? { outline: "2px solid currentColor" } : void 0,
			onClick: () => r({
				kind: "display",
				row: n,
				col: a
			}),
			children: e === null ? "-" : kt(t, e)
		}, `${n}-${a}`))), [
			"firstTop",
			"firstBottom",
			"central"
		].map((n) => {
			let a = n === "firstTop" ? "games.kanban.stackFirstTop" : n === "firstBottom" ? "games.kanban.stackFirstBottom" : "games.kanban.stackCentral";
			return /* @__PURE__ */ h("button", {
				type: "button",
				className: "btn-base min-h-11 px-2 text-xs",
				disabled: e.stackCounts[n] <= 0,
				style: i({
					kind: "stack",
					stack: n
				}) ? { outline: "2px solid currentColor" } : void 0,
				onClick: () => r({
					kind: "stack",
					stack: n
				}),
				children: [
					t(a),
					" (",
					e.stackCounts[n],
					")"
				]
			}, n);
		})]
	});
}
function Ft({ pub: e, t }) {
	let n = ee(e.players.length), r = O(e.players.length);
	return /* @__PURE__ */ h(p, { children: [
		/* @__PURE__ */ h("div", {
			className: "plate mb-2 p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: t("games.kanban.warehouses")
				}),
				/* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2 text-xs",
					children: e.warehouses.map((e, n) => /* @__PURE__ */ h("span", {
						className: "plate px-1 py-0.5",
						children: [
							t(Q[n]),
							" × ",
							e
						]
					}, n))
				}),
				/* @__PURE__ */ h("div", {
					className: "mt-1 text-xs opacity-80",
					children: [
						t("games.kanban.recycleBin"),
						": ",
						e.recycle.map((e) => t(Q[e])).join(" · ")
					]
				})
			]
		}),
		/* @__PURE__ */ h("div", {
			className: "plate mb-2 p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: t("games.kanban.displayTitle")
				}),
				e.display.map((e, n) => /* @__PURE__ */ m("div", {
					className: "mb-1 flex flex-wrap gap-1 text-xs",
					children: e.map((e, n) => /* @__PURE__ */ m("span", {
						className: "plate px-1 py-0.5",
						children: e === null ? "-" : kt(t, e)
					}, n))
				}, n)),
				/* @__PURE__ */ h("div", {
					className: "text-xs opacity-70",
					children: [
						t("games.kanban.stackFirstTop"),
						" ",
						e.stackCounts.firstTop,
						" · ",
						t("games.kanban.stackFirstBottom"),
						" ",
						e.stackCounts.firstBottom,
						" · ",
						t("games.kanban.stackCentral"),
						" ",
						e.stackCounts.central
					]
				})
			]
		}),
		/* @__PURE__ */ h("div", {
			className: "plate mb-2 p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: t("games.kanban.upgradesTitle")
				}),
				Z.map((n, r) => /* @__PURE__ */ h("div", {
					className: "mb-1 text-xs",
					children: [
						/* @__PURE__ */ m("span", {
							className: "font-bold",
							children: t(n)
						}),
						/* @__PURE__ */ h("span", {
							className: "ml-1 opacity-70",
							children: [
								t("games.kanban.assemblySlots", {
									n: e.asmParts[r].length,
									cap: w[r]
								}),
								" · ",
								e.asmParts[r].map((e) => t(Q[e])).join("+")
							]
						}),
						/* @__PURE__ */ m("span", {
							className: "ml-1 opacity-70",
							children: e.upgrades[r].map((e) => e === null ? "□" : t(Q[e])).join(" ")
						})
					]
				}, n)),
				/* @__PURE__ */ m("div", {
					className: "mt-1 text-xs opacity-80",
					children: Q.map((n, r) => `${t(n)} ${t("games.kanban.upgradeValue", { n: e.upVal[r] })}${e.doubled[r] ? "×2" : ""}`).join(" · ")
				})
			]
		}),
		/* @__PURE__ */ h("div", {
			className: "plate mb-2 p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: t("games.kanban.testTrack")
				}),
				/* @__PURE__ */ h("div", {
					className: "flex flex-wrap gap-1 text-xs",
					children: [e.testQueue.map((e, n) => /* @__PURE__ */ h("span", {
						className: "plate px-1 py-0.5",
						children: [
							t(Z[e]),
							" (",
							k[n],
							")"
						]
					}, n)), e.testQueue.length === 0 && /* @__PURE__ */ m("span", {
						className: "opacity-60",
						children: "-"
					})]
				}),
				/* @__PURE__ */ h("div", {
					className: "mt-1 text-xs opacity-70",
					children: [
						t("games.kanban.paceCar"),
						": ",
						e.pace + 1,
						"/",
						n,
						r.includes(e.pace) ? " ▤" : "",
						" · ",
						t("games.kanban.demand"),
						": ",
						e.demand.map((e) => `${t(Z[e.model])}×${e.tokens}/${te[e.model]}`).join(" · ")
					]
				})
			]
		}),
		/* @__PURE__ */ h("div", {
			className: "plate mb-2 p-2",
			children: [
				/* @__PURE__ */ m("div", {
					className: "section-label",
					children: t("games.kanban.meetingTitle")
				}),
				e.tableGoals.map((e) => /* @__PURE__ */ h("div", {
					className: "text-xs",
					children: [
						L[e].pp,
						" PP × ",
						Et(t, L[e].kind)
					]
				}, e)),
				/* @__PURE__ */ h("div", {
					className: "mt-1 text-xs",
					children: [/* @__PURE__ */ h("span", {
						className: "font-bold",
						children: [t("games.kanban.finalTitle"), ": "]
					}), ie[e.finalGoal].map((e, n) => `${n + 1}. ${e.pp}PP ${e.all.map((e) => Dt(t, e)).join("+")}`).join(" / ")]
				})
			]
		})
	] });
}
function It({ pub: e, me: t, priv: n, t: r, tool: i, sel: a, startTool: o, pick: s, fire: c, send: l, garageTileKeys: u }) {
	let d = e.work, f = t.dept === 4, g = (e) => t.dept === e || f && d.adminTarget === e, _ = t.special?.pending === "train2" || (t.special?.pending?.startsWith("train2b:") ?? !1), v = (e) => a[e], y = (n, r) => {
		let i = e.asmParts[n], a = e.upgrades[n].filter((e) => e !== null && !i.includes(e));
		return i.length < w[n] && !i.includes(r) && (e.config.speedcharger && t.chargeRows[1] || a.length === 0 || a.includes(r));
	}, b = [
		{
			id: "claim",
			label: r("games.kanban.claim"),
			show: g(0)
		},
		{
			id: "upgrade",
			label: r("games.kanban.upgrade"),
			show: g(0)
		},
		{
			id: "provide",
			label: r("games.kanban.provide"),
			show: g(1)
		},
		{
			id: "kanban",
			label: r("games.kanban.kanbanPlay"),
			show: g(2) && !d.kanbanUsed
		},
		{
			id: "collect",
			label: r("games.kanban.collect"),
			show: g(2)
		},
		{
			id: "recycle",
			label: r("games.kanban.recycle"),
			show: !0
		},
		{
			id: "charge",
			label: r("games.kanban.charge"),
			show: f && e.config.speedcharger && !d.chargeUsed
		},
		{
			id: "homework",
			label: r("games.kanban.homework"),
			show: t.books > 0
		},
		{
			id: "banked",
			label: r("games.kanban.useBanked"),
			show: t.banked > 0
		},
		{
			id: "flip",
			label: r("games.kanban.flipTile"),
			show: e.config.delayedTuning && t.garageTiles.some((t) => t && !t.flipped && t.placedTurn < e.turnSeq)
		},
		{
			id: "trainSg",
			label: r(St[1]),
			show: _
		}
	];
	return /* @__PURE__ */ h("div", {
		className: "plate mb-2 p-2",
		children: [
			/* @__PURE__ */ h("div", {
				className: "section-label",
				children: [
					r("games.kanban.phaseWork"),
					" — ",
					t.dept === null ? "" : r(X[t.dept]),
					" · ",
					r("games.kanban.shiftsLeft", { n: d.shiftsLeft })
				]
			}),
			f && d.adminTarget === null && /* @__PURE__ */ h("div", {
				className: "mb-2",
				children: [/* @__PURE__ */ m("div", {
					className: "mb-1 text-xs",
					children: r("games.kanban.adminPick")
				}), /* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2",
					children: [
						0,
						1,
						2,
						3
					].map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-3 text-xs",
						onClick: () => l({
							type: "adminTarget",
							dept: e
						}),
						children: r(X[e])
					}, e))
				})]
			}),
			/* @__PURE__ */ h("div", {
				className: "mb-2 flex flex-wrap items-center gap-2 text-xs",
				children: [/* @__PURE__ */ h("span", { children: [r("games.kanban.train"), ":"] }), [
					0,
					1,
					2,
					3,
					4
				].filter((e) => g(e) && t.training[e] < 5).map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					disabled: d.shiftsLeft < 1,
					onClick: () => l({
						type: "train",
						dept: e
					}),
					children: [
						r(X[e]),
						" ",
						t.training[e],
						"/5"
					]
				}, e))]
			}),
			g(3) && /* @__PURE__ */ h("div", {
				className: "mb-2",
				children: [
					/* @__PURE__ */ m("div", {
						className: "mb-1 text-xs",
						children: r("games.kanban.takeDesign")
					}),
					/* @__PURE__ */ m("div", {
						className: "flex flex-wrap gap-1",
						children: e.display.map((e, n) => e.map((e, i) => /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-2 text-xs",
							disabled: e === null || d.shiftsLeft < 1 || t.designs.length >= 3 + +!!t.certs[3],
							title: i === 2 ? r("games.kanban.colBonusBank") : i === 3 ? r("games.kanban.colBonusBook") : void 0,
							onClick: () => l({
								type: "takeDesign",
								row: n,
								col: i
							}),
							children: e === null ? "-" : kt(r, e)
						}, `${n}-${i}`)))
					}),
					t.certs[3] && /* @__PURE__ */ m("div", {
						className: "mt-1 flex flex-wrap gap-2",
						children: [
							"firstTop",
							"firstBottom",
							"central"
						].map((n) => {
							let i = n === "firstTop" ? "games.kanban.stackFirstTop" : n === "firstBottom" ? "games.kanban.stackFirstBottom" : "games.kanban.stackCentral";
							return /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: e.stackCounts[n] <= 0 || d.shiftsLeft < 1 || t.designs.length >= 3 + +!!t.certs[3],
								onClick: () => l({
									type: "takeAdvancedDesign",
									stack: n
								}),
								children: [
									r("games.kanban.takeAdvanced"),
									": ",
									r(i)
								]
							}, n);
						})
					})
				]
			}),
			g(2) && t.certs[2] && /* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-base mb-2 min-h-11 px-3 text-xs",
				disabled: d.voucherUsed || d.shiftsLeft < 1,
				onClick: () => l({ type: "takeVoucher" }),
				children: r("games.kanban.takeVoucher")
			}),
			t.special && !t.special.activated && t.garages[4] !== null && /* @__PURE__ */ h("button", {
				type: "button",
				className: "btn-base mb-2 min-h-11 px-3 text-xs",
				onClick: () => l({ type: "sgActivate" }),
				children: [
					r("games.kanban.sgActivate"),
					": ",
					r(St[t.special.tile])
				]
			}),
			t.special?.activated && /* @__PURE__ */ h("div", {
				className: "mb-2 text-xs opacity-70",
				children: [
					r("games.kanban.sgActive"),
					": ",
					r(St[t.special.tile])
				]
			}),
			/* @__PURE__ */ h("div", {
				className: "mb-2 flex flex-wrap gap-2",
				children: [b.filter((e) => e.show).map((e) => /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					style: i === e.id ? { outline: "2px solid currentColor" } : void 0,
					onClick: () => o(i === e.id ? null : e.id),
					children: e.label
				}, e.id)), /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					onClick: () => l({ type: "endWork" }),
					children: r("games.kanban.endTurn")
				})]
			}),
			i === "banked" && /* @__PURE__ */ m("div", {
				className: "mb-2 flex flex-wrap gap-2",
				children: [
					1,
					2,
					3
				].filter((e) => e <= t.banked && d.bankedUsed + e <= 3).map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					onClick: () => c({
						type: "useBanked",
						n: e
					}),
					children: ["+", e]
				}, e))
			}),
			i === "homework" && /* @__PURE__ */ h("div", {
				className: "mb-2",
				children: [/* @__PURE__ */ m("div", {
					className: "mb-1 text-xs opacity-70",
					children: r("games.kanban.homeworkHint")
				}), /* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2",
					children: [
						0,
						1,
						2,
						3,
						4
					].filter((e) => g(e) && t.training[e] < 5).map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-3 text-xs",
						onClick: () => c({
							type: "homework",
							dept: e,
							n: 1
						}),
						children: r(X[e])
					}, e))
				})]
			}),
			i === "trainSg" && t.special && /* @__PURE__ */ h("div", {
				className: "mb-2",
				children: [/* @__PURE__ */ m("div", {
					className: "mb-1 text-xs opacity-70",
					children: r(Ct[1])
				}), /* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2",
					children: [
						0,
						1,
						2,
						3,
						4
					].filter((e) => t.training[e] < 5 && t.special.pending !== `train2b:${e}`).map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-3 text-xs",
						onClick: () => c({
							type: "train",
							dept: e
						}),
						children: r(X[e])
					}, e))
				})]
			}),
			i === "recycle" && /* @__PURE__ */ h("div", {
				className: "mb-2 flex flex-wrap items-center gap-2 text-xs",
				children: [
					/* @__PURE__ */ h("span", { children: [r("games.kanban.recycleBin"), ":"] }),
					[...new Set(t.parts)].map((e) => /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base min-h-11 px-2 text-xs",
						style: v("give") === e ? { outline: "2px solid currentColor" } : void 0,
						onClick: () => s("give", e),
						children: ["−", r(Q[e])]
					}, `g${e}`)),
					e.recycle.map((e, t) => /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base min-h-11 px-2 text-xs",
						style: v("take") === e ? { outline: "2px solid currentColor" } : void 0,
						onClick: () => s("take", e),
						children: ["+", r(Q[e])]
					}, `t${t}`)),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-3 text-xs",
						disabled: v("give") === void 0 || v("take") === void 0,
						onClick: () => c({
							type: "recycle",
							give: v("give"),
							take: v("take")
						}),
						children: r("games.kanban.confirm")
					})
				]
			}),
			i === "collect" && /* @__PURE__ */ h("div", {
				className: "mb-2 flex flex-wrap items-center gap-2 text-xs",
				children: [Q.map((t, n) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base min-h-11 px-2 text-xs",
					disabled: e.warehouses[n] <= 0,
					style: v("part") === n ? { outline: "2px solid currentColor" } : void 0,
					onClick: () => s("part", n),
					children: [
						r(t),
						" (",
						e.warehouses[n],
						")"
					]
				}, t)), v("part") !== void 0 && [
					1,
					2,
					3,
					4
				].filter((t) => t <= e.warehouses[v("part")]).map((e) => /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					onClick: () => c({
						type: "collectParts",
						part: v("part"),
						count: e
					}),
					children: ["×", e]
				}, e))]
			}),
			i === "kanban" && /* @__PURE__ */ m("div", {
				className: "mb-2",
				children: /* @__PURE__ */ m("div", {
					className: "flex flex-wrap gap-2",
					children: n.kanbanHand.map((e) => /* @__PURE__ */ h("div", {
						className: "plate p-2 text-xs",
						children: [
							/* @__PURE__ */ m("div", {
								className: "mb-1",
								children: F[e].slice(0, 4).map((e) => r(Q[e])).join("+")
							}),
							/* @__PURE__ */ m("div", {
								className: "mb-1 opacity-70",
								children: F[e].slice(4, 6).map((e) => r(Q[e])).join("+")
							}),
							/* @__PURE__ */ h("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ m("button", {
									type: "button",
									className: "btn-base min-h-11 px-2 text-xs",
									disabled: d.shiftsLeft < 1,
									onClick: () => c({
										type: "kanbanOrder",
										cardId: e,
										side: 0
									}),
									children: r("games.kanban.side4")
								}), /* @__PURE__ */ m("button", {
									type: "button",
									className: "btn-base min-h-11 px-2 text-xs",
									disabled: d.shiftsLeft < 1,
									onClick: () => c({
										type: "kanbanOrder",
										cardId: e,
										side: 1
									}),
									children: r("games.kanban.side2")
								})]
							})
						]
					}, e))
				})
			}),
			i === "provide" && /* @__PURE__ */ h("div", {
				className: "mb-2 text-xs",
				children: [
					/* @__PURE__ */ m("div", {
						className: "mb-1 flex flex-wrap gap-2",
						children: Z.map((t, n) => /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-2 text-xs",
							disabled: e.asmParts[n].length >= w[n],
							style: v("model") === n ? { outline: "2px solid currentColor" } : void 0,
							onClick: () => s("model", n),
							children: r(t)
						}, t))
					}),
					/* @__PURE__ */ m("div", {
						className: "mb-1 flex flex-wrap gap-2",
						children: Q.map((e, t) => /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-2 text-xs",
							disabled: v("model") !== void 0 && !y(v("model"), t),
							style: v("part") === t ? { outline: "2px solid currentColor" } : void 0,
							onClick: () => s("part", t),
							children: r(e)
						}, e))
					}),
					/* @__PURE__ */ h("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-3 text-xs",
							disabled: v("model") === void 0 || v("part") === void 0 || !y(v("model"), v("part")) || !t.parts.includes(v("part")) || d.shiftsLeft < 1,
							onClick: () => c({
								type: "providePart",
								model: v("model"),
								part: v("part"),
								source: "part"
							}),
							children: r("games.kanban.provide")
						}), /* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-3 text-xs",
							disabled: v("model") === void 0 || v("part") === void 0 || !y(v("model"), v("part")) || t.vouchers < 1 || d.shiftsLeft < 1,
							onClick: () => c({
								type: "providePart",
								model: v("model"),
								part: v("part"),
								source: "voucher"
							}),
							children: r("games.kanban.provideVoucher")
						})]
					})
				]
			}),
			i === "claim" && /* @__PURE__ */ h("div", {
				className: "mb-2 text-xs",
				children: [
					/* @__PURE__ */ m("div", {
						className: "mb-1",
						children: r("games.kanban.pickTrack")
					}),
					/* @__PURE__ */ m("div", {
						className: "mb-1 flex flex-wrap gap-2",
						children: e.testQueue.map((e, t) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-base min-h-11 px-2 text-xs",
							disabled: d.shiftsLeft < k[t],
							style: v("trackIdx") === t ? { outline: "2px solid currentColor" } : void 0,
							onClick: () => s("trackIdx", t),
							children: [
								r(Z[e]),
								" (",
								k[t],
								")"
							]
						}, t))
					}),
					v("trackIdx") !== void 0 && /* @__PURE__ */ h(p, { children: [
						/* @__PURE__ */ m("div", {
							className: "mb-1",
							children: r("games.kanban.pickDesign")
						}),
						/* @__PURE__ */ m("div", {
							className: "mb-1 flex flex-wrap gap-2",
							children: t.designs.filter((t) => R(t) === e.testQueue[v("trackIdx")]).map((e) => /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								style: v("designId") === e ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("designId", e),
								children: kt(r, e)
							}, e))
						}),
						/* @__PURE__ */ m("div", {
							className: "mb-1",
							children: r("games.kanban.pickGarage")
						}),
						/* @__PURE__ */ m("div", {
							className: "mb-1 flex flex-wrap gap-2",
							children: t.garages.map((e, n) => /* @__PURE__ */ h("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: e !== null || n === 4 && !t.certs[1],
								style: v("garage") === n ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("garage", n),
								children: [r("games.kanban.garageN", { n: n + 1 }), n === 4 && !t.certs[1] ? ` (${r("games.kanban.garageLocked")})` : ""]
							}, n))
						}),
						e.config.delayedTuning && v("garage") !== void 0 && v("garage") <= 3 && /* @__PURE__ */ m("div", {
							className: "mb-1 flex flex-wrap gap-2",
							children: t.tilePool.map((e) => /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								style: v("tile") === e ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("tile", e),
								children: r(u[e])
							}, e))
						}),
						/* @__PURE__ */ m(Lt, {
							pub: e,
							me: t,
							sel: a,
							pick: s,
							t: r
						}),
						/* @__PURE__ */ m("button", {
							type: "button",
							className: "btn-base min-h-11 px-4 text-sm",
							disabled: v("designId") === void 0 || v("garage") === void 0 || e.config.delayedTuning && v("garage") <= 3 && v("tile") === void 0,
							onClick: () => c({
								type: "claimCar",
								trackIdx: v("trackIdx"),
								designId: v("designId"),
								garage: v("garage"),
								tile: v("tile"),
								lockChoice: a.lockChoice,
								gainParts: a.gainParts
							}),
							children: r("games.kanban.confirm")
						})
					] })
				]
			}),
			i === "upgrade" && /* @__PURE__ */ h("div", {
				className: "mb-2 text-xs",
				children: [/* @__PURE__ */ m("div", {
					className: "mb-1 flex flex-wrap gap-2",
					children: t.designs.filter((e) => z(e) !== null).map((e) => /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-2 text-xs",
						style: v("designId") === e ? { outline: "2px solid currentColor" } : void 0,
						onClick: () => s("designId", e),
						children: kt(r, e)
					}, e))
				}), v("designId") !== void 0 && /* @__PURE__ */ h(p, { children: [
					/* @__PURE__ */ m("div", {
						className: "mb-1 flex flex-wrap gap-2",
						children: N[R(v("designId"))].map((t, n) => /* @__PURE__ */ h("button", {
							type: "button",
							className: "btn-base min-h-11 px-2 text-xs",
							disabled: e.upgrades[R(v("designId"))][n] !== null,
							style: v("space") === n ? { outline: "2px solid currentColor" } : void 0,
							onClick: () => s("space", n),
							children: [n + 1, t.kind === "pp" ? ` ${t.n}PP` : t.kind === "book" ? " 📖" : ""]
						}, n))
					}),
					/* @__PURE__ */ h("div", {
						className: "mb-1 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: !t.parts.includes(z(v("designId"))),
								style: a.source === "part" ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("source", "part"),
								children: r("games.kanban.srcPart")
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: t.vouchers < 1,
								style: a.source === "voucher" ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("source", "voucher"),
								children: r("games.kanban.srcVoucher")
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: !(e.config.speedcharger && t.chargeRows[0] && !d.speedRdUsed || t.special?.pending === "upgrade"),
								style: a.source === "supply" ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("source", "supply"),
								children: r("games.kanban.srcSupply")
							}),
							/* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-base min-h-11 px-2 text-xs",
								disabled: !t.certs[0] || t.doubleUsed || e.doubled[z(v("designId"))],
								style: a.double === !0 ? { outline: "2px solid currentColor" } : void 0,
								onClick: () => s("double", a.double !== !0),
								children: r("games.kanban.upgradeDouble")
							})
						]
					}),
					/* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-4 text-sm",
						disabled: v("space") === void 0 || a.source === void 0 || d.shiftsLeft < 1,
						onClick: () => c({
							type: "upgradeDesign",
							designId: v("designId"),
							space: v("space"),
							source: a.source,
							double: a.double === !0
						}),
						children: r("games.kanban.confirm")
					})
				] })]
			}),
			i === "charge" && /* @__PURE__ */ m("div", {
				className: "mb-2 flex flex-wrap gap-2",
				children: [
					0,
					1,
					2,
					3,
					4
				].filter((e) => !t.chargeRows[e]).map((t) => /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base min-h-11 px-3 text-xs",
					disabled: d.shiftsLeft < 1 || e.chargerSupply <= 0,
					onClick: () => c({
						type: "charge",
						row: t
					}),
					children: r("games.kanban.chargeRow", { n: t + 1 })
				}, t))
			}),
			i === "flip" && /* @__PURE__ */ h("div", {
				className: "mb-2 text-xs",
				children: [/* @__PURE__ */ m("div", {
					className: "mb-1 flex flex-wrap gap-2",
					children: t.garageTiles.map((t, n) => t && !t.flipped && t.placedTurn < e.turnSeq && n <= 3 ? /* @__PURE__ */ h("button", {
						type: "button",
						className: "btn-base min-h-11 px-2 text-xs",
						style: v("garage") === n ? { outline: "2px solid currentColor" } : void 0,
						onClick: () => s("garage", n),
						children: [
							r("games.kanban.garageN", { n: n + 1 }),
							": ",
							r(u[t.tile])
						]
					}, n) : null)
				}), v("garage") !== void 0 && /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ m(Lt, {
					pub: e,
					me: t,
					sel: a,
					pick: s,
					t: r,
					forGarage: v("garage")
				}), /* @__PURE__ */ m("button", {
					type: "button",
					className: "btn-base min-h-11 px-4 text-sm",
					onClick: () => c({
						type: "flipGarageTile",
						garage: v("garage"),
						lockChoice: a.lockChoice,
						gainParts: a.gainParts
					}),
					children: r("games.kanban.confirm")
				})] })]
			})
		]
	});
}
function Lt({ pub: e, me: t, sel: n, pick: r, t: i, forGarage: a }) {
	let o = a ?? n.garage;
	if (o === void 0) return null;
	let s = e.config.delayedTuning && a === void 0 ? n.tile : t.garageTiles[o]?.tile;
	if (s === void 0) return null;
	let c = (e.config.expertTuning ? I : ne)[s], l = n.lockChoice ?? [];
	return e.config.specialGarage && o === 4 && a === void 0 ? null : c.kind === "lock" ? /* @__PURE__ */ h("div", {
		className: "mb-1",
		children: [
			/* @__PURE__ */ m("div", {
				className: "mb-1",
				children: i("games.kanban.lockPick")
			}),
			/* @__PURE__ */ m("div", {
				className: "flex flex-wrap gap-2",
				children: xt.map((e, t) => {
					let n = [
						i("games.kanban.gtBasic0"),
						i("games.kanban.gtBasic1"),
						i("games.kanban.gtBasic2"),
						i("games.kanban.gtBasic3")
					][t], a = l.includes(t);
					return /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base min-h-11 px-2 text-xs",
						style: a ? { outline: "2px solid currentColor" } : void 0,
						onClick: () => {
							r("lockChoice", a ? l.filter((e) => e !== t) : l.length < 2 ? [...l, t] : [l[1], t]);
						},
						children: n
					}, t);
				})
			}),
			l.includes(3) && /* @__PURE__ */ m(Rt, {
				sel: n,
				pick: r,
				t: i,
				count: 2
			})
		]
	}) : c.kind === "parts" ? /* @__PURE__ */ m(Rt, {
		sel: n,
		pick: r,
		t: i,
		count: c.n
	}) : null;
}
function Rt({ sel: e, pick: t, t: n, count: r }) {
	let i = e.gainParts ?? [];
	return /* @__PURE__ */ h("div", {
		className: "mb-1",
		children: [/* @__PURE__ */ m("div", {
			className: "mb-1",
			children: n("games.kanban.gainPartsPick", { n: r })
		}), /* @__PURE__ */ m("div", {
			className: "flex flex-wrap gap-2",
			children: Q.map((e, a) => /* @__PURE__ */ m("button", {
				type: "button",
				className: "btn-base min-h-11 px-2 text-xs",
				disabled: !i.includes(a) && i.length >= r,
				style: i.includes(a) ? { outline: "2px solid currentColor" } : void 0,
				onClick: () => t("gainParts", i.includes(a) ? i.filter((e) => e !== a) : [...i, a]),
				children: n(e)
			}, e))
		})]
	});
}
//#endregion
//#region src/games/kanban/bot.ts
function $(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
var zt = (e) => e.garages.filter((e) => e !== null), Bt = (e) => 3 + +!!e.certs[2], Vt = (e) => 3 + +!!e.certs[3], Ht = (e) => e.upgraded.filter((t) => zt(e).includes(R(t)));
function Ut(e, t) {
	let n = e.warehouses[t] + e.recycle.filter((e) => e === t).length;
	for (let r of e.asmParts) n += r.filter((e) => e === t).length;
	for (let r of e.upgrades) n += r.filter((e) => e === t).length;
	for (let r of e.players) n += r.parts.filter((e) => e === t).length;
	return 10 - n;
}
function Wt(e, t) {
	switch (e.t) {
		case "cars": return zt(t).length;
		case "models": return new Set(zt(t)).size;
		case "modelCars": return zt(t).filter((t) => t === e.m).length;
		case "partUpgrades": return t.upgraded.filter((t) => z(t) === e.p).length;
		case "upgrades": return t.upgraded.length;
		case "tested": return Ht(t).length;
		case "parts2": return t.parts.filter((t) => e.ps.includes(t)).length;
		case "garagePair": return e.g.filter((e) => t.garages[e] !== null).length;
		case "cert": return +!!t.certs[e.d];
		case "designs": return t.designs.length;
		case "books": return t.books;
		case "certs": return t.certs.filter(Boolean).length;
		case "vouchers": return t.vouchers;
		case "banked": return t.banked;
		case "speech": return t.speechBoard;
		case "chargers": return t.chargeRows.filter(Boolean).length;
		case "chargerRow": return +!!t.chargeRows[e.row];
	}
}
function Gt(e, t) {
	let n = zt(t);
	switch (e.t) {
		case "sameModelCars": return [
			0,
			1,
			2,
			3,
			4
		].some((t) => n.filter((e) => e === t).length >= e.n);
		case "cars": return n.length >= e.n;
		case "distinctModels": return new Set(n).size >= e.n;
		case "modelCars": return n.filter((t) => t === e.m).length >= e.n;
		case "distinctPartUpgrades": return new Set(t.upgraded.map((e) => z(e))).size >= e.n;
		case "samePartUpgrades": return [
			0,
			1,
			2,
			3,
			4,
			5
		].some((n) => t.upgraded.filter((e) => z(e) === n).length >= e.n);
		case "partUpgrades": return t.upgraded.filter((t) => z(t) === e.p).length >= e.n;
		case "upgrades": return t.upgraded.length >= e.n;
		case "tested": return Ht(t).length >= e.n;
		case "testedParts": return new Set(Ht(t).map((e) => z(e))).size >= e.n;
		case "certs": return t.certs.filter(Boolean).length >= e.n;
		case "certsMax": return t.certs.filter(Boolean).length <= e.n;
		case "certPair": return e.ds[0] === e.ds[1] ? t.certs[e.ds[0]] : t.certs[e.ds[0]] && t.certs[e.ds[1]];
		case "banked": return t.banked >= e.n;
		case "books": return t.books >= e.n;
		case "vouchers": return t.vouchers >= e.n;
		case "experts": return t.training.filter((e) => e >= 5).length >= e.n;
		case "expertsMax": return t.training.filter((e) => e >= 5).length <= e.n;
		case "chargers": return t.chargeRows.filter(Boolean).length >= e.n;
		case "chargerRow": return t.chargeRows[e.row];
		case "speechBoard": return t.speechBoard >= e.n;
	}
}
function Kt(e, t, n) {
	let r = e.work, i = [], a = n.dept === 4, o = (e) => n.dept === e || a && r.adminTarget === e, s = 4 + (n.special?.tile === 2 && n.special.activated ? 1 : 0), c = e.config.expertTuning ? I : ne, l = n.special?.pending === "train2" ? -1 : n.special?.pending?.startsWith("train2b:") ? Number(n.special.pending.slice(8)) : null;
	if (l !== null) {
		let e = [...[
			0,
			1,
			2,
			3,
			4
		].filter((e) => n.training[e] === 2), ...[
			0,
			1,
			2,
			3,
			4
		].filter((e) => n.training[e] < 5)];
		for (let t of e) t !== l && i.push({
			type: "train",
			dept: t
		});
		return i;
	}
	if (n.special?.pending === "design" && n.designs.length < Vt(n)) for (let t = 3; t >= 0; t--) for (let n = 0; n < 2; n++) e.display[n][t] !== null && i.push({
		type: "takeDesign",
		row: n,
		col: t
	});
	if (a && r.adminTarget === null) {
		let t = e.testQueue.some((e, t) => r.shiftsLeft >= k[t] && n.designs.some((t) => R(t) === e));
		i.push({
			type: "adminTarget",
			dept: t ? 0 : n.designs.length < Vt(n) ? 3 : 2
		});
	}
	let u = [];
	if (o(0)) {
		for (let t = 0; t < e.testQueue.length; t++) {
			if (r.shiftsLeft < k[t]) continue;
			let i = e.testQueue[t], a = n.designs.find((e) => R(e) === i);
			if (a !== void 0) for (let r = 0; r < 5; r++) {
				if (n.garages[r] !== null || r === 4 && !n.certs[1] || e.config.planner && r !== n.garages.indexOf(null)) continue;
				if (e.config.delayedTuning && r <= 3) {
					for (let e of n.tilePool) u.push({
						type: "claimCar",
						trackIdx: t,
						designId: a,
						garage: r,
						tile: e
					});
					continue;
				}
				let i = n.garageTiles[r], o = e.config.specialGarage && r === 4;
				if (i && !o) {
					let o = c[i.tile];
					if (o.kind === "lock") {
						u.push({
							type: "claimCar",
							trackIdx: t,
							designId: a,
							garage: r,
							lockChoice: [0, 1]
						});
						continue;
					}
					if (o.kind === "parts") {
						let i = [
							0,
							1,
							2,
							3,
							4,
							5
						].filter((t) => Ut(e, t) > 0);
						if (i.length < o.n || n.parts.length + o.n > Bt(n)) continue;
						u.push({
							type: "claimCar",
							trackIdx: t,
							designId: a,
							garage: r,
							gainParts: i.slice(0, o.n)
						});
						continue;
					}
				}
				u.push({
					type: "claimCar",
					trackIdx: t,
					designId: a,
					garage: r
				});
			}
		}
		let t = new Set(zt(n)), i = [...n.designs].sort((e, n) => Number(t.has(R(n))) - Number(t.has(R(e))));
		for (let t of i) {
			let i = z(t);
			if (i === null) continue;
			let a = R(t), o = e.upgrades[a].findIndex((e) => e === null);
			if (o < 0) continue;
			let s = n.certs[0] && !n.doubleUsed && !e.doubled[i];
			n.parts.includes(i) && u.push({
				type: "upgradeDesign",
				designId: t,
				source: "part",
				space: o,
				double: s
			}), n.vouchers > 0 && Ut(e, i) > 0 && u.push({
				type: "upgradeDesign",
				designId: t,
				source: "voucher",
				space: o,
				double: s
			}), (n.special?.pending === "upgrade" || e.config.speedcharger && n.chargeRows[0] && !r.speedRdUsed) && Ut(e, i) > 0 && u.push({
				type: "upgradeDesign",
				designId: t,
				source: "supply",
				space: o,
				double: s
			});
		}
	}
	if (o(1)) for (let t = 0; t < 5; t++) {
		if (e.asmParts[t].length >= w[t]) continue;
		let r = e.upgrades[t].filter((e) => e !== null).filter((n) => !e.asmParts[t].includes(n));
		for (let i = 0; i < 6; i++) e.asmParts[t].includes(i) || r.length > 0 && !r.includes(i) && !(e.config.speedcharger && n.chargeRows[1]) || (n.parts.includes(i) ? u.push({
			type: "providePart",
			model: t,
			source: "part",
			part: i
		}) : n.vouchers > 0 && Ut(e, i) > 0 && u.push({
			type: "providePart",
			model: t,
			source: "voucher",
			part: i
		}));
	}
	if (o(2)) {
		if (!r.kanbanUsed && n.kanbanCount > 0) for (let e of t.kanbanHand) u.push({
			type: "kanbanOrder",
			cardId: e,
			side: 0
		});
		let i = Bt(n) - n.parts.length;
		if (i > 0) {
			let t = [...new Set(n.designs.map((e) => z(e)).filter((e) => e !== null))];
			for (let n of [
				...t,
				0,
				1,
				2,
				3,
				4,
				5
			]) {
				let t = Math.min(e.warehouses[n], i, 4);
				if (t > 0) {
					u.push({
						type: "collectParts",
						part: n,
						count: t
					});
					break;
				}
			}
		}
		n.certs[2] && !r.voucherUsed && u.push({ type: "takeVoucher" });
	}
	if (o(3) && n.designs.length < Vt(n)) {
		for (let t = 3; t >= 0; t--) for (let n = 0; n < 2; n++) e.display[n][t] !== null && u.push({
			type: "takeDesign",
			row: n,
			col: t
		});
		n.certs[3] && (e.stackCounts.central > 0 && u.push({
			type: "takeAdvancedDesign",
			stack: "central"
		}), e.stackCounts.firstTop > 0 && u.push({
			type: "takeAdvancedDesign",
			stack: "firstTop"
		}), e.stackCounts.firstBottom > 0 && u.push({
			type: "takeAdvancedDesign",
			stack: "firstBottom"
		}));
	}
	if (a && e.config.speedcharger && !r.chargeUsed && e.chargerSupply > 0) for (let e of [
		2,
		0,
		3,
		1,
		4
	]) n.chargeRows[e] || u.push({
		type: "charge",
		row: e
	});
	for (let e of u) r.shiftsLeft >= 1 && i.push(e);
	if (n.books > 0) {
		let e = [
			0,
			1,
			2,
			3,
			4
		].filter((e) => o(e) && n.training[e] < 5);
		for (let t of [...e.filter((e) => n.training[e] === 2), ...e.filter((e) => n.training[e] !== 2)]) i.push({
			type: "homework",
			dept: t,
			n: 1
		});
	}
	if (n.special && !n.special.activated && n.garages[4] !== null && (n.special.tile !== 4 || n.designs.length < Vt(n)) && i.push({ type: "sgActivate" }), e.config.delayedTuning) for (let t = 0; t <= 3; t++) {
		let r = n.garageTiles[t];
		if (!r || r.flipped || r.placedTurn >= e.turnSeq) continue;
		let a = c[r.tile];
		if (a.kind === "lock") i.push({
			type: "flipGarageTile",
			garage: t,
			lockChoice: [0, 1]
		});
		else if (a.kind === "parts") {
			let r = [
				0,
				1,
				2,
				3,
				4,
				5
			].filter((t) => Ut(e, t) > 0);
			r.length >= a.n && n.parts.length + a.n <= Bt(n) && i.push({
				type: "flipGarageTile",
				garage: t,
				gainParts: r.slice(0, a.n)
			});
		} else i.push({
			type: "flipGarageTile",
			garage: t
		});
	}
	if (r.shiftsLeft >= 1) {
		let e = [
			0,
			1,
			2,
			3,
			4
		].filter((e) => o(e) && n.training[e] < 5), t = e.find((e) => n.training[e] === 2);
		t !== void 0 && i.push({
			type: "train",
			dept: t
		});
		let r = [...e].sort((e, t) => n.training[e] - n.training[t])[0];
		r !== void 0 && i.push({
			type: "train",
			dept: r
		});
	}
	if (r.shiftsLeft === 0 && n.banked > 0 && u.length > 0) {
		let e = Math.min(3 - r.bankedUsed, n.banked, s);
		e > 0 && i.unshift({
			type: "useBanked",
			n: e
		});
	}
	return i.push({ type: "endWork" }), i;
}
var qt = (e, t) => {
	let n = e.public, r = e.private;
	if (!r) return null;
	let i = r.seat, a = n.players[i];
	if (!a) return null;
	let o = t.difficulty === "weak", s = (e) => e.length === 0 ? null : o ? $(e) : e[0], c = n.prompt;
	if (c && c.seat === i) {
		if (c.kind === "certSpace") {
			let e = [...Array(P[c.section].length).keys()].filter((e) => !n.players.some((t) => t.certSection === c.section && t.certSpace === e));
			return e.length === 0 ? null : { action: {
				type: "chooseCertSpace",
				space: o ? $(e) : Math.max(...e)
			} };
		}
		let e = r.awardOptions ?? [];
		if (e.length === 0) return null;
		let t = [
			0,
			3,
			2,
			1
		].find((t) => e.includes(t)) ?? e[0];
		return { action: {
			type: "chooseAward",
			award: o ? $(e) : t
		} };
	}
	if (n.branch && n.current === i) {
		let e = n.branch.options;
		if (e.length === 0) return null;
		let t = e.find((e) => e.exit === 2), r = e.find((e) => e.exit === 1), i = o ? $(e) : t ?? r ?? e[0];
		return { action: {
			type: "carMove",
			to: i.to,
			exit: i.exit
		} };
	}
	switch (n.phase) {
		case "inductCert": {
			if (n.current !== i) return null;
			let e = [
				0,
				1,
				2,
				3
			].filter((e) => !n.players.some((t) => t.certSection === 0 && t.certSpace === e));
			return e.length === 0 ? null : { action: {
				type: "inductCert",
				space: o ? $(e) : Math.max(...e)
			} };
		}
		case "inductTake": {
			if (n.current !== i) return null;
			let e = [
				0,
				1,
				2,
				3,
				4,
				5
			].filter((e) => n.warehouses[e] > 0);
			if (e.length === 0) return null;
			let t = [];
			for (let e = 3; e >= 0; e--) for (let r = 0; r < 2; r++) n.display[r][e] !== null && t.push({
				kind: "display",
				row: r,
				col: e
			});
			let r = t.length > 0 ? o ? $(t) : t[0] : {
				kind: "stack",
				stack: "central"
			}, a = r.kind === "display" ? z(n.display[r.row][r.col]) : null;
			return { action: {
				type: "inductTake",
				part: a !== null && e.includes(a) ? a : o ? $(e) : e[0],
				design: r
			} };
		}
		case "specialGarage": {
			if (n.current !== i) return null;
			let e = new Set(n.players.map((e) => e.special?.tile).filter((e) => e !== void 0)), t = [
				2,
				5,
				0,
				1,
				4,
				6,
				3
			].filter((t) => !e.has(t) && !(n.config.niceSandra && t === 3));
			return t.length === 0 ? null : { action: {
				type: "pickSpecialGarage",
				tile: o ? $(t) : t[0]
			} };
		}
		case "select": {
			if (n.current !== i) return null;
			let e = (e, t) => n.players.some((n) => n.dept === e && n.station === t) || !n.sandra.desk && n.sandra.dept === e && n.sandra.station === t, t = (e) => {
				switch (e) {
					case 0: return (n.testQueue.some((e) => a.designs.some((t) => R(t) === e)) && a.garages.includes(null) ? 6 : 0) + a.designs.filter((e) => z(e) !== null).length;
					case 1: return Math.min(4, a.parts.length * 1.5 + a.vouchers);
					case 2: return (a.kanbanCount > 0 ? 3 : 0) + +!!a.certs[2] + .5;
					case 3: return a.designs.length < Vt(a) ? 3 + +!!a.certs[3] : 0;
					default: return 1.5;
				}
			}, r = [], o = [
				0,
				1,
				2,
				3,
				4
			].filter((e) => e !== a.dept && (n.players.length !== 2 || n.sandra.dept !== e)).map((e) => ({
				d: e,
				s: t(e)
			})).sort((e, t) => t.s - e.s);
			for (let { d: t } of o) for (let n of [0, 1]) e(t, n) || r.push({
				type: "selectDept",
				dept: t,
				station: n
			});
			let c = s(r);
			return c ? { action: c } : null;
		}
		case "work": {
			if (n.current !== i) return null;
			let e = s(Kt(n, r, a));
			return e ? { action: e } : null;
		}
		case "meeting": {
			let e = n.meeting;
			if (!e || e.current !== i) return null;
			let t = [];
			if (!e.played[i]) {
				let e = a.speechBoard > 0 || !!a.special?.speechOn, n = r.perfHand.map((e) => ({
					c: e,
					v: Math.min(Wt(L[e].kind, a), L[e].max) * L[e].pp
				})).sort((e, t) => t.v - e.v);
				for (let { c: r } of n) e && t.push({
					type: "meetPlay",
					cardId: r,
					speak: !0
				}), t.push({
					type: "meetPlay",
					cardId: r,
					speak: !1
				});
			} else if (a.speechBoard > 0 || a.special?.speechOn) {
				let n = e.goals.map((e, t) => {
					if (e.tokens.some((e) => e?.seat === i) || e.tokens.every((e) => e !== null)) return null;
					let n = L[e.card], r = e.tokens.findIndex((e) => e === null);
					return {
						gi: t,
						v: Math.min(Wt(n.kind, a), n.max - r) * n.pp
					};
				}).filter((e) => e !== null && e.v > 0).sort((e, t) => t.v - e.v);
				for (let { gi: e } of n) a.speechBoard > 0 && t.push({
					type: "meetSpeak",
					goalIdx: e,
					source: "board"
				}), a.special?.speechOn && t.push({
					type: "meetSpeak",
					goalIdx: e,
					source: "tile"
				});
			}
			e.played[i] && t.push({ type: "meetPass" });
			let o = s(t);
			return o ? { action: o } : null;
		}
		case "meetingContribute": return !n.contribute || n.contribute.indexOf(!1) !== i || r.perfHand.length === 0 ? null : { action: {
			type: "meetContribute",
			cardId: [...r.perfHand].sort((e, t) => Wt(L[e].kind, a) * L[e].pp - Wt(L[t].kind, a) * L[t].pp)[0]
		} };
		case "finalGoals": {
			if (n.current !== i) return null;
			let e = ie[n.finalGoal], t = a.speechBoard + a.genericBeside;
			return { action: {
				type: "claimFinal",
				achievements: e.map((e, t) => ({
					i: t,
					pp: e.pp,
					ok: !a.finalClaimed.includes(t) && e.all.every((e) => Gt(e, a))
				})).filter((e) => e.ok).sort((e, t) => t.pp - e.pp).slice(0, t).map((e) => e.i)
			} };
		}
		default: return null;
	}
};
//#endregion
//#region src/games/kanban/endgame-review.tsx
function Jt({ board: e, renderResult: t, ...n }) {
	let s = l(), [c, u] = o(!0), [d, f] = o(null), p = a(null), _ = a(null), b = a(null);
	r(() => {
		if (!d) return;
		b.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => f(null), 5e3);
		return () => clearTimeout(e);
	}, [d]);
	let x = (e) => {
		f(null), u(e), requestAnimationFrame(() => (e ? p : _).current?.focus({ preventScroll: !0 }));
	}, S = i(() => ({
		onPlayAgain: n.onPlayAgain && (() => f({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => f({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => f({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), C = {
		...n,
		...S
	};
	return /* @__PURE__ */ h("div", {
		className: "kanban-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ m("div", {
				className: "kanban-endgame-board",
				inert: c,
				children: e
			}),
			/* @__PURE__ */ m("div", {
				className: "kanban-endgame-overlay",
				hidden: !c,
				children: /* @__PURE__ */ h("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), x(!1));
					},
					className: "kanban-endgame-panel",
					"aria-label": s("session.result.title"),
					children: [
						/* @__PURE__ */ h("header", {
							className: "kanban-endgame-heading",
							children: [/* @__PURE__ */ h("div", {
								className: "kanban-endgame-brand",
								children: [/* @__PURE__ */ m("span", {
									"aria-hidden": "true",
									children: V.icon
								}), s(V.nameKey)]
							}), /* @__PURE__ */ m("button", {
								type: "button",
								ref: p,
								className: "btn-quiet",
								"aria-label": s("games.kanban.reviewHide"),
								title: s("games.kanban.reviewHide"),
								onClick: () => x(!1),
								children: /* @__PURE__ */ m(v, { size: 19 })
							})]
						}),
						/* @__PURE__ */ m("div", {
							className: "kanban-endgame-result",
							inert: d !== null,
							children: t(C)
						}),
						d && /* @__PURE__ */ h("div", {
							className: "kanban-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || f(null);
							},
							children: [/* @__PURE__ */ m("button", {
								type: "button",
								ref: b,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = d.run;
									f(null), e();
								},
								children: s(d.label === "again" ? "games.kanban.reviewConfirmAgain" : "games.kanban.reviewConfirmLobby")
							}), /* @__PURE__ */ m("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									f(null), p.current?.focus({ preventScroll: !0 });
								},
								children: s("games.kanban.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ m("div", {
				className: "kanban-endgame-toolbar",
				hidden: c,
				children: /* @__PURE__ */ h("button", {
					type: "button",
					className: "btn-base",
					ref: _,
					onClick: () => x(!0),
					children: [
						/* @__PURE__ */ m(y, { size: 18 }),
						s("games.kanban.reviewShow"),
						/* @__PURE__ */ m(g, { size: 18 })
					]
				})
			})
		]
	});
}
function Yt({ result: e, members: t, myRid: r, hintCount: i, onPlayAgain: a, onBackToLobby: s, rows: u, renderRowExtra: d, summary: g, navigation: y, content: x, afterRanking: S, scoreUnit: C, rankOf: w }) {
	let T = l(), E = c((e) => e.locale), [D, ee] = o({}), O = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? f(n, E) : e;
	}, k = (t, n) => w?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), A = e.ranking.some((t) => e.scores?.[t] !== void 0), j = (t, n) => /* @__PURE__ */ h("div", {
		className: "kanban-score-identity",
		children: [
			/* @__PURE__ */ h("span", {
				className: "kanban-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ m("span", {
					"aria-label": T("games.kanban.reviewWinner"),
					children: "♛ "
				}), A && k(t, n)]
			}),
			/* @__PURE__ */ h("span", {
				className: "kanban-score-name",
				children: [O(t), t === r && /* @__PURE__ */ m("small", { children: T("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ h("small", {
				className: "kanban-score-autopilot",
				children: [
					/* @__PURE__ */ m(_, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), M = (t) => e.ranking.map((n) => /* @__PURE__ */ m("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ h("div", {
		className: "kanban-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ m(b, {}),
			y,
			/* @__PURE__ */ h("div", {
				className: "kanban-score-body",
				children: [
					g && /* @__PURE__ */ m("div", {
						className: "kanban-score-summary",
						children: g
					}),
					i !== void 0 && /* @__PURE__ */ m("p", {
						className: "kanban-score-hints",
						children: T("session.hint.usedCount", { n: i })
					}),
					x ?? (u?.length ? /* @__PURE__ */ m("div", {
						className: "kanban-score-table-scroll",
						children: /* @__PURE__ */ h("table", {
							className: "kanban-score-table",
							"aria-label": T(V.nameKey),
							children: [
								/* @__PURE__ */ m("thead", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", { scope: "col" }), /* @__PURE__ */ m(p, { children: e.ranking.map((t, n) => /* @__PURE__ */ m("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: j(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ m("tbody", { children: u.map((e, t) => /* @__PURE__ */ h(n, { children: [/* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ h("button", {
										type: "button",
										"aria-expanded": !!D[t],
										onClick: () => ee((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ m(v, { size: 15 }), e.label]
									}) : e.label
								}), M(e)] }), D[t] && e.details?.map((e, t) => /* @__PURE__ */ h("tr", {
									className: "kanban-score-sub",
									children: [/* @__PURE__ */ m("th", {
										scope: "row",
										children: e.label
									}), M(e)]
								}, t))] }, t)) }),
								A && /* @__PURE__ */ m("tfoot", { children: /* @__PURE__ */ h("tr", { children: [/* @__PURE__ */ m("th", {
									scope: "row",
									children: T("games.kanban.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ m("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ m("ol", {
						className: "kanban-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ h("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ h("div", {
								className: "kanban-score-rankline",
								children: [j(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ h("strong", {
									className: "kanban-score-points",
									children: [e.scores[t], C && /* @__PURE__ */ m("small", { children: C })]
								})]
							}), d?.(t)]
						}, t))
					})),
					S,
					!!u?.length && d && /* @__PURE__ */ m("div", {
						className: "kanban-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ h("details", { children: [/* @__PURE__ */ m("summary", { children: O(e) }), d(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ h("footer", {
				className: "kanban-score-actions",
				children: [
					s && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-quiet",
						onClick: s,
						children: T("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ m("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: T("session.result.playAgain")
					}),
					!a && !s && /* @__PURE__ */ m("p", { children: T("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/games/kanban/game-over.tsx
function Xt(e) {
	let t = l(), n = e.public, r = n.players.find((t) => t.rid === e.myRid), i = (t) => {
		let r = n.players.find((e) => e.rid === t)?.seat, i = 1;
		for (let e of n.result?.ranking ?? []) {
			if (r !== void 0 && e.includes(r)) return i;
			i += e.length;
		}
		return e.result.ranking.indexOf(t) + 1;
	};
	return /* @__PURE__ */ m(Yt, {
		...e,
		scoreUnit: "PP",
		rankOf: i,
		afterRanking: r && /* @__PURE__ */ m("dl", {
			className: "kanban-result-stats",
			children: [
				["games.kanban.uiGarageCars", r.garages.filter((e) => e !== null).length],
				["games.kanban.uiCerts", r.certs.filter(Boolean).length],
				["games.kanban.uiUpgraded", r.upgraded.length]
			].map(([e, n]) => /* @__PURE__ */ h("div", { children: [/* @__PURE__ */ m("dt", { children: t(e) }), /* @__PURE__ */ m("dd", { children: n })] }, e))
		})
	});
}
function Zt(e) {
	return /* @__PURE__ */ m(Jt, {
		...e,
		board: /* @__PURE__ */ m(jt, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ m(Xt, { ...e })
	});
}
//#endregion
//#region src/games/kanban/options.tsx
function Qt({ value: e, onChange: t }) {
	let n = l(), r = oe.safeParse(e), i = r.success ? r.data : oe.parse(void 0), a = (e) => t({
		...i,
		...e
	});
	return /* @__PURE__ */ h(p, { children: [/* @__PURE__ */ h(x, {
		title: n("games.kanban.optVariants"),
		columns: 2,
		children: [
			/* @__PURE__ */ m(S, {
				checked: i.niceSandra,
				label: n("games.kanban.optNice"),
				hint: n("games.kanban.optNiceHint"),
				accent: V.accent,
				onChange: () => a({ niceSandra: !i.niceSandra })
			}),
			/* @__PURE__ */ m(S, {
				checked: i.planner,
				label: n("games.kanban.optPlanner"),
				hint: n("games.kanban.optPlannerHint"),
				accent: V.accent,
				onChange: () => a({ planner: !i.planner })
			}),
			/* @__PURE__ */ m(S, {
				checked: i.expertTuning,
				label: n("games.kanban.optExpert"),
				hint: n("games.kanban.optExpertHint"),
				accent: V.accent,
				onChange: () => a({ expertTuning: !i.expertTuning })
			}),
			/* @__PURE__ */ m(S, {
				checked: i.delayedTuning,
				label: n("games.kanban.optDelayed"),
				hint: n("games.kanban.optDelayedHint"),
				accent: V.accent,
				onChange: () => a({ delayedTuning: !i.delayedTuning })
			})
		]
	}), /* @__PURE__ */ h(x, {
		title: n("games.kanban.optExpansions"),
		columns: 2,
		children: [/* @__PURE__ */ m(S, {
			checked: i.speedcharger,
			label: n("games.kanban.optSpeed"),
			hint: n("games.kanban.optSpeedHint"),
			accent: V.accent,
			onChange: () => a({ speedcharger: !i.speedcharger })
		}), /* @__PURE__ */ m(S, {
			checked: i.specialGarage,
			label: n("games.kanban.optGarage"),
			hint: n("games.kanban.optGarageHint"),
			accent: V.accent,
			onChange: () => a({ specialGarage: !i.specialGarage })
		})]
	})] });
}
//#endregion
//#region .bgparty/cache/pack-entry/kanban/entry.tsx
var $t = {
	definition: nt,
	View: jt,
	bot: qt,
	OverView: Zt,
	Options: Qt,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "看板:电动汽车",
			desc: "Lacerda 工厂桌游:培训认证、看板物流、装配测试,在桑德拉的审视下造出电动车",
			rules: "目标:在电动车工厂中培训、认证、装配与测试,终局绩效点(PP)最高者获胜。\n准备:\n· 工厂设研发、装配、物流、设计、行政五个部门,每个部门各有两个工位。\n· 第一周从入职开始:先在认证轨选择一个空格获得收益,再领取 1 个零件与 1 张设计。\n每天流程:\n· 按巷道顺序,每人选择一个部门工位入座;每天必须更换部门。\n· 两人局中,不能进入桑德拉所在的部门。\n· 随后按顺序轮流工作;桑德拉从第 2 天起每天巡视一个部门。\n工作:\n· 工位提供 2 至 3 个班次，行政部工位提供 1 至 2 个班次。所需班次不足时，可以使用之前积存的存班。\n· 每回合至多使用 3 点存班,一天的总班次至多 4 班。\n· 班次用于培训本部门,或执行本部门任务;行政部需要先指定一个协同部门。\n· 研发部:按测试道位置支付班次领取车辆并将其放入车库,或升级自己的设计。\n· 研发部认证后,每局可以进行一次双重升级。\n· 在装配部，可以向生产线供应零件，推动车辆前进。如果某种车型已有升级零件，必须先为该车型供应升级零件。\n· 物流部:打出看板卡将卡牌图标所示的零件放入仓库(每回合一张),或从仓库收取零件。\n· 物流部认证后,每回合可以领取 1 张零件券。\n· 在设计部，可以领取陈列区中的设计牌。获得设计部认证后，也可以领取设计牌堆顶的牌。\n· 家庭作业:每本书使所在部门的培训前进 1 格,不占用班次。\n· 当天获得的书、零件券与存班,次日才能使用。\n培训与认证:\n· 部门培训前进 3 格时获得认证:选择认证段一个空格,获得收益并解锁部门能力。\n· 前进满 5 格时成为专家,秘密选择一块奖励板块:绩效点、存班、书或零件券。\n装配与测试:\n· 装配供件使车辆沿产线前进;车辆从出场口离开时得分,并进入测试道。\n· 领取车辆时，必须持有同一车型的设计牌。车辆放入车库后，触发该车库砖的收益；使用第五个车库前，必须获得装配部认证。\nSandra 巡视:\n· 评估在场培训最低的玩家:其部门指标不超过 2 则扣除绩效点,存班可减轻惩罚。\n随后，桑德拉执行所在部门的任务：\n· 在研发部，推动配速车。\n· 在装配部，清空产线。\n· 在物流部，压缩仓库。\n· 在设计部，回收陈列中的设计。\n· 巡视行政部时进行周末计分:每辆入库车按该车型升级件与你的测试设计数得分。\n会议:\n· 配速车经过条纹格后,当天工作结束后召开会议。\n· 轮流打出绩效卡并放置发言标记:按达成值与剩余倍率的较低者乘以牌面分值得分。\n· 已经打过绩效卡的玩家可以跳过;全员连续跳过则会议结束。\n· 会议结束后，每名玩家将 1 张绩效卡暗放在自己面前，作为下次会议的目标，再抽取 2 张绩效卡。\n结束:\n· 第二周期第 3 周、或第三周期第 2 周结束时,完成当天流程后进入终局。\n· 先按认证顺序认领终局成就:满足条件的成就每项消耗 1 个发言标记。\n· 再结算存班、发言标记、书、零件券、车库车辆、部门培训排名与测试设计。\n· 总分最高者获胜;平局依次比较车辆数、测试设计数与存班数。\n可选变体与扩展:\n· 友善桑德拉：桑德拉奖励培训进度最高的玩家，不再执行惩罚。使用此变体时，玩家以 0 点绩效点开始游戏。\n· 规划师：可以自行排列车库砖的顺序。领取车辆时，必须将车辆放入最左侧的空车库。\n· 专家调校:车库砖换为收益较弱的专家版。\n· 延迟调校：领取车辆时，将对应的车库砖暗放；必须等到之后的回合，才能翻开该车库砖并使其生效。\n· 快速充电扩展:行政部可以放置充电标记,逐行为全桌解锁能力。\n· 特别车库扩展:第五车库改为特别车库砖,开局每人各选其一。",
			phaseInductCert: "入职:选择认证格",
			phaseInductTake: "入职:领取零件与设计",
			phaseSpecialGarage: "选择特别车库砖",
			phaseSelect: "选择部门",
			phaseWork: "工作",
			phaseMeeting: "会议",
			phaseContribute: "扣置绩效卡",
			phaseFinalGoals: "终局目标",
			phaseOver: "已结束",
			day: "第 {{n}} 天",
			week: "第 {{n}} 周",
			cycle: "周期 {{n}}",
			meetingSoon: "配速车已过线,今天工作结束后召开会议",
			turnYou: "轮到你",
			turnWait: "等待 {{name}}",
			turnSandra: "桑德拉行动中",
			dept0: "研发部",
			dept1: "装配部",
			dept2: "物流部",
			dept3: "设计部",
			dept4: "行政部",
			sandraAt: "桑德拉:{{dept}}",
			sandraDesk: "行政桌",
			stationShifts: "{{n}} 班",
			model0: "城市款",
			model1: "SUV",
			model2: "皮卡",
			model3: "跑车",
			model4: "概念车",
			part0: "自动驾驶",
			part1: "电池",
			part2: "车身",
			part3: "传动",
			part4: "电子",
			part5: "电机",
			selectDeptTitle: "选择部门与工位",
			mustMoveHint: "每天必须更换部门",
			shiftsLeft: "剩余班次 {{n}}",
			train: "培训",
			homework: "家庭作业",
			homeworkHint: "每本书前进 1 格,不占班次",
			useBanked: "使用存班",
			bankedHave: "存班 {{n}}",
			booksHave: "书 {{n}}",
			vouchersHave: "零件券 {{n}}",
			speechHave: "发言 {{b}} · 通用 {{g}}",
			trainLevel: "培训 {{n}}",
			certified: "已认证",
			expert: "专家",
			claim: "提车",
			upgrade: "升级设计",
			upgradeDouble: "双重升级",
			upgradeValue: "零件值 {{n}}",
			provide: "供件",
			provideVoucher: "用零件券供件",
			assemblySlots: "{{n}}/{{cap}}",
			kanbanPlay: "打看板卡",
			side4: "四图标侧",
			side2: "两图标侧",
			collect: "收取零件",
			takeVoucher: "领取零件券",
			takeDesign: "拿取设计",
			takeAdvanced: "堆顶拿取",
			colBonusBank: "该列 +1 存班",
			colBonusBook: "该列 +1 书",
			adminPick: "选择协同部门",
			charge: "放置充电标记",
			chargeRow: "第 {{n}} 行",
			recycle: "回收换件",
			endTurn: "结束回合",
			garage: "车库",
			garageN: "车库 {{n}}",
			garageLocked: "需装配认证",
			pickGarage: "选择库位",
			pickDesign: "选择设计",
			pickPart: "选择零件",
			pickTrack: "选择测试道车辆",
			pickSpace: "选择升级格",
			pickSource: "选择零件来源",
			srcPart: "板上零件",
			srcVoucher: "零件券",
			srcSupply: "供应直取",
			confirm: "确认",
			cancel: "取消",
			branch: "选择车辆移动方向",
			branchExit: "出场({{n}} PP)",
			certPick: "选择认证格",
			certEmpty: "无收益",
			certOrderHint: "每格仅可坐一人;同一段内位置越靠右,会议与终局认领的出手顺序越靠前",
			awardPick: "选择奖励砖",
			award0: "2 PP",
			award1: "存 1 班",
			award2: "1 本书",
			award3: "1 张零件券",
			sgName0: "供应升级",
			sgName1: "双重培训",
			sgName2: "五班",
			sgName3: "免疫评估",
			sgName4: "免费设计",
			sgName5: "车辆双倍计分",
			sgName6: "砖上发言",
			sgDesc0: "未来回合:用供应零件升级 1 张桌上设计",
			sgDesc1: "未来回合:在 2 个不同部门各培训 1 次",
			sgDesc2: "之后每回合至多可工作 5 班",
			sgDesc3: "免疫桑德拉的第一次惩罚",
			sgDesc4: "未来回合:免费拿 1 张设计(得列收益)",
			sgDesc5: "第五车库的车辆终局再计一次分",
			sgDesc6: "立即放 1 个发言标记于砖上,会议可用",
			sgActivate: "激活特别车库",
			sgActive: "已激活",
			flipTile: "翻开车库砖",
			meetingTitle: "会议",
			meetPlay: "打出绩效卡",
			meetPlaySpeak: "打出并发言",
			meetSpeak: "发言",
			meetPass: "跳过",
			meetMustPlay: "须先打出一张绩效卡才能跳过",
			contribute: "扣置 1 张绩效卡作为下次会议目标",
			finalTitle: "终局目标",
			uiResults: "最终成绩",
			uiScore: "总绩效",
			uiRank: "本局排名",
			uiGarageCars: "入库车辆",
			uiCerts: "部门认证",
			uiUpgraded: "升级设计",
			uiAssemblyLanes: "五条装配产线",
			uiTestEmpty: "暂无待测车辆",
			uiOwnedStock: "持有 {{own}} · 仓库 {{stock}}",
			finalClaim: "认领成就(每项 1 发言)",
			finalDone: "等待其他玩家认领",
			claimedAch: "已认领",
			demand: "需求",
			factory: "工厂目标",
			stackFirstTop: "First Office 上堆",
			stackFirstBottom: "First Office 下堆",
			stackCentral: "中央堆",
			displayTitle: "设计陈列",
			testTrack: "测试道",
			warehouses: "仓库",
			recycleBin: "回收区",
			upgradesTitle: "升级格",
			myBoard: "我的玩家板",
			partsHave: "零件",
			designsHave: "设计",
			upgradedHave: "已升级",
			paceCar: "配速车",
			waiting: "等待其他玩家",
			score: "分数",
			perfCars: "车库中每辆车",
			perfModels: "每种不同车型",
			perfModelCars: "每辆{{model}}",
			perfPartUpgrades: "{{part}}的升级设计",
			perfUpgrades: "每个升级设计",
			perfTested: "每个测试设计",
			perfParts2: "板上每个{{a}}或{{b}}",
			perfGaragePair: "车库 {{a}} 与 {{b}} 中每辆车",
			perfCert: "已认证{{dept}}",
			perfDesigns: "桌上每张设计",
			perfBooks: "每本书",
			perfCerts: "每个认证部门",
			perfVouchers: "每张零件券",
			perfBanked: "每点存班",
			perfSpeech: "板上每个发言标记",
			perfChargers: "每个充电标记",
			perfChargerRow: "充电标记位于第 {{n}} 行",
			finSameModelCars: "{{n}} 辆同型号车",
			finCars: "{{n}} 辆车",
			finDistinctModels: "{{n}} 种不同车型",
			finModelCars: "{{n}} 辆{{model}}",
			finDistinctPartUpgrades: "{{n}} 种零件的升级设计",
			finSamePartUpgrades: "{{n}} 个同零件升级设计",
			finPartUpgrades: "{{n}} 个{{part}}升级设计",
			finUpgrades: "{{n}} 个升级设计",
			finTested: "{{n}} 个测试设计",
			finTestedParts: "{{n}} 种零件的测试设计",
			finCerts: "认证 {{n}} 个部门",
			finCertsMax: "认证至多 {{n}} 个部门",
			finCertPair: "认证{{a}}与{{b}}",
			finCertOne: "认证{{a}}",
			finBanked: "存班至少 {{n}}",
			finBooks: "持有 {{n}} 本书",
			finVouchers: "持有 {{n}} 张零件券",
			finExperts: "{{n}} 个部门成为专家",
			finExpertsMax: "至多 {{n}} 个部门成为专家",
			finChargers: "{{n}} 个充电标记",
			finChargerRow: "充电标记在第 {{n}} 行",
			finSpeechBoard: "板上至少 {{n}} 个发言标记",
			gtBasic0: "通用发言",
			gtBasic1: "2 存班",
			gtBasic2: "2 书",
			gtBasic3: "2 零件",
			gtBasic4: "锁:四选二",
			gtExpert0: "空白",
			gtExpert1: "1 零件",
			gtExpert2: "1 书",
			gtExpert3: "1 存班",
			gtExpert4: "通用发言",
			lockPick: "选择两项不同收益",
			gainPartsPick: "从供应选择 {{n}} 个零件",
			designOf: "{{model}} · {{part}}",
			designBase: "{{model}} · 基础",
			optVariants: "变体",
			optExpansions: "扩展",
			optNice: "友善桑德拉",
			optNiceHint: "桑德拉奖励培训最高者而非惩罚;起始 0 PP",
			optPlanner: "规划师",
			optPlannerHint: "车库砖任意排序,提车必须放入最左空库位",
			optExpert: "专家调校",
			optExpertHint: "车库砖换为专家版(收益更弱)",
			optDelayed: "延迟调校",
			optDelayedHint: "提车时选择车库砖放入,之后的回合才能翻开",
			optSpeed: "快速充电扩展",
			optSpeedHint: "行政部放置充电标记,逐行解锁全桌能力",
			optGarage: "特别车库扩展",
			optGarageHint: "第五车库改为特别车库砖,每人各选其一",
			errNotYourTurn: "现在不是你的回合",
			errBadPhase: "当前阶段不能执行此操作",
			errBadChoice: "选择无效",
			errPromptPending: "请先完成待处理的选择",
			errOccupied: "该位置已被占用",
			errMustMove: "每天必须更换部门",
			errSandraDept: "两人局不能进入桑德拉所在部门",
			errNoShift: "没有剩余班次",
			errNoBanked: "存班不足",
			errBankMax: "每回合至多使用 3 点存班,且总班次不超过上限",
			errBadDept: "只能培训当前所在部门",
			errNoBook: "书不足",
			errAdminOnly: "只有行政部可以执行此操作",
			errCapDesigns: "设计桌已满",
			errNoDesign: "没有可用的设计",
			errNeedCert: "需要先获得该部门认证",
			errNoCard: "没有这张手牌",
			errKanbanUsed: "每回合只能打一张看板卡",
			errSupplyEmpty: "供应不足",
			errCapParts: "零件存储位不足",
			errVoucherUsed: "每回合只能领取一张零件券",
			errNoPart: "没有该零件",
			errNoVoucher: "零件券不足",
			errAsmFull: "该车型装配格已满",
			errPartMismatch: "所供零件与该车型已有零件重复",
			errUpgradeFirst: "该车型有升级件,必须先供升级件",
			errNoCar: "测试道上没有该车",
			errDesignMismatch: "设计与车型不匹配",
			errNoGarage: "目标车库位已被占用",
			errGarageLocked: "第五车库需要装配认证",
			errPlanner: "规划师:必须放入最左空库位",
			errBadTile: "车库砖无效",
			errDoubleUsed: "每局只能双重升级一次",
			errDoubled: "该零件已被双重升级过",
			errChargeUsed: "每回合只能放置一个充电标记",
			errChargeRowFull: "该行已有充电标记",
			errSgNoCar: "第五车库有车后才能激活",
			errNotFlippable: "车库砖须等到之后的回合才能翻开",
			errNoSpeech: "没有可用的发言标记",
			errMustPlay: "须先打出一张绩效卡",
			errAlreadyPlayed: "你已经打出过绩效卡",
			errAlreadySpoken: "你已在该目标上放置过发言标记",
			errBadAchievement: "未满足该成就条件"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "Kanban EV",
			desc: "Lacerda factory game: train, certify, run kanban logistics and assembly under Sandra’s watch",
			rules: "Goal: train, certify, assemble and test in the electric-car factory; the highest PP at the end wins.\nSetup:\n· The factory has five departments — R&D, Assembly, Logistics, Design and Administration — each with two workstations.\n· Week one begins with induction: pick a space on the certification track for its bonus, then take 1 part and 1 design.\nEach day:\n· In alley order, each player takes a workstation in a department; you must change departments every day.\n· With two players, you cannot enter Sandra’s department.\n· Players then work in order; from day 2 on, Sandra inspects one department each day.\nWork:\n· A workstation provides 2 to 3 shifts (1 to 2 in Administration); banked shifts can make up the difference.\n· You may use at most 3 banked shifts during a turn. Your total number of shifts for a day cannot exceed 4.\n· Shifts are spent training in your department or performing its tasks; Administration names a partner department first.\n· R&D: spend shifts by test-track position to claim a car into a garage, or upgrade your designs.\n· Once certified in R&D, you may perform one double upgrade per game.\n· Assembly: supply parts to push the line; a model with upgrade parts must receive them first.\n· Logistics: play a kanban card to stock the shown parts (one per turn), or collect parts from the warehouses.\n· Once certified in Logistics, you may take 1 part voucher each turn.\n· Design: take a design from the display; once certified, you may also take from a design stack.\n· Homework: each book advances training in your department by 1 space without spending shifts.\n· Books, vouchers and banked shifts gained today become usable only tomorrow.\nTraining and certification:\n· At 3 training spaces in a department you are certified: pick a space in its certification section for a bonus and unlock its ability.\n· At 5 spaces you become an Expert and secretly pick an award tile: PP, a banked shift, a book or a voucher.\nAssembly and testing:\n· Supplied parts move cars along the line; a car leaving the line scores and enters the test track.\n· Claiming a car requires a design of the same model; garaging triggers the garage tile, and garage 5 requires Assembly certification.\nSandra’s inspection:\n· She evaluates the least-trained players present: anyone whose department metric is at most 2 loses PP; banked shifts soften the penalty.\nSandra then performs the task for her department:\n· In R&D, she advances the pace car.\n· In Assembly, she clears the line.\n· In Logistics, she shrinks the warehouses.\n· In Design, she clears the display.\n· Inspecting Administration triggers weekend scoring: each garaged car scores its model’s upgrade parts plus your tested designs.\nMeeting:\n· After the pace car crosses a striped space, a meeting is held once the day’s work ends.\n· Take turns playing a performance card and placing a speech token: score the lower of your metric and the remaining multiplier, times the card’s value.\n· A player who has played a card may pass; the meeting ends when everyone passes in a row.\n· Afterwards each player sets aside 1 card as the next meeting’s goal and draws 2 cards.\nEnd of the game:\n· The game ends after the day in which cycle 2 week 3, or cycle 3 week 2, is completed.\n· First, in certification order, claim end-game achievements: each claimed achievement costs 1 speech token.\n· Then score banked shifts, speech tokens, books, vouchers, garaged cars, department training ranks and tested designs.\n· The highest total wins; ties break on cars, then tested designs, then banked shifts.\nVariants and expansions (optional):\n· Nice Sandra: she rewards the most-trained instead of punishing, and players start at 0 PP.\n· The Planner: garage tiles are freely ordered, but claimed cars must go to the leftmost empty garage.\n· Expert Tuning: garage tiles are replaced by the weaker expert set.\n· Delayed Tuning: garage tiles are placed face down when claiming a car and flip on a later turn.\n· Speedcharger expansion: Administration places charge markers, unlocking table-wide abilities row by row.\n· Special Garage expansion: garage 5 becomes a special garage tile, drafted by each player at the start.",
			phaseInductCert: "Induction: pick a certification space",
			phaseInductTake: "Induction: take a part and a design",
			phaseSpecialGarage: "Pick a special garage tile",
			phaseSelect: "Choose department",
			phaseWork: "Work",
			phaseMeeting: "Meeting",
			phaseContribute: "Set aside a card",
			phaseFinalGoals: "End-game goals",
			phaseOver: "Finished",
			day: "Day {{n}}",
			week: "Week {{n}}",
			cycle: "Cycle {{n}}",
			meetingSoon: "Pace car crossed a stripe: meeting after today’s work",
			turnYou: "Your turn",
			turnWait: "Waiting for {{name}}",
			turnSandra: "Sandra is acting",
			dept0: "R&D",
			dept1: "Assembly",
			dept2: "Logistics",
			dept3: "Design",
			dept4: "Administration",
			sandraAt: "Sandra: {{dept}}",
			sandraDesk: "Admin desk",
			stationShifts: "{{n}} shifts",
			model0: "City",
			model1: "SUV",
			model2: "Truck",
			model3: "Sport",
			model4: "Concept",
			part0: "Autopilot",
			part1: "Battery",
			part2: "Body",
			part3: "Drivetrain",
			part4: "Electronics",
			part5: "Motor",
			selectDeptTitle: "Choose department and workstation",
			mustMoveHint: "You must change department every day",
			shiftsLeft: "{{n}} shifts left",
			train: "Train",
			homework: "Homework",
			homeworkHint: "1 book advances 1 space, costs no shift",
			useBanked: "Use banked shifts",
			bankedHave: "Banked {{n}}",
			booksHave: "Books {{n}}",
			vouchersHave: "Vouchers {{n}}",
			speechHave: "Speech {{b}} · generic {{g}}",
			trainLevel: "Training {{n}}",
			certified: "Certified",
			expert: "Expert",
			claim: "Claim car",
			upgrade: "Upgrade design",
			upgradeDouble: "Double upgrade",
			upgradeValue: "Part value {{n}}",
			provide: "Supply part",
			provideVoucher: "Supply via voucher",
			assemblySlots: "{{n}}/{{cap}}",
			kanbanPlay: "Play kanban card",
			side4: "4-icon side",
			side2: "2-icon side",
			collect: "Collect parts",
			takeVoucher: "Take a voucher",
			takeDesign: "Take design",
			takeAdvanced: "Take from stack",
			colBonusBank: "This column +1 banked shift",
			colBonusBook: "This column +1 book",
			adminPick: "Choose partner department",
			charge: "Place charging marker",
			chargeRow: "Row {{n}}",
			recycle: "Recycle swap",
			endTurn: "End turn",
			garage: "Garage",
			garageN: "Garage {{n}}",
			garageLocked: "Assembly certification required",
			pickGarage: "Pick garage",
			pickDesign: "Pick design",
			pickPart: "Pick part",
			pickTrack: "Pick test track car",
			pickSpace: "Pick upgrade space",
			pickSource: "Pick part source",
			srcPart: "Board part",
			srcVoucher: "Voucher",
			srcSupply: "From supply",
			confirm: "Confirm",
			cancel: "Cancel",
			branch: "Choose where the car moves",
			branchExit: "Exit ({{n}} PP)",
			certPick: "Pick certification space",
			certEmpty: "No bonus",
			certOrderHint: "One player per space; within a section, spaces further right act earlier in meetings and end-game claims",
			awardPick: "Pick award tile",
			award0: "2 PP",
			award1: "Bank 1 shift",
			award2: "1 book",
			award3: "1 voucher",
			sgName0: "Supply upgrade",
			sgName1: "Double training",
			sgName2: "Five shifts",
			sgName3: "Evaluation immunity",
			sgName4: "Free design",
			sgName5: "Double car scoring",
			sgName6: "Speech on tile",
			sgDesc0: "Future turn: upgrade 1 design with a supply part",
			sgDesc1: "Future turn: train once each in 2 different departments",
			sgDesc2: "From now on work up to 5 shifts per turn",
			sgDesc3: "Immune to Sandra’s first penalty",
			sgDesc4: "Future turn: take 1 design for free (column bonus included)",
			sgDesc5: "The car in garage 5 scores twice at the end",
			sgDesc6: "Place 1 speech token on the tile, usable in meetings",
			sgActivate: "Activate special garage",
			sgActive: "Activated",
			flipTile: "Flip garage tile",
			meetingTitle: "Meeting",
			meetPlay: "Play performance card",
			meetPlaySpeak: "Play and speak",
			meetSpeak: "Speak",
			meetPass: "Pass",
			meetMustPlay: "Play a performance card before passing",
			contribute: "Set aside 1 card as the next meeting goal",
			finalTitle: "End-game goal",
			uiResults: "Final results",
			uiScore: "Total performance",
			uiRank: "Ranking",
			uiGarageCars: "Garage cars",
			uiCerts: "Certifications",
			uiUpgraded: "Upgraded designs",
			uiAssemblyLanes: "Five assembly lines",
			uiTestEmpty: "No cars awaiting test",
			uiOwnedStock: "Own {{own}} · Stock {{stock}}",
			finalClaim: "Claim achievements (1 speech each)",
			finalDone: "Waiting for others to claim",
			claimedAch: "Claimed",
			demand: "Demand",
			factory: "Factory goals",
			stackFirstTop: "First Office top",
			stackFirstBottom: "First Office bottom",
			stackCentral: "Central stack",
			displayTitle: "Design display",
			testTrack: "Test track",
			warehouses: "Warehouses",
			recycleBin: "Recycling",
			upgradesTitle: "Upgrade spaces",
			myBoard: "My player board",
			partsHave: "Parts",
			designsHave: "Designs",
			upgradedHave: "Upgraded",
			paceCar: "Pace car",
			waiting: "Waiting for others",
			score: "Score",
			perfCars: "Per car in garages",
			perfModels: "Per distinct model",
			perfModelCars: "Per {{model}}",
			perfPartUpgrades: "Upgraded designs for {{part}}",
			perfUpgrades: "Per upgraded design",
			perfTested: "Per tested design",
			perfParts2: "Per {{a}} or {{b}} on board",
			perfGaragePair: "Per car in garages {{a}} and {{b}}",
			perfCert: "Certified in {{dept}}",
			perfDesigns: "Per design on board",
			perfBooks: "Per book",
			perfCerts: "Per certified department",
			perfVouchers: "Per voucher",
			perfBanked: "Per banked shift",
			perfSpeech: "Per speech token on board",
			perfChargers: "Per charging marker",
			perfChargerRow: "Charging marker in row {{n}}",
			finSameModelCars: "{{n}} cars of one model",
			finCars: "{{n}} cars",
			finDistinctModels: "{{n}} distinct models",
			finModelCars: "{{n}} {{model}}",
			finDistinctPartUpgrades: "Upgrades in {{n}} distinct parts",
			finSamePartUpgrades: "{{n}} upgrades of one part",
			finPartUpgrades: "{{n}} {{part}} upgrades",
			finUpgrades: "{{n}} upgraded designs",
			finTested: "{{n}} tested designs",
			finTestedParts: "Tested designs in {{n}} parts",
			finCerts: "Certify {{n}} departments",
			finCertsMax: "Certify at most {{n}} departments",
			finCertPair: "Certify {{a}} and {{b}}",
			finCertOne: "Certify {{a}}",
			finBanked: "At least {{n}} banked shifts",
			finBooks: "Hold {{n}} books",
			finVouchers: "Hold {{n}} vouchers",
			finExperts: "Expert in {{n}} departments",
			finExpertsMax: "Expert in at most {{n}} departments",
			finChargers: "{{n}} charging markers",
			finChargerRow: "Charging marker in row {{n}}",
			finSpeechBoard: "At least {{n}} speech tokens on board",
			gtBasic0: "Generic speech",
			gtBasic1: "2 banked shifts",
			gtBasic2: "2 books",
			gtBasic3: "2 parts",
			gtBasic4: "Lock: pick 2 of 4",
			gtExpert0: "Blank",
			gtExpert1: "1 part",
			gtExpert2: "1 book",
			gtExpert3: "1 banked shift",
			gtExpert4: "Generic speech",
			lockPick: "Pick two different bonuses",
			gainPartsPick: "Pick {{n}} parts from supply",
			designOf: "{{model}} · {{part}}",
			designBase: "{{model}} · base",
			optVariants: "Variants",
			optExpansions: "Expansions",
			optNice: "Nice Sandra",
			optNiceHint: "Sandra rewards the most trained instead of punishing; start at 0 PP",
			optPlanner: "The Planner",
			optPlannerHint: "Arrange garage tiles freely; cars must go to the leftmost free garage",
			optExpert: "Expert Tuning",
			optExpertHint: "Use expert garage tiles (weaker bonuses)",
			optDelayed: "Delayed Tuning",
			optDelayedHint: "Place a garage tile when claiming a car; flip it on a later turn",
			optSpeed: "Speedcharger expansion",
			optSpeedHint: "Place charging markers in Administration to unlock row abilities",
			optGarage: "Special Garage expansion",
			optGarageHint: "Garage 5 becomes a special tile; each player picks one",
			errNotYourTurn: "Not your turn",
			errBadPhase: "This action is not available now",
			errBadChoice: "Invalid choice",
			errPromptPending: "Finish the pending choice first",
			errOccupied: "That space is occupied",
			errMustMove: "You must change department every day",
			errSandraDept: "In a 2-player game you cannot enter Sandra’s department",
			errNoShift: "No shifts left",
			errNoBanked: "Not enough banked shifts",
			errBankMax: "At most 3 banked shifts per turn, within the shift cap",
			errBadDept: "You can only train in your current department",
			errNoBook: "Not enough books",
			errAdminOnly: "Only Administration can do this",
			errCapDesigns: "Design table is full",
			errNoDesign: "No design available",
			errNeedCert: "Certification in that department required",
			errNoCard: "You do not have that card",
			errKanbanUsed: "Only one kanban card per turn",
			errSupplyEmpty: "Supply exhausted",
			errCapParts: "Part storage full",
			errVoucherUsed: "Only one voucher per turn",
			errNoPart: "You do not have that part",
			errNoVoucher: "Not enough vouchers",
			errAsmFull: "That model’s assembly spaces are full",
			errPartMismatch: "Part duplicates one already supplied for that model",
			errUpgradeFirst: "Upgraded parts must be supplied first for that model",
			errNoCar: "No such car on the test track",
			errDesignMismatch: "Design does not match the model",
			errNoGarage: "That garage is occupied",
			errGarageLocked: "Garage 5 requires Assembly certification",
			errPlanner: "The Planner: must use the leftmost free garage",
			errBadTile: "Invalid garage tile",
			errDoubleUsed: "Double upgrade usable once per game",
			errDoubled: "That part was already double-upgraded",
			errChargeUsed: "Only one charging marker per turn",
			errChargeRowFull: "That row already has a marker",
			errSgNoCar: "A car in garage 5 is required to activate",
			errNotFlippable: "Garage tiles flip only on a later turn",
			errNoSpeech: "No speech token available",
			errMustPlay: "Play a performance card first",
			errAlreadyPlayed: "You already played a card",
			errAlreadySpoken: "You already spoke on that goal",
			errBadAchievement: "Achievement conditions not met"
		}
	}
};
//#endregion
export { $t as default };
