import { randomIntAt as e } from "@bgparty/sdk/core";
import { z as t } from "zod";
import { useEffect as n, useRef as r, useState as i } from "react";
import { DeltaNumber as a, PhaseBanner as o, PlayerStrip as s } from "@bgparty/sdk/ui";
import { GameScreen as c } from "@bgparty/sdk/ui/game-screen";
import { seatName as l } from "@bgparty/sdk/ui/player-strip";
import { useI18nSettings as u, useT as d } from "@bgparty/sdk/i18n";
import { useFxAnchor as f } from "@bgparty/sdk/fx/anchors";
import { useWakeLock as p } from "@bgparty/sdk/use-wake-lock";
import { IconBot as m, IconClose as h } from "@bgparty/sdk/icons";
import { gameAssetUrl as g } from "@bgparty/sdk/assets";
import { Fragment as _, jsx as v, jsxs as y } from "react/jsx-runtime";
import { FlySprite as b, PulseBox as x } from "@bgparty/sdk/fx/primitives";
import { ConfirmButton as S } from "@bgparty/sdk/confirm-button";
//#region src/games/london/data.ts
var C = (e, t, n = {}) => ({
	name: e,
	colour: t,
	...n
}), w = C("games.london.cards.paupers", "grey", {
	effect: "none",
	flip: !1
}), T = C("games.london.cards.hospital", "blue", {
	cost: 2,
	end: 3,
	effect: "hospital",
	flip: !1
}), E = C("games.london.cards.shops", "brown", {
	effect: "shops",
	vp: 2,
	relief: 1
}), D = C("games.london.cards.sewers", "blue", {
	cost: 4,
	relief: 3
}), O = C("games.london.cards.underground", "pink", {
	cost: 7,
	activation: "card",
	effect: "underground"
}), k = {
	A: [
		C("games.london.cards.almshouses", "brown", { relief: 2 }),
		C("games.london.cards.bank", "brown", {
			money: 2,
			vp: 2
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.coffee", "brown", {
			effect: "coffee",
			flip: !1
		})),
		C("games.london.cards.covent", "brown", {
			money: 5,
			vp: 2
		}),
		C("games.london.cards.eastIndia", "brown", {
			cost: 4,
			activation: "card",
			money: 12
		}),
		C("games.london.cards.fishmongers", "brown", { money: 5 }),
		C("games.london.cards.monument", "pink", {
			cost: 5,
			end: 4,
			effect: "none",
			flip: !1
		}),
		C("games.london.cards.grocers", "brown", { money: 4 }),
		C("games.london.cards.haberdashers", "brown", { money: 4 }),
		T,
		C("games.london.cards.huguenots", "brown", {
			effect: "draw2",
			flip: !1
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.leather", "brown", {
			end: 1,
			money: 7,
			poverty: 1
		})),
		C("games.london.cards.mercers", "brown", { money: 5 }),
		w,
		w,
		C("games.london.cards.salters", "brown", { money: 4 }),
		C("games.london.cards.stPauls", "blue", {
			cost: 8,
			end: 6,
			effect: "none",
			flip: !1
		}),
		C("games.london.cards.stock", "brown", { effect: "stock" }),
		C("games.london.cards.vauxhall", "blue", {
			money: 2,
			vp: 2,
			relief: 1
		}),
		C("games.london.cards.vintners", "brown", { money: 4 }),
		...Array.from({ length: 2 }, () => C("games.london.cards.water", "blue", {
			cost: 1,
			end: 1,
			relief: 2
		})),
		C("games.london.cards.woolwich", "pink", {
			activation: 7,
			vp: 5
		}),
		C("games.london.cards.wren", "blue", {
			effect: "wren",
			flip: !1
		})
	],
	B: [
		C("games.london.cards.albertDock", "brown", {
			cost: 2,
			end: 2,
			activation: "card",
			money: 10,
			vp: 1
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.brewing", "brown", {
			cost: 2,
			end: 1,
			activation: "card",
			money: 9
		})),
		...Array.from({ length: 2 }, () => C("games.london.cards.bridge", "pink", {
			cost: 2,
			end: 2,
			effect: "bridge",
			flip: !1
		})),
		C("games.london.cards.britishMuseum", "blue", {
			cost: 4,
			end: 2,
			vp: 1,
			relief: 1,
			flip: !1
		}),
		C("games.london.cards.brixton", "pink", { effect: "prison" }),
		C("games.london.cards.buckingham", "blue", {
			cost: 10,
			end: 7,
			effect: "none",
			flip: !1
		}),
		C("games.london.cards.clockmakers", "brown", {
			end: 1,
			money: 7
		}),
		C("games.london.cards.fire", "pink", {
			effect: "fire",
			vp: 2
		}),
		C("games.london.cards.highgate", "pink", {
			cost: 4,
			end: 2,
			relief: 2
		}),
		T,
		T,
		C("games.london.cards.kew", "blue", {
			cost: 7,
			end: 4,
			relief: 1,
			flip: !1
		}),
		C("games.london.cards.lloyds", "pink", {
			effect: "lloyds",
			money: 5
		}),
		C("games.london.cards.millbank", "pink", {
			cost: 5,
			effect: "millbank"
		}),
		C("games.london.cards.nelson", "blue", {
			cost: 8,
			end: 5,
			effect: "none",
			flip: !1
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.omnibus", "brown", {
			effect: "omnibus",
			flip: !1
		})),
		C("games.london.cards.oxford", "brown", {
			cost: 4,
			money: 8,
			vp: 2,
			relief: 1
		}),
		w,
		w,
		w,
		w,
		C("games.london.cards.police", "pink", {
			cost: 2,
			effect: "police",
			vp: 2,
			relief: 1
		}),
		C("games.london.cards.regent", "pink", {
			cost: 2,
			end: 2,
			money: 3,
			vp: 2,
			relief: 1
		}),
		C("games.london.cards.victoriaDock", "brown", {
			cost: 2,
			end: 2,
			activation: "card",
			money: 10,
			vp: 1
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.shipbuilding", "brown", {
			cost: 2,
			end: 1,
			activation: "card",
			money: 6,
			vp: 2
		})),
		E,
		E,
		...Array.from({ length: 2 }, () => C("games.london.cards.steamboats", "brown", { effect: "boats" })),
		...Array.from({ length: 2 }, () => C("games.london.cards.lights", "blue", {
			activation: 4,
			vp: 1,
			relief: 2,
			flip: !1
		})),
		...Array.from({ length: 2 }, () => C("games.london.cards.townhouses", "blue", {
			cost: 4,
			effect: "town"
		})),
		...Array.from({ length: 2 }, () => C("games.london.cards.turners", "brown", {
			end: 1,
			money: 6
		})),
		C("games.london.cards.university", "blue", {
			end: 1,
			vp: 1,
			relief: 1,
			flip: !1
		}),
		C("games.london.cards.upholders", "brown", {
			end: 1,
			money: 6
		}),
		C("games.london.cards.westIndia", "brown", {
			end: 2,
			activation: "card",
			money: 7
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.workers", "brown", { relief: 2 }))
	],
	C: [
		C("games.london.cards.albertHall", "blue", {
			cost: 5,
			end: 3,
			vp: 2
		}),
		C("games.london.cards.billingsgate", "brown", { money: 8 }),
		C("games.london.cards.grandHotel", "brown", {
			money: 4,
			flip: !1
		}),
		C("games.london.cards.exhibition", "pink", {
			cost: 3,
			activation: "card",
			vp: 5
		}),
		...Array.from({ length: 2 }, () => C("games.london.cards.refugees", "brown", {
			effect: "draw2",
			flip: !1
		})),
		C("games.london.cards.naturalMuseum", "blue", {
			cost: 6,
			end: 1,
			vp: 2,
			relief: 1,
			flip: !1
		}),
		w,
		w,
		w,
		w,
		w,
		D,
		D,
		D,
		D,
		D,
		E,
		E,
		C("games.london.cards.smithfield", "brown", {
			money: 8,
			relief: 1
		}),
		C("games.london.cards.embankment", "pink", {
			cost: 6,
			end: 4,
			relief: 1
		}),
		C("games.london.cards.towerBridge", "pink", {
			cost: 6,
			end: 4,
			effect: "bridge"
		}),
		C("games.london.cards.trainNorth", "brown", {
			cost: 3,
			end: 3,
			activation: "card",
			effect: "north",
			relief: 1
		}),
		C("games.london.cards.trainNorth", "brown", {
			cost: 3,
			end: 3,
			activation: "card",
			effect: "north",
			relief: 1
		}),
		C("games.london.cards.trainSouth", "brown", {
			cost: 3,
			end: 3,
			activation: "card",
			effect: "south",
			relief: 1
		}),
		O,
		O,
		O,
		O,
		O,
		C("games.london.cards.whitehall", "pink", {
			cost: 4,
			end: 1,
			effect: "whitehall"
		})
	]
}, A = [
	"A",
	"B",
	"C"
].flatMap((e) => k[e].map((t, n) => ({
	cost: 0,
	end: 0,
	activation: 0,
	money: 0,
	vp: 0,
	relief: 0,
	poverty: 0,
	flip: !0,
	effect: "basic",
	...t,
	id: (e === "A" ? 0 : e === "B" ? 26 : 70) + n,
	era: e,
	art: n
}))), j = (e, t, n, r, i, a, o, s = !1, c = "none") => ({
	id: e,
	name: t,
	cost: n,
	draw: r,
	vp: i,
	relief: a,
	side: o,
	river: s,
	ability: c
}), M = [
	j(0, "games.london.boroughs.battersea", 5, 1, 3, 1, "S", !0, "battersea"),
	j(1, "games.london.boroughs.bethnal", 5, 5, 2, 2, "N"),
	j(2, "games.london.boroughs.camberwell", 5, 2, 3, 2, "S"),
	j(3, "games.london.boroughs.city", 8, 4, 6, 4, "N", !0, "loan"),
	j(4, "games.london.boroughs.deptford", 6, 3, 2, 4, "S", !0),
	j(5, "games.london.boroughs.fulham", 7, 2, 5, 2, "N", !0),
	j(6, "games.london.boroughs.greenwich", 6, 3, 1, 3, "S", !0, "greenwich"),
	j(7, "games.london.boroughs.hackney", 6, 5, 2, 1, "N", !1, "colour"),
	j(8, "games.london.boroughs.hammersmith", 8, 3, 2, 1, "N", !0, "hammersmith"),
	j(9, "games.london.boroughs.hampstead", 7, 2, 6, 2, "N"),
	j(10, "games.london.boroughs.islington", 5, 4, 2, 3, "N"),
	j(11, "games.london.boroughs.kensington", 7, 2, 4, 1, "N", !1, "colour"),
	j(12, "games.london.boroughs.lambeth", 5, 4, 3, 1, "S", !0, "colour"),
	j(13, "games.london.boroughs.lewisham", 5, 5, 1, 4, "S"),
	j(14, "games.london.boroughs.paddington", 5, 3, 2, 1, "N", !1, "paddington"),
	j(15, "games.london.boroughs.southwark", 5, 4, 1, 2, "S", !0, "swap"),
	j(16, "games.london.boroughs.marylebone", 5, 3, 4, 2, "N"),
	j(17, "games.london.boroughs.pancras", 9, 3, 7, 1, "N", !1, "peek"),
	j(18, "games.london.boroughs.wandsworth", 7, 2, 2, 1, "S", !0, "wandsworth"),
	j(19, "games.london.boroughs.westminster", 8, 2, 4, 2, "N", !0, "westminster")
], N = (e) => ["wren", "draw2"].includes(A[e].effect), ee = (e) => A[e].colour !== "grey" && !N(e), P = {
	id: "london",
	tier: "alpha",
	nameKey: "games.london.name",
	descKey: "games.london.desc",
	rulesKey: "games.london.rules",
	icon: "🏛️",
	iconImg: "games/london.webp",
	minPlayers: 2,
	maxPlayers: 4,
	bestPlayers: [3, 4],
	mechanics: ["hand-management", "engine-building"],
	interactionTags: [],
	accent: "#385a67",
	releasedAt: "2026-10-31T12:42:00+08:00",
	search: {
		py: "lun dun",
		init: "ld"
	},
	hotseat: "cover",
	rulesUrl: { en: "https://drive.google.com/file/d/0B2UGzFKyUbhOc29QV2hWZUc5WXM/view" }
}, F = t.int().min(0).max(100), te = t.int().min(-1).max(100), ne = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("begin"),
		count: t.int().min(0).max(2).default(1),
		peek: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("draw"),
		source: t.int().min(-1).max(100)
	}),
	t.object({
		type: t.literal("peek"),
		card: F
	}),
	t.object({
		type: t.literal("choose"),
		action: t.enum([
			"develop",
			"run",
			"draw"
		])
	}),
	t.object({
		type: t.literal("buy"),
		borough: t.int().min(0).max(19)
	}),
	t.object({
		type: t.literal("build"),
		card: F,
		pay: F.nullable(),
		stack: te,
		recolour: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("action"),
		card: F
	}),
	t.object({
		type: t.literal("activate"),
		stack: t.int().nonnegative().max(100),
		discard: t.array(F).max(10).default([]),
		target: t.string().optional(),
		copy: t.int().nonnegative().max(100).optional(),
		board: F.optional(),
		hospital: t.int().nonnegative().max(100).optional()
	}),
	t.object({
		type: t.literal("borough"),
		discard: t.array(F).max(20).default([])
	}),
	t.object({
		type: t.literal("swap"),
		discard: F,
		take: F,
		recolour: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("discard"),
		card: F
	}),
	t.object({ type: t.literal("loan") }),
	t.object({ type: t.literal("repay") }),
	t.object({ type: t.literal("finish") })
]), re = t.enum([
	"start",
	"draw",
	"peek",
	"choose",
	"develop",
	"run",
	"overflow",
	"done"
]), ie = t.object({
	id: F.nullable(),
	down: t.boolean(),
	coins: t.int().nonnegative(),
	placed: t.int().nonnegative()
}), ae = t.object({
	prestige: t.int(),
	buildings: t.int(),
	cash: t.int(),
	loans: t.int(),
	poverty: t.int(),
	total: t.int(),
	adjustedPoverty: t.int(),
	repaid: t.int()
}), I = t.object({
	rid: t.string(),
	cash: t.int().nonnegative(),
	prestige: t.int(),
	poverty: t.int().nonnegative(),
	loans: t.int().nonnegative(),
	handCount: t.int().nonnegative(),
	boroughs: t.array(t.int().min(0).max(19)),
	stacks: t.array(t.array(ie)),
	final: ae.nullable()
}), L = t.object({
	kind: t.enum([
		"build",
		"buy",
		"activate",
		"loan",
		"repay",
		"run",
		"draw",
		"discard",
		"action",
		"swap",
		"borough"
	]),
	rid: t.string(),
	card: t.int().nullable(),
	n: t.int()
}), R = t.object({
	phase: re,
	turn: t.string(),
	turnNo: t.int(),
	deckCount: t.int().nonnegative(),
	era: t.enum([
		"A",
		"B",
		"C"
	]).nullable(),
	board: t.array(t.array(F.nullable())),
	market: t.array(t.int().min(0).max(19)),
	boroughCount: t.int().nonnegative(),
	players: t.array(I),
	remaining: t.int().nullable(),
	drawRemaining: t.int().nonnegative(),
	freeBuilds: t.int().nonnegative(),
	developed: t.int().nonnegative(),
	used: t.array(F),
	boroughUsed: t.boolean(),
	swapUsed: t.boolean(),
	log: t.array(L)
}), z = t.object({
	hand: t.array(F),
	peek: t.array(F)
}), B = (e) => e[e.length - 1], V = (e) => M[e.boroughs[e.boroughs.length - 1]], H = (e) => e.stacks.map(B).filter((e) => !e.down), U = (e) => e <= 2 ? +!!e : e <= 4 ? e - 1 : e <= 10 ? e * 2 - 5 : 15 + (e - 10) * 3, W = () => ({ code: "games.london.invalid" }), G = (e, t, n, r = null, i = 0) => {
	e.log.push({
		kind: t,
		rid: n.rid,
		card: r,
		n: i
	});
};
function oe(t, n) {
	for (let r = n.length - 1; r > 0; r--) {
		let i = e(t.seed, t.cursor++, r + 1);
		[n[r], n[i]] = [n[i], n[r]];
	}
	return n;
}
function se(e, t) {
	let n = V(t)?.ability === "loan" ? 12 : 10;
	t.cash += n, t.loans++, G(e, "loan", t, null, n);
}
function K(e, t, n) {
	for (; t.cash < n;) se(e, t);
	t.cash -= n;
}
function q(e, t) {
	let n = e.board.find((e) => e.includes(null));
	n ||= (e.removed.push(...e.board[1].filter((e) => e !== null)), e.board[1] = [...e.board[0]], e.board[0] = e.board[0].map(() => null), e.board[0]), n[n.indexOf(null)] = t;
}
function ce(e, t) {
	for (let n of e.board) {
		let e = n.indexOf(t);
		if (e >= 0) return n[e] = null, !0;
	}
	return !1;
}
var le = (e) => e.deck.length + e.board.flat().filter((e) => e !== null).length;
function J(e, t) {
	e.hand.splice(e.hand.indexOf(t), 1);
}
function Y(e, t) {
	e.poverty = Math.max(0, e.poverty + t);
}
function ue(e, t, n, r) {
	K(e, t, A[n].cost);
	let i = {
		id: n,
		down: !1,
		coins: 0,
		placed: e.turnNo
	};
	r === -1 ? t.stacks.push([i]) : t.stacks[r].push(i);
	for (let e of H(t)) A[e.id].effect === "shops" && e.coins++;
	G(e, "build", t, n);
}
function de(e) {
	for (let t of e.players) t.poverty += t.hand.length, e.removed.push(...t.hand), t.hand = [];
	let t = Math.min(...e.players.map((e) => e.poverty));
	for (let n of e.players) {
		let e = n.stacks.flat().reduce((e, t) => e + A[t.id].end, 0), r = Math.min(n.loans, Math.floor(n.cash / 15));
		n.cash -= r * 15, n.loans -= r, n.poverty -= t;
		let i = Math.floor(n.cash / 3), a = n.loans * 7, o = U(n.poverty);
		n.final = {
			prestige: n.prestige,
			buildings: e,
			cash: i,
			loans: a,
			poverty: o,
			total: n.prestige + e + i - a - o,
			adjustedPoverty: n.poverty,
			repaid: r
		};
	}
	e.phase = "done";
}
function fe(e) {
	if (e.remaining !== null) {
		if (e.remaining--, e.remaining === 0) {
			de(e);
			return;
		}
	} else e.deck.length || (e.remaining = e.players.length - 1);
	e.turn = (e.turn + 1) % e.players.length, e.turnNo++, e.phase = "start", e.used = [], e.boroughUsed = !1, e.swapUsed = !1, e.developed = 0, e.freeBuilds = 0, e.drawRemaining = 0;
}
function pe(e) {
	e.players[e.turn].hand.length > 9 ? e.phase = "overflow" : fe(e);
}
function me(e) {
	e.drawRemaining && le(e) || (e.drawRemaining = 0, e.resume === "end" ? pe(e) : e.phase = e.resume);
}
function he(e, t, n) {
	e.phase = "draw", e.drawRemaining = t, e.resume = n, me(e);
}
function ge(e, t) {
	return new Set(t).size === t.length && t.every((t) => e.hand.includes(t));
}
function _e(e, t, n) {
	for (let r of n) J(t, r), q(e, r);
}
function ve(e, t, n, r) {
	let i = e.players.find((e) => e.rid === r), a = t.players.find((e) => e.rid === r), o = [], s = (e, t, n, i = !1) => o.push({
		kind: "londonMove",
		rid: r,
		with: o.length > 0,
		data: {
			card: i ? null : e,
			from: t,
			to: i ? `london-hand:${r}` : n
		},
		...i ? {
			for: [r],
			secret: { card: e }
		} : {}
	}), c = (e, t, n = r, i = !1) => o.push({
		kind: "londonRetire",
		rid: n,
		with: o.length > 0,
		data: {
			card: i ? null : e,
			from: t
		},
		...i ? {
			for: [n],
			secret: { card: e }
		} : {}
	}), l = (e, t) => {
		for (let n = 0; n < e.board.length; n++) {
			let r = e.board[n].indexOf(t);
			if (r >= 0) return `london-boardslot:${n}:${r}`;
		}
		return "london-board";
	};
	for (let e of i.hand) if (!a.hand.includes(e)) {
		if (t.phase === "done" && t.removed.includes(e)) continue;
		let n = a.stacks.findIndex((t) => B(t).id === e);
		t.removed.includes(e) ? c(e, `london-hand:${r}`) : s(e, `london-hand:${r}`, n >= 0 ? `london-stack:${r}:${n}` : l(t, e));
	}
	for (let n of e.board.flat()) n !== null && (!e.removed.includes(n) && t.removed.includes(n) ? c(n, l(e, n)) : t.board.flat().includes(n) && l(e, n) !== l(t, n) && s(n, l(e, n), l(t, n)));
	if (t.phase === "done") {
		for (let n of e.players) for (let e of n.hand) t.removed.includes(e) && c(e, `london-hand:${n.rid}`, n.rid, !0);
		return o;
	}
	for (let t of a.hand) i.hand.includes(t) || s(t, e.board.flat().includes(t) ? l(e, t) : "london-deck", `london-handcard:${t}`, !e.board.flat().includes(t));
	if (n.type === "buy" && o.push({
		kind: "londonBorough",
		rid: r,
		with: o.length > 0,
		data: {
			borough: n.borough,
			slot: e.market.indexOf(n.borough)
		}
	}), n.type === "borough" && o.push({
		kind: "londonBoroughActivate",
		rid: r,
		with: o.length > 0,
		data: { borough: i.boroughs.at(-1) }
	}), n.type === "activate") {
		let t = B(i.stacks[n.stack]), c = A[t.id];
		(c.effect === "coffee" || c.effect === "whitehall" && n.copy !== void 0 && A[B(i.stacks[n.copy]).id].effect === "coffee") && s(n.board, l(e, n.board), `london-stack:${r}:${n.stack}`), o.push({
			kind: "londonActivate",
			rid: r,
			with: o.length > 0,
			data: {
				stack: n.stack,
				...n.hospital === void 0 ? {} : { hospital: n.hospital },
				card: n.hospital === void 0 ? t.id : B(i.stacks[n.hospital]).id,
				flip: c.flip && (n.hospital !== void 0 || B(a.stacks[n.stack]).id === t.id)
			}
		});
	}
	return o;
}
function ye(e, t, n) {
	let r = t.stacks[n.stack] && B(t.stacks[n.stack]);
	if (!r || r.down || e.used.includes(r.id)) return !1;
	let i = A[r.id], a = i;
	if (i.effect === "whitehall") {
		let e = n.copy === void 0 ? void 0 : t.stacks[n.copy] && B(t.stacks[n.copy]);
		if (!e || e === r || e.down || [
			"none",
			"hospital",
			"whitehall",
			"wren",
			"draw2"
		].includes(A[e.id].effect)) return !1;
		a = A[e.id];
	}
	if ([
		"none",
		"hospital",
		"wren",
		"draw2"
	].includes(a.effect)) return !1;
	let o = +(i.activation === "card"), s = a.effect === "prison" || a.effect === "millbank";
	if (!ge(t, n.discard) || n.discard.length < o || n.discard.length > o + (s ? 3 : 0) || (a.effect === "lloyds" || a.effect === "police") && !e.players.some((e) => e.rid === n.target) || a.effect === "coffee" && (n.board === void 0 || !e.board.flat().includes(n.board))) return !1;
	let c = n.hospital === void 0 ? void 0 : t.stacks[n.hospital] && B(t.stacks[n.hospital]);
	if (n.hospital !== void 0 && (!i.flip || !c || c.down || c === r || A[c.id].effect !== "hospital")) return !1;
	_e(e, t, n.discard), typeof i.activation == "number" && K(e, t, i.activation), e.used.push(r.id);
	let l = H(t), u = t.boroughs.map((e) => M[e]);
	switch (t.cash += a.money, t.prestige += a.vp, (a.effect === "lloyds" || a.effect === "police") && Y(e.players.find((e) => e.rid === n.target), a.effect === "lloyds" ? 2 : 1), Y(t, a.poverty - a.relief), a.effect) {
		case "stock":
			for (let n of e.players) n !== t && (K(e, n, 2), t.cash += 2);
			break;
		case "bridge":
			t.cash += l.filter((e) => A[e.id].colour === "brown").length;
			break;
		case "town":
			t.prestige += l.filter((e) => A[e.id].colour === "blue" || A[e.id].colour === "pink").length;
			break;
		case "boats":
			t.cash += u.filter((e) => e.river).length * 2;
			break;
		case "north":
		case "south":
			t.cash += u.filter((e) => e.side === (a.effect === "north" ? "N" : "S")).length * 2;
			break;
		case "underground":
			t.prestige += 3 + u.length, u.some((e) => e.side === "N") && u.some((e) => e.side === "S") && K(e, t, 2);
			break;
		case "fire":
			for (let n of e.players) n !== t && K(e, n, n.boroughs.filter((e) => M[e].river).length);
			break;
		case "prison":
		case "millbank": {
			let e = n.discard.length - o;
			Y(t, -e), a.effect === "millbank" && (t.prestige += e);
			break;
		}
		case "omnibus":
		case "shops": {
			let e = i.effect === "whitehall" ? B(t.stacks[n.copy]) : r;
			t.cash += e.coins, e.coins = 0;
			break;
		}
		case "coffee": ce(e, n.board), ue(e, t, n.board, n.stack);
	}
	return i.flip && (c ? c.down = !0 : r.down = !0), G(e, "activate", t, r.id), !0;
}
var be = {
	meta: P,
	saveCompatibility: { version: "1" },
	schemas: {
		action: ne,
		publicView: R,
		privateView: z
	},
	setup(e, t, n) {
		let r = {
			seed: n,
			cursor: 0,
			players: t.map((e) => ({
				rid: e,
				hand: [],
				cash: 5,
				prestige: 0,
				poverty: 0,
				loans: 0,
				boroughs: [],
				stacks: [],
				final: null
			})),
			deck: [],
			boroughDeck: [],
			market: [
				3,
				19,
				15
			],
			board: Array.from({ length: 2 }, () => Array.from({ length: t.length + 1 }, () => null)),
			removed: [],
			phase: "start",
			turn: 0,
			turnNo: 1,
			remaining: null,
			drawRemaining: 0,
			resume: "choose",
			freeBuilds: 0,
			developed: 0,
			used: [],
			boroughUsed: !1,
			swapUsed: !1,
			peek: [],
			log: []
		};
		r.deck = [
			"A",
			"B",
			"C"
		].flatMap((e) => oe(r, A.filter((t) => t.era === e).map((e) => e.id))), r.boroughDeck = oe(r, M.filter((e) => !r.market.includes(e.id)).map((e) => e.id));
		for (let e of r.players) e.hand = r.deck.splice(0, 6);
		return { state: r };
	},
	reduce(e, t, n) {
		if (e.phase === "done" || t.type !== "loan" && e.players[e.turn].rid !== n.by || !e.players.some((e) => e.rid === n.by)) return W();
		let r = structuredClone(e), i = r.players[r.turn], a = r.phase;
		switch (t.type) {
			case "loan":
				se(r, r.players.find((e) => e.rid === n.by));
				break;
			case "repay":
				if (a !== "start" || !i.loans || i.cash < 15) return W();
				i.cash -= 15, i.loans--, G(r, "repay", i);
				break;
			case "begin": {
				if (a !== "start") return W();
				let e = V(i)?.ability;
				if (t.peek) {
					if (e !== "peek" || !r.deck.length) return W();
					r.peek = r.deck.splice(0, 3), r.phase = "peek";
				} else {
					if (e !== "westminster" && t.count !== 1) return W();
					he(r, t.count, "choose");
				}
				break;
			}
			case "peek":
				if (a !== "peek" || !r.peek.includes(t.card)) return W();
				i.hand.push(t.card), r.deck.unshift(...r.peek.filter((e) => e !== t.card)), r.peek = [], r.phase = "choose", G(r, "draw", i, null, 1);
				break;
			case "draw": {
				if (a !== "draw") return W();
				let e = t.source === -1 ? r.deck[0] : t.source;
				if (e === void 0 || t.source !== -1 && !r.board.flat().includes(e)) return W();
				t.source === -1 ? r.deck.shift() : ce(r, e), i.hand.push(e), r.drawRemaining--, G(r, "draw", i, t.source === -1 ? null : e, 1), me(r);
				break;
			}
			case "choose":
				if (a !== "choose") return W();
				if (t.action === "draw") he(r, 3, "end");
				else if (t.action === "develop") {
					let e = V(i)?.ability === "colour";
					if (!i.hand.some((t) => N(t) || ee(t) && (A[t].effect === "coffee" || i.hand.some((n) => n !== t && (e || A[n].colour !== "grey" && A[n].colour === A[t].colour))))) return W();
					r.phase = "develop";
				} else r.phase = "run", r.boroughUsed = ![
					"greenwich",
					"battersea",
					"hammersmith",
					"paddington",
					"swap",
					"wandsworth"
				].includes(V(i)?.ability ?? "");
				break;
			case "buy": {
				if (a !== "choose" || !r.market.includes(t.borough)) return W();
				let e = M[t.borough];
				K(r, i, e.cost), i.boroughs.push(e.id), i.prestige += e.vp, Y(i, -e.relief);
				let n = r.market.indexOf(e.id), o = r.boroughDeck.shift();
				o === void 0 ? r.market.splice(n, 1) : r.market[n] = o;
				for (let e of r.players) for (let t of H(e)) A[t.id].effect === "omnibus" && t.coins++;
				G(r, "buy", i, e.id), he(r, e.draw, "end");
				break;
			}
			case "build": {
				if (a !== "develop" || !i.hand.includes(t.card)) return W();
				let e = A[t.card], n = r.freeBuilds > 0 || e.effect === "coffee";
				if (!r.freeBuilds && !ee(t.card) || t.stack >= i.stacks.length || t.stack >= 0 && B(i.stacks[t.stack]).placed === r.turnNo) return W();
				if (n) {
					if (t.pay !== null || t.recolour) return W();
				} else {
					if (t.pay === null || t.pay === t.card || !i.hand.includes(t.pay)) return W();
					if (t.recolour) {
						if (V(i)?.ability !== "colour") return W();
						K(r, i, 1);
					} else if (A[t.pay].colour !== e.colour || A[t.pay].colour === "grey") return W();
					J(i, t.pay), q(r, t.pay);
				}
				J(i, t.card), ue(r, i, t.card, t.stack), r.developed++, r.freeBuilds && r.freeBuilds--;
				break;
			}
			case "action":
				if (a !== "develop" || r.freeBuilds || !i.hand.includes(t.card) || !N(t.card)) return W();
				J(i, t.card), r.removed.push(t.card), r.developed++, G(r, "action", i, t.card), A[t.card].effect === "wren" ? r.freeBuilds = Math.min(2, i.hand.length) : he(r, 2, "develop");
				break;
			case "activate":
				if (a !== "run" || !ye(r, i, t)) return W();
				break;
			case "borough": {
				if (a !== "run" || r.boroughUsed) return W();
				let e = V(i)?.ability;
				if (!ge(i, t.discard) || e !== "greenwich" && t.discard.length || t.discard.some((e) => A[e].colour !== "grey")) return W();
				if (e === "greenwich") _e(r, i, t.discard), i.cash += t.discard.length, Y(i, -t.discard.length);
				else if (e === "battersea") Y(i, -2);
				else if (e === "hammersmith") Y(i, -1), i.cash += 2;
				else if (e === "paddington") Y(i, -1);
				else if (e === "swap") Y(i, 1);
				else if (e === "wandsworth") Y(i, 2);
				else return W();
				r.boroughUsed = !0, G(r, "borough", i, V(i).id);
				break;
			}
			case "swap":
				if (V(i)?.ability !== "swap" || r.swapUsed || t.discard === t.take || !i.hand.includes(t.discard) || !r.board.flat().includes(t.take) || t.recolour) return W();
				ce(r, t.take), J(i, t.discard), q(r, t.discard), i.hand.push(t.take), r.swapUsed = !0, G(r, "swap", i, t.take);
				break;
			case "discard":
				if (a !== "overflow" || !i.hand.includes(t.card)) return W();
				J(i, t.card), q(r, t.card), G(r, "discard", i, t.card), i.hand.length <= 9 && fe(r);
				break;
			case "finish": if (a === "develop") {
				if (!r.developed) return { code: "games.london.mustDevelop" };
				pe(r);
			} else if (a === "run") {
				if (!r.boroughUsed) return { code: "games.london.mustBorough" };
				let e = i.stacks.length + i.loans + (V(i)?.ability === "wandsworth" ? 0 : i.hand.length);
				Y(i, e), G(r, "run", i, null, e), pe(r);
			} else return W();
		}
		return {
			state: r,
			fx: ve(e, r, t, n.by)
		};
	},
	viewFor(e, t) {
		let n = e.players.find((e) => e.rid === t);
		return {
			public: {
				phase: e.phase,
				turn: e.players[e.turn].rid,
				turnNo: e.turnNo,
				deckCount: e.deck.length,
				era: e.deck.length ? A[e.deck[0]].era : null,
				board: e.board.map((e) => [...e]),
				market: [...e.market],
				boroughCount: e.boroughDeck.length,
				remaining: e.remaining,
				drawRemaining: e.drawRemaining,
				freeBuilds: e.freeBuilds,
				developed: e.developed,
				used: e.phase === "run" ? [...e.used] : [],
				boroughUsed: e.boroughUsed,
				swapUsed: e.swapUsed,
				log: e.log.slice(-120),
				players: e.players.map((t) => ({
					rid: t.rid,
					cash: t.cash,
					prestige: t.prestige,
					poverty: t.poverty,
					loans: t.loans,
					boroughs: [...t.boroughs],
					handCount: t.hand.length,
					final: t.final && { ...t.final },
					stacks: t.stacks.map((t) => t.map((n, r) => ({
						down: n.down,
						id: e.phase === "done" || r === t.length - 1 && !n.down ? n.id : null,
						coins: n.coins,
						placed: n.placed
					})))
				}))
			},
			private: n ? {
				hand: [...n.hand],
				peek: e.players[e.turn].rid === t ? [...e.peek] : []
			} : void 0
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = (e) => Math.max(0, ...e.stacks.flat().map((e) => A[e.id].end)), n = (e, n) => n.final.total - e.final.total || e.poverty - n.poverty || n.boroughs.length - e.boroughs.length || t(n) - t(e), r = [...e.players].sort(n);
		return {
			phase: "done",
			ranking: r.map((e) => e.rid),
			winner: r.filter((e) => !n(e, r[0])).map((e) => e.rid),
			scores: Object.fromEntries(e.players.map((e) => [e.rid, e.final.total]))
		};
	}
}, xe = {
	basic: "games.london.effects.basic",
	none: "games.london.effects.none",
	hospital: "games.london.effects.hospital",
	coffee: "games.london.effects.coffee",
	draw2: "games.london.effects.draw2",
	wren: "games.london.effects.wren",
	stock: "games.london.effects.stock",
	bridge: "games.london.effects.bridge",
	prison: "games.london.effects.prison",
	millbank: "games.london.effects.millbank",
	fire: "games.london.effects.fire",
	lloyds: "games.london.effects.lloyds",
	police: "games.london.effects.police",
	omnibus: "games.london.effects.omnibus",
	shops: "games.london.effects.shops",
	boats: "games.london.effects.boats",
	town: "games.london.effects.town",
	north: "games.london.effects.north",
	south: "games.london.effects.south",
	underground: "games.london.effects.underground",
	whitehall: "games.london.effects.whitehall"
}, Se = {
	none: "games.london.abilities.none",
	loan: "games.london.abilities.loan",
	greenwich: "games.london.abilities.greenwich",
	colour: "games.london.abilities.colour",
	battersea: "games.london.abilities.battersea",
	hammersmith: "games.london.abilities.hammersmith",
	paddington: "games.london.abilities.paddington",
	swap: "games.london.abilities.swap",
	peek: "games.london.abilities.peek",
	wandsworth: "games.london.abilities.wandsworth",
	westminster: "games.london.abilities.westminster"
}, Ce = {
	brown: "games.london.colours.brown",
	blue: "games.london.colours.blue",
	pink: "games.london.colours.pink",
	grey: "games.london.colours.grey"
}, we = {
	brown: "london-brown",
	blue: "london-blue",
	pink: "london-pink",
	grey: "london-grey"
};
function Te() {
	return /* @__PURE__ */ v("svg", {
		className: "london-target",
		viewBox: "0 0 100 140",
		preserveAspectRatio: "none",
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("rect", {
			x: "2",
			y: "2",
			width: "96",
			height: "136",
			rx: "5",
			fill: "none",
			stroke: "#1686a9",
			strokeWidth: "2",
			strokeDasharray: "5 4",
			vectorEffect: "non-scaling-stroke",
			children: /* @__PURE__ */ v("animate", {
				attributeName: "stroke-dashoffset",
				from: "18",
				to: "0",
				dur: "0.9s",
				repeatCount: "indefinite"
			})
		})
	});
}
function Ee({ end: e = !1 }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 32 32",
		className: "london-icon",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("path", {
			d: "M14 3Q16 1 18 3L29 14Q31 16 29 18L18 29Q16 31 14 29L3 18Q1 16 3 14Z",
			fill: "none",
			stroke: e ? "#514838" : "#b6a58b",
			strokeWidth: "1.5"
		}), !e && /* @__PURE__ */ v("path", {
			d: "M14 7Q16 5 18 7L25 14Q27 16 25 18L18 25Q16 27 14 25L7 18Q5 16 7 14Z",
			fill: "none",
			stroke: "#b6a58b"
		})]
	});
}
function De({ n: e, spend: t = !1 }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 40 40",
		className: "london-money-icon",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("circle", {
				cx: "20",
				cy: "20",
				r: "18.5",
				fill: t ? "#685340" : "#d4b68c",
				stroke: "#675541",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("circle", {
				cx: "20",
				cy: "20",
				r: "15.7",
				fill: t ? "#7e654e" : "#eddbb5",
				stroke: t ? "#bba483" : "#ac8d62",
				strokeWidth: "2",
				strokeDasharray: "1 1.4"
			}),
			/* @__PURE__ */ y("text", {
				x: "20",
				y: "25",
				textAnchor: "middle",
				fill: t ? "#eee0c6" : "#302d25",
				fontFamily: "Georgia,serif",
				fontSize: "17",
				fontWeight: "bold",
				children: ["£", e]
			})
		]
	});
}
function Oe() {
	return /* @__PURE__ */ v("svg", {
		viewBox: "0 0 24 32",
		className: "london-icon",
		"aria-hidden": !0,
		children: /* @__PURE__ */ v("rect", {
			x: "4",
			y: "2",
			width: "16",
			height: "28",
			rx: "3",
			fill: "#161613"
		})
	});
}
function ke({ n: e }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 24 32",
		className: "london-icon",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			x: "4",
			y: "2",
			width: "16",
			height: "28",
			rx: "2",
			fill: "#d8c394",
			stroke: "#716047",
			strokeWidth: "1.4"
		}), e !== void 0 && /* @__PURE__ */ v("text", {
			x: "12",
			y: "22",
			textAnchor: "middle",
			fill: "#302d25",
			fontFamily: "Georgia,serif",
			fontSize: "18",
			children: e
		})]
	});
}
function Ae() {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 40 36",
		className: "london-icon",
		"aria-hidden": !0,
		children: [
			/* @__PURE__ */ v("rect", {
				x: "23",
				y: "2",
				width: "14",
				height: "25",
				rx: "2",
				fill: "#161613"
			}),
			/* @__PURE__ */ v("rect", {
				x: "10",
				y: "11",
				width: "16",
				height: "23",
				rx: "2",
				fill: "#d7bd8d",
				stroke: "#716047",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ v("path", {
				d: "M1 22Q12 11 29 13L29 9 39 18 28 23 28 19Q14 18 7 26L9 19Z",
				fill: "#d7bd8d",
				stroke: "#716047",
				strokeWidth: "1.2"
			})
		]
	});
}
function X({ gain: e = !1 }) {
	return /* @__PURE__ */ y("svg", {
		viewBox: "0 0 32 32",
		className: "london-icon",
		"aria-hidden": !0,
		children: [/* @__PURE__ */ v("rect", {
			x: "3",
			y: "3",
			width: "26",
			height: "26",
			rx: "2",
			fill: "#161613"
		}), /* @__PURE__ */ v("path", {
			d: e ? "M10 16h12M16 10v12" : "M10 16h12",
			stroke: "#f3eddd",
			strokeWidth: "5"
		})]
	});
}
function Z({ id: e, down: t = !1, selected: n = !1, legal: r = !1, anchor: i, coins: a = 0, detail: o = !1 }) {
	let s = d(), { ref: c } = f(i ?? null);
	if (e === null || t) return /* @__PURE__ */ y("span", {
		ref: i ? c : void 0,
		className: "london-card london-back",
		children: [
			/* @__PURE__ */ v("span", {
				className: "london-back-seal",
				children: "L"
			}),
			/* @__PURE__ */ v("span", { className: "london-back-lines" }),
			r && /* @__PURE__ */ v(Te, {})
		]
	});
	let l = A[e], u = A.find((e) => e.name === l.name).id;
	return /* @__PURE__ */ y("span", {
		ref: i ? c : void 0,
		className: `london-card ${we[l.colour]}${n ? " london-selected" : ""}${o ? " london-detail-card" : ""}`,
		children: [
			/* @__PURE__ */ y("span", {
				className: "london-card-top",
				children: [
					/* @__PURE__ */ v("b", { children: l.era }),
					l.cost > 0 && /* @__PURE__ */ v(De, {
						n: l.cost,
						spend: !0
					}),
					n && /* @__PURE__ */ v("b", { children: "✓" })
				]
			}),
			/* @__PURE__ */ v("strong", {
				className: "london-card-name",
				children: s(l.name)
			}),
			/* @__PURE__ */ v("img", {
				className: "london-art",
				src: g(`games/london/city-${u}.svg`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ v("span", {
				className: "london-card-type",
				children: s(Ce[l.colour])
			}),
			/* @__PURE__ */ y("span", {
				className: "london-card-yield",
				children: [
					l.money > 0 && /* @__PURE__ */ v("b", {
						title: s("games.london.moneyGain", { n: l.money }),
						children: /* @__PURE__ */ v(De, { n: l.money })
					}),
					l.vp > 0 && /* @__PURE__ */ y("span", {
						title: s("games.london.vpGain", { n: l.vp }),
						children: [/* @__PURE__ */ v(Ee, {}), l.vp]
					}),
					l.relief > 0 && /* @__PURE__ */ y("span", {
						title: s("games.london.relief", { n: l.relief }),
						children: [/* @__PURE__ */ v(X, {}), l.relief]
					}),
					l.poverty > 0 && /* @__PURE__ */ y("span", {
						title: s("games.london.povertyGain", { n: l.poverty }),
						children: [/* @__PURE__ */ v(X, { gain: !0 }), l.poverty]
					}),
					!l.money && !l.vp && !l.relief && !l.poverty && /* @__PURE__ */ v("small", { children: s(xe[l.effect]) })
				]
			}),
			/* @__PURE__ */ y("span", {
				className: "london-card-foot",
				children: [
					/* @__PURE__ */ v("span", {
						title: typeof l.activation == "number" ? s("games.london.activationCost", { n: l.activation }) : s("games.london.cardCost"),
						children: l.activation === "card" ? /* @__PURE__ */ v(Oe, {}) : l.activation ? /* @__PURE__ */ v(De, {
							n: l.activation,
							spend: !0
						}) : ""
					}),
					/* @__PURE__ */ v("span", {
						title: s("games.london.endVP", { n: l.end }),
						children: l.end ? /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(Ee, { end: !0 }), l.end] }) : ""
					}),
					/* @__PURE__ */ v("span", {
						title: l.flip ? s("games.london.flip") : void 0,
						children: l.flip && /* @__PURE__ */ v(Ae, {})
					})
				]
			}),
			a > 0 && /* @__PURE__ */ y("span", {
				className: "london-coin-stash",
				children: ["£", a]
			}),
			r && /* @__PURE__ */ v(Te, {})
		]
	});
}
function je({ id: e, selected: t = !1, legal: n = !1, detail: r = !1, anchor: i }) {
	let a = d(), o = M[e], { ref: s } = f(i ?? null);
	return /* @__PURE__ */ y("span", {
		ref: i ? s : void 0,
		className: `london-deed${t ? " london-selected" : ""}${r ? " london-detail-deed" : ""}`,
		children: [
			/* @__PURE__ */ y("span", {
				className: "london-deed-place",
				children: [/* @__PURE__ */ v("b", { children: a(o.side === "N" ? "games.london.north" : "games.london.south") }), /* @__PURE__ */ v("small", { children: a(o.river ? "games.london.riverside" : "games.london.inland") })]
			}),
			/* @__PURE__ */ v("img", {
				className: "london-deed-art",
				src: g(`games/london/borough-${e}.svg`),
				alt: "",
				draggable: !1
			}),
			/* @__PURE__ */ v("strong", { children: a(o.name) }),
			/* @__PURE__ */ y("span", {
				className: "london-deed-values",
				children: [
					/* @__PURE__ */ y("b", { children: ["£", o.cost] }),
					/* @__PURE__ */ v("span", {
						title: a("games.london.drawN", { n: o.draw }),
						children: /* @__PURE__ */ v(ke, { n: o.draw })
					}),
					/* @__PURE__ */ y("span", {
						title: a("games.london.vpGain", { n: o.vp }),
						children: [/* @__PURE__ */ v(Ee, {}), o.vp]
					}),
					/* @__PURE__ */ y("span", {
						title: a("games.london.relief", { n: o.relief }),
						children: [/* @__PURE__ */ v(X, {}), o.relief]
					})
				]
			}),
			r && /* @__PURE__ */ v("span", {
				className: "london-deed-ability",
				children: a(Se[o.ability])
			}),
			n && /* @__PURE__ */ v(Te, {})
		]
	});
}
function Me({ id: e }) {
	let t = d(), n = A[e];
	return /* @__PURE__ */ y("div", {
		className: "london-card-description",
		children: [
			/* @__PURE__ */ v(Z, {
				id: e,
				detail: !0
			}),
			/* @__PURE__ */ v("p", { children: t(xe[n.effect]) }),
			/* @__PURE__ */ y("ul", { children: [
				n.cost > 0 && /* @__PURE__ */ v("li", { children: t("games.london.buildCost", { n: n.cost }) }),
				n.activation !== 0 && /* @__PURE__ */ v("li", { children: n.activation === "card" ? t("games.london.cardCost") : t("games.london.activationCost", { n: n.activation }) }),
				n.money > 0 && /* @__PURE__ */ v("li", { children: t("games.london.moneyGain", { n: n.money }) }),
				n.vp > 0 && /* @__PURE__ */ v("li", { children: t("games.london.vpGain", { n: n.vp }) }),
				n.relief > 0 && /* @__PURE__ */ v("li", { children: t("games.london.relief", { n: n.relief }) }),
				n.poverty > 0 && /* @__PURE__ */ v("li", { children: t("games.london.povertyGain", { n: n.poverty }) }),
				n.end > 0 && /* @__PURE__ */ v("li", { children: t("games.london.endVP", { n: n.end }) }),
				/* @__PURE__ */ v("li", { children: t(n.flip ? "games.london.flip" : "games.london.reusable") })
			] })
		]
	});
}
//#endregion
//#region src/games/london/view-player.tsx
var Ne = {
	start: "games.london.start",
	draw: "games.london.draw",
	peek: "games.london.peek",
	choose: "games.london.choose",
	develop: "games.london.develop",
	run: "games.london.run",
	overflow: "games.london.overflow",
	done: "games.london.done"
};
function Pe(e) {
	return p(), /* @__PURE__ */ v(Fe, { ...e }, e.myRid);
}
function Q({ children: e, title: t, onClose: i }) {
	let a = d(), o = r(null);
	return n(() => {
		let e = document.activeElement;
		return o.current?.focus(), () => {
			e instanceof HTMLElement && e.focus();
		};
	}, []), /* @__PURE__ */ v("div", {
		className: "london-dialog-shade",
		onClick: i,
		onKeyDown: (e) => {
			if (e.key === "Escape" && i(), e.key === "Tab") {
				let t = o.current?.querySelectorAll("button:not(:disabled),input,[tabindex=\"0\"]");
				if (!t?.length) {
					e.preventDefault();
					return;
				}
				let n = t[0], r = t[t.length - 1];
				e.shiftKey && (document.activeElement === n || document.activeElement === o.current) ? (e.preventDefault(), r.focus()) : !e.shiftKey && document.activeElement === r && (e.preventDefault(), n.focus());
			}
		},
		children: /* @__PURE__ */ y("div", {
			ref: o,
			role: "dialog",
			"aria-modal": "true",
			"aria-label": t,
			tabIndex: -1,
			className: "london-dialog",
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ y("header", { children: [/* @__PURE__ */ v("h2", { children: t }), /* @__PURE__ */ v("button", {
				type: "button",
				className: "london-close",
				"aria-label": a("games.london.close"),
				onClick: i,
				children: /* @__PURE__ */ v(h, { size: 22 })
			})] }), e]
		})
	});
}
function $({ name: e, className: t, children: n }) {
	let { ref: r } = f(e);
	return /* @__PURE__ */ v("div", {
		ref: r,
		className: t,
		children: n
	});
}
function Fe({ public: e, private: t, members: n, myRid: r, send: f, readOnly: p = !1 }) {
	let m = e, h = t, g = d(), b = u((e) => e.locale), x = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? l(t, b) : e;
	}, S = m.players.find((e) => e.rid === r), [C, w] = i(r), [T, E] = i(null), [D, O] = i(null), [k, j] = i(null), [P, F] = i(!1), [te, ne] = i(!1), re = `${m.turnNo}:${m.phase}:${h?.hand.join(",")}:${m.used.join(",")}:${m.boroughUsed}`, [ie, ae] = i(re);
	ie !== re && (ae(re), E(null), O(null), j(null), F(!1), ne(!1));
	let I = !p && m.phase !== "done" && m.turn === r && !!h, L = m.players.find((e) => e.rid === C) ?? S ?? m.players[0], R = L.rid === r, z = S ? M[S.boroughs.at(-1)]?.ability : void 0, B = h?.hand ?? [], V = T !== null && (m.freeBuilds > 0 || A[T].effect === "coffee"), H = (e) => T !== null && e !== T && (te && z === "colour" || A[e].colour !== "grey" && A[e].colour === A[T].colour), U = I && R && m.phase === "develop" && T !== null && (m.freeBuilds > 0 || ee(T)) && (V || D !== null && H(D)), W = (e) => {
		f(e), j(null), E(null), O(null), F(!1);
	}, G = (e) => {
		U && W({
			type: "build",
			card: T,
			pay: V ? null : D,
			stack: e,
			recolour: !V && te
		});
	}, oe = (e) => {
		if (!I) {
			j({
				kind: "card",
				id: e
			});
			return;
		}
		if (P) {
			E(e);
			return;
		}
		if (m.phase === "overflow") {
			W({
				type: "discard",
				card: e
			});
			return;
		}
		if (m.phase === "develop") {
			T !== null && H(e) && !V ? O(e) : (E(T === e ? null : e), O(null)), w(r);
			return;
		}
		j({
			kind: "card",
			id: e
		});
	}, se = (e) => {
		I && P && T !== null ? W({
			type: "swap",
			discard: T,
			take: e,
			recolour: !1
		}) : I && m.phase === "draw" ? W({
			type: "draw",
			source: e
		}) : j({
			kind: "card",
			id: e
		});
	}, K = I ? g(Ne[m.phase], { n: m.drawRemaining }) : p || m.phase === "done" ? g("games.london.done") : g("games.london.wait", { name: x(m.turn) }), q = /* @__PURE__ */ y("div", {
		className: "london-banner",
		children: [/* @__PURE__ */ v(o, {
			tone: I ? "accent" : "info",
			text: K,
			accent: "#385a67",
			chip: g("games.london.turn", { n: m.turnNo })
		}), /* @__PURE__ */ v(s, {
			members: n.filter((e) => m.players.some((t) => t.rid === e.rid)),
			myRid: r,
			onPick: w,
			picked: (e) => e === L.rid,
			action: (e) => !p && m.phase !== "done" && e === m.turn ? "pending" : null,
			anchorOf: (e) => `london-seat:${e}`,
			status: (e) => {
				let t = m.players.find((t) => t.rid === e);
				return /* @__PURE__ */ y("span", {
					className: "london-resources",
					children: [
						/* @__PURE__ */ y("span", {
							title: g("games.london.money"),
							children: ["£", /* @__PURE__ */ v(a, { value: t.cash })]
						}),
						/* @__PURE__ */ y("span", {
							title: g("games.london.prestige"),
							children: [/* @__PURE__ */ v(Ee, {}), /* @__PURE__ */ v(a, { value: t.prestige })]
						}),
						/* @__PURE__ */ y("span", {
							title: g("games.london.poverty"),
							children: [/* @__PURE__ */ v(X, { gain: !0 }), /* @__PURE__ */ v(a, { value: t.poverty })]
						}),
						/* @__PURE__ */ y("span", {
							title: g("games.london.loans"),
							children: ["£10 × ", t.loans]
						}),
						/* @__PURE__ */ y("span", {
							title: g("games.london.hand"),
							children: [/* @__PURE__ */ v(ke, {}), t.handCount]
						})
					]
				});
			}
		})]
	}), ce = /* @__PURE__ */ y("div", {
		className: "london-controls",
		children: [/* @__PURE__ */ y("div", {
			className: "london-command-row",
			children: [
				I && m.phase === "start" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "begin",
							count: 1,
							peek: !1
						}),
						children: g("games.london.begin")
					}),
					z === "westminster" && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "begin",
							count: 0,
							peek: !1
						}),
						children: g("games.london.zero")
					}), /* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "begin",
							count: 2,
							peek: !1
						}),
						children: g("games.london.two")
					})] }),
					z === "peek" && m.deckCount > 0 && /* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "begin",
							count: 1,
							peek: !0
						}),
						children: g("games.london.peekButton")
					}),
					!!S?.loans && S.cash >= 15 && /* @__PURE__ */ v("button", {
						onClick: () => W({ type: "repay" }),
						children: g("games.london.repay")
					})
				] }),
				I && m.phase === "choose" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "choose",
							action: "develop"
						}),
						children: g("games.london.developButton")
					}),
					/* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "choose",
							action: "run"
						}),
						children: g("games.london.runButton")
					}),
					/* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "choose",
							action: "draw"
						}),
						children: g("games.london.drawThree")
					})
				] }),
				I && m.phase === "develop" && /* @__PURE__ */ y(_, { children: [
					/* @__PURE__ */ v("button", {
						disabled: !m.developed,
						onClick: () => W({ type: "finish" }),
						children: g("games.london.finish")
					}),
					T !== null && !m.freeBuilds && N(T) && /* @__PURE__ */ v("button", {
						onClick: () => W({
							type: "action",
							card: T
						}),
						children: g("games.london.playAction")
					}),
					z === "colour" && T !== null && !V && /* @__PURE__ */ y("label", { children: [/* @__PURE__ */ v("input", {
						type: "checkbox",
						checked: te,
						onChange: (e) => {
							ne(e.target.checked), O(null);
						}
					}), g("games.london.recolour")] }),
					m.freeBuilds > 0 && /* @__PURE__ */ v("span", { children: g("games.london.freeBuilds", { n: m.freeBuilds }) })
				] }),
				I && m.phase === "run" && /* @__PURE__ */ y(_, { children: [!m.boroughUsed && /* @__PURE__ */ v("button", {
					onClick: () => j({ kind: "runBorough" }),
					children: g("games.london.useBorough")
				}), /* @__PURE__ */ v("button", {
					disabled: !m.boroughUsed,
					onClick: () => W({ type: "finish" }),
					children: g("games.london.finishRun")
				})] }),
				I && z === "swap" && !m.swapUsed && /* @__PURE__ */ v("button", {
					"aria-pressed": P,
					onClick: () => {
						F(!P), E(null), O(null);
					},
					children: g(P ? "games.london.cancel" : "games.london.swap")
				}),
				T !== null && !P && /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v("button", {
					onClick: () => j({
						kind: "card",
						id: T
					}),
					children: g("games.london.inspect")
				}), /* @__PURE__ */ v("button", {
					onClick: () => {
						E(null), O(null);
					},
					children: g("games.london.cancel")
				})] }),
				!p && m.phase !== "done" && S && /* @__PURE__ */ v("button", {
					className: "london-loan",
					onClick: () => W({ type: "loan" }),
					children: g("games.london.loan")
				}),
				m.remaining !== null && m.phase !== "done" && /* @__PURE__ */ v("span", { children: g("games.london.finalTurns", { n: m.remaining }) })
			]
		}), /* @__PURE__ */ v($, {
			name: `london-hand:${r}`,
			className: "london-hand",
			children: B.map((e) => /* @__PURE__ */ v("button", {
				className: "london-card-button",
				"aria-label": g(A[e].name),
				"aria-pressed": T === e || D === e,
				onClick: () => oe(e),
				children: /* @__PURE__ */ v(Z, {
					id: e,
					anchor: `london-handcard:${e}`,
					selected: T === e || D === e,
					legal: I && (m.phase === "overflow" || P || m.phase === "develop" && (T === null ? m.freeBuilds > 0 || ee(e) || N(e) : !V && H(e)))
				})
			}, e))
		})]
	});
	return /* @__PURE__ */ y("div", {
		className: "london-screen",
		children: [
			/* @__PURE__ */ v(c, {
				adaptive: !0,
				scroll: !1,
				banner: q,
				actions: p ? void 0 : ce,
				actionsHeight: p ? void 0 : "london-actions-height",
				children: /* @__PURE__ */ y("div", {
					className: "london-table-scroll",
					children: [!p && /* @__PURE__ */ y("div", {
						className: "london-public-zone",
						children: [/* @__PURE__ */ y("section", {
							className: "london-development",
							children: [/* @__PURE__ */ v("h2", { children: g("games.london.board") }), /* @__PURE__ */ y("div", {
								className: "london-board-layout",
								children: [/* @__PURE__ */ v($, {
									name: "london-deck",
									children: /* @__PURE__ */ y("button", {
										className: "london-card-button london-deck-button",
										disabled: !I || m.phase !== "draw" || !m.deckCount,
										onClick: () => W({
											type: "draw",
											source: -1
										}),
										children: [/* @__PURE__ */ v(Z, {
											id: null,
											legal: I && m.phase === "draw" && m.deckCount > 0
										}), /* @__PURE__ */ y("span", { children: [
											m.era ?? "—",
											" · ",
											m.deckCount
										] })]
									})
								}), /* @__PURE__ */ v($, {
									name: "london-board",
									className: "london-board",
									children: m.board.map((e, t) => /* @__PURE__ */ v("div", {
										className: "london-board-row",
										children: e.map((e, n) => /* @__PURE__ */ v($, {
											name: `london-boardslot:${t}:${n}`,
											className: "london-board-slot",
											children: e === null ? /* @__PURE__ */ v("span", {
												className: "london-empty",
												"aria-label": g("games.london.empty")
											}) : /* @__PURE__ */ v("button", {
												className: "london-card-button",
												onClick: () => se(e),
												children: /* @__PURE__ */ v(Z, {
													id: e,
													anchor: `london-boardcard:${e}`,
													legal: I && (m.phase === "draw" || P && T !== null)
												})
											})
										}, n))
									}, t))
								})]
							})]
						}), /* @__PURE__ */ y("section", {
							className: "london-market",
							children: [/* @__PURE__ */ y("h2", { children: [
								g("games.london.market"),
								" ",
								/* @__PURE__ */ v("small", { children: m.boroughCount })
							] }), /* @__PURE__ */ v($, {
								name: "london-market",
								className: "london-deeds",
								children: m.market.map((e, t) => /* @__PURE__ */ v($, {
									name: `london-market-slot:${t}`,
									children: /* @__PURE__ */ v("button", {
										className: "london-deed-button",
										onClick: () => j({
											kind: "borough",
											id: e
										}),
										children: /* @__PURE__ */ v(je, {
											id: e,
											legal: I && m.phase === "choose"
										})
									})
								}, e))
							})]
						})]
					}), /* @__PURE__ */ y("section", {
						className: "london-city-zone",
						children: [/* @__PURE__ */ y("h2", { children: [
							x(L.rid),
							" · ",
							g("games.london.city")
						] }), /* @__PURE__ */ y("div", {
							className: "london-city-layout",
							children: [/* @__PURE__ */ y("div", {
								className: "london-stacks",
								children: [L.stacks.map((e, t) => {
									let n = e.at(-1), r = n.id === null ? null : A[n.id], i = I && R && (U && n.placed !== m.turnNo || m.phase === "run" && r !== null && !n.down && !m.used.includes(r.id) && ![
										"none",
										"hospital",
										"draw2",
										"wren"
									].includes(r.effect));
									return /* @__PURE__ */ y($, {
										name: `london-stack:${L.rid}:${t}`,
										className: "london-stack",
										children: [
											/* @__PURE__ */ y("button", {
												className: "london-card-button",
												"aria-label": g(r ? r.name : "games.london.hidden"),
												onClick: () => {
													U && n.placed !== m.turnNo ? G(t) : i && m.phase === "run" ? j({
														kind: "activate",
														stack: t
													}) : n.id !== null && j({
														kind: "card",
														id: n.id
													});
												},
												children: [/* @__PURE__ */ v(Z, {
													id: n.id,
													down: n.down && !p,
													coins: n.coins,
													legal: i
												}), /* @__PURE__ */ v("span", {
													className: "london-stack-count",
													children: e.length
												})]
											}),
											m.phase !== "done" && R && m.used.includes(n.id) && /* @__PURE__ */ v("span", {
												className: "london-state-stamp",
												children: g("games.london.used")
											}),
											p && /* @__PURE__ */ v("div", {
												className: "london-layer-list",
												children: e.map((e, t) => e.id !== null && /* @__PURE__ */ v("button", {
													onClick: () => j({
														kind: "card",
														id: e.id
													}),
													children: g(A[e.id].name)
												}, t))
											})
										]
									}, t);
								}), I && R && m.phase === "develop" && /* @__PURE__ */ y("button", {
									className: "london-new-stack",
									disabled: !U,
									onClick: () => G(-1),
									children: [g("games.london.newStack"), U && /* @__PURE__ */ v(Te, {})]
								})]
							}), /* @__PURE__ */ v($, {
								name: `london-boroughs:${L.rid}`,
								className: "london-owned",
								children: L.boroughs.map((e, t) => /* @__PURE__ */ y("button", {
									className: "london-deed-button",
									onClick: () => j({
										kind: "borough",
										id: e
									}),
									children: [/* @__PURE__ */ v(je, {
										id: e,
										anchor: `london-owned:${L.rid}:${e}`
									}), /* @__PURE__ */ v("span", { children: t === L.boroughs.length - 1 && g("games.london.topOnly") })]
								}, e))
							})]
						})]
					})]
				})
			}),
			I && m.phase === "peek" && /* @__PURE__ */ v(Q, {
				title: g("games.london.peek"),
				onClose: () => {},
				children: /* @__PURE__ */ v("div", {
					className: "london-dialog-body london-pick-cards",
					children: h.peek.map((e) => /* @__PURE__ */ v("button", {
						className: "london-card-button",
						onClick: () => W({
							type: "peek",
							card: e
						}),
						children: /* @__PURE__ */ v(Z, {
							id: e,
							legal: !0
						})
					}, e))
				})
			}),
			k?.kind === "card" && /* @__PURE__ */ v(Q, {
				title: g(A[k.id].name),
				onClose: () => j(null),
				children: /* @__PURE__ */ v("div", {
					className: "london-dialog-body",
					children: /* @__PURE__ */ v(Me, { id: k.id })
				})
			}),
			k?.kind === "borough" && /* @__PURE__ */ y(Q, {
				title: g(M[k.id].name),
				onClose: () => j(null),
				children: [/* @__PURE__ */ v("div", {
					className: "london-dialog-body",
					children: /* @__PURE__ */ v(je, {
						id: k.id,
						detail: !0
					})
				}), I && m.phase === "choose" && m.market.includes(k.id) && /* @__PURE__ */ v("footer", { children: /* @__PURE__ */ v("button", {
					onClick: () => W({
						type: "buy",
						borough: k.id
					}),
					children: g("games.london.buy", { n: M[k.id].cost })
				}) })]
			}),
			k?.kind === "activate" && I && /* @__PURE__ */ v(Le, {
				pub: m,
				priv: h,
				stack: k.stack,
				nameOf: x,
				send: W,
				close: () => j(null)
			}, `${m.turnNo}:${k.stack}`),
			k?.kind === "runBorough" && I && /* @__PURE__ */ v(Re, {
				pub: m,
				priv: h,
				send: W,
				close: () => j(null)
			})
		]
	});
}
function Ie({ cards: e, chosen: t, onPick: n }) {
	let r = d();
	return /* @__PURE__ */ v("div", {
		className: "london-pick-cards",
		children: e.map((e) => /* @__PURE__ */ v("button", {
			className: "london-card-button",
			"aria-label": r(A[e].name),
			"aria-pressed": t.includes(e),
			onClick: () => n(e),
			children: /* @__PURE__ */ v(Z, {
				id: e,
				selected: t.includes(e),
				legal: !0
			})
		}, e))
	});
}
function Le({ pub: e, priv: t, stack: n, nameOf: r, send: a, close: o }) {
	let s = d(), c = e.players.find((t) => t.rid === e.turn), l = A[c.stacks[n].at(-1).id], [u, f] = i([]), [p, m] = i(), [h, g] = i(), [_, b] = i(), [x, S] = i(), C = l.effect === "whitehall" && p !== void 0 ? A[c.stacks[p].at(-1).id] : l, w = +(l.activation === "card"), T = w + (["prison", "millbank"].includes(C.effect) ? 3 : 0), E = c.stacks.flatMap((e, t) => {
		let n = e.at(-1);
		return n.id !== null && !n.down ? [{
			i: t,
			c: A[n.id]
		}] : [];
	}), D = u.length >= w && u.length <= T && (l.effect !== "whitehall" || p !== void 0) && (C.effect !== "coffee" || h !== void 0) && (!["lloyds", "police"].includes(C.effect) || _ !== void 0);
	return /* @__PURE__ */ y(Q, {
		title: s(A[c.stacks[n].at(-1).id].name),
		onClose: o,
		children: [/* @__PURE__ */ y("div", {
			className: "london-dialog-body",
			children: [
				/* @__PURE__ */ v(Me, { id: l.id }),
				l.effect === "whitehall" && /* @__PURE__ */ y("fieldset", { children: [/* @__PURE__ */ v("legend", { children: s("games.london.copy") }), /* @__PURE__ */ v("div", {
					className: "london-pick-cards",
					children: E.filter((e) => e.i !== n && ![
						"none",
						"hospital",
						"wren",
						"draw2",
						"whitehall"
					].includes(e.c.effect)).map((e) => /* @__PURE__ */ v("button", {
						className: "london-card-button",
						onClick: () => {
							m(e.i), g(void 0), b(void 0), f([]);
						},
						children: /* @__PURE__ */ v(Z, {
							id: e.c.id,
							selected: p === e.i,
							legal: !0
						})
					}, e.i))
				})] }),
				T > 0 && /* @__PURE__ */ y("fieldset", { children: [/* @__PURE__ */ y("legend", { children: [
					s("games.london.discard"),
					" (",
					w,
					"–",
					T,
					")"
				] }), /* @__PURE__ */ v(Ie, {
					cards: t.hand,
					chosen: u,
					onPick: (e) => f(u.includes(e) ? u.filter((t) => t !== e) : u.length < T ? [...u, e] : T === 1 ? [e] : u)
				})] }),
				C.effect === "coffee" && /* @__PURE__ */ y("fieldset", { children: [/* @__PURE__ */ v("legend", { children: s("games.london.coffee") }), /* @__PURE__ */ v(Ie, {
					cards: e.board.flat().filter((e) => e !== null),
					chosen: h === void 0 ? [] : [h],
					onPick: g
				})] }),
				["lloyds", "police"].includes(C.effect) && /* @__PURE__ */ y("fieldset", { children: [/* @__PURE__ */ v("legend", { children: s("games.london.target") }), /* @__PURE__ */ v("div", {
					className: "london-target-players",
					children: e.players.map((e) => /* @__PURE__ */ y("button", {
						"aria-pressed": e.rid === _,
						onClick: () => b(e.rid),
						children: [
							r(e.rid),
							" ",
							/* @__PURE__ */ v(X, { gain: !0 }),
							e.poverty
						]
					}, e.rid))
				})] }),
				l.flip && E.some((e) => e.c.effect === "hospital") && /* @__PURE__ */ y("fieldset", { children: [
					/* @__PURE__ */ v("legend", { children: s("games.london.hospital") }),
					/* @__PURE__ */ v("button", {
						"aria-pressed": x === void 0,
						onClick: () => S(void 0),
						children: s("games.london.noHospital")
					}),
					/* @__PURE__ */ v("div", {
						className: "london-pick-cards",
						children: E.filter((e) => e.c.effect === "hospital" && e.i !== n).map((e) => /* @__PURE__ */ v("button", {
							className: "london-card-button",
							onClick: () => S(x === e.i ? void 0 : e.i),
							children: /* @__PURE__ */ v(Z, {
								id: e.c.id,
								selected: x === e.i,
								legal: !0
							})
						}, e.i))
					})
				] })
			]
		}), /* @__PURE__ */ y("footer", { children: [/* @__PURE__ */ v("button", {
			onClick: o,
			children: s("games.london.cancel")
		}), /* @__PURE__ */ v("button", {
			disabled: !D,
			onClick: () => a({
				type: "activate",
				stack: n,
				discard: u,
				copy: p,
				board: h,
				target: _,
				hospital: x
			}),
			children: s("games.london.activate")
		})] })]
	});
}
function Re({ pub: e, priv: t, send: n, close: r }) {
	let a = d(), o = e.players.find((t) => t.rid === e.turn).boroughs.at(-1), s = M[o], [c, l] = i([]);
	return /* @__PURE__ */ y(Q, {
		title: a(s.name),
		onClose: r,
		children: [/* @__PURE__ */ y("div", {
			className: "london-dialog-body",
			children: [
				/* @__PURE__ */ v(je, {
					id: o,
					detail: !0
				}),
				/* @__PURE__ */ v("p", { children: a(Se[s.ability]) }),
				s.ability === "greenwich" && /* @__PURE__ */ v(Ie, {
					cards: t.hand.filter((e) => A[e].colour === "grey"),
					chosen: c,
					onPick: (e) => l(c.includes(e) ? c.filter((t) => t !== e) : [...c, e])
				})
			]
		}), /* @__PURE__ */ v("footer", { children: /* @__PURE__ */ v("button", {
			onClick: () => n({
				type: "borough",
				discard: c
			}),
			children: a("games.london.confirm")
		}) })]
	});
}
//#endregion
//#region src/games/london/bot.ts
var ze = {
	cash: .7,
	relief: 2,
	stack: 1.5,
	borough: 1,
	run: 1.2
}, Be = (e, t, n = ze) => {
	let r = t.stacks.flatMap((e) => {
		let t = e[e.length - 1];
		return t.id !== null && !t.down ? [A[t.id]] : [];
	}), i = e.money * n.cash + e.vp + Math.min(t.poverty + 3, e.relief) * n.relief + e.end * .7 - e.cost * .25 - (typeof e.activation == "number" ? e.activation * n.cash : .6) - e.poverty * n.relief;
	switch (e.effect) {
		case "none": return e.colour === "grey" ? -8 : e.end * .7 - e.cost * .25;
		case "draw2": return 3;
		case "wren": return 6;
		case "coffee": return 4;
		case "stock":
			i += 2 * n.cash * 2;
			break;
		case "bridge":
			i += r.filter((e) => e.colour === "brown").length * n.cash;
			break;
		case "town":
			i += r.filter((e) => e.colour === "blue" || e.colour === "pink").length;
			break;
		case "hospital":
			i += 2;
			break;
		case "prison":
		case "millbank":
			i += 3;
			break;
		case "omnibus":
			i += 2;
			break;
		case "shops":
			i += 2;
			break;
		case "boats":
			i += t.boroughs.filter((e) => M[e].river).length * 2 * n.cash;
			break;
		case "north":
		case "south":
			i += t.boroughs.filter((t) => M[t].side === (e.effect === "north" ? "N" : "S")).length * 2 * n.cash;
			break;
		case "underground":
			i += 3 + t.boroughs.length;
			break;
		case "whitehall": i += 5;
	}
	return i * (e.flip ? 1 : 1.5);
};
function Ve(e, t) {
	let n = e.players.find((t) => t.rid === e.turn), r = [-1, ...n.stacks.flatMap((t, n) => t[t.length - 1].placed === e.turnNo ? [] : [n])], i = [], a = M[n.boroughs[n.boroughs.length - 1]]?.ability === "colour";
	for (let n of t.hand) {
		let o = A[n], s = e.freeBuilds > 0 || o.effect === "coffee";
		if (e.freeBuilds || ee(n)) for (let e of r) if (s) i.push({
			type: "build",
			card: n,
			pay: null,
			stack: e,
			recolour: !1
		});
		else for (let r of t.hand) {
			if (r === n) continue;
			let t = A[r].colour === o.colour && A[r].colour !== "grey";
			(t || a) && i.push({
				type: "build",
				card: n,
				pay: r,
				stack: e,
				recolour: !t
			});
		}
	}
	return i;
}
function He(e, t, n = ze) {
	let r = e.players.find((t) => t.rid === e.turn), i = [...t.hand].sort((e, t) => Be(A[e], r, n) - Be(A[t], r, n)), a = r.stacks.flatMap((e, t) => {
		let n = e[e.length - 1];
		return n.id !== null && !n.down ? [{
			b: n,
			i: t,
			c: A[n.id]
		}] : [];
	}), o = [];
	for (let { b: t, i: n, c: s } of a) {
		if (e.used.includes(t.id) || [
			"none",
			"hospital",
			"wren",
			"draw2"
		].includes(s.effect)) continue;
		let c = s.effect === "whitehall" ? a.filter((e) => e.i !== n && ![
			"none",
			"hospital",
			"wren",
			"draw2",
			"whitehall"
		].includes(e.c.effect)) : [{
			b: t,
			i: n,
			c: s
		}];
		for (let t of c) {
			let a = +(s.activation === "card");
			if (i.length < a) continue;
			let c = [i.slice(0, a)];
			(t.c.effect === "prison" || t.c.effect === "millbank") && c.push(i.slice(0, a + 3));
			let l = t.c.effect === "coffee" ? e.board.flat().filter((e) => e !== null) : [void 0];
			for (let i of c) for (let a of l) o.push({
				type: "activate",
				stack: n,
				discard: i,
				target: [...e.players].filter((e) => e.rid !== r.rid).sort((e, t) => e.poverty - t.poverty)[0]?.rid ?? r.rid,
				copy: s.effect === "whitehall" ? t.i : void 0,
				board: a
			});
		}
	}
	return o;
}
function Ue(e = ze) {
	return ({ public: t, private: n }, r) => {
		if (t.turn !== r.rid || t.phase === "done" || !n) return null;
		let i = t.players.find((e) => e.rid === r.rid), a = (e) => ({ action: e }), o = (t) => Be(A[t], i, e), s = [...n.hand].sort((e, t) => o(e) - o(t)), c = Ve(t, n).sort((t, n) => {
			let r = (t) => o(t.card) - (t.pay === null ? 0 : o(t.pay) * .5) - (t.stack === -1 ? e.stack * (i.stacks.length + 1) : i.stacks[t.stack].at(-1).id === null ? 0 : o(i.stacks[t.stack].at(-1).id) * .4);
			return r(n) - r(t);
		})[0];
		if (t.phase === "start") {
			if (i.loans && i.cash >= 20) return a({ type: "repay" });
			let e = M[i.boroughs.at(-1)]?.ability;
			return a({
				type: "begin",
				count: e === "westminster" && n.hand.length >= 6 ? 0 : 1,
				peek: e === "peek" && t.deckCount > 0
			});
		}
		if (t.phase === "peek") return a({
			type: "peek",
			card: [...n.peek].sort((e, t) => o(t) - o(e))[0]
		});
		if (t.phase === "draw") {
			let e = t.board.flat().filter((e) => e !== null).sort((e, t) => o(t) - o(e));
			return a({
				type: "draw",
				source: e.length && (!t.deckCount || o(e[0]) > 4.2) ? e[0] : -1
			});
		}
		if (t.phase === "overflow") return a({
			type: "discard",
			card: s[0]
		});
		if (t.phase === "develop") {
			let e = n.hand.filter(N).sort((e, t) => o(t) - o(e))[0];
			return !t.freeBuilds && e !== void 0 && n.hand.length < 10 ? a({
				type: "action",
				card: e
			}) : a(c || { type: "finish" });
		}
		if (t.phase === "run") {
			let r = He(t, n, e).map((t) => {
				let n = A[i.stacks[t.stack].at(-1).id], r = n.effect === "whitehall" ? A[i.stacks[t.copy].at(-1).id] : n, a = o(r.id) + t.discard.length * .5;
				return r.effect === "coffee" && (a = t.board === void 0 ? -20 : o(t.board) - A[t.board].cost * .3), (r.effect === "bridge" || r.effect === "town") && (a += 20), (r.effect === "shops" || r.effect === "omnibus") && (a += i.stacks[t.copy ?? t.stack].at(-1).coins * e.cash), {
					a: t,
					v: a
				};
			}).sort((e, t) => t.v - e.v);
			if (r.length) {
				let e = r[0].a, t = A[i.stacks[e.stack].at(-1).id];
				if (t.flip && o(t.id) > 5) {
					let t = i.stacks.findIndex((e) => e.at(-1).id !== null && !e.at(-1).down && A[e.at(-1).id].effect === "hospital");
					t >= 0 && t !== e.stack && (e.hospital = t);
				}
				return a(e);
			}
			return t.boroughUsed ? a({ type: "finish" }) : a({
				type: "borough",
				discard: M[i.boroughs.at(-1)]?.ability === "greenwich" ? n.hand.filter((e) => A[e].colour === "grey") : []
			});
		}
		if (t.phase === "choose") {
			let r = n.hand.some(N), s = i.stacks.filter((e) => {
				let t = e.at(-1);
				return t.id !== null && !t.down && ![
					"none",
					"hospital",
					"wren",
					"draw2"
				].includes(A[t.id].effect);
			}), l = s.reduce((e, t) => e + o(t.at(-1).id), 0) * e.run - n.hand.length * e.relief - i.stacks.length, u = [...t.market].sort((t, n) => {
				let r = (t) => {
					let n = M[t];
					return (n.vp + Math.min(i.poverty, n.relief) * e.relief + n.draw * .6 - n.cost * e.cash - Math.max(0, n.cost - i.cash) * .5) * e.borough;
				};
				return r(n) - r(t);
			})[0], d = M[u];
			return d && i.cash >= d.cost && (i.poverty >= d.relief + 2 || t.deckCount < 12 && d.vp > 3) ? a({
				type: "buy",
				borough: u
			}) : c || r ? l > 7 && n.hand.length <= 3 ? a({
				type: "choose",
				action: "run"
			}) : a({
				type: "choose",
				action: "develop"
			}) : s.length && (l > -4 || n.hand.length <= 2) ? a({
				type: "choose",
				action: "run"
			}) : a({
				type: "choose",
				action: "draw"
			});
		}
		return null;
	};
}
var We = Ue(), Ge = {
	londonRetire(e, t) {
		let n = e.data, r = (e.rid === t.myRid ? e.secret?.card : void 0) ?? n.card, i = t.anchor(n.from) ?? t.anchor(`london-seat:${e.rid}`);
		if (!i) return null;
		let a = t.queued ? 160 : 360, o = Math.min(110, i.w);
		return {
			ms: a,
			node: /* @__PURE__ */ v("span", {
				className: "london-retire-sprite",
				style: {
					position: "absolute",
					left: i.x,
					top: i.y,
					"--london-card-w": `${o}px`,
					animationDuration: `${a}ms`
				},
				children: /* @__PURE__ */ v(Z, { id: r })
			})
		};
	},
	londonMove(e, t) {
		let n = e.data, r = (e.rid === t.myRid ? e.secret?.card : void 0) ?? n.card, i = t.anchor(n.from) ?? t.anchor(`london-seat:${e.rid}`), a = n.to.startsWith("london-hand") ? e.rid === t.myRid ? r === null ? n.to : `london-handcard:${r}` : `london-seat:${e.rid}` : n.to, o = t.anchor(a) ?? t.anchor(`london-seat:${e.rid}`);
		if (!i || !o) return null;
		let s = t.queued ? 160 : 360, c = Math.min(120, o.w), l = c * 1.4;
		return {
			ms: s,
			hide: t.queued ? [] : [a],
			node: /* @__PURE__ */ v(b, {
				from: {
					...i,
					w: c,
					h: l
				},
				to: o,
				ms: s,
				children: /* @__PURE__ */ v("span", {
					className: "london-fx-card",
					style: { "--london-card-w": `${c}px` },
					children: /* @__PURE__ */ v(Z, { id: r })
				})
			})
		};
	},
	londonBorough(e, t) {
		let n = e.data, r = t.anchor(`london-market-slot:${n.slot}`) ?? t.anchor("london-market"), i = t.anchor(`london-owned:${e.rid}:${n.borough}`) ?? t.anchor(`london-seat:${e.rid}`);
		if (!r || !i) return null;
		let a = t.queued ? 160 : 400;
		return {
			ms: a,
			hide: t.queued ? [] : [`london-owned:${e.rid}:${n.borough}`],
			node: /* @__PURE__ */ v(b, {
				from: r,
				to: i,
				ms: a,
				children: /* @__PURE__ */ v("span", {
					style: {
						display: "block",
						width: r.w
					},
					children: /* @__PURE__ */ v(je, { id: n.borough })
				})
			})
		};
	},
	londonBoroughActivate(e, t) {
		let n = e.data, r = t.anchor(`london-owned:${e.rid}:${n.borough}`) ?? t.anchor(`london-seat:${e.rid}`);
		if (!r) return null;
		let i = t.queued ? 180 : 400;
		return {
			ms: i,
			node: /* @__PURE__ */ v(x, {
				at: r,
				ms: i
			})
		};
	},
	londonActivate(e, t) {
		let n = e.data, r = `london-stack:${e.rid}:${n.hospital ?? n.stack}`, i = t.anchor(r) ?? t.anchor(`london-seat:${e.rid}`);
		if (!i) return null;
		let a = t.queued ? 180 : 500;
		return {
			ms: a,
			hide: t.queued || !n.flip ? [] : [r],
			node: /* @__PURE__ */ y(_, { children: [/* @__PURE__ */ v(x, {
				at: i,
				ms: a
			}), n.flip && !t.queued && /* @__PURE__ */ y("span", {
				className: "london-flip-sprite",
				style: {
					position: "absolute",
					left: i.x,
					top: i.y,
					"--london-card-w": `${i.w}px`
				},
				children: [/* @__PURE__ */ v("span", {
					className: "london-flip-front",
					children: /* @__PURE__ */ v(Z, { id: n.card })
				}), /* @__PURE__ */ v("span", {
					className: "london-flip-back",
					children: /* @__PURE__ */ v(Z, { id: null })
				})]
			})] })
		};
	}
}, Ke = [
	[
		"games.london.startingPrestige",
		"prestige",
		1
	],
	[
		"games.london.finalBuildings",
		"buildings",
		1
	],
	[
		"games.london.finalCash",
		"cash",
		1
	],
	[
		"games.london.finalLoans",
		"loans",
		-1
	],
	[
		"games.london.finalPoverty",
		"poverty",
		-1
	],
	[
		"games.london.score",
		"total",
		1
	]
];
function qe(e) {
	let { result: t, members: a, myRid: o, onPlayAgain: s, onBackToLobby: c, hintCount: f } = e, p = e.public, g = d(), b = u((e) => e.locale), [x, C] = i(!0), w = r(null), T = r(null);
	n(() => {
		(x ? w : T).current?.focus();
	}, [x]);
	let E = (e) => {
		let t = a.find((t) => t.rid === e);
		return t ? l(t, b) : e;
	}, D = t.ranking.map((e) => p.players.find((t) => t.rid === e)).filter(Boolean), O = !!(s || c);
	return /* @__PURE__ */ y("div", {
		className: "london-screen london-result",
		children: [
			/* @__PURE__ */ v("div", {
				className: "london-review-table",
				inert: x,
				children: /* @__PURE__ */ v(Fe, {
					public: p,
					members: a,
					myRid: o,
					send: () => {},
					readOnly: !0
				})
			}),
			x && /* @__PURE__ */ v("div", {
				className: "london-result-shade",
				children: /* @__PURE__ */ y("section", {
					className: "london-score-paper",
					"aria-label": g("games.london.result"),
					children: [/* @__PURE__ */ y("header", { children: [
						/* @__PURE__ */ v("button", {
							ref: w,
							className: "london-score-collapse",
							"aria-label": g("games.london.reviewCity"),
							onClick: () => C(!1),
							children: /* @__PURE__ */ v(h, { size: 22 })
						}),
						/* @__PURE__ */ v("h1", { children: g("games.london.result") }),
						/* @__PURE__ */ v("p", { children: t.winner.map(E).join(" · ") })
					] }), /* @__PURE__ */ y("div", {
						className: "london-score-scroll",
						children: [
							/* @__PURE__ */ y("table", { children: [/* @__PURE__ */ v("thead", { children: /* @__PURE__ */ y("tr", { children: [/* @__PURE__ */ v("th", { "aria-label": g("games.london.score") }), D.map((e) => /* @__PURE__ */ y("th", {
								className: t.winner.includes(e.rid) ? "london-won" : "",
								children: [E(e.rid), e.rid === o && /* @__PURE__ */ v("small", { children: g("lobby.you") })]
							}, e.rid))] }) }), /* @__PURE__ */ v("tbody", { children: Ke.map(([e, t, n]) => /* @__PURE__ */ y("tr", {
								className: t === "total" ? "london-score-total" : "",
								children: [/* @__PURE__ */ v("th", { children: g(e) }), D.map((e) => /* @__PURE__ */ v("td", { children: (e.final?.[t] ?? 0) * n }, e.rid))]
							}, t)) })] }),
							D.some((e) => (t.autopilot?.[e.rid] ?? 0) > 0) && /* @__PURE__ */ v("div", {
								className: "london-autopilot",
								children: D.filter((e) => (t.autopilot?.[e.rid] ?? 0) > 0).map((e) => /* @__PURE__ */ y("p", { children: [
									/* @__PURE__ */ v(m, { size: 14 }),
									E(e.rid),
									" · ",
									g("session.autopilot.share", { n: Math.round(t.autopilot[e.rid] * 100) })
								] }, e.rid))
							}),
							f !== void 0 && /* @__PURE__ */ v("p", { children: g("session.hint.usedCount", { n: f }) })
						]
					})]
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "london-result-controls",
				children: [!x && /* @__PURE__ */ v("button", {
					ref: T,
					onClick: () => C(!0),
					children: g("games.london.score")
				}), O ? /* @__PURE__ */ y(_, { children: [s && /* @__PURE__ */ v(S, {
					label: g("session.result.playAgain"),
					confirmLabel: g("games.london.confirm"),
					onConfirm: s
				}), c && /* @__PURE__ */ v(S, {
					label: g("session.result.backToLobby"),
					confirmLabel: g("games.london.confirm"),
					onConfirm: c
				})] }) : /* @__PURE__ */ v("span", { children: g("session.result.waitHost") })]
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/london/entry.tsx
var Je = {
	definition: be,
	View: Pe,
	bot: We,
	fx: Ge,
	OverView: qe,
	locales: {
		zh: {
			name: "伦敦",
			desc: "重建大火后的伦敦，经营城市、购置城区，在繁荣与贫困之间取得平衡。",
			rules: "目标：\n你是重建伦敦的建筑师。通过建造、运营和购地积累声望，最终声望最高者获胜。本游戏使用 2017 年第二版基础规则，支持 2–4 人。\n准备：\n101 张城市牌分为 A、B、C 三个时代，各自洗牌后依次叠放。每人获得 6 张手牌和 £5。城中区、西敏区、南华克与伯蒙西区作为首批城区，其他 17 张城区牌洗成牌堆。起始玩家先行动。\n回合：\n回合开始可以偿还借款：支付 £15，归还一笔 £10 借款。然后从城市牌堆顶或发展版图上的任意位置抽 1 张牌，再选择一项主要行动。每次抽多张牌时，逐张选择来源，看到上一张后再决定下一张。抽牌来源全部耗尽时停止。回合结束最多保留 9 张手牌，超出的牌由你选择弃掉。\n· 发展城市：依次打出至少 1 张牌。通常先弃掉另一张同色手牌，再支付牌面建造费用；可以建立新牌叠，也可以覆盖旧牌叠，但不能覆盖本回合刚放置的牌。咖啡馆不需要同色弃牌。常驻能力从放置起生效，覆盖或翻面后失效。\n· 购置城区：购买市场中的 1 张城区牌，立即获得其声望、减贫和抽牌收益，再补充市场。所有已购城区都计入南岸、北岸及沿河数量；只有最上方城区的能力有效。\n· 运营城市：按你选择的顺序激活任意数量的正面城市牌，每张牌每回合最多激活一次。先支付激活费用，再执行全部收益，最后按牌面要求翻面。弃牌激活费用可以用任意手牌支付。医院可以代替另一张城市牌翻面，保留后者供今后运营；不能在同一回合再次激活它。城区的运营效果必须执行，可以安排在城市牌之前或之后。结束运营时获得等于牌叠数、借款数与手牌数总和的贫困；旺兹沃思区免除手牌造成的这部分贫困。\n· 抽取 3 张牌：逐张选择来源；不足 3 张时抽取所有剩余牌。\n特殊能力：\n胡格诺派和犹太难民是行动牌，只能在发展城市时打出：抽 2 张牌后移出游戏。雷恩使你放置手中至多 2 张牌，不弃同色牌，但仍支付建造费用；同回合覆盖限制仍适用。贫民牌不能按普通方式建造或作为同色建造费用，但可支付激活费用、按能力弃掉或在超过手牌上限时弃掉；雷恩及咖啡馆的“任意牌”放置能力也允许放置贫民牌和没有运营能力的行动牌。\n咖啡馆运营时，从发展版图取任意牌覆盖自身，只支付该牌建造费用，新牌可在本次运营中激活。白厅复制另一张正面城市牌的运营能力，忽略被复制牌的激活费用；白厅依照自身要求翻面。商店在你每次放置城市牌时积累 £1，包括商店自身；公共马车在任何人购买城区时积累 £1。运营时才能领取这些钱币，覆盖不会自动领取。\n哈克尼区或肯辛顿区作为最上方城区时，每次需要弃牌可额外支付 £1 将该牌视为任意颜色，包括贫民牌。南华克与伯蒙西区每回合允许用 1 张手牌交换发展版图上的 1 张其他牌。格林尼治区运营时可弃掉任意数量贫民牌，每张获得 £1 并消除 1 贫困。西敏区可以将回合开始的抽牌改为 0 张或 2 张；圣潘克拉斯区可以改为查看牌堆顶 3 张，保留其中 1 张，其余以原相对顺序放回。\n发展版图与借款：\n发展版图有两排，每排容量为人数加 1。弃牌先填上排，上排满后填下排。两排都满时，移除下排，原上排移到下排，再从上排弃牌。任何抽牌都可以从版图选择。你随时可以借款，每笔获得 £10；城中区为最上方城区时每笔获得 £12，但仍只欠 £10。必须支付而现金不足时自动借款。\n结束与计分：\n某人回合结束时城市牌堆为空，其余每人再行动一回合。最终每张剩余手牌带来 1 贫困，然后移出游戏。加入所有已建城市牌的终局声望，包括覆盖及翻面的牌；按每笔 £15 尽量偿还借款，每笔未还借款扣 7 声望，每剩余 £3 获得 1 声望。所有人同时减去最低玩家的贫困，再扣除贫困罚分：0 点扣 0；1–2 点扣 1；3 点扣 2；4 点扣 3；5–10 点分别扣 5、7、9、11、13、15；超过 10 点的部分每点再扣 3。声望相同时依次比较更少贫困、更多城区、单张城市牌最高终局声望；仍相同则共同获胜。",
			invalid: "这项操作当前无法执行，请重新选择。",
			mustDevelop: "至少放置一张牌或使用一张行动牌。",
			mustBorough: "请先执行城区的运营效果。",
			turn: "第 {{n}} 回合",
			wait: "等待 {{name}}",
			start: "抽牌前可以偿还借款",
			draw: "选择抽牌来源，还要抽 {{n}} 张",
			choose: "选择本回合的行动",
			develop: "选择手牌，然后选择费用牌与落位",
			run: "点击城市牌安排运营顺序",
			overflow: "选择弃牌，将手牌减至 9 张",
			peek: "选择保留的城市牌",
			done: "伦敦重建完成",
			money: "现金",
			prestige: "声望",
			poverty: "贫困",
			loans: "借款",
			hand: "手牌",
			city: "城市",
			borough: "城区",
			board: "发展版图",
			deck: "城市牌堆",
			market: "可购城区",
			stack: "牌叠 {{n}}",
			newStack: "新牌叠",
			hidden: "已覆盖或翻面的城市牌",
			developButton: "发展城市",
			runButton: "运营城市",
			drawThree: "抽取 3 张",
			begin: "开始抽牌",
			zero: "不抽牌",
			two: "抽取 2 张",
			peekButton: "查看牌堆顶 3 张",
			loan: "借款",
			repay: "偿还 £15",
			finish: "结束行动",
			finishRun: "结束运营",
			cancel: "取消",
			confirm: "确认",
			close: "关闭",
			inspect: "查看详情",
			buy: "购买 £{{n}}",
			build: "建造",
			playAction: "使用行动牌",
			activate: "激活",
			useBorough: "执行城区效果",
			swap: "交换手牌",
			payment: "选择费用牌",
			discard: "选择弃牌",
			target: "选择玩家",
			copy: "选择要复制的城市牌",
			coffee: "选择发展版图上的牌",
			hospital: "医院代为翻面",
			noHospital: "按原牌翻面",
			recolour: "支付 £1 改变颜色",
			freeBuilds: "可免同色弃牌放置 {{n}} 张",
			finalTurns: "最后 {{n}} 个回合",
			buildCost: "建造 £{{n}}",
			activationCost: "激活 £{{n}}",
			cardCost: "激活时弃 1 张牌",
			endVP: "终局声望 {{n}}",
			moneyGain: "获得 £{{n}}",
			vpGain: "获得 {{n}} 声望",
			relief: "消除 {{n}} 贫困",
			povertyGain: "获得 {{n}} 贫困",
			flip: "激活后翻面",
			reusable: "保留正面",
			north: "北岸",
			south: "南岸",
			riverside: "沿河",
			inland: "非沿河",
			drawN: "抽取 {{n}} 张牌",
			topOnly: "仅最上方城区能力生效",
			ownedBoroughs: "已购城区",
			coins: "牌上 £{{n}}",
			selected: "已选中",
			placed: "本回合已放置",
			used: "本回合已激活",
			empty: "空位",
			result: "伦敦建设纪事",
			winner: "{{name}} 赢得最高声望",
			score: "总声望",
			finalBuildings: "城市牌",
			finalCash: "剩余现金",
			finalLoans: "未还借款",
			finalPoverty: "贫困罚分",
			reviewCity: "查看建造历程",
			startingPrestige: "已获声望",
			logs: {
				build: "{{name}} 建造了 {{card}}",
				buy: "{{name}} 购买了 {{card}}",
				activate: "{{name}} 激活了 {{card}}",
				loan: "{{name}} 借款获得 £{{n}}",
				repay: "{{name}} 偿还了一笔借款",
				run: "{{name}} 运营结束，获得 {{n}} 贫困",
				draw: "{{name}} 抽取了 {{n}} 张牌",
				discard: "{{name}} 弃掉了 {{card}}",
				action: "{{name}} 使用了 {{card}}",
				swap: "{{name}} 交换获得 {{card}}",
				borough: "{{name}} 执行了城区运营效果"
			},
			effects: {
				none: "没有运营能力。",
				hospital: "另一张城市牌需要翻面时，可改为将这张医院翻面。",
				coffee: "建造时不弃同色牌。运营时从发展版图取任意牌覆盖自身，支付其建造费用；新牌可在本次运营中激活。",
				draw2: "发展城市时使用：抽 2 张牌，然后将此牌移出游戏。",
				wren: "发展城市时使用：放置手中至多 2 张牌，不弃同色牌，仍支付建造费用；此牌移出游戏。",
				stock: "从每位其他玩家处收取 £2。",
				bridge: "每有一张正面棕色城市牌，获得 £1。",
				prison: "可弃掉至多 3 张手牌，每张消除 1 贫困。",
				millbank: "可弃掉至多 3 张手牌，每张获得 1 声望并消除 1 贫困。",
				fire: "每位其他玩家向银行支付等于其沿河城区数的英镑。",
				lloyds: "选择一位玩家，使其获得 2 贫困。",
				police: "选择一位玩家，使其获得 1 贫困。",
				omnibus: "任何人购置城区时，在本牌上放 £1；运营时领取。",
				shops: "你每次放置城市牌时，在本牌上放 £1；运营时领取。",
				boats: "每有一个沿河城区，获得 £2。",
				town: "每有一张正面蓝色或粉色城市牌，获得 1 声望，包括本牌。",
				north: "每有一个北岸城区，获得 £2。",
				south: "每有一个南岸城区，获得 £2。",
				underground: "获得 3 声望，并按每个城区再获得 1 声望；同时拥有南北岸城区时支付 £2。",
				whitehall: "复制另一张正面城市牌的运营能力，不支付被复制牌的激活费用。",
				basic: ""
			},
			abilities: {
				none: "",
				loan: "借款每笔获得 £12。",
				greenwich: "运营时可弃掉任意数量贫民牌，每张获得 £1 并消除 1 贫困。",
				colour: "每次弃牌时可以支付 £1 将该牌视为任意颜色。",
				battersea: "每次运营消除 2 贫困。",
				hammersmith: "每次运营消除 1 贫困并获得 £2。",
				paddington: "每次运营消除 1 贫困。",
				swap: "每回合可交换 1 张手牌与发展版图上的牌。每次运营获得 1 贫困。",
				peek: "回合开始可查看牌堆顶 3 张，保留 1 张，其余放回。",
				wandsworth: "运营时手牌不产生贫困；每次运营获得 2 贫困。",
				westminster: "回合开始可以改为抽取 0 张或 2 张牌。"
			},
			colours: {
				brown: "经济",
				blue: "科学与文化",
				pink: "政治",
				grey: "贫民"
			},
			cards: {
				almshouses: "救济院",
				bank: "英格兰银行",
				coffee: "咖啡馆",
				covent: "科文特花园",
				eastIndia: "东印度公司",
				fishmongers: "鱼贩行会",
				monument: "大火纪念碑",
				grocers: "杂货商行会",
				haberdashers: "服饰商行会",
				hospital: "医院",
				huguenots: "胡格诺派",
				leather: "皮革工业",
				mercers: "布商行会",
				paupers: "贫民",
				salters: "盐商行会",
				stPauls: "圣保罗大教堂",
				stock: "证券交易所",
				vauxhall: "沃克斯豪尔花园",
				vintners: "酒商行会",
				water: "自来水厂",
				woolwich: "伍尔维奇兵工厂",
				wren: "雷恩",
				albertDock: "阿尔伯特码头",
				brewing: "酿酒业",
				bridge: "桥梁",
				britishMuseum: "大英博物馆",
				brixton: "布里克斯顿监狱",
				buckingham: "白金汉宫",
				clockmakers: "钟表匠行会",
				fire: "消防队",
				highgate: "海格特公墓",
				kew: "邱园",
				lloyds: "伦敦劳合社",
				millbank: "米尔班克监狱",
				nelson: "纳尔逊纪念柱",
				omnibus: "公共马车",
				oxford: "牛津街",
				police: "警察队",
				regent: "摄政街",
				victoriaDock: "皇家维多利亚码头",
				shipbuilding: "造船业",
				shops: "商店",
				steamboats: "蒸汽船",
				lights: "街灯",
				townhouses: "联排住宅",
				turners: "车工行会",
				university: "伦敦大学",
				upholders: "装潢商行会",
				westIndia: "西印度码头",
				workers: "工人住宅",
				albertHall: "阿尔伯特音乐厅",
				billingsgate: "比林斯盖特市场",
				grandHotel: "大饭店",
				exhibition: "万国博览会",
				refugees: "犹太难民",
				naturalMuseum: "自然历史博物馆",
				sewers: "下水道",
				smithfield: "史密斯菲尔德市场",
				embankment: "泰晤士河堤",
				towerBridge: "伦敦塔桥",
				trainNorth: "北岸火车站",
				trainSouth: "南岸火车站",
				underground: "地铁",
				whitehall: "白厅"
			},
			boroughs: {
				battersea: "巴特西区",
				bethnal: "贝斯纳尔格林、斯特普尼与波普勒区",
				camberwell: "坎伯韦尔区",
				city: "城中区",
				deptford: "德特福德区",
				fulham: "富勒姆与切尔西区",
				greenwich: "格林尼治区",
				hackney: "哈克尼区",
				hammersmith: "哈默史密斯区",
				hampstead: "汉普斯特德区",
				islington: "伊斯灵顿与斯托克纽因顿区",
				kensington: "肯辛顿区",
				lambeth: "兰贝斯区",
				lewisham: "刘易舍姆区",
				paddington: "帕丁顿区",
				southwark: "南华克与伯蒙西区",
				marylebone: "圣马里波恩区",
				pancras: "圣潘克拉斯区",
				wandsworth: "旺兹沃思区",
				westminster: "西敏区"
			}
		},
		en: {
			name: "London",
			desc: "Rebuild London after the Great Fire. Develop and run your city while balancing wealth, prestige and poverty.",
			rules: "Goal:\nBuild the most prestigious part of London. This game uses the 2017 Second Edition base rules for 2–4 players.\nSetup:\nShuffle the 101 city cards separately by era, stacking A above B above C. Each player receives six cards and £5. City, Westminster, and Southwark & Bermondsey form the initial borough market. Shuffle the other 17 boroughs. The first player takes the first turn.\nYour turn:\nAt the start of your turn, you may repay each £10 loan for £15. Draw one card from the city deck or anywhere on the development board, then take one main action. Whenever drawing multiple cards, choose each source separately after seeing the previous card. Stop if no cards remain anywhere. At turn end, discard chosen cards until you hold at most nine.\n· Develop: play one or more cards in sequence. Normally discard another card of the same colour and pay the printed building cost. Start a new stack or cover an existing one, but never cover a card placed this turn. Coffee Houses need no matching discard. Ongoing abilities work immediately and stop when covered or flipped.\n· Buy land: buy one borough from the market, immediately gain its prestige, poverty relief and cards, then refill the market. Every owned borough counts towards north, south and riverside totals. Only the top borough has active abilities.\n· Run: activate any number of face-up city cards in any chosen order, at most once per card this turn. Pay the activation cost, resolve all effects, then flip if indicated. Activation discards may be any card. A Hospital may flip instead of another card, keeping that card available for a future run, but never permitting a second activation this turn. Your top borough's run effect is mandatory and may happen before or after city activations. Finally gain poverty equal to your stack count, loan count and hand size. Wandsworth excludes hand size from this calculation.\n· Draw three: choose the source of each card separately. If fewer than three exist, take all remaining cards.\nSpecial abilities:\nHuguenots and Jewish Refugees are action cards: during development, draw two cards and remove the action card from the game. Wren lets you place up to two cards without matching discards, paying their printed building costs; same-turn covering restrictions still apply. Paupers cannot be built normally or discarded as matching payment. They may pay activation costs, be discarded by abilities or above the hand limit. Wren and Coffee House explicitly place any card, including Paupers and action cards with no run ability.\nCoffee House takes any card from the development board onto itself, paying only its printed cost; the new card may activate in the same run. Whitehall copies another face-up city card's activated ability without paying that card's activation cost; Whitehall follows its own flip rule. Shops collect £1 each time you place a city card, including themselves. Omnibuses collect £1 whenever anyone buys a borough. Collect these coins only when running the card; covering it does not collect them.\nHackney or Kensington allows you to pay £1 when discarding a card to treat it as any colour, including a Pauper. Southwark & Bermondsey permits one exchange of a hand card for a different development-board card each turn. Greenwich lets you discard any number of Paupers during its run effect for £1 and one poverty relief each. Westminster may replace the start-of-turn draw with zero or two cards. St Pancras may instead look at the top three city-deck cards, keep one, and return the others in their original relative order.\nDevelopment board and loans:\nThe board has two rows, each with player count plus one spaces. Discard into the top row first, then the bottom. When both are full, remove the bottom row, move the top row down and resume discarding at the top. Any draw can take a board card. Borrow at any time for £10 per loan, or £12 while City is your top borough; the debt is still £10. Mandatory costs automatically take loans if cash is insufficient.\nEnd and scoring:\nIf the city deck is empty at a turn's end, every other player takes one last turn. Gain one poverty per remaining hand card, then remove the hand. Add printed end prestige from all built cards, including covered and face-down cards. Repay as many loans as possible at £15 each. Lose seven prestige per unpaid loan and gain one prestige per full £3 remaining. Subtract the lowest poverty total from everyone, then apply poverty penalties: zero costs zero; 1–2 costs one; 3 costs two; 4 costs three; 5–10 costs 5, 7, 9, 11, 13, 15 respectively; every point above ten costs three more. Ties favour less poverty, then more boroughs, then the highest single printed city-card prestige. Remaining ties share victory.",
			invalid: "That action is not available. Please choose again.",
			mustDevelop: "Place at least one card or use an action card.",
			mustBorough: "Resolve your borough’s run effect first.",
			turn: "Turn {{n}}",
			wait: "Waiting for {{name}}",
			start: "You may repay loans before drawing",
			draw: "Choose a source · {{n}} cards to draw",
			choose: "Choose your main action",
			develop: "Choose a hand card, payment and stack",
			run: "Select city cards in the order you want to run them",
			overflow: "Discard down to nine cards",
			peek: "Choose a city card to keep",
			done: "London rebuilt",
			money: "Cash",
			prestige: "Prestige",
			poverty: "Poverty",
			loans: "Loans",
			hand: "Hand",
			city: "City",
			borough: "Borough",
			board: "Development board",
			deck: "City deck",
			market: "Borough market",
			stack: "Stack {{n}}",
			newStack: "New stack",
			hidden: "Covered or face-down city card",
			developButton: "Develop",
			runButton: "Run city",
			drawThree: "Draw three",
			begin: "Draw a card",
			zero: "Draw none",
			two: "Draw two",
			peekButton: "Look at top three",
			loan: "Take a loan",
			repay: "Repay £15",
			finish: "Finish action",
			finishRun: "Finish running",
			cancel: "Cancel",
			confirm: "Confirm",
			close: "Close",
			inspect: "Details",
			buy: "Buy · £{{n}}",
			build: "Build",
			playAction: "Play action",
			activate: "Activate",
			useBorough: "Run borough",
			swap: "Exchange a card",
			payment: "Choose payment card",
			discard: "Choose discards",
			target: "Choose a player",
			copy: "Choose a city card to copy",
			coffee: "Choose a development-board card",
			hospital: "Flip a Hospital instead",
			noHospital: "Flip the original card",
			recolour: "Pay £1 to change colour",
			freeBuilds: "{{n}} placements without matching discards",
			finalTurns: "{{n}} final turns left",
			buildCost: "Build £{{n}}",
			activationCost: "Activate £{{n}}",
			cardCost: "Discard one to activate",
			endVP: "{{n}} end prestige",
			moneyGain: "Gain £{{n}}",
			vpGain: "Gain {{n}} prestige",
			relief: "Remove {{n}} poverty",
			povertyGain: "Gain {{n}} poverty",
			flip: "Flip after activation",
			reusable: "Remain face up",
			north: "North",
			south: "South",
			riverside: "Riverside",
			inland: "Inland",
			drawN: "Draw {{n}} cards",
			topOnly: "Only the top borough’s ability is active",
			ownedBoroughs: "Owned boroughs",
			coins: "£{{n}} on card",
			selected: "Selected",
			placed: "Placed this turn",
			used: "Activated this turn",
			empty: "Empty space",
			result: "The rebuilding of London",
			winner: "{{name}} has the most prestige",
			score: "Final prestige",
			finalBuildings: "City cards",
			finalCash: "Cash",
			finalLoans: "Unpaid loans",
			finalPoverty: "Poverty penalty",
			reviewCity: "Review the city",
			startingPrestige: "Earned prestige",
			logs: {
				build: "{{name}} built {{card}}",
				buy: "{{name}} bought {{card}}",
				activate: "{{name}} activated {{card}}",
				loan: "{{name}} borrowed £{{n}}",
				repay: "{{name}} repaid a loan",
				run: "{{name}} finished running and gained {{n}} poverty",
				draw: "{{name}} drew {{n}} card(s)",
				discard: "{{name}} discarded {{card}}",
				action: "{{name}} played {{card}}",
				swap: "{{name}} exchanged for {{card}}",
				borough: "{{name}} resolved the borough’s run effect"
			},
			effects: {
				none: "No activated ability.",
				hospital: "When another city card would flip, you may flip this Hospital instead.",
				coffee: "No matching discard to build. When run, put any development-board card onto this card, paying its printed cost. It may activate this run.",
				draw2: "During development: draw two cards, then remove this card.",
				wren: "During development: place up to two hand cards without matching discards, paying printed costs. Remove Wren.",
				stock: "Take £2 from every other player.",
				bridge: "Gain £1 per face-up brown city card.",
				prison: "Discard up to three cards; remove one poverty per card.",
				millbank: "Discard up to three cards; gain one prestige and remove one poverty per card.",
				fire: "Each other player pays the bank £1 per riverside borough they own.",
				lloyds: "A chosen player gains two poverty.",
				police: "A chosen player gains one poverty.",
				omnibus: "Put £1 here whenever anyone buys a borough. Collect when run.",
				shops: "Put £1 here whenever you place a city card. Collect when run.",
				boats: "Gain £2 per riverside borough you own.",
				town: "Gain one prestige per face-up blue or pink city card, including this one.",
				north: "Gain £2 per north London borough.",
				south: "Gain £2 per south London borough.",
				underground: "Gain three prestige plus one per owned borough. Pay £2 if you own boroughs on both sides of the river.",
				whitehall: "Copy another face-up city card’s activated ability, ignoring its activation cost.",
				basic: ""
			},
			abilities: {
				none: "",
				loan: "Receive £12 per loan.",
				greenwich: "When run, discard any number of Paupers for £1 and one poverty relief each.",
				colour: "Pay £1 when discarding a card to treat it as any colour.",
				battersea: "Remove two poverty each run.",
				hammersmith: "Remove one poverty and gain £2 each run.",
				paddington: "Remove one poverty each run.",
				swap: "Once per turn exchange a hand card with a development-board card. Gain one poverty each run.",
				peek: "At turn start, look at the top three deck cards, keep one and return the others.",
				wandsworth: "Hand cards generate no poverty when running. Gain two poverty each run.",
				westminster: "At turn start, you may draw zero or two cards instead."
			},
			colours: {
				brown: "Economy",
				blue: "Science & culture",
				pink: "Politics",
				grey: "Paupers"
			},
			cards: {
				almshouses: "Almshouses",
				bank: "Bank of England",
				coffee: "Coffee House",
				covent: "Covent Garden",
				eastIndia: "East India Company",
				fishmongers: "Fishmongers",
				monument: "Great Fire Monument",
				grocers: "Grocers",
				haberdashers: "Haberdashers",
				hospital: "Hospital",
				huguenots: "Huguenots",
				leather: "Leather Industry",
				mercers: "Mercers",
				paupers: "Paupers",
				salters: "Salters",
				stPauls: "St Paul’s",
				stock: "Stock Exchange",
				vauxhall: "Vauxhall Gardens",
				vintners: "Vintners",
				water: "Water Works",
				woolwich: "Woolwich Arsenal",
				wren: "Wren",
				albertDock: "Albert Dock",
				brewing: "Brewing",
				bridge: "Bridge",
				britishMuseum: "British Museum",
				brixton: "Brixton Prison",
				buckingham: "Buckingham Palace",
				clockmakers: "Clockmakers",
				fire: "Fire Brigade",
				highgate: "Highgate Cemetery",
				kew: "Kew Gardens",
				lloyds: "Lloyds of London",
				millbank: "Millbank Prison",
				nelson: "Nelson’s Column",
				omnibus: "Omnibus",
				oxford: "Oxford Street",
				police: "Police Force",
				regent: "Regent Street",
				victoriaDock: "Royal Victoria Dock",
				shipbuilding: "Shipbuilding",
				shops: "Shops",
				steamboats: "Steamboats",
				lights: "Street Lights",
				townhouses: "Town Houses",
				turners: "Turners",
				university: "University of London",
				upholders: "Upholders",
				westIndia: "West India Docks",
				workers: "Workers’ Houses",
				albertHall: "Albert Hall",
				billingsgate: "Billingsgate Market",
				grandHotel: "Grand Hotel",
				exhibition: "Great Exhibition",
				refugees: "Jewish Refugees",
				naturalMuseum: "Natural History Museum",
				sewers: "Sewers",
				smithfield: "Smithfield Market",
				embankment: "Thames Embankment",
				towerBridge: "Tower Bridge",
				trainNorth: "Train Station North",
				trainSouth: "Train Station South",
				underground: "Underground",
				whitehall: "Whitehall"
			},
			boroughs: {
				battersea: "Battersea",
				bethnal: "Bethnal Green, Stepney & Poplar",
				camberwell: "Camberwell",
				city: "City",
				deptford: "Deptford",
				fulham: "Fulham & Chelsea",
				greenwich: "Greenwich",
				hackney: "Hackney",
				hammersmith: "Hammersmith",
				hampstead: "Hampstead",
				islington: "Islington & Stoke Newington",
				kensington: "Kensington",
				lambeth: "Lambeth",
				lewisham: "Lewisham",
				paddington: "Paddington",
				southwark: "Southwark & Bermondsey",
				marylebone: "St Marylebone",
				pancras: "St Pancras",
				wandsworth: "Wandsworth",
				westminster: "Westminster"
			}
		}
	}
};
//#endregion
export { Je as default };
