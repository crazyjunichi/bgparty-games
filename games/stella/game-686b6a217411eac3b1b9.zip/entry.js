import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useEffect as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useI18nSettings as o, useT as s } from "@bgparty/sdk/i18n";
import { useWakeLock as c } from "@bgparty/sdk/use-wake-lock";
import { useFxAnchor as l, useFxAnchorsMaybe as u } from "@bgparty/sdk/fx/anchors";
import { usePrefersReducedMotion as d } from "@bgparty/sdk/fx/use-reduced-motion";
import { GameScreen as f } from "@bgparty/sdk/ui/game-screen";
import { seatName as p } from "@bgparty/sdk/ui/player-strip";
import { createPortal as m } from "react-dom";
import { Fragment as h, jsx as g, jsxs as _ } from "react/jsx-runtime";
//#region src/games/stella/data.ts
var v = [...Array.from({ length: 69 }, (e, t) => 152200 + t), ...Array.from({ length: 15 }, (e, t) => 152300 + t)], y = (/* @__PURE__ */ "ring/plate.wardrobe/lamp.cold/evil.shirt/tall.illness/old.ice/dog.day/heavy.octopus/shovel.happiness/cake.safety/armour.slow/firefighter.fire/bus.horse/ear.group/road.red/earth.pleasant/wind.lightning/car.man/woman.enemy/knight.black/salad.brown/spider.grey/arrow.pink/radish.green/sandwich.chicken/glasses.ocean/prison.lentils/house.summer/surprise.white/wheat.palm/rubber band.veterinarian/travel.teacher/vase.chest/hat.robot/dessert.honey/pig.dragon/dinosaur.wolf/yellow.cow/bag.disgust/suitcase.weather/ugly.airport/castle.desert/strawberry.train/tomato.chess/jungle.moon/Mars.mountain/beach.pen/helicopter.snow/pear.rat/camel.war/treasure.notebook/shark.bear/moustache.snake/anger.monkey/fear.holiday/snail.sadness/fries.joy/wood.sofa/box.stone/cape.diamond/boat.guitar/toy.bed/blue.soup/painting.autumn/letter.paper/hero.hole/parachute.strange/meal.dwarf/night.arm/detective.eye/water.foot/helmet.plane/trailer.zoo/motorcycle.bicycle/air.pirate/nurse.peak/doctor.soldier/cook.map/president.cane/planet.small/young.clever/story.tall/light.banana/leg.circus/chocolate.dove/fish.unicorn/piano.mouse/sugar.friends/king.fast/queen.beautiful/hot.head/cheese.child/spaceship.winter/school.tie/butter.mushroom/ball.camera/cauliflower.camera/book.ankle/mouth.spring/cat.goat/orange".split(".")).map((e) => e.split("/")), b = Object.fromEntries(Object.entries({
	152200: "old woman astronaut helmet stars space wood wardrobe house night light treasure",
	152201: "group family young old birthday cake meal happiness friends party glass",
	152202: "city road tall grey travel stone old ruins columns luggage",
	152203: "man woman love fire volcano red wine meal friends hot",
	152204: "snail forest tree flowers green house ruins slow stone",
	152205: "man old scarf wind mountain ice blue cold climb travel",
	152206: "child moon night light desert stars small house warm strange",
	152207: "child toy robot train dinosaur group house joy",
	152208: "fox snow winter cold red trees travel child",
	152209: "forest tree house animal old green wood",
	152210: "child water blue octopus fish ocean dream sleep",
	152211: "animals school teacher book paper green house lesson",
	152212: "theatre child light hero cape red stage puppet forest winter",
	152213: "girl red pink birds flowers tree hair winter strange",
	152214: "old man king beard clouds white tall mountain crown",
	152215: "yellow green garden plant water light magic tower",
	152216: "girl boat water forest blue glass plants ocean",
	152217: "family old story game group glasses house paper table",
	152218: "whale sea ocean water blue fish cold wind",
	152219: "girl jungle bamboo green house doorway light travel",
	152220: "circus group hippo animal joy party strange cards",
	152221: "robot machine desk moon night red light window clock",
	152222: "man monkey helmet swim blue ocean water fish space",
	152223: "forest tree animal light green golden dog fox house",
	152224: "book light stars dark house paper story",
	152225: "girl boy spider web forest basket tree fear",
	152226: "boy night wolf lantern light forest black fear",
	152227: "forest tree sword wood light green strange",
	152228: "temple house garden stone road travel statue",
	152229: "woman desert stone rock green sun lonely",
	152230: "squirrel animal forest yellow sun wind tree autumn",
	152231: "woman green forest flowers mask leaves strange",
	152232: "red house telephone forest night blue tree",
	152233: "frog green roof well water house wood stone",
	152234: "wolf man bird forest hat backpack white flower clouds",
	152235: "cat forest autumn orange fire light house warm",
	152236: "man monkey forest branch animal travel wood",
	152237: "fish water pink glass drink ice meal",
	152238: "rabbit plane blue cloud flight toy helmet pilot",
	152239: "giant man octopus beard old ocean bath water",
	152240: "boat ship sea ice winter cold blue adventure",
	152241: "girl fire glasses chemistry bottle light school volcano",
	152242: "child girl city winter snow blue wind",
	152243: "child boy candle dark fear night light shadows house",
	152244: "man tree wood house village green tall",
	152245: "deer forest autumn tree yellow animal travel man",
	152246: "woman witch cat fire magic black house book",
	152247: "chess king queen cards horse sword water fountain",
	152248: "hippo animal orange coat suitcase jungle tropical water",
	152249: "friends group child horse white green animal",
	152250: "woman violin music lamp night house man water",
	152251: "man house chair window television pink red newspaper",
	152252: "old man piano girl music black white stars",
	152253: "woman restaurant cook house meal bread light",
	152254: "woman circus dance theatre pink light music",
	152255: "children flower underwater blue water forest shadow",
	152256: "boy sleep chair book house tired paper",
	152257: "robot clock window yellow light house machine",
	152258: "boy man blue whale water bubble detective magnifying glass",
	152259: "woman room dream grey light bath forest river",
	152260: "woman house attic blue stars sea stingray strange",
	152261: "paper story map pirate treasure desk room",
	152262: "boat rabbit frog water summer green joy plants",
	152263: "man robot bird tea meal group clock strange",
	152264: "man tree house sun yellow road sunflower wood",
	152265: "robot tree forest wood boxes golden light green",
	152266: "cat house dark strange number paper game stairs dice",
	152267: "woman stars sun moon day night clothes magic",
	152268: "red chair desert flower dry earth lonely music guitar",
	152300: "woman blue dress desert earth deer tree night stars bow",
	152301: "man ice white paper triangle mountain winter fear climb",
	152302: "green field school map maze boots giant strange",
	152303: "cake glass food light surprise white red shell",
	152304: "woman desert mountain clouds warm travel foot sand",
	152305: "robot magnifying glass detective child moon city",
	152306: "girl reading book blue plant house cat glasses",
	152307: "tea cup flowers meal pink house hat party",
	152308: "man prison chains justice gold scales black ball",
	152309: "bed snake white room stone shadow light fear",
	152310: "girl ship spaceship red helmet light travel",
	152311: "children school teacher lesson blue group paper",
	152312: "woman sea water blue space bubble fish jellyfish",
	152313: "man town train travel photo story glass road",
	152314: "girl forest house road light book travel trees"
}).map(([e, t]) => [e, t.split(" ")])), x = {
	joy: [
		"happiness",
		"friends",
		"party"
	],
	happiness: [
		"joy",
		"friends",
		"love"
	],
	sadness: [
		"lonely",
		"night",
		"fear"
	],
	safety: [
		"helmet",
		"armour",
		"house"
	],
	evil: [
		"fear",
		"black",
		"wolf"
	],
	fear: [
		"dark",
		"night",
		"black",
		"wolf"
	],
	illness: [
		"doctor",
		"nurse",
		"old"
	],
	pleasant: [
		"love",
		"joy",
		"flowers"
	],
	strange: [
		"magic",
		"dream",
		"robot"
	],
	treasure: [
		"gold",
		"light",
		"stars"
	],
	holiday: [
		"travel",
		"summer",
		"beach"
	],
	weather: [
		"rain",
		"snow",
		"clouds",
		"wind"
	],
	travel: [
		"boat",
		"ship",
		"road",
		"plane",
		"map"
	],
	airport: [
		"plane",
		"flight",
		"travel"
	],
	night: [
		"moon",
		"dark",
		"stars"
	],
	light: [
		"candle",
		"lamp",
		"sun",
		"stars"
	],
	paper: [
		"book",
		"letter",
		"map"
	],
	beautiful: [
		"woman",
		"flower",
		"magic"
	],
	cold: [
		"winter",
		"snow",
		"ice"
	],
	hot: [
		"fire",
		"summer",
		"red"
	],
	hero: [
		"cape",
		"knight",
		"armour"
	],
	story: [
		"book",
		"old",
		"child"
	],
	painting: [
		"paper",
		"artist",
		"camera"
	],
	captain: [
		"boat",
		"ship",
		"map"
	],
	spring: ["flower", "green"],
	summer: ["sun", "warm"],
	autumn: [
		"orange",
		"yellow",
		"forest"
	]
};
function S(e, t) {
	let n = t.custom?.toLowerCase() ?? y[t.pair]?.[t.side]?.toLowerCase() ?? "", r = b[e] ?? [];
	return n.split(" ").reduce((e, t) => e + +!!r.includes(t), 0) + (x[n] ?? []).filter((e) => r.includes(e)).length * .35;
}
//#endregion
//#region src/games/stella/meta.ts
var C = {
	id: "stella",
	tier: "alpha",
	mechanics: ["word-association", "push-your-luck"],
	interactionTags: [],
	nameKey: "games.stella.name",
	descKey: "games.stella.desc",
	rulesKey: "games.stella.rules",
	icon: "🌠",
	iconImg: "games/stella.webp",
	minPlayers: 3,
	maxPlayers: 6,
	bestPlayers: [
		4,
		5,
		6
	],
	accent: "#a77bbd",
	releasedAt: "2026-11-03T23:53:00+08:00",
	search: {
		py: "xing wu yu zhui xing ren",
		init: "xwy zxr"
	},
	hotseat: "cover"
}, w = t.int().min(0).max(14), T = t.string(), E = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("select"),
		slots: t.array(w).min(1).max(10)
	}),
	t.object({
		type: t.literal("reveal"),
		slot: w
	}),
	t.object({ type: t.literal("swapWord") }),
	t.object({ type: t.literal("ready") }),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), D = t.object({ customWords: t.string().max(600).default("") }).default({ customWords: "" }), O = t.object({
	slot: w,
	by: T,
	matches: t.array(T),
	awarded: t.array(T),
	stars: t.int().min(0).max(3)
}), k = t.object({
	pair: t.int(),
	side: t.int().min(0).max(1),
	custom: t.string().nullable()
}), A = t.object({
	rid: T,
	score: t.int(),
	submitted: t.boolean(),
	count: t.int().nullable(),
	dark: t.boolean(),
	fallen: t.boolean(),
	roundStars: t.int()
}), j = t.object({
	round: t.int(),
	board: t.array(t.int()),
	word: k,
	reveals: t.array(O),
	scores: t.record(T, t.int()),
	dark: T.nullable(),
	fallen: t.array(T),
	selections: t.record(T, t.array(w))
}), M = t.object({
	phase: t.enum([
		"select",
		"announce",
		"reveal",
		"focus",
		"resonate",
		"travel",
		"award",
		"falling",
		"resolve",
		"roundOver",
		"done"
	]),
	round: t.int().min(1).max(4),
	board: t.array(t.int()).length(15),
	word: k,
	wordRevision: t.int(),
	swapVotes: t.array(T),
	players: t.array(A),
	first: T,
	turn: T.nullable(),
	reveals: t.array(O),
	lastReveal: O.nullable(),
	currentReveal: t.object({
		slot: w,
		by: T
	}).nullable(),
	ready: t.array(T),
	roundScores: t.record(T, t.int()),
	history: t.array(j)
}), N = t.object({
	slots: t.array(w),
	submitted: t.boolean()
}), P = {
	announce: 1e3,
	focus: 1400,
	resonate: 1200,
	travel: 800,
	award: 800,
	falling: 1800,
	resolve: 800,
	score: 1500
}, F = (e) => ({ code: e }), I = (e) => Object.fromEntries(e.map((e) => [e, 0]));
function L(t, n, r) {
	let i = [...t], a = r;
	for (let t = i.length - 1; t > 0; t--) {
		let r = e(n, a++, t + 1);
		[i[t], i[r]] = [i[r], i[t]];
	}
	return {
		cards: i,
		cursor: a
	};
}
function R(e) {
	let t = e.wordDeck[e.round - 1];
	return {
		pair: t,
		side: 0,
		custom: e.custom.length ? e.custom[t] : null
	};
}
function z(t, n, r) {
	let i = L(v, r, 0), a = [...new Set(t.customWords.split("\n").map((e) => e.trim()).filter(Boolean))].slice(0, 10), o = a.length >= 4 ? a : [], s = L(Array.from({ length: o.length || y.length }, (e, t) => t), r, i.cursor), c = e(r, s.cursor, n.length), l = {
		players: [...n],
		seed: r,
		cursor: s.cursor + 1,
		deck: i.cards.slice(15),
		board: i.cards.slice(0, 15),
		wordDeck: s.cards,
		custom: o,
		phase: "select",
		round: 1,
		firstIndex: c,
		turnIndex: c,
		word: {
			pair: 0,
			side: 0,
			custom: null
		},
		wordRevision: 0,
		swapVotes: [],
		selections: {},
		dark: null,
		fallen: [],
		stars: I(n),
		hits: I(n),
		scores: I(n),
		reveals: [],
		lastReveal: null,
		currentReveal: null,
		ready: [],
		roundScores: {},
		history: [],
		beatMs: 0
	};
	return l.word = R(l), { state: l };
}
function B(e, t) {
	let n = new Set(e.reveals.map((e) => e.slot));
	for (let r = 1; r <= e.players.length; r++) {
		let i = (t + r + e.players.length) % e.players.length, a = e.players[i];
		if (!e.fallen.includes(a) && (e.selections[a] ?? []).some((e) => !n.has(e))) return i;
	}
	return -1;
}
function V(e) {
	e.roundScores = Object.fromEntries(e.players.map((t) => [t, e.stars[t] - (e.dark === t && e.fallen.includes(t) ? e.hits[t] : 0)])), e.scores = Object.fromEntries(e.players.map((t) => [t, e.scores[t] + e.roundScores[t]])), e.history.push({
		round: e.round,
		board: [...e.board],
		word: { ...e.word },
		reveals: e.reveals.map((e) => ({
			...e,
			matches: [...e.matches],
			awarded: [...e.awarded]
		})),
		scores: { ...e.roundScores },
		dark: e.dark,
		fallen: [...e.fallen],
		selections: structuredClone(e.selections)
	}), e.phase = "roundOver", e.ready = [], e.turnIndex = -1, e.beatMs = 0;
}
function H(e, t, { by: n }) {
	if (t.type === "tick") {
		if (n !== "$engine") return F("games.stella.errPhase");
		if (![
			"announce",
			"focus",
			"resonate",
			"travel",
			"award",
			"falling",
			"resolve"
		].includes(e.phase)) return { state: e };
		let t = structuredClone(e);
		if (t.phase === "focus" && t.currentReveal) {
			let { slot: e, by: n } = t.currentReveal, r = t.players.filter((n) => t.selections[n].includes(e)), i = r.length === 1 ? 0 : r.length === 2 ? 3 : 2, a = {
				slot: e,
				by: n,
				matches: r,
				awarded: i ? r.filter((e) => !t.fallen.includes(e)) : [],
				stars: i
			};
			return t.reveals.push(a), t.lastReveal = a, i ? (t.phase = "resonate", t.beatMs = P.resonate) : (t.fallen.push(n), t.phase = "falling", t.beatMs = P.falling), { state: t };
		}
		if (t.phase === "resonate") return t.phase = "travel", t.beatMs = P.travel, { state: t };
		if (t.phase === "travel" && t.lastReveal) {
			for (let e of t.lastReveal.awarded) t.stars[e] += t.lastReveal.stars, t.hits[e]++;
			return t.phase = "award", t.beatMs = P.award, { state: t };
		}
		if (t.phase === "falling") return t.phase = "resolve", t.beatMs = P.resolve, { state: t };
		t.currentReveal = null;
		let r = B(t, t.phase === "announce" ? t.firstIndex - 1 : t.turnIndex);
		return r < 0 ? (V(t), { state: t }) : (t.turnIndex = r, t.phase = "reveal", t.beatMs = 0, { state: t });
	}
	if (!e.players.includes(n) || e.phase === "done") return F("games.stella.errPhase");
	if (t.type === "select") {
		if (e.phase !== "select" || e.selections[n]) return F("games.stella.errPhase");
		if (new Set(t.slots).size !== t.slots.length || t.slots.length < 1 || t.slots.length > 10 || t.slots.some((e) => e < 0 || e >= 15 || !Number.isInteger(e))) return F("games.stella.errSelection");
		let r = structuredClone(e);
		if (r.selections[n] = [...t.slots].sort((e, t) => e - t), r.players.every((e) => r.selections[e])) {
			let e = Math.max(...r.players.map((e) => r.selections[e].length)), t = r.players.filter((t) => r.selections[t].length === e);
			r.dark = t.length === 1 ? t[0] : null, r.phase = "announce", r.beatMs = P.announce;
		}
		return { state: r };
	}
	if (t.type === "swapWord") {
		if (e.phase !== "select" || Object.keys(e.selections).length || e.custom.length) return F("games.stella.errPhase");
		let t = structuredClone(e);
		return t.swapVotes = t.swapVotes.includes(n) ? t.swapVotes.filter((e) => e !== n) : [...t.swapVotes, n], t.swapVotes.length === t.players.length && (t.word.side = 1 - t.word.side, t.wordRevision++, t.swapVotes = []), { state: t };
	}
	if (t.type === "reveal") {
		if (e.phase !== "reveal" || e.players[e.turnIndex] !== n) return F("games.stella.errTurn");
		if (!e.selections[n]?.includes(t.slot) || e.reveals.some((e) => e.slot === t.slot)) return F("games.stella.errCard");
		let r = structuredClone(e);
		return r.currentReveal = {
			slot: t.slot,
			by: n
		}, r.phase = "focus", r.beatMs = P.focus, { state: r };
	}
	if (t.type === "ready") {
		if (e.phase !== "roundOver" || e.ready.includes(n)) return F("games.stella.errPhase");
		let t = structuredClone(e);
		if (t.ready.push(n), t.ready.length === t.players.length) {
			if (t.round === 4) return t.phase = "done", { state: t };
			let e = 3 - t.round;
			return t.board.splice(e * 5, 5, ...t.deck.splice(0, 5)), t.round++, t.firstIndex = (t.firstIndex + 1) % t.players.length, t.turnIndex = t.firstIndex, t.word = R(t), t.wordRevision++, t.phase = "select", t.selections = {}, t.dark = null, t.fallen = [], t.stars = I(t.players), t.hits = I(t.players), t.reveals = [], t.lastReveal = null, t.currentReveal = null, t.ready = [], t.roundScores = {}, t.swapVotes = [], {
				state: t,
				fx: [{
					kind: "stellaRow",
					data: { row: e }
				}]
			};
		}
		return { state: t };
	}
	return F("games.stella.errPhase");
}
var ee = {
	meta: C,
	saveCompatibility: {
		version: "2",
		migrate: ({ version: e, log: t }) => {
			if (e !== "1") return null;
			let n = t[0];
			if (!Array.isArray(n?.players) || typeof n.seed != "number" || !D.safeParse(n.config).success) return null;
			let r = z(D.parse(n.config), n.players, n.seed).state, i = [{
				...n,
				saveVersion: "2"
			}];
			for (let e of t.slice(1)) {
				let t = e, n = E.safeParse(t?.action);
				if (typeof t?.by != "string" || !n.success) return null;
				let a = H(r, n.data, { by: t.by });
				if ("code" in a) return null;
				if (r = a.state, i.push(e), n.data.type === "reveal") for (; [
					"focus",
					"resonate",
					"travel",
					"falling"
				].includes(r.phase);) {
					let e = {
						type: "tick",
						now: 0
					}, t = H(r, e, { by: "$engine" });
					if ("code" in t) return null;
					r = t.state, i.push({
						by: "$engine",
						action: e
					});
				}
			}
			return i;
		}
	},
	schemas: {
		action: E,
		publicView: M,
		privateView: N,
		config: D
	},
	setup: z,
	reduce: H,
	viewFor: (e, t) => ({
		public: {
			phase: e.phase,
			round: e.round,
			board: [...e.board],
			word: { ...e.word },
			wordRevision: e.wordRevision,
			swapVotes: [...e.swapVotes],
			players: e.players.map((t) => ({
				rid: t,
				score: e.scores[t],
				submitted: !!e.selections[t],
				count: e.phase === "select" ? null : e.selections[t]?.length ?? 0,
				dark: e.dark === t,
				fallen: e.fallen.includes(t),
				roundStars: e.stars[t]
			})),
			first: e.players[e.firstIndex],
			turn: e.phase === "reveal" ? e.players[e.turnIndex] : null,
			reveals: structuredClone(e.reveals),
			lastReveal: e.lastReveal ? structuredClone(e.lastReveal) : null,
			currentReveal: e.currentReveal ? { ...e.currentReveal } : null,
			ready: [...e.ready],
			roundScores: { ...e.roundScores },
			history: structuredClone(e.history)
		},
		...e.players.includes(t) ? { private: {
			slots: [...e.selections[t] ?? []],
			submitted: !!e.selections[t]
		} } : {}
	}),
	status: (e) => {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]);
		return {
			phase: "done",
			winner: t.filter((n) => e.scores[n] === e.scores[t[0]]),
			ranking: t,
			scores: { ...e.scores }
		};
	},
	nextTickIn: (e) => [
		"announce",
		"focus",
		"resonate",
		"travel",
		"award",
		"falling",
		"resolve"
	].includes(e.phase) ? e.beatMs : null
}, U = (e) => `games/stella/art/${e}.webp`, W = (e) => `${"ABC"[Math.floor(e / 5)]}${e % 5 + 1}`, G = (e, t) => e.custom ?? t("games.stella.wordPairs").split("|")[e.pair]?.split("/")[e.side] ?? "";
function K({ hollow: e = !1 }) {
	return /* @__PURE__ */ g("svg", {
		viewBox: "0 0 32 32",
		"aria-hidden": !0,
		className: "stella-star",
		children: /* @__PURE__ */ g("path", {
			d: "m16 2 4.2 8.8 9.8 1.4-7 6.8 1.7 9.7-8.7-4.6-8.7 4.6L9 19 2 12.2l9.8-1.4Z",
			fill: e ? "none" : "currentColor",
			stroke: "currentColor",
			strokeWidth: "1.6",
			strokeLinejoin: "round"
		})
	});
}
function q() {
	return /* @__PURE__ */ g("svg", {
		className: "stella-explorer",
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		children: /* @__PURE__ */ g("path", {
			d: "M5 22V3m0 1c5-5 9 5 15 0v11c-6 5-10-5-15 0",
			fill: "#e6a6bf",
			stroke: "#ffe4af",
			strokeWidth: "2",
			strokeLinecap: "round",
			strokeLinejoin: "round"
		})
	});
}
function J({ dark: e = !1, fallen: t = !1, color: n }) {
	return /* @__PURE__ */ _("svg", {
		viewBox: "0 0 42 48",
		"aria-hidden": !0,
		className: `stella-lantern${t ? " is-fallen" : ""}`,
		style: { "--lantern": n ?? "#e2bd7b" },
		children: [
			/* @__PURE__ */ g("path", {
				d: "M5 5Q21 0 37 5L35 30 21 44 7 30Z",
				fill: e ? "#252445" : "var(--lantern)",
				stroke: "#e8d6a5",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ g("path", {
				d: "M9 8Q21 5 33 8L31 28 21 38 11 28Z",
				fill: e ? "#34324c" : "#f8ead0",
				opacity: ".65"
			}),
			e ? /* @__PURE__ */ g("path", {
				d: "M24 11c-8 1-11 12-2 16-10 1-15-11-6-16 3-2 5-1 8 0Z",
				fill: "#a8d9e6"
			}) : /* @__PURE__ */ g("path", {
				d: "m21 11 2.5 5 5.5.8-4 3.9.9 5.5-4.9-2.6-4.9 2.6.9-5.5-4-3.9 5.5-.8Z",
				fill: "#f5bc54"
			})
		]
	});
}
function Y({ card: e, slot: t, selected: n = !1, result: r, enabled: i = !1, target: a = !1, onClick: o }) {
	let c = s(), { ref: u } = l(`stella:card:${t}`);
	return /* @__PURE__ */ _("button", {
		type: "button",
		ref: u,
		className: `stella-picture${n ? " is-selected" : ""}${r ? " is-revealed" : ""}${r?.stars === 0 ? " is-lost" : ""}${a ? " is-target" : ""}`,
		disabled: !i,
		onClick: o,
		"aria-label": `${c("games.stella.position", { label: W(t) })}${n ? ` · ${c("games.stella.selected")}` : ""}${r ? ` · ${c("games.stella.revealed")}` : ""}`,
		"aria-pressed": n,
		children: [
			/* @__PURE__ */ g("img", {
				src: U(e),
				alt: c("games.stella.illustration", { n: v.indexOf(e) + 1 }),
				draggable: !1
			}),
			/* @__PURE__ */ g("span", {
				className: "stella-picture-number",
				children: W(t)
			}),
			n && !r && /* @__PURE__ */ g("span", {
				className: "stella-check",
				"aria-hidden": !0,
				children: "✓"
			}),
			r && /* @__PURE__ */ g("span", {
				className: "stella-picture-result",
				children: r.stars === 0 ? "×" : /* @__PURE__ */ g(h, { children: Array.from({ length: r.stars }, (e, t) => /* @__PURE__ */ g(K, { hollow: t === 2 }, t)) })
			}),
			a && /* @__PURE__ */ g("svg", {
				viewBox: "0 0 100 148",
				preserveAspectRatio: "none",
				className: "stella-target",
				"aria-hidden": !0,
				children: /* @__PURE__ */ g("rect", {
					x: "2",
					y: "2",
					width: "96",
					height: "144",
					rx: "5"
				})
			})
		]
	});
}
function X({ board: e, initial: t, onClose: r }) {
	let o = s(), c = i(null);
	n(() => {
		let e = c.current;
		return e?.showModal(), () => e?.close();
	}, []);
	let [l, u] = a(t);
	return m(/* @__PURE__ */ g("dialog", {
		ref: c,
		className: "stella-gallery stella-theme",
		"aria-label": o("games.stella.gallery"),
		onCancel: (e) => {
			e.preventDefault(), r();
		},
		onClick: (e) => {
			e.target === e.currentTarget && r();
		},
		onKeyDown: (t) => {
			t.key === "ArrowLeft" && (t.preventDefault(), u((l + e.length - 1) % e.length)), t.key === "ArrowRight" && (t.preventDefault(), u((l + 1) % e.length));
		},
		children: /* @__PURE__ */ _("div", {
			className: "stella-gallery-inner",
			children: [
				/* @__PURE__ */ _("header", { children: [/* @__PURE__ */ g("span", { children: o("games.stella.position", { label: W(l) }) }), /* @__PURE__ */ _("button", {
					type: "button",
					onClick: r,
					children: [o("games.stella.close"), " ×"]
				})] }),
				/* @__PURE__ */ g("img", {
					src: U(e[l]),
					alt: o("games.stella.illustration", { n: v.indexOf(e[l]) + 1 })
				}),
				/* @__PURE__ */ _("footer", { children: [
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => u((l + e.length - 1) % e.length),
						children: ["← ", o("games.stella.previous")]
					}),
					/* @__PURE__ */ _("span", { children: [
						l + 1,
						" / ",
						e.length
					] }),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => u((l + 1) % e.length),
						children: [o("games.stella.next"), " →"]
					})
				] })
			]
		})
	}), document.body);
}
function te({ word: e, onClose: t }) {
	let r = s(), a = i(null);
	return n(() => {
		let e = a.current;
		return e?.showModal(), () => e?.close();
	}, []), m(/* @__PURE__ */ g("dialog", {
		ref: a,
		className: "stella-theme stella-word-dialog",
		"aria-label": r("games.stella.wordDetails"),
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		onClick: (e) => {
			e.target === e.currentTarget && t();
		},
		children: /* @__PURE__ */ _("div", { children: [/* @__PURE__ */ _("button", {
			type: "button",
			onClick: t,
			children: [r("games.stella.close"), " ×"]
		}), /* @__PURE__ */ g("p", { children: e })] })
	}), document.body);
}
//#endregion
//#region src/games/stella/motion.tsx
function Z({ value: e, motion: t }) {
	let n = i(null), a = i(e);
	return r(() => {
		let r = n.current, i = a.current;
		if (a.current = e, !r || !t || i === e) return;
		let o = performance.now(), s = 0, c = (t) => {
			let n = Math.min(1, (t - o) / 400);
			r.textContent = String(Math.round(i + (e - i) * (1 - (1 - n) ** 2))), n < 1 && (s = requestAnimationFrame(c));
		};
		r.textContent = String(i), s = requestAnimationFrame(c);
		let l = r.animate([
			{ transform: "scale(1)" },
			{
				transform: "scale(1.35)",
				offset: .4
			},
			{ transform: "scale(1)" }
		], {
			duration: 520,
			easing: "ease-out"
		});
		return () => {
			cancelAnimationFrame(s), l.cancel(), r.textContent = String(e);
		};
	}, [e, t]), /* @__PURE__ */ g("span", {
		ref: n,
		className: "stella-number",
		children: e
	});
}
function ne({ current: e, result: t, board: n, phase: a, name: o, motion: c }) {
	let d = s(), f = u(), p = i(null), { ref: m } = l("stella:focus");
	r(() => {
		let t = p.current, n = f?.measure(`stella:card:${e.slot}`), r = f?.measure("stella:focus"), i = f?.measure("stella:board");
		if (!t || !c || !n || !r) return;
		let a = i && n.y < i.y + i.h && n.y + n.h > i.y, o = t.animate([{
			transform: a ? `translate(${n.x + n.w / 2 - r.x - r.w / 2}px,${n.y + n.h / 2 - r.y - r.h / 2}px) scale(${n.w / r.w})` : "translateY(20px) scale(.92)",
			opacity: +!!a
		}, {
			transform: "translate(0,0) scale(1)",
			opacity: 1
		}], {
			duration: 500,
			easing: "cubic-bezier(.2,.8,.2,1)",
			fill: "both"
		});
		return () => o.cancel();
	}, [
		f,
		e.slot,
		c
	]);
	let h = a !== "focus" && t?.slot === e.slot;
	return /* @__PURE__ */ g("div", {
		className: `stella-reveal-focus is-${a}`,
		children: /* @__PURE__ */ _("figure", { children: [/* @__PURE__ */ _("div", {
			className: "stella-focus-image",
			children: [/* @__PURE__ */ g("img", {
				ref: (e) => {
					p.current = e, m(e);
				},
				src: U(n[e.slot]),
				alt: d("games.stella.position", { label: W(e.slot) })
			}), h && /* @__PURE__ */ g("div", {
				className: "stella-focus-symbol",
				"aria-hidden": !0,
				children: t.stars ? Array.from({ length: t.stars }, (e, t) => /* @__PURE__ */ g(K, { hollow: t === 2 }, t)) : "×"
			})]
		}), /* @__PURE__ */ _("figcaption", { children: [/* @__PURE__ */ _("strong", { children: [
			W(e.slot),
			" · ",
			o
		] }), /* @__PURE__ */ g("span", { children: d(h ? t.stars === 0 ? "games.stella.noMatch" : t.stars === 3 ? "games.stella.superSpark" : "games.stella.spark" : "games.stella.revealing") })] })] })
	});
}
function re({ rid: e, index: t, count: r }) {
	let a = u(), o = i(null);
	return n(() => {
		let n = o.current, i = a?.measure("stella:focus"), s = a?.measure(`stella:score:${e}`), c = a?.measure("stella:flight-layer");
		if (!n || !i || !s || !c) return;
		let l = i.x + i.w / 2 - c.x - 13 + (t - (r - 1) / 2) * 30, u = i.y + i.h / 2 - c.y - 13, d = s.x + s.w / 2 - c.x - 13 - l, f = s.y + s.h / 2 - c.y - 13 - u, p = n.animate([
			{
				transform: `translate(${l}px,${u}px) scale(.8)`,
				opacity: 0
			},
			{
				transform: `translate(${l + d * .12}px,${u + f * .12 - 18}px) scale(1.2)`,
				opacity: 1,
				offset: .18
			},
			{
				transform: `translate(${l + d}px,${u + f}px) scale(.65)`,
				opacity: 1,
				offset: .94
			},
			{
				transform: `translate(${l + d}px,${u + f}px) scale(.3)`,
				opacity: 0
			}
		], {
			duration: P.travel - 140,
			delay: t * 60,
			easing: "cubic-bezier(.3,.5,.3,1)",
			fill: "both"
		});
		return () => p.cancel();
	}, [
		a,
		e,
		t,
		r
	]), /* @__PURE__ */ g("span", {
		ref: o,
		className: "stella-flying-star",
		children: /* @__PURE__ */ g(K, {})
	});
}
function ie({ reveal: e }) {
	let { ref: t } = l("stella:flight-layer");
	return /* @__PURE__ */ g("div", {
		ref: t,
		className: "stella-flight-layer",
		"aria-hidden": !0,
		children: e.awarded.flatMap((t) => Array.from({ length: e.stars }, (n, r) => /* @__PURE__ */ g(re, {
			rid: t,
			index: r,
			count: e.stars
		}, `${t}/${r}`)))
	});
}
//#endregion
//#region src/games/stella/view-player.tsx
var Q = [
	"#edb3bd",
	"#93cdd6",
	"#dbca84",
	"#b8a4dd",
	"#d8af7b",
	"#a7c69e"
];
function ae({ player: e, name: t, index: n, active: r, mine: i, choosing: a, first: o, settled: c, resonance: u, falling: d, gain: f, motion: p }) {
	let m = s(), { ref: h } = l(`stella:player:${e.rid}`), { ref: v } = l(`stella:score:${e.rid}`);
	return /* @__PURE__ */ _("div", {
		ref: h,
		className: `stella-player${r ? " is-active" : ""}${i ? " is-me" : ""}${e.fallen ? " is-fallen" : ""}${u >= 0 ? " is-resonating" : ""}${d ? " is-falling" : ""}${f ? " is-awarded" : ""}${c === void 0 ? "" : " is-settled"}`,
		style: {
			"--seat": Q[n],
			"--resonance-delay": `${Math.max(0, u) * 75}ms`,
			"--resonate-ms": `${P.resonate}ms`,
			"--fall-ms": `${P.falling}ms`,
			"--award-ms": `${P.award}ms`,
			"--settle-ms": `${P.score}ms`
		},
		children: [
			o && /* @__PURE__ */ g("span", {
				className: "stella-first",
				title: m("games.stella.first"),
				"aria-label": m("games.stella.first"),
				children: /* @__PURE__ */ g(q, {})
			}),
			/* @__PURE__ */ g(J, {
				dark: e.dark,
				fallen: e.fallen,
				color: Q[n]
			}),
			/* @__PURE__ */ _("div", {
				className: "stella-player-text",
				children: [/* @__PURE__ */ g("strong", {
					title: t,
					children: t
				}), /* @__PURE__ */ g("span", { children: a ? e.submitted ? m("games.stella.submitted") : "…" : `${e.fallen ? m("games.stella.fallen") + " · " : e.dark ? m("games.stella.dark") + " · " : ""}${m("games.stella.count", { n: e.count ?? 0 })}` })]
			}),
			/* @__PURE__ */ _("div", {
				className: "stella-player-score",
				children: [/* @__PURE__ */ _("span", {
					ref: v,
					className: "stella-round-score",
					"aria-label": `${m("games.stella.roundShort")} · ${m(c === void 0 ? "games.stella.stars" : "games.stella.points", { n: c ?? e.roundStars })}`,
					children: [
						/* @__PURE__ */ g("small", { children: m("games.stella.roundShort") }),
						/* @__PURE__ */ g(K, {}),
						/* @__PURE__ */ g(Z, {
							value: c ?? e.roundStars,
							motion: p
						})
					]
				}), /* @__PURE__ */ _("span", {
					className: "stella-total-score",
					children: [/* @__PURE__ */ g("small", { children: m("games.stella.score") }), /* @__PURE__ */ g(Z, {
						value: e.score,
						motion: p
					})]
				})]
			}),
			f > 0 && /* @__PURE__ */ _("span", {
				className: "stella-local-gain",
				"aria-hidden": !0,
				children: [
					"+",
					f,
					/* @__PURE__ */ g(K, {})
				]
			}),
			d && /* @__PURE__ */ g("span", {
				className: "stella-local-fall",
				"aria-hidden": !0,
				children: "× +0"
			}),
			c !== void 0 && /* @__PURE__ */ _("span", {
				className: "stella-local-settle",
				"aria-hidden": !0,
				children: [e.roundStars > c && /* @__PURE__ */ _("i", { children: ["−", e.roundStars - c] }), /* @__PURE__ */ _("b", { children: [
					"+",
					c,
					/* @__PURE__ */ g(K, {})
				] })]
			})
		]
	});
}
function oe(e) {
	let t = e.public, [n, r] = a(!1), i = d();
	return /* @__PURE__ */ g(se, {
		...e,
		forceMotion: n,
		motion: n || !i,
		toggleMotion: () => r((e) => !e)
	}, `${e.myRid}/${t.round}/${t.wordRevision}`);
}
function se({ public: e, private: t, members: n, myRid: r, send: i, forceMotion: u, motion: d, toggleMotion: m }) {
	c();
	let v = e, y = t, b = s(), x = o((e) => e.locale), { ref: S } = l("stella:board"), [C, w] = a([]), [T, E] = a(null), [D, O] = a(!0), [k, A] = a(!1), j = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, x) : e;
	}, M = y?.submitted ? y.slots : C, N = v.phase === "select" && !!y && !y.submitted, P = v.phase === "reveal" && v.turn === r, F = new Set(v.reveals.map((e) => e.slot)), I = !!y && v.phase === "select" && !v.word.custom && !v.players.some((e) => e.submitted), L = v.lastReveal, R = v.currentReveal, z = v.phase === "focus" ? null : L && `${W(L.slot)} · ${L.stars ? ["resonate", "travel"].includes(v.phase) ? b("games.stella.matchNames", { names: L.matches.map(j).join(" · ") }) : L.awarded.map((e) => `${j(e)} +${L.stars}`).join(" · ") : `${j(L.by)} · ${b("games.stella.fallZero")}`}`, B = v.phase === "select" ? b(y?.submitted ? "games.stella.waiting" : "games.stella.choose") : v.phase === "announce" ? b("games.stella.counting") : v.phase === "roundOver" ? b("games.stella.roundOver") : P ? b("games.stella.yourTurn") : v.phase === "focus" && R ? b("games.stella.revealingBy", { name: j(R.by) }) : v.phase === "travel" ? b("games.stella.collecting") : [
		"resonate",
		"award",
		"falling",
		"resolve"
	].includes(v.phase) && L ? b(L.stars === 0 ? "games.stella.fall" : L.stars === 3 ? "games.stella.superSpark" : "games.stella.spark") : b("games.stella.turn", { name: j(v.turn ?? v.first) }), V = (e) => {
		N ? w((t) => t.includes(e) ? t.filter((t) => t !== e) : t.length < 10 ? [...t, e] : t) : P && M.includes(e) && !F.has(e) && i({
			type: "reveal",
			slot: e
		});
	};
	return /* @__PURE__ */ _("div", {
		className: `stella-scene stella-theme${u ? " stella-motion-on" : ""}`,
		children: [/* @__PURE__ */ _(f, {
			adaptive: !0,
			className: `stella-theme stella-screen${u ? " stella-motion-on" : ""}`,
			actionsHeight: "stella-actions-slot",
			scroll: !1,
			banner: /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ _("header", {
				className: "stella-header",
				children: [
					/* @__PURE__ */ _("div", {
						className: "stella-round-label",
						children: [b("games.stella.round", { n: v.round }), /* @__PURE__ */ g("button", {
							type: "button",
							className: "stella-motion-toggle",
							role: "switch",
							"aria-checked": u,
							"aria-label": b("games.stella.alwaysMotion"),
							title: b("games.stella.alwaysMotion"),
							onClick: m,
							children: b(u ? "games.stella.motionOn" : "games.stella.motionAuto")
						})]
					}),
					/* @__PURE__ */ g("h1", { children: /* @__PURE__ */ g("button", {
						type: "button",
						className: "stella-word-button",
						title: G(v.word, b),
						"aria-label": `${b("games.stella.wordDetails")} · ${G(v.word, b)}`,
						onClick: () => A(!0),
						children: G(v.word, b)
					}) }),
					/* @__PURE__ */ _("button", {
						type: "button",
						onClick: () => E(0),
						children: [
							b("games.stella.gallery"),
							" ",
							/* @__PURE__ */ g("span", {
								"aria-hidden": !0,
								children: "↗"
							})
						]
					})
				]
			}), /* @__PURE__ */ g("div", {
				className: "stella-players",
				children: v.players.map((e, t) => /* @__PURE__ */ g(ae, {
					player: e,
					name: j(e.rid),
					index: t,
					active: v.turn === e.rid || v.phase === "announce" && e.dark,
					mine: r === e.rid,
					choosing: v.phase === "select",
					first: v.first === e.rid,
					settled: v.phase === "roundOver" ? v.roundScores[e.rid] : void 0,
					resonance: v.phase === "resonate" && L ? L.matches.indexOf(e.rid) : -1,
					falling: ["falling", "resolve"].includes(v.phase) && L?.by === e.rid,
					gain: v.phase === "award" && L?.awarded.includes(e.rid) ? L.stars : 0,
					motion: d
				}, e.rid))
			})] }),
			actions: /* @__PURE__ */ _("div", {
				className: "stella-actions",
				children: [/* @__PURE__ */ _("div", {
					className: "stella-action-message",
					role: "status",
					children: [/* @__PURE__ */ g("strong", { children: B }), z && /* @__PURE__ */ g("small", {
						className: "stella-last-result",
						title: z,
						children: z
					})]
				}), /* @__PURE__ */ _("div", {
					className: "stella-action-buttons",
					children: [
						N && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
							type: "button",
							className: "stella-quiet",
							disabled: !C.length,
							onClick: () => w([]),
							children: b("games.stella.clear")
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: "stella-primary",
							disabled: !C.length,
							onClick: () => i({
								type: "select",
								slots: C
							}),
							children: b(C.length === 1 ? "games.stella.submitOne" : "games.stella.submit", { n: C.length })
						})] }),
						I && /* @__PURE__ */ _("button", {
							type: "button",
							className: "stella-quiet stella-swap",
							"aria-pressed": v.swapVotes.includes(r),
							onClick: () => i({ type: "swapWord" }),
							children: [b(v.swapVotes.includes(r) ? "games.stella.voted" : "games.stella.swap"), v.swapVotes.length > 0 && /* @__PURE__ */ g("small", { children: b("games.stella.swapVotes", {
								n: v.swapVotes.length,
								total: v.players.length
							}) })]
						}),
						v.phase === "roundOver" && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("button", {
							type: "button",
							className: "stella-quiet",
							onClick: () => O(!D),
							children: b(D ? "games.stella.hideResults" : "games.stella.showResults")
						}), /* @__PURE__ */ g("button", {
							type: "button",
							className: "stella-primary",
							disabled: !y || v.ready.includes(r),
							onClick: () => i({ type: "ready" }),
							children: b(v.ready.includes(r) ? "games.stella.readyWaiting" : v.round === 4 ? "games.stella.finish" : "games.stella.ready")
						})] })
					]
				})]
			}),
			overlay: v.phase === "roundOver" && D ? /* @__PURE__ */ _("div", {
				className: "stella-round-results",
				children: [
					/* @__PURE__ */ g("h2", { children: b("games.stella.roundOver") }),
					/* @__PURE__ */ g("div", { children: v.players.map((e, t) => /* @__PURE__ */ _("article", {
						style: { "--seat": Q[t] },
						children: [
							/* @__PURE__ */ g("strong", { children: j(e.rid) }),
							/* @__PURE__ */ _("b", { children: ["+", v.roundScores[e.rid]] }),
							/* @__PURE__ */ g("small", { children: b(e.dark && e.fallen ? "games.stella.penaltyDetail" : "games.stella.normalDetail", {
								stars: e.roundStars,
								penalty: e.roundStars - v.roundScores[e.rid]
							}) })
						]
					}, e.rid)) }),
					/* @__PURE__ */ g("p", { children: b("games.stella.readyCount", {
						n: v.ready.length,
						total: v.players.length
					}) })
				]
			}) : void 0,
			children: [
				/* @__PURE__ */ _("div", {
					className: `stella-board-scene${R ? " has-focus" : ""}`,
					children: [/* @__PURE__ */ g("div", {
						ref: S,
						className: "stella-board-scroll",
						children: /* @__PURE__ */ g("div", {
							className: "stella-board",
							"aria-label": b("games.stella.gallery"),
							children: v.board.map((e, t) => /* @__PURE__ */ _("div", {
								className: "stella-card-cell",
								children: [/* @__PURE__ */ g(Y, {
									card: e,
									slot: t,
									selected: M.includes(t),
									result: v.reveals.find((e) => e.slot === t),
									target: P && M.includes(t) && !F.has(t),
									enabled: N ? M.includes(t) || M.length < 10 : P && M.includes(t) && !F.has(t),
									onClick: () => V(t)
								}), /* @__PURE__ */ g("button", {
									type: "button",
									className: "stella-enlarge",
									onClick: () => E(t),
									"aria-label": `${b("games.stella.enlarge")} · ${W(t)}`,
									children: "⌕"
								})]
							}, `${t}/${e}`))
						})
					}), R && /* @__PURE__ */ g(ne, {
						current: R,
						result: L,
						board: v.board,
						phase: v.phase,
						name: j(R.by),
						motion: d
					}, `${v.round}/${R.slot}`)]
				}),
				T !== null && /* @__PURE__ */ g(X, {
					board: v.board,
					initial: T,
					onClose: () => E(null)
				}),
				k && /* @__PURE__ */ g(te, {
					word: G(v.word, b),
					onClose: () => A(!1)
				})
			]
		}), d && v.phase === "travel" && L && /* @__PURE__ */ g(ie, { reveal: L }, `${v.round}/${L.slot}`)]
	});
}
//#endregion
//#region src/games/stella/bot.ts
function $(e) {
	let t = 2166136261;
	for (let n of e) t = Math.imul(t ^ n.charCodeAt(0), 16777619);
	return (t >>> 0) / 4294967296;
}
var ce = ({ public: e, private: t }, n) => {
	if (!t) return null;
	if (e.phase === "roundOver") return e.ready.includes(n.rid) ? null : { action: { type: "ready" } };
	let r = n.difficulty === "weak";
	if (e.phase === "select" && !t.submitted) {
		let t = e.board.map((t, i) => ({
			slot: i,
			value: (r ? 0 : S(t, e.word)) + $(`${n.rid}/${e.round}/${t}`) * (r ? 1 : .55)
		})).sort((e, t) => t.value - e.value), i = r ? 2 + Math.floor($(`${n.rid}/${e.round}/count`) * 6) : Math.max(2, Math.min(7, t.filter((e) => e.value >= .55).length));
		return { action: {
			type: "select",
			slots: t.slice(0, i).map((e) => e.slot)
		} };
	}
	if (e.phase === "reveal" && e.turn === n.rid) {
		let n = t.slots.filter((t) => !e.reveals.some((e) => e.slot === t));
		return n.length ? (n.sort((t, n) => S(e.board[n], e.word) - S(e.board[t], e.word)), { action: {
			type: "reveal",
			slot: n[0]
		} }) : null;
	}
	return null;
}, le = { stellaRow: (e, t) => {
	let { row: n } = e.data, r = t.queued ? 150 : 550, i = Array.from({ length: 5 }, (e, r) => t.anchor(`stella:card:${n * 5 + r}`));
	return {
		ms: r,
		node: /* @__PURE__ */ g(h, { children: i.map((e, t) => e && /* @__PURE__ */ g("div", {
			className: "stella-fx-row",
			style: {
				left: e.x,
				top: e.y,
				width: e.w,
				height: e.h,
				animationDelay: `${t * 35}ms`
			}
		}, t)) })
	};
} };
//#endregion
//#region src/games/stella/game-over.tsx
function ue({ result: e, public: t, members: n, onPlayAgain: r, onBackToLobby: i }) {
	let c = t, l = s(), u = o((e) => e.locale), [d, f] = a(0), [m, v] = a(null), y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? p(t, u) : e;
	}, b = typeof e.winner == "string" ? [e.winner] : e.winner ?? [], x = c.history[d];
	return /* @__PURE__ */ _("main", {
		className: "stella-theme stella-ending",
		children: [
			/* @__PURE__ */ _("header", { children: [
				/* @__PURE__ */ g(K, {}),
				/* @__PURE__ */ g("h1", { children: l("games.stella.resultTitle") }),
				/* @__PURE__ */ g("p", { children: l("games.stella.resultWinner", { names: b.map(y).join(" · ") }) })
			] }),
			/* @__PURE__ */ g("div", {
				className: "stella-score-scroll",
				children: /* @__PURE__ */ _("table", { children: [/* @__PURE__ */ g("thead", { children: /* @__PURE__ */ _("tr", { children: [
					/* @__PURE__ */ g("th", { children: l("games.stella.name") }),
					c.history.map((e) => /* @__PURE__ */ g("th", { children: l("games.stella.roundColumn", { n: e.round }) }, e.round)),
					/* @__PURE__ */ g("th", { children: l("games.stella.total") })
				] }) }), /* @__PURE__ */ g("tbody", { children: [...c.players].sort((e, t) => t.score - e.score).map((e) => /* @__PURE__ */ _("tr", {
					className: b.includes(e.rid) ? "is-winner" : "",
					children: [
						/* @__PURE__ */ _("th", { children: [/* @__PURE__ */ g(J, { color: Q[c.players.indexOf(e)] }), y(e.rid)] }),
						c.history.map((t) => /* @__PURE__ */ g("td", { children: t.scores[e.rid] }, t.round)),
						/* @__PURE__ */ g("td", { children: /* @__PURE__ */ g("b", { children: e.score }) })
					]
				}, e.rid)) })] })
			}),
			/* @__PURE__ */ _("section", {
				className: "stella-history",
				children: [/* @__PURE__ */ g("nav", {
					"aria-label": l("games.stella.history"),
					children: c.history.map((e, t) => /* @__PURE__ */ g("button", {
						type: "button",
						"aria-pressed": d === t,
						onClick: () => f(t),
						children: l("games.stella.roundColumn", { n: e.round })
					}, e.round))
				}), x && /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g("h2", { children: l("games.stella.reviewTitle", {
					n: x.round,
					word: G(x.word, l)
				}) }), /* @__PURE__ */ g("div", {
					className: "stella-history-grid",
					children: x.board.map((e, t) => {
						let n = x.reveals.find((e) => e.slot === t);
						return /* @__PURE__ */ _("button", {
							type: "button",
							onClick: () => v(t),
							"aria-label": l("games.stella.illustration", { n: t + 1 }),
							children: [
								/* @__PURE__ */ g("img", {
									src: U(e),
									alt: ""
								}),
								/* @__PURE__ */ g("span", { children: n ? n.stars ? /* @__PURE__ */ _(h, { children: [/* @__PURE__ */ g(K, {}), n.stars] }) : "×" : "—" }),
								/* @__PURE__ */ g("small", { children: x.selections && Object.entries(x.selections).filter(([, e]) => e.includes(t)).map(([e]) => y(e)).join(" · ") })
							]
						}, t);
					})
				})] })]
			}),
			/* @__PURE__ */ _("footer", { children: [r && /* @__PURE__ */ g("button", {
				type: "button",
				className: "stella-primary",
				onClick: r,
				children: l("session.result.playAgain")
			}), i && /* @__PURE__ */ g("button", {
				type: "button",
				onClick: i,
				children: l("session.result.backToLobby")
			})] }),
			m !== null && x && /* @__PURE__ */ g(X, {
				board: x.board,
				initial: m,
				onClose: () => v(null)
			}, d)
		]
	});
}
//#endregion
//#region src/games/stella/options.tsx
function de({ value: e, onChange: t }) {
	let n = s(), r = D.parse(e), i = new Set(r.customWords.split("\n").map((e) => e.trim()).filter(Boolean)).size;
	return /* @__PURE__ */ _("label", {
		className: "flex flex-col gap-2",
		children: [
			/* @__PURE__ */ g("span", {
				className: "font-bold",
				children: n("games.stella.customLabel")
			}),
			/* @__PURE__ */ g("span", {
				className: "text-sm",
				children: n("games.stella.customHelp")
			}),
			/* @__PURE__ */ g("textarea", {
				className: "rounded-lg border-2 p-3",
				rows: 6,
				maxLength: 600,
				value: r.customWords,
				placeholder: n("games.stella.customPlaceholder"),
				onChange: (e) => t({
					...r,
					customWords: e.target.value
				})
			}),
			i > 0 && i < 4 && /* @__PURE__ */ g("span", {
				className: "text-sm",
				children: n("games.stella.customInvalid")
			})
		]
	});
}
//#endregion
//#region src/games/stella/guide.tsx
function fe() {
	let e = s();
	return /* @__PURE__ */ g("article", {
		className: "stella-theme stella-guide",
		children: /* @__PURE__ */ _("div", {
			className: "stella-guide-symbols",
			children: [
				/* @__PURE__ */ _("span", { children: [
					/* @__PURE__ */ g(K, {}),
					/* @__PURE__ */ g(K, {}),
					" ",
					e("games.stella.spark")
				] }),
				/* @__PURE__ */ _("span", { children: [
					/* @__PURE__ */ g(K, {}),
					/* @__PURE__ */ g(K, {}),
					/* @__PURE__ */ g(K, { hollow: !0 }),
					" ",
					e("games.stella.superSpark")
				] }),
				/* @__PURE__ */ _("span", { children: [
					/* @__PURE__ */ g(J, { dark: !0 }),
					" ",
					e("games.stella.dark")
				] }),
				/* @__PURE__ */ _("span", { children: [
					/* @__PURE__ */ g(q, {}),
					" ",
					e("games.stella.first")
				] })
			]
		})
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/stella/entry.tsx
var pe = {
	definition: ee,
	View: oe,
	bot: ce,
	fx: le,
	OverView: ue,
	Options: de,
	Guide: fe,
	locales: {
		zh: {
			name: "星物语",
			desc: "围绕同一个词寻找图画中的共鸣，在星光与暗夜之间决定冒多大的风险。",
			rules: "目标：\n三至六位玩家进行四轮游戏，累计得分最高者获胜；最高分相同的玩家共同获胜。\n\n准备：\n将八十四张图画洗混，公开摆出十五张，其余作为牌堆。每轮揭示一个共同词语。数字版词库依据参考模组的二百个词翻译；自定义词语为可选设置。\n\n联想与公布：\n所有玩家秘密选择与本轮词语有关的一至十张图画。点击图画作标记，可在提交前取消。提交后不能修改，其他人只知道你已提交。若要改用另一个词，须在任何人提交前由所有玩家同意；换词后重新选择。\n所有人提交后，同时公布各自选择的数量。只有一人选择数量最多时，该玩家进入暗夜；最多数量并列时，没有人进入暗夜。\n\n揭示：\n从本轮首位探险者开始，按座位顺序轮流揭示自己选择且本轮尚未揭示的一张图画。已经失足或没有剩余图画的玩家跳过。\n· 如果共有三人或更多人选择这张图画，形成火花，参与匹配且尚未失足的每位玩家获得两颗星。\n· 如果恰好两人选择这张图画，形成超级火花，两位玩家各获得三颗星；已失足者仍参与人数计算，但不再获得星星。\n· 如果只有探险者本人选择这张图画，该玩家失足，本次不得分，本轮不能继续揭示或获得星星。其尚未揭示的选择仍参与其他玩家之后的匹配。\n当所有尚未失足的玩家都没有剩余图画，或所有玩家均已失足时，进入计分。\n\n计分与下一轮：\n通常每颗星计一分。进入暗夜的玩家若本轮失足，其此前每次成功匹配各扣一分：火花由两分变为一分，超级火花由三分变为两分；未失足时正常计分。\n轮末确认后，首位探险者顺延一位，并换入五张新图画：第一轮后换底行，第二轮后换中行，第三轮后换顶行。清除标记并重置暗夜与失足状态，开始下一轮。第四轮计分后结束。",
			round: "第 {{n}} / 4 轮",
			select: "联想",
			announce: "公布数量",
			reveal: "揭示",
			resolve: "星光交汇",
			roundOver: "本轮计分",
			choose: "选择一至十张图画",
			submit: "提交 {{n}} 张",
			submitOne: "提交 1 张",
			waiting: "等待其他玩家选择",
			submitted: "已提交",
			yourTurn: "揭示一张已选择的图画",
			turn: "等待 {{name}} 揭示",
			counting: "正在公布选择数量",
			score: "总分",
			points: "{{n}} 分",
			stars: "{{n}} 颗星",
			count: "选择 {{n}} 张",
			dark: "暗夜",
			fallen: "失足",
			first: "首位探险者",
			spark: "火花",
			superSpark: "超级火花",
			fall: "失足",
			noMatch: "没有其他玩家选择这张图画",
			matchNames: "共同选择：{{names}}",
			gained: "获得 {{n}} 颗星",
			roundPoints: "本轮 {{n}} 分",
			roundShort: "本轮",
			fallZero: "失足 · +0",
			penaltyDetail: "{{stars}} 颗星 − {{penalty}} 分暗夜扣分",
			normalDetail: "{{stars}} 颗星，无扣分",
			revealing: "正在揭示",
			revealingBy: "{{name}} 正在揭示",
			collecting: "星光汇入",
			alwaysMotion: "始终播放动效",
			motionOn: "动效：开启",
			motionAuto: "动效：自动",
			ready: "继续",
			finish: "查看最终得分",
			readyWaiting: "等待其他玩家确认",
			readyCount: "{{n}} / {{total}} 已确认",
			swap: "同意换词",
			voted: "撤回换词",
			swapVotes: "换词 {{n}} / {{total}}",
			gallery: "查看图画",
			wordDetails: "查看完整词语",
			close: "关闭",
			previous: "上一张",
			next: "下一张",
			illustration: "图画 {{n}}",
			position: "位置 {{label}}",
			selected: "已选择",
			revealed: "已揭示",
			enlarge: "放大查看",
			clear: "清除选择",
			customLabel: "自定义词语",
			customHelp: "留空使用内置词库；输入四至十个词，每行一个。",
			customPlaceholder: "每行一个词语",
			customInvalid: "至少需要四个不同的词语；不足时使用内置词库。",
			resultTitle: "这一夜，我们点亮了星空",
			resultWinner: "共同的星光属于 {{names}}",
			total: "总计",
			roundColumn: "第 {{n}} 轮",
			review: "回看本轮",
			reviewTitle: "第 {{n}} 轮 · {{word}}",
			showResults: "显示计分",
			hideResults: "回看星图",
			history: "回看四轮",
			noReveals: "尚未揭示图画",
			darkPenalty: "暗夜且失足：每次匹配扣一分",
			noPenalty: "按星星正常计分",
			errPhase: "当前阶段不能执行这个操作。",
			errTurn: "请等待轮到你揭示。",
			errCard: "请选择自己标记且尚未揭示的图画。",
			errSelection: "请选择一至十张不同的图画。",
			hintSelect: "选择 {{labels}}。",
			hintReveal: "揭示 {{label}}。",
			hintReady: "确认本轮得分。",
			wordPairs: "戒指/盘子|衣柜/灯|寒冷/邪恶|衬衫/高大|疾病/年老|冰/狗|白天/沉重|章鱼/铲子|幸福/蛋糕|安全/盔甲|缓慢/消防员|火/公交车|马/耳朵|群体/道路|红色/大地|愉快/风|闪电/汽车|男人/女人|敌人/骑士|黑色/沙拉|棕色/蜘蛛|灰色/箭|粉色/萝卜|绿色/三明治|鸡/眼镜|海洋/监狱|扁豆/房子|夏天/惊喜|白色/小麦|棕榈树/橡皮筋|兽医/旅行|教师/花瓶|胸膛/帽子|机器人/甜点|蜂蜜/猪|龙/恐龙|狼/黄色|牛/包|厌恶/手提箱|天气/丑陋|机场/城堡|沙漠/草莓|火车/番茄|国际象棋/丛林|月亮/火星|山/海滩|笔/直升机|雪/梨|老鼠/骆驼|战争/宝藏|笔记本/鲨鱼|熊/胡子|蛇/愤怒|猴子/恐惧|假期/蜗牛|悲伤/薯条|喜悦/木头|沙发/箱子|石头/披风|钻石/船|吉他/玩具|床/蓝色|汤/绘画|秋天/信|纸/英雄|洞/降落伞|奇怪/餐食|矮人/夜晚|手臂/侦探|眼睛/水|脚/头盔|飞机/拖车|动物园/摩托车|自行车/空气|海盗/护士|山峰/医生|士兵/厨师|地图/总统|手杖/行星|小巧/年轻|聪明/故事|高大/光|香蕉/腿|马戏团/巧克力|鸽子/鱼|独角兽/钢琴|老鼠/糖|朋友/国王|快速/王后|美丽/炎热|头/奶酪|孩子/宇宙飞船|冬天/学校|领带/黄油|蘑菇/球|相机/花椰菜|相机/书|脚踝/嘴巴|春天/猫|山羊/橙子"
		},
		en: {
			name: "Stella: Dixit Universe",
			desc: "Find shared meaning in dreamlike pictures. Reach for the stars, but beware of the dark.",
			rules: "Goal:\nThree to six players play four rounds. The highest total wins; tied leaders share victory.\n\nSetup:\nShuffle the 84 picture cards and reveal 15, keeping the rest as a draw pile. Reveal one shared clue word each round. The digital word bank translates the 200 terms in the reference module. Custom words are optional.\n\nAssociate and announce:\nSecretly choose one to ten pictures connected to the word. Tap pictures to mark or unmark them before submitting. Submission locks your choice; other players only see that you have submitted. To use the alternative word, everyone must agree before anyone submits. A word change clears drafts.\nOnce everyone submits, all selection counts are announced together. The sole player with the highest count enters the dark. If the highest count is tied, nobody enters the dark.\n\nReveal:\nStarting with the first explorer, take turns clockwise revealing one of your marked pictures that has not yet been revealed. Skip players who have fallen or have no pictures left.\n· A picture chosen by three or more players creates a spark. Every matching player who has not fallen gains two stars.\n· A picture chosen by exactly two players creates a super-spark worth three stars each. Fallen players still count toward the match but gain no more stars.\n· A picture chosen only by its explorer causes a fall. The explorer scores nothing for it, cannot reveal again, and earns no further stars this round. Their remaining selections still count toward later matches for other players.\nRevealing ends when every player has fallen or every remaining explorer has no unrevealed pictures.\n\nScore and continue:\nNormally each star is worth one point. A player in the dark who falls loses one point for each successful match already scored: a spark is worth one, a super-spark two. A player in the dark who does not fall scores normally.\nAfter everyone confirms, pass the first explorer to the next seat. Replace five pictures: the bottom row after round one, the middle after round two, and the top after round three. Clear marks and reset the dark and fallen states. The game ends after round four.",
			round: "Round {{n}} / 4",
			select: "Associate",
			announce: "Announce",
			reveal: "Reveal",
			resolve: "Starlight",
			roundOver: "Round score",
			choose: "Choose one to ten pictures",
			submit: "Submit {{n}} pictures",
			submitOne: "Submit 1 picture",
			waiting: "Waiting for other players",
			submitted: "Submitted",
			yourTurn: "Reveal one of your marked pictures",
			turn: "Waiting for {{name}} to reveal",
			counting: "Announcing selection counts",
			score: "Total",
			points: "{{n}} points",
			stars: "{{n}} stars",
			count: "{{n}} chosen",
			dark: "In the dark",
			fallen: "Fallen",
			first: "First explorer",
			spark: "Spark",
			superSpark: "Super-spark",
			fall: "Fall",
			noMatch: "Nobody else chose this picture",
			matchNames: "Chosen by: {{names}}",
			gained: "{{n}} stars gained",
			roundPoints: "{{n}} this round",
			roundShort: "Round",
			fallZero: "Fallen · +0",
			penaltyDetail: "{{stars}} stars − {{penalty}} dark penalty",
			normalDetail: "{{stars}} stars, no penalty",
			revealing: "Revealing",
			revealingBy: "{{name}} is revealing",
			collecting: "Collecting starlight",
			alwaysMotion: "Always play animations",
			motionOn: "Motion: on",
			motionAuto: "Motion: auto",
			ready: "Continue",
			finish: "See final scores",
			readyWaiting: "Waiting for confirmation",
			readyCount: "{{n}} / {{total}} confirmed",
			swap: "Agree to switch word",
			voted: "Withdraw vote",
			swapVotes: "Switch {{n}} / {{total}}",
			gallery: "View pictures",
			wordDetails: "View full word",
			close: "Close",
			previous: "Previous",
			next: "Next",
			illustration: "Picture {{n}}",
			position: "Position {{label}}",
			selected: "Selected",
			revealed: "Revealed",
			enlarge: "Enlarge",
			clear: "Clear marks",
			customLabel: "Custom words",
			customHelp: "Leave blank for the built-in deck, or enter four to ten words, one per line.",
			customPlaceholder: "One word per line",
			customInvalid: "At least four different words are needed. Otherwise the built-in deck is used.",
			resultTitle: "Together, we lit the sky",
			resultWinner: "The stars belong to {{names}}",
			total: "Total",
			roundColumn: "Round {{n}}",
			review: "Review round",
			reviewTitle: "Round {{n}} · {{word}}",
			showResults: "Show scores",
			hideResults: "View the stars",
			history: "Review four rounds",
			noReveals: "No pictures revealed yet",
			darkPenalty: "In the dark and fallen: one point lost per match",
			noPenalty: "Normal star scoring",
			errPhase: "This action is unavailable now.",
			errTurn: "Wait for your turn to reveal.",
			errCard: "Choose a marked picture that has not been revealed.",
			errSelection: "Choose one to ten different pictures.",
			hintSelect: "Choose {{labels}}.",
			hintReveal: "Reveal {{label}}.",
			hintReady: "Confirm the round score.",
			wordPairs: "Ring/Plate|Wardrobe/Lamp|Cold/Evil|Shirt/Tall|Illness/Old|Ice/Dog|Day/Heavy|Octopus/Shovel|Happiness/Cake|Safety/Armour|Slow/Firefighter|Fire/Bus|Horse/Ear|Group/Road|Red/Earth|Pleasant/Wind|Lightning/Car|Man/Woman|Enemy/Knight|Black/Salad|Brown/Spider|Grey/Arrow|Pink/Radish|Green/Sandwich|Chicken/Glasses|Ocean/Prison|Lentils/House|Summer/Surprise|White/Wheat|Palm/Rubber band|Veterinarian/Travel|Teacher/Vase|Chest/Hat|Robot/Dessert|Honey/Pig|Dragon/Dinosaur|Wolf/Yellow|Cow/Bag|Disgust/Suitcase|Weather/Ugly|Airport/Castle|Desert/Strawberry|Train/Tomato|Chess/Jungle|Moon/Mars|Mountain/Beach|Pen/Helicopter|Snow/Pear|Rat/Camel|War/Treasure|Notebook/Shark|Bear/Moustache|Snake/Anger|Monkey/Fear|Holiday/Snail|Sadness/Fries|Joy/Wood|Sofa/Box|Stone/Cape|Diamond/Boat|Guitar/Toy|Bed/Blue|Soup/Painting|Autumn/Letter|Paper/Hero|Hole/Parachute|Strange/Meal|Dwarf/Night|Arm/Detective|Eye/Water|Foot/Helmet|Plane/Trailer|Zoo/Motorcycle|Bicycle/Air|Pirate/Nurse|Peak/Doctor|Soldier/Cook|Map/President|Cane/Planet|Small/Young|Clever/Story|Tall/Light|Banana/Leg|Circus/Chocolate|Dove/Fish|Unicorn/Piano|Mouse/Sugar|Friends/King|Fast/Queen|Beautiful/Hot|Head/Cheese|Child/Spaceship|Winter/School|Tie/Butter|Mushroom/Ball|Camera/Cauliflower|Camera/Book|Ankle/Mouth|Spring/Cat|Goat/Orange"
		}
	}
};
//#endregion
export { pe as default };
