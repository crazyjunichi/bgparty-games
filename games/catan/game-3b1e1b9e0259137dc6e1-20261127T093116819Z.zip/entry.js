import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { DICE_ROLL_MS as t } from "@bgparty/sdk/fx/dice-roll-ms";
import { z as n } from "zod";
import { Fragment as r, useEffect as i, useId as a, useMemo as o, useRef as s, useState as c } from "react";
import { BottomSheet as l } from "@bgparty/sdk/bottom-sheet";
import { DeltaNumber as u } from "@bgparty/sdk/fx/delta-number";
import { useFxAnchor as d } from "@bgparty/sdk/fx/anchors";
import { useI18nSettings as f, useT as p } from "@bgparty/sdk/i18n";
import { PLAYER_COLORS as m } from "@bgparty/sdk/player-colors";
import { GameScreen as h } from "@bgparty/sdk/ui/game-screen";
import { PhaseBanner as g } from "@bgparty/sdk/ui/phase-banner";
import { SeatBadgedAvatar as _, seatName as ee } from "@bgparty/sdk/ui/player-strip";
import { Fragment as v, jsx as y, jsxs as b } from "react/jsx-runtime";
import { createDiceRollRenderer as x } from "@bgparty/sdk/fx/dice-roll";
import { Floater as S, FlySprite as te, PulseBox as C } from "@bgparty/sdk/fx/primitives";
import { IconBack as ne, IconBot as w, IconExpand as T, IconLog as re } from "@bgparty/sdk/icons";
import { Confetti as ie } from "@bgparty/sdk/ui/confetti";
//#region src/game/data.ts
var E = [
	"wood",
	"brick",
	"wool",
	"wheat",
	"ore"
], ae = {
	hills: "brick",
	forest: "wood",
	pasture: "wool",
	fields: "wheat",
	mountains: "ore",
	desert: null
}, oe = [
	"hills",
	"hills",
	"hills",
	"forest",
	"forest",
	"forest",
	"forest",
	"pasture",
	"pasture",
	"pasture",
	"pasture",
	"fields",
	"fields",
	"fields",
	"fields",
	"mountains",
	"mountains",
	"mountains",
	"desert"
], D = [
	5,
	2,
	6,
	3,
	8,
	10,
	9,
	12,
	11,
	4,
	8,
	10,
	9,
	4,
	5,
	6,
	3,
	11
], O = [
	"any",
	"any",
	"any",
	"any",
	"wood",
	"brick",
	"wool",
	"wheat",
	"ore"
], se = [
	...Array(14).fill("knight"),
	...[
		,
		,
		,
		,
		,
	].fill("vp"),
	...[, ,].fill("monopoly"),
	...[, ,].fill("roadBuilding"),
	...[, ,].fill("invention")
], k = {
	wood: 1,
	brick: 1
}, A = {
	wood: 1,
	brick: 1,
	wool: 1,
	wheat: 1
}, ce = {
	wheat: 2,
	ore: 3
}, le = {
	wool: 1,
	wheat: 1,
	ore: 1
};
function ue(e) {
	return 6 - Math.abs(7 - e);
}
function j(e) {
	return E.reduce((t, n) => t + (e[n] ?? 0), 0);
}
function M(e, t) {
	return E.every((n) => (e[n] ?? 0) >= (t[n] ?? 0));
}
function N(e, t) {
	for (let n of E) {
		let r = t[n] ?? 0;
		r > 0 && (e[n] = (e[n] ?? 0) - r);
	}
}
function P(e, t) {
	for (let n of E) {
		let r = t[n] ?? 0;
		r > 0 && (e[n] = (e[n] ?? 0) + r);
	}
}
//#endregion
//#region src/game/geo.ts
var de = Math.sqrt(3), F = (() => {
	let e = [];
	for (let t = -2; t <= 2; t++) for (let n = Math.max(-2, -2 - t); n <= Math.min(2, 2 - t); n++) e.push([n, t]);
	return e;
})(), I = F.length;
function L(e) {
	let [t, n] = F[e];
	return [de * (t + n / 2), 1.5 * n];
}
function fe(e) {
	let t = (90 - 60 * ((e % 6 + 6) % 6)) * Math.PI / 180;
	return [Math.cos(t), Math.sin(t)];
}
function pe(e, t) {
	return `${Math.round(e * 1e4)},${Math.round(t * 1e4)}`;
}
function me(e, t) {
	let [n, r] = L(e), [i, a] = fe(t);
	return pe(n + i, r + a);
}
function he(e, t) {
	let [n, r] = L(e), [i, a] = fe(t), [o, s] = fe(t + 1);
	return pe(n + (i + o) / 2, r + (a + s) / 2);
}
function R(e) {
	let t = e.indexOf(",");
	return [Number(e.slice(0, t)) / 1e4, Number(e.slice(t + 1)) / 1e4];
}
function ge() {
	let e = {}, t = {};
	for (let n = 0; n < I; n++) for (let r = 0; r < 6; r++) {
		let i = me(n, r), a = he(n, r), o = me(n, r + 1), s = e[i] ??= {
			key: i,
			hexes: [],
			edges: []
		};
		s.hexes.includes(n) || s.hexes.push(n), s.edges.includes(a) || s.edges.push(a);
		let c = e[o] ??= {
			key: o,
			hexes: [],
			edges: []
		};
		if (c.hexes.includes(n) || c.hexes.push(n), c.edges.includes(a) || c.edges.push(a), t[a]) t[a].hexes.includes(n) || t[a].hexes.push(n);
		else {
			let [e, r] = R(a), [s, c] = R(i), [l, u] = R(o);
			t[a] = {
				key: a,
				hexes: [n],
				v: [i, o],
				x: e,
				y: r,
				angle: Math.atan2(u - c, l - s) * 180 / Math.PI
			};
		}
	}
	return {
		vertices: e,
		edges: t
	};
}
var _e = ge(), z = _e.vertices, B = _e.edges;
function ve(e) {
	return Array.from({ length: 6 }, (t, n) => me(e, n));
}
function ye(e) {
	let t = z[e], n = [];
	for (let r of t.edges) {
		let t = B[r];
		n.push(t.v[0] === e ? t.v[1] : t.v[0]);
	}
	return n;
}
var be = (() => {
	let e = Object.values(B).filter((e) => e.hexes.length === 1);
	return e.sort((e, t) => Math.atan2(e.y, e.x) - Math.atan2(t.y, t.x)), Array.from({ length: 9 }, (t, n) => e[Math.round(n * e.length / 9)].key);
})(), xe = [
	[0, 1],
	[1, 0],
	[1, -1],
	[0, -1],
	[-1, 0],
	[-1, 1]
], Se = (e, t) => F.findIndex(([n, r]) => n === e && r === t);
function Ce(e, t) {
	let n = F.map(([e, t], n) => ({
		i: n,
		q: e,
		r: t
	})).filter(({ q: e, r: t }) => [
		Math.abs(e),
		Math.abs(t),
		Math.abs(e + t)
	].filter((e) => e === 2).length === 2)[e], r = (e, t) => Math.max(Math.abs(e), Math.abs(t), Math.abs(e + t)), i = xe.map((e, t) => t).filter((e) => {
		let t = Se(n.q + xe[e][0], n.r + xe[e][1]);
		return t >= 0 && r(...F[t]) === 2;
	}), a = [];
	for (let e of i) for (let t of [[
		-1,
		0,
		1
	], [
		1,
		0,
		-1
	]]) {
		let r = /* @__PURE__ */ new Set([n.i]), i = [n.i], o = n.q, s = n.r, c = e;
		for (; i.length < I;) {
			let e = !1;
			for (let n of t) {
				let t = ((c + n) % 6 + 6) % 6, a = Se(o + xe[t][0], s + xe[t][1]);
				if (a >= 0 && !r.has(a)) {
					r.add(a), i.push(a), o += xe[t][0], s += xe[t][1], c = t, e = !0;
					break;
				}
			}
			if (!e) break;
		}
		if (i.length === I - 1) for (let e = 0; e < I; e++) r.has(e) || i.push(e);
		i.length === I && a.push(i);
	}
	let o = (e) => {
		let t = 0;
		for (let n = 0; n < e.length; n++) {
			let [r, i] = L(e[n]), [a, o] = L(e[(n + 1) % e.length]);
			t += r * o - a * i;
		}
		return t < 0;
	};
	return a.find((e) => o(e) === t) ?? a[0];
}
//#endregion
//#region src/game/board-gen.ts
function V(t, n, r) {
	for (let i = t.length - 1; i > 0; --i) {
		let a = e(n, r, i + 1);
		r += 1, [t[i], t[a]] = [t[a], t[i]];
	}
	return r;
}
function we(t, n) {
	let r = [...oe];
	n = V(r, t, n);
	let i = e(t, n, 6);
	n += 1;
	let a = e(t, n, 2) === 0;
	n += 1;
	let o = Ce(i, a), s = Array.from({ length: I }, () => null), c = -1, l = 0;
	for (let e of o) {
		if (r[e] === "desert") {
			c = e;
			continue;
		}
		s[e] = D[l], l += 1;
	}
	let u = [...O];
	return n = V(u, t, n), {
		board: {
			terrain: r,
			discs: s,
			harbors: u,
			robber: c
		},
		cursor: n
	};
}
//#endregion
//#region src/game/meta.ts
var H = {
	id: "catan",
	uuid: "cfec0d78-7f41-479f-8640-d419df0330e3",
	tier: "beta",
	mechanics: ["route-building"],
	interactionTags: [],
	nameKey: "games.catan.name",
	descKey: "games.catan.desc",
	rulesKey: "games.catan.rules",
	icon: "🏝️",
	iconImg: "games/catan.webp",
	rulesUrl: { en: "https://rules.bgparty.uuppi.com/catan/en.pdf" },
	minPlayers: 3,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#d05a1e",
	releasedAt: "2026-09-16",
	search: {
		py: "ka tan dao",
		init: "ktd"
	},
	hotseat: "cover"
}, Te = n.enum([
	"wood",
	"brick",
	"wool",
	"wheat",
	"ore"
]), U = n.partialRecord(Te, n.int().min(1).max(19)), W = n.string().min(1), Ee = n.string().min(1), G = n.string(), De = n.discriminatedUnion("type", [
	n.object({
		type: n.literal("placeSettlement"),
		vertex: W
	}),
	n.object({
		type: n.literal("placeRoad"),
		edge: Ee
	}),
	n.object({
		type: n.literal("tick"),
		now: n.number()
	}),
	n.object({ type: n.literal("roll") }),
	n.object({
		type: n.literal("discard"),
		cards: U
	}),
	n.object({
		type: n.literal("moveRobber"),
		hex: n.int().min(0).max(18),
		stealFrom: G.nullable()
	}),
	n.object({
		type: n.literal("buildRoad"),
		edge: Ee
	}),
	n.object({
		type: n.literal("buildSettlement"),
		vertex: W
	}),
	n.object({
		type: n.literal("buildCity"),
		vertex: W
	}),
	n.object({ type: n.literal("buyDev") }),
	n.object({
		type: n.literal("playDev"),
		card: n.enum([
			"knight",
			"roadBuilding",
			"invention",
			"monopoly"
		]),
		resource: Te.optional(),
		take: n.tuple([Te, Te]).optional()
	}),
	n.object({ type: n.literal("cancelRoadBuilding") }),
	n.object({
		type: n.literal("offerTrade"),
		give: U,
		want: U
	}),
	n.object({ type: n.literal("cancelTrade") }),
	n.object({ type: n.literal("acceptTrade") }),
	n.object({ type: n.literal("declineTrade") }),
	n.object({
		type: n.literal("bankTrade"),
		give: Te,
		get: Te
	}),
	n.object({ type: n.literal("endTurn") })
]), Oe = n.enum([
	"hills",
	"forest",
	"pasture",
	"fields",
	"mountains",
	"desert"
]), ke = n.enum([
	"any",
	"wood",
	"brick",
	"wool",
	"wheat",
	"ore"
]), Ae = n.enum([
	"knight",
	"vp",
	"monopoly",
	"roadBuilding",
	"invention"
]), je = n.object({
	phase: n.enum([
		"setup",
		"play",
		"done"
	]),
	terrain: n.array(Oe),
	discs: n.array(n.int().nullable()),
	harbors: n.array(ke),
	robber: n.int(),
	buildings: n.record(n.string(), n.object({
		p: n.int(),
		city: n.boolean()
	})),
	roads: n.record(n.string(), n.int()),
	players: n.array(n.object({
		rid: G,
		resCount: n.int().nonnegative(),
		devCount: n.int().nonnegative(),
		knights: n.int().nonnegative(),
		vp: n.int().nonnegative(),
		stock: n.object({
			road: n.int().nonnegative(),
			settlement: n.int().nonnegative(),
			city: n.int().nonnegative()
		}),
		ports: n.array(ke),
		longestRoute: n.boolean(),
		largestArmy: n.boolean()
	})),
	setup: n.object({
		order: n.array(n.int()),
		idx: n.int(),
		stage: n.enum(["settlement", "road"]),
		lastVertex: n.string().nullable()
	}).nullable(),
	turn: n.object({
		p: n.int(),
		stage: n.enum(["roll", "action"]),
		dice: n.tuple([n.int(), n.int()]).nullable(),
		devPlayed: n.boolean(),
		freeRoads: n.int().nonnegative(),
		pendingDiscard: n.array(n.object({
			rid: G,
			need: n.int().min(1)
		})),
		pendingRobber: n.boolean(),
		producePending: n.boolean(),
		offer: n.object({
			from: n.int(),
			give: U,
			want: U,
			declined: n.array(n.int())
		}).nullable()
	}).nullable(),
	devDeck: n.int().nonnegative(),
	supply: n.record(Te, n.int().nonnegative()),
	winner: G.nullable()
}), K = n.object({
	hand: n.partialRecord(Te, n.int().nonnegative()),
	devs: n.array(n.object({
		card: Ae,
		playable: n.boolean()
	}))
}), q = (e) => ({ code: e }), J = {
	lead: 120,
	flight: 560,
	row: 380,
	hold: 1e3,
	chip: 280,
	exit: 220
};
function Me(e, t) {
	let n = 0;
	for (let r of Object.values(e.buildings)) r.p === t && (n += r.city ? 2 : 1);
	return e.longestRoute?.p === t && (n += 2), e.largestArmy?.p === t && (n += 2), n;
}
function Ne(e, t) {
	let n = e.players[t];
	return Me(e, t) + e.devs[n].filter((e) => e.card === "vp").length;
}
function Pe(e, t) {
	let n = [];
	return be.forEach((r, i) => {
		B[r].v.some((n) => e.buildings[n]?.p === t) && n.push(e.harbors[i]);
	}), n;
}
function Fe(e, t, n) {
	let r = 4;
	for (let i of Pe(e, t)) i === "any" ? r = Math.min(r, 3) : i === n && (r = Math.min(r, 2));
	return r;
}
function Ie(e, t) {
	let n = new Set(Object.entries(e.buildings).filter(([, e]) => e.p !== t).map(([e]) => e)), r = 0, i = (a, o) => {
		if (o.size > r && (r = o.size), !n.has(a)) for (let n of z[a].edges) {
			if (o.has(n) || e.roads[n] !== t) continue;
			let r = B[n], s = r.v[0] === a ? r.v[1] : r.v[0];
			o.add(n), i(s, o), o.delete(n);
		}
	};
	for (let [n, r] of Object.entries(e.roads)) {
		if (r !== t) continue;
		let e = B[n];
		for (let t of e.v) {
			let r = /* @__PURE__ */ new Set([n]);
			i(e.v[0] === t ? e.v[1] : e.v[0], r);
		}
	}
	return r;
}
function Y(e) {
	let t = e.players.map((t, n) => Ie(e, n)), n = e.longestRoute;
	if (n) {
		let r = Math.max(0, ...t.filter((e, t) => t !== n.p));
		if (t[n.p] >= 5 && t[n.p] >= r) {
			e.longestRoute = {
				p: n.p,
				len: t[n.p]
			};
			return;
		}
		e.longestRoute = null;
	}
	let r = Math.max(...t), i = t.map((e, t) => ({
		l: e,
		p: t
	})).filter(({ l: e }) => e === r && e >= 5);
	i.length === 1 && (e.longestRoute = {
		p: i[0].p,
		len: r
	});
}
function Le(e) {
	let t = e.players.map((t) => e.knightsPlayed[t]), n = e.largestArmy;
	if (n) {
		let r = Math.max(0, ...t.filter((e, t) => t !== n.p));
		if (t[n.p] > r) {
			e.largestArmy = {
				p: n.p,
				n: t[n.p]
			};
			return;
		}
		e.largestArmy = null;
	}
	let r = Math.max(...t), i = t.map((e, t) => ({
		n: e,
		p: t
	})).filter(({ n: e }) => e === r && e >= 3);
	i.length === 1 && (e.largestArmy = {
		p: i[0].p,
		n: r
	});
}
function Re(e, t, n) {
	let r = B[n];
	for (let i of r.v) {
		let r = e.buildings[i];
		if (r?.p === t) return !0;
		if (!(r && r.p !== t)) {
			for (let r of z[i].edges) if (r !== n && e.roads[r] === t) return !0;
		}
	}
	return !1;
}
function ze(e, t, n, r) {
	if (e.buildings[n]) return !1;
	for (let t of ye(n)) if (e.buildings[t]) return !1;
	return r ? !0 : z[n].edges.some((n) => e.roads[n] === t);
}
function Be(e) {
	return e.phase !== "play" || !e.turn ? !1 : Ne(e, e.turn.p) >= 10 && (e.phase = "done", e.winner = e.players[e.turn.p], !0);
}
function Ve(t, n, r) {
	let { board: i, cursor: a } = we(r, 0), o = [...se], s = a;
	for (let t = o.length - 1; t > 0; --t) {
		let n = e(r, s, t + 1);
		s += 1, [o[t], o[n]] = [o[n], o[t]];
	}
	let c = n.length, l = [...Array(c).keys(), ...Array.from({ length: c }, (e, t) => c - 1 - t)];
	return { state: {
		seed: r,
		rngCursor: s,
		players: [...n],
		board: i,
		robber: i.robber,
		buildings: {},
		roads: {},
		hands: Object.fromEntries(n.map((e) => [e, {}])),
		devs: Object.fromEntries(n.map((e) => [e, []])),
		devDeck: o,
		supply: Object.fromEntries(E.map((e) => [e, 19])),
		knightsPlayed: Object.fromEntries(n.map((e) => [e, 0])),
		longestRoute: null,
		largestArmy: null,
		stock: Object.fromEntries(n.map((e) => [e, {
			road: 15,
			settlement: 5,
			city: 4
		}])),
		turnCount: 0,
		phase: "setup",
		winner: null,
		setup: {
			order: l,
			idx: 0,
			stage: "settlement",
			lastVertex: null
		},
		turn: null
	} };
}
function He(t, n, r) {
	let i = structuredClone(t), a = [];
	if (n.type === "tick") {
		let e = i.phase === "play" ? i.turn : null;
		if (e?.producePending && e.dice) {
			let t = We(i, e.dice[0] + e.dice[1]);
			e.producePending = !1, Object.keys(t).length > 0 && a.push({
				kind: "produce",
				data: {
					gains: t,
					seats: i.players.length,
					source: "dice"
				}
			});
		}
		return {
			state: i,
			fx: a
		};
	}
	let o = i.players.indexOf(r.by);
	if (o < 0) return q("games.catan.errNotPlaying");
	if (i.phase === "setup") {
		let e = i.setup;
		if (o !== e.order[e.idx]) return q("games.catan.errNotYourTurn");
		if (n.type === "placeSettlement") {
			if (e.stage !== "settlement" || !ze(i, o, n.vertex, !0)) return q("games.catan.errBadVertex");
			i.buildings[n.vertex] = {
				p: o,
				city: !1
			}, --i.stock[r.by].settlement;
			let t = null;
			if (e.idx >= i.players.length) {
				let e = {};
				for (let t of z[n.vertex].hexes) {
					let n = ae[i.board.terrain[t]];
					n && i.supply[n] > 0 && (e[n] = (e[n] ?? 0) + 1, --i.supply[n]);
				}
				P(i.hands[r.by], e), Object.keys(e).length > 0 && (t = e);
			}
			return e.stage = "road", e.lastVertex = n.vertex, a.push({
				kind: "build",
				rid: r.by,
				data: {
					what: "settlement",
					key: n.vertex
				}
			}), t && a.push({
				kind: "produce",
				data: {
					gains: { [r.by]: t },
					seats: i.players.length
				},
				with: !0
			}), {
				state: i,
				fx: a
			};
		}
		return n.type === "placeRoad" ? e.stage !== "road" || !e.lastVertex || i.roads[n.edge] !== void 0 || !z[e.lastVertex].edges.includes(n.edge) ? q("games.catan.errBadEdge") : (i.roads[n.edge] = o, --i.stock[r.by].road, e.stage = "settlement", e.lastVertex = null, e.idx += 1, a.push({
			kind: "build",
			rid: r.by,
			data: {
				what: "road",
				key: n.edge
			}
		}), e.idx >= e.order.length && (i.setup = null, i.phase = "play", i.turnCount = 1, i.turn = {
			p: 0,
			stage: "roll",
			dice: null,
			devPlayed: !1,
			freeRoads: 0,
			pendingDiscard: [],
			pendingRobber: !1,
			producePending: !1,
			offer: null
		}), {
			state: i,
			fx: a
		}) : q("games.catan.errNotYourTurn");
	}
	if (i.phase !== "play" || !i.turn) return q("games.catan.errNotPlaying");
	let s = i.turn, c = o === s.p;
	if (s.producePending) return q("games.catan.errNotYourTurn");
	if (i.turn.pendingDiscard.length > 0) {
		if (n.type !== "discard") return q("games.catan.errMustDiscard");
		let e = s.pendingDiscard.find((e) => e.rid === r.by);
		return !e || j(n.cards) !== e.need || !M(i.hands[r.by], n.cards) ? q("games.catan.errBadDiscard") : (N(i.hands[r.by], n.cards), P(i.supply, n.cards), s.pendingDiscard = s.pendingDiscard.filter((e) => e.rid !== r.by), a.push({
			kind: "discard",
			rid: r.by,
			data: { n: e.need }
		}), {
			state: i,
			fx: a
		});
	}
	if (s.pendingRobber) return n.type === "moveRobber" ? c ? Ue(i, n.hex, n.stealFrom, a) : q("games.catan.errNotYourTurn") : q("games.catan.errMustRobber");
	switch (n.type) {
		case "roll": {
			if (!c || s.stage !== "roll") return q("games.catan.errNotYourTurn");
			let t = 1 + e(i.seed, i.rngCursor, 6), n = 1 + e(i.seed, i.rngCursor + 1, 6);
			return i.rngCursor += 2, s.dice = [t, n], s.stage = "action", a.push({
				kind: "diceRoll",
				rid: r.by,
				data: {
					dice: [t, n],
					banner: !0
				}
			}), t + n === 7 ? (s.pendingDiscard = i.players.map((e) => ({
				rid: e,
				n: j(i.hands[e])
			})).filter(({ n: e }) => e > 7).map(({ rid: e, n: t }) => ({
				rid: e,
				need: Math.floor(t / 2)
			})), s.pendingRobber = !0) : s.producePending = !0, {
				state: i,
				fx: a
			};
		}
		case "moveRobber": return q("games.catan.errNoRobber");
		case "buildRoad": {
			if (!c || s.stage !== "action") return q("games.catan.errNotYourTurn");
			if (i.roads[n.edge] !== void 0 || !B[n.edge]) return q("games.catan.errBadEdge");
			let e = s.freeRoads > 0;
			return !e && !M(i.hands[r.by], k) ? q("games.catan.errCantAfford") : i.stock[r.by].road <= 0 ? q("games.catan.errNoStock") : Re(i, o, n.edge) ? (e ? --s.freeRoads : (N(i.hands[r.by], k), P(i.supply, k)), i.roads[n.edge] = o, --i.stock[r.by].road, Y(i), a.push({
				kind: "build",
				rid: r.by,
				data: {
					what: "road",
					key: n.edge
				}
			}), Be(i), {
				state: i,
				fx: a
			}) : q("games.catan.errBadEdge");
		}
		case "buildSettlement": return !c || s.stage !== "action" ? q("games.catan.errNotYourTurn") : M(i.hands[r.by], A) ? i.stock[r.by].settlement <= 0 ? q("games.catan.errNoStock") : ze(i, o, n.vertex, !1) ? (N(i.hands[r.by], A), P(i.supply, A), i.buildings[n.vertex] = {
			p: o,
			city: !1
		}, --i.stock[r.by].settlement, Y(i), a.push({
			kind: "build",
			rid: r.by,
			data: {
				what: "settlement",
				key: n.vertex
			}
		}), Be(i), {
			state: i,
			fx: a
		}) : q("games.catan.errBadVertex") : q("games.catan.errCantAfford");
		case "buildCity": {
			if (!c || s.stage !== "action") return q("games.catan.errNotYourTurn");
			let e = i.buildings[n.vertex];
			return !e || e.p !== o || e.city ? q("games.catan.errBadVertex") : M(i.hands[r.by], ce) ? i.stock[r.by].city <= 0 ? q("games.catan.errNoStock") : (N(i.hands[r.by], ce), P(i.supply, ce), e.city = !0, --i.stock[r.by].city, i.stock[r.by].settlement += 1, a.push({
				kind: "build",
				rid: r.by,
				data: {
					what: "city",
					key: n.vertex
				}
			}), Be(i), {
				state: i,
				fx: a
			}) : q("games.catan.errCantAfford");
		}
		case "buyDev": {
			if (!c || s.stage !== "action") return q("games.catan.errNotYourTurn");
			if (i.devDeck.length === 0) return q("games.catan.errNoStock");
			if (!M(i.hands[r.by], le)) return q("games.catan.errCantAfford");
			N(i.hands[r.by], le), P(i.supply, le);
			let e = i.devDeck.pop();
			return i.devs[r.by].push({
				card: e,
				boughtTurn: i.turnCount
			}), a.push({
				kind: "devBuy",
				rid: r.by
			}), Be(i), {
				state: i,
				fx: a
			};
		}
		case "playDev": {
			if (!c) return q("games.catan.errNotYourTurn");
			if (s.devPlayed) return q("games.catan.errDevPlayed");
			if (s.stage === "roll" && n.card !== "knight") return q("games.catan.errBadDev");
			let e = i.devs[r.by].findIndex((e) => e.card === n.card && e.boughtTurn < i.turnCount);
			if (e < 0) return q("games.catan.errBadDev");
			switch (i.devs[r.by].splice(e, 1), s.devPlayed = !0, a.push({
				kind: "devPlay",
				rid: r.by,
				data: { card: n.card }
			}), n.card) {
				case "knight":
					i.knightsPlayed[r.by] += 1, Le(i), s.pendingRobber = !0;
					break;
				case "roadBuilding":
					s.freeRoads = 2;
					break;
				case "invention": {
					let e = n.take;
					if (!e) return q("games.catan.errBadDev");
					let t = {};
					for (let n of e) t[n] = (t[n] ?? 0) + 1;
					for (let e of E) if ((t[e] ?? 0) > i.supply[e]) return q("games.catan.errBadDev");
					for (let e of E) i.supply[e] -= t[e] ?? 0;
					P(i.hands[r.by], t), a.push({
						kind: "produce",
						data: {
							gains: { [r.by]: t },
							seats: i.players.length
						},
						with: !0
					});
					break;
				}
				case "monopoly": {
					if (!n.resource) return q("games.catan.errBadDev");
					let e = 0;
					for (let t of i.players) {
						if (t === r.by) continue;
						let a = i.hands[t][n.resource] ?? 0;
						a > 0 && (i.hands[t][n.resource] = 0, e += a);
					}
					P(i.hands[r.by], { [n.resource]: e }), e > 0 && a.push({
						kind: "produce",
						data: {
							gains: { [r.by]: { [n.resource]: e } },
							seats: i.players.length
						},
						with: !0
					});
					break;
				}
			}
			return Be(i), {
				state: i,
				fx: a
			};
		}
		case "cancelRoadBuilding": return !c || s.freeRoads === 0 ? q("games.catan.errNotYourTurn") : (s.freeRoads = 0, {
			state: i,
			fx: a
		});
		case "offerTrade":
			if (!c || s.stage !== "action") return q("games.catan.errNotYourTurn");
			if (s.offer || j(n.give) === 0 || j(n.want) === 0) return q("games.catan.errBadTrade");
			for (let e of E) if ((n.give[e] ?? 0) > 0 && (n.want[e] ?? 0) > 0) return q("games.catan.errBadTrade");
			return M(i.hands[r.by], n.give) ? (s.offer = {
				from: o,
				give: n.give,
				want: n.want,
				declined: []
			}, a.push({
				kind: "offer",
				rid: r.by
			}), {
				state: i,
				fx: a
			}) : q("games.catan.errCantAfford");
		case "cancelTrade": return !s.offer || s.offer.from !== o ? q("games.catan.errBadTrade") : (s.offer = null, {
			state: i,
			fx: a
		});
		case "acceptTrade": {
			let e = s.offer;
			if (!e || e.from === o || e.declined.includes(o)) return q("games.catan.errBadTrade");
			if (!M(i.hands[r.by], e.want)) return q("games.catan.errCantAfford");
			let t = i.players[e.from];
			return M(i.hands[t], e.give) ? (N(i.hands[r.by], e.want), P(i.hands[t], e.want), N(i.hands[t], e.give), P(i.hands[r.by], e.give), s.offer = null, a.push({
				kind: "trade",
				data: {
					a: t,
					b: r.by
				}
			}), Be(i), {
				state: i,
				fx: a
			}) : q("games.catan.errBadTrade");
		}
		case "declineTrade": {
			let e = s.offer;
			return !e || e.from === o ? q("games.catan.errBadTrade") : (e.declined.includes(o) || e.declined.push(o), e.declined.length >= i.players.length - 1 && (s.offer = null), {
				state: i,
				fx: a
			});
		}
		case "bankTrade": {
			if (!c || s.stage !== "action") return q("games.catan.errNotYourTurn");
			if (n.give === n.get) return q("games.catan.errBadTrade");
			let e = Fe({
				buildings: i.buildings,
				harbors: i.board.harbors
			}, o, n.give);
			return (i.hands[r.by][n.give] ?? 0) < e ? q("games.catan.errCantAfford") : i.supply[n.get] <= 0 ? q("games.catan.errNoStock") : (i.hands[r.by][n.give] = (i.hands[r.by][n.give] ?? 0) - e, i.supply[n.give] += e, --i.supply[n.get], i.hands[r.by][n.get] = (i.hands[r.by][n.get] ?? 0) + 1, a.push({
				kind: "bankTrade",
				rid: r.by,
				data: {
					give: n.give,
					get: n.get,
					n: e
				}
			}), {
				state: i,
				fx: a
			});
		}
		case "endTurn": return !c || s.stage !== "action" ? q("games.catan.errNotYourTurn") : s.freeRoads > 0 ? q("games.catan.errFreeRoads") : (i.turnCount += 1, i.turn = {
			p: (s.p + 1) % i.players.length,
			stage: "roll",
			dice: null,
			devPlayed: !1,
			freeRoads: 0,
			pendingDiscard: [],
			pendingRobber: !1,
			producePending: !1,
			offer: null
		}, {
			state: i,
			fx: a
		});
		default: return q("games.catan.errNotYourTurn");
	}
}
function Ue(t, n, r, i) {
	let a = t.turn;
	if (n === t.robber || n < 0 || n >= 19) return q("games.catan.errBadHex");
	let o = [...new Set(ve(n).map((e) => t.buildings[e]?.p).filter((e) => e !== void 0 && e !== a.p))], s = null;
	if (o.length > 0) {
		if (!r) return q("games.catan.errBadSteal");
		let e = t.players.indexOf(r);
		if (!o.includes(e)) return q("games.catan.errBadSteal");
		s = r;
	}
	if (t.robber = n, a.pendingRobber = !1, i.push({
		kind: "robber",
		rid: t.players[a.p],
		data: { hex: n }
	}), s && j(t.hands[s]) > 0) {
		let n = [];
		for (let e of E) for (let r = 0; r < (t.hands[s][e] ?? 0); r++) n.push(e);
		let r = n[e(t.seed, t.rngCursor, n.length)];
		t.rngCursor += 1, t.hands[s][r] = (t.hands[s][r] ?? 0) - 1, P(t.hands[t.players[a.p]], { [r]: 1 }), i.push({
			kind: "steal",
			data: {
				from: s,
				to: t.players[a.p]
			}
		});
	}
	return Be(t), {
		state: t,
		fx: i
	};
}
function We(e, t) {
	let n = {};
	for (let r = 0; r < 19; r++) {
		if (e.board.discs[r] !== t || r === e.robber) continue;
		let i = ae[e.board.terrain[r]];
		if (i) for (let t of ve(r)) {
			let r = e.buildings[t];
			if (!r) continue;
			let a = r.city ? 2 : 1, o = n[i] ??= [], s = o.find((t) => t.rid === e.players[r.p]);
			s ? s.n += a : o.push({
				rid: e.players[r.p],
				n: a
			});
		}
	}
	let r = {};
	for (let [t, i] of Object.entries(n)) {
		let n = i.reduce((e, t) => e + t.n, 0), a = e.supply[t];
		if (!(n > a && i.length > 1)) for (let n of i) {
			let o = Math.min(n.n, i.length === 1 ? a : n.n);
			o <= 0 || (e.supply[t] -= o, P(e.hands[n.rid], { [t]: o }), P(r[n.rid] ??= {}, { [t]: o }));
		}
	}
	return r;
}
function X(e, t) {
	return {
		public: {
			phase: e.phase,
			terrain: e.board.terrain,
			discs: e.board.discs,
			harbors: e.board.harbors,
			robber: e.robber,
			buildings: e.buildings,
			roads: e.roads,
			players: e.players.map((t, n) => ({
				rid: t,
				resCount: j(e.hands[t]),
				devCount: e.devs[t].length,
				knights: e.knightsPlayed[t],
				vp: Me(e, n),
				stock: e.stock[t],
				ports: Pe({
					buildings: e.buildings,
					harbors: e.board.harbors
				}, n),
				longestRoute: e.longestRoute?.p === n,
				largestArmy: e.largestArmy?.p === n
			})),
			setup: e.setup,
			turn: e.turn,
			devDeck: e.devDeck.length,
			supply: e.supply,
			winner: e.winner
		},
		private: {
			hand: e.hands[t] ?? {},
			devs: (e.devs[t] ?? []).map((t) => ({
				card: t.card,
				playable: t.boughtTurn < e.turnCount
			}))
		}
	};
}
function Ge(e) {
	if (e.phase !== "done" || !e.winner) return { phase: e.phase };
	let t = Object.fromEntries(e.players.map((t, n) => [t, Ne(e, n)])), n = [...e.players].sort((e, n) => t[n] - t[e]);
	return {
		phase: "done",
		winner: [e.winner],
		ranking: n,
		scores: t
	};
}
function Z(e) {
	return e.phase === "play" && e.turn?.producePending ? t.banner(2) : null;
}
var Ke = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: H,
	schemas: {
		action: De,
		publicView: je,
		privateView: K
	},
	setup: Ve,
	reduce: He,
	viewFor: X,
	status: Ge,
	nextTickIn: Z
}, Q = "var(--color-ink)", qe = {
	wood: /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y("rect", {
			x: 5,
			y: 9,
			width: 15.5,
			height: 6,
			rx: 3,
			fill: "#a5713a",
			stroke: Q,
			strokeWidth: 1.8
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: 6.6,
			cy: 12,
			rx: 2.5,
			ry: 3,
			fill: "#e3c188",
			stroke: Q,
			strokeWidth: 1.4
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: 6.6,
			cy: 12,
			rx: 1.1,
			ry: 1.6,
			fill: "none",
			stroke: "#8a5a28",
			strokeWidth: .9
		}),
		/* @__PURE__ */ y("path", {
			d: "M11.5 10.6 H17.5 M11.5 13.4 H16.5",
			fill: "none",
			stroke: "#7c5023",
			strokeWidth: 1,
			strokeLinecap: "round",
			opacity: .7
		})
	] }),
	brick: /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y("rect", {
			x: 5.5,
			y: 6,
			width: 13,
			height: 12,
			rx: 1.5,
			fill: "#c14f2b",
			stroke: Q,
			strokeWidth: 1.8
		}),
		/* @__PURE__ */ y("path", {
			d: "M6 12 H18 M12 6.5 V12 M9 12 V17.5 M15 12 V17.5",
			fill: "none",
			stroke: "#8f3f24",
			strokeWidth: 1.1,
			opacity: .85
		}),
		/* @__PURE__ */ y("path", {
			d: "M7.5 9 H11",
			fill: "none",
			stroke: "#e8967a",
			strokeWidth: 1.2,
			strokeLinecap: "round",
			opacity: .7
		})
	] }),
	wool: /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y("rect", {
			x: 7.2,
			y: 17.6,
			width: 1.9,
			height: 3.2,
			rx: .9,
			fill: "#5b5348"
		}),
		/* @__PURE__ */ y("rect", {
			x: 12.6,
			y: 17.6,
			width: 1.9,
			height: 3.2,
			rx: .9,
			fill: "#5b5348"
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: 10.8,
			cy: 13.4,
			rx: 6.6,
			ry: 5.4,
			fill: "#f4f1e8",
			stroke: Q,
			strokeWidth: 1.7
		}),
		/* @__PURE__ */ y("circle", {
			cx: 6.4,
			cy: 10.4,
			r: 2,
			fill: "#f4f1e8"
		}),
		/* @__PURE__ */ y("circle", {
			cx: 10.2,
			cy: 8.7,
			r: 2.2,
			fill: "#f4f1e8"
		}),
		/* @__PURE__ */ y("circle", {
			cx: 14,
			cy: 10,
			r: 2,
			fill: "#f4f1e8"
		}),
		/* @__PURE__ */ y("ellipse", {
			cx: 17.2,
			cy: 13.8,
			rx: 2.5,
			ry: 3,
			fill: "#5b5348",
			stroke: Q,
			strokeWidth: 1.2
		}),
		/* @__PURE__ */ y("circle", {
			cx: 17.6,
			cy: 12.9,
			r: .55,
			fill: "#f4f1e8"
		})
	] }),
	wheat: /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y("path", {
			d: "M12 21 V9",
			fill: "none",
			stroke: "#b8860b",
			strokeWidth: 1.5,
			strokeLinecap: "round"
		}),
		[
			5,
			8,
			11,
			14
		].map((e) => /* @__PURE__ */ b("g", { children: [/* @__PURE__ */ y("ellipse", {
			cx: 9.4,
			cy: e + 1.5,
			rx: 1.5,
			ry: 2.7,
			fill: "#e9b63c",
			stroke: Q,
			strokeWidth: .85,
			transform: `rotate(-28 9.4 ${e + 1.5})`
		}), /* @__PURE__ */ y("ellipse", {
			cx: 14.6,
			cy: e + 1.5,
			rx: 1.5,
			ry: 2.7,
			fill: "#e9b63c",
			stroke: Q,
			strokeWidth: .85,
			transform: `rotate(28 14.6 ${e + 1.5})`
		})] }, e)),
		/* @__PURE__ */ y("ellipse", {
			cx: 12,
			cy: 4.2,
			rx: 1.5,
			ry: 2.7,
			fill: "#f2c85c",
			stroke: Q,
			strokeWidth: .85
		})
	] }),
	ore: /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y("path", {
			d: "M7 6.5 L13.5 4.5 L19 9 L18 17 L8 18.5 L4.5 11.5 Z",
			fill: "#9aa3ad",
			stroke: Q,
			strokeWidth: 1.8,
			strokeLinejoin: "round"
		}),
		/* @__PURE__ */ y("path", {
			d: "M8 8.5 L13 7 L16.5 9.8",
			fill: "none",
			stroke: "#d8dde3",
			strokeWidth: 1.4,
			strokeLinecap: "round",
			opacity: .8
		}),
		/* @__PURE__ */ y("path", {
			d: "M13 7 L12.5 17.5",
			fill: "none",
			stroke: "#7d858f",
			strokeWidth: 1,
			opacity: .6
		})
	] })
};
function Je({ resource: e, size: t = 18 }) {
	return /* @__PURE__ */ y("svg", {
		width: t,
		height: t,
		viewBox: "0 0 24 24",
		"aria-hidden": !0,
		className: "flex-none",
		children: qe[e]
	});
}
var Ye = Math.sqrt(3), Xe = {
	hills: "#c2703e",
	forest: "#3f7d4e",
	pasture: "#a3c56a",
	fields: "#e3b23c",
	mountains: "#8b8f98",
	desert: "#e2c99a"
}, $ = {
	wood: "🌲",
	brick: "🧱",
	wool: "🐑",
	wheat: "🌾",
	ore: "🪨"
}, Ze = {
	hills: "terrain-hills.webp",
	forest: "terrain-forest.webp",
	pasture: "terrain-pasture.webp",
	fields: "terrain-fields.webp",
	mountains: "terrain-mountains.webp",
	desert: "terrain-desert.webp"
}, Qe = {
	hills: $.brick,
	forest: $.wood,
	pasture: $.wool,
	fields: $.wheat,
	mountains: $.ore,
	desert: "🏜️"
};
function $e(e) {
	let t = (90 - 60 * ((e % 6 + 6) % 6)) * Math.PI / 180;
	return [50 * Math.cos(t), 50 * Math.sin(t)];
}
var et = Array.from({ length: 6 }, (e, t) => $e(t).join(",")).join(" "), tt = Array.from({ length: 6 }, (e, t) => $e(t).map((e) => e * .94).join(",")).join(" "), nt = (() => {
	let e = F.map((e, t) => L(t)), t = e.map((e) => e[0]), n = e.map((e) => e[1]);
	return {
		minX: Math.min(...t) * 50 - 95,
		maxX: Math.max(...t) * 50 + 95,
		minY: Math.min(...n) * 50 - 105,
		maxY: Math.max(...n) * 50 + 105
	};
})();
function rt(e) {
	return e.w === 0 ? {
		cx: 0,
		cy: 0,
		s: 1
	} : {
		cx: (nt.minX + nt.maxX) / 2,
		cy: (nt.minY + nt.maxY) / 2,
		s: Math.min(e.w / (nt.maxX - nt.minX), e.h / (nt.maxY - nt.minY))
	};
}
function it({ n: e }) {
	let t = e === 6 || e === 8, n = ue(e);
	return /* @__PURE__ */ b("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ y("circle", {
				cy: 3,
				r: 17,
				fill: "#6b5540",
				opacity: .5
			}),
			/* @__PURE__ */ y("circle", {
				r: 17,
				fill: "#f7e9c9",
				stroke: "#3b2b20",
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ y("circle", {
				r: 14,
				fill: "none",
				stroke: "#ba9263",
				strokeWidth: 1.2
			}),
			t && /* @__PURE__ */ y("path", {
				d: "M -11 -9 L -7 -13 M 7 -13 L 11 -9",
				stroke: "#b5312b",
				strokeWidth: 2,
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ y("text", {
				y: 3,
				textAnchor: "middle",
				fontSize: 17,
				fontWeight: 800,
				fill: t ? "#b5312b" : "#30251e",
				children: e
			}),
			Array.from({ length: n }, (e, r) => /* @__PURE__ */ y("circle", {
				cx: (r - (n - 1) / 2) * 5,
				cy: 10,
				r: 1.8,
				fill: t ? "#b5312b" : "#30251e"
			}, r))
		]
	});
}
function at() {
	return /* @__PURE__ */ b("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ y("ellipse", {
				cy: 14,
				rx: 16,
				ry: 5,
				fill: "#30251e",
				opacity: .35
			}),
			/* @__PURE__ */ y("circle", {
				cy: -14,
				r: 9,
				fill: "#454347",
				stroke: "#282325",
				strokeWidth: 2.5
			}),
			/* @__PURE__ */ y("path", {
				d: "M -13 14 L -9 -4 L 9 -4 L 13 14 Z",
				fill: "#454347",
				stroke: "#282325",
				strokeWidth: 2.5,
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ y("path", {
				d: "M -6 -3 L -8 10",
				stroke: "#89878a",
				strokeWidth: 2,
				strokeLinecap: "round"
			})
		]
	});
}
function ot({ city: e, color: t, ghost: n }) {
	let r = {
		fill: t,
		stroke: "#30251e",
		strokeWidth: 2.5,
		strokeLinejoin: "round",
		opacity: n ? .65 : 1
	};
	return e ? /* @__PURE__ */ b("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ y("ellipse", {
				cy: 13,
				rx: 18,
				ry: 5,
				fill: "#30251e",
				opacity: n ? .15 : .3
			}),
			/* @__PURE__ */ y("path", {
				d: "M -16 11 L -16 -1 L -7 -10 L 2 -1 L 2 11 Z",
				...r
			}),
			/* @__PURE__ */ y("path", {
				d: "M 2 11 L 2 -5 L 9 -14 L 16 -5 L 16 11 Z",
				...r
			}),
			/* @__PURE__ */ y("path", {
				d: "M -13 -1 L -7 -8 L -1 -1 M 5 -5 L 9 -12 L 13 -5",
				fill: "none",
				stroke: "#fff1cd",
				strokeWidth: 1.8,
				opacity: .8
			}),
			/* @__PURE__ */ y("rect", {
				x: 7,
				y: 2,
				width: 4,
				height: 9,
				fill: "#f8dda7",
				opacity: n ? .65 : 1
			})
		]
	}) : /* @__PURE__ */ b("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ y("ellipse", {
				cy: 13,
				rx: 14,
				ry: 5,
				fill: "#30251e",
				opacity: n ? .15 : .3
			}),
			/* @__PURE__ */ y("path", {
				d: "M -12 11 L -12 -2 L 0 -14 L 12 -2 L 12 11 Z",
				...r
			}),
			/* @__PURE__ */ y("path", {
				d: "M -11 -2 L 0 -13 L 11 -2",
				fill: "none",
				stroke: "#fff1cd",
				strokeWidth: 2,
				opacity: .8
			}),
			/* @__PURE__ */ y("path", {
				d: "M -2 11 L -2 3 L 3 3 L 3 11",
				fill: "#f8dda7",
				opacity: n ? .65 : 1
			})
		]
	});
}
function st({ terrain: e, discs: t, rollTotal: n, harbors: r, robber: l, buildings: u, roads: d, colorOf: f, spots: m, ghost: h, ghostColor: g, onTap: _ }) {
	let ee = p(), v = `${a().replaceAll(":", "")}-tile`, x = s(null), [S, te] = c({
		w: 0,
		h: 0
	}), [C, ne] = c(null), w = s({
		cx: 0,
		cy: 0,
		s: 1
	}), T = s(!1), re = s(d), [ie, E] = c(null), [ae, oe] = c(() => typeof window < "u" && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
	i(() => {
		let e = window.matchMedia("(prefers-reduced-motion: reduce)"), t = () => oe(e.matches);
		return e.addEventListener("change", t), () => e.removeEventListener("change", t);
	}, []), i(() => {
		let e = Object.keys(d).find((e) => re.current[e] === void 0);
		re.current = d, e && E(e);
	}, [d]), i(() => {
		if (!ie) return;
		let e = window.setTimeout(() => E(null), 460);
		return () => window.clearTimeout(e);
	}, [ie]), i(() => {
		let e = x.current, t = new ResizeObserver(() => te({
			w: e.clientWidth,
			h: e.clientHeight
		}));
		return t.observe(e), () => t.disconnect();
	}, []), i(() => {
		S.w > 0 && S.h > 0 && !T.current && ne(rt(S));
	}, [S]);
	let D = C ?? rt(S);
	i(() => {
		w.current = D;
	}), i(() => {
		let e = x.current, t = (t) => {
			t.preventDefault(), T.current = !0;
			let n = e.getBoundingClientRect(), r = w.current, i = t.deltaY < 0 ? 1.15 : 1 / 1.15, a = Math.min(Math.max(r.s * i, .35), 3), o = t.clientX - n.left - n.width / 2, s = t.clientY - n.top - n.height / 2, c = r.cx + o / r.s, l = r.cy + s / r.s, u = {
				s: a,
				cx: c - o / a,
				cy: l - s / a
			};
			w.current = u, ne(u);
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let O = s(/* @__PURE__ */ new Map()), se = s(0), k = s(0), A = (e) => {
		if (e.currentTarget.setPointerCapture(e.pointerId), O.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		}), O.current.size === 1 && (se.current = 0), O.current.size === 2) {
			let [e, t] = [...O.current.values()];
			k.current = Math.hypot(e.x - t.x, e.y - t.y);
		}
	}, ce = (e) => {
		let t = O.current.get(e.pointerId);
		if (!t) return;
		let n = x.current.getBoundingClientRect();
		if (O.current.size === 1) {
			let n = e.clientX - t.x, r = e.clientY - t.y;
			se.current += Math.abs(n) + Math.abs(r), se.current > 10 && (T.current = !0);
			let i = w.current, a = {
				...i,
				cx: i.cx - n / i.s,
				cy: i.cy - r / i.s
			};
			w.current = a, ne(a);
		} else if (O.current.size === 2) {
			T.current = !0, O.current.set(e.pointerId, {
				x: e.clientX,
				y: e.clientY
			});
			let [t, r] = [...O.current.values()], i = Math.hypot(t.x - r.x, t.y - r.y);
			if (k.current > 0 && i > 0) {
				let e = w.current, a = Math.min(Math.max(e.s * i / k.current, .35), 3), o = (t.x + r.x) / 2 - n.left - n.width / 2, s = (t.y + r.y) / 2 - n.top - n.height / 2, c = e.cx + o / e.s, l = e.cy + s / e.s, u = {
					s: a,
					cx: c - o / a,
					cy: l - s / a
				};
				w.current = u, ne(u);
			}
			k.current = i, se.current = 99;
			return;
		}
		O.current.set(e.pointerId, {
			x: e.clientX,
			y: e.clientY
		});
	}, le = (e) => {
		let t = O.current.size === 1 && se.current < 10;
		if (O.current.delete(e.pointerId), k.current = 0, !t || !_ || !m) return;
		let n = x.current.getBoundingClientRect(), r = w.current, i = (r.cx + (e.clientX - n.left - n.width / 2) / r.s) / 50, a = (r.cy + (e.clientY - n.top - n.height / 2) / r.s) / 50;
		if (m.vertices) {
			let e = null, t = .55;
			for (let n of m.vertices) {
				let [r, o] = R(n), s = Math.hypot(r - i, o - a);
				s < t && (t = s, e = n);
			}
			if (e) {
				_({
					kind: "vertex",
					key: e
				});
				return;
			}
		}
		if (m.edges) {
			let e = null, t = .4;
			for (let n of m.edges) {
				let r = B[n], [o, s] = R(r.v[0]), [c, l] = R(r.v[1]), u = c - o, d = l - s, f = Math.max(0, Math.min(1, ((i - o) * u + (a - s) * d) / (u * u + d * d))), p = Math.hypot(o + f * u - i, s + f * d - a);
				p < t && (t = p, e = n);
			}
			if (e) {
				_({
					kind: "edge",
					key: e
				});
				return;
			}
		}
		if (m.hexes) {
			let e = null, t = Ye / 2 + .15;
			for (let n of m.hexes) {
				let [r, o] = L(n), s = Math.hypot(r - i, o - a);
				s < t && (t = s, e = n);
			}
			e !== null && _({
				kind: "hex",
				key: e
			});
		}
	}, ue = o(() => be.map((e, t) => {
		let n = B[e], i = Math.hypot(n.x, n.y) || 1, a = n.x / i * .62, o = n.y / i * .62;
		return {
			e: n,
			kind: r[t],
			lx: (n.x + a) * 50,
			ly: (n.y + o) * 50,
			i: t
		};
	}), [r]), j = (e) => {
		let [t, n] = R(e);
		return [t * 50, n * 50];
	}, M = (m?.vertices?.size ?? 0) > 25, N = (m?.edges?.size ?? 0) > 8;
	return /* @__PURE__ */ y("div", {
		ref: x,
		className: "relative h-full w-full overflow-hidden bg-[#8dc9c8]",
		children: /* @__PURE__ */ b("svg", {
			className: "h-full w-full touch-none select-none",
			onPointerDown: A,
			onPointerMove: ce,
			onPointerUp: le,
			onPointerCancel: le,
			children: [
				/* @__PURE__ */ y("defs", { children: /* @__PURE__ */ y("clipPath", {
					id: v,
					children: /* @__PURE__ */ y("polygon", { points: tt })
				}) }),
				/* @__PURE__ */ y("rect", {
					width: S.w,
					height: S.h,
					fill: "#8dc9c8",
					pointerEvents: "none"
				}),
				/* @__PURE__ */ y("g", {
					fill: "none",
					stroke: "#d7f1e7",
					strokeWidth: 2,
					opacity: .55,
					pointerEvents: "none",
					children: [
						[.1, .15],
						[.88, .2],
						[.08, .62],
						[.9, .58],
						[.12, .84],
						[.86, .89]
					].map(([e, t], n) => /* @__PURE__ */ y("path", { d: `M ${S.w * e - 13} ${S.h * t + 4} Q ${S.w * e} ${S.h * t - 4} ${S.w * e + 13} ${S.h * t + 4}` }, n))
				}),
				/* @__PURE__ */ b("g", {
					className: "catan-board-title",
					pointerEvents: "none",
					children: [/* @__PURE__ */ y("rect", {
						x: S.w / 2 - 48,
						y: 13,
						width: 96,
						height: 25,
						rx: 7,
						fill: "#f7e3b4",
						stroke: "#30251e",
						strokeWidth: 2
					}), /* @__PURE__ */ y("text", {
						x: S.w / 2,
						y: 30,
						textAnchor: "middle",
						fontSize: 12,
						fontWeight: 800,
						fill: "#30251e",
						children: ee("games.catan.name")
					})]
				}),
				/* @__PURE__ */ b("g", {
					transform: `translate(${S.w / 2 - D.cx * D.s}, ${S.h / 2 - D.cy * D.s}) scale(${D.s})`,
					children: [
						F.map((r, i) => {
							let [a, o] = L(i);
							return /* @__PURE__ */ b("g", {
								transform: `translate(${a * 50}, ${o * 50})`,
								children: [
									/* @__PURE__ */ y("polygon", {
										points: et,
										transform: "translate(0 4)",
										fill: "#477d77",
										opacity: .55,
										pointerEvents: "none"
									}),
									/* @__PURE__ */ y("polygon", {
										points: et,
										fill: Xe[e[i]],
										stroke: "#30251e",
										strokeWidth: 3,
										strokeLinejoin: "round",
										pointerEvents: "none"
									}),
									/* @__PURE__ */ y("text", {
										y: -22,
										textAnchor: "middle",
										fontSize: 24,
										pointerEvents: "none",
										"aria-hidden": "true",
										children: Qe[e[i]]
									}),
									/* @__PURE__ */ y("image", {
										href: `./games/catan/${Ze[e[i]]}`,
										x: -50,
										y: -50,
										width: 100,
										height: 100,
										preserveAspectRatio: "xMidYMid slice",
										clipPath: `url(#${v})`,
										pointerEvents: "none"
									}),
									/* @__PURE__ */ y("polygon", {
										points: tt,
										fill: "none",
										stroke: "#f5dba8",
										strokeWidth: 1.5,
										strokeLinejoin: "round",
										pointerEvents: "none"
									}),
									t[i] !== null && /* @__PURE__ */ b("g", {
										transform: `translate(0, ${l === i ? 10 : 0})`,
										children: [/* @__PURE__ */ y(it, { n: t[i] }), t[i] === n && l !== i && /* @__PURE__ */ b("g", {
											pointerEvents: "none",
											children: [/* @__PURE__ */ y("circle", {
												className: "catan-produced-disc",
												r: 21,
												fill: "none",
												stroke: "#fff8d6",
												strokeWidth: 4
											}), /* @__PURE__ */ y("circle", {
												className: "catan-produced-echo",
												r: 21,
												fill: "none",
												stroke: "#fff8d6",
												strokeWidth: 2
											})]
										})]
									}),
									l === i && /* @__PURE__ */ y("g", {
										transform: "translate(0, -24)",
										children: /* @__PURE__ */ y(at, {})
									}),
									m?.hexes?.has(i) && /* @__PURE__ */ y("polygon", {
										points: et,
										fill: "#fff8d6",
										fillOpacity: .16,
										stroke: "#fff8d6",
										strokeWidth: 4,
										strokeDasharray: "10 6",
										strokeLinejoin: "round",
										pointerEvents: "none"
									})
								]
							}, i);
						}),
						ue.map(({ e, kind: t, lx: n, ly: r, i }) => /* @__PURE__ */ b("g", {
							pointerEvents: "none",
							children: [
								/* @__PURE__ */ y("line", {
									x1: n,
									y1: r,
									x2: e.x * 50,
									y2: e.y * 50,
									stroke: "#705239",
									strokeWidth: 1.6,
									opacity: .75
								}),
								/* @__PURE__ */ y("rect", {
									x: n - 19,
									y: r - 17,
									width: 38,
									height: 32,
									rx: 7,
									fill: "#f8e9c9",
									stroke: "#30251e",
									strokeWidth: 2.3
								}),
								/* @__PURE__ */ y("text", {
									x: n,
									y: r - 2,
									textAnchor: "middle",
									fontSize: 12,
									fontWeight: 800,
									fill: "#30251e",
									children: t === "any" ? "3:1" : "2:1"
								}),
								t === "any" ? /* @__PURE__ */ b("g", {
									transform: `translate(${n}, ${r + 7})`,
									fill: "none",
									stroke: "#4e735e",
									strokeWidth: 2,
									strokeLinecap: "round",
									strokeLinejoin: "round",
									children: [/* @__PURE__ */ y("circle", {
										cy: -4,
										r: 2
									}), /* @__PURE__ */ y("path", { d: "M0-2V5 M-6 1H6 M-6 1Q-6 6 0 6Q6 6 6 1" })]
								}) : /* @__PURE__ */ y("g", {
									transform: `translate(${n - 8}, ${r + 1})`,
									children: /* @__PURE__ */ y(Je, {
										resource: t,
										size: 16
									})
								})
							]
						}, i)),
						Object.entries(d).map(([e, t]) => {
							let n = B[e], [r, i] = j(n.v[0]), [a, o] = j(n.v[1]), s = f(t), c = ie === e && !ae, l = Math.hypot(a - r, o - i);
							return /* @__PURE__ */ b("g", {
								pointerEvents: "none",
								strokeLinecap: "round",
								children: [
									/* @__PURE__ */ y("line", {
										x1: r,
										y1: i + 2,
										x2: a,
										y2: o + 2,
										stroke: "#30251e",
										strokeWidth: 14,
										strokeDasharray: c ? l : void 0,
										strokeDashoffset: c ? l : void 0,
										children: c && /* @__PURE__ */ y("animate", {
											attributeName: "stroke-dashoffset",
											from: l,
											to: "0",
											dur: "0.22s",
											fill: "freeze"
										})
									}),
									/* @__PURE__ */ y("line", {
										x1: r,
										y1: i,
										x2: a,
										y2: o,
										stroke: s,
										strokeWidth: 8,
										strokeDasharray: c ? l : void 0,
										strokeDashoffset: c ? l : void 0,
										children: c && /* @__PURE__ */ y("animate", {
											attributeName: "stroke-dashoffset",
											from: l,
											to: "0",
											dur: "0.22s",
											fill: "freeze"
										})
									}),
									/* @__PURE__ */ y("line", {
										x1: r,
										y1: i - 1.5,
										x2: a,
										y2: o - 1.5,
										stroke: "#fff1cd",
										strokeWidth: 1.5,
										opacity: .65,
										strokeDasharray: c ? l : void 0,
										strokeDashoffset: c ? l : void 0,
										children: c && /* @__PURE__ */ y("animate", {
											attributeName: "stroke-dashoffset",
											from: l,
											to: "0",
											dur: "0.22s",
											fill: "freeze"
										})
									}),
									c && /* @__PURE__ */ y("line", {
										x1: r,
										y1: i,
										x2: a,
										y2: o,
										stroke: "#fff5c9",
										strokeWidth: 18,
										strokeLinecap: "round",
										opacity: 0,
										children: /* @__PURE__ */ y("animate", {
											attributeName: "opacity",
											values: "0;0;0.85;0",
											keyTimes: "0;0.45;0.65;1",
											dur: "0.44s",
											fill: "freeze"
										})
									})
								]
							}, e);
						}),
						Object.entries(u).map(([e, t]) => {
							let [n, r] = j(e);
							return /* @__PURE__ */ y("g", {
								transform: `translate(${n}, ${r})`,
								children: /* @__PURE__ */ y(ot, {
									city: t.city,
									color: f(t.p)
								})
							}, e);
						}),
						m?.vertices && [...m.vertices].map((e) => {
							let [t, n] = j(e), r = M ? 7 : 14;
							return /* @__PURE__ */ b("g", {
								transform: `translate(${t}, ${n})`,
								pointerEvents: "none",
								children: [/* @__PURE__ */ y("circle", {
									r,
									fill: "#fff8d6",
									fillOpacity: .9,
									stroke: "#237950",
									strokeWidth: M ? 2 : 3
								}), !M && /* @__PURE__ */ y("path", {
									d: "M -5 0 H 5 M 0 -5 V 5",
									stroke: "#237950",
									strokeWidth: 2.5,
									strokeLinecap: "round"
								})]
							}, `sv${e}`);
						}),
						m?.edges && [...m.edges].map((e) => {
							let t = B[e], [n, r] = j(t.v[0]), [i, a] = j(t.v[1]);
							if (h?.kind === "road" && h.key === e) return null;
							let o = N ? .28 : 0, s = 1 - o;
							return /* @__PURE__ */ b("g", {
								pointerEvents: "none",
								children: [/* @__PURE__ */ y("line", {
									x1: n + (i - n) * o,
									y1: r + (a - r) * o,
									x2: n + (i - n) * s,
									y2: r + (a - r) * s,
									stroke: "#237950",
									strokeWidth: N ? 5 : 10,
									strokeLinecap: "round"
								}), /* @__PURE__ */ y("line", {
									x1: n + (i - n) * o,
									y1: r + (a - r) * o,
									x2: n + (i - n) * s,
									y2: r + (a - r) * s,
									stroke: "#fff8d6",
									strokeWidth: N ? 2.5 : 5,
									strokeLinecap: "round"
								})]
							}, `se${e}`);
						}),
						h && h.kind !== "robber" && /* @__PURE__ */ y("g", { children: h.kind === "road" ? (() => {
							let e = B[h.key], [t, n] = j(e.v[0]), [r, i] = j(e.v[1]);
							return /* @__PURE__ */ b("g", {
								pointerEvents: "none",
								strokeLinecap: "round",
								children: [
									/* @__PURE__ */ y("line", {
										x1: t,
										y1: n,
										x2: r,
										y2: i,
										stroke: "#237950",
										strokeWidth: 16,
										opacity: .8
									}),
									/* @__PURE__ */ y("line", {
										x1: t,
										y1: n,
										x2: r,
										y2: i,
										stroke: "#30251e",
										strokeWidth: 11
									}),
									/* @__PURE__ */ y("line", {
										x1: t,
										y1: n,
										x2: r,
										y2: i,
										stroke: g ?? "var(--color-ink)",
										strokeWidth: 7,
										opacity: .75
									})
								]
							});
						})() : (() => {
							let [e, t] = j(h.key);
							return /* @__PURE__ */ b("g", {
								transform: `translate(${e}, ${t})`,
								children: [/* @__PURE__ */ y("circle", {
									r: 19,
									fill: "#fff8d6",
									stroke: "#237950",
									strokeWidth: 3,
									pointerEvents: "none"
								}), /* @__PURE__ */ y(ot, {
									city: h.kind === "city",
									color: g ?? "var(--color-ink)",
									ghost: !0
								})]
							});
						})() }),
						h?.kind === "robber" && /* @__PURE__ */ y("g", {
							transform: `translate(${L(h.key)[0] * 50}, ${L(h.key)[1] * 50 - 24})`,
							opacity: .65,
							pointerEvents: "none",
							children: /* @__PURE__ */ y(at, {})
						})
					]
				})
			]
		})
	});
}
//#endregion
//#region src/game/view-player.tsx
var ct = {
	knight: "games.catan.devKnight",
	vp: "games.catan.devVp",
	monopoly: "games.catan.devMonopoly",
	roadBuilding: "games.catan.devRoadBuilding",
	invention: "games.catan.devInvention"
}, lt = {
	wood: "games.catan.resWood",
	brick: "games.catan.resBrick",
	wool: "games.catan.resWool",
	wheat: "games.catan.resWheat",
	ore: "games.catan.resOre"
}, ut = {
	knight: "🗡️",
	vp: "⭐",
	monopoly: "🫰",
	roadBuilding: "🛣️",
	invention: "🎁"
}, dt = {
	knight: "games.catan.devKnightDesc",
	vp: "games.catan.devVpDesc",
	monopoly: "games.catan.devMonopolyDesc",
	roadBuilding: "games.catan.devRoadBuildingDesc",
	invention: "games.catan.devInventionDesc"
};
function ft({ value: e, className: t = "" }) {
	let [n, r] = c(!1), a = s(e);
	return i(() => {
		if (e > a.current) {
			r(!0), a.current = e;
			let t = window.setTimeout(() => r(!1), 1100);
			return () => window.clearTimeout(t);
		}
		a.current = e;
	}, [e]), /* @__PURE__ */ y("span", {
		className: `${t} ${n ? "catan-count-gain" : ""}`,
		children: e
	});
}
function pt({ kind: e, color: t }) {
	return e === "road" ? /* @__PURE__ */ b("svg", {
		width: "27",
		height: "25",
		viewBox: "0 0 27 25",
		"aria-hidden": !0,
		className: "flex-none",
		children: [/* @__PURE__ */ y("path", {
			d: "M3 18 23 7",
			stroke: "var(--color-ink)",
			strokeWidth: "10",
			strokeLinecap: "round"
		}), /* @__PURE__ */ y("path", {
			d: "M3 18 23 7",
			stroke: t,
			strokeWidth: "6",
			strokeLinecap: "round"
		})]
	}) : e === "dev" ? /* @__PURE__ */ b("svg", {
		width: "27",
		height: "25",
		viewBox: "0 0 27 25",
		"aria-hidden": !0,
		className: "flex-none",
		children: [
			/* @__PURE__ */ y("rect", {
				x: "5",
				y: "2",
				width: "17",
				height: "21",
				rx: "2",
				fill: "#f8e6c2",
				stroke: "var(--color-ink)",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("path", {
				d: "M8 6h11M8 19h11",
				stroke: t,
				strokeWidth: "2"
			}),
			/* @__PURE__ */ y("circle", {
				cx: "13.5",
				cy: "12.5",
				r: "3",
				fill: t
			})
		]
	}) : /* @__PURE__ */ b("svg", {
		width: "27",
		height: "25",
		viewBox: "0 0 27 25",
		"aria-hidden": !0,
		className: "flex-none",
		children: [e === "city" ? /* @__PURE__ */ y("path", {
			d: "M2 22V9L8 3l6 6v13M14 22V7l5-5 6 5v15Z",
			fill: t,
			stroke: "var(--color-ink)",
			strokeWidth: "2",
			strokeLinejoin: "round"
		}) : /* @__PURE__ */ y("path", {
			d: "M3 22V10L13.5 2 24 10v12Z",
			fill: t,
			stroke: "var(--color-ink)",
			strokeWidth: "2",
			strokeLinejoin: "round"
		}), /* @__PURE__ */ y("path", {
			d: "M11 22v-8h5v8",
			fill: "#f8e6c2"
		})]
	});
}
function mt({ counts: e }) {
	let t = p(), n = E.filter((t) => (e[t] ?? 0) > 0).map((n) => `${t(lt[n])} ${e[n]}`).join(", ");
	return /* @__PURE__ */ y("span", {
		role: "img",
		"aria-label": n,
		className: "catan-cost inline-flex items-center gap-0.5",
		children: E.filter((t) => (e[t] ?? 0) > 0).map((t) => /* @__PURE__ */ b("span", {
			className: "inline-flex items-center",
			children: [/* @__PURE__ */ y(Je, {
				resource: t,
				size: 15
			}), (e[t] ?? 0) > 1 && /* @__PURE__ */ b("span", {
				className: "font-mono text-[10px] font-bold tabular-nums",
				children: ["×", e[t]]
			})]
		}, t))
	});
}
function ht(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ y(gt, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
function gt({ pub: e, priv: t, members: n, myRid: r, send: i }) {
	let a = p(), s = f((e) => e.locale), x = e.players.findIndex((e) => e.rid === r), S = t?.hand ?? {}, te = t?.devs ?? [], [C, ne] = c(null), [w, T] = c(null), [re, ie] = c(null), [ae, oe] = c({}), [D, O] = c(null), [se, ue] = c(!1), [N, P] = c(!1), [de, F] = c({}), [I, L] = c({}), [fe, pe] = c(null), [me, he] = c(null), [R, ge] = c(null), [_e, ye] = c(!1), [be, xe] = c(null), [Se, Ce] = c(!1), V = e.turn, { ref: we, hidden: Te } = d(V?.dice ? "dice" : null), U = e.setup, W = e.phase === "play" && V !== null && V.p === x, Ee = e.phase === "setup" && U !== null && e.players[U.order[U.idx]]?.rid === r, G = V?.pendingDiscard.find((e) => e.rid === r) ?? null, De = (V?.pendingDiscard.length ?? 0) > 0, Oe = W && V.pendingRobber && !De, [ke, Ae] = c(""), je = `${e.phase}|${U ? `${U.idx}:${U.stage}` : ""}|${V ? `${V.p}:${V.stage}:${V.pendingRobber}:${+!!V.offer}` : ""}`;
	ke !== je && (Ae(je), ne(null), T(null), ie(null), oe({}), ue(!1), Ce(!1), F({}), L({}), pe(null), he(null));
	let K = (e) => n.find((t) => t.rid === e)?.name ?? e, q = (t) => {
		let r = e.players[t]?.rid, i = n.find((e) => e.rid === r);
		return m[(i?.colorIndex ?? t) % m.length].hex;
	}, J = o(() => {
		if (!(x < 0)) {
			if (e.phase === "setup" && U && Ee) {
				if (U.stage === "settlement") return { vertices: new Set(Object.keys(z).filter((t) => ze(e, x, t, !0))) };
				let t = U.lastVertex;
				return t ? { edges: new Set(z[t].edges.filter((t) => e.roads[t] === void 0)) } : void 0;
			}
			if (e.phase === "play" && V && !De) {
				if (V.pendingRobber) return W ? { hexes: new Set(Array.from({ length: 19 }, (e, t) => t).filter((t) => t !== e.robber)) } : void 0;
				if (W && V.stage === "action") {
					if (V.freeRoads > 0 || C === "road") return { edges: new Set(Object.keys(B).filter((t) => e.roads[t] === void 0 && Re(e, x, t))) };
					if (C === "settlement") return { vertices: new Set(Object.keys(z).filter((t) => ze(e, x, t, !1))) };
					if (C === "city") return { vertices: new Set(Object.entries(e.buildings).filter(([, e]) => e.p === x && !e.city).map(([e]) => e)) };
				}
			}
		}
	}, [
		e,
		x,
		U,
		Ee,
		V,
		De,
		W,
		C
	]), Me = (e) => {
		e.kind === "hex" ? (T({
			kind: "robber",
			key: e.key
		}), ie(null)) : e.kind === "edge" ? T({
			kind: "road",
			key: e.key
		}) : T({
			kind: C === "city" ? "city" : "settlement",
			key: e.key
		});
	}, Ne = w !== null && (w.kind === "robber" && J?.hexes?.has(w.key) === !0 || w.kind === "road" && J?.edges?.has(w.key) === !0 || (w.kind === "settlement" || w.kind === "city") && J?.vertices?.has(w.key) === !0), Pe = o(() => !w || w.kind !== "robber" ? [] : [...new Set(ve(w.key).map((t) => e.buildings[t]?.p).filter((e) => e !== void 0 && e !== x))], [
		w,
		e.buildings,
		x
	]), Fe = () => {
		if (w && Ne) {
			if (w.kind === "robber") {
				if (Pe.length > 0 && !re) return;
				i({
					type: "moveRobber",
					hex: w.key,
					stealFrom: re
				});
			} else e.phase === "setup" ? w.kind === "settlement" ? i({
				type: "placeSettlement",
				vertex: w.key
			}) : w.kind === "road" && i({
				type: "placeRoad",
				edge: w.key
			}) : w.kind === "road" ? i({
				type: "buildRoad",
				edge: w.key
			}) : w.kind === "settlement" ? i({
				type: "buildSettlement",
				vertex: w.key
			}) : w.kind === "city" && i({
				type: "buildCity",
				vertex: w.key
			});
			T(null), ie(null);
		}
	}, Ie = "info", Y = "", Le;
	if (e.phase === "setup" && U) {
		let t = e.players[U.order[U.idx]]?.rid ?? "";
		Ee ? (Ie = "accent", Y = a(U.stage === "settlement" ? "games.catan.setupSettlementYou" : "games.catan.setupRoadYou")) : Y = a("games.catan.setupWait", { name: K(t) });
	} else if (V) {
		let t = e.players[V.p]?.rid ?? "";
		Le = V.dice ? /* @__PURE__ */ y("span", {
			ref: we,
			className: "inline-block",
			style: { visibility: Te ? "hidden" : void 0 },
			children: a("games.catan.diceChip", {
				a: V.dice[0],
				b: V.dice[1]
			})
		}) : void 0, De ? G ? (Ie = "warn", Y = a("games.catan.discardYou", { n: G.need })) : Y = a("games.catan.discardWait", { name: K(V.pendingDiscard[0].rid) }) : V.pendingRobber ? W ? (Ie = "warn", Y = a("games.catan.robberYou")) : Y = a("games.catan.robberWait", { name: K(t) }) : W ? (Ie = "accent", Y = a(V.stage === "roll" ? "games.catan.rollYou" : "games.catan.actionYou")) : Y = a("games.catan.turnWait", { name: K(t) });
	}
	let Be = x >= 0 ? e.players[x].stock : null, Ve = M(S, k) && (Be?.road ?? 0) > 0, He = M(S, A) && (Be?.settlement ?? 0) > 0, Ue = M(S, ce) && (Be?.city ?? 0) > 0 && Object.values(e.buildings).some((e) => e.p === x && !e.city), We = M(S, le) && e.devDeck > 0, X = V?.offer ?? null, Ge = X !== null && X.from !== x && !X.declined.includes(x), Z = e.players.find((e) => e.rid === R), Ke = /* @__PURE__ */ b("div", {
		className: "flex items-stretch gap-1.5",
		children: [/* @__PURE__ */ y("button", {
			type: "button",
			onClick: () => {
				T(null), ie(null);
			},
			className: "btn-quiet min-h-12 flex-none px-4 text-xs font-bold",
			children: a("games.catan.placeCancel")
		}), /* @__PURE__ */ y("button", {
			type: "button",
			disabled: !Ne || w?.kind === "robber" && Pe.length > 0 && !re,
			onClick: Fe,
			className: "btn-base min-h-12 flex-1 text-sm text-white",
			style: { background: H.accent },
			children: w?.kind === "robber" ? a("games.catan.robberConfirm") : a("games.catan.placeConfirm")
		})]
	}), Q = G?.need ?? 0, qe = j(ae), Ye = /* @__PURE__ */ y("div", {
		className: "catan-hand",
		"aria-label": a("games.catan.handAria"),
		children: E.map((e) => {
			let t = S[e] ?? 0, n = ae[e] ?? 0, r = /* @__PURE__ */ b(v, { children: [
				/* @__PURE__ */ y(Je, {
					resource: e,
					size: 22
				}),
				/* @__PURE__ */ y("span", {
					className: "catan-resource-label",
					children: a(lt[e])
				}),
				/* @__PURE__ */ y("span", {
					className: "catan-resource-count font-mono font-bold tabular-nums",
					children: G && n > 0 ? `${n}/${t}` : /* @__PURE__ */ y(ft, { value: t })
				})
			] });
			return G ? /* @__PURE__ */ y("button", {
				type: "button",
				"aria-label": `${a(lt[e])} ${n}/${t}`,
				disabled: t === 0,
				onClick: () => oe((n) => ({
					...n,
					[e]: ((n[e] ?? 0) + 1) % (t + 1)
				})),
				className: `catan-resource catan-resource--button ${n > 0 ? "catan-resource--selected" : ""} ${t === 0 ? "catan-resource--empty" : ""}`,
				children: r
			}, e) : /* @__PURE__ */ y("span", {
				"aria-label": `${a(lt[e])} ${t}`,
				className: `catan-resource ${t === 0 ? "catan-resource--empty" : ""}`,
				children: r
			}, e);
		})
	}), Xe = (e, t) => W && !De && !V.pendingRobber && V.freeRoads === 0 && !V.devPlayed && t && (V.stage === "action" || e === "knight"), $ = be === null ? void 0 : te[be], Ze = !!$ && e.phase === "play" && V !== null && $.card !== "vp" && Xe($.card, $.playable), Qe = "games.catan.devDetailNotTurn";
	$ && (Qe = $.card === "vp" ? "games.catan.devDetailVp" : !V || e.phase !== "play" ? "games.catan.devDetailNotTurn" : De ? "games.catan.devDetailDiscard" : V.pendingRobber ? "games.catan.devDetailRobber" : W ? $.playable ? V.devPlayed ? "games.catan.devDetailPlayed" : V.freeRoads > 0 ? "games.catan.devDetailRoads" : V.stage === "roll" && $.card !== "knight" ? "games.catan.devDetailBeforeRoll" : "games.catan.devDetailReady" : "games.catan.devDetailBought" : "games.catan.devDetailNotTurn");
	let $e = () => {
		if (!$ || !Ze) return;
		let e = $.card;
		Ce(!1), e === "monopoly" || e === "invention" ? (O({
			card: e,
			take: []
		}), ue(!0)) : e !== "vp" && i({
			type: "playDev",
			card: e
		});
	}, et = te.length > 0 && e.phase === "play" && /* @__PURE__ */ y("div", {
		className: "catan-dev-hand pointer-events-auto",
		"aria-label": a("games.catan.devsAria"),
		children: te.map((e, t) => {
			let n = Xe(e.card, e.playable) && e.card !== "vp";
			return /* @__PURE__ */ b("button", {
				type: "button",
				"aria-label": a("games.catan.devInspectAria", { name: a(ct[e.card]) }),
				"aria-haspopup": "dialog",
				onClick: () => {
					xe(t), Ce(!0);
				},
				className: `catan-dev-card ${n ? "catan-dev-card--ready" : "catan-dev-card--held"}`,
				children: [/* @__PURE__ */ y("span", {
					"aria-hidden": !0,
					children: ut[e.card]
				}), a(ct[e.card])]
			}, t);
		})
	}), tt = (e, t, n, r, i) => /* @__PURE__ */ b("button", {
		type: "button",
		"data-resource": e,
		"aria-label": `${a(lt[e])}${t > 0 ? ` ×${t}` : ""}`,
		disabled: i,
		onClick: r,
		className: `catan-trade-chip flex min-h-11 min-w-11 items-center justify-center gap-0.5 border-2 border-ink px-1.5 ${t > 0 ? "catan-trade-chip--selected" : ""} ${i ? "opacity-35" : ""}`,
		children: [
			/* @__PURE__ */ y(Je, {
				resource: e,
				size: 22
			}),
			t > 0 && /* @__PURE__ */ b("span", {
				className: "font-mono text-[11px] font-bold tabular-nums",
				children: ["×", t]
			}),
			n > 0 && t === 0 && /* @__PURE__ */ y("span", {
				className: "font-mono text-[10px] tabular-nums opacity-50",
				children: n
			})
		]
	}, e), nt = j(de) > 0 && j(I) > 0 && M(S, de) && E.every((e) => !((de[e] ?? 0) > 0 && (I[e] ?? 0) > 0)), rt = (t) => {
		if (x < 0) return 4;
		let n = e.players[x].ports, r = 4;
		return n.includes("any") && (r = 3), n.includes(t) && (r = 2), r;
	};
	return /* @__PURE__ */ b(v, { children: [
		/* @__PURE__ */ y(h, {
			adaptive: !0,
			className: "catan-shell",
			scroll: !1,
			children: /* @__PURE__ */ b("div", {
				className: "catan-table",
				children: [/* @__PURE__ */ b("div", {
					className: "catan-board-area",
					children: [/* @__PURE__ */ y("div", {
						className: "catan-board-frame",
						children: /* @__PURE__ */ y(st, {
							terrain: e.terrain,
							discs: e.discs,
							rollTotal: V?.dice ? V.dice[0] + V.dice[1] : null,
							harbors: e.harbors,
							robber: e.robber,
							buildings: e.buildings,
							roads: e.roads,
							colorOf: q,
							spots: J,
							ghost: Ne ? w : null,
							ghostColor: x >= 0 ? q(x) : void 0,
							onTap: J ? Me : void 0
						})
					}), /* @__PURE__ */ y("div", {
						className: "catan-overlays pointer-events-none",
						children: /* @__PURE__ */ b("div", {
							className: "catan-offers pointer-events-none",
							children: [
								Ge && X && /* @__PURE__ */ b("div", {
									className: "catan-offer-card pointer-events-auto flex flex-none flex-wrap items-center gap-2 rounded-xl border-3 border-ink bg-info-soft px-3 py-2 shadow-[2px_2px_0_var(--color-ink)]",
									children: [
										/* @__PURE__ */ y("span", {
											className: "text-xs font-extrabold",
											children: a("games.catan.tradeIncoming", { name: K(e.players[X.from]?.rid ?? "") })
										}),
										/* @__PURE__ */ b("span", {
											className: "flex items-center gap-1 text-xs font-bold",
											children: [
												/* @__PURE__ */ y(mt, { counts: X.give }),
												/* @__PURE__ */ y("span", {
													"aria-hidden": !0,
													children: "⇄"
												}),
												/* @__PURE__ */ y(mt, { counts: X.want })
											]
										}),
										/* @__PURE__ */ b("span", {
											className: "ml-auto flex gap-1.5",
											children: [/* @__PURE__ */ y("button", {
												type: "button",
												disabled: !M(S, X.want),
												onClick: () => i({ type: "acceptTrade" }),
												className: "btn-base min-h-11 px-3 text-xs text-white",
												style: { background: H.accent },
												children: a("games.catan.tradeAccept")
											}), /* @__PURE__ */ y("button", {
												type: "button",
												onClick: () => i({ type: "declineTrade" }),
												className: "btn-quiet min-h-11 px-3 text-xs font-bold",
												children: a("games.catan.tradeDecline")
											})]
										})
									]
								}),
								X && X.from === x && /* @__PURE__ */ b("div", {
									className: "catan-offer-card pointer-events-auto flex flex-none items-center gap-2 rounded-xl border-3 border-ink bg-surface px-3 py-2 shadow-[2px_2px_0_var(--color-ink)]",
									children: [
										/* @__PURE__ */ y("span", {
											className: "text-xs font-extrabold",
											children: a("games.catan.tradeOfferWait")
										}),
										/* @__PURE__ */ b("span", {
											className: "flex items-center gap-1 text-xs font-bold",
											children: [
												/* @__PURE__ */ y(mt, { counts: X.give }),
												/* @__PURE__ */ y("span", {
													"aria-hidden": !0,
													children: "⇄"
												}),
												/* @__PURE__ */ y(mt, { counts: X.want })
											]
										}),
										/* @__PURE__ */ y("button", {
											type: "button",
											onClick: () => i({ type: "cancelTrade" }),
											className: "btn-quiet ml-auto min-h-11 px-3 text-xs font-bold",
											children: a("games.catan.tradeWithdraw")
										})
									]
								}),
								et,
								w && Ne && /* @__PURE__ */ b("div", {
									className: "catan-place-overlay pointer-events-auto",
									children: [/* @__PURE__ */ y("span", {
										className: "catan-place-label",
										children: a("games.catan.placePreview")
									}), Ke]
								})
							]
						})
					})]
				}), /* @__PURE__ */ b("div", {
					className: "catan-sidebar",
					children: [/* @__PURE__ */ b("div", {
						className: "catan-top",
						children: [/* @__PURE__ */ y(g, {
							tone: Ie,
							text: Y,
							chip: Le,
							accent: H.accent
						}), /* @__PURE__ */ y("ul", {
							className: "catan-player-strip",
							children: n.filter((t) => e.players.some((e) => e.rid === t.rid)).map((t) => {
								let n = e.players.find((e) => e.rid === t.rid), i = e.phase === "setup" && U ? e.players[U.order[U.idx]]?.rid === t.rid : !!V && (V.pendingDiscard.some((e) => e.rid === t.rid) || e.players[V.p]?.rid === t.rid);
								return /* @__PURE__ */ y("li", {
									className: "catan-player-slot",
									children: /* @__PURE__ */ b("button", {
										type: "button",
										className: `catan-player-card ${i ? "catan-player-card--active" : ""} ${_e && R === t.rid ? "catan-player-card--picked" : ""}`,
										onClick: () => {
											ge(t.rid), ye(!0);
										},
										"aria-label": `${ee(t, s)} · ${a("games.catan.stripVpAria", { n: n.vp })} · ${a("games.catan.stripResAria", { n: n.resCount })}`,
										children: [/* @__PURE__ */ y(_, {
											m: t,
											myRid: r,
											action: i ? "pending" : null,
											anchorName: `seat:${t.rid}`,
											box: "catan-seat-avatar size-8",
											img: "catan-seat-img size-7"
										}), /* @__PURE__ */ b("span", {
											className: "catan-player-copy",
											children: [/* @__PURE__ */ y("span", {
												className: "catan-player-name",
												children: ee(t, s)
											}), /* @__PURE__ */ b("span", {
												className: "catan-player-stats",
												children: [/* @__PURE__ */ b("span", {
													"aria-hidden": !0,
													children: ["⭐ ", /* @__PURE__ */ y(u, {
														value: n.vp,
														className: "font-mono tabular-nums"
													})]
												}), /* @__PURE__ */ b("span", {
													"aria-hidden": !0,
													children: ["🖐️ ", /* @__PURE__ */ y(ft, {
														value: n.resCount,
														className: "font-mono tabular-nums"
													})]
												})]
											})]
										})]
									})
								}, t.rid);
							})
						})]
					}), /* @__PURE__ */ b("div", {
						className: "catan-dock",
						children: [
							Ye,
							e.phase === "setup" && U && /* @__PURE__ */ b("div", {
								className: "catan-setup-tray",
								children: [
									/* @__PURE__ */ y(pt, {
										kind: U.stage === "settlement" ? "settlement" : "road",
										color: x >= 0 ? q(x) : H.accent
									}),
									/* @__PURE__ */ y("span", {
										className: "font-bold",
										children: a(U.stage === "settlement" ? "games.catan.buildSettlement" : "games.catan.buildRoad")
									}),
									/* @__PURE__ */ y("span", {
										className: "ml-auto text-xs font-bold opacity-70",
										children: Ee ? a("games.catan.placeHint") : a("games.catan.setupWait", { name: K(e.players[U.order[U.idx]]?.rid ?? "") })
									})
								]
							}),
							/* @__PURE__ */ y("div", {
								className: "safe-b flex flex-none flex-col gap-1.5 pb-1",
								children: e.phase === "setup" ? Ee && w ? /* @__PURE__ */ y("div", {
									className: "min-h-12",
									"aria-hidden": !0
								}) : /* @__PURE__ */ y("p", {
									className: "flex min-h-12 items-center justify-center text-xs font-bold opacity-50",
									children: a("games.catan.watchHint")
								}) : G ? /* @__PURE__ */ b("div", {
									className: "flex items-stretch gap-1.5",
									children: [/* @__PURE__ */ y("span", {
										className: "flex min-h-12 flex-1 items-center justify-center rounded-xl text-xs font-extrabold",
										children: a("games.catan.discardPick", {
											sel: qe,
											need: Q
										})
									}), /* @__PURE__ */ y("button", {
										type: "button",
										disabled: qe !== Q,
										onClick: () => {
											i({
												type: "discard",
												cards: ae
											}), oe({});
										},
										className: "btn-base min-h-12 flex-1 text-sm text-white",
										style: { background: H.accent },
										children: a("games.catan.discardConfirm")
									})]
								}) : De ? /* @__PURE__ */ y("p", {
									className: "flex min-h-12 items-center justify-center text-xs font-bold opacity-50",
									children: a("games.catan.watchHint")
								}) : Oe ? w?.kind === "robber" ? /* @__PURE__ */ b("div", {
									className: "catan-robber-tray flex flex-col gap-1.5",
									children: [Pe.length > 0 && /* @__PURE__ */ b("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [/* @__PURE__ */ y("span", {
											className: "text-xs font-extrabold",
											children: a("games.catan.stealPick")
										}), Pe.map((t) => {
											let n = e.players[t].rid;
											return /* @__PURE__ */ y("button", {
												type: "button",
												onClick: () => ie(n),
												className: `min-h-11 rounded-lg border-2 border-ink px-2.5 text-xs font-bold ${re === n ? "bg-warn-soft ring-2 ring-ink" : "bg-surface"}`,
												children: K(n)
											}, t);
										})]
									}), /* @__PURE__ */ y("div", {
										className: "min-h-12",
										"aria-hidden": !0
									})]
								}) : /* @__PURE__ */ y("p", {
									className: "flex min-h-12 items-center justify-center text-xs font-bold opacity-50",
									children: a("games.catan.robberYou")
								}) : W ? V.stage === "roll" ? /* @__PURE__ */ b("button", {
									type: "button",
									onClick: () => i({ type: "roll" }),
									className: "btn-base min-h-12 w-full text-base text-white",
									style: { background: H.accent },
									children: ["🎲 ", a("games.catan.roll")]
								}) : /* @__PURE__ */ b(v, { children: [V.freeRoads > 0 && /* @__PURE__ */ b("div", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ y("span", {
										className: "flex-1 text-xs font-extrabold",
										children: a("games.catan.freeRoads", { n: V.freeRoads })
									}), /* @__PURE__ */ y("button", {
										type: "button",
										onClick: () => i({ type: "cancelRoadBuilding" }),
										className: "btn-quiet min-h-11 px-3 text-xs font-bold",
										children: a("games.catan.freeRoadsCancel")
									})]
								}), V.freeRoads === 0 && /* @__PURE__ */ b(v, { children: [/* @__PURE__ */ b("div", {
									className: "catan-build-row",
									children: [[
										{
											mode: "road",
											label: a("games.catan.buildRoad"),
											cost: k,
											can: Ve
										},
										{
											mode: "settlement",
											label: a("games.catan.buildSettlement"),
											cost: A,
											can: He
										},
										{
											mode: "city",
											label: a("games.catan.buildCity"),
											cost: ce,
											can: Ue
										}
									].map((e) => /* @__PURE__ */ b("button", {
										type: "button",
										disabled: !!w || !e.can,
										onClick: () => ne((t) => t === e.mode ? null : e.mode),
										className: `catan-build-button flex min-h-12 flex-1 items-center justify-center rounded-xl border-3 border-ink text-xs font-extrabold shadow-[2px_2px_0_var(--color-ink)] ${C === e.mode ? "bg-info-soft ring-2 ring-ink" : "bg-surface"} ${e.can ? "" : "opacity-40"}`,
										children: [/* @__PURE__ */ y(pt, {
											kind: e.mode,
											color: x >= 0 ? q(x) : H.accent
										}), /* @__PURE__ */ b("span", {
											className: "flex flex-col items-start",
											children: [/* @__PURE__ */ y("span", { children: e.label }), /* @__PURE__ */ y(mt, { counts: e.cost })]
										})]
									}, e.mode)), /* @__PURE__ */ b("button", {
										type: "button",
										disabled: !!w || !We,
										onClick: () => i({ type: "buyDev" }),
										"aria-label": a("games.catan.devDeckAria", { n: e.devDeck }),
										className: `catan-build-button flex min-h-12 flex-1 items-center justify-center rounded-xl border-3 border-ink bg-surface text-xs font-extrabold shadow-[2px_2px_0_var(--color-ink)] ${We ? "" : "opacity-40"}`,
										children: [/* @__PURE__ */ y(pt, {
											kind: "dev",
											color: H.accent
										}), /* @__PURE__ */ b("span", {
											className: "flex flex-col items-start",
											children: [/* @__PURE__ */ y("span", { children: a("games.catan.buyDev") }), /* @__PURE__ */ y(mt, { counts: le })]
										})]
									})]
								}), /* @__PURE__ */ b("div", {
									className: "flex items-stretch gap-1.5",
									children: [/* @__PURE__ */ y("button", {
										type: "button",
										disabled: !!w,
										onClick: () => P(!0),
										className: "btn-quiet min-h-12 flex-none px-4 text-xs font-bold",
										children: a("games.catan.trade")
									}), /* @__PURE__ */ y("button", {
										type: "button",
										disabled: !!w,
										onClick: () => i({ type: "endTurn" }),
										className: "btn-base min-h-12 flex-1 text-sm text-white",
										style: { background: H.accent },
										children: a("games.catan.endTurn")
									})]
								})] })] }) : /* @__PURE__ */ y("p", {
									className: "flex min-h-12 items-center justify-center text-xs font-bold opacity-50",
									children: a("games.catan.watchHint")
								})
							})
						]
					})]
				})]
			})
		}),
		/* @__PURE__ */ y(l, {
			open: N,
			onClose: () => P(!1),
			label: a("games.catan.trade"),
			children: /* @__PURE__ */ b("div", {
				className: "flex flex-col gap-4 pb-4",
				children: [/* @__PURE__ */ b("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ y("h3", {
							className: "text-sm font-extrabold",
							children: a("games.catan.trade")
						}),
						/* @__PURE__ */ b("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ y("span", {
								className: "w-10 flex-none text-xs font-bold",
								children: a("games.catan.tradeGive")
							}), E.map((e) => tt(e, de[e] ?? 0, S[e] ?? 0, () => F((t) => ({
								...t,
								[e]: ((t[e] ?? 0) + 1) % ((S[e] ?? 0) + 1)
							})), (S[e] ?? 0) === 0 || (I[e] ?? 0) > 0))]
						}),
						/* @__PURE__ */ b("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ y("span", {
								className: "w-10 flex-none text-xs font-bold",
								children: a("games.catan.tradeWant")
							}), E.map((e) => tt(e, I[e] ?? 0, 0, () => L((t) => ({
								...t,
								[e]: ((t[e] ?? 0) + 1) % 4
							})), (de[e] ?? 0) > 0))]
						}),
						/* @__PURE__ */ y("button", {
							type: "button",
							disabled: !nt || X !== null,
							onClick: () => {
								i({
									type: "offerTrade",
									give: de,
									want: I
								}), F({}), L({}), P(!1);
							},
							className: "btn-base min-h-12 text-sm text-white",
							style: { background: H.accent },
							children: a("games.catan.tradeSend")
						})
					]
				}), /* @__PURE__ */ b("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ y("h3", {
							className: "text-sm font-extrabold",
							children: a("games.catan.tradeBank")
						}),
						/* @__PURE__ */ b("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ y("span", {
								className: "w-10 flex-none text-xs font-bold",
								children: a("games.catan.tradeGive")
							}), E.map((e) => {
								let t = rt(e);
								return /* @__PURE__ */ b("button", {
									type: "button",
									"data-resource": e,
									"aria-label": `${a(lt[e])} ${t}:1`,
									disabled: (S[e] ?? 0) < t,
									onClick: () => pe((t) => t === e ? null : e),
									className: `catan-trade-chip flex min-h-11 min-w-11 flex-col items-center justify-center border-2 border-ink px-1 ${fe === e ? "catan-trade-chip--selected" : ""} ${(S[e] ?? 0) < t ? "opacity-35" : ""}`,
									children: [/* @__PURE__ */ y(Je, {
										resource: e,
										size: 20
									}), /* @__PURE__ */ b("span", {
										className: "font-mono text-[10px] font-bold tabular-nums",
										children: [t, ":1"]
									})]
								}, e);
							})]
						}),
						/* @__PURE__ */ b("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ y("span", {
								className: "w-10 flex-none text-xs font-bold",
								children: a("games.catan.tradeWant")
							}), E.map((t) => /* @__PURE__ */ y("button", {
								type: "button",
								"data-resource": t,
								"aria-label": a(lt[t]),
								disabled: e.supply[t] === 0 || fe === t,
								onClick: () => he((e) => e === t ? null : t),
								className: `catan-trade-chip flex min-h-11 min-w-11 items-center justify-center border-2 border-ink px-1 ${me === t ? "catan-trade-chip--selected" : ""} ${e.supply[t] === 0 || fe === t ? "opacity-35" : ""}`,
								children: /* @__PURE__ */ y(Je, {
									resource: t,
									size: 20
								})
							}, t))]
						}),
						/* @__PURE__ */ y("button", {
							type: "button",
							disabled: !fe || !me,
							onClick: () => {
								i({
									type: "bankTrade",
									give: fe,
									get: me
								}), pe(null), he(null);
							},
							className: "btn-base min-h-12 text-sm text-white",
							style: { background: H.accent },
							children: a("games.catan.bankTradeDo")
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ y(l, {
			open: _e,
			onClose: () => ye(!1),
			label: R ? K(R) : a("games.catan.playerDetails"),
			children: Z && /* @__PURE__ */ b("div", {
				className: "flex flex-col gap-3 pb-4",
				children: [
					/* @__PURE__ */ y("h3", {
						className: "font-display text-lg font-extrabold",
						children: K(Z.rid)
					}),
					/* @__PURE__ */ b("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ b("div", {
								className: "plate text-sm font-bold",
								children: ["⭐ ", a("games.catan.stripVpAria", { n: Z.vp })]
							}),
							/* @__PURE__ */ b("div", {
								className: "plate text-sm font-bold",
								children: ["🖐️ ", a("games.catan.stripResAria", { n: Z.resCount })]
							}),
							/* @__PURE__ */ b("div", {
								className: "plate text-sm font-bold",
								children: ["🎴 ", a("games.catan.stripDevAria", { n: Z.devCount })]
							}),
							/* @__PURE__ */ b("div", {
								className: "plate text-sm font-bold",
								children: ["🗡️ ", a("games.catan.stripKnightAria", { n: Z.knights })]
							})
						]
					}),
					(Z.longestRoute || Z.largestArmy) && /* @__PURE__ */ b("div", {
						className: "flex flex-wrap gap-2 text-sm font-bold",
						children: [Z.longestRoute && /* @__PURE__ */ b("span", {
							className: "plate bg-done-soft",
							children: ["🛣️ ", a("games.catan.longestRoute")]
						}), Z.largestArmy && /* @__PURE__ */ b("span", {
							className: "plate bg-done-soft",
							children: ["⚔️ ", a("games.catan.largestArmy")]
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ y(l, {
			open: se,
			onClose: () => ue(!1),
			label: a(D ? ct[D.card] : "games.catan.devsAria"),
			children: D && /* @__PURE__ */ b("div", {
				className: "flex flex-col gap-3 pb-4",
				children: [
					/* @__PURE__ */ y("p", {
						className: "text-sm font-bold",
						children: a(D.card === "monopoly" ? "games.catan.monopolyPick" : "games.catan.inventionPick")
					}),
					/* @__PURE__ */ y("div", {
						className: "grid grid-cols-5 gap-1.5",
						children: E.map((t) => D.card === "monopoly" ? tt(t, 0, 0, () => {
							i({
								type: "playDev",
								card: "monopoly",
								resource: t
							}), ue(!1);
						}, !1) : tt(t, D.take.filter((e) => e === t).length, e.supply[t], () => O((n) => {
							if (!n) return n;
							let r = n.take.filter((e) => e === t).length, i = Math.min(2, e.supply[t]), a = (r + 1) % (i + 1);
							return {
								...n,
								take: [...n.take.filter((e) => e !== t), ...Array(a).fill(t)]
							};
						}), e.supply[t] === 0))
					}),
					D.card === "invention" && /* @__PURE__ */ y("button", {
						type: "button",
						disabled: D.take.length !== 2,
						onClick: () => {
							i({
								type: "playDev",
								card: "invention",
								take: [D.take[0], D.take[1]]
							}), ue(!1);
						},
						className: "btn-base min-h-12 w-full text-sm text-white",
						style: { background: H.accent },
						children: a("games.catan.inventionConfirm")
					})
				]
			})
		}),
		/* @__PURE__ */ y(l, {
			open: Se,
			onClose: () => Ce(!1),
			label: a($ ? ct[$.card] : "games.catan.devsAria"),
			children: $ && /* @__PURE__ */ b("div", {
				className: "flex flex-col gap-3 pb-4",
				children: [
					/* @__PURE__ */ b("div", {
						className: "catan-dev-face",
						"data-card": $.card,
						children: [
							/* @__PURE__ */ b("div", {
								className: "catan-dev-face__band",
								children: [/* @__PURE__ */ y("span", {
									"aria-hidden": !0,
									children: ut[$.card]
								}), /* @__PURE__ */ y("span", { children: a(ct[$.card]) })]
							}),
							/* @__PURE__ */ y("div", {
								className: "catan-dev-face__art",
								"aria-hidden": !0,
								children: ut[$.card]
							}),
							/* @__PURE__ */ y("p", {
								className: "catan-dev-face__text",
								children: a(dt[$.card])
							})
						]
					}),
					/* @__PURE__ */ y("p", {
						className: `catan-dev-status ${Ze ? "catan-dev-status--ready" : ""}`,
						children: a(Qe)
					}),
					Ze && /* @__PURE__ */ y("button", {
						type: "button",
						onClick: $e,
						className: "btn-base min-h-12 w-full text-sm text-white",
						style: { background: H.accent },
						children: a("games.catan.devPlayNow")
					})
				]
			})
		})
	] });
}
//#endregion
//#region src/game/bot.ts
function _t(e) {
	return e[crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0] % e.length];
}
function vt(e, t) {
	let n = 0;
	for (let r of z[t].hexes) {
		let t = e.discs[r];
		t && (n += ue(t));
	}
	return be.forEach((r, i) => {
		B[r].v.includes(t) && (n += e.harbors[i] === "any" ? 1.5 : 2.5);
	}), n;
}
function yt(e, t) {
	return !e.buildings[t] && !ye(t).some((t) => e.buildings[t] !== void 0);
}
function bt(e, t) {
	let n = null;
	for (let r of Object.keys(B)) {
		if (e.roads[r] !== void 0 || !Re(e, t, r)) continue;
		let i = 0;
		for (let t of B[r].v) yt(e, t) && (i = Math.max(i, vt(e, t)));
		(n === null || i > n.score) && (n = {
			edge: r,
			score: i
		});
	}
	return n;
}
function xt(e, t, n, r) {
	if (M(n, r)) return null;
	for (let i of E) if (!((r[i] ?? 0) - (n[i] ?? 0) <= 0 || e.supply[i] <= 0)) for (let a of E) {
		if (a === i) continue;
		let o = Fe({
			buildings: e.buildings,
			harbors: e.harbors
		}, t, a);
		if ((n[a] ?? 0) - (r[a] ?? 0) >= o) return {
			type: "bankTrade",
			give: a,
			get: i
		};
	}
	return null;
}
function St(e, t) {
	let n = e.public, r = e.private?.hand ?? {}, i = e.private?.devs ?? [], a = n.players.findIndex((e) => e.rid === t.rid), o = t.difficulty === "weak";
	if (a < 0 || n.phase === "done") return null;
	if (n.phase === "setup") {
		let e = n.setup;
		if (!e || e.order[e.idx] !== a) return null;
		if (e.stage === "settlement") {
			let e = Object.keys(z).filter((e) => ze(n, a, e, !0));
			return e.length === 0 ? null : (e.sort((e, t) => vt(n, t) - vt(n, e)), { action: {
				type: "placeSettlement",
				vertex: o ? _t(e.slice(0, 3)) : e[0]
			} });
		}
		if (!e.lastVertex) return null;
		let t = z[e.lastVertex].edges.filter((e) => n.roads[e] === void 0);
		if (t.length === 0) return null;
		let r = t.map((t) => {
			let r = B[t].v.find((t) => t !== e.lastVertex);
			return {
				ek: t,
				q: vt(n, r)
			};
		}).sort((e, t) => t.q - e.q);
		return { action: {
			type: "placeRoad",
			edge: o ? _t(r).ek : r[0].ek
		} };
	}
	let s = n.turn;
	if (!s) return null;
	let c = s.pendingDiscard.find((e) => e.rid === t.rid);
	if (c) {
		let e = {}, t = c.need, n = [...E].sort((e, t) => (r[t] ?? 0) - (r[e] ?? 0));
		for (let i of n) {
			let n = Math.min(r[i] ?? 0, t);
			n > 0 && (e[i] = n, t -= n);
		}
		return { action: {
			type: "discard",
			cards: e
		} };
	}
	if (s.pendingDiscard.length > 0) return null;
	if (s.offer && s.offer.from !== a && !s.offer.declined.includes(a)) {
		let e = s.offer, t = E.every((t) => (e.want[t] ?? 0) === 0 || (r[t] ?? 0) >= 3), n = E.some((t) => (e.give[t] ?? 0) > 0 && (r[t] ?? 0) === 0);
		return { action: { type: !o && M(r, e.want) && t && n ? "acceptTrade" : "declineTrade" } };
	}
	if (s.p !== a) return null;
	if (s.pendingRobber) {
		let e = Array.from({ length: 19 }, (e, t) => t).filter((e) => e !== n.robber).map((e) => {
			let t = [...new Set(ve(e).map((e) => n.buildings[e]?.p).filter((e) => e !== void 0 && e !== a))], r = ve(e).some((e) => n.buildings[e]?.p === a), i = n.discs[e];
			return {
				h: e,
				victims: t,
				q: (i ? ue(i) : 0) * (t.length > 0 ? t.length : .2) * (r ? .1 : 1)
			};
		}).sort((e, t) => t.q - e.q), t = o ? _t(e.slice(0, 3)) : e[0], r = [...t.victims].sort((e, t) => n.players[t].vp - n.players[e].vp)[0];
		return { action: {
			type: "moveRobber",
			hex: t.h,
			stealFrom: r === void 0 ? null : n.players[r].rid
		} };
	}
	if (s.producePending) return null;
	let l = (e) => !s.devPlayed && i.some((t) => t.card === e && t.playable);
	if (s.stage === "roll") {
		if (l("knight")) {
			let e = n.discs[n.robber];
			if (ve(n.robber).some((e) => n.buildings[e]?.p === a) && e && ue(e) >= 3) return { action: {
				type: "playDev",
				card: "knight"
			} };
		}
		return { action: { type: "roll" } };
	}
	let u = n.players[a].stock;
	if (s.freeRoads > 0) {
		let e = bt(n, a);
		return e ? { action: {
			type: "buildRoad",
			edge: e.edge
		} } : { action: { type: "cancelRoadBuilding" } };
	}
	if (M(r, ce) && u.city > 0) {
		let e = Object.entries(n.buildings).filter(([, e]) => e.p === a && !e.city).map(([e]) => ({
			vk: e,
			q: vt(n, e)
		})).sort((e, t) => t.q - e.q);
		if (e.length > 0) return { action: {
			type: "buildCity",
			vertex: e[0].vk
		} };
	}
	if (M(r, A) && u.settlement > 0) {
		let e = Object.keys(z).filter((e) => ze(n, a, e, !1));
		if (e.length > 0) return e.sort((e, t) => vt(n, t) - vt(n, e)), { action: {
			type: "buildSettlement",
			vertex: e[0]
		} };
	}
	if (l("roadBuilding") && u.road >= 2 && bt(n, a) !== null) return { action: {
		type: "playDev",
		card: "roadBuilding"
	} };
	if (l("invention")) for (let e of [ce, A]) {
		let t = E.filter((t) => (r[t] ?? 0) < (e[t] ?? 0) && n.supply[t] > 0);
		if (!M(r, e) && t.length >= 1 && t.length <= 2) {
			let e = [t[0], t[1] ?? t[0]];
			if ((n.supply[e[0]] ?? 0) >= (e[0] === e[1] ? 2 : 1)) return { action: {
				type: "playDev",
				card: "invention",
				take: e
			} };
		}
	}
	if (l("monopoly")) {
		let e = null, t = 3;
		for (let i of E) {
			let a = 19 - n.supply[i] - (r[i] ?? 0);
			a > t && (t = a, e = i);
		}
		if (e) return { action: {
			type: "playDev",
			card: "monopoly",
			resource: e
		} };
	}
	if (M(r, k) && u.road > 0) {
		let e = bt(n, a);
		if (e && e.score > 0) return { action: {
			type: "buildRoad",
			edge: e.edge
		} };
	}
	let d = xt(n, a, r, ce) ?? xt(n, a, r, A) ?? (o ? null : xt(n, a, r, le));
	if (d) return { action: d };
	if (!o && M(r, le) && n.devDeck > 0 && j(r) <= 9) return { action: { type: "buyDev" } };
	let f = t.memory ?? {}, p = `${s.p}:${s.dice?.[0] ?? 0},${s.dice?.[1] ?? 0}`;
	if (!o && !s.offer && f.offerKey !== p && j(r) >= 7) for (let e of [A, ce]) {
		let t = E.find((t) => (e[t] ?? 0) - (r[t] ?? 0) === 1);
		if (!t) continue;
		let n = [...E].filter((n) => n !== t && (r[n] ?? 0) - (e[n] ?? 0) >= 2).sort((e, t) => (r[t] ?? 0) - (r[e] ?? 0))[0];
		if (n) return {
			action: {
				type: "offerTrade",
				give: { [n]: 2 },
				want: { [t]: 1 }
			},
			memory: { offerKey: p }
		};
	}
	return { action: { type: "endTurn" } };
}
var Ct = (e, t) => St(e, t), wt = {
	knight: "games.catan.devKnight",
	roadBuilding: "games.catan.devRoadBuilding",
	invention: "games.catan.devInvention",
	monopoly: "games.catan.devMonopoly"
};
function Tt(e) {
	return E.filter((t) => (e[t] ?? 0) > 0).map((t) => `${$[t]}${(e[t] ?? 0) > 1 ? `×${e[t]}` : ""}`).join(" ");
}
var Et = (e, t, n) => {
	switch (e.type) {
		case "placeSettlement":
		case "buildSettlement": return n("games.catan.hintPlaceSettlement");
		case "placeRoad":
		case "buildRoad": return n("games.catan.hintPlaceRoad");
		case "roll": return n("games.catan.roll");
		case "discard": return n("games.catan.hintDiscard", { cards: Tt(e.cards) });
		case "moveRobber": return n(e.stealFrom ? "games.catan.hintRobberSteal" : "games.catan.hintRobber");
		case "buildCity": return n("games.catan.hintBuildCity");
		case "buyDev": return n("games.catan.hintBuyDev");
		case "playDev": return e.card === "monopoly" && e.resource ? n("games.catan.hintMonopoly", { res: $[e.resource] }) : e.card === "invention" && e.take ? n("games.catan.hintInvention", { cards: e.take.map((e) => $[e]).join(" ") }) : n("games.catan.devPlayAria", { name: n(wt[e.card]) });
		case "cancelRoadBuilding": return n("games.catan.hintCancelRoads");
		case "offerTrade": return n("games.catan.hintOffer", {
			give: Tt(e.give),
			want: Tt(e.want)
		});
		case "cancelTrade": return n("games.catan.hintCancelTrade");
		case "acceptTrade": return n("games.catan.hintAcceptTrade");
		case "declineTrade": return n("games.catan.hintDeclineTrade");
		case "bankTrade": return n("games.catan.hintBankTrade", {
			give: $[e.give],
			get: $[e.get]
		});
		case "endTurn": return n("games.catan.endTurn");
		case "tick": return "";
	}
}, Dt = 16, Ot = 36, kt = 6, At = 2;
function jt({ from: e, toX: t, toY: n, ms: r, delay: a, children: o }) {
	let c = s(null);
	return i(() => {
		let i = c.current;
		if (!i) return;
		let o = e.x + e.w / 2, s = e.y + e.h / 2, l = t - o, u = n - s, d = i.animate([
			{
				opacity: 0,
				transform: "translate(-50%, -50%) translate(0px, 0px) scale(.55)"
			},
			{
				opacity: 1,
				transform: "translate(-50%, -50%) translate(0px, 0px) scale(1.12)",
				offset: .12
			},
			{
				opacity: 1,
				transform: `translate(-50%, -50%) translate(${l * .55}px, ${u * .55 - 16}px) scale(1.08)`,
				offset: .66
			},
			{
				opacity: .9,
				transform: `translate(-50%, -50%) translate(${l}px, ${u}px) scale(1)`,
				offset: .9
			},
			{
				opacity: 0,
				transform: `translate(-50%, -50%) translate(${l}px, ${u}px) scale(.9)`
			}
		], {
			duration: r,
			delay: a,
			easing: "cubic-bezier(.3,.7,.3,1)",
			fill: "both"
		});
		return () => d.cancel();
	}, [
		e,
		t,
		n,
		r,
		a
	]), /* @__PURE__ */ y("div", {
		ref: c,
		className: "catan-gain-fly",
		style: {
			left: e.x + e.w / 2,
			top: e.y + e.h / 2
		},
		"aria-hidden": !0,
		children: o
	});
}
var Mt = {
	diceRoll: x(),
	produce(e, t) {
		let n = e.data;
		if (!n?.gains) return null;
		let r = Math.max(2, n.seats ?? 0), i = t.queued > 1 ? .55 : 1, a = Math.round(J.lead * i), o = Math.round(J.flight * i), s = Math.round(J.row * i), c = Math.round(J.hold * i), l = J.exit, u = n.source === "dice" ? t.anchor("dice") : null, d = typeof window > "u" ? 390 : window.innerWidth, f = typeof window > "u" ? 844 : window.innerHeight, p = Math.round(Math.min(170, Math.max(84, d / r - 10))), h = 0, g = [];
		for (let [e, r] of Object.entries(n.gains)) {
			let n = E.filter((e) => (r[e] ?? 0) > 0);
			if (!n.length) continue;
			let i = t.anchor(`seat:${e}`);
			if (!i) continue;
			let _ = 32 + n.length * Ot, ee = Math.round(Math.max(4, Math.min(i.x + i.w / 2 - p / 2, d - p - 4))), v = Math.round(Math.max(4, Math.min(i.y + i.h / 2 - _ / 2, f - _ - 4))), x = t.member(e), S = x ? m[x.colorIndex % m.length].hex : "var(--color-ink)", te = a + (n.length - 1) * s + o + c;
			h = Math.max(h, te + l), u && n.forEach((t, n) => {
				g.push(/* @__PURE__ */ y(jt, {
					from: u,
					toX: ee + p / 2,
					toY: v + At + kt + Dt + n * Ot + Ot / 2,
					ms: o,
					delay: a + n * s,
					children: /* @__PURE__ */ y("span", {
						className: "catan-gain-fly-icon",
						children: /* @__PURE__ */ y(Je, {
							resource: t,
							size: 30
						})
					})
				}, `fly:${e}:${t}:${n}`));
			}), g.push(/* @__PURE__ */ b("div", {
				className: "catan-gain-chip",
				style: {
					left: ee,
					top: v,
					width: p,
					height: _,
					padding: kt,
					animation: `catan-gain-in ${J.chip}ms cubic-bezier(.2,.9,.3,1.3) both, catan-gain-out ${l}ms ease-in ${Math.max(0, te - l)}ms forwards`
				},
				children: [/* @__PURE__ */ b("div", {
					className: "catan-gain-head",
					style: { height: Dt },
					children: [/* @__PURE__ */ y("span", {
						className: "catan-gain-dot",
						style: { background: S }
					}), /* @__PURE__ */ y("span", {
						className: "catan-gain-name",
						children: x?.name ?? ""
					})]
				}), n.map((e, t) => /* @__PURE__ */ b("div", {
					className: "catan-gain-row",
					style: {
						height: Ot,
						animationDelay: `${Math.max(0, u ? a + t * s + o - 90 : a + t * s)}ms`
					},
					children: [/* @__PURE__ */ y(Je, {
						resource: e,
						size: 26
					}), /* @__PURE__ */ b("span", {
						className: "catan-gain-n",
						children: ["+", r[e]]
					})]
				}, e))]
			}, `chip:${e}`));
		}
		return g.length ? {
			ms: h,
			node: /* @__PURE__ */ y(v, { children: g })
		} : null;
	},
	build(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 600
			})
		} : null;
	},
	robber(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 700
			})
		} : null;
	},
	steal(e, t) {
		let n = e.data;
		if (!n?.from || !n?.to) return null;
		let r = t.anchor(`seat:${n.from}`), i = t.anchor(`seat:${n.to}`);
		return !r || !i ? null : {
			ms: 900,
			node: /* @__PURE__ */ y(te, {
				from: r,
				to: i,
				ms: 900,
				children: "🃏"
			})
		};
	},
	offer(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 600
			})
		} : null;
	},
	trade(e, t) {
		let n = e.data, r = n?.a ? t.anchor(`seat:${n.a}`) : null, i = n?.b ? t.anchor(`seat:${n.b}`) : null;
		return !r && !i ? null : {
			ms: 700,
			node: /* @__PURE__ */ b(v, { children: [r && /* @__PURE__ */ y(C, {
				at: r,
				ms: 700
			}), i && /* @__PURE__ */ y(C, {
				at: i,
				ms: 700
			})] })
		};
	},
	devBuy(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 800,
			node: /* @__PURE__ */ y(S, {
				at: n,
				ms: 800,
				children: "🎴+1"
			})
		} : null;
	},
	devPlay(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 700,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 700
			})
		} : null;
	},
	discard(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		if (!n) return null;
		let r = e.data;
		return {
			ms: 900,
			node: /* @__PURE__ */ b(S, {
				at: n,
				ms: 900,
				children: ["🖐️−", r?.n ?? ""]
			})
		};
	},
	bankTrade(e, t) {
		let n = e.rid ? t.anchor(`seat:${e.rid}`) : null;
		return n ? {
			ms: 600,
			node: /* @__PURE__ */ y(C, {
				at: n,
				ms: 600
			})
		} : null;
	}
};
//#endregion
//#region src/game/endgame-review.tsx
function Nt({ board: e, renderResult: t, ...n }) {
	let r = p(), [a, l] = c(!0), [u, d] = c(null), f = s(null), m = s(null), h = s(null);
	i(() => {
		if (!u) return;
		h.current?.focus({ preventScroll: !0 });
		let e = setTimeout(() => d(null), 5e3);
		return () => clearTimeout(e);
	}, [u]);
	let g = (e) => {
		d(null), l(e), requestAnimationFrame(() => (e ? f : m).current?.focus({ preventScroll: !0 }));
	}, _ = o(() => ({
		onPlayAgain: n.onPlayAgain && (() => d({
			run: n.onPlayAgain,
			label: "again"
		})),
		onBackToLobby: n.onBackToLobby && (() => d({
			run: n.onBackToLobby,
			label: "lobby"
		})),
		onPlayAgainWithConfig: n.onPlayAgainWithConfig && ((e) => d({
			run: () => n.onPlayAgainWithConfig(e),
			label: "again"
		}))
	}), [
		n.onPlayAgain,
		n.onBackToLobby,
		n.onPlayAgainWithConfig
	]), ee = {
		...n,
		..._
	};
	return /* @__PURE__ */ b("div", {
		className: "catan-endgame",
		style: { "--endgame-seats": n.result.ranking.length },
		children: [
			/* @__PURE__ */ y("div", {
				className: "catan-endgame-board",
				inert: a,
				children: e
			}),
			/* @__PURE__ */ y("div", {
				className: "catan-endgame-overlay",
				hidden: !a,
				children: /* @__PURE__ */ b("section", {
					role: "dialog",
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), g(!1));
					},
					className: "catan-endgame-panel",
					"aria-label": r("session.result.title"),
					children: [
						/* @__PURE__ */ b("header", {
							className: "catan-endgame-heading",
							children: [/* @__PURE__ */ b("div", {
								className: "catan-endgame-brand",
								children: [/* @__PURE__ */ y("span", {
									"aria-hidden": "true",
									children: H.icon
								}), r(H.nameKey)]
							}), /* @__PURE__ */ y("button", {
								type: "button",
								ref: f,
								className: "btn-quiet",
								"aria-label": r("games.catan.reviewHide"),
								title: r("games.catan.reviewHide"),
								onClick: () => g(!1),
								children: /* @__PURE__ */ y(T, { size: 19 })
							})]
						}),
						/* @__PURE__ */ y("div", {
							className: "catan-endgame-result",
							inert: u !== null,
							children: t(ee)
						}),
						u && /* @__PURE__ */ b("div", {
							className: "catan-endgame-confirm",
							onBlur: (e) => {
								e.currentTarget.contains(e.relatedTarget) || d(null);
							},
							children: [/* @__PURE__ */ y("button", {
								type: "button",
								ref: h,
								className: "btn-base danger-stripes text-white",
								onClick: () => {
									let e = u.run;
									d(null), e();
								},
								children: r(u.label === "again" ? "games.catan.reviewConfirmAgain" : "games.catan.reviewConfirmLobby")
							}), /* @__PURE__ */ y("button", {
								type: "button",
								className: "btn-quiet",
								onClick: () => {
									d(null), f.current?.focus({ preventScroll: !0 });
								},
								children: r("games.catan.reviewCancel")
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ y("div", {
				className: "catan-endgame-toolbar",
				hidden: a,
				children: /* @__PURE__ */ b("button", {
					type: "button",
					className: "btn-base",
					ref: m,
					onClick: () => g(!0),
					children: [
						/* @__PURE__ */ y(re, { size: 18 }),
						r("games.catan.reviewShow"),
						/* @__PURE__ */ y(ne, { size: 18 })
					]
				})
			})
		]
	});
}
function Pt({ result: e, members: t, myRid: n, hintCount: i, onPlayAgain: a, onBackToLobby: o, rows: s, renderRowExtra: l, summary: u, navigation: d, content: m, afterRanking: h, scoreUnit: g, rankOf: _ }) {
	let x = p(), S = f((e) => e.locale), [te, C] = c({}), ne = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? ee(n, S) : e;
	}, re = (t, n) => _?.(t) ?? (e.winner.includes(t) ? 1 : n + 1), E = e.ranking.some((t) => e.scores?.[t] !== void 0), ae = (t, r) => /* @__PURE__ */ b("div", {
		className: "catan-score-identity",
		children: [
			/* @__PURE__ */ b("span", {
				className: "catan-score-place",
				children: [e.winner.includes(t) && /* @__PURE__ */ y("span", {
					"aria-label": x("games.catan.reviewWinner"),
					children: "♛ "
				}), E && re(t, r)]
			}),
			/* @__PURE__ */ b("span", {
				className: "catan-score-name",
				children: [ne(t), t === n && /* @__PURE__ */ y("small", { children: x("lobby.you") })]
			}),
			!!e.autopilot?.[t] && /* @__PURE__ */ b("small", {
				className: "catan-score-autopilot",
				children: [
					/* @__PURE__ */ y(w, { size: 12 }),
					Math.round(e.autopilot[t] * 100),
					"%"
				]
			})
		]
	}), oe = (t) => e.ranking.map((n) => /* @__PURE__ */ y("td", {
		"data-winner": e.winner.includes(n) || void 0,
		children: t.value(n)
	}, n));
	return /* @__PURE__ */ b("div", {
		className: "catan-scorecard",
		children: [
			e.winner.length > 0 && /* @__PURE__ */ y(ie, {}),
			d,
			/* @__PURE__ */ b("div", {
				className: "catan-score-body",
				children: [
					u && /* @__PURE__ */ y("div", {
						className: "catan-score-summary",
						children: u
					}),
					i !== void 0 && /* @__PURE__ */ y("p", {
						className: "catan-score-hints",
						children: x("session.hint.usedCount", { n: i })
					}),
					m ?? (s?.length ? /* @__PURE__ */ y("div", {
						className: "catan-score-table-scroll",
						children: /* @__PURE__ */ b("table", {
							className: "catan-score-table",
							"aria-label": x(H.nameKey),
							children: [
								/* @__PURE__ */ y("thead", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", { scope: "col" }), /* @__PURE__ */ y(v, { children: e.ranking.map((t, n) => /* @__PURE__ */ y("th", {
									scope: "col",
									"data-winner": e.winner.includes(t) || void 0,
									children: ae(t, n)
								}, t)) })] }) }),
								/* @__PURE__ */ y("tbody", { children: s.map((e, t) => /* @__PURE__ */ b(r, { children: [/* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: e.details?.length ? /* @__PURE__ */ b("button", {
										type: "button",
										"aria-expanded": !!te[t],
										onClick: () => C((e) => ({
											...e,
											[t]: !e[t]
										})),
										children: [/* @__PURE__ */ y(T, { size: 15 }), e.label]
									}) : e.label
								}), oe(e)] }), te[t] && e.details?.map((e, t) => /* @__PURE__ */ b("tr", {
									className: "catan-score-sub",
									children: [/* @__PURE__ */ y("th", {
										scope: "row",
										children: e.label
									}), oe(e)]
								}, t))] }, t)) }),
								E && /* @__PURE__ */ y("tfoot", { children: /* @__PURE__ */ b("tr", { children: [/* @__PURE__ */ y("th", {
									scope: "row",
									children: x("games.catan.reviewTotal")
								}), e.ranking.map((t) => /* @__PURE__ */ y("td", {
									"data-winner": e.winner.includes(t) || void 0,
									children: e.scores?.[t] ?? "—"
								}, t))] }) })
							]
						})
					}) : /* @__PURE__ */ y("ol", {
						className: "catan-score-ranking",
						children: e.ranking.map((t, n) => /* @__PURE__ */ b("li", {
							"data-winner": e.winner.includes(t) || void 0,
							children: [/* @__PURE__ */ b("div", {
								className: "catan-score-rankline",
								children: [ae(t, n), e.scores?.[t] !== void 0 && /* @__PURE__ */ b("strong", {
									className: "catan-score-points",
									children: [e.scores[t], g && /* @__PURE__ */ y("small", { children: g })]
								})]
							}), l?.(t)]
						}, t))
					})),
					h,
					!!s?.length && l && /* @__PURE__ */ y("div", {
						className: "catan-score-details",
						children: e.ranking.map((e) => /* @__PURE__ */ b("details", { children: [/* @__PURE__ */ y("summary", { children: ne(e) }), l(e)] }, e))
					})
				]
			}),
			/* @__PURE__ */ b("footer", {
				className: "catan-score-actions",
				children: [
					o && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-quiet",
						onClick: o,
						children: x("session.result.backToLobby")
					}),
					a && /* @__PURE__ */ y("button", {
						type: "button",
						className: "btn-base",
						onClick: a,
						children: x("session.result.playAgain")
					}),
					!a && !o && /* @__PURE__ */ y("p", { children: x("session.result.waitHost") })
				]
			})
		]
	});
}
//#endregion
//#region src/game/game-over.tsx
function Ft({ result: e, members: t, myRid: n, onPlayAgain: r, onBackToLobby: i, hintCount: a }) {
	return /* @__PURE__ */ y(Pt, {
		result: e,
		members: t,
		myRid: n,
		accent: H.accent,
		onPlayAgain: r,
		onBackToLobby: i,
		hintCount: a
	});
}
function It(e) {
	return /* @__PURE__ */ y(Nt, {
		...e,
		board: /* @__PURE__ */ y(ht, {
			public: e.public,
			private: e.private,
			members: e.members,
			myRid: e.myRid,
			send: () => {}
		}),
		renderResult: (e) => /* @__PURE__ */ y(Ft, { ...e })
	});
}
//#endregion
//#region src/index.tsx
var Lt = {
	definition: Ke,
	View: ht,
	bot: Ct,
	describe: Et,
	fx: Mt,
	OverView: It,
	locales: {
		zh: {
			reviewTotal: "总分",
			reviewWinner: "获胜",
			reviewShow: "查看结算",
			reviewHide: "收起结算",
			reviewConfirmAgain: "确认再来一局",
			reviewConfirmLobby: "确认返回大厅",
			reviewCancel: "取消",
			name: "卡坦岛",
			desc: "拓荒、修路、交易,在卡坦岛上建起你的势力",
			rules: "目标:自己回合内率先达到 10 分者立即获胜。\n准备:\n· 版图随机生成:19 块地形按螺旋摆数字碟,红色高产的 6 与 8 永不相邻;沙漠上放强盗。\n· 蛇形开局:先按正序，每人放置1座村庄和1条道路；再按逆序，每人放置第2座村庄和1条道路;第二座村庄立即收获相邻地形的资源。\n· 任何建筑之间至少隔 2 条边(全程生效)。\n流程(每回合):\n· 可先打 1 张骑士,再掷 2 颗骰子;对应数字的地形产出资源,相邻村庄获得 1 张、城市获得 2 张。\n· 掷出 7:不产出;手牌超过 7 张者弃一半(向下取整),随后移动强盗到新地形,并从该地块有建筑的一名玩家手中随机抽取1张资源卡。\n· 行动阶段(任意顺序、不限次数):建造、与银行兑换、向其他玩家发报价,或打出 1 张发展卡(当回合买的不能打)。\n· 建造费用：建造1条道路需要支付1张木材和1张砖块；建造1座村庄需要支付木材、砖块、羊毛和小麦各1张。\n· 将村庄升级为城市需要支付2张小麦和3张矿石；购买1张发展卡需要支付羊毛、小麦和矿石各1张。\n· 与银行按 4:1 兑换;建有港口建筑可 3:1,专属港口 2:1。\n· 新路必须接自家路网,不可穿过对手建筑;新村必须连着自家路。\n交易:\n· 报价是一口价:其他人只能接受或拒绝,不接受还价;不能同种资源互换。\n发展卡:\n· 骑士:移动强盗并从目标玩家手中随机抽取1张资源卡;累计打出 3 张获得「最大军队」2 分,被超过则易主。\n· 修路:免费修 2 条路。\n· 丰收:从银行任取 2 张资源。\n· 垄断:收取其他所有玩家手中全部的该种资源。\n· 胜利点:提供1点隐藏胜利点，获胜时展示。\n计分:\n· 村庄 1 分、城市 2 分;最长连续道路达到 5 条获得 2 分(被对手建筑打断可能失去,平手持有者优先)。\n· 银行每种资源 19 张;某次产出若不足以分配给所有应领取者，该种资源本次不向任何人发放；若只有一名玩家应领取，则由该玩家获得剩余的全部资源卡。",
			errNotPlaying: "对局已结束",
			errNotYourTurn: "还没轮到你",
			errBadVertex: "这里不能建(空位、距离规则、连自家路)",
			errBadEdge: "这里不能修路(必须接自家路网)",
			errCantAfford: "资源不够",
			errNoStock: "对应的棋子/牌用完了",
			errMustDiscard: "先等超牌的玩家弃牌",
			errBadDiscard: "弃牌数量或种类不对",
			errMustRobber: "先移动强盗",
			errNoRobber: "现在不能移动强盗",
			errBadHex: "强盗必须移到新地块",
			errBadSteal: "只能从该地块有建筑的玩家偷",
			errDevPlayed: "本回合已经打过发展卡了",
			errBadDev: "这张发展卡现在不能打",
			errBadTrade: "这笔交易不成立",
			errFreeRoads: "修路卡的免费路还没修完",
			setupSettlementYou: "放置村庄",
			setupRoadYou: "修建道路",
			setupWait: "等 {{name}} 摆放…",
			rollYou: "掷骰子",
			roll: "掷骰子",
			actionYou: "行动",
			turnWait: "等 {{name}} 行动…",
			diceChip: "🎲{{a}}+{{b}}",
			discardYou: "弃 {{n}} 张牌",
			discardWait: "等 {{name}} 弃牌…",
			discardPick: "已选 {{sel}}/{{need}} 张",
			discardConfirm: "弃掉这些",
			robberYou: "移动强盗",
			robberWait: "等 {{name}} 移动强盗…",
			stealPick: "偷谁的?",
			robberConfirm: "就放这里",
			placeConfirm: "确认",
			placeCancel: "取消",
			placeHint: "点亮处可放",
			placePreview: "落点预览",
			endTurn: "结束回合",
			buildRoad: "路",
			buildSettlement: "村",
			buildCity: "城",
			buyDev: "发展卡",
			freeRoads: "修路卡:还可免费修 {{n}} 条",
			freeRoadsCancel: "不修了",
			trade: "交易",
			tradeGive: "我给",
			tradeWant: "我要",
			tradeSend: "发报价",
			tradeOfferWait: "报价已发出,等答复…",
			tradeWithdraw: "撤回",
			tradeIncoming: "{{name}} 的报价",
			tradeAccept: "接受",
			tradeDecline: "拒绝",
			tradeBank: "银行 / 港口",
			bankTradeDo: "兑换",
			devKnight: "骑士",
			devVp: "胜利点",
			devMonopoly: "垄断",
			devRoadBuilding: "修路",
			devInvention: "丰收",
			devKnightDesc: "把强盗移动到另一个地块,并从该地块有建筑的玩家手中随机抽取一张资源牌。累计打出三张骑士后获得「最大军队」,额外得到两分。",
			devVpDesc: "保留在手中,计分时自动提供一点胜利点。只有在获胜时才向其他玩家展示。",
			devMonopolyDesc: "选择一种资源,收取其他所有玩家手中该种资源的全部牌。",
			devRoadBuildingDesc: "免费放置两条道路,不消耗资源。",
			devInventionDesc: "从银行任意拿取两张资源牌。",
			devInspectAria: "查看{{name}}",
			devPlayNow: "打出这张卡",
			devDetailReady: "现在可以打出",
			devDetailVp: "计分时自动计入,不能主动打出",
			devDetailBought: "本回合刚购买,下回合才能打出",
			devDetailPlayed: "本回合已经打出过发展卡",
			devDetailNotTurn: "轮到你时可以打出",
			devDetailDiscard: "先等超出手牌上限的玩家弃牌",
			devDetailRobber: "先移动强盗",
			devDetailRoads: "先放完修路卡提供的免费道路",
			devDetailBeforeRoll: "掷骰后才能打出这张卡",
			devPlayAria: "打出{{name}}",
			monopolyPick: "垄断:选一种资源,收取其他玩家手中全部该资源",
			inventionPick: "丰收:从银行任选 2 张资源",
			inventionConfirm: "获得这 2 张",
			stripVpAria: "{{n}} 分",
			playerDetails: "玩家详情",
			stripResAria: "{{n}} 张资源牌",
			stripDevAria: "{{n}} 张发展卡",
			stripKnightAria: "已打出 {{n}} 张骑士",
			longestRoute: "最长道路",
			largestArmy: "最大军队",
			watchHint: "拖动版图查看,双指缩放",
			handAria: "我的手牌",
			resWood: "木材",
			resBrick: "砖块",
			resWool: "羊毛",
			resWheat: "小麦",
			resOre: "矿石",
			devsAria: "我的发展卡",
			devDeckAria: "发展卡堆剩 {{n}} 张",
			hintPlaceSettlement: "放一个村庄",
			hintPlaceRoad: "修一条路",
			hintDiscard: "弃掉 {{cards}}",
			hintRobber: "移动强盗",
			hintRobberSteal: "移动强盗,并偷一名玩家 1 张牌",
			hintBuildCity: "把一座村庄升级成城市",
			hintBuyDev: "买一张发展卡",
			hintMonopoly: "打出垄断:收取全场的{{res}}",
			hintInvention: "打出丰收:获得 {{cards}}",
			hintCancelRoads: "不修免费路了",
			hintOffer: "发报价:给 {{give}},要 {{want}}",
			hintCancelTrade: "撤回报价",
			hintAcceptTrade: "接受这笔报价",
			hintDeclineTrade: "拒绝这笔报价",
			hintBankTrade: "向银行兑换:{{give}} 换 {{get}}"
		},
		en: {
			reviewTotal: "Total",
			reviewWinner: "Winner",
			reviewShow: "Show results",
			reviewHide: "Hide results",
			reviewConfirmAgain: "Confirm new game",
			reviewConfirmLobby: "Confirm return to lobby",
			reviewCancel: "Cancel",
			name: "CATAN",
			desc: "Settle, build roads, and trade your way across the island",
			rules: "Goal: reach 10 victory points on your own turn to win immediately.\nSetup:\n· The island is generated at random: number discs are placed in a spiral over 19 terrain hexes, and the red high-yield 6s and 8s are never adjacent; the robber starts on the desert.\n· Snake draft: in seat order each player places 1 settlement + 1 road, then in reverse order a second pair; your second settlement immediately yields the resources of its adjacent hexes.\n· Buildings must always be at least two edges apart.\nEach turn:\n· You may play 1 Knight, then roll both dice; hexes with the matching number produce: 1 card per adjacent settlement, 2 per city.\n· On a 7: nothing produces; anyone holding more than 7 cards discards half (rounded down), then you move the robber to a new hex and steal 1 random card from a player with a building there.\n· Action phase (any order, any number of times): build, trade with the supply, make trade offers, or play 1 development card (not one bought this turn).\n· Building costs: a road takes 1 wood and 1 brick; a settlement takes 1 wood, 1 brick, 1 wool and 1 wheat.\n· A city takes 2 wheat and 3 ore (upgrading a settlement); a development card takes 1 wool, 1 wheat and 1 ore.\n· Trade with the supply at 4:1; a generic port gives 3:1, a matching port 2:1.\n· New roads must connect to your network and may not pass through an opponent’s building; new settlements must touch your own road.\nTrading:\n· Offers are take-it-or-leave-it: others may only accept or decline, no counteroffers; trading a resource for itself is not allowed.\nDevelopment cards:\n· Knight: move the robber and steal 1 card; 3 played Knights earn Largest Army (2 VP), lost if surpassed.\n· Road Building: build 2 roads free.\n· Invention: take any 2 resources from the supply.\n· Monopoly: take every card of one resource from all other players.\n· Victory Point: kept hidden, revealed when you win.\nScoring:\n· Settlement 1 VP, city 2 VP; the longest continuous route of at least 5 roads earns 2 VP (it can be lost when an opponent’s building cuts it; ties favor the holder).\n· The supply holds 19 of each resource; if a production roll cannot pay everyone, that resource pays nobody (a lone recipient takes what remains).",
			errNotPlaying: "The game is over",
			errNotYourTurn: "Not your turn yet",
			errBadVertex: "Cannot build here (distance rule / needs your road)",
			errBadEdge: "Cannot build a road here (must connect to your network)",
			errCantAfford: "Not enough resources",
			errNoStock: "No pieces or cards left",
			errMustDiscard: "Waiting for players to discard",
			errBadDiscard: "Wrong cards or count to discard",
			errMustRobber: "Move the robber first",
			errNoRobber: "Cannot move the robber now",
			errBadHex: "The robber must move to a new hex",
			errBadSteal: "Steal from a player with a building on that hex",
			errDevPlayed: "Already played a development card this turn",
			errBadDev: "Cannot play that card now",
			errBadTrade: "That trade is not possible",
			errFreeRoads: "Road Building roads not placed yet",
			setupSettlementYou: "Place a settlement",
			setupRoadYou: "Build a road",
			setupWait: "Waiting for {{name}} to place…",
			rollYou: "Roll dice",
			roll: "Roll dice",
			actionYou: "Act",
			turnWait: "Waiting for {{name}}…",
			diceChip: "🎲{{a}}+{{b}}",
			discardYou: "Discard {{n}}",
			discardWait: "Waiting for {{name}} to discard…",
			discardPick: "Picked {{sel}}/{{need}}",
			discardConfirm: "Discard these",
			robberYou: "Move robber",
			robberWait: "Waiting for {{name}} to move the robber…",
			stealPick: "Steal from whom?",
			robberConfirm: "Put it here",
			placeConfirm: "Confirm",
			placeCancel: "Cancel",
			placeHint: "Place on a lit spot",
			placePreview: "Placement preview",
			endTurn: "End turn",
			buildRoad: "Road",
			buildSettlement: "Settle",
			buildCity: "City",
			buyDev: "Dev card",
			freeRoads: "Road Building: {{n}} free road(s) left",
			freeRoadsCancel: "Stop building",
			trade: "Trade",
			tradeGive: "I give",
			tradeWant: "I want",
			tradeSend: "Send offer",
			tradeOfferWait: "Offer sent, waiting…",
			tradeWithdraw: "Withdraw",
			tradeIncoming: "Offer from {{name}}",
			tradeAccept: "Accept",
			tradeDecline: "Decline",
			tradeBank: "Bank / ports",
			bankTradeDo: "Trade",
			devKnight: "Knight",
			devVp: "Victory Point",
			devMonopoly: "Monopoly",
			devRoadBuilding: "Road Building",
			devInvention: "Invention",
			devKnightDesc: "Move the robber to another hex, then take 1 random resource card from a player with a building there. After playing 3 Knights you gain Largest Army and 2 extra victory points.",
			devVpDesc: "Kept in your hand, it adds 1 victory point to your score. It is shown to the other players only when you win.",
			devMonopolyDesc: "Choose one resource and take every card of that resource from all other players.",
			devRoadBuildingDesc: "Place 2 roads for free without spending resources.",
			devInventionDesc: "Take any 2 resource cards from the supply.",
			devInspectAria: "View {{name}}",
			devPlayNow: "Play this card",
			devDetailReady: "Ready to play now",
			devDetailVp: "Counts toward your score automatically; it cannot be played",
			devDetailBought: "Bought this turn; playable next turn",
			devDetailPlayed: "A development card was already played this turn",
			devDetailNotTurn: "You can play it on your turn",
			devDetailDiscard: "Waiting for players over the hand limit to discard",
			devDetailRobber: "Move the robber first",
			devDetailRoads: "Place the free roads first",
			devDetailBeforeRoll: "Playable after you roll the dice",
			devPlayAria: "Play {{name}}",
			monopolyPick: "Monopoly: pick a resource, take all of it from the other players",
			inventionPick: "Invention: take any 2 resources from the supply",
			inventionConfirm: "Take these 2",
			stripVpAria: "{{n}} victory points",
			playerDetails: "Player details",
			stripResAria: "{{n}} resource cards",
			stripDevAria: "{{n}} development cards",
			stripKnightAria: "{{n}} knights played",
			longestRoute: "Longest Route",
			largestArmy: "Largest Army",
			watchHint: "Drag to pan, pinch to zoom",
			handAria: "My hand",
			resWood: "Wood",
			resBrick: "Brick",
			resWool: "Wool",
			resWheat: "Wheat",
			resOre: "Ore",
			devsAria: "My development cards",
			devDeckAria: "{{n}} development cards left",
			hintPlaceSettlement: "Place a settlement",
			hintPlaceRoad: "Build a road",
			hintDiscard: "Discard {{cards}}",
			hintRobber: "Move the robber",
			hintRobberSteal: "Move the robber and steal 1 card from a player",
			hintBuildCity: "Upgrade a settlement to a city",
			hintBuyDev: "Buy a development card",
			hintMonopoly: "Play Monopoly: take all {{res}}",
			hintInvention: "Play Year of Plenty: take {{cards}}",
			hintCancelRoads: "Skip the free roads",
			hintOffer: "Offer a trade: give {{give}}, want {{want}}",
			hintCancelTrade: "Withdraw the offer",
			hintAcceptTrade: "Accept this offer",
			hintDeclineTrade: "Decline this offer",
			hintBankTrade: "Trade with the bank: {{give}} for {{get}}"
		}
	}
};
//#endregion
export { Lt as default };
