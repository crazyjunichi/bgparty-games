import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useId as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { SheetView as o } from "@bgparty/sdk/sheet-view";
import { useI18nSettings as s } from "@bgparty/sdk/i18n";
import { seatName as c } from "@bgparty/sdk/ui/player-strip";
import { GameScreen as l } from "@bgparty/sdk/ui/game-screen";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { IconCheck as p, IconClose as m, IconMirror as ee, IconRecenter as te, IconRotate as ne } from "@bgparty/sdk/icons";
import { OptionCheckbox as h, OptionRadio as g, OptionSection as _ } from "@bgparty/sdk/ui/game-options";
//#region src/games/railroadink/data.ts
var v = (e, t) => ({
	side: e,
	kind: t
}), y = (e, t, n, r = {}) => ({
	id: e,
	groups: [n.map((e) => v(e, t))],
	...r
}), b = (e, t, n, r, i, a = {}) => ({
	id: e,
	groups: [n.map((e) => v(e, t)), i.map((e) => v(e, r))],
	...a
}), x = (e, t, n, r = {}) => ({
	id: e,
	groups: [[...t.map((e) => v(e, "h")), ...n.map((e) => v(e, "r"))]],
	station: !0,
	...r
}), S = {};
function C(e) {
	return S[e.id] = e, e.id;
}
for (let e of ["h", "r"]) C(y(`${e}I`, e, [0, 2])), C(y(`${e}L`, e, [0, 1])), C(y(`${e}T`, e, [
	0,
	1,
	3
])), C(y(`${e}X`, e, [
	0,
	1,
	2,
	3
])), C(y(`${e}D`, e, [0])), C(b(`${e}B`, e, [0, 1], e, [2, 3]));
C(x("stI", [2], [0])), C(x("stL", [1], [0])), C(x("stH", [0, 2], [3])), C(x("stR", [3], [0, 2])), C(b("over", "h", [0, 2], "r", [1, 3])), C(x("sp0", [
	0,
	1,
	3
], [2])), C(x("sp1", [2], [
	0,
	1,
	3
])), C(y("sp2", "h", [
	0,
	1,
	2,
	3
])), C(y("sp3", "r", [
	0,
	1,
	2,
	3
])), C(x("sp4", [0, 1], [2, 3])), C(x("sp5", [0, 2], [1, 3]));
for (let e of [
	"w",
	"l",
	"v",
	"a",
	"s"
]) C(y(`${e}I`, e, [0, 2], { free: e === "w" || e === "l" || e === "a" })), C(y(`${e}L`, e, [0, 1], { free: e === "w" || e === "l" || e === "a" })), C(y(`${e}T`, e, [
	0,
	1,
	3
], { free: e === "l" })), C(y(`${e}X`, e, [
	0,
	1,
	2,
	3
], { free: e === "l" })), C(y(`${e}D`, e, [0], { free: e === "l" }));
for (let e of ["h", "r"]) {
	C(b(`w${e}`, "w", [0, 2], e, [1, 3], { free: !0 })), C(b(`v${e}`, "v", [3], e, [0, 2])), C({
		id: `pier${e}`,
		groups: [[v(0, e), v(2, "l")]],
		station: !0,
		free: !0
	}), C({
		id: `portal${e}A`,
		groups: [[v(0, e)]],
		mark: "A"
	}), C({
		id: `portal${e}B`,
		groups: [[v(0, e)]],
		mark: "B"
	}), C({
		id: `portal${e}C`,
		groups: [[v(0, e)]],
		mark: "C"
	});
	for (let t of [
		"I",
		"L",
		"T",
		"D"
	]) {
		let n = S[`${e}${t}`];
		C({
			...n,
			id: `tree${e}${t}`,
			mark: "tree",
			free: !0
		}), C({
			...n,
			id: `cactus${e}${t}`,
			mark: "cactus",
			amount: 1,
			free: !0
		}), C({
			...n,
			id: `oasis${e}${t}`,
			mark: "oasis",
			free: !0
		}), C({
			...n,
			id: `sheep${e}${t}`,
			mark: "sheep",
			amount: t === "T" ? 1 : 2,
			free: !0
		}), C({
			...n,
			id: `lamp${e}${t}`,
			mark: "lamp"
		});
	}
}
C({
	id: "pier2",
	groups: [[
		v(0, "h"),
		v(1, "l"),
		v(2, "l"),
		v(3, "r")
	]],
	station: !0,
	free: !0
});
for (let [e, t, n] of [
	[
		"tree",
		"tree",
		1
	],
	[
		"cacti",
		"cactus",
		2
	],
	[
		"ufo",
		"ufo",
		1
	],
	[
		"crater",
		"crater",
		1
	],
	[
		"volcano",
		"volcano",
		1
	],
	[
		"airport",
		"airport",
		1
	],
	[
		"rainbow",
		"rainbow",
		1
	],
	[
		"rain",
		"rain",
		1
	],
	[
		"clover",
		"clover",
		1
	],
	[
		"battery",
		"battery",
		1
	],
	[
		"tower1",
		"tower",
		1
	],
	[
		"tower2",
		"tower",
		2
	],
	[
		"tower3",
		"tower",
		3
	]
]) C({
	id: e,
	groups: [],
	mark: t,
	amount: n,
	free: !0
});
var re = [
	[
		"rL",
		"rT",
		"rI",
		"hL",
		"hT",
		"hI"
	],
	[
		"rL",
		"rT",
		"rI",
		"hL",
		"hT",
		"hI"
	],
	[
		"rL",
		"rT",
		"rI",
		"hL",
		"hT",
		"hI"
	],
	[
		"over",
		"over",
		"stI",
		"stI",
		"stL",
		"stL"
	]
], ie = [
	re[0],
	re[0],
	[
		"hB",
		"rB",
		"rT",
		"hT",
		"over",
		"over"
	],
	[
		"hD",
		"rD",
		"stR",
		"stH",
		"stL",
		"stI"
	]
], w = [
	"sp0",
	"sp1",
	"sp2",
	"sp3",
	"sp4",
	"sp5"
], ae = [
	"none",
	"river",
	"lake",
	"lava",
	"meteor",
	"forest",
	"trail",
	"desert",
	"canyon",
	"tetromino",
	"pluckman",
	"invaders",
	"rainbow",
	"lamps",
	"power",
	"city",
	"super",
	"farmer",
	"ritual",
	"portal",
	"tentacle",
	"investigation",
	"airline",
	"weather",
	"underground"
], oe = {
	river: [[
		"wI",
		"wI",
		"wL",
		"wL",
		"wh",
		"wr"
	], [
		"wI",
		"wI",
		"wL",
		"wL",
		"wh",
		"wr"
	]],
	lake: [[
		"lL",
		"pierr",
		"pierh",
		"lD",
		"lT",
		"pier2"
	], [
		"lL",
		"pierr",
		"pierh",
		"lD",
		"lT",
		"pier2"
	]],
	lava: [[
		"vL",
		"vI",
		"vr",
		"vL",
		"vT",
		"vh"
	], [
		"vL",
		"vI",
		"vr",
		"vL",
		"vT",
		"vh"
	]],
	meteor: [[
		"any",
		"south",
		"east",
		"north",
		"west",
		"any"
	], [
		"1",
		"1",
		"1",
		"2",
		"2",
		"3"
	]],
	forest: [[
		"treerI",
		"treerL",
		"tree",
		"treehL",
		"treehI",
		"tree"
	], [
		"treerI",
		"treerL",
		"tree",
		"treehL",
		"treehI",
		"tree"
	]],
	desert: [[
		"arid",
		"cactusrI",
		"cactusrL",
		"oasishI",
		"oasishL",
		"cacti"
	], [
		"cacti",
		"oasisrI",
		"oasisrL",
		"cactushI",
		"cactushL",
		"arid"
	]],
	portal: [[
		"portalrA",
		"portalhA",
		"portalhB",
		"portalrB",
		"portalhC",
		"portalrC"
	]],
	super: [[
		"superStation",
		"sI",
		"superStation",
		"sT",
		"sL",
		"sI"
	]],
	farmer: [[
		"sheepStationH",
		"sheephD",
		"sheepStationR",
		"sheeprD",
		"ufo",
		"ufo"
	]],
	lamps: [[
		"lamphBridge",
		"lamphX",
		"lamphT",
		"lamphL",
		"lamphI",
		"lamphB"
	], [
		"lamphBridge",
		"lamphX",
		"lamphT",
		"lamphL",
		"lamphI",
		"lamphB"
	]],
	weather: [[
		"cloud",
		"cloud",
		"cloud",
		"snow",
		"storm",
		"storm"
	], [
		"cloud",
		"cloud",
		"cloud",
		"snow",
		"storm",
		"storm"
	]],
	power: [[
		"east",
		"south",
		"west",
		"north",
		"any",
		"any"
	], [
		"east",
		"south",
		"west",
		"north",
		"any",
		"any"
	]],
	city: [[
		"tower1",
		"tower1",
		"tower2",
		"tower2",
		"tower3",
		"tower3"
	], [
		"adjacent",
		"adjacent",
		"adjacent",
		"exits",
		"urban",
		"center"
	]],
	pluckman: [[
		"fruit",
		"pluck",
		"pluck",
		"ghost",
		"ghost",
		"ghost"
	]],
	invaders: [[
		"nuke",
		"attack",
		"attack",
		"alien",
		"alien",
		"alien"
	]],
	rainbow: [[
		"clover",
		"rainbow",
		"rainbow",
		"rainbow",
		"rain",
		"rain"
	]],
	tetromino: [[
		"O",
		"S",
		"Z",
		"L",
		"J",
		"T"
	]],
	tentacle: [[
		"5",
		"5",
		"4",
		"4",
		"3",
		"3"
	]],
	trail: [[
		"trailhT",
		"trailhL",
		"trailhI",
		"trailrT",
		"trailrL",
		"trailrI"
	], [
		"trailhT",
		"trailhL",
		"trailhI",
		"trailrT",
		"trailrL",
		"trailrI"
	]],
	canyon: [[
		"canyon2",
		"canyonL",
		"canyonLongL",
		"canyon1",
		"canyon3",
		"canyonZ"
	], [
		"canyon2",
		"canyonL",
		"canyonLongL",
		"canyon1",
		"canyon3",
		"canyonZ"
	]],
	ritual: [[
		"ritualhSplit",
		"ritualrSplit",
		"ritualrL",
		"ritualhL",
		"ritualrT",
		"ritualhT"
	]],
	investigation: [[
		"clueStationH",
		"cluehI",
		"cluehT",
		"clueStationRT",
		"clueStationRI",
		"clueStationR"
	]],
	airline: [[
		"airport",
		"airport",
		"aL",
		"aL",
		"ar",
		"ah"
	], [
		"airport",
		"airport",
		"aI",
		"aI",
		"adiverger",
		"adivergeh"
	]]
};
C({
	id: "superStation",
	groups: [[
		v(3, "r"),
		v(1, "h"),
		v(2, "s")
	]],
	station: !0
}), C({
	...S.hX,
	id: "lamphX",
	mark: "lamp"
}), C({
	...S.hB,
	id: "lamphB",
	mark: "lamp"
}), C({
	...b("lamphBridge", "h", [0, 2], "h", [1, 3]),
	mark: "lamp"
});
for (let e of ["h", "r"]) {
	for (let t of [
		"L",
		"B",
		"T"
	]) C({
		...S[`${e}${t}`],
		id: `ritual${e}${t}`,
		mark: "ritual",
		free: !0
	});
	C({
		...b(`ritual${e}Split`, e, [1, 3], e, [2]),
		mark: "ritual",
		ritualGroup: 1,
		free: !0
	});
	for (let t of ["I", "T"]) C({
		...S[`${e}${t}`],
		id: `clue${e}${t}`,
		mark: "clue",
		amount: e === "h" ? t === "I" ? 3 : 2 : t === "I" ? 3 : 1
	});
	C(b(`a${e}`, "a", [0, 2], e, [1, 3], { free: !0 })), C(b(`adiverge${e}`, "a", [0, 1], e, [2, 3], { free: !0 }));
}
C({
	...S.stL,
	id: "cluestL",
	mark: "clue",
	amount: 1
}), C({
	...S.stR,
	id: "cluestR",
	mark: "clue",
	amount: 2
}), C({
	...x("clueStationH", [1, 2], [3]),
	mark: "clue",
	amount: 2
}), C({
	...S.rT,
	id: "clueStationRT",
	mark: "clue",
	amount: 1,
	station: !0
}), C({
	...S.rI,
	id: "clueStationRI",
	mark: "clue",
	amount: 3,
	station: !0
}), C({
	...x("clueStationR", [3], [0]),
	mark: "clue",
	amount: 2
}), C({
	...x("sheepStationH", [1, 2], [3]),
	mark: "sheep",
	amount: 1,
	free: !0
}), C({
	...x("sheepStationR", [3], [0, 1]),
	mark: "sheep",
	amount: 2,
	free: !0
}), S.sheeprD.amount = 1;
for (let e of ["h", "r"]) for (let t of [
	"T",
	"L",
	"I"
]) C({
	...S[`${e}${t}`],
	id: `trail${e}${t}`,
	trails: t === "I" ? e === "h" ? [[1], [3]] : [[0], [2]] : t === "L" ? [[
		0,
		2,
		3
	]] : [[2, 3]]
});
S.volcano.groups = [[
	0,
	1,
	2,
	3
].map((e) => v(e, "v"))];
for (let e of ["h", "r"]) for (let t of [
	"I",
	"L",
	"T",
	"B",
	"D",
	"X"
]) C({
	...S[`${e}${t}`],
	id: `u${e}${t}`,
	underground: !0
});
for (let e of [
	"I",
	"L",
	"T",
	"D"
]) C({
	...S[`r${e}`],
	id: `us${e}`,
	station: !0,
	underground: !0
});
C({
	...b("uOver", "h", [0, 2], "r", [1, 3]),
	underground: !0
}), C({
	...b("uBend", "h", [0, 1], "r", [2, 3]),
	underground: !0
}), C({
	...b("uStation", "h", [
		0,
		1,
		2
	], "r", [3]),
	station: !0,
	underground: !0
}), C({
	...b("uSBend", "r", [0, 3], "h", [1, 2]),
	station: !0,
	underground: !0
}), C({
	...b("uPipeD", "h", [3], "r", [
		0,
		1,
		2
	]),
	underground: !0
}), C(b("sepBend", "r", [0, 3], "h", [1, 2])), C({
	id: "sepStations",
	groups: [[v(0, "h"), v(3, "r")], [v(2, "h"), v(1, "r")]],
	station: !0
}), C(b("sepH", "h", [0], "h", [
	1,
	2,
	3
])), C(b("sepR", "r", [0], "r", [
	1,
	2,
	3
]));
var se = [
	[
		"urI",
		"uhI",
		"uhL",
		"urL",
		"urT",
		"uhT"
	],
	[
		"usI",
		"usI",
		"usL",
		"usL",
		"usT",
		"usT"
	],
	[
		"uhI",
		"uhL",
		"uhT",
		"uhI",
		"uhL",
		"uhX"
	],
	[
		"uOver",
		"uBend",
		"uStation",
		"uOver",
		"uSBend",
		"uPipeD"
	]
], ce = [
	"sepBend",
	"sepH",
	"sepStations",
	"sepBend",
	"sepR",
	"sepStations"
], T = [
	"destroy",
	"destroy",
	"move",
	"move",
	"free",
	"free"
], le = [
	"bendH",
	"stationR",
	"overH",
	"bendR",
	"stationH",
	"overR"
], E = {
	O: [
		[0, 0],
		[1, 0],
		[0, 1],
		[1, 1]
	],
	S: [
		[1, 0],
		[2, 0],
		[0, 1],
		[1, 1]
	],
	Z: [
		[0, 0],
		[1, 0],
		[1, 1],
		[2, 1]
	],
	L: [
		[0, 0],
		[0, 1],
		[0, 2],
		[1, 2]
	],
	J: [
		[1, 0],
		[1, 1],
		[1, 2],
		[0, 2]
	],
	T: [
		[0, 0],
		[1, 0],
		[2, 0],
		[1, 1]
	]
}, ue = [
	"river",
	"lake",
	"lava",
	"meteor",
	"forest",
	"trail",
	"desert",
	"rainbow",
	"lamps",
	"super",
	"farmer",
	"ritual",
	"investigation",
	"airline"
];
function D(e, t, n) {
	let r = (e) => ((n ? (4 - e) % 4 : e) + t) % 4;
	return {
		...e,
		groups: e.groups.map((e) => e.map((e) => ({
			...e,
			side: r(e.side)
		}))),
		trails: e.trails?.map((e) => e.map((e) => ((n ? (5 - e) % 4 : e) + t) % 4))
	};
}
function O(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < 2; r++) for (let i = 0; i < 4; i++) {
		let a = D(S[e], i, !!r), o = de(a);
		t.has(o) || (t.add(o), n.push({
			rotation: i,
			mirror: !!r,
			piece: a
		}));
	}
	return n;
}
function de(e) {
	return JSON.stringify(e.groups.map((t, n) => [t.map((e) => `${e.kind}${e.side}`).sort(), e.mark === "ritual" && n === (e.ritualGroup ?? 0)]).sort()) + JSON.stringify(e.trails?.map((e) => e.slice().sort()).sort());
}
//#endregion
//#region src/games/railroadink/score.ts
function k(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map(), r = (e, t) => {
		n.set(e, [...n.get(e) ?? [], t]), n.set(t, [...n.get(t) ?? [], e]);
	};
	e.forEach((e, n) => {
		let i = R(e);
		if (i) for (let e of i.trails ?? []) {
			let i = e.map((e) => q(n, e));
			for (let e of i) t.set(e, /* @__PURE__ */ new Set([...t.get(e) ?? [], n])), e !== i[0] && r(i[0], e);
		}
	}), e.forEach((e, n) => {
		if (!R(e)?.station) return;
		let i = [
			0,
			1,
			2,
			3
		].map((e) => q(n, e)).filter((e) => t.has(e));
		for (let e of i) r(i[0], e), t.get(e)?.add(n);
	});
	let i = /* @__PURE__ */ new Set(), a = 0;
	for (let r of t.keys()) {
		if (i.has(r)) continue;
		let o = [r], s = /* @__PURE__ */ new Set();
		i.add(r);
		for (let r = 0; r < o.length; r++) {
			for (let n of t.get(o[r]) ?? []) R(e[n])?.station && s.add(n);
			for (let e of n.get(o[r]) ?? []) i.has(e) || (i.add(e), o.push(e));
		}
		a += Math.floor(W(Math.min(12, s.size)) / 2);
	}
	return a;
}
var A = (e, t) => `${Math.min(e, t)}:${Math.max(e, t)}`;
function j(e) {
	let t = e % 7, n = Math.floor(e / 7) * 8 + t;
	return [
		A(n, n + 1),
		A(n + 1, n + 9),
		A(n + 8, n + 9),
		A(n, n + 8)
	];
}
var fe = (e) => e % 8 == 0 || e % 8 == 7 || e < 8 || e >= 56;
function pe(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) for (let e = 1; e < n.length; e++) {
		let r = n[e - 1], i = n[e];
		t.set(r, [.../* @__PURE__ */ new Set([...t.get(r) ?? [], i])]), t.set(i, [.../* @__PURE__ */ new Set([...t.get(i) ?? [], r])]);
	}
	let n = 0, r = 0, i = /* @__PURE__ */ new Set();
	for (let e of t.keys()) {
		if (i.has(e)) continue;
		let a = [e];
		i.add(e);
		for (let e = 0; e < a.length; e++) for (let n of t.get(a[e]) ?? []) i.has(n) || (i.add(n), a.push(n));
		let o = a.reduce((e, n) => e + (t.get(n)?.length ?? 0), 0) / 2;
		n = Math.max(n, o);
		let s = a.filter((e) => t.get(e)?.length === 1);
		s.length === 2 && s.every(fe) && (r += 2);
	}
	return n + r;
}
function me(e, t, n = !1) {
	if (t.expansion === "underground" && t.undergroundSolo && !n) return me(e, t, !0);
	let r = n ? e.under : e.cells, i = G(r), a = K(i), o = 0, s = 0;
	for (let c of a) {
		let a = [...new Set(c.flatMap((e) => i[e].exits))];
		if (!c.some((e) => H({
			id: "",
			groups: [i[e].ports]
		}))) continue;
		let l = new Set(c.filter((e) => {
			let t = R(r[i[e].cell]);
			return t?.mark === "ritual" && i[e].group === (t.ritualGroup ?? 0);
		}).map((e) => i[e].cell)).size, u = e.ritualPortals.filter((e) => {
			let [t, n] = e.split(":").map(Number);
			return c.some((e) => i[e].cell === t && i[e].ports.some((e) => e.side === n));
		}).length;
		if (!n && t.expansion === "ritual" && (l || u) ? s += W(l + u) : o += W(a.length + (n ? new Set(c.filter((e) => r[i[e].cell]?.hub && i[e].ports.some((e) => e.kind === "r")).map((e) => i[e].cell)).size : 0)), !n && t.expansion === "pluckman") {
			let t = a.map((t) => e.exitMarks[t]);
			t.includes("pluck") && (s += 3 + t.filter((e) => e === "ghost").length * (t.includes("fruit") ? 2 : -2));
		}
	}
	let c = Ce(r, "h", t.challenge), l = Ce(r, "r", t.challenge), u = r.filter((e, t) => e && t % 7 >= 2 && t % 7 <= 4 && t >= 14 && t < 35).length, d = J(r, n ? "underground" : t.expansion), f = (e) => r.flatMap((t, n) => R(t)?.mark === e ? [n] : []);
	if (n) c *= 2;
	else switch (t.expansion) {
		case "river": {
			let e = G(r, "w");
			s = Math.max(0, ...K(e).map((t) => t.length + (t.reduce((t, n) => t + e[n].ports.filter((t) => F(e[n].cell, t.side) < 0).length, 0) === 2 ? 3 : 0)));
			break;
		}
		case "lake": {
			let e = G(r, "l"), t = K(e).map((t) => new Set(t.map((t) => e[t].cell)).size);
			s = t.length ? Math.min(...t) : 0;
			break;
		}
		case "lava": {
			let e = G(r, "v"), t = K(e);
			s = Math.max(0, ...t.map((e) => e.length)) + t.filter((t) => t.every((t) => e[t].ports.every((n) => F(e[t].cell, n.side) < 0 || B(R(r[F(e[t].cell, n.side)]), M[n.side]).includes("v")))).length * 5;
			break;
		}
		case "meteor":
			r.forEach((e, t) => {
				for (let n of R(e)?.groups.flat() ?? []) [
					"h",
					"r",
					"s"
				].includes(n.kind) && R(r[F(t, n.side)])?.mark === "crater" && (s += 2);
			});
			break;
		case "forest": {
			let e = we(r, (e) => R(e)?.mark === "tree").map((e) => e.length).sort((e, t) => t - e);
			s = (e[0] ?? 0) * 2 + (e[1] ?? 0);
			break;
		}
		case "trail":
			s = k(r);
			break;
		case "desert":
			s = r.reduce((e, t) => e + (t?.cacti ?? 0), 0);
			break;
		case "canyon":
			s = pe(e.canyons);
			break;
		case "lamps":
			s = r.filter((e) => e?.lit).length;
			break;
		case "farmer":
			s = f("ufo").reduce((e, t) => e + r.reduce((e, n, r) => e + (R(n)?.mark === "sheep" && (t % 7 == r % 7 || Math.floor(t / 7) === Math.floor(r / 7)) ? (R(n)?.amount ?? 0) * 2 : 0), 0), 0);
			break;
		case "city":
			s = r.reduce((e, t) => e + (R(t)?.mark === "tower" ? R(t)?.amount ?? 0 : 0), 0);
			break;
		case "tetromino":
			s = e.enhanced.reduce((e, t) => e + (r[t] ? 1 : -1), 0);
			break;
		case "invaders":
			s = -e.aliens.length;
			break;
		case "rainbow":
			s = f("rainbow").reduce((e, t) => e + I(t).filter((e) => R(r[e])?.mark === "clover").length * 2, 0);
			break;
		case "weather":
			for (let e of [
				"cloud",
				"storm",
				"snow"
			]) {
				let t = we(r, (t) => t?.weather === e).filter((t) => t.every((t) => {
					for (let n = -1; n <= 1; n++) for (let i = -1; i <= 1; i++) {
						let a = t % 7 + i, o = Math.floor(t / 7) + n;
						if (a >= 0 && a < 7 && o >= 0 && o < 7) {
							let t = r[o * 7 + a]?.weather;
							if (t && t !== e) return !1;
						}
					}
					return !0;
				}));
				s += Math.max(0, ...t.map((e) => e.length));
			}
			break;
		case "investigation":
			s = e.cluesCollected + (e.cluesCollected === e.cluesDrawn ? 4 : 0);
			break;
		case "tentacle":
			s = e.tentacles.length * 2 + [...new Set(e.tentacles.flat())].filter((e) => H(R(r[e]))).length;
			break;
		case "airline":
			s = Ce(r, "a", t.challenge, !0) * 2;
			break;
		case "underground":
			s = me(e, t, !0).total;
			break;
		case "power": {
			let t = we(r, (e) => !!e?.powered || R(e)?.mark === "battery").find((e) => e.includes(24)) ?? [];
			s = e.charge * N.filter((e) => t.includes(e.cell)).length;
			break;
		}
	}
	let p = n ? 0 : [
		0,
		1,
		2,
		4,
		6
	][Math.min(4, e.villages)], m = n ? 0 : e.goals.reduce((e, t) => e + Math.max(0, t), 0);
	return {
		network: o,
		highway: c,
		railway: l,
		center: u,
		errors: d,
		expansion: s,
		villages: p,
		goals: m,
		total: o + c + l + u - d + s + p + m
	};
}
function he(e) {
	let t = G(e.cells);
	return K(t).map((e) => [...new Set(e.flatMap((e) => t[e].exits))]);
}
function ge(e, t) {
	if (t === "exits") return Math.max(0, ...he(e).map((e) => e.length));
	if (t === "center") return e.cells.filter((e, t) => e && t % 7 >= 2 && t % 7 <= 4 && t >= 14 && t < 35).length;
	if (t === "urban") return 2 + e.cells.filter((e) => R(e)?.mark === "tower").length;
	let n = G(e.cells.map((t, n) => t && t.round !== e.roundStart[n]?.round ? t : null));
	return Math.max(0, ...K(n).map((e) => new Set(e.map((e) => n[e].cell)).size));
}
function _e(e) {
	let t = G(e.cells), n = /* @__PURE__ */ new Set(), r = e.investigator < 0 ? N[-e.investigator - 1] : null, i = t.flatMap((t, n) => r ? t.cell === r.cell && t.ports.some((e) => e.side === r.side && e.kind === r.kind) ? [n] : [] : t.cell === e.investigator ? [n] : []);
	for (let a of i) {
		let i = t[a];
		if (!r || r.kind === "h") {
			if (r) n.add(i.cell);
			else for (let t of i.ports.filter((e) => e.kind === "h")) {
				let r = F(i.cell, t.side);
				B(R(e.cells[r]), M[t.side]).includes("h") && n.add(r);
			}
		}
		if ((r?.kind === "r" || !r && z(R(e.cells[i.cell]), i.group)) && i.ports.some((e) => e.kind === "r")) {
			let i = /* @__PURE__ */ new Set(), o = [a];
			for (let s = 0; s < o.length; s++) {
				let c = o[s];
				if (!i.has(c)) {
					if (i.add(c), (c !== a || r) && z(R(e.cells[t[c].cell]), t[c].group)) {
						n.add(t[c].cell);
						continue;
					}
					for (let e of t[c].ports.filter((e) => e.kind === "r")) {
						let n = F(t[c].cell, e.side);
						for (let r = 0; r < t.length; r++) t[r].cell === n && t[r].ports.some((t) => t.kind === "r" && t.side === M[e.side]) && o.push(r);
					}
				}
			}
		}
	}
	return [...n].filter((t) => t !== e.investigator);
}
//#endregion
//#region src/games/railroadink/board.ts
var M = [
	2,
	3,
	0,
	1
], ve = [
	0,
	1,
	0,
	-1
], ye = [
	-1,
	0,
	1,
	0
], N = Array.from({ length: 4 }, (e, t) => [
	1,
	3,
	5
].map((e, n) => ({
	side: t,
	cell: t === 0 ? e : t === 1 ? e * 7 + 6 : t === 2 ? 42 + e : e * 7,
	kind: t % 2 == 0 == (n % 2 == 0) ? "h" : "r"
}))).flat(), P = {
	0: "factory",
	2: "village",
	12: "village",
	14: "university",
	18: "university",
	24: "village",
	29: "university",
	34: "factory",
	37: "factory",
	39: "village",
	48: "university"
};
function F(e, t) {
	let n = e % 7 + ve[t], r = Math.floor(e / 7) + ye[t];
	return n < 0 || r < 0 || n >= 7 || r >= 7 ? -1 : r * 7 + n;
}
function I(e) {
	return [
		0,
		1,
		2,
		3
	].map((t) => F(e, t)).filter((e) => e >= 0);
}
function L(e, t) {
	return [
		0,
		1,
		2,
		3
	].find((n) => F(e, n) === t) ?? -1;
}
function R(e) {
	if (!e || !S[e.id]) return null;
	let t = D(S[e.id], e.rotation, e.mirror);
	return {
		...t,
		...e.groups ? {
			groups: e.groups,
			stationGroups: t.stationGroups ?? (t.station ? t.groups.map((e, t) => t) : [])
		} : {},
		...e.station === void 0 ? {} : { station: e.station }
	};
}
function z(e, t) {
	return !!e?.station && (!e.stationGroups || e.stationGroups.includes(t));
}
function B(e, t) {
	return e?.groups.flat().filter((e) => e.side === t).map((e) => e.kind) ?? [];
}
function V(e, t) {
	return e === t || e === "s" && (t === "h" || t === "r") || t === "s" && (e === "h" || e === "r");
}
function H(e) {
	return !!e?.groups.flat().some((e) => [
		"h",
		"r",
		"s"
	].includes(e.kind));
}
function be() {
	return {
		cells: Array(49).fill(null),
		under: Array(49).fill(null),
		used: [],
		specials: [],
		regularSpecials: 0,
		specialRound: !1,
		done: !1,
		stage: "draw",
		expUsed: [],
		weatherUsed: [],
		coins: 0,
		charge: 0,
		villages: 0,
		universities: 0,
		duplications: 0,
		freeSpecial: 0,
		factory: 0,
		meteor: 24,
		investigator: -1,
		movement: 0,
		enhanced: [],
		aliens: [],
		exitMarks: {},
		ritualPortals: [],
		tentacles: [],
		canyons: [],
		bridges: [],
		goals: [],
		roundStart: Array(49).fill(null),
		incomePaid: !1,
		constructionUsed: !1,
		renovationUsed: !1,
		freePlacement: !1,
		underDuplicate: !1,
		pendingLamp: 0,
		setupLeft: 0,
		cluesCollected: 0,
		cluesDrawn: 0,
		effects: [],
		last: null
	};
}
function xe(e, t, n, r = !1, i = !1) {
	let a = i ? e.under : e.cells;
	if (n < 0 || n >= 49 || a[n] && a[n]?.id !== "crater" || !i && (e.tentacles.some((e) => e.includes(n)) || e.aliens.some((e) => e.cell === n && e.shield)) || t.mark && [
		"A",
		"B",
		"C"
	].includes(t.mark) && a.filter((e) => R(e)?.mark === t.mark).length >= 2 || t.mark === "rainbow" && I(n).some((e) => R(a[e])?.mark === "rainbow")) return !1;
	let o = r || !!t.free || t.groups.length === 0;
	for (let e = 0; e < 4; e++) {
		let r = B(t, e), i = F(n, e);
		if (i < 0) {
			let t = N.find((t) => t.cell === n && t.side === e);
			if (t && r.length) {
				if (!r.some((e) => V(e, t.kind))) return !1;
				o = !0;
			}
			continue;
		}
		let s = R(a[i]), c = B(s, M[e]);
		if (["airport", "rainbow"].includes(s?.mark ?? "")) {
			r.some((e) => [
				"h",
				"r",
				"s",
				"a"
			].includes(e)) && (o = !0);
			continue;
		}
		if (["airport", "rainbow"].includes(t.mark ?? "")) {
			c.some((e) => [
				"h",
				"r",
				"s",
				"a"
			].includes(e)) && (o = !0);
			continue;
		}
		if (r.length && c.length) {
			if (!r.some((e) => c.some((t) => V(e, t)))) return !1;
			o = !0;
		}
	}
	return t.groups.flat().some((e) => e.kind === "v") && t.mark !== "volcano" && (o = [
		0,
		1,
		2,
		3
	].some((e) => B(t, e).includes("v") && B(R(a[F(n, e)]), M[e]).includes("v"))), t.trails && (o ||= Te(a, n, t.trails.flat())), o;
}
function Se(e, t, n, r, i, a = !1, o = !1) {
	return !!S[t] && xe(e, D(S[t], r, i), n, a, o);
}
function U(e, t, n = !1, r = !1) {
	if (!S[t]) return [];
	let i = [];
	for (let a of O(t)) for (let t = 0; t < 49; t++) xe(e, a.piece, t, n, r) && i.push({
		cell: t,
		rotation: a.rotation,
		mirror: a.mirror
	});
	return i;
}
function W(e) {
	return e < 2 ? 0 : e >= 12 ? 45 + (e - 12) * 5 : 4 * (e - 1);
}
function G(e, t) {
	let n = [], r = /* @__PURE__ */ new Map();
	e.forEach((e, i) => {
		let a = R(e);
		a && (["airport", "rainbow"].includes(a.mark ?? "") && (!t || a.mark === "airport") ? [[
			0,
			1,
			2,
			3
		].flatMap((e) => (t ? [t] : [
			"h",
			"r",
			"a"
		]).map((t) => ({
			side: e,
			kind: t
		})))] : a.groups).forEach((e, a) => {
			let o = t ? e.filter((e) => V(e.kind, t)) : e;
			if (!o.length) return;
			let s = n.length;
			n.push({
				cell: i,
				group: a,
				ports: o,
				next: [],
				exits: []
			}), r.set(i, [...r.get(i) ?? [], s]);
		});
	});
	let i = (e, t) => {
		e !== t && (n[e].next.includes(t) || n[e].next.push(t), n[t].next.includes(e) || n[t].next.push(e));
	};
	if (n.forEach((t, a) => {
		for (let o of t.ports) {
			let s = F(t.cell, o.side);
			if (s < 0) {
				N.forEach((n, r) => {
					!["airport", "rainbow"].includes(R(e[t.cell])?.mark ?? "") && n.cell === t.cell && n.side === o.side && V(o.kind, n.kind) && !t.exits.includes(r) && t.exits.push(r);
				});
				continue;
			}
			for (let e of r.get(s) ?? []) n[e].ports.some((e) => e.side === M[o.side] && V(e.kind, o.kind)) && i(a, e);
		}
	}), !t || t === "h" || t === "r" || t === "s") for (let t of [
		"A",
		"B",
		"C"
	]) {
		let r = n.flatMap((n, r) => R(e[n.cell])?.mark === t ? [r] : []);
		r.length === 2 && i(r[0], r[1]);
	}
	return n;
}
function K(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r++) {
		if (t.has(r)) continue;
		let i = [r];
		t.add(r);
		for (let n = 0; n < i.length; n++) for (let r of e[i[n]].next) t.has(r) || (t.add(r), i.push(r));
		n.push(i);
	}
	return n;
}
function Ce(e, t, n = !1, r = !1) {
	let i = G(e, t), a = i.length;
	if ((t === "h" || t === "r") && e.some((e) => [
		"A",
		"B",
		"C"
	].includes(R(e)?.mark ?? ""))) {
		let n = G(e, t === "h" ? "r" : "h"), r = i.length;
		i.push(...n.map((e) => ({
			...e,
			next: e.next.map((e) => e + r)
		})));
		for (let t of [
			"A",
			"B",
			"C"
		]) {
			let n = i.flatMap((n, r) => R(e[n.cell])?.mark === t ? [r] : []);
			n.length === 2 && !i[n[0]].next.includes(n[1]) && (i[n[0]].next.push(n[1]), i[n[1]].next.push(n[0]));
		}
	}
	let o = 0, s = [...new Set(i.map((e) => `${e.cell}:${e.group}`))], c = i.map((e) => 1n << BigInt(n ? s.indexOf(`${e.cell}:${e.group}`) : e.cell)), l = (t) => !r || R(e[i[t].cell])?.mark === "airport" || i[t].ports.some((e) => F(i[t].cell, e.side) < 0);
	for (let e of K(i)) {
		let t = new Set(e.map((e) => c[e])).size;
		if (t <= o) continue;
		let n = /* @__PURE__ */ new Map(), r = (e, a, s) => {
			if (l(e) && (o = Math.max(o, s)), o >= t) return;
			let u = `${e}:${a}`;
			if ((n.get(u) ?? 0) >= s) return;
			n.set(u, s);
			let d = /* @__PURE__ */ new Set([e]), f = [e], p = 0n;
			for (let e = 0; e < f.length; e++) for (let t of i[f[e]].next) !(a & c[t]) && !d.has(t) && (d.add(t), f.push(t), p |= c[t]);
			let m = 0;
			for (let e = p; e; e &= e - 1n) m++;
			if (!(s + m <= o)) for (let t of i[e].next) a & c[t] || r(t, a | c[t], s + 1);
		};
		for (let t of e) t < a && l(t) && r(t, c[t], 1);
	}
	return o;
}
function we(e, t) {
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i = 0; i < 49; i++) if (t(e[i]) && !n.has(i)) {
		let a = [i];
		n.add(i);
		for (let r = 0; r < a.length; r++) for (let i of I(a[r])) !n.has(i) && t(e[i]) && (n.add(i), a.push(i));
		r.push(a);
	}
	return r;
}
function q(e, t) {
	return (Math.floor(e / 7) + +(t >= 2)) * 8 + e % 7 + +(t === 1 || t === 2);
}
function Te(e, t, n) {
	let r = n.map((e) => q(t, e));
	return e.some((e, n) => n !== t && (R(e)?.trails?.flat().some((e) => r.includes(q(n, e))) || R(e)?.station && [
		0,
		1,
		2,
		3
	].some((e) => r.includes(q(n, e)))));
}
function J(e, t) {
	let n = 0;
	return e.forEach((r, i) => {
		let a = R(r);
		if (a) {
			for (let t of a.groups.flat()) {
				let r = F(i, t.side);
				if (r < 0 || t.kind === "l") continue;
				let a = R(e[r]), o = a?.mark;
				[
					"h",
					"r",
					"s"
				].includes(t.kind) && [
					"crater",
					"tower",
					"rain",
					"clover",
					"airport",
					"rainbow",
					"battery"
				].includes(o ?? "") || (t.kind !== "a" || o !== "airport") && (B(a, M[t.side]).some((e) => V(e, t.kind)) || (n += t.kind === "a" ? 2 : 1));
			}
			a.mark === "airport" && !I(i).some((t) => B(R(e[t]), L(t, i)).includes("a")) && (n += 4), t === "underground" && r?.broken && (n += 2);
		}
	}), n;
}
//#endregion
//#region src/games/railroadink/schema.ts
var Ee = t.object({
	challenge: t.boolean().default(!1),
	goals: t.boolean().default(!1),
	expansion: t.enum(ae).default("none"),
	specialDie: t.boolean().default(!1),
	separationDie: t.boolean().default(!1),
	renovation: t.boolean().default(!1),
	construction: t.boolean().default(!1),
	undergroundSolo: t.boolean().default(!1)
}).prefault({}), De = t.object({
	id: t.string(),
	rotation: t.int().min(0).max(3),
	mirror: t.boolean(),
	round: t.int(),
	weather: t.string().optional(),
	powered: t.boolean().optional(),
	lit: t.boolean().optional(),
	collected: t.boolean().optional(),
	cacti: t.int().optional(),
	hub: t.boolean().optional(),
	broken: t.boolean().optional(),
	origin: t.string().optional(),
	groups: t.array(t.array(t.object({
		side: t.int(),
		kind: t.enum([
			"h",
			"r",
			"w",
			"l",
			"v",
			"a",
			"s"
		])
	}))).optional(),
	station: t.boolean().optional()
}), Oe = t.object({
	cells: t.array(De.nullable()),
	under: t.array(De.nullable()),
	used: t.array(t.int()),
	specials: t.array(t.string()),
	regularSpecials: t.int(),
	specialRound: t.boolean(),
	done: t.boolean(),
	stage: t.enum([
		"start",
		"draw",
		"end"
	]),
	expUsed: t.array(t.int()),
	weatherUsed: t.array(t.int()),
	coins: t.int(),
	charge: t.int(),
	villages: t.int(),
	universities: t.int(),
	duplications: t.int(),
	freeSpecial: t.int(),
	factory: t.int(),
	meteor: t.int(),
	investigator: t.int(),
	movement: t.int(),
	enhanced: t.array(t.int()),
	aliens: t.array(t.object({
		cell: t.int(),
		shield: t.boolean()
	})),
	exitMarks: t.record(t.string(), t.string()),
	ritualPortals: t.array(t.string()),
	tentacles: t.array(t.array(t.int())),
	canyons: t.array(t.array(t.int())),
	bridges: t.array(t.string()),
	goals: t.array(t.int()),
	roundStart: t.array(De.nullable()),
	incomePaid: t.boolean(),
	constructionUsed: t.boolean(),
	renovationUsed: t.boolean(),
	freePlacement: t.boolean(),
	underDuplicate: t.boolean(),
	pendingLamp: t.int(),
	setupLeft: t.int(),
	cluesCollected: t.int(),
	cluesDrawn: t.int(),
	effects: t.array(t.object({
		cell: t.int(),
		kind: t.enum(["erase", "mark"]),
		serial: t.int()
	})),
	last: t.object({
		cell: t.int(),
		kind: t.string(),
		serial: t.int()
	}).nullable()
}), ke = t.object({
	network: t.number(),
	highway: t.number(),
	railway: t.number(),
	center: t.number(),
	errors: t.number(),
	expansion: t.number(),
	villages: t.number(),
	goals: t.number(),
	total: t.number()
}), Ae = t.object({
	id: t.string(),
	face: t.string(),
	mandatory: t.boolean(),
	source: t.enum([
		"route",
		"expansion",
		"engineer"
	])
}), je = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("place"),
		die: t.int().min(0),
		cell: t.int().min(0).max(48),
		rotation: t.int().min(0).max(3),
		mirror: t.boolean(),
		duplicate: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("special"),
		id: t.string(),
		cell: t.int().min(0).max(48),
		rotation: t.int().min(0).max(3),
		mirror: t.boolean(),
		as: t.enum(["ufo", "airport"]).optional()
	}),
	t.object({ type: t.literal("finish") }),
	t.object({ type: t.literal("skipStart") }),
	t.object({ type: t.literal("skipEnd") }),
	t.object({
		type: t.literal("meteor"),
		direction: t.int().min(0).max(3),
		sacrifice: t.string().optional()
	}),
	t.object({
		type: t.literal("weather"),
		die: t.int().min(0).max(1),
		cell: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("lamp"),
		axis: t.enum(["row", "column"]),
		index: t.int().min(0).max(6)
	}),
	t.object({
		type: t.literal("startEffect"),
		cell: t.int().min(0).max(48),
		sacrifice: t.string().optional()
	}),
	t.object({
		type: t.literal("path"),
		path: t.array(t.int().min(0).max(63)).min(1).max(20),
		die: t.int().min(0).max(20).default(0)
	}),
	t.object({
		type: t.literal("markExit"),
		exit: t.int().min(0).max(11)
	}),
	t.object({
		type: t.literal("power"),
		die: t.int().min(0).max(1),
		cell: t.int().min(0).max(48),
		direction: t.int().min(0).max(3).default(0)
	}),
	t.object({
		type: t.literal("build"),
		cell: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("moveInvestigator"),
		cell: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("ritualPortal"),
		cell: t.int().min(0).max(48),
		side: t.int().min(0).max(3)
	}),
	t.object({
		type: t.literal("construct"),
		cell: t.int().min(0).max(48),
		target: t.int().min(0).max(48).optional(),
		rotation: t.int().min(0).max(3).default(0),
		mirror: t.boolean().default(!1)
	}),
	t.object({
		type: t.literal("renovate"),
		cell: t.int().min(0).max(48),
		rotation: t.int().min(0).max(3),
		mirror: t.boolean()
	}),
	t.object({
		type: t.literal("volcano"),
		cell: t.int().min(0).max(48)
	}),
	t.object({
		type: t.literal("eraseLava"),
		cell: t.int().min(0).max(48)
	}),
	t.object({ type: t.literal("declineBonus") }),
	t.object({
		type: t.literal("alien"),
		cell: t.int().min(0).max(48)
	})
]), Me = t.object({
	players: t.array(t.string()),
	config: Ee,
	round: t.int(),
	maxRounds: t.int(),
	phase: t.enum(["play", "done"]),
	dice: t.array(Ae),
	boards: t.record(t.string(), Oe),
	scores: t.record(t.string(), ke),
	goalIds: t.array(t.string()),
	goalRanks: t.array(t.int()),
	underRound: t.boolean(),
	serial: t.int(),
	finalHeat: t.boolean()
}), Ne = t.object({});
//#endregion
//#region src/games/railroadink/paths.ts
function Pe(e) {
	let t = Math.min(...e.map((e) => e[0])), n = Math.min(...e.map((e) => e[1]));
	return e.map((e) => `${e[0] - t}:${e[1] - n}`).sort().join(",");
}
function Fe(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n = 0; n < 2; n++) for (let r = 0; r < 4; r++) {
		let i = e.map(([e, t]) => {
			let i = n ? -e : e, a = t;
			for (let e = 0; e < r; e++) [i, a] = [-a, i];
			return [i, a];
		}), a = Math.min(...i.map((e) => e[0])), o = Math.min(...i.map((e) => e[1])), s = i.map(([e, t]) => [e - a, t - o]);
		t.set(Pe(s), s);
	}
	return [...t.values()];
}
function Ie(e, t, n) {
	return t.length === 4 && new Set(t).size === 4 && t.every((t) => t < 49 && !e.cells[t] && !e.enhanced.includes(t)) && Fe(E[n] ?? []).some((e) => Pe(e) === Pe(t.map((e) => [e % 7, Math.floor(e / 7)])));
}
function Le(e, t) {
	let n = [];
	for (let r of Fe(E[t] ?? [])) for (let i = 0; i < 7; i++) for (let a = 0; a < 7; a++) {
		if (r.some(([e, t]) => a + e >= 7 || i + t >= 7)) continue;
		let o = r.map(([e, t]) => (i + t) * 7 + a + e);
		Ie(e, o, t) && n.push(o);
	}
	return n;
}
function Re(e, t) {
	let n = R(e.cells[t])?.groups.flat().map((e) => e.side) ?? [];
	for (let r of e.tentacles) for (let i = 0; i < r.length; i++) r[i] === t && (i ? n.push(L(t, r[i - 1])) : n.push([
		0,
		1,
		2,
		3
	].find((n) => F(t, n) < 0 && !B(R(e.cells[t]), n).length) ?? 0), i < r.length - 1 && n.push(L(t, r[i + 1])));
	return [...new Set(n)];
}
function ze(e, t, n) {
	if (t.length !== n || new Set(t).size !== n || t.some((e) => e > 48) || N.some((e) => e.cell === t[0])) return !1;
	for (let n = 0; n < t.length; n++) {
		let r = t[n], i = Re(e, r), a = R(e.cells[r]);
		if (a && (a.groups.length !== 1 || a.groups[0].length !== 2 || a.station) || i.length > 2) return !1;
		let o = n ? L(r, t[n - 1]) : [
			0,
			1,
			2,
			3
		].find((e) => F(r, e) < 0 && !i.includes(e)) ?? -1, s = n < t.length - 1 ? L(r, t[n + 1]) : -1;
		if (o < 0 || i.includes(o) || n < t.length - 1 && (s < 0 || s === o || i.includes(s))) return !1;
	}
	return !0;
}
function Be(e, t) {
	let n = [], r = (i) => {
		if (i.length === t) {
			ze(e, i, t) && n.push(i);
			return;
		}
		let a = i[i.length - 1];
		for (let e = 0; e < 4; e++) {
			let t = F(a, e);
			t >= 0 && !i.includes(t) && r([...i, t]);
		}
	};
	for (let e = 0; e < 49; e++) [
		0,
		1,
		2,
		3
	].some((t) => F(e, t) < 0) && !N.some((t) => t.cell === e) && r([e]);
	return n;
}
var Ve = {
	canyon1: [[0, 0], [1, 0]],
	canyon2: [
		[0, 0],
		[1, 0],
		[2, 0]
	],
	canyon3: [
		[0, 0],
		[1, 0],
		[2, 0],
		[3, 0]
	],
	canyonL: [
		[0, 0],
		[1, 0],
		[1, 1]
	],
	canyonLongL: [
		[0, 0],
		[1, 0],
		[2, 0],
		[2, 1]
	],
	canyonEqualL: [
		[0, 0],
		[1, 0],
		[2, 0],
		[2, 1],
		[2, 2]
	],
	canyonZ: [
		[0, 0],
		[1, 0],
		[1, 1],
		[2, 1]
	]
};
function He(e, t, n) {
	let r = Ve[n];
	if (!r || t.length !== r.length || new Set(t).size !== t.length || !Fe(r).some((e) => Pe(e) === Pe(t.map((e) => [e % 8, Math.floor(e / 8)])))) return null;
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Set();
	for (let t of e.canyons) for (let e = 1; e < t.length; e++) {
		a.add(A(t[e - 1], t[e]));
		for (let n of [t[e - 1], t[e]]) i.set(n, (i.get(n) ?? 0) + 1);
	}
	let o = !1, s = /* @__PURE__ */ new Set();
	for (let e = 0; e < t.length; e++) {
		let n = t[e];
		if (n < 0 || n > 63) return null;
		let r = e === 0 || e === t.length - 1;
		if (i.has(n) && (!r || i.get(n) >= 2)) return null;
		if (r && (fe(n) || i.get(n) === 1) && (o = !0), e) {
			let r = t[e - 1];
			if (Math.abs(r % 8 - n % 8) + Math.abs(Math.floor(r / 8) - Math.floor(n / 8)) !== 1) return null;
			let i = A(r, n);
			if (a.has(i)) return null;
			s.add(i);
		}
	}
	if (!o) return null;
	let c = new Set(e.bridges);
	return e.cells.forEach((e, t) => {
		for (let n = 0; n < 4; n++) B(R(e), n).length && s.has(j(t)[n]) && c.add(j(t)[n]);
	}), c.size <= 12 ? [...c].filter((t) => !e.bridges.includes(t)) : null;
}
function Ue(e, t) {
	let n = Ve[t];
	if (!n) return [];
	let r = /* @__PURE__ */ new Map();
	for (let i = 0; i < 2; i++) for (let a = 0; a < 4; a++) {
		let o = n.map(([e, t]) => {
			let n = i ? -e : e, r = t;
			for (let e = 0; e < a; e++) [n, r] = [-r, n];
			return [n, r];
		}), s = Math.min(...o.map((e) => e[0])), c = Math.min(...o.map((e) => e[1])), l = o.map(([e, t]) => [e - s, t - c]);
		for (let n = 0; n < 8; n++) for (let i = 0; i < 8; i++) {
			if (l.some(([e, t]) => e + i > 7 || t + n > 7)) continue;
			let a = l.map(([e, t]) => (t + n) * 8 + e + i);
			He(e, a, t) && r.set(a.join(","), a);
		}
	}
	return [...r.values()];
}
function We(e, t) {
	if (t === "any") return Array.from({ length: 49 }, (e, t) => [t]);
	let n = [
		"north",
		"east",
		"south",
		"west"
	].indexOf(t);
	if (n < 0) return [];
	let r = [];
	for (let t = 0; t < 49; t++) {
		let i = F(t, M[n]);
		if (i >= 0 ? !e.cells[i]?.powered : !N.some((e) => e.cell === t && e.side === M[n])) continue;
		let a = [], o = t;
		for (; o >= 0 && (o === 24 || e.cells[o] && !e.cells[o]?.powered) && (a.push(o), r.push([...a]), o !== 24);) o = F(o, n);
	}
	return r;
}
//#endregion
//#region src/games/railroadink/goals.ts
var Ge = [
	"network3",
	"opposite",
	"middle",
	"stations4",
	"highway6",
	"railway6",
	"center5",
	"corners3",
	"loop",
	"row",
	"square",
	"villages3"
], Ke = {
	forest: [
		"forest5",
		"forestDiagonal",
		"forestExits"
	],
	trail: [
		"trailStation",
		"trailRow",
		"trailCenter"
	],
	desert: [
		"cactusRow",
		"oasis3",
		"cactusSquare"
	],
	canyon: [
		"bridge6",
		"canyonCross3",
		"canyonCenter"
	]
};
function qe(e, t, n = !1) {
	let r = new Set(e);
	return e.some((e) => (n ? [[1, 1], [-1, 1]] : [[1, 0], [0, 1]]).some(([n, i]) => Array.from({ length: t }, (t, r) => [e % 7 + n * r, Math.floor(e / 7) + i * r]).every(([e, t]) => e >= 0 && e < 7 && t >= 0 && t < 7 && r.has(t * 7 + e))));
}
function Je(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.canyons) for (let e = 1; e < n.length; e++) {
		let r = n[e - 1], i = n[e];
		t.set(r, [...t.get(r) ?? [], i]), t.set(i, [...t.get(i) ?? [], r]);
	}
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let e of t.keys()) {
		if (n.has(e)) continue;
		let i = [e];
		n.add(e);
		for (let e = 0; e < i.length; e++) for (let r of t.get(i[e]) ?? []) n.has(r) || (n.add(r), i.push(r));
		r.push(i);
	}
	return r;
}
function Ye(e, t, n) {
	let r = e.cells, i = G(r), a = K(i), o = r.flatMap((e, t) => R(e)?.trails ? [t] : []), s = r.flatMap((e, t) => (e?.cacti ?? 0) > 0 ? [t] : []);
	if (t === "highway6" || t === "railway6" || t === "center5") {
		let r = me(e, n);
		return t === "highway6" ? r.highway >= 6 : t === "railway6" ? r.railway >= 6 : r.center >= 5;
	}
	return t === "corners3" ? [
		0,
		6,
		42,
		48
	].filter((e) => r[e]).length >= 3 : t === "villages3" ? e.villages >= 3 : t === "row" ? qe(r.flatMap((e, t) => e ? [t] : []), 7) : t === "square" ? r.some((e, t) => t % 7 < 5 && t < 35 && [
		0,
		7,
		14
	].every((e) => [
		0,
		1,
		2
	].every((n) => r[t + e + n]))) : t === "forest5" ? we(r, (e) => R(e)?.mark === "tree").length >= 5 : t === "forestDiagonal" ? qe(r.flatMap((e, t) => R(e)?.mark === "tree" ? [t] : []), 4, !0) : t === "forestExits" ? N.filter((e) => R(r[e.cell])?.mark === "tree").length >= 4 : t === "trailRow" ? qe(o, 5) : t === "trailCenter" ? o.filter((e) => e % 7 >= 2 && e % 7 <= 4 && e >= 14 && e < 35).length >= 5 : t === "trailStation" ? r.some((e, t) => R(e)?.station && o.filter((e) => e !== t && R(r[e])?.trails?.flat().some((n) => [
		0,
		1,
		2,
		3
	].some((r) => q(t, r) === q(e, n)))).length >= 3) : t === "cactusRow" ? qe(s, 4) : t === "cactusSquare" ? s.some((e) => e % 7 < 6 && e < 42 && [
		e + 1,
		e + 7,
		e + 8
	].every((e) => s.includes(e))) : t === "bridge6" ? e.bridges.length >= 6 : t === "canyonCenter" ? Je(e).some((e) => e.filter(fe).length >= 2 && e.some((e) => e % 8 >= 2 && e % 8 <= 5 && e >= 16 && e <= 45)) : t === "canyonCross3" ? Je(e).some((t) => {
		let n = new Set(t), r = new Set(e.bridges.filter((e) => e.split(":").map(Number).every((e) => n.has(e))));
		if (r.size < 3) return !1;
		let a = (e, t) => {
			let n = [
				0,
				1,
				2,
				3
			].find((n) => F(e, n) === t);
			return n === void 0 ? "" : j(e)[n];
		}, o = (e, t, n) => {
			if (n.size >= 3) return !0;
			for (let s of i[e].next) {
				if (t & 1n << BigInt(s)) continue;
				let c = a(i[e].cell, i[s].cell), l = new Set(n);
				if (r.has(c) && l.add(c), o(s, t | 1n << BigInt(s), l)) return !0;
			}
			return !1;
		};
		return i.some((e, t) => o(t, 1n << BigInt(t), /* @__PURE__ */ new Set()));
	}) : a.some((e) => {
		let n = [...new Set(e.flatMap((e) => i[e].exits))], a = [...new Set(e.map((e) => i[e].cell))];
		return t === "network3" ? n.length >= 3 : t === "opposite" ? n.some((e) => n.some((t) => (N[e].side + 2) % 4 === N[t].side)) : t === "middle" ? n.filter((e) => e % 3 == 1).length >= 2 : t === "stations4" ? new Set(e.filter((e) => z(R(r[i[e].cell]), i[e].group)).map((e) => i[e].cell)).size >= 4 : t === "loop" ? e.some((e) => i[e].ports.some((e) => [
			"h",
			"r",
			"s"
		].includes(e.kind))) && e.reduce((e, t) => e + i[t].next.length, 0) / 2 >= e.length : t === "oasis3" && a.filter((e) => R(r[e])?.mark === "oasis").length >= 3;
	});
}
//#endregion
//#region src/games/railroadink/meta.ts
var Xe = {
	id: "railroadink",
	tier: "alpha",
	mechanics: ["roll-and-write"],
	interactionTags: [],
	nameKey: "games.railroadink.name",
	descKey: "games.railroadink.desc",
	rulesKey: "games.railroadink.rules",
	icon: "🚂",
	iconImg: "games/railroadink.webp",
	accent: "#257eaa",
	minPlayers: 1,
	maxPlayers: 6,
	bestPlayers: [
		1,
		2,
		4
	],
	releasedAt: "2026-11-02T18:00:00+08:00",
	search: {
		py: "qian mo jiao tong",
		init: "qmjt"
	},
	hotseat: "open",
	rulesUrl: { en: "https://steamusercontent-a.akamaihd.net/ugc/1004809286527715150/0C0B4EECC8E0B91D1C359A80F73FD565C76B23D0/" }
}, Ze = () => ({ code: "games.railroadink.errAction" }), Qe = (e) => e.dice.flatMap((e, t) => e.source === "expansion" ? [t] : []), $e = (e) => e.freeSpecial > 0 || !e.specialRound && e.regularSpecials < 3, et = (e, t, n) => e.players[(e.players.indexOf(t) + n + e.players.length) % e.players.length], Y = (e, t, n = 0, r = !1, i = "expansion") => ({
	id: e,
	round: t,
	rotation: n,
	mirror: r,
	origin: i
}), X = (e, t) => e.players.every((n) => e.boards[n].stage !== t);
function tt(e, t) {
	return !w.includes(t) || e.specials.includes(t) || !$e(e) ? !1 : (e.specials.push(t), e.freeSpecial > 0 ? e.freeSpecial-- : (e.regularSpecials++, e.specialRound = !0), !0);
}
function nt(e, t, n, r) {
	let i = (r ? e.under : e.cells)[n], a = R(i);
	if (e.aliens = e.aliens.filter((e) => e.cell !== n || e.shield), i && a?.mark === "cactus" && (i.cacti = a.amount ?? 1), a?.mark === "clue" && e.cluesDrawn++, t.config.challenge && !r && H(a) && (P[n] === "factory" && e.factory++, P[n] === "village" && a?.station && (e.villages = Math.min(4, e.villages + 1)), P[n] === "university" && e.universities < 3 && (e.universities++, e.universities === 3 && e.freeSpecial++)), t.config.expansion === "underground" && (r && i && a?.station && (i.hub = t.config.undergroundSolo ? !e.under.some((e, t) => e?.hub && (t % 7 == n % 7 || Math.floor(t / 7) === Math.floor(n / 7))) : !!R(e.cells[n])?.station), !r && a?.station && e.under[n])) {
		let t = e.under[n];
		R(t)?.station && (t.hub = !0), R(t)?.groups.flat().some((e) => e.kind === "h") && (t.broken = !0);
	}
	if (t.config.expansion === "lake") {
		let n = !0;
		for (; n;) {
			n = !1;
			for (let r = 0; r < 49; r++) !e.cells[r] && [
				0,
				1,
				2,
				3
			].filter((t) => B(R(e.cells[F(r, t)]), M[t]).includes("l")).length >= 3 && (e.cells[r] = Y("lX", t.round), n = !0);
		}
	}
	if (t.config.expansion === "canyon" && a) for (let t of a.groups.flat()) {
		let r = j(n)[t.side];
		e.canyons.some((e) => e.some((t, n) => n && A(e[n - 1], t) === r)) && !e.bridges.includes(r) && e.bridges.push(r);
	}
	t.serial++, e.last = {
		cell: n,
		kind: r ? "under" : "draw",
		serial: t.serial
	};
}
function rt(e, t, n, r, i) {
	let a = j(t), o = D(S[n], r, i).groups.flat(), s = new Set(e.bridges);
	for (let t of o) e.canyons.some((e) => e.some((n, r) => r && A(e[r - 1], n) === a[t.side])) && s.add(a[t.side]);
	return s.size <= 12;
}
function it(e, t) {
	if (e.round === 0) return t.setupLeft > 0;
	let n = e.config.expansion, r = Qe(e).map((t) => e.dice[t].face);
	return n === "meteor" || n === "rainbow" || n === "tetromino" || n === "desert" && r.includes("arid");
}
function at(e, t) {
	let n = e.dice[Qe(e)[0]]?.face, r = e.boards[n === "rain" ? et(e, t, -1) : t], i = r.cells.flatMap((e, t) => n === "rainbow" ? (!e || e.id === "rain") && !I(t).some((e) => r.cells[e]?.id === "rainbow") ? [t] : [] : e ? [] : [t]), a = i.filter((e) => I(e).some((e) => r.cells[e]?.id === "rainbow"));
	return n === "rain" && a.length ? a : i;
}
function ot(e, t) {
	return t.cells.flatMap((t, n) => t && H(R(t)) && t.round === e.round && !t.weather ? [n] : []);
}
function st(e) {
	return N.flatMap((t, n) => !e.exitMarks[n] && !B(R(e.cells[t.cell]), t.side).some((e) => e === t.kind || e === "s") ? [n] : []);
}
function ct(e, t) {
	return e.config.expansion === "lava" && !Qe(e).some((e) => t.used.includes(e));
}
function lt(e, t) {
	return !t.pendingLamp && e.dice.every((n, r) => !n.mandatory || t.used.includes(r) || !U(t, n.face, t.freePlacement && n.source === "route", e.underRound).some((r) => e.config.expansion !== "canyon" || rt(t, r.cell, n.face, r.rotation, r.mirror))) && !ct(e, t);
}
function ut(e) {
	for (let t = 0; t < 49; t++) e.cells[t]?.cacti && !I(t).some((t) => R(e.cells[t])?.mark === "oasis") && (e.cells[t].cacti = 0);
}
function dt(e, t) {
	e.finalHeat || e.round === 0 ? t.done = !0 : t.stage = "draw";
}
function ft(e, t, n) {
	if (t.stage !== "draw" || !X(e, "start") || t.pendingLamp || t.freeSpecial > 0 || t.factory > 0 && !n.duplicate) return !1;
	let { die: r, cell: i, rotation: a, mirror: o, duplicate: s } = n, c = e.dice[r];
	if (!c || !S[c.face] || c.source === "engineer") return !1;
	if (s) {
		if (e.underRound) {
			if (t.underDuplicate || t.duplications >= 3) return !1;
		} else if (t.factory <= 0 || c.source !== "route") return !1;
	} else if (t.used.includes(r)) return !1;
	return !Se(t, c.face, i, a, o, t.freePlacement && c.source === "route", e.underRound) || e.config.expansion === "canyon" && !rt(t, i, c.face, a, o) ? !1 : (s ? e.underRound ? (t.underDuplicate = !0, t.duplications++) : t.factory-- : t.used.push(r), (e.underRound ? t.under : t.cells)[i] = Y(c.face, e.round, a, o, c.source), t.freePlacement && c.source === "route" && (t.freePlacement = !1), nt(t, e, i, e.underRound), !0);
}
function pt(e, t, n) {
	let r = e.boards[n], i = e.config.expansion, a = Qe(e), o = a.map((t) => e.dice[t].face);
	if (!r || r.done || e.phase === "done" || r.stage === "draw" && r.pendingLamp && t.type !== "lamp" || r.stage === "draw" && r.freeSpecial && !["special", "declineBonus"].includes(t.type) || r.stage === "draw" && r.factory && t.type !== "declineBonus" && !(t.type === "place" && t.duplicate)) return !1;
	if (t.type === "place") return ft(e, r, t);
	if (t.type === "skipStart") return r.stage !== "start" || e.round === 0 && r.setupLeft > 0 || it(e, r) && i !== "tetromino" && (i !== "rainbow" || at(e, n).length) ? !1 : (dt(e, r), !0);
	if (t.type === "meteor") {
		if (r.stage !== "start" || i !== "meteor") return !1;
		if (t.sacrifice) {
			if (!tt(r, t.sacrifice)) return !1;
		} else {
			let n = [
				"north",
				"east",
				"south",
				"west"
			].indexOf(o[0]);
			if (n >= 0 && t.direction !== n) return !1;
			let i = t.direction, a = r.meteor, s = () => {
				F(a, i) < 0 && (i = M[i]), a = F(a, i);
			};
			for (let e = 0; e < Number(o[1]); e++) s();
			let c = /* @__PURE__ */ new Set();
			for (; r.cells[a]?.id === "crater";) {
				if (c.has(a * 4 + i)) return !1;
				c.add(a * 4 + i), s();
			}
			r.cells[a] = Y("crater", e.round), r.meteor = a, e.serial++, r.last = {
				cell: a,
				kind: "meteor",
				serial: e.serial
			};
		}
		return dt(e, r), !0;
	}
	if (t.type === "startEffect") {
		if (r.stage !== "start") return !1;
		if (i === "desert" && o.includes("arid")) {
			if (t.sacrifice) {
				if (!tt(r, t.sacrifice)) return !1;
			} else ut(r);
			return dt(e, r), !0;
		}
		if (i === "rainbow") {
			if (!at(e, n).includes(t.cell)) return !1;
			let i = o[0], a = e.boards[i === "rain" ? et(e, n, -1) : n], s = a.cells[t.cell];
			if (i === "rainbow") {
				if (s && s.id !== "rain" || I(t.cell).some((e) => a.cells[e]?.id === "rainbow")) return !1;
			} else if (s) return !1;
			if (i === "rain") {
				let e = a.cells.flatMap((e, t) => !e && I(t).some((e) => a.cells[e]?.id === "rainbow") ? [t] : []);
				if (e.length && !e.includes(t.cell)) return !1;
			}
			return a.cells[t.cell] = Y(i, e.round), dt(e, r), !0;
		}
		return !1;
	}
	if (t.type === "special") {
		if (r.stage !== "draw" || !X(e, "start") || e.underRound || r.pendingLamp || r.factory > 0) return !1;
		let n = t.as ?? t.id;
		return t.as && !(t.as === "ufo" && i === "farmer" || t.as === "airport" && i === "airline") || !S[n] || !Se(r, n, t.cell, t.rotation, t.mirror) || !tt(r, t.id) || i === "canyon" && !rt(r, t.cell, n, t.rotation, t.mirror) ? !1 : (r.cells[t.cell] = Y(n, e.round, t.rotation, t.mirror, "special"), nt(r, e, t.cell, !1), i === "lamps" && r.pendingLamp++, !0);
	}
	if (t.type === "lamp") return r.pendingLamp ? (r.cells.forEach((e, n) => {
		e && R(e)?.mark === "lamp" && (t.axis === "row" ? Math.floor(n / 7) === t.index : n % 7 === t.index) && (e.lit = !0);
	}), r.pendingLamp--, !0) : !1;
	if (t.type === "declineBonus") return r.stage !== "draw" || !r.freeSpecial && !r.factory ? !1 : (r.freeSpecial = 0, r.factory = 0, !0);
	if (t.type === "finish") return r.stage !== "draw" || !X(e, "start") || !lt(e, r) || i === "pluckman" && !r.expUsed.length && st(r).length ? !1 : (r.stage = "end", r.factory = 0, r.freeSpecial = 0, i === "city" && (r.coins = Math.min(12, r.coins + ge(r, o[1])), r.incomePaid = !0), i === "investigation" && (r.movement = S[o[0]]?.amount ?? 0), !0);
	if (t.type === "skipEnd") return r.stage !== "end" || !X(e, "draw") || i === "weather" && r.weatherUsed.length < Math.min(2, r.weatherUsed.length + ot(e, r).length) || i === "invaders" && !r.expUsed.length && (o[0] === "attack" || o[0] === "nuke" && r.aliens.length || o[0] === "alien" && e.boards[et(e, n, 1)].cells.some((t, r) => !t && !e.boards[et(e, n, 1)].aliens.some((e) => e.cell === r))) ? !1 : (r.done = !0, !0);
	if (t.type === "weather") return i !== "weather" || r.stage !== "end" || !X(e, "draw") || r.weatherUsed.includes(t.die) || !ot(e, r).includes(t.cell) ? !1 : (r.cells[t.cell].weather = o[t.die], r.weatherUsed.push(t.die), !0);
	if (t.type === "markExit") return i === "investigation" && e.round === 0 && r.setupLeft ? (r.investigator = -t.exit - 1, r.setupLeft = 0, !0) : i !== "pluckman" || r.stage !== "draw" || !X(e, "start") || r.expUsed.length || !st(r).includes(t.exit) ? !1 : (r.exitMarks[t.exit] = o[0], r.expUsed.push(0), !0);
	if (t.type === "build") {
		if (i !== "city" || r.stage !== "end" || !X(e, "draw") || r.cells[t.cell]) return !1;
		let n = S[o[0]]?.amount ?? 0, a = n * 2 + 1;
		return !n || r.coins < a ? !1 : (r.coins -= a, r.cells[t.cell] = Y(o[0], e.round), !0);
	}
	if (t.type === "alien") {
		if (i !== "invaders") return !1;
		if (e.round === 0 && r.setupLeft) {
			let i = e.boards[et(e, n, 1)];
			return i.cells[t.cell] || i.aliens.some((e) => e.cell === t.cell) ? !1 : (i.aliens.push({
				cell: t.cell,
				shield: !1
			}), r.setupLeft--, !0);
		}
		if (r.stage !== "end" || !X(e, "draw") || r.expUsed.length) return !1;
		if (o[0] === "attack") r.aliens.forEach((e) => {
			e.shield = !0, r.cells[e.cell] = null;
		});
		else if (o[0] === "nuke") {
			if (!r.aliens.some((e) => e.cell === t.cell)) return !1;
			r.aliens = r.aliens.filter((e) => e.cell !== t.cell);
		} else {
			let r = e.boards[et(e, n, 1)];
			if (r.cells[t.cell] || r.aliens.some((e) => e.cell === t.cell)) return !1;
			r.aliens.push({
				cell: t.cell,
				shield: !1
			});
		}
		return r.expUsed.push(0), !0;
	}
	if (t.type === "moveInvestigator") {
		if (i !== "investigation" || r.stage !== "end" || !X(e, "draw") || r.movement <= 0 || !_e(r).includes(t.cell)) return !1;
		r.investigator = t.cell, r.movement--;
		let n = r.cells[t.cell];
		return n && R(n)?.mark === "clue" && !n.collected && (n.collected = !0, r.cluesCollected++), !0;
	}
	if (t.type === "ritualPortal") {
		let n = `${t.cell}:${t.side}`, a = R(r.cells[t.cell]);
		return i !== "ritual" || r.stage !== "end" || !X(e, "draw") || r.expUsed.length || r.ritualPortals.includes(n) || F(t.cell, t.side) >= 0 || N.some((e) => e.cell === t.cell && e.side === t.side) || !B(a, t.side).some((e) => [
			"h",
			"r",
			"s"
		].includes(e)) ? !1 : (r.ritualPortals.push(n), r.expUsed.push(0), !0);
	}
	if (t.type === "volcano") return i !== "lava" || r.stage !== "draw" || !X(e, "start") || r.cells[t.cell] || I(t.cell).some((e) => R(r.cells[e])?.groups.flat().some((e) => e.kind === "v")) ? !1 : (r.cells[t.cell] = Y("volcano", e.round), !0);
	if (t.type === "eraseLava") return i !== "lava" || r.stage !== "draw" || !X(e, "start") || !ct(e, r) || a.some((t) => U(r, e.dice[t].face).length) || !r.cells[t.cell] || !I(t.cell).some((e) => R(r.cells[e])?.groups.flat().some((e) => e.kind === "v")) ? !1 : (r.cells[t.cell] = null, !0);
	if (t.type === "path") {
		if (i === "tetromino" && r.stage === "start") return Ie(r, t.path, o[0]) ? (r.enhanced.push(...t.path), dt(e, r), !0) : !1;
		if (i === "tentacle" && r.stage === "end" && X(e, "draw") && !r.expUsed.length) return ze(r, t.path, Number(o[0])) ? (r.tentacles.push(t.path), r.expUsed.push(0), !0) : !1;
		if (i === "canyon" && r.stage === "draw" && a.includes(t.die) && !r.used.includes(t.die)) {
			let n = He(r, t.path, e.dice[t.die].face);
			return n ? (r.canyons.push(t.path), r.bridges.push(...n), r.used.push(t.die), !0) : !1;
		}
		return i === "power" && r.stage === "end" && X(e, "draw") && a.includes(t.die) && !r.expUsed.includes(t.die) ? mt(e, r, t.path, t.die) : !1;
	}
	return t.type === "construct" ? ht(e, r, t) : t.type === "renovate" && yt(e, r, t);
}
function mt(e, t, n, r) {
	if (!n.length || n.some((e) => e > 48)) return !1;
	let i = e.dice[r].face;
	if (i === "any") {
		if (n.length !== 1 || n[0] !== 24 && (!H(R(t.cells[n[0]])) || t.cells[n[0]]?.powered) || n[0] === 24 && t.charge >= 3) return !1;
	} else {
		let e = [
			"north",
			"east",
			"south",
			"west"
		].indexOf(i);
		if (e < 0) return !1;
		let r = F(n[0], M[e]);
		if (r >= 0 ? !t.cells[r]?.powered : !N.some((t) => t.cell === n[0] && t.side === M[e])) return !1;
		for (let i = 0; i < n.length; i++) {
			let a = n[i];
			if (i && F(n[i - 1], e) !== a) return !1;
			if (a === 24) {
				if (i !== n.length - 1 || t.charge >= 3 || i === 0 && r < 0) return !1;
			} else if (!H(R(t.cells[a])) || t.cells[a]?.powered) return !1;
		}
	}
	for (let e of n) e === 24 ? t.charge++ : t.cells[e].powered = !0;
	return t.expUsed.push(r), !0;
}
function ht(e, t, n) {
	let r = e.dice.find((e) => e.id === "construction");
	if (!r || t.stage !== "draw" || !X(e, "start") || t.constructionUsed || e.underRound) return !1;
	if (r.face === "free") return t.freePlacement = !0, t.constructionUsed = !0, !0;
	let i = t.cells[n.cell];
	if (!i || !["route", "special"].includes(i.origin ?? "")) return !1;
	if (t.cells[n.cell] = null, r.face === "move") {
		let r = gt(i, n.rotation, n.mirror), a = R(r);
		if (n.target === void 0 || n.target === n.cell || !xe(t, a, n.target) || e.config.expansion === "canyon" && !vt(t, n.target, a.groups.flat())) return t.cells[n.cell] = i, !1;
		t.cells[n.target] = {
			...r,
			round: e.round
		}, nt(t, e, n.target, !1);
	}
	return t.constructionUsed = !0, !0;
}
function gt(e, t, n) {
	if (!e.groups) return {
		...e,
		rotation: t,
		mirror: n
	};
	let r = e.groups.map((t) => t.map((t) => ({
		...t,
		side: ((e.mirror ? e.rotation - t.side : t.side - e.rotation) + 4) % 4
	})));
	return {
		...e,
		rotation: t,
		mirror: n,
		groups: D({
			...S[e.id],
			groups: r
		}, t, n).groups
	};
}
function _t(e, t, n) {
	let r = e.dice.find((e) => e.id === "renovation"), i = t.cells[n.cell], a = R(i);
	if (!r || !i || !a || !["route", "special"].includes(i.origin ?? "")) return null;
	let o = (e) => ((n.mirror ? (4 - e) % 4 : e) + n.rotation) % 4, s = r.face.startsWith("station"), c = r.face.startsWith("bend"), l = r.face.endsWith("H") ? "h" : "r", u = (c ? [0, 3] : s ? [
		0,
		1,
		2,
		3
	] : [0, 2]).map(o);
	if (s ? !a.station : a.groups.flat().some((e) => !u.includes(e.side))) return null;
	let d = (s ? [0] : [1, 2].map((e) => c ? e : e === 2 ? 3 : 1)).map((e) => ({
		side: o(e),
		kind: l
	}));
	if (d.some((e) => a.groups.flat().some((t) => t.side === e.side))) return null;
	let f = a.stationGroups?.[0] ?? 0, p = s ? a.groups.map((e, t) => t === f ? [...e, ...d] : e) : [...a.groups, d], m = {
		...a,
		groups: p
	};
	return !xe({
		...t,
		cells: t.cells.map((e, t) => t === n.cell ? null : e)
	}, m, n.cell, !0) || e.config.expansion === "canyon" && !vt(t, n.cell, m.groups.flat()) ? null : {
		...i,
		groups: p,
		round: e.round
	};
}
function vt(e, t, n) {
	let r = new Set(e.bridges), i = j(t);
	for (let t of n) e.canyons.some((e) => e.some((n, r) => r && A(e[r - 1], n) === i[t.side])) && r.add(i[t.side]);
	return r.size <= 12;
}
function yt(e, t, n) {
	if (!e.config.renovation || t.renovationUsed || t.stage !== "draw" || e.underRound || !X(e, "start")) return !1;
	let r = _t(e, t, n);
	if (!r) return !1;
	if (t.cells[n.cell] = r, t.renovationUsed = !0, e.config.expansion === "canyon") for (let e of R(r).groups.flat()) {
		let r = j(n.cell)[e.side];
		!t.bridges.includes(r) && t.canyons.some((e) => e.some((t, n) => n && A(e[n - 1], t) === r)) && t.bridges.push(r);
	}
	return e.serial++, t.last = {
		cell: n.cell,
		kind: "renovate",
		serial: e.serial
	}, !0;
}
function bt(t) {
	t.underRound = t.config.expansion === "underground" && (t.config.undergroundSolo || t.round % 2 == 0);
	let n = t.underRound ? se : t.config.challenge ? ie : re;
	n = n.map((e) => [...e]), t.underRound || (t.config.specialDie && (n[0] = w), t.config.separationDie && (n[1] = ce));
	let r = n.map((e, t) => ({
		faces: e,
		mandatory: !0,
		source: "route",
		id: `route${t}`
	}));
	if (!t.underRound) {
		for (let [e, n] of (t.config.expansion === "invaders" ? [] : oe[t.config.expansion] ?? []).entries()) r.push({
			faces: n,
			mandatory: ["super", "ritual"].includes(t.config.expansion),
			source: "expansion",
			id: `exp${e}`
		});
		t.config.construction && r.push({
			faces: T,
			mandatory: !1,
			source: "engineer",
			id: "construction"
		}), t.config.renovation && r.push({
			faces: le,
			mandatory: !1,
			source: "engineer",
			id: "renovation"
		});
	}
	t.dice = r.map((n) => ({
		id: n.id,
		face: n.faces[e(t.seed, t.rngCursor++, n.faces.length)],
		mandatory: n.mandatory,
		source: n.source
	}));
	for (let e of Object.values(t.boards)) e.used = [], e.done = !1, e.specialRound = !1, e.expUsed = [], e.weatherUsed = [], e.factory = 0, e.freeSpecial = 0, e.roundStart = structuredClone(e.cells), e.incomePaid = !1, e.constructionUsed = !1, e.renovationUsed = !1, e.freePlacement = !1, e.underDuplicate = !1, e.stage = !t.underRound && it(t, e) ? "start" : "draw";
}
function xt(e) {
	e.config.goals && !e.underRound && e.goalIds.forEach((t, n) => {
		let r = e.players.filter((r) => e.boards[r].goals[n] < 0 && Ye(e.boards[r], t, e.config));
		if (!r.length) return;
		let i = e.players.length === 1 ? Math.ceil(e.round / (e.config.expansion === "underground" ? 2 : 1)) <= n + 3 ? 4 : 1 : [
			4,
			2,
			1
		][Math.min(2, e.goalRanks[n])];
		r.forEach((t) => {
			e.boards[t].goals[n] = i;
		}), e.goalRanks[n] = Math.min(2, e.goalRanks[n] + 1);
	});
}
function St(e) {
	e.scores = Object.fromEntries(e.players.map((t) => [t, me(e.boards[t], e.config)]));
}
function Ct(t) {
	if (t.players.every((e) => t.boards[e].done)) {
		if (t.finalHeat) {
			t.phase = "done";
			return;
		}
		if (t.round > 0 && xt(t), t.round === t.maxRounds) {
			if (t.config.expansion === "desert") {
				if (t.finalHeat = !0, t.dice = (oe.desert ?? []).map((n, r) => ({
					id: `exp${r}`,
					face: n[e(t.seed, t.rngCursor++, 6)],
					mandatory: !1,
					source: "expansion"
				})), t.dice.some((e) => e.face === "arid")) for (let e of Object.values(t.boards)) e.done = !1, e.specialRound = !1, e.stage = "start";
				else t.phase = "done";
			} else t.phase = "done";
		} else t.round++, bt(t);
	}
}
var wt = {
	meta: Xe,
	saveCompatibility: { version: "1" },
	schemas: {
		action: je,
		publicView: Me,
		privateView: Ne,
		config: Ee
	},
	setup(t, n, r) {
		let i = Ee.parse(t), a = ["invaders", "investigation"].includes(i.expansion);
		i.expansion === "underground" && i.undergroundSolo && (i.goals = !1);
		let o = {
			players: [...n],
			config: i,
			round: +!a,
			maxRounds: i.expansion === "underground" && !i.undergroundSolo ? 14 : ue.includes(i.expansion) ? 6 : 7,
			phase: "play",
			dice: [],
			boards: Object.fromEntries(n.map((e) => [e, be()])),
			scores: {},
			goalIds: [],
			goalRanks: [
				0,
				0,
				0
			],
			underRound: !1,
			serial: 0,
			finalHeat: !1,
			seed: r,
			rngCursor: 0
		}, s = Ge.filter((e) => i.challenge || e !== "villages3");
		for (let t = 0; t < 3; t++) {
			let n = t === 2 && Ke[i.expansion] ? Ke[i.expansion].slice() : s, a = e(r, o.rngCursor++, n.length);
			o.goalIds.push(n.splice(a, 1)[0]);
		}
		for (let e of Object.values(o.boards)) e.goals = [
			-1,
			-1,
			-1
		], i.expansion === "lava" && (e.cells[24] = Y("volcano", 0)), i.expansion === "power" && (e.cells[24] = Y("battery", 0)), a && (e.setupLeft = i.expansion === "invaders" ? 2 : 1, e.stage = "start");
		return a || bt(o), St(o), {
			state: o,
			fx: []
		};
	},
	reduce(t, n, r) {
		let i = structuredClone(t);
		if (!pt(i, n, r.by)) return Ze();
		if (i.config.expansion === "invaders" && i.round > 0 && X(i, "draw") && !Qe(i).length) {
			let t = oe.invaders[0];
			i.dice.push({
				id: "exp0",
				face: t[e(i.seed, i.rngCursor++, t.length)],
				mandatory: !1,
				source: "expansion"
			});
		}
		for (let e of i.players) {
			let n = i.boards[e], r = t.boards[e];
			n.effects = [];
			for (let e = 0; e < 49; e++) JSON.stringify(n.cells[e]) !== JSON.stringify(r.cells[e]) && n.effects.push({
				cell: e,
				kind: r.cells[e] && !n.cells[e] ? "erase" : "mark",
				serial: i.serial + 1
			});
		}
		return Ct(i), St(i), {
			state: i,
			fx: []
		};
	},
	viewFor(e) {
		let t = { ...e };
		return delete t.seed, delete t.rngCursor, {
			public: t,
			private: {}
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: "play" };
		let t = [...e.players].sort((t, n) => e.scores[n].total - e.scores[t].total || e.scores[t].errors - e.scores[n].errors || e.players.indexOf(t) - e.players.indexOf(n)), n = e.scores[t[0]];
		return {
			phase: "done",
			ranking: t,
			winner: t.filter((t) => e.scores[t].total === n.total && e.scores[t].errors === n.errors),
			scores: Object.fromEntries(e.players.map((t) => [t, e.scores[t].total]))
		};
	}
};
//#endregion
//#region src/games/railroadink/interface.ts
function Z(e, t) {
	let n = {
		O: t.tetromino,
		S: t.tetromino,
		Z: t.tetromino,
		L: t.tetromino,
		J: t.tetromino,
		T: t.tetromino,
		bendH: t.renovation,
		bendR: t.renovation,
		stationH: t.renovation,
		stationR: t.renovation,
		overH: t.renovation,
		overR: t.renovation
	};
	if (e.startsWith("canyon")) return t.expansions.canyon;
	if (n[e]) return n[e];
	let r = S[e];
	return r ? r.underground ? [...new Set(r.groups.flat().map((e) => e.kind === "h" ? t.pipe : t.subway))].join(" / ") + (r.station ? ` · ${t.marks.station}` : "") : r.mark === "tower" ? `${t.marks.tower} ${r.amount} · ${t.coins} ${(r.amount ?? 1) * 2 + 1}` : r.mark === "clue" ? `${t.marks.clue} · ${t.movement} ${r.amount ?? 1}` : r.mark ? t.marks[r.mark] ?? t.actions.place : [...new Set(r.groups.flat().map((e) => t.marks[e.kind]))].join(" / ") : t.marks[e] ?? (/^\d+$/.test(e) ? e : t.actions.place);
}
function Tt(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of t) {
		let t = i.type, a, o = n.actions[i.type], s = !1;
		i.type === "place" ? (t += `:${i.die}:${i.duplicate}`, a = e.dice[i.die].face, o = i.duplicate ? n.duplicate : Z(a, n)) : i.type === "special" ? (t += `:${i.id}:${i.as ?? ""}`, a = i.as ?? i.id, o = i.as ? Z(i.as, n) : n.special) : i.type === "path" ? (t += `:${i.die}`, a = e.dice[i.die]?.face, o = Z(a ?? "", n)) : i.type === "weather" ? (t += `:${i.die}`, a = e.dice.filter((e) => e.source === "expansion")[i.die].face, o = Z(a, n)) : i.type === "meteor" ? (t += `:${i.direction}:${i.sacrifice ?? ""}`, a = i.sacrifice ?? [
			"north",
			"east",
			"south",
			"west"
		][i.direction], o = i.sacrifice ? n.sacrifice : Z(a, n), s = !0) : i.type === "startEffect" && e.config.expansion === "desert" && !i.sacrifice ? (a = "arid", o = Z(a, n), s = !0) : i.type === "startEffect" && i.sacrifice ? (t += `:${i.sacrifice}`, a = i.sacrifice, o = n.sacrifice, s = !0) : i.type === "lamp" ? (t += `:${i.axis}:${i.index}`, o = `${i.axis === "row" ? n.row : n.column} ${i.index + 1}`, s = !0) : i.type === "construct" || i.type === "renovate" ? (a = e.dice.find((e) => e.id === (i.type === "construct" ? "construction" : "renovation"))?.face, o = Z(a ?? "", n), a === "free" && (s = !0)) : i.type === "alien" && e.round > 0 && e.dice.find((e) => e.source === "expansion")?.face === "attack" ? (a = "attack", s = !0) : [
			"finish",
			"skipStart",
			"skipEnd",
			"declineBonus"
		].includes(i.type) && (s = !0), r.has(t) || r.set(t, {
			key: t,
			actions: [],
			face: a,
			label: o,
			immediate: s
		}), r.get(t).actions.push(i);
	}
	return [...r.values()];
}
function Et(e, t, n, r, i) {
	let a = (t, n) => de(D(S[e], t, n));
	return a(t, n) === a(r, i);
}
//#endregion
//#region src/games/railroadink/official-symbols.ts
var Dt = {
	ritual: "M17.12 5.16L13.10 7.07L9.93 9.40L7.81 11.51L4.63 16.59L4.00 18.29L4.21 31.62L5.69 35.01L8.66 38.81L12.04 41.78L15.22 43.47L31.94 43.47L35.11 41.78L38.50 38.81L41.46 35.01L42.94 31.62L43.15 29.71L43.58 29.71L43.79 20.61L43.15 20.19L43.37 19.56L42.52 16.59L39.34 11.51L37.23 9.40L34.05 7.07L30.03 5.16L26.22 4.32L20.93 4.32ZM22.84 8.34L29.82 9.40L34.48 12.36L37.23 15.32L37.44 16.38L38.71 17.86L39.98 22.73L39.77 28.23L38.29 32.47L36.80 34.58L33.84 37.76L31.09 39.45L27.70 40.72L24.32 41.14L19.45 40.72L16.06 39.45L13.31 37.76L8.87 32.47L7.17 26.75L7.39 21.25L8.23 18.29L9.29 16.38L9.71 16.38L9.93 15.32L13.52 11.72L16.49 9.82ZM26.65 11.94L22.84 11.94L18.39 13.21L14.58 15.53L13.10 17.02L11.83 19.34L11.41 22.10L13.10 28.02L16.91 34.37L20.08 38.18L21.57 37.97L21.99 37.33L21.78 35.85L16.91 28.87L14.58 23.37L14.79 19.98L16.91 17.44L19.66 15.96L22.62 15.11L26.86 15.11L30.03 17.23L31.51 19.34L32.99 22.73L32.99 24.85L31.72 28.23L30.24 29.50L28.97 29.71L25.80 29.50L22.41 25.90L21.14 22.94L22.84 21.04L25.80 21.04L26.43 22.31L26.65 25.90L28.13 26.54L29.19 25.90L29.40 21.88L28.34 19.56L26.86 18.29L23.68 17.86L21.57 18.29L19.45 19.98L18.18 22.94L18.18 24.42L21.78 29.93L24.74 32.25L28.55 32.89L31.72 32.04L34.05 30.14L35.32 27.60L35.96 22.73L33.42 16.80L32.78 16.59L32.15 15.11L30.24 13.42Z",
	alien: "M31.37 5.02L30.57 4.95L29.99 5.09L29.04 6.04L28.82 7.36L29.11 8.09L29.62 8.60L29.62 9.11L29.18 10.86L27.94 13.20L27.72 13.27L25.61 12.69L23.42 12.39L20.42 12.39L16.85 13.05L14.07 14.15L11.37 15.90L8.60 18.67L5.39 22.61L4.51 24.15L4.07 25.31L4.07 27.21L5.09 29.18L12.18 37.14L14.00 38.67L16.48 40.28L18.38 41.23L21.52 42.32L24.73 42.91L27.94 42.98L29.84 42.76L31.59 42.32L34.44 41.15L36.26 40.06L38.67 37.72L41.52 34.15L42.83 32.18L43.71 30.35L43.93 28.45L43.42 26.70L41.52 24.07L37.43 19.33L33.93 16.19L31.88 14.95L29.26 13.78L29.69 11.81L30.72 9.40L31.01 9.04L31.66 8.96L32.18 8.67L32.76 7.72L32.91 6.99L32.76 6.12L32.32 5.53ZM5.17 25.09L6.04 23.20L7.43 21.45L10.57 18.45L12.18 17.28L14.07 16.41L16.26 15.75L19.40 15.39L22.61 15.53L24.58 15.82L28.23 16.77L31.88 18.23L34.95 19.99L37.87 22.39L41.23 25.90L42.18 27.28L42.76 29.04L42.76 30.13L42.32 31.66L40.57 34.22L37.43 37.21L35.09 38.82L33.05 39.69L30.28 40.35L28.67 40.50L25.02 40.35L22.54 39.91L18.60 38.67L14.36 36.63L11.81 34.88L8.74 32.32L6.34 29.69L5.17 27.36ZM32.25 29.04L31.52 29.62L31.08 30.35L31.08 31.74L31.96 32.76L32.61 33.05L33.56 33.05L34.44 32.47L34.95 31.59L34.95 30.20L34.15 29.26L33.71 29.04ZM15.17 23.42L14.44 23.71L13.93 24.22L13.56 24.88L13.42 25.68L13.78 26.63L14.36 27.21L15.17 27.58L16.04 27.58L16.55 27.36L17.28 26.41L17.50 25.82L17.50 24.95L17.14 24.22L16.41 23.64Z",
	attack: "M6.29 10.71L9.43 23.50L4.21 31.79L12.29 33.43L14.00 43.93L15.36 42.50L17.50 39.71L22.29 34.07L28.86 40.86L29.14 41.36L30.07 42.14L32.29 32.57L39.00 33.14L42.07 33.71L42.71 34.14L43.29 34.00L43.71 33.64L43.50 32.86L42.64 32.00L38.79 25.71L36.36 22.29L36.93 20.71L40.21 14.00L32.71 14.07L31.93 14.21L31.71 14.00L34.50 4.29L34.29 4.29L22.71 14.43L22.29 14.57L15.36 4.00L15.21 4.57L15.14 16.14L15.00 16.29ZM32.64 7.64L30.57 16.29L34.50 16.07L35.79 15.86L37.71 15.86L34.79 20.64L34.50 21.36L36.79 25.29L37.00 25.43L38.14 27.64L40.29 30.79L41.14 31.79L41.29 32.21L37.57 31.71L31.50 31.29L29.36 40.50L28.50 39.64L24.21 34.00L22.64 32.21L18.86 36.50L15.79 40.36L14.79 41.29L14.64 39.71L14.50 39.64L13.93 33.07L13.71 32.86L7.29 31.07L6.00 30.57L11.21 23.93L8.07 14.36L8.29 14.21L15.50 17.93L15.93 18.00L15.79 17.79L15.93 17.57L15.93 16.29L16.07 16.00L16.36 9.43L16.57 8.93L17.14 9.43L21.79 15.57L21.93 15.57ZM33.36 18.57L32.64 18.00L31.57 17.71L28.14 17.79L26.14 18.21L25.07 17.43L23.43 16.86L21.93 16.57L19.50 16.79L18.14 17.43L16.71 18.64L15.93 19.71L15.29 21.71L15.29 23.79L14.50 24.29L13.43 25.36L11.86 27.71L11.36 29.64L11.43 30.43L11.71 31.00L12.57 31.79L13.64 32.07L17.07 32.00L20.86 31.07L26.14 28.79L30.07 26.07L31.79 24.43L32.86 22.79L33.57 21.07L33.64 19.14ZM32.71 19.43L32.71 20.64L32.36 21.93L30.86 23.86L28.50 26.00L22.79 29.29L19.50 30.43L16.71 31.14L13.50 31.07L12.64 30.64L12.29 29.43L12.71 28.29L13.64 26.86L15.29 25.00L15.57 25.14L16.00 25.93L17.14 26.43L18.29 26.43L20.50 25.93L23.50 24.50L25.00 23.50L26.07 22.50L27.07 20.86L27.00 19.07L28.50 18.64L31.07 18.64L32.14 18.93ZM25.93 19.71L26.21 20.21L26.21 20.79L25.86 21.36L23.86 23.29L22.21 24.29L20.43 24.93L18.64 25.29L17.14 25.29L16.43 24.79L16.21 24.21L16.21 22.07L16.50 20.86L17.43 19.07L18.71 18.07L20.29 17.71L22.79 17.71L24.57 18.36Z",
	nuke: "M4.00 30.42L4.00 31.19L4.70 32.17L5.54 33.84L6.23 36.01L7.84 38.38L9.86 40.47L11.96 42.01L14.68 43.27L16.71 43.76L17.47 43.76L18.17 43.41L18.73 42.36L18.87 40.54L19.85 36.64L21.10 33.21L21.10 32.73L21.24 32.66L21.10 30.84L20.89 30.35L18.52 28.40L16.84 26.79L16.50 26.58L15.66 26.58L11.89 27.14L9.03 27.77L5.12 29.58ZM6.44 30.42L9.65 29.17L12.52 28.54L15.80 28.05L19.22 30.91L19.64 31.61L19.64 32.10L19.22 33.28L18.52 37.12L18.38 37.19L17.96 41.03L17.40 42.08L16.91 42.29L15.52 42.29L14.75 42.08L12.66 40.82L10.77 39.15L7.77 35.52L6.93 33.28L5.88 31.47L5.95 30.91ZM24.94 20.44L23.27 20.30L21.45 20.72L20.34 21.49L19.50 22.81L19.15 24.35L19.22 25.61L19.92 27.21L21.17 28.40L22.57 28.82L24.66 28.61L26.27 27.84L26.97 27.21L27.39 26.44L27.80 24.84L27.80 24.14L27.46 22.67L26.97 22.05L26.97 21.84L26.13 21.00ZM22.50 21.49L23.97 21.42L24.66 21.63L25.71 22.53L26.34 23.72L26.62 25.05L26.48 25.95L25.64 27.00L24.73 27.56L23.69 27.77L22.57 27.63L21.24 26.65L20.68 25.68L20.40 24.56L20.40 23.37L20.54 23.02L21.31 22.05ZM42.32 19.95L41.35 19.95L39.25 20.72L37.02 21.28L31.57 22.12L29.83 23.09L29.41 23.86L29.06 26.51L28.15 28.12L28.29 29.51L32.34 34.89L33.11 35.66L35.20 37.12L35.97 38.10L36.74 38.66L37.44 38.66L38.00 38.17L39.25 36.22L41.21 33.98L42.32 32.10L43.23 29.86L43.72 28.05L43.93 26.51L43.93 24.00L43.30 20.93L43.02 20.44ZM41.70 21.49L42.12 21.98L42.67 23.37L42.67 25.40L42.39 27.07L41.56 29.72L40.58 32.10L39.95 33.14L38.55 34.75L37.37 36.57L36.81 36.98L36.25 36.98L35.48 36.50L33.67 34.75L30.04 29.72L30.04 29.17L30.74 27.21L31.16 25.19L31.43 24.63L32.62 23.72L37.65 22.60L40.44 21.49ZM27.39 4.80L27.04 4.66L23.27 4.45L22.08 4.17L19.71 4.17L15.94 4.94L14.75 5.36L12.59 6.48L10.98 7.73L9.31 9.62L9.17 10.04L9.31 10.88L12.94 14.16L16.29 18.14L17.75 19.25L18.38 19.46L19.36 19.46L21.73 18.55L23.69 18.14L24.73 17.58L27.32 10.81L27.94 7.94L27.94 5.71L27.73 5.15ZM25.85 6.34L26.34 7.18L25.92 9.76L25.29 11.99L23.69 16.11L22.92 16.67L21.59 16.95L19.85 17.65L18.80 17.79L17.68 17.23L14.68 13.81L13.49 12.62L12.24 11.71L11.54 10.81L11.75 9.83L12.80 8.50L14.26 7.53L16.22 6.76L20.34 5.85L21.80 5.85L23.69 6.20L25.43 6.20Z",
	fruit: "M43.85 4.00L36.76 4.00L36.76 7.35L36.53 7.66L29.52 7.66L29.37 11.31L22.13 11.31L22.13 12.76L22.29 12.84L22.13 12.99L22.29 13.14L22.13 13.30L22.13 14.82L18.63 14.90L18.55 18.48L7.81 18.48L7.81 21.98L7.66 22.13L4.15 22.13L4.08 32.95L7.12 32.95L7.12 33.33L7.73 33.33L7.73 36.61L18.48 36.61L18.55 29.45L22.06 29.37L22.13 40.11L25.79 40.27L25.79 43.85L36.69 43.85L36.69 40.27L40.34 40.11L40.34 29.37L36.76 29.37L36.69 25.71L33.03 25.64L33.03 18.63L36.69 18.48L36.76 11.24L43.85 11.24ZM33.03 11.24L33.10 18.40L32.19 18.55L29.45 18.48L29.45 25.64L25.87 25.71L25.87 29.22L25.71 29.37L22.29 29.37L22.21 22.13L18.63 22.13L18.55 18.63L22.21 18.55L22.21 14.90L29.45 14.90L29.52 11.31Z",
	pluck: "M23.49 4.00L20.69 4.41L17.41 5.43L14.82 6.73L12.70 8.16L9.90 10.83L8.54 12.60L7.45 14.38L6.08 17.52L5.54 19.43L5.54 19.90L5.40 19.97L5.40 20.66L5.26 20.72L5.06 22.63L5.06 25.30L5.67 29.05L6.90 32.46L8.81 35.67L10.18 37.38L11.54 38.74L12.77 39.77L15.23 41.41L18.78 42.98L22.46 43.80L26.22 43.93L28.81 43.59L31.41 42.91L34.14 41.75L36.59 40.25L38.37 38.81L40.28 36.83L42.05 34.38L42.74 32.87L24.99 23.93L42.87 15.06L40.96 11.92L39.32 10.01L37.28 8.16L34.82 6.53L32.23 5.30L29.22 4.41L26.42 4.00Z",
	ghost: "M13.26 7.52L10.58 9.92L10.58 10.13L10.02 10.62L10.02 10.83L9.04 11.96L8.54 13.01L8.26 13.23L8.33 13.37L8.05 13.65L7.77 14.56L7.06 15.90L6.92 17.03L6.71 17.24L6.78 17.45L6.36 18.65L6.29 41.32L7.06 43.51L7.70 43.93L9.04 43.44L9.53 43.01L9.81 42.45L11.50 40.97L11.99 40.27L12.35 40.13L12.35 39.99L12.91 39.92L13.40 39.63L14.04 39.63L14.95 40.55L15.16 40.48L16.01 41.54L15.94 41.75L16.50 42.52L16.78 42.66L16.78 42.87L17.06 42.80L17.63 43.37L17.63 43.58L18.61 43.93L20.09 43.44L20.44 43.08L20.51 42.73L20.94 42.38L21.22 41.75L21.50 41.68L21.57 41.39L21.78 41.32L22.27 40.34L22.91 39.92L23.75 39.77L23.82 39.63L25.02 39.77L25.09 39.99L26.50 41.04L26.57 41.32L26.92 41.61L26.78 41.75L27.49 42.59L28.54 43.44L28.61 43.72L29.32 43.93L31.08 43.44L32.13 42.38L32.20 42.10L32.91 41.61L33.19 40.90L34.18 39.92L34.53 39.92L34.81 39.63L35.58 39.63L36.50 40.48L36.85 40.48L37.77 41.54L38.05 42.17L38.54 42.45L39.67 43.79L40.02 43.93L40.65 43.79L41.50 43.30L41.64 43.01L41.64 18.08L40.80 15.76L40.80 15.34L40.09 14.00L40.09 13.72L38.26 10.83L36.01 8.44L33.61 6.61L32.42 6.11L31.78 5.62L31.29 5.55L30.94 5.27L30.30 5.20L29.60 4.77L26.29 4.07L22.49 4.00L19.88 4.42L17.35 5.20L16.36 5.76L16.08 5.76ZM34.04 15.41L35.73 15.41L35.80 15.55L36.92 15.76L37.98 16.46L39.18 17.94L39.74 19.70L39.74 20.69L39.46 21.39L39.53 21.61L38.75 23.15L37.49 24.28L35.73 24.99L33.96 24.99L31.78 24.00L31.15 23.37L30.16 21.61L30.09 20.69L29.95 20.55L29.95 19.85L30.16 19.56L30.09 19.14L30.80 17.52L31.78 16.39L32.63 16.04L32.91 15.76L33.96 15.55ZM36.22 17.94L36.15 18.08L35.65 18.15L34.67 19.14L34.53 19.63L34.67 21.25L35.44 22.10L35.94 22.38L37.56 22.38L38.40 21.82L38.40 21.61L38.82 21.18L38.96 19.70L38.40 18.58L37.77 18.15L37.20 18.08L37.13 17.94ZM19.32 15.41L21.08 15.41L21.08 15.55L21.92 15.69L23.19 16.39L24.39 17.73L24.95 19.14L24.88 19.63L25.09 19.77L24.95 21.25L24.32 22.80L23.26 24.00L22.20 24.63L21.15 24.85L21.08 24.99L19.32 24.99L19.25 24.85L18.12 24.63L17.49 24.28L16.29 23.15L15.73 22.17L15.37 21.04L15.30 19.77L15.94 17.80L17.13 16.39L18.12 15.76L19.25 15.55ZM21.57 17.94L20.80 18.30L20.02 19.14L19.88 19.56L19.88 21.04L20.73 22.10L21.29 22.38L22.91 22.38L23.75 21.75L24.32 20.69L24.32 19.70L24.04 19.00L23.12 18.15L22.42 17.94Z",
	free: "M4.00 4.00L4.00 43.92L43.92 43.92L43.92 4.00ZM6.61 6.69L41.24 6.61L41.31 41.24L6.69 41.31Z",
	destroy: "M42.89 4.56L41.85 4.00L41.22 4.07L39.97 5.04L39.42 6.15L8.51 6.15L7.96 5.11L7.19 4.42L6.50 4.07L5.74 4.14L4.56 5.04L4.07 5.81L4.07 6.71L5.04 7.96L5.88 8.44L5.88 39.49L4.62 40.46L4.07 41.36L4.14 42.19L5.04 43.38L5.67 43.79L6.50 43.93L7.40 43.44L8.38 42.26L39.62 42.26L40.46 43.31L41.43 43.86L42.19 43.79L43.38 42.89L43.93 41.85L43.86 41.22L42.89 39.97L41.99 39.42L41.99 8.44L43.31 7.47L43.86 6.50L43.79 5.74ZM38.24 8.51L39.62 8.58L39.56 10.18L39.07 9.35ZM8.24 10.74L8.38 10.74L8.72 11.57L9.49 12.33L10.25 12.75L10.81 12.75L11.71 12.26L12.26 11.71L12.75 10.81L12.75 10.25L12.47 9.69L11.36 8.51L36.50 8.51L35.60 9.49L35.18 10.25L35.18 10.81L35.39 11.29L36.22 12.26L36.92 12.68L37.68 12.75L38.44 12.33L39.14 11.64L39.56 10.94L39.62 36.85L38.31 35.46L37.26 35.11L36.57 35.39L35.60 36.29L35.18 37.06L35.18 37.61L35.74 38.58L36.43 39.21L37.12 39.56L37.68 39.56L38.44 39.14L39.21 38.38L39.56 37.75L39.62 39.83L8.31 39.90ZM10.32 35.18L9.62 35.53L8.86 36.22L8.44 36.92L8.38 37.68L8.79 38.44L9.56 39.21L10.18 39.56L10.74 39.62L11.71 39.14L12.33 38.51L12.68 37.96L12.82 37.26L12.54 36.57L11.99 35.88L11.08 35.25ZM32.89 30.81L32.12 31.15L31.29 31.99L30.94 32.61L30.88 33.17L31.15 33.86L31.78 34.62L32.61 35.18L33.31 35.25L34.21 34.76L34.69 34.28L35.18 33.51L35.25 32.82L34.90 32.06L34.28 31.36L33.51 30.88ZM14.69 30.81L13.86 31.22L13.10 31.99L12.75 32.61L12.68 33.24L13.51 34.56L14.28 35.11L15.11 35.25L15.94 34.83L16.71 34.07L17.06 33.44L17.12 32.82L16.71 31.99L15.94 31.22L15.32 30.88ZM28.44 26.50L27.75 26.85L27.06 27.47L26.57 28.24L26.50 28.93L26.92 29.76L27.68 30.53L28.31 30.88L28.86 30.94L29.56 30.67L30.46 29.83L30.88 29.14L30.94 28.58L30.67 27.89L30.18 27.26L29.14 26.57ZM19.00 26.50L17.75 27.26L17.06 28.31L16.99 28.86L17.47 29.83L18.10 30.46L18.79 30.88L19.42 30.94L20.25 30.53L21.01 29.76L21.43 28.93L21.43 28.44L21.08 27.75L20.46 27.06L19.69 26.57ZM23.65 21.08L22.47 21.71L21.71 22.47L21.08 23.58L21.08 24.28L21.36 24.90L22.12 25.88L22.82 26.43L24.07 26.85L25.04 26.50L26.22 25.46L26.85 24.42L26.92 23.79L26.64 23.03L25.67 21.85L24.56 21.15ZM23.93 23.58L24.35 23.93L24.00 24.35L23.65 24.00ZM28.58 16.99L27.61 17.47L26.92 18.17L26.57 18.79L26.50 19.42L26.92 20.25L27.68 21.01L28.51 21.43L29.00 21.43L29.69 21.08L30.39 20.46L30.94 19.56L30.94 18.93L30.11 17.68L29.14 17.06ZM18.93 16.99L18.24 17.33L17.61 17.89L17.12 18.58L16.99 19.35L17.47 20.32L18.17 21.01L19.00 21.43L19.49 21.43L20.25 21.01L21.01 20.25L21.43 19.42L21.43 18.93L21.08 18.24L20.39 17.47L19.56 16.99ZM32.82 12.68L32.26 12.89L31.36 13.65L30.88 14.42L30.81 15.04L31.57 16.29L32.61 16.99L33.17 17.06L33.86 16.78L34.62 16.15L35.18 15.32L35.25 14.62L34.90 13.93L34.28 13.24L33.65 12.82ZM14.69 12.68L13.79 13.17L13.24 13.72L12.75 14.56L12.75 15.25L13.24 16.08L13.79 16.64L14.49 17.06L15.11 17.12L16.01 16.64L16.50 16.15L16.99 15.39L17.06 14.56L16.78 14.00L16.01 13.17L15.32 12.75ZM9.69 8.51L8.86 9.35L8.31 10.39L8.24 8.58Z",
	move: "M4.00 4.00L4.00 43.92L43.92 43.92L43.92 4.00ZM6.61 6.69L41.24 6.61L41.31 41.24L6.69 41.31ZM24.04 10.68L18.82 15.21L18.82 17.67L22.89 14.13L23.04 14.21L23.04 22.89L14.44 22.96L14.44 22.73L17.90 18.74L15.44 18.74L10.91 24.04L15.44 29.26L17.90 29.26L14.44 25.27L14.44 25.04L22.96 25.04L23.04 33.48L22.89 33.56L18.82 30.03L18.82 32.48L24.04 37.01L29.34 32.48L29.34 30.03L25.27 33.56L25.11 33.48L25.11 25.04L33.40 24.96L33.40 25.19L29.95 29.18L32.41 29.18L36.94 23.88L32.41 18.66L29.95 18.66L33.48 22.73L33.40 22.89L25.11 22.81L25.11 14.21L25.34 14.21L29.34 17.67L29.34 15.21Z",
	cactus: "M22.19 4.00L19.42 5.11L18.31 6.78L18.31 17.61L17.75 17.89L16.64 16.78L16.36 10.39L13.86 8.72L11.64 9.28L10.81 10.39L10.81 16.78L11.36 18.44L13.31 20.67L18.31 23.17L18.31 40.94L19.69 42.89L21.64 43.72L23.86 43.72L25.81 42.89L27.19 40.94L27.19 35.11L32.75 31.50L36.08 27.61L36.92 25.11L36.92 16.50L34.69 15.11L32.75 15.39L31.36 16.50L31.08 25.11L30.25 27.06L27.47 29.28L27.19 7.06L25.81 4.83Z",
	oasis: "M4.00 23.78L4.26 24.83L4.96 25.62L6.88 26.66L8.63 27.28L14.13 28.41L22.17 29.02L30.64 28.76L36.84 27.89L39.28 27.28L41.82 26.31L42.95 25.62L43.48 25.09L43.91 24.22L43.83 23.43L43.04 22.38L41.03 21.25L39.28 20.64L33.08 19.41L26.01 18.89L17.28 19.15L10.72 20.11L7.58 20.99L5.48 21.95L4.44 22.82ZM4.61 23.69L5.48 22.65L6.71 21.95L9.50 20.99L12.30 20.38L19.11 19.59L27.14 19.50L33.34 20.03L39.02 21.16L41.21 21.95L42.43 22.65L43.13 23.34L43.30 24.22L42.43 25.27L41.21 25.97L38.76 26.84L35.62 27.54L28.80 28.32L20.77 28.41L13.87 27.80L9.15 26.84L7.32 26.23L5.48 25.27L4.79 24.57ZM31.25 25.62L29.59 25.35L26.71 25.88L25.14 25.88L24.26 25.53L24.09 25.79L25.40 26.23L26.45 26.23L29.15 25.70L31.16 25.88ZM13.96 24.31L13.78 24.04L12.91 23.87L9.41 24.39L7.93 24.39L7.06 24.04L6.79 24.13L6.88 24.39L8.19 24.74L9.76 24.66L11.86 24.22ZM40.07 22.82L38.41 22.56L35.53 23.08L34.04 23.08L33.08 22.73L32.91 23.00L34.22 23.43L35.27 23.43L37.97 22.91L39.98 23.08ZM24.17 21.95L22.52 21.69L19.72 22.21L18.15 22.21L17.19 21.86L17.01 22.12L18.32 22.56L19.28 22.56L22.08 22.03L24.09 22.21Z",
	sheep: "M8.53 13.81L8.72 15.70L4.57 20.04L4.00 22.87L4.38 23.81L5.51 24.57L8.34 24.75L11.92 24.00L13.06 26.08L14.75 26.45L15.13 27.96L17.02 27.96L17.40 28.34L17.40 30.98L16.26 37.40L17.58 37.21L18.72 37.77L18.91 38.34L20.04 37.96L20.98 38.53L21.55 38.34L21.92 30.60L23.25 29.85L23.81 31.17L24.75 31.74L26.26 31.55L27.58 30.60L28.53 31.55L30.23 32.30L32.11 31.92L31.74 37.96L33.06 37.77L34.19 38.53L36.45 38.72L37.40 29.47L39.85 28.53L40.42 26.45L41.55 26.08L42.30 25.13L42.49 23.43L43.81 20.79L43.62 18.72L42.49 17.77L42.68 15.70L42.30 14.19L41.55 13.25L39.28 12.87L38.15 10.79L36.26 9.66L34.19 9.85L33.06 8.91L31.55 8.91L30.04 9.85L28.53 8.91L26.64 8.91L24.38 9.66L23.43 10.60L22.49 9.85L19.85 10.23L18.15 11.55L17.58 12.87L16.64 12.87L15.89 13.81L15.13 12.49L13.25 11.92L11.55 12.11L10.79 13.43L8.91 13.43ZM33.81 31.36L33.43 35.89L33.06 36.08L32.68 35.70L32.87 32.11L33.25 31.36ZM21.36 30.42L20.79 36.45L20.23 36.64L20.04 30.60ZM36.64 29.85L36.08 35.32L35.51 36.83L35.13 31.36ZM18.34 29.85L19.09 30.60L18.34 35.51L17.77 35.70L17.96 30.04ZM15.70 17.77L15.70 21.92L14.75 24.75L13.81 25.51L12.87 24.38L12.68 23.25L12.87 18.91L13.43 17.77ZM8.53 16.83L10.04 17.40L10.98 18.34L12.49 18.53L11.92 23.43L11.55 23.81L6.26 24.00L4.94 23.25L4.75 21.74L5.51 20.04ZM9.47 14.38L11.74 14.19L12.11 12.68L14.19 12.68L16.08 14.94L16.08 16.08L15.51 17.02L13.62 17.02L13.25 16.08L12.68 16.08L12.30 17.21L11.55 17.58L10.79 15.89L9.47 16.08L9.85 15.32ZM16.26 14.00L17.21 13.25L18.53 13.43L18.53 11.92L20.98 10.42L22.30 10.42L23.06 11.92L23.62 11.92L25.13 10.04L27.58 9.47L28.91 9.85L29.85 10.79L30.79 10.60L31.74 9.66L32.68 9.66L33.81 11.17L35.89 10.42L37.77 11.92L38.53 13.62L40.79 13.81L41.74 15.32L41.74 18.53L42.87 19.47L42.87 20.60L41.55 23.06L41.36 24.75L40.42 25.51L39.28 25.51L39.28 27.77L37.40 28.34L36.64 27.58L35.89 27.58L35.89 28.91L34.38 30.60L32.87 29.28L32.30 29.28L31.92 30.79L31.17 31.36L29.28 30.98L28.15 29.28L27.58 29.09L26.26 30.60L24.75 30.98L24.19 30.42L23.81 28.15L21.74 29.85L19.85 29.85L18.53 29.09L18.15 27.21L16.45 27.77L15.13 27.21L14.94 25.70L15.51 25.13L16.45 21.36L16.26 17.21L16.83 15.51Z",
	ufo: "M43.75 24.34L43.07 23.83L27.78 17.12L31.26 12.96L32.96 10.50L33.47 9.31L33.55 8.29L33.38 7.78L32.87 7.27L32.11 6.93L29.56 7.01L25.74 8.03L23.36 9.05L18.35 7.69L14.79 7.69L12.66 8.37L10.37 9.82L8.08 12.20L6.80 14.32L6.21 16.02L5.95 18.48L6.21 20.60L6.97 23.75L6.21 24.42L4.51 28.33L4.08 29.94L4.08 32.07L4.51 33.09L5.27 33.85L6.04 34.11L7.99 33.94L10.79 32.49L15.89 28.67L20.65 36.23L23.02 40.39L23.53 40.99L23.79 40.99L24.13 40.73L24.13 39.88L17.16 28.67L16.82 27.74L22.43 22.73L29.14 28.59L29.73 28.67L29.90 27.74L23.28 21.96L26.93 17.97L42.90 25.02L43.75 25.02L43.58 24.76ZM23.36 10.24L23.02 12.20L22.34 13.64L20.31 16.44L17.42 19.24L15.21 21.03L13.00 22.39L10.11 23.41L8.16 23.58L7.23 19.75L7.14 17.38L7.31 16.27L8.50 13.55L9.44 12.28L11.47 10.33L13.43 9.22L15.97 8.63L19.37 8.97ZM32.37 8.29L32.37 9.22L31.86 10.24L30.24 12.45L26.68 16.61L21.66 21.96L11.39 30.79L7.91 32.83L6.38 33.09L5.61 32.75L5.19 31.81L5.27 29.77L6.12 27.23L7.40 24.76L10.03 24.51L12.83 23.66L15.55 22.13L18.44 19.84L21.07 17.21L23.11 14.57L24.13 12.37L24.72 9.56L29.48 8.12L31.69 7.95Z",
	tree: "M12.48 43.01L12.48 43.84L38.81 43.84L38.81 43.01ZM24.82 4.00L13.63 4.00L10.83 6.63L9.84 8.44L9.02 11.41L9.35 15.36L11.00 18.65L14.12 21.45L18.24 22.93L18.24 37.09L18.90 37.58L19.88 37.09L19.88 22.93L23.34 21.94L25.98 20.30L28.12 17.66L29.27 14.53L29.43 11.74L28.61 8.44L26.96 5.81ZM17.91 4.16L21.20 4.33L23.84 5.48L26.63 8.44L27.62 11.41L27.46 14.53L25.81 17.83L23.34 19.97L20.38 20.95L16.59 20.63L14.12 19.31L12.15 17.17L10.83 13.88L11.00 10.58L12.15 7.95L14.62 5.48Z",
	lamp: "M29.50 5.88L28.43 5.88L25.21 4.00L21.99 4.00L20.64 5.34L19.57 8.56L19.03 14.20L19.30 28.70L20.64 39.17L19.57 39.97L15.01 40.51L10.17 42.12L10.17 43.73L19.57 41.32L23.60 41.32L32.72 43.19L32.19 41.58L22.79 39.70L22.26 39.17L21.18 31.92L20.64 23.33L20.91 10.71L21.45 7.76L23.33 5.34L26.55 6.68L27.62 7.76L27.09 18.23L28.16 17.96L28.43 15.81L29.23 14.74L32.99 14.47L36.21 17.69L37.83 17.42L37.83 16.62L32.19 10.44ZM29.23 9.64L31.38 12.32L31.11 13.13L28.97 12.59Z",
	clover: "M42.59 14.29L41.33 12.96L39.52 12.09L37.56 12.02L34.96 12.64L35.43 10.76L35.43 9.03L35.12 7.54L34.02 6.04L32.53 5.02L30.80 4.63L28.68 4.79L27.65 5.18L26.16 6.51L25.93 6.51L24.43 5.26L22.23 4.71L20.11 4.86L18.54 5.49L17.28 7.14L16.89 8.48L16.97 10.84L17.60 12.41L17.75 13.35L15.55 12.88L13.90 12.88L11.86 13.51L10.84 14.29L10.05 15.55L9.58 16.73L9.58 19.32L10.37 21.21L11.47 22.15L10.60 23.10L9.74 24.98L9.58 27.10L10.05 29.07L10.68 30.09L12.25 31.19L13.67 31.50L16.18 31.19L16.42 31.35L14.06 33.71L11.86 35.51L7.14 38.42L4.08 39.76L4.00 40.94L4.16 41.33L7.14 43.14L7.69 43.29L8.48 43.21L10.76 41.88L12.72 40.15L13.12 39.99L15.08 38.11L17.60 35.12L17.91 35.28L17.83 35.59L18.07 36.30L19.01 37.79L20.11 38.58L21.52 39.05L23.49 39.05L24.59 38.73L25.77 38.18L27.03 37.01L27.34 37.01L28.83 38.11L31.03 38.58L32.68 38.42L34.49 37.48L35.75 35.91L36.38 33.71L36.22 32.06L35.83 30.56L35.59 30.40L35.43 29.85L35.67 29.78L36.22 30.09L38.18 30.56L40.31 30.56L41.49 30.25L42.27 29.78L42.82 29.23L43.53 28.05L43.92 26.55L43.76 24.12L42.51 21.76L41.72 21.21L42.82 19.80L43.29 18.62L43.45 16.50L43.14 15.32ZM41.17 14.29L42.27 16.10L42.43 17.44L42.27 18.22L41.64 19.56L40.70 20.58L39.21 21.21L39.28 21.45L41.41 22.31L42.11 23.10L42.59 24.04L42.90 25.30L42.90 26.24L42.43 27.81L41.96 28.44L40.23 29.46L38.26 29.46L36.93 29.15L35.04 28.28L31.27 25.77L30.72 25.22L30.48 25.30L30.48 25.61L32.84 27.97L33.16 28.68L34.49 30.33L35.04 31.66L35.28 33.16L35.20 34.41L34.57 35.75L33.39 36.77L32.13 37.40L30.17 37.40L29.07 36.93L28.44 36.30L28.20 36.30L27.18 34.65L27.26 34.33L26.87 34.41L26.55 35.75L26.08 36.46L25.45 37.08L24.51 37.63L22.55 38.03L21.21 37.79L20.50 37.48L19.25 36.30L19.09 35.51L18.85 35.28L18.77 34.33L19.40 32.29L20.74 29.30L20.50 29.23L19.32 31.11L18.38 32.13L17.91 33.00L17.52 33.31L17.60 33.47L17.12 33.78L16.50 34.81L16.18 34.96L16.18 35.20L15.71 35.51L13.27 38.26L10.60 40.54L8.09 42.19L7.61 42.11L5.26 40.62L5.26 40.39L5.89 40.31L8.56 38.97L11.31 37.32L14.45 34.96L17.52 31.98L20.42 28.13L20.58 27.65L20.35 27.58L17.99 29.30L16.42 30.01L15.32 30.33L13.67 30.40L12.64 30.09L11.62 29.38L10.84 28.05L10.84 27.50L10.60 27.26L10.76 27.03L10.60 26.87L10.60 26.24L11.23 24.43L11.15 24.28L11.86 23.65L11.94 23.33L13.59 22.39L13.90 22.39L13.90 22.07L12.80 21.76L11.39 20.58L10.60 18.93L10.60 17.20L10.92 16.18L12.09 14.77L13.74 13.98L15.47 13.98L16.57 14.22L18.85 15.32L21.60 17.20L22.31 17.99L22.86 18.07L21.45 16.18L20.82 15.63L20.35 14.77L19.87 14.45L18.46 12.02L18.46 11.54L17.99 10.52L17.99 8.95L17.83 8.79L18.54 7.22L19.01 6.67L20.35 5.96L21.13 5.81L22.94 5.89L24.20 6.44L25.45 7.61L25.77 8.17L25.77 8.64L26.16 9.19L26.48 8.17L27.10 7.14L27.58 6.83L27.58 6.59L28.75 5.89L30.33 5.65L31.35 5.81L33.23 6.83L33.94 7.85L34.41 9.11L34.26 11.23L33.16 13.74L31.58 16.10L30.80 16.81L30.80 17.05L31.03 17.20L32.21 16.02L33.08 15.55L33.78 14.84L34.96 14.06L37.40 13.12L39.21 13.19L40.23 13.59Z",
	rainbow: "M19.03 29.01L18.42 30.09L17.81 31.92L17.13 35.84L19.30 35.91L19.91 32.26L20.85 30.09L21.60 29.35L22.27 29.01L23.97 28.81L24.85 28.94L25.93 29.41L27.01 30.63L27.55 32.73L27.69 35.91L29.79 35.91L29.79 33.88L29.38 31.04L28.97 29.82L28.50 29.01L27.21 27.72L26.13 27.11L24.10 26.64L22.75 26.71L21.60 26.98L20.72 27.38L20.04 27.86ZM12.87 35.91L14.96 35.91L15.44 33.20L16.25 30.09L17.20 27.93L18.35 26.37L19.43 25.49L21.33 24.61L23.36 24.20L25.18 24.20L27.35 24.74L28.43 25.35L29.25 26.17L29.99 27.25L30.80 29.08L31.61 32.60L32.02 35.84L34.19 35.84L33.31 30.09L33.17 30.02L32.43 27.38L31.68 25.90L30.19 24.07L28.77 23.05L26.88 22.31L25.25 22.04L22.21 22.17L20.11 22.78L18.15 23.80L16.45 25.29L15.10 27.32L14.42 28.87L13.61 31.58ZM39.26 35.78L39.13 35.64L39.13 34.69L38.72 32.26L38.59 32.19L38.31 29.96L37.64 27.25L36.55 24.14L35.20 21.77L33.31 19.60L31.48 18.31L28.30 17.10L25.18 16.69L22.14 16.83L19.70 17.30L17.87 17.91L15.03 19.40L12.87 21.29L11.24 23.59L9.96 26.44L9.14 29.01L8.33 33.00L8.06 35.44L7.93 35.57L7.93 35.91L9.96 35.91L10.09 35.78L10.84 31.11L11.65 27.93L11.78 27.86L12.32 26.17L13.14 24.61L14.08 23.19L15.03 22.17L16.79 20.82L19.43 19.60L22.61 18.92L24.98 18.86L27.28 19.06L29.52 19.74L31.41 20.82L32.70 21.97L34.19 24.14L35.13 26.30L36.49 31.72L37.10 35.91L39.19 35.91ZM4.00 35.24L4.00 35.91L6.10 35.91L6.64 31.65L7.99 25.49L9.48 21.83L10.29 20.48L11.92 18.45L14.29 16.62L17.20 15.27L20.92 14.39L22.88 14.19L25.59 14.19L29.11 14.73L31.68 15.61L33.92 16.89L36.22 19.13L37.91 21.77L39.47 25.49L40.95 31.24L41.70 35.71L41.83 35.91L43.93 35.84L42.65 29.01L41.02 23.53L39.53 20.28L37.71 17.57L35.20 15.20L34.12 14.46L32.22 13.51L28.97 12.49L25.05 12.02L23.02 12.02L20.24 12.29L17.40 12.97L15.64 13.58L13.75 14.46L11.85 15.68L9.41 18.04L7.65 20.75L6.44 23.46L5.49 26.64L5.08 28.94L4.95 29.01Z",
	rain: "M11.04 30.24L10.56 30.72L10.56 31.69L16.35 41.75L17.64 43.76L18.29 43.92L18.85 43.68L19.17 43.20L19.17 42.63L12.09 30.40L11.61 30.16ZM18.61 30.16L18.21 30.80L18.29 31.53L23.28 40.22L24.08 41.18L24.64 41.26L25.13 41.10L25.53 40.46L25.45 39.90L19.98 30.40L19.33 30.00ZM27.14 29.92L26.66 30.48L26.82 31.44L31.32 39.01L33.74 43.44L34.30 43.92L35.03 43.92L35.59 43.28L35.43 42.31L28.51 30.40L27.94 29.84L27.46 29.75ZM35.35 29.59L34.78 30.16L34.78 30.80L35.03 31.36L35.59 32.09L39.53 39.17L40.18 39.81L41.06 39.81L41.55 39.25L41.55 38.61L36.56 30.16L36.56 29.92L36.15 29.59ZM42.99 18.49L42.03 15.99L40.18 13.82L38.00 12.45L35.19 11.81L34.95 10.12L34.22 8.35L33.34 7.06L32.21 5.93L30.92 5.05L28.83 4.24L27.54 4.00L26.09 4.00L23.68 4.56L21.67 5.69L20.30 6.98L19.17 8.75L17.96 8.35L15.95 8.27L14.02 8.75L12.57 9.63L11.53 10.68L10.72 12.05L10.24 13.50L10.24 14.14L7.66 15.43L5.89 17.28L5.17 18.65L4.76 19.94L4.76 22.83L5.57 25.01L6.05 25.81L7.18 27.02L9.11 28.23L10.96 28.79L35.43 28.71L37.44 28.23L38.73 27.66L40.58 26.29L41.71 25.01L42.51 23.64L42.99 22.11L42.99 21.22L43.15 21.14ZM41.46 18.41L41.63 21.46L40.74 23.80L38.97 25.73L37.60 26.54L35.27 27.18L11.20 27.26L9.92 26.94L8.14 25.89L6.86 24.36L6.13 22.19L6.13 20.58L6.78 18.65L7.58 17.52L9.51 16.07L11.61 15.35L11.61 14.14L11.77 14.06L11.77 13.42L12.09 12.61L13.46 10.84L14.91 10.04L15.79 9.79L17.48 9.79L19.65 10.60L20.22 10.20L20.78 8.83L22.47 6.98L24.56 5.85L26.09 5.53L27.54 5.53L28.99 5.85L30.28 6.41L31.32 7.14L32.29 8.19L33.18 9.63L33.74 11.57L33.74 12.93L34.06 13.26L36.31 13.50L37.28 13.82L38.89 14.70L40.42 16.31Z",
	towerGlyph: "M23.43 4.00L23.34 10.64L19.76 10.72L19.85 14.13L19.68 14.48L15.57 14.48L15.57 43.91L32.25 43.91L32.34 14.74L32.25 14.48L28.32 14.48L28.15 10.72L24.22 10.64L24.31 4.09ZM16.45 15.09L31.55 15.18L31.47 43.30L16.36 43.21ZM25.27 18.59L24.92 18.76L24.92 42.17L25.70 42.25L25.88 18.76ZM22.65 18.59L22.12 18.76L22.21 42.17L22.38 42.34L23.08 42.17L23.08 18.76ZM20.55 11.42L27.36 11.34L27.45 14.39L20.64 14.48L20.46 14.31Z",
	clue: "M38.13 6.61L32.70 4.22L28.57 4.22L23.57 6.17L20.30 9.22L18.13 13.35L17.70 16.17L18.13 19.65L19.43 22.91L17.04 24.87L4.87 38.35L4.87 40.74L6.61 42.48L8.78 43.78L10.96 42.91L24.43 27.91L29.65 29.43L33.78 29.00L36.83 27.70L40.52 24.65L42.91 19.43L42.91 14.22L41.17 10.09ZM28.57 5.52L32.48 5.52L37.04 7.48L40.52 11.39L41.83 15.74L41.17 20.74L39.22 24.00L36.39 26.61L31.61 28.13L27.26 27.70L23.78 25.96L20.74 22.70L19.22 18.57L19.22 14.87L20.96 10.30L25.30 6.61ZM32.48 6.83L27.91 6.61L24.65 7.70L21.39 10.96L20.52 14.22L20.96 14.43L21.83 13.13L25.74 9.87L31.17 7.48L31.61 7.70Z",
	footstep: "M33.77 20.74L31.91 26.95L31.91 30.98L35.63 32.22L39.04 32.22L41.83 30.98L43.69 27.88L42.76 24.78L38.11 21.67ZM4.31 21.36L4.00 23.53L4.93 25.40L10.20 28.81L16.71 30.36L23.84 30.05L25.40 29.12L26.64 19.81L21.98 16.71L16.71 15.47L12.37 15.78L7.72 17.64Z",
	airport: "M4.00 4.00L4.00 43.83L43.83 43.83L43.83 4.00ZM35.30 17.57L35.48 35.83L18.26 36.00L22.09 31.65L32.00 31.65L32.00 21.04ZM29.57 11.65L25.91 15.83L16.17 15.83L16.17 26.26L12.52 30.09L12.35 11.83Z",
	cloud: "M43.92 28.27L43.15 26.12L42.62 25.35L41.38 24.27L40.46 23.81L39.08 23.42L37.31 23.42L37.31 21.04L36.77 19.12L35.92 17.50L34.77 16.04L33.23 14.81L31.23 13.88L30.00 13.58L27.46 13.50L25.85 13.81L23.54 14.81L21.77 16.35L21.00 17.27L20.15 18.81L17.54 18.81L16.08 19.19L14.92 19.81L13.23 21.27L12.46 22.35L11.85 23.88L10.38 23.42L8.69 23.42L7.54 23.73L6.31 24.42L5.23 25.42L4.46 26.65L4.00 28.27L4.00 29.58L4.46 31.27L5.15 32.35L6.38 33.50L8.15 34.35L39.23 34.42L41.23 33.73L42.69 32.50L43.23 31.73L43.77 30.35ZM42.85 28.35L42.77 29.88L42.08 31.50L41.15 32.50L40.54 32.88L38.77 33.42L8.54 33.35L6.77 32.50L6.08 31.81L5.31 30.50L5.08 29.42L5.08 28.27L5.62 26.73L6.46 25.65L7.54 24.88L8.69 24.50L10.38 24.50L12.08 25.27L12.46 25.27L12.77 25.04L12.92 24.04L13.46 22.81L13.92 22.12L15.46 20.73L16.08 20.35L17.77 19.81L20.77 19.96L21.92 17.81L23.69 16.04L24.62 15.42L25.92 14.88L28.08 14.50L29.62 14.58L31.85 15.27L33.31 16.19L34.85 17.81L35.85 19.65L36.31 21.81L36.23 23.81L36.08 24.12L36.23 24.65L36.69 24.81L37.69 24.50L39.08 24.50L40.62 25.04L42.15 26.50Z",
	snow: "M23.52 4.00L22.39 4.56L22.23 4.88L22.23 9.78L21.99 9.94L20.87 9.14L19.58 8.74L18.38 8.90L17.73 9.78L17.65 10.99L17.82 11.47L19.74 12.35L21.99 13.80L22.07 16.37L21.83 16.93L19.66 15.73L18.86 15.65L18.78 18.86L16.77 17.82L15.97 17.09L15.97 12.11L15.24 11.87L14.28 11.15L13.80 11.15L13.08 11.71L12.67 12.67L12.51 14.60L12.27 15.16L8.74 13.16L7.21 13.16L6.33 13.72L6.33 15.97L9.78 17.82L10.75 18.54L8.02 20.14L8.02 22.15L9.30 22.88L9.86 22.80L14.20 20.39L16.29 21.67L16.77 22.15L14.44 23.60L14.20 24.00L17.01 25.85L13.96 27.37L12.03 26.01L10.43 25.20L8.98 25.20L8.02 25.93L8.02 27.78L9.86 28.66L10.91 29.38L6.33 31.95L6.33 34.20L7.21 34.68L8.42 34.76L9.70 34.28L12.19 32.76L12.67 32.67L12.76 35.65L13.64 36.37L14.84 36.37L15.73 35.89L15.97 35.57L15.97 30.75L17.98 29.38L18.78 29.22L18.94 32.43L19.74 32.19L21.91 30.75L21.99 33.88L17.73 36.37L17.73 38.46L19.26 39.18L22.23 37.65L22.31 43.04L23.84 43.92L24.16 43.92L24.80 43.36L25.61 43.04L25.61 38.70L25.85 37.73L28.66 39.18L30.18 38.46L30.18 36.37L25.93 33.88L25.93 30.99L26.09 30.83L26.41 30.91L27.69 31.79L28.82 32.19L28.98 29.14L30.59 29.86L31.95 30.91L31.95 35.81L32.84 36.37L34.12 36.45L35.16 35.89L35.16 33.08L35.33 32.76L35.65 32.76L38.14 34.28L39.18 34.68L40.47 34.68L41.43 34.12L41.43 31.79L39.02 30.59L37.25 29.30L39.90 27.78L39.82 26.41L39.10 25.37L38.70 25.20L37.65 25.29L33.96 27.29L33.64 27.29L33.32 26.97L31.63 26.25L30.99 25.69L33.56 24.24L33.48 23.84L33.08 23.44L31.63 22.63L31.07 22.07L33.96 20.31L34.84 20.71L37.01 22.23L38.14 22.63L38.70 22.63L39.82 22.15L39.82 19.98L37.82 18.94L37.17 18.38L41.51 16.05L41.59 14.60L41.27 13.72L40.79 13.24L39.34 13.16L35.24 15.16L35.16 11.87L33.96 11.31L33.16 11.31L32.43 11.55L31.95 11.87L31.95 17.25L28.98 18.94L28.90 15.81L28.58 15.24L26.97 16.45L25.93 16.85L25.93 13.56L27.13 12.84L29.30 12.03L30.10 11.39L30.43 10.67L30.35 9.54L29.70 8.90L28.66 8.74L26.97 9.14L25.69 9.94L25.61 4.64L24.40 4.00Z",
	storm: "M32.83 4.86L31.50 4.31L30.09 4.00L26.73 4.00L24.94 4.47L22.59 5.72L20.95 7.12L19.86 8.61L18.45 7.91L16.42 7.52L14.47 7.67L12.52 8.45L10.72 10.02L9.62 11.81L9.23 13.30L9.23 15.56L7.98 16.11L6.42 17.28L5.48 18.38L4.62 19.78L4.00 21.81L4.00 24.86L4.47 26.42L5.17 27.75L6.81 29.47L8.30 30.41L10.56 31.11L20.33 31.27L16.11 36.50L16.11 37.05L16.42 37.20L20.02 37.20L20.09 37.36L15.41 43.45L15.41 43.92L16.11 43.92L31.34 35.48L31.42 35.02L31.11 34.78L26.50 34.70L28.92 31.19L36.66 31.19L38.22 30.88L39.55 30.33L41.27 29.16L42.59 27.67L43.30 26.42L43.92 24.39L43.92 21.34L43.45 19.78L42.52 18.14L41.03 16.50L39.16 15.33L38.45 15.09L38.53 12.98L38.38 11.89L37.36 9.16L35.64 6.81L34.86 6.11Z",
	arid: "M23.38 35.86L23.05 36.32L23.05 43.80L24.10 43.80L24.10 36.32L23.77 35.86ZM33.62 32.31L33.75 32.77L39.40 38.42L39.99 38.42L40.19 38.15L40.12 37.69L34.41 31.98L33.95 31.91ZM13.92 31.52L13.39 31.65L6.30 38.75L6.23 39.21L6.63 39.53L7.02 39.47L14.18 32.31L14.25 31.85ZM4.00 22.13L4.00 23.18L10.77 23.18L11.22 22.85L11.16 22.33L10.77 22.13ZM36.71 22.26L36.78 22.72L37.17 22.98L43.47 22.98L43.93 22.65L43.93 22.26L43.47 21.93L37.17 21.93ZM18.98 13.79L17.27 14.57L15.36 15.89L13.52 17.92L12.41 20.03L11.82 22.33L11.82 24.89L12.41 27.19L13.52 29.35L14.31 30.40L16.41 32.37L18.65 33.69L21.34 34.61L23.77 34.94L26.86 34.74L29.16 34.08L31.13 33.10L32.64 31.98L34.08 30.47L35.26 28.56L35.92 26.66L36.18 24.89L36.05 22.65L35.40 20.42L34.41 18.58L32.90 16.74L31.59 15.63L29.81 14.51L27.78 13.66L25.02 13.06L22.78 13.00L20.81 13.26ZM18.78 14.97L20.29 14.44L22.39 14.05L24.62 14.05L26.86 14.44L28.83 15.17L30.47 16.09L31.65 17.00L33.43 18.98L34.28 20.42L34.87 22.00L35.13 23.38L35.07 25.81L34.74 27.12L33.89 28.96L32.90 30.27L31.06 31.91L29.02 33.03L27.19 33.62L25.54 33.89L22.26 33.75L20.22 33.23L17.99 32.18L16.41 31.06L14.84 29.42L13.66 27.51L12.93 25.35L12.80 22.65L13.06 21.27L13.98 19.11L15.10 17.60L16.87 16.02ZM28.70 16.74L26.73 16.22L24.76 16.22L22.59 16.74L21.41 17.27L19.83 18.32L18.38 19.70L17.60 20.75L16.74 22.39L16.28 23.90L16.15 24.76L16.22 26.73L16.55 28.04L17.46 29.68L18.38 30.67L19.30 31.32L21.01 32.05L22.59 32.31L24.23 32.24L25.67 31.91L27.19 31.32L28.50 30.54L29.55 29.68L31.06 27.97L31.91 26.46L32.51 24.69L32.70 23.31L32.51 21.21L32.05 19.89L31.26 18.65L30.01 17.46ZM29.09 18.06L29.88 18.65L30.80 19.70L31.52 21.34L31.72 22.65L31.59 24.30L31.13 25.81L29.75 28.04L28.56 29.22L27.12 30.21L25.67 30.86L24.10 31.26L21.41 31.13L20.75 30.93L19.17 30.01L18.12 28.89L17.66 28.11L17.14 26.20L17.14 24.82L17.53 23.11L17.99 22.06L18.98 20.55L20.35 19.17L21.47 18.38L23.77 17.40L24.89 17.20L26.59 17.20L28.17 17.60ZM24.43 18.45L22.78 18.65L21.93 18.98L20.81 19.70L19.83 20.75L19.30 21.60L18.91 22.59L18.65 23.84L18.65 25.22L18.84 26.33L19.89 28.43L20.62 29.22L21.73 30.01L22.85 30.47L23.97 30.67L25.08 30.60L26.27 30.27L27.78 29.35L28.63 28.43L29.42 27.05L29.88 25.08L29.88 23.97L29.62 22.65L29.29 21.80L28.50 20.55L27.65 19.70L26.86 19.17L25.61 18.65ZM23.51 19.50L25.48 19.63L26.86 20.35L27.58 21.01L28.24 21.93L28.83 23.57L28.83 25.54L28.11 27.45L26.73 28.89L25.74 29.42L24.95 29.62L23.24 29.55L22.26 29.16L21.47 28.63L20.42 27.45L19.70 25.61L19.63 23.90L19.89 22.72L20.29 21.87L21.67 20.29L22.33 19.89ZM8.01 8.20L7.88 8.47L7.94 8.86L14.51 15.36L15.03 15.23L15.17 14.97L15.10 14.57L8.66 8.14L8.27 8.07ZM38.42 6.63L37.96 6.69L31.00 13.66L30.93 14.05L31.13 14.38L31.72 14.38L38.68 7.42L38.75 6.96ZM22.78 4.13L22.78 11.75L23.11 12.21L23.51 12.21L23.84 11.75L23.84 4.13Z",
	A: "M4.00 29.55L4.00 31.32L16.97 31.32L16.97 29.55ZM4.29 22.48L4.29 24.25L9.50 24.25L9.50 22.48ZM4.00 15.79L4.00 17.56L16.97 17.56L16.97 15.79ZM8.62 8.03L7.05 9.31L5.87 11.08L4.98 13.43L5.38 14.22L6.16 14.02L7.34 11.17L8.23 10.00L10.09 8.82L13.63 7.93L17.17 7.83L19.92 8.32L21.49 9.11L22.77 10.39L23.75 11.96L23.66 12.35L20.81 13.73L18.25 16.09L16.68 18.64L15.60 22.48L11.37 22.48L11.37 24.25L15.70 24.34L15.89 26.11L16.48 27.49L16.48 27.98L17.86 30.44L19.23 31.91L19.14 32.21L18.84 32.21L19.23 34.37L20.02 36.53L21.20 38.30L22.38 39.48L24.25 40.76L26.70 41.74L28.28 42.03L30.04 42.03L32.01 41.64L34.76 40.56L37.81 38.89L38.10 38.59L38.00 37.91L37.32 37.61L33.88 39.48L31.13 40.46L28.37 40.66L26.51 40.27L24.54 39.38L22.28 37.51L21.00 35.45L20.31 33.09L24.15 34.86L26.01 35.25L28.86 35.25L30.73 34.86L33.29 33.78L36.04 31.62L37.81 29.16L38.79 26.51L41.15 24.44L42.53 22.57L43.51 20.02L43.90 17.86L43.90 13.14L43.31 10.78L42.13 8.72L40.36 7.24L38.20 6.16L36.92 5.87L36.53 6.26L36.73 7.05L39.58 8.32L40.86 9.31L41.84 10.68L42.62 13.53L42.62 17.66L42.23 19.72L41.25 22.08L40.66 22.97L39.28 24.25L38.99 21.00L38.00 18.25L36.04 15.40L33.29 13.24L31.91 12.55L28.86 11.76L26.01 11.76L25.33 11.96L23.85 9.60L22.67 8.32L21.10 7.34L19.33 6.75L17.37 6.46L13.63 6.56L10.68 7.14ZM26.11 13.14L29.85 13.34L32.11 14.12L33.88 15.30L35.55 16.87L36.73 18.64L37.51 20.51L37.91 22.48L37.71 25.82L36.92 27.98L35.55 30.14L34.07 31.62L32.30 32.80L30.93 33.39L28.77 33.88L25.03 33.68L22.57 32.80L20.81 31.62L19.33 30.14L18.15 28.37L17.37 26.51L16.97 24.64L17.17 21.10L17.37 21.00L17.96 19.04L19.14 17.07L21.59 14.81L23.95 13.63ZM26.31 15.30L25.72 16.38L21.99 26.70L22.08 26.90L21.20 28.86L21.00 30.14L22.18 30.24L22.87 29.85L23.85 26.60L24.15 26.21L30.34 26.21L31.62 29.95L32.21 30.24L33.48 30.14L33.68 29.85L32.21 26.11L32.30 25.92L32.11 25.82L29.95 19.43L29.75 19.33L29.85 19.14L29.65 19.04L29.75 18.84L29.55 18.74L28.57 15.60L28.18 15.30ZM27.19 17.27L28.57 20.71L28.47 20.90L29.06 22.18L29.75 24.74L24.64 24.64L24.64 24.15L24.84 24.05L26.21 19.63Z",
	B: "M5.49 17.53L4.85 18.06L4.85 23.36L4.00 23.47L4.00 25.38L4.85 25.49L4.74 30.05L5.06 31.00L5.80 31.21L6.44 30.79L6.65 30.15L6.65 25.49L12.17 25.38L12.17 23.47L6.76 23.47L6.65 18.59L6.12 17.63ZM41.88 4.58L41.14 4.37L37.74 5.54L36.47 6.60L36.04 8.08L36.89 11.16L36.47 11.90L35.09 12.65L31.80 13.50L30.42 12.75L27.87 12.01L24.16 11.90L22.89 12.12L20.87 12.75L18.64 13.92L17.37 14.88L15.78 16.57L15.56 16.25L15.78 16.15L15.78 15.62L13.34 14.88L11.96 13.50L12.38 8.62L11.75 7.13L10.90 6.39L8.88 5.64L5.59 5.22L5.06 5.64L5.06 6.28L5.70 6.71L9.20 7.24L10.79 8.30L11.00 9.57L10.47 12.54L10.58 13.92L10.90 14.66L12.28 15.94L15.35 17.10L14.19 19.01L13.34 21.35L13.02 23.89L13.12 26.76L14.40 30.47L16.10 32.91L17.47 34.29L17.16 34.40L17.16 36.73L16.84 37.16L15.99 37.37L10.15 37.37L9.31 37.69L8.46 38.43L8.03 39.49L8.03 41.19L8.24 42.57L8.77 43.52L9.41 43.52L9.84 42.99L9.41 40.98L9.41 39.81L9.73 39.17L11.00 38.75L16.10 38.85L17.26 38.54L18.11 37.90L18.54 37.16L18.54 35.35L18.75 35.14L20.13 35.99L22.89 36.94L27.13 37.16L30.95 36.10L33.50 34.50L33.92 35.03L33.92 35.67L34.56 37.37L35.72 38.64L37.42 38.85L40.07 38.01L41.24 38.11L41.98 39.49L42.41 42.36L42.83 42.89L43.36 42.89L43.79 42.57L43.79 41.19L43.58 40.98L43.36 39.17L42.94 38.01L41.98 36.84L41.35 36.52L39.86 36.52L37.42 37.37L36.47 37.37L35.72 36.63L35.09 34.61L35.09 33.87L34.66 33.34L35.30 32.81L36.79 30.68L37.85 28.14L38.27 25.91L38.27 23.05L37.85 20.92L36.79 18.38L35.30 16.25L33.60 14.66L35.83 13.92L37.53 12.86L38.27 11.37L37.42 7.87L37.63 7.45L39.01 6.60L41.67 5.75L41.98 5.22ZM23.52 13.50L27.02 13.39L28.30 13.60L30.21 14.24L31.90 15.19L33.18 16.15L34.98 18.27L36.04 20.18L36.68 22.09L36.89 25.70L36.47 27.71L35.62 29.84L33.92 32.17L31.90 33.87L29.68 35.03L27.77 35.56L23.52 35.56L21.61 35.03L19.07 33.66L17.47 32.28L16.20 30.68L15.35 29.09L14.50 26.44L14.50 22.73L14.72 21.67L16.41 18.06L17.37 16.89L19.70 14.98L21.61 14.03ZM21.61 16.89L21.19 17.42L21.19 32.28L21.82 32.81L27.13 32.81L29.78 31.96L31.06 30.68L31.48 29.84L31.48 29.09L31.69 28.99L31.69 27.50L31.27 26.23L29.99 24.85L28.51 24.21L29.99 23.15L30.63 21.77L30.63 19.86L30.21 18.69L29.36 17.74L27.24 16.89ZM23.20 25.49L26.81 25.38L28.72 26.12L29.25 26.76L29.68 28.03L29.25 29.84L28.19 30.79L27.24 31.11L23.31 31.11ZM23.20 18.59L26.49 18.48L27.66 18.91L28.40 19.76L28.62 20.39L28.62 21.67L28.19 22.73L26.81 23.68L23.31 23.79Z",
	C: "M6.79 22.77L6.79 24.30L8.14 24.30L8.14 22.77ZM23.62 4.00L23.11 4.00L22.77 4.34L22.69 13.98L21.42 14.06L19.56 14.57L17.87 15.42L16.35 16.52L16.26 16.09L9.33 9.16L8.74 8.99L8.40 9.16L8.31 9.50L8.57 10.09L15.84 17.19L14.74 18.55L14.57 18.38L14.57 17.02L6.79 17.02L6.79 18.55L14.66 18.63L13.98 19.90L13.30 22.69L9.92 22.77L9.84 24.13L9.92 24.30L13.22 24.30L13.64 27.00L14.49 28.78L6.79 28.86L6.79 30.38L14.57 30.38L14.57 29.45L14.74 29.29L16.18 31.06L7.72 39.52L7.72 40.28L8.48 40.45L16.85 31.99L17.19 31.91L19.14 33.09L22.10 33.94L22.10 43.58L22.44 43.92L22.94 43.92L23.20 43.66L23.20 34.02L23.37 33.85L24.89 33.77L26.75 33.26L29.37 31.74L36.98 39.26L37.32 39.43L37.91 39.26L37.91 38.50L30.30 30.81L31.48 29.45L32.50 27.51L33.01 25.56L33.09 24.21L33.43 24.38L41.12 24.38L41.12 23.20L33.43 23.20L33.09 23.37L33.01 22.18L32.50 20.32L31.65 18.80L31.82 18.29L40.28 9.92L40.11 9.16L39.35 9.16L30.89 17.62L29.29 16.01L27.17 14.74L23.87 13.89L23.87 4.25ZM21.51 15.25L24.89 15.25L26.75 15.84L28.10 16.60L29.71 17.95L30.72 19.31L31.40 20.66L31.91 22.52L31.91 25.40L31.23 27.59L30.38 29.03L29.45 30.13L28.10 31.23L26.58 32.08L24.80 32.58L22.10 32.67L21.08 32.50L19.56 31.99L18.21 31.23L16.94 30.22L15.42 28.19L14.82 27.00L14.40 25.48L14.40 22.60L14.57 21.67L15.75 19.05L16.60 17.95L18.21 16.60L19.56 15.84ZM22.44 17.36L21.25 17.70L20.07 18.38L18.71 19.98L17.87 22.60L17.87 25.40L18.71 28.02L19.90 29.37L21.67 30.22L23.87 30.38L25.56 29.96L26.66 29.37L27.00 28.86L26.92 27.76L25.31 28.61L24.04 28.95L22.10 28.78L20.91 28.10L20.32 27.42L19.64 25.73L19.48 24.89L19.64 22.01L20.15 20.66L20.66 19.90L22.10 18.88L24.13 18.71L25.23 19.05L26.66 19.98L26.92 19.81L27.00 19.31L26.75 18.38L25.56 17.70L24.38 17.36Z",
	"power:any": "M5.20 43.52L5.44 43.84L5.84 43.92L10.17 41.52L14.66 39.83L18.67 38.87L22.76 38.39L27.25 38.47L31.74 39.19L36.71 40.79L39.91 42.32L42.00 43.60L42.48 43.52L42.72 42.96L41.43 42.00L38.15 40.31L33.34 38.55L28.61 37.59L23.16 37.35L18.67 37.83L13.54 39.11L10.17 40.39L7.69 41.60L5.52 42.88ZM33.50 33.66L33.50 35.66L35.42 35.66L35.42 33.66ZM33.98 24.20L32.94 24.68L32.14 25.48L31.41 27.01L31.25 28.29L33.10 28.29L33.18 27.81L33.82 27.17L34.30 27.17L34.70 27.49L34.86 29.09L33.66 30.69L33.50 32.54L35.42 32.54L35.50 31.66L36.38 30.61L36.87 29.65L37.03 28.61L36.95 26.93L36.46 25.56L35.66 24.68L34.78 24.28ZM40.23 4.00L24.20 5.36L15.86 20.03L22.20 20.19L12.90 36.30L28.53 18.43L24.36 17.55Z",
	"power:north": "M5.20 43.52L5.44 43.84L5.84 43.92L10.17 41.52L14.66 39.83L18.67 38.87L22.76 38.39L27.25 38.47L31.74 39.19L36.71 40.79L39.91 42.32L42.00 43.60L42.48 43.52L42.72 42.96L41.43 42.00L38.15 40.31L33.34 38.55L28.61 37.59L23.16 37.35L18.67 37.83L13.54 39.11L10.17 40.39L7.69 41.60L5.52 42.88ZM34.78 23.88L29.89 28.93L32.46 29.01L32.46 34.78L37.27 34.78L37.27 29.01L39.75 28.85ZM40.23 4.00L24.20 5.36L15.86 20.03L22.20 20.19L12.90 36.30L28.53 18.43L24.36 17.55Z",
	"power:east": "M5.20 43.52L5.44 43.84L5.84 43.92L10.17 41.52L14.66 39.83L18.67 38.87L22.84 38.39L27.25 38.47L31.74 39.19L36.71 40.79L39.91 42.32L42.08 43.60L42.48 43.52L42.72 42.96L41.43 42.00L38.15 40.31L33.34 38.55L27.89 37.51L23.16 37.35L17.39 38.07L13.06 39.27L7.85 41.52L5.52 42.88ZM35.18 24.28L35.10 26.85L29.33 26.85L29.33 31.66L35.10 31.66L35.18 34.22L40.31 29.25ZM40.23 4.00L24.20 5.36L15.86 20.03L22.20 20.19L12.90 36.30L28.53 18.43L24.36 17.55Z",
	"power:south": "M5.20 43.52L5.44 43.84L5.84 43.92L10.01 41.60L14.66 39.83L18.67 38.87L22.76 38.39L27.25 38.47L31.01 39.03L36.30 40.63L39.75 42.24L42.00 43.60L42.56 43.52L42.72 42.96L41.27 41.92L38.31 40.39L33.90 38.71L28.61 37.59L23.40 37.35L18.27 37.91L13.06 39.27L7.69 41.60L5.52 42.88ZM32.46 23.80L32.46 29.57L29.89 29.65L34.94 34.70L39.83 29.65L37.27 29.57L37.27 23.80ZM40.23 4.00L24.20 5.36L15.86 20.03L22.20 20.19L12.82 36.38L28.53 18.43L24.36 17.55Z",
	"power:west": "M5.20 43.52L5.44 43.84L5.84 43.92L10.17 41.52L14.66 39.83L19.15 38.79L22.76 38.39L27.25 38.47L31.74 39.19L36.87 40.87L39.75 42.24L42.08 43.60L42.48 43.52L42.72 42.96L42.48 42.64L40.87 41.68L37.99 40.23L33.90 38.71L28.61 37.59L23.32 37.35L18.27 37.91L13.30 39.19L10.73 40.15L7.85 41.52L5.44 42.96ZM34.38 24.36L29.41 29.33L34.46 34.22L34.54 31.66L40.31 31.66L40.31 26.85L34.54 26.85ZM40.23 4.00L24.20 5.36L15.86 20.03L22.20 20.19L12.82 36.38L28.53 18.43L24.36 17.55Z",
	"meteor:south": "M4.00 41.17L4.14 42.09L4.35 42.44L5.56 41.66L7.26 40.88L12.42 39.12L17.45 38.05L22.90 37.56L27.29 37.63L32.88 38.27L37.98 39.47L41.03 40.53L42.87 41.38L43.65 41.10L43.93 40.18L41.81 39.40L38.83 38.62L32.25 37.42L27.01 36.99L21.91 36.99L16.04 37.49L12.64 38.05L8.53 39.12L5.63 39.26L4.64 39.75ZM8.81 7.96L8.60 8.60L8.60 9.66L8.96 11.29L9.52 12.57L10.51 13.84L12.99 15.89L15.82 17.52L18.16 18.58L19.93 19.93L19.79 20.07L17.31 18.65L14.34 17.52L11.43 16.81L10.94 17.10L11.08 17.66L12.50 18.87L13.20 19.86L14.05 22.34L14.69 23.68L16.88 26.80L18.16 28.07L19.86 29.35L21.63 30.12L22.48 31.47L23.26 32.25L25.38 33.38L26.65 33.66L28.07 33.66L30.19 33.03L31.19 32.32L32.18 31.04L32.60 29.84L32.88 27.72L32.67 25.88L31.96 24.32L30.48 22.90L30.41 21.63L29.98 20.28L29.27 18.94L27.43 16.74L22.76 13.20L20.85 12.35L17.88 11.72L16.81 11.65L16.32 11.79L16.18 12.00L16.46 12.57L17.73 12.78L18.51 13.20L19.93 14.55L19.86 14.76L18.09 13.84L14.55 12.92L12.99 12.35L12.00 11.79L10.73 10.65L9.88 9.17L9.59 7.89L9.03 7.82ZM10.02 11.43L10.16 11.36L10.73 11.93L11.72 12.50L12.71 12.78L15.19 13.98L17.73 14.76L19.43 15.61L20.78 16.74L21.42 18.44L21.70 18.65L21.98 18.65L22.27 18.37L22.05 17.03L21.63 15.75L21.06 14.62L19.93 13.20L20.07 13.06L21.84 13.49L22.76 13.98L25.03 16.11L28.00 18.30L28.57 18.94L28.99 19.79L29.56 22.05L29.42 23.19L30.34 23.54L31.26 24.39L31.89 25.45L32.25 26.51L32.32 28.00L32.18 28.92L31.82 29.91L31.26 30.76L29.98 31.82L28.42 32.39L26.09 32.60L24.39 32.25L23.19 31.33L22.62 30.55L22.05 29.27L20.42 28.64L17.52 26.51L16.46 25.45L15.54 24.18L14.83 22.48L14.55 20.78L13.77 19.58L12.57 18.23L13.06 18.16L15.47 18.94L18.87 20.42L20.07 21.27L20.42 22.41L20.85 22.83L21.42 22.48L21.63 21.42L21.27 20.21L20.50 19.15L19.22 18.16L14.69 15.89L12.42 14.34L10.87 12.85ZM26.94 23.75L26.16 23.89L25.10 24.39L23.75 25.45L23.04 26.51L22.83 27.93L23.26 29.49L24.32 30.83L25.73 31.68L27.58 31.89L28.92 31.40L30.48 30.19L31.33 28.78L31.47 27.50L30.90 25.81L29.77 24.60L28.35 23.89ZM26.16 24.88L27.43 24.81L28.57 25.24L29.49 25.88L30.34 26.80L30.62 27.72L30.41 28.78L30.12 29.35L29.27 30.19L28.50 30.62L27.72 30.83L26.23 30.62L24.96 29.84L23.96 28.78L23.75 28.14L23.89 26.80L25.03 25.45ZM29.20 27.93L28.57 27.93L27.86 28.42L27.65 29.20L27.93 29.56L28.50 29.49L29.06 29.13L29.35 28.57ZM26.73 27.86L26.23 28.00L25.95 28.35L25.95 28.78L26.23 29.13L26.87 29.13L27.29 28.78L27.29 28.21ZM27.58 26.37L27.08 26.44L27.01 26.73L27.15 26.94L27.65 26.80ZM36.28 5.49L32.53 6.12L32.04 11.50L31.89 11.65L30.27 11.65L34.44 17.95L39.19 11.58L37.13 11.58L36.71 11.29Z",
	"meteor:north": "M4.00 42.09L4.14 43.01L4.35 43.36L5.70 42.51L7.26 41.81L12.42 40.04L17.45 38.97L22.90 38.48L27.29 38.55L32.88 39.19L37.98 40.39L41.03 41.45L42.87 42.30L43.65 42.02L43.93 41.10L41.81 40.32L38.83 39.54L32.25 38.34L27.01 37.91L21.91 37.91L16.04 38.41L12.00 39.12L8.46 40.04L5.63 40.18L4.64 40.67ZM8.88 8.81L8.60 9.45L8.81 11.72L9.52 13.49L10.51 14.76L12.99 16.81L15.82 18.44L18.16 19.50L19.93 20.85L19.79 20.99L17.31 19.58L14.34 18.44L11.43 17.73L10.94 18.02L10.94 18.37L12.21 19.50L13.20 20.78L14.05 23.26L14.69 24.60L16.88 27.72L18.16 28.99L19.86 30.27L21.63 31.04L22.48 32.39L23.26 33.17L25.38 34.30L26.65 34.58L28.78 34.44L30.19 33.95L31.19 33.24L32.11 32.11L32.60 30.76L32.88 28.57L32.81 27.50L32.39 26.02L31.96 25.24L30.48 23.82L30.41 22.55L29.98 21.20L29.27 19.86L27.43 17.66L22.76 14.12L20.85 13.27L17.95 12.64L16.81 12.57L16.32 12.71L16.18 12.92L16.46 13.49L17.73 13.70L19.08 14.55L19.93 15.47L19.79 15.68L18.09 14.76L14.55 13.84L12.71 13.13L11.29 12.14L10.51 11.29L9.95 10.30L9.59 8.81ZM10.02 12.35L10.16 12.28L10.73 12.85L11.72 13.42L12.71 13.70L15.19 14.90L17.38 15.54L19.22 16.39L20.78 17.66L21.42 19.36L21.70 19.58L21.98 19.58L22.27 19.29L22.05 17.95L21.06 15.54L20.00 14.05L21.42 14.27L22.76 14.90L25.03 17.03L28.00 19.22L28.57 19.86L28.99 20.71L29.56 22.97L29.42 24.11L30.34 24.46L31.26 25.31L31.89 26.37L32.32 27.93L32.18 29.91L31.75 30.97L31.19 31.75L29.98 32.74L28.42 33.31L27.15 33.52L24.81 33.31L24.11 33.03L23.19 32.25L22.62 31.47L22.05 30.19L21.35 30.05L20.35 29.49L17.52 27.43L16.46 26.37L15.54 25.10L14.90 23.61L14.55 21.70L13.77 20.50L12.57 19.15L13.06 19.08L15.47 19.86L18.87 21.35L20.07 22.19L20.42 23.33L20.85 23.75L21.42 23.40L21.63 22.34L21.27 21.13L20.57 20.14L19.22 19.08L14.69 16.81L12.42 15.26L10.87 13.77ZM26.87 24.67L26.16 24.81L25.10 25.31L23.75 26.37L23.04 27.43L22.83 28.85L23.40 30.62L24.32 31.75L25.73 32.60L27.50 32.81L28.92 32.32L30.48 31.12L31.33 29.70L31.47 28.42L30.90 26.73L29.77 25.52L28.35 24.81ZM25.24 26.23L26.44 25.73L27.43 25.73L28.57 26.16L29.49 26.80L30.34 27.72L30.62 28.64L30.55 29.27L30.12 30.27L29.06 31.26L27.72 31.75L26.23 31.54L24.60 30.48L23.82 29.35L23.75 28.21L24.11 27.36ZM29.27 28.92L28.57 28.85L28.14 29.06L27.72 29.56L27.72 30.27L28.00 30.48L28.92 30.19L29.35 29.49ZM26.73 28.78L26.23 28.92L25.95 29.27L25.95 29.70L26.23 30.05L26.87 30.05L27.29 29.70L27.29 29.13ZM27.58 27.29L27.08 27.36L27.01 27.65L27.15 27.86L27.65 27.72ZM34.51 4.57L29.70 11.08L32.18 11.22L32.60 17.24L36.50 16.53L36.99 11.15L37.13 11.01L38.76 11.01Z",
	"meteor:west": "M4.00 40.21L4.14 41.13L4.35 41.49L5.70 40.64L7.26 39.93L12.42 38.16L17.45 37.10L22.90 36.60L27.29 36.67L32.88 37.31L37.98 38.51L41.03 39.58L42.87 40.42L43.65 40.14L43.93 39.22L41.81 38.44L38.83 37.66L32.25 36.46L27.01 36.04L21.91 36.04L16.04 36.53L12.00 37.24L8.46 38.16L5.63 38.30L4.64 38.80ZM8.88 6.94L8.60 7.58L8.81 9.84L9.52 11.61L10.51 12.88L12.99 14.94L15.82 16.57L18.16 17.63L19.93 18.97L19.79 19.12L17.31 17.70L14.34 16.57L11.43 15.86L10.94 16.14L10.94 16.50L12.21 17.63L13.20 18.90L14.05 21.38L14.69 22.73L16.88 25.84L18.16 27.12L19.86 28.39L21.63 29.17L22.48 30.51L23.26 31.29L25.38 32.42L26.65 32.71L28.78 32.57L30.19 32.07L31.19 31.36L32.11 30.23L32.60 28.88L32.88 26.69L32.81 25.63L32.39 24.14L31.96 23.36L30.48 21.95L30.41 20.67L29.98 19.33L29.27 17.98L27.43 15.79L22.76 12.25L20.85 11.40L17.95 10.76L16.81 10.69L16.32 10.83L16.18 11.04L16.46 11.61L17.73 11.82L19.08 12.67L19.93 13.59L19.79 13.81L18.09 12.88L14.55 11.96L12.71 11.26L11.29 10.27L10.51 9.42L9.95 8.42L9.59 6.94ZM10.02 10.48L10.16 10.41L10.73 10.97L11.72 11.54L12.71 11.82L15.19 13.03L17.38 13.66L19.22 14.51L20.78 15.79L21.42 17.49L21.70 17.70L21.98 17.70L22.27 17.42L22.05 16.07L21.06 13.66L20.00 12.18L21.42 12.39L22.76 13.03L25.03 15.15L28.00 17.35L28.57 17.98L28.99 18.83L29.56 21.10L29.42 22.23L30.34 22.58L31.26 23.43L31.89 24.50L32.32 26.05L32.18 28.04L31.75 29.10L31.19 29.88L29.98 30.87L28.42 31.43L27.15 31.65L24.81 31.43L24.11 31.15L23.19 30.37L22.62 29.59L22.05 28.32L21.35 28.18L20.35 27.61L17.52 25.56L16.46 24.50L15.54 23.22L14.90 21.73L14.55 19.82L13.77 18.62L12.57 17.27L13.06 17.20L15.47 17.98L18.87 19.47L20.07 20.32L20.42 21.45L20.85 21.88L21.42 21.52L21.63 20.46L21.27 19.26L20.57 18.27L19.22 17.20L14.69 14.94L12.42 13.38L10.87 11.89ZM26.87 22.80L26.16 22.94L25.10 23.43L23.75 24.50L23.04 25.56L22.83 26.97L23.40 28.74L24.32 29.88L25.73 30.73L27.50 30.94L28.92 30.44L30.48 29.24L31.33 27.82L31.47 26.55L30.90 24.85L29.77 23.65L28.35 22.94ZM25.24 24.35L26.44 23.86L27.43 23.86L28.57 24.28L29.49 24.92L30.34 25.84L30.62 26.76L30.55 27.40L30.12 28.39L29.06 29.38L27.72 29.88L26.23 29.66L24.60 28.60L23.82 27.47L23.75 26.34L24.11 25.49ZM29.27 27.04L28.57 26.97L28.14 27.19L27.72 27.68L27.72 28.39L28.00 28.60L28.92 28.32L29.35 27.61ZM26.73 26.90L26.23 27.04L25.95 27.40L25.95 27.82L26.23 28.18L26.87 28.18L27.29 27.82L27.29 27.26ZM27.58 25.42L27.08 25.49L27.01 25.77L27.15 25.98L27.65 25.84ZM34.23 6.44L28.07 10.55L28.07 10.83L34.51 15.50L34.51 13.03L40.53 12.53L39.89 8.71L34.44 8.14L34.37 6.44Z",
	"meteor:any": "M13.77 27.93L10.65 32.11L12.21 32.25L12.28 34.02L10.37 33.88L10.23 32.74L6.05 35.50L10.37 38.62L10.44 36.99L12.21 36.92L12.07 38.97L10.94 39.12L13.70 43.22L16.81 38.97L15.19 38.90L15.12 37.20L17.03 37.35L17.17 38.48L21.35 35.72L17.03 32.60L17.10 34.09L16.96 34.23L15.19 34.30L15.33 32.25L15.47 32.11L16.46 32.11L16.46 31.96ZM16.74 14.83L15.75 16.11L15.33 17.31L15.04 19.50L15.12 20.57L15.54 22.05L15.96 22.83L17.45 24.25L17.52 25.52L17.95 26.87L18.65 28.21L20.50 30.41L25.17 33.95L27.08 34.80L29.98 35.43L31.04 35.50L31.47 35.43L31.75 35.15L31.47 34.58L30.19 34.37L29.42 33.95L28.00 32.60L28.07 32.39L29.84 33.31L33.38 34.23L34.94 34.80L35.93 35.36L37.20 36.50L38.05 37.98L38.34 39.26L38.90 39.33L39.12 39.19L39.33 38.55L39.33 37.49L38.97 35.86L38.41 34.58L37.42 33.31L34.94 31.26L32.11 29.63L29.77 28.57L28.00 27.22L28.14 27.08L30.62 28.50L33.52 29.63L36.50 30.34L36.99 30.05L36.85 29.49L36.00 28.85L34.94 27.65L33.24 23.47L30.97 20.28L29.77 19.08L28.07 17.81L26.30 17.03L25.45 15.68L24.67 14.90L22.55 13.77L21.27 13.49L19.86 13.49L17.73 14.12ZM16.74 16.32L17.95 15.33L19.50 14.76L21.84 14.55L23.54 14.90L24.74 15.82L25.31 16.60L25.88 17.88L27.50 18.51L30.41 20.64L31.47 21.70L32.39 22.97L33.10 24.67L33.38 26.37L34.16 27.58L35.36 28.92L34.87 28.99L32.46 28.21L29.06 26.73L27.86 25.88L27.50 24.74L27.08 24.32L26.51 24.67L26.30 25.73L26.65 26.94L27.36 27.93L28.71 28.99L33.24 31.26L35.08 32.46L37.06 34.30L37.91 35.72L37.77 35.79L37.20 35.22L36.21 34.65L35.22 34.37L32.74 33.17L30.55 32.53L28.71 31.68L27.15 30.41L26.51 28.71L26.23 28.50L25.95 28.50L25.66 28.78L25.88 30.12L26.30 31.40L26.87 32.53L28.00 33.95L27.86 34.09L26.09 33.66L25.17 33.17L22.90 31.04L19.93 28.85L19.36 28.21L18.94 27.36L18.37 25.10L18.51 23.96L17.59 23.61L16.67 22.76L16.04 21.70L15.61 20.14L15.75 18.16L16.18 17.10ZM20.42 15.26L19.01 15.75L17.45 16.96L16.60 18.37L16.46 19.72L17.03 21.35L18.16 22.55L19.58 23.26L21.06 23.40L21.77 23.26L22.83 22.76L24.18 21.70L24.88 20.64L25.10 19.22L24.53 17.45L23.61 16.32L22.19 15.47ZM19.22 16.60L20.21 16.32L21.35 16.39L22.69 17.10L23.82 18.16L24.18 19.01L24.04 20.35L23.68 20.92L22.62 21.91L21.49 22.34L20.50 22.34L19.01 21.70L17.59 20.35L17.31 19.43L17.52 18.37L17.81 17.81ZM20.78 20.21L20.28 20.35L20.35 20.78L20.85 20.71L20.92 20.42ZM21.70 18.02L21.06 18.02L20.64 18.37L20.57 18.73L20.78 19.15L21.27 19.29L21.91 18.94L21.98 18.37ZM20.00 17.59L19.43 17.66L18.87 18.02L18.58 18.58L18.58 18.94L18.80 19.22L19.36 19.22L20.07 18.73L20.28 17.95ZM43.93 5.98L43.79 5.06L43.58 4.71L42.23 5.56L40.67 6.27L35.50 8.04L30.48 9.10L25.03 9.59L20.64 9.52L15.04 8.88L9.95 7.68L4.99 5.77L4.28 6.05L4.00 6.97L6.12 7.75L9.10 8.53L15.68 9.73L20.92 10.16L26.09 10.16L31.33 9.73L35.93 8.96L39.04 8.11L42.30 7.89L43.29 7.40Z",
	"meteor:east": "M4.00 40.42L4.14 41.35L4.35 41.70L5.70 40.85L7.26 40.14L12.42 38.37L17.45 37.31L22.90 36.81L27.29 36.88L32.88 37.52L37.98 38.73L41.03 39.79L42.87 40.64L43.65 40.35L43.93 39.43L41.81 38.65L38.83 37.88L32.25 36.67L27.01 36.25L21.84 36.25L16.60 36.67L12.00 37.45L8.46 38.37L5.63 38.51L4.64 39.01ZM8.81 7.22L8.60 7.79L8.60 8.92L8.96 10.55L9.52 11.82L10.51 13.10L12.99 15.15L15.82 16.78L18.16 17.84L19.93 19.19L19.79 19.33L17.31 17.91L14.34 16.78L11.43 16.07L11.08 16.14L10.94 16.35L11.08 16.92L12.21 17.84L13.20 19.12L14.05 21.59L14.69 22.94L16.96 26.12L18.16 27.33L19.86 28.60L21.63 29.38L22.48 30.73L23.26 31.50L25.38 32.64L26.65 32.92L28.78 32.78L30.19 32.28L31.19 31.58L32.18 30.30L32.60 29.10L32.88 26.97L32.67 25.20L32.39 24.35L31.75 23.29L30.48 22.16L30.41 20.88L29.63 18.76L27.93 16.50L23.12 12.67L20.85 11.61L17.95 10.97L16.88 10.90L16.46 10.97L16.18 11.26L16.25 11.61L16.60 11.89L17.03 11.82L17.73 12.04L19.01 12.81L19.93 13.81L19.86 14.02L18.09 13.10L14.55 12.18L12.99 11.61L12.00 11.04L10.73 9.91L9.88 8.42L9.59 7.15L9.31 7.01ZM10.02 10.69L10.16 10.62L10.73 11.19L11.72 11.75L12.71 12.04L15.19 13.24L17.73 14.02L19.43 14.87L20.78 16.00L21.42 17.70L21.70 17.91L21.98 17.91L22.27 17.63L21.98 16.07L21.06 13.88L20.00 12.39L21.42 12.60L22.76 13.24L25.03 15.36L28.00 17.56L28.57 18.19L28.99 19.04L29.56 21.31L29.42 22.44L30.34 22.80L31.33 23.72L32.18 25.56L32.32 26.27L32.18 28.25L31.75 29.31L31.19 30.09L29.98 31.08L28.42 31.65L26.09 31.86L24.39 31.50L23.19 30.58L22.62 29.81L22.05 28.53L20.42 27.89L17.52 25.77L16.46 24.71L15.40 23.15L14.76 21.45L14.55 20.04L13.77 18.83L12.57 17.49L13.06 17.42L15.47 18.19L18.87 19.68L20.07 20.53L20.42 21.66L20.85 22.09L21.42 21.73L21.63 20.67L21.27 19.47L20.57 18.48L19.22 17.42L14.69 15.15L12.42 13.59L10.87 12.11ZM26.87 23.01L26.16 23.15L25.10 23.65L23.75 24.71L23.04 25.77L22.83 27.19L23.40 28.96L24.32 30.09L25.73 30.94L27.50 31.15L28.92 30.65L30.48 29.45L31.33 28.04L31.47 26.69L30.90 25.06L29.77 23.86L28.35 23.15ZM25.95 24.21L27.43 24.07L28.07 24.28L29.49 25.13L30.34 26.05L30.62 26.97L30.41 28.04L30.12 28.60L28.71 29.81L27.72 30.09L26.58 30.02L24.96 29.10L23.96 28.04L23.75 27.40L23.89 26.05L25.03 24.71ZM29.27 27.26L28.57 27.19L28.14 27.40L27.72 27.89L27.72 28.60L28.00 28.81L28.92 28.53L29.35 27.82ZM26.73 27.12L26.23 27.26L25.95 27.61L25.95 28.04L26.23 28.39L26.87 28.39L27.29 28.04L27.29 27.47ZM27.08 25.70L27.01 25.98L27.15 26.19L27.65 26.05L27.58 25.63ZM34.65 6.23L34.58 8.71L28.57 9.13L29.27 13.03L34.65 13.52L34.80 13.66L34.80 15.29L41.17 10.97Z",
	adjacent: "M4.00 42.92L30.56 42.98L30.56 29.87L30.69 29.74L43.87 29.74L43.93 15.97L43.80 15.84L16.59 15.90L16.72 29.08L4.00 29.15ZM29.90 29.74L29.97 42.26L17.51 42.33L17.38 42.20L17.38 36.95L17.51 36.82L24.85 36.82L25.31 36.30L25.31 29.80ZM17.38 29.87L17.57 29.74L23.54 29.74L23.67 30.00L23.61 35.18L17.51 35.25L17.38 34.92ZM4.07 29.80L16.59 29.74L16.72 30.13L16.72 35.11L16.59 35.25L7.93 35.25L7.48 35.64L7.41 36.23L7.48 36.56L7.93 36.82L16.59 36.82L16.72 36.95L16.72 42.20L16.59 42.33L4.20 42.33ZM25.44 23.18L29.77 23.18L29.97 23.31L29.90 29.08L25.44 29.15L25.31 29.02L25.31 23.31ZM30.69 16.43L43.08 16.43L43.21 16.56L43.21 29.02L43.08 29.15L30.75 29.15L30.62 29.02L30.62 23.31L30.75 23.18L38.62 23.18L39.15 22.66L39.15 22.20L38.95 21.80L38.62 21.61L30.69 21.61ZM29.84 16.43L29.97 16.56L29.90 21.61L24.26 21.54L23.67 22.00L23.61 29.02L23.48 29.15L17.38 29.15L17.31 16.56L17.44 16.43ZM7.74 6.98L6.95 7.44L7.02 7.57L6.69 7.90L6.62 8.82L7.15 9.67L7.80 10.00L8.46 10.07L9.44 9.48L9.77 8.30L9.38 7.38L8.66 6.98ZM13.97 4.95L14.10 5.41L16.20 8.56L14.23 10.59L14.10 10.85L14.16 11.31L14.56 11.51L14.89 11.44L16.79 9.61L18.36 12.03L18.62 12.23L19.15 12.10L19.34 11.77L17.97 9.61L17.57 8.75L19.74 6.59L19.87 6.33L19.80 6.00L19.61 5.80L18.95 5.93L16.98 7.90L15.08 4.95ZM5.90 4.95L4.85 5.87L4.07 7.57L4.00 8.95L4.59 10.66L5.51 11.70L6.95 12.49L8.85 12.62L10.30 12.16L10.95 11.70L11.74 10.85L12.33 9.61L12.46 7.97L12.33 7.90L12.33 7.38L11.87 6.26L10.56 4.95L8.52 4.95L9.25 5.02L9.84 5.28L10.82 6.00L11.61 7.25L11.74 9.15L11.61 9.67L11.34 10.00L11.41 10.13L10.43 11.25L9.84 11.64L8.52 12.03L7.15 11.90L5.84 11.11L4.85 9.67L4.72 7.84L5.25 6.52L6.10 5.61L7.08 5.08L7.87 4.95Z",
	exits: "M4.00 38.97L7.80 39.10L7.93 39.23L7.93 42.77L15.87 42.77L15.87 39.30L16.00 39.10L19.53 39.10L19.80 38.97L18.47 38.03L18.47 37.90L23.60 37.90L23.67 38.03L24.13 37.90L29.47 37.90L29.40 38.10L28.13 38.97L28.40 39.10L31.93 39.10L32.07 39.30L32.07 42.77L39.93 42.77L40.07 42.63L40.07 39.10L43.93 39.03L36.13 33.10L35.27 33.57L30.00 37.63L23.93 37.57L23.93 26.90L24.07 26.77L27.87 26.77L27.87 23.30L28.07 23.03L31.73 23.03L24.00 17.10L23.53 17.23L16.07 22.97L16.13 23.10L19.80 23.03L19.93 23.17L19.93 26.77L23.67 26.83L23.60 37.57L17.93 37.63L12.13 33.17L11.80 33.10ZM8.87 7.17L8.07 7.23L7.53 7.50L6.93 8.43L6.93 9.10L7.40 9.97L8.13 10.30L9.00 10.30L9.53 10.03L10.00 9.50L10.13 8.70L10.00 8.10L9.67 7.63ZM14.40 5.17L14.67 5.83L16.67 8.90L14.60 11.03L14.53 11.57L15.00 11.83L15.33 11.77L17.33 9.90L18.87 12.37L19.20 12.57L19.53 12.50L19.80 12.17L19.80 11.90L18.00 9.10L20.33 6.77L20.33 6.17L19.93 5.97L19.53 6.10L17.47 8.17L15.53 5.17ZM5.20 6.03L4.67 6.90L4.27 8.37L4.40 9.90L5.33 11.63L6.33 12.43L8.07 12.97L9.87 12.83L11.13 12.23L12.27 10.97L12.87 9.23L12.73 7.57L11.87 5.97L10.93 5.17L9.00 5.17L9.80 5.30L11.33 6.37L12.00 7.57L12.13 9.43L11.80 10.43L10.80 11.57L9.80 12.17L8.33 12.37L7.73 12.30L6.93 11.97L6.07 11.37L5.20 10.03L5.00 9.50L4.93 8.37L5.07 8.30L5.07 7.83L5.20 7.77L5.40 6.97L6.13 6.03L7.07 5.43L8.27 5.17L6.20 5.17Z",
	urban: "M12.10 14.10L12.17 43.93L42.06 43.93L42.06 14.03ZM12.86 14.73L41.30 14.66L41.44 14.80L41.44 43.24L12.93 43.31ZM26.63 15.14L26.63 19.64L26.49 19.78L24.21 19.71L24.07 19.85L24.07 22.20L23.93 22.34L21.16 22.34L21.23 42.69L21.09 42.75L32.86 42.75L32.72 42.48L32.79 22.34L30.02 22.34L29.88 22.20L29.88 19.78L27.11 19.71L27.18 15.14ZM21.72 22.82L32.10 22.82L32.30 22.96L32.30 42.13L32.17 42.34L21.85 42.34L21.65 42.13ZM27.67 25.31L27.74 41.58L28.22 41.58L28.15 25.38L28.29 25.31ZM25.73 25.31L25.80 41.51L26.28 41.58L26.35 25.31ZM24.62 20.26L29.33 20.19L29.40 22.20L29.26 22.34L24.62 22.27ZM18.88 6.15L17.91 6.70L18.05 6.77L17.70 7.25L17.63 8.01L18.19 8.98L18.88 9.33L19.78 9.33L20.33 9.05L20.75 8.57L20.96 7.67L20.89 7.11L20.40 6.49L19.92 6.21ZM8.57 6.35L8.15 6.70L7.81 7.46L7.81 8.08L8.08 8.71L8.43 9.05L9.05 9.33L10.30 9.19L10.78 8.78L11.13 7.94L10.78 6.70L9.88 6.15L9.05 6.15ZM27.04 5.04L26.91 5.18L26.91 7.25L24.90 7.32L24.83 8.01L26.84 8.15L26.91 10.23L27.04 10.37L27.74 10.37L27.88 10.09L27.88 8.15L29.88 8.08L29.88 7.39L27.88 7.32L27.81 5.11ZM30.85 4.00L33.27 7.88L31.13 10.09L31.06 10.51L31.20 10.78L31.47 10.92L31.89 10.85L33.90 8.91L35.49 11.40L35.97 11.68L36.39 11.54L36.53 10.92L35.00 8.71L34.73 8.01L37.08 5.66L37.08 5.04L36.66 4.83L36.32 4.90L35.07 6.21L34.03 7.04L32.10 4.00ZM16.73 4.07L15.49 5.38L14.93 6.77L14.87 8.29L15.00 8.43L15.00 8.91L15.90 10.57L16.46 11.13L17.56 11.82L18.67 12.10L20.40 12.03L21.09 11.82L21.09 11.68L22.20 11.13L23.24 9.88L23.79 8.22L23.72 6.77L22.96 5.11L22.34 4.35L21.79 4.00L19.71 4.00L21.09 4.35L22.48 5.66L23.03 7.04L23.03 8.50L22.20 10.16L21.65 10.64L20.54 11.27L19.09 11.47L18.12 11.27L16.73 10.44L16.04 9.54L15.63 8.50L15.63 7.04L16.32 5.45L16.66 5.04L17.77 4.28L18.88 4.00ZM6.49 4.35L5.80 5.25L5.80 10.16L6.63 11.13L7.74 11.68L7.74 11.82L8.84 12.10L10.16 12.10L11.27 11.82L12.37 11.13L13.34 10.02L13.97 8.29L13.83 6.49L13.34 5.38L12.86 4.76L11.96 4.00L9.95 4.00L10.78 4.14L12.17 5.04L12.65 5.66L13.20 7.04L13.20 8.50L12.79 9.54L11.75 10.71L10.71 11.27L9.12 11.47L8.29 11.27L6.84 10.37L6.28 9.61L5.80 8.50L5.80 7.04L6.35 5.66L7.74 4.35L9.12 4.00L7.04 4.00Z",
	center: "M25.49 36.22L25.35 36.78L26.95 39.21L27.16 39.76L24.80 42.12L24.80 42.68L25.15 42.96L25.63 42.82L27.78 40.67L29.94 43.93L30.98 43.93L30.91 43.44L28.62 39.90L30.77 37.68L30.84 37.26L30.49 36.85L29.94 36.99L27.99 38.86L26.53 36.71L26.47 36.36L25.98 36.08ZM34.59 36.29L33.62 37.19L33.13 37.89L32.58 39.49L32.72 41.22L33.55 42.89L34.80 43.93L39.31 43.93L40.56 42.89L40.98 42.26L41.47 40.94L41.53 39.56L41.40 38.86L40.70 37.47L39.45 36.29L38.20 35.74L36.33 35.67ZM36.74 36.29L38.13 36.43L39.59 37.26L40.56 38.65L40.77 39.35L40.77 40.88L39.94 42.54L38.76 43.44L37.37 43.86L35.77 43.65L34.52 42.89L33.62 41.57L33.27 40.32L33.55 38.65L34.24 37.54L35.08 36.85ZM36.60 38.44L36.05 38.72L35.49 39.49L35.49 40.53L35.84 41.15L36.26 41.50L36.88 41.71L37.51 41.64L38.20 41.29L38.76 40.39L38.76 39.76L38.48 39.07L37.78 38.51ZM6.40 4.00L6.40 34.00L36.60 33.93L36.60 4.00ZM7.30 4.62L35.84 4.69L35.70 33.38L7.16 33.31L7.16 4.76ZM15.01 12.68L14.94 25.39L27.92 25.39L27.78 25.25L27.85 12.68ZM16.19 13.65L26.74 13.72L26.67 24.42L16.12 24.35Z",
	"tentacle:5": "M30.29 38.20L29.87 38.68L29.80 39.23L30.49 40.96L31.60 42.00L32.01 42.13L32.64 42.00L32.91 41.65L32.98 40.82L32.43 39.37L31.25 38.27L30.84 38.13ZM30.63 38.82L31.67 39.51L32.29 40.75L32.29 41.31L32.15 41.44L31.60 41.17L30.70 39.99L30.49 39.30ZM32.22 36.47L31.81 37.16L32.15 38.68L32.84 39.65L33.46 40.20L34.09 40.41L34.57 40.27L34.92 39.85L34.98 39.09L34.43 37.71L33.40 36.61L32.91 36.40ZM32.64 37.02L33.12 37.23L33.81 37.99L34.22 38.96L34.29 39.51L34.16 39.72L33.67 39.51L32.77 38.40L32.50 37.64L32.50 37.16ZM22.76 34.81L22.55 35.23L22.83 35.50L23.86 35.92L25.38 36.88L27.59 38.82L29.46 41.44L30.36 43.93L31.05 43.93L30.56 42.27L29.60 40.34L27.87 38.13L25.24 35.99L23.38 34.95ZM27.25 34.74L27.04 35.02L27.04 35.71L27.45 36.54L28.42 37.37L28.84 37.51L29.32 37.44L29.66 37.02L29.53 36.06L29.04 35.36L28.08 34.67L27.59 34.60ZM27.66 35.43L28.01 35.36L28.91 36.33L28.97 36.68L28.70 36.75L28.01 36.12ZM20.34 33.78L20.27 34.19L21.58 34.88L22.07 34.74L22.13 34.54L21.86 34.26L20.68 33.71ZM29.04 33.02L28.70 33.57L29.04 34.54L30.36 35.57L31.25 35.57L31.60 35.09L31.60 34.74L31.25 34.05L30.56 33.36L29.87 33.02ZM29.39 33.78L29.60 33.64L30.15 33.91L30.84 34.60L30.84 34.88L30.63 34.95L30.22 34.74ZM23.17 32.88L23.10 33.43L23.24 33.78L23.93 34.47L25.04 34.88L25.80 34.60L25.87 33.98L25.66 33.57L24.83 32.88L23.86 32.60ZM23.93 33.43L24.41 33.43L25.11 34.05L24.76 34.12L24.35 33.91ZM20.20 31.63L20.06 32.32L20.41 32.81L21.17 33.15L21.79 33.08L22.00 32.88L22.07 32.32L21.72 31.77L20.96 31.43ZM24.35 31.70L24.48 31.98L25.17 32.67L26.00 33.02L26.76 33.02L27.11 32.81L27.18 32.12L26.42 31.29L25.17 30.87L24.55 31.08ZM25.17 31.70L25.31 31.56L25.66 31.63L26.42 32.26L26.00 32.32ZM20.89 30.04L20.75 30.60L21.24 31.29L21.93 31.56L22.69 31.36L22.83 30.67L22.41 30.11L21.93 29.84L21.31 29.84ZM18.75 29.42L17.92 29.56L17.85 30.18L17.99 30.39L17.30 30.87L17.44 31.50L18.13 31.91L18.68 31.84L18.89 31.63L18.96 31.29L18.75 30.87L19.16 30.74L19.44 30.32L19.37 29.91ZM15.71 28.59L15.43 28.80L15.36 29.28L14.95 29.63L14.95 30.04L15.36 30.46L15.92 30.53L16.19 30.32L16.19 29.91L16.68 29.49L16.68 29.15L16.33 28.73ZM10.74 20.65L10.32 21.48L9.98 23.00L9.98 25.62L10.46 27.83L11.01 29.22L11.84 30.67L13.71 32.81L15.16 33.91L16.95 34.95L20.41 36.47L22.76 38.20L24.07 39.58L24.97 40.89L25.80 42.62L26.14 43.93L26.83 43.93L26.35 42.27L25.52 40.55L23.93 38.40L22.41 37.02L21.24 36.19L19.44 35.23L17.37 34.40L15.43 33.29L13.43 31.56L12.05 29.70L11.22 27.97L10.67 25.76L10.60 23.48L10.80 22.58L10.94 22.65L10.94 24.45L11.29 26.18L11.77 27.42L12.81 29.22L14.47 31.01L16.33 32.39L19.23 33.84L19.79 33.91L19.92 33.78L19.85 33.36L17.78 32.46L15.78 31.22L13.78 29.35L13.02 28.39L12.05 26.52L11.63 24.93L11.56 22.31L11.70 21.34L11.91 21.13L12.12 23.69L12.39 24.73L13.02 25.97L14.47 27.42L15.92 28.25L17.02 28.66L24.41 30.25L26.35 30.87L29.11 32.12L31.18 33.43L32.84 34.95L34.78 37.44L35.74 39.37L36.02 39.58L36.37 39.44L36.44 39.16L35.54 37.37L33.81 34.95L32.29 33.43L30.29 31.98L28.15 30.87L25.38 29.84L22.20 29.01L17.99 28.25L15.99 27.56L14.95 26.94L13.71 25.76L13.02 24.45L12.74 23.21L12.67 20.99L12.46 20.23L12.05 19.96L11.29 20.10ZM28.35 4.07L28.01 4.48L28.08 12.57L28.35 12.77L32.15 12.64L33.05 12.77L34.16 13.19L35.33 14.36L35.61 15.19L35.68 16.44L35.54 17.26L35.05 18.30L34.29 19.06L33.60 19.47L32.01 19.82L30.22 19.75L28.91 19.41L27.39 18.72L27.11 19.06L27.11 20.30L27.45 20.79L27.87 20.99L30.36 21.62L32.77 21.62L34.50 21.20L36.37 20.10L37.13 19.20L37.61 18.30L38.02 16.71L37.89 14.29L37.47 13.26L36.99 12.57L36.23 11.88L35.26 11.32L33.05 10.84L30.22 10.84L30.22 6.07L36.50 6.00L36.78 5.87L36.99 5.24L36.85 4.21L36.57 4.00Z",
	"tentacle:4": "M28.66 38.25L28.25 38.73L28.18 39.27L28.79 40.85L29.82 41.95L30.30 42.15L30.99 42.01L31.33 41.47L31.33 40.78L30.78 39.41L29.62 38.32L29.27 38.18ZM29.00 38.86L29.68 39.21L30.16 39.75L30.64 40.78L30.64 41.33L30.51 41.47L29.89 41.12L29.14 40.16L28.86 39.34ZM30.58 36.53L30.16 37.22L30.51 38.73L31.12 39.62L31.74 40.16L32.15 40.37L32.90 40.30L33.25 39.89L33.32 39.14L32.77 37.77L31.95 36.81L31.47 36.53ZM30.92 37.15L31.47 37.29L32.15 38.04L32.63 39.14L32.56 39.68L32.22 39.68L31.19 38.59L30.85 37.70ZM21.19 34.89L20.99 35.23L21.26 35.58L23.32 36.60L25.99 38.86L27.49 40.85L28.18 42.22L28.73 43.93L29.41 43.93L28.93 42.29L28.11 40.58L26.19 38.11L23.59 35.99L21.81 35.03ZM25.58 34.89L25.44 35.10L25.44 35.78L25.85 36.60L26.81 37.42L27.15 37.56L27.84 37.42L28.04 37.08L28.04 36.60L27.56 35.64L26.47 34.75L25.99 34.68ZM26.12 35.44L26.47 35.51L27.36 36.53L27.22 36.88L26.40 36.19L26.05 35.58ZM18.73 33.93L18.86 34.41L19.68 34.82L20.37 34.96L20.58 34.68L20.23 34.27L19.34 33.86L18.93 33.79ZM27.15 33.38L27.15 34.14L28.04 35.23L29.00 35.71L29.75 35.58L29.96 35.23L29.96 34.82L29.68 34.21L29.00 33.52L27.90 33.04L27.42 33.11ZM27.77 33.86L27.90 33.73L28.73 34.14L29.14 34.62L29.21 34.96L29.00 35.03L28.52 34.75ZM21.74 32.84L21.53 33.18L21.53 33.59L22.01 34.27L23.18 34.89L23.86 34.89L24.21 34.68L24.27 34.07L23.73 33.32L22.70 32.77ZM22.36 33.52L22.49 33.38L22.97 33.59L23.52 34.14L22.84 34.07ZM18.66 31.74L18.45 32.15L18.52 32.49L18.86 32.90L19.62 33.25L19.96 33.25L20.44 32.97L20.51 32.42L20.16 31.88L19.41 31.53ZM22.90 31.26L22.77 31.53L22.90 32.08L23.73 32.84L24.41 33.11L25.10 33.11L25.51 32.90L25.58 32.22L24.96 31.47L23.59 30.99ZM23.59 31.81L23.73 31.67L24.07 31.74L24.82 32.36L24.41 32.42ZM19.34 30.16L19.21 30.51L19.27 30.92L19.68 31.40L20.03 31.60L20.64 31.67L21.19 31.33L21.19 30.64L20.85 30.23L20.30 29.96L19.75 29.96ZM17.22 29.55L16.60 29.55L16.33 29.82L16.26 30.16L16.47 30.51L16.12 30.64L15.78 31.05L15.92 31.60L16.40 31.95L17.15 31.95L17.36 31.74L17.29 30.99L17.84 30.64L17.84 30.03ZM14.21 28.73L13.93 28.93L13.86 29.41L13.52 29.62L13.45 30.16L13.86 30.58L14.41 30.64L14.68 30.44L14.68 30.03L15.10 29.68L15.16 29.27L14.82 28.86ZM9.34 20.78L8.86 21.67L8.45 23.86L8.52 25.78L9.14 28.38L10.51 30.99L12.08 32.77L13.45 33.86L15.92 35.23L18.73 36.47L21.19 38.25L22.56 39.68L23.32 40.78L24.21 42.63L24.62 43.93L25.23 43.93L24.75 42.29L23.86 40.44L22.36 38.45L20.85 37.08L19.68 36.26L17.90 35.30L15.58 34.34L13.38 32.97L11.47 31.12L10.58 29.82L9.75 28.11L9.21 25.92L9.14 23.45L9.34 22.97L9.48 23.04L9.41 23.73L9.62 25.51L10.10 27.08L10.71 28.38L11.67 29.75L13.04 31.19L14.82 32.49L17.84 34.00L18.38 33.86L18.32 33.45L16.67 32.77L14.07 31.19L12.29 29.48L11.53 28.52L10.44 26.26L10.10 24.62L10.10 22.42L10.37 21.33L10.51 21.40L10.64 23.79L11.12 25.37L11.74 26.40L13.25 27.77L15.51 28.79L21.33 29.96L23.52 30.58L26.12 31.53L27.90 32.42L29.62 33.59L31.19 35.03L32.63 36.74L34.27 39.62L34.68 39.48L34.75 39.21L33.32 36.53L32.22 35.10L30.64 33.52L28.73 32.15L26.53 30.99L23.79 29.96L19.68 28.93L16.19 28.32L14.82 27.84L13.45 27.08L12.22 25.92L11.53 24.62L11.19 22.70L11.19 21.12L10.99 20.44L10.58 20.16L10.16 20.16ZM9.27 22.90L9.34 22.77L9.48 22.84ZM34.62 4.00L33.79 4.21L33.32 4.82L27.49 14.75L27.15 15.58L27.08 16.67L27.22 17.15L27.49 17.36L34.75 17.36L34.82 21.19L35.23 21.40L36.53 21.40L37.01 21.19L37.01 17.42L39.14 17.36L39.48 16.88L39.48 15.99L39.07 15.51L37.01 15.44L37.01 4.34L36.53 4.07ZM34.75 5.99L34.82 15.44L29.27 15.51L29.21 15.37Z",
	"tentacle:3": "M28.38 38.17L27.89 38.86L28.03 39.83L28.31 40.46L29.28 41.71L30.04 42.12L30.60 42.06L31.01 41.64L31.08 40.81L30.53 39.35L29.35 38.24L28.93 38.10ZM28.72 38.79L29.42 39.14L30.18 40.18L30.39 40.74L30.39 41.29L30.25 41.43L29.69 41.15L28.86 40.11L28.58 39.28ZM30.32 36.43L29.97 36.85L29.90 37.54L30.39 38.86L31.57 40.18L32.26 40.39L32.68 40.25L33.03 39.90L33.10 39.14L32.61 37.82L32.06 37.06L31.36 36.50L31.01 36.36ZM30.74 36.99L31.22 37.19L31.78 37.75L32.33 38.86L32.33 39.62L31.99 39.62L31.64 39.35L30.88 38.38L30.60 37.54ZM20.81 34.76L20.60 35.18L20.88 35.46L22.40 36.15L23.44 36.85L25.74 38.86L27.54 41.43L28.44 43.93L29.14 43.93L28.65 42.26L27.82 40.53L26.50 38.72L25.46 37.61L23.93 36.36L22.26 35.32ZM25.32 34.69L25.11 34.97L25.11 35.74L25.53 36.50L26.50 37.33L26.92 37.47L27.40 37.40L27.75 37.06L27.75 36.43L27.33 35.60L26.15 34.62L25.60 34.56ZM25.81 35.32L26.08 35.32L27.06 36.43L26.92 36.78L26.08 36.08L25.74 35.46ZM18.31 33.79L18.31 34.14L18.51 34.35L19.76 34.90L20.18 34.56L19.83 34.14L18.93 33.72L18.44 33.65ZM26.85 33.24L26.85 34.00L27.75 35.11L28.72 35.60L29.56 35.39L29.69 35.11L29.56 34.35L28.72 33.38L27.68 32.89L27.12 32.96ZM27.47 33.65L27.89 33.65L28.44 34.00L28.93 34.56L28.93 34.83L28.31 34.69ZM21.29 32.75L21.15 33.38L21.43 33.93L21.92 34.35L22.75 34.76L23.31 34.83L23.79 34.62L23.93 34.00L23.38 33.17L22.33 32.61L21.85 32.54ZM21.99 33.38L22.12 33.24L22.47 33.38L23.17 34.00L22.61 34.00ZM18.17 31.64L18.10 32.26L18.51 32.82L19.21 33.10L19.56 33.10L20.04 32.82L20.11 32.19L19.69 31.64L19.00 31.36L18.65 31.36ZM18.93 32.19L19.07 32.12L19.14 32.26ZM22.54 31.08L22.40 31.36L22.47 31.78L23.38 32.68L24.07 32.96L24.76 32.96L25.25 32.68L25.32 32.33L25.11 31.78L24.49 31.22L23.24 30.81ZM23.31 31.64L23.72 31.57L24.49 32.19L24.35 32.33L24.07 32.26ZM18.93 29.97L18.79 30.32L18.86 30.74L19.28 31.22L20.18 31.50L20.67 31.36L20.88 31.01L20.88 30.60L20.39 29.97L19.76 29.76ZM16.78 29.35L16.08 29.42L15.81 29.97L16.01 30.32L15.32 30.81L15.46 31.43L15.94 31.78L16.71 31.78L16.99 31.22L16.78 30.88L17.40 30.46L17.33 29.69ZM13.72 28.51L13.44 28.72L13.38 29.21L13.03 29.42L12.96 29.97L13.38 30.39L13.93 30.46L14.21 30.18L14.21 29.83L14.62 29.49L14.69 29.07L14.35 28.65ZM8.72 20.53L8.31 21.36L7.96 22.89L7.96 25.53L8.72 28.51L9.97 30.81L11.64 32.68L12.96 33.72L14.97 34.90L18.44 36.43L20.81 38.17L21.85 39.21L23.03 40.88L23.72 42.26L24.28 43.93L24.90 43.93L24.42 42.26L23.58 40.53L21.99 38.38L20.46 36.99L19.28 36.15L17.47 35.18L14.97 34.14L12.96 32.89L11.50 31.57L10.04 29.62L9.21 27.89L8.65 25.67L8.58 23.31L8.79 22.68L8.93 22.75L8.93 24.35L9.28 26.01L9.76 27.33L10.81 29.14L12.54 31.01L14.49 32.40L17.26 33.79L17.82 33.86L17.96 33.72L17.89 33.31L15.32 32.12L13.72 31.08L11.78 29.28L11.01 28.31L10.25 26.92L9.62 24.90L9.49 23.10L9.83 21.01L10.04 21.36L10.04 22.96L10.39 24.62L11.01 25.88L12.26 27.19L13.24 27.82L15.04 28.58L22.75 30.25L25.81 31.36L27.33 32.12L29.35 33.44L31.01 34.97L32.40 36.64L33.44 38.31L33.86 39.35L34.07 39.56L34.42 39.49L34.56 39.14L34.00 37.96L32.19 35.25L30.32 33.31L28.10 31.78L26.22 30.81L23.44 29.76L19.28 28.72L15.74 28.10L14.00 27.47L13.03 26.92L11.78 25.74L11.01 24.35L10.74 23.24L10.67 20.81L10.46 20.11L10.25 19.90L9.62 19.83ZM8.72 22.61L8.79 22.47L8.93 22.54ZM35.39 4.00L33.31 4.00L31.57 4.42L29.83 5.39L29.56 6.01L29.62 7.12L29.97 7.33L32.47 6.01L33.51 5.81L34.69 5.88L35.67 6.29L36.29 6.92L36.71 7.82L36.78 8.93L36.57 9.76L36.22 10.46L35.60 11.08L34.90 11.50L34.00 11.78L31.22 11.85L30.88 12.26L30.88 13.17L31.29 13.65L34.00 13.65L35.11 13.86L36.22 14.35L37.19 15.25L37.68 16.50L37.61 17.75L37.19 18.72L36.50 19.42L35.32 19.97L34.56 20.11L32.40 19.97L29.35 18.72L29.07 19.14L29.07 20.04L29.28 20.67L30.60 21.43L32.19 21.85L33.31 21.99L35.18 21.92L36.64 21.57L37.82 21.01L38.79 20.18L39.35 19.42L39.97 17.68L39.97 15.94L39.21 14.28L38.03 13.24L37.12 12.82L35.94 12.54L36.64 12.33L37.82 11.64L38.44 10.94L38.86 10.18L39.21 8.72L39.14 7.26L38.86 6.36L38.38 5.53L37.82 4.97L36.71 4.35Z",
	"meteor:1": "M31.14 4.00L20.63 15.23L12.88 5.67L13.89 15.45L14.33 18.28L14.25 18.86L4.98 13.06L9.18 24.72L9.11 25.16L5.05 33.28L13.24 32.55L13.38 32.70L15.63 43.93L21.79 36.25L22.22 36.32L30.78 40.67L31.57 33.06L31.93 31.17L40.49 31.17L41.50 31.32L42.22 31.68L42.95 31.17L42.59 30.38L39.91 27.84L33.53 20.88L37.59 12.84L30.63 14.94L30.49 14.80ZM29.40 8.20L29.54 8.35L29.40 17.41L34.54 15.16L34.83 15.23L31.36 20.67L35.78 26.17L39.47 29.36L39.69 29.72L30.63 29.80L30.05 35.45L29.54 38.49L23.60 34.29L22.88 33.93L17.22 39.94L16.43 40.59L15.27 31.75L7.59 31.75L7.44 31.61L11.50 25.09L7.73 16.61L7.88 16.54L16.43 21.90L14.83 10.96L14.98 10.81L20.49 16.46ZM23.31 19.87L22.44 19.87L21.36 21.97L21.86 21.97L22.15 21.75L22.22 22.26L21.21 26.46L21.21 27.12L21.07 27.26L20.63 30.38L20.34 31.39L20.92 30.67L20.85 30.01L21.21 29.29L21.07 29.22L21.36 29.00L21.43 28.57L21.79 28.42L21.93 26.90L22.37 26.54L22.59 25.01L23.82 20.52L23.67 20.01ZM21.14 28.13L21.36 28.13ZM21.72 27.48L21.79 28.13L21.57 28.35L21.43 28.13L21.50 27.70ZM21.72 27.04L21.72 27.33ZM22.30 26.03L22.30 26.46L22.08 26.32Z",
	"meteor:2": "M31.22 4.00L20.71 15.19L19.69 14.17L12.92 5.69L14.27 17.76L14.27 18.92L4.98 13.08L9.25 24.81L5.05 33.36L13.25 32.61L13.46 32.88L13.53 33.69L13.73 34.10L13.73 34.64L15.69 43.93L21.93 36.27L30.75 40.68L30.95 39.86L31.83 31.39L32.10 31.19L40.37 31.19L41.59 31.39L42.00 31.66L42.34 31.66L42.95 31.25L42.61 30.37L42.20 30.17L33.66 21.08L33.66 20.75L37.59 12.88L31.15 14.85L30.54 14.92ZM29.46 8.20L29.59 8.41L29.39 17.42L34.81 15.19L31.42 20.68L35.69 26.10L39.76 29.69L39.63 29.83L30.68 29.83L29.80 37.90L29.59 38.51L23.29 34.10L22.88 33.97L16.51 40.68L16.17 39.25L15.29 31.73L7.49 31.73L7.49 31.53L11.56 25.08L7.76 16.61L7.97 16.54L16.51 22.03L14.88 10.92L15.02 10.85L18.81 14.85L20.58 16.47ZM25.32 18.37L24.78 18.10L23.83 18.10L23.08 18.37L21.73 19.32L20.71 20.61L20.64 20.95L21.19 21.36L21.73 21.36L22.20 21.15L22.34 20.75L23.29 19.80L24.51 19.19L24.85 19.32L24.78 20.61L24.51 21.36L23.15 23.80L22.00 24.88L21.66 25.56L20.51 26.37L19.76 27.25L18.47 27.73L18.47 28.41L18.88 28.95L19.63 29.02L20.98 28.34L22.81 27.73L23.83 27.53L25.73 27.46L26.54 27.25L26.61 27.05L27.97 27.05L26.95 26.71L24.92 26.64L24.71 26.78L24.10 26.71L24.17 26.85L24.31 26.71L24.51 26.92L24.78 26.85L24.78 27.05L23.76 27.05L23.56 27.19L23.42 26.98L23.76 26.71L23.02 26.85L22.68 26.58L22.41 26.64L22.27 26.51L23.76 24.88L23.90 24.41L25.25 22.44L25.66 21.42L25.93 19.59L25.80 18.98ZM22.81 27.53L23.02 27.53ZM25.73 27.32L26.00 27.32ZM24.85 27.25L25.53 27.19L25.73 27.32L25.19 27.46ZM25.93 27.05L26.00 27.19L25.86 27.25ZM24.92 26.85L25.32 26.71L25.46 26.92ZM24.17 19.19L24.44 19.19Z",
	"meteor:3": "M31.50 4.00L30.45 4.00L20.51 14.66L12.36 4.66L13.87 18.01L13.74 18.47L4.07 12.36L8.54 24.72L4.13 33.67L5.91 33.41L6.37 33.47L7.95 33.34L8.08 33.21L12.82 32.88L15.05 43.93L15.91 43.93L21.76 36.70L31.11 41.37L31.83 34.66L32.03 33.93L32.22 31.50L32.36 31.37L41.04 31.37L42.42 31.57L43.01 31.89L43.87 31.37L43.67 30.78L41.76 29.00L34.07 20.78L34.13 20.38L38.28 12.09L31.37 14.26L30.84 14.26ZM29.72 7.36L29.86 8.61L29.66 12.75L29.66 16.96L34.92 14.66L35.38 14.66L31.83 20.05L31.76 20.38L34.46 23.93L36.11 25.84L37.49 27.22L40.51 29.79L40.38 29.92L32.75 29.86L32.42 29.99L30.97 29.99L30.38 35.71L30.18 36.30L30.18 37.22L29.86 39.07L22.88 34.26L16.11 41.30L15.84 40.38L14.86 32.03L14.66 31.89L6.70 31.89L10.91 24.99L6.96 16.11L7.16 16.04L16.11 21.70L14.39 10.51L14.46 10.12L20.32 15.97L28.34 8.47ZM25.97 19.13L24.33 18.93L23.01 19.26L21.83 19.79L20.58 20.64L19.99 21.43L19.92 22.16L20.51 22.55L21.11 22.62L21.37 22.49L21.37 22.03L21.76 21.57L23.01 20.71L24.26 20.18L25.64 20.05L25.64 20.45L24.53 22.03L23.61 22.75L22.68 22.82L22.03 23.14L21.83 23.01L21.30 23.54L21.24 24.07L21.76 24.59L22.88 24.39L23.67 23.93L24.72 23.80L25.51 24.07L25.71 24.26L25.78 24.72L25.64 25.38L25.12 26.43L24.26 27.49L22.68 28.87L20.45 29.72L19.79 29.86L19.07 29.79L18.93 29.92L18.74 29.46L19.13 28.67L20.38 27.49L18.67 28.61L18.08 29.26L17.88 29.79L17.68 29.86L18.01 30.12L18.01 30.38L18.41 30.45L18.14 30.64L18.28 30.84L18.54 30.84L18.47 31.11L19.20 31.24L20.78 30.91L22.75 30.12L24.33 29.00L25.71 27.55L26.37 26.37L26.57 24.92L26.04 23.61L25.51 23.14L25.18 23.08L24.92 22.75L25.84 21.96L26.50 20.84L26.57 19.86ZM20.38 30.05L20.58 29.92L20.71 30.05L20.51 30.18ZM19.99 30.12L20.25 29.92L20.45 30.18L20.05 30.25ZM21.57 29.66L21.04 30.05L20.71 29.99L20.84 29.72ZM22.88 29.07L22.42 29.46L22.03 29.33L22.16 29.13ZM23.67 28.61L23.74 28.41L23.93 28.47Z"
}, Ot = 1e3, Q = (e) => ({
	x: 85 + e % 7 * 90 + 3,
	y: 265 + Math.floor(e / 7) * 90 + 3,
	w: 84,
	h: 84
}), kt = [
	[24, 0],
	[48, 24],
	[24, 48],
	[0, 24]
], $ = {
	h: "#18313a",
	r: "#18313a",
	w: "#3a8fb4",
	l: "#88c7da",
	v: "#d95731",
	a: "#706fbb",
	s: "#c18b2c"
}, At = "#fffef8";
function jt({ name: e, amount: t = 1, ink: n, surface: r = At }) {
	let i = n ?? (e === "tree" || e === "clover" ? "#367759" : e === "cactus" || e === "oasis" ? "#728d32" : e === "lamp" || e === "battery" ? "#b98329" : e === "rainbow" || [
		"A",
		"B",
		"C",
		"ritual"
	].includes(e) ? "#7c5a97" : "#355e77"), a = Dt[e];
	if (a) {
		let n = [
			"cactus",
			"sheep",
			"tree"
		].includes(e) ? t : 1;
		return /* @__PURE__ */ d("g", { children: (n === 1 ? [[
			0,
			0,
			1
		]] : n === 2 ? [[
			-1,
			2,
			.6
		], [
			21,
			18,
			.6
		]] : n === 3 ? [
			[
				0,
				3,
				.52
			],
			[
				24,
				3,
				.52
			],
			[
				12,
				22,
				.52
			]
		] : [
			[
				-2,
				-2,
				.48
			],
			[
				26,
				-2,
				.48
			],
			[
				12,
				13,
				.48
			],
			[
				-2,
				26,
				.48
			],
			[
				26,
				26,
				.48
			]
		]).map(([e, t, n], r) => /* @__PURE__ */ d("path", {
			d: a,
			fill: i,
			fillRule: "evenodd",
			transform: `translate(${e} ${t}) scale(${n})`
		}, r)) });
	}
	let o;
	switch (e) {
		case "crater":
			o = /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "m6 27 8-9 8 3 8-10 10 12 4 11-13 8-17-3Z",
					fill: "#a3aaa1"
				}),
				/* @__PURE__ */ d("ellipse", {
					cx: 25,
					cy: 28,
					rx: 14,
					ry: 8,
					fill: "#6d776f"
				}),
				/* @__PURE__ */ d("path", {
					d: "m10 16-4-5m26-2 3-5",
					stroke: i,
					strokeWidth: 2
				})
			] });
			break;
		case "volcano":
			o = /* @__PURE__ */ f(u, { children: [
				/* @__PURE__ */ d("path", {
					d: "m5 43 13-26h12l14 26Z",
					fill: "#8e6550",
					stroke: "#5d5549",
					strokeWidth: 2
				}),
				/* @__PURE__ */ d("path", {
					d: "m18 18 6 8 6-8m-6 8 7 15",
					fill: "none",
					stroke: "#e97735",
					strokeWidth: 4
				}),
				/* @__PURE__ */ d("path", {
					d: "m18 9 3-5m9 6 3-5",
					stroke: "#d35833",
					strokeWidth: 3
				})
			] });
			break;
		case "battery":
			o = /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("rect", {
				x: 12,
				y: 10,
				width: 24,
				height: 33,
				rx: 4,
				fill: "#e1d3a1",
				stroke: i,
				strokeWidth: 2
			}), /* @__PURE__ */ d("path", {
				d: "M20 6h8m-4 10-6 13h8l-3 9 9-15h-9",
				fill: "none",
				stroke: i,
				strokeWidth: 3
			})] });
			break;
		case "tower":
			o = /* @__PURE__ */ d(u, { children: Array.from({ length: t }, (e, n) => /* @__PURE__ */ d("path", {
				transform: `translate(${(n - (t - 1) / 2) * 13} 0)`,
				d: Dt.towerGlyph,
				fill: i,
				fillRule: "evenodd"
			}, n)) });
			break;
		case "north":
		case "east":
		case "south":
		case "west":
			o = /* @__PURE__ */ d("path", {
				d: "m24 5-14 16h9v22h10V21h9Z",
				fill: i,
				transform: `rotate(${[
					"north",
					"east",
					"south",
					"west"
				].indexOf(e) * 90} 24 24)`
			});
			break;
		case "bendH":
		case "bendR":
		case "stationH":
		case "stationR":
		case "overH":
		case "overR": {
			let t = e.startsWith("station"), i = e.startsWith("bend"), a = e.endsWith("H") ? "h" : "r";
			o = /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("path", {
				d: t ? "M16 16h16v16H16Z" : i ? "M24 0Q24 24 0 24" : "M24 0V48",
				fill: "none",
				stroke: n ?? "#879a97",
				strokeOpacity: .65,
				strokeWidth: t ? 2 : 10,
				strokeDasharray: "3 3"
			}), /* @__PURE__ */ d(Ft, {
				piece: {
					id: e,
					groups: [(t ? [0] : i ? [1, 2] : [1, 3]).map((e) => ({
						side: e,
						kind: a
					}))]
				},
				ink: n,
				surface: r
			})] });
			break;
		}
		default:
			if (E[e]) {
				let t = E[e];
				o = /* @__PURE__ */ d("g", {
					transform: "translate(6 6)",
					children: t.map(([e, t], r) => /* @__PURE__ */ d("rect", {
						x: e * 11,
						y: t * 11,
						width: 10,
						height: 10,
						fill: n ?? "#c728c4"
					}, r))
				});
				break;
			}
			if (Ve[e]) {
				let t = Ve[e], r = Math.max(...t.map((e) => e[0])), i = Math.max(...t.map((e) => e[1])), a = 34 / Math.max(r, i, 1), s = (48 - r * a) / 2, c = (48 - i * a) / 2;
				o = /* @__PURE__ */ f("g", {
					stroke: n ?? "#64431e",
					fill: "none",
					children: [/* @__PURE__ */ d("path", {
						d: t.map(([e, t], n) => `${n ? "L" : "M"}${s + e * a} ${c + t * a}`).join(""),
						strokeWidth: 1.5
					}), t.slice(1, -1).map(([e, t], n) => /* @__PURE__ */ d("path", {
						d: `M${s + e * a - 2.5} ${c + t * a}h5m-2.5-2.5v5`,
						strokeWidth: 1.2
					}, n))]
				});
				break;
			}
			o = /* @__PURE__ */ d("text", {
				x: 24,
				y: 33,
				textAnchor: "middle",
				fontSize: 28,
				fontWeight: 800,
				fill: i,
				children: e === "any" ? "?" : /^\d+$/.test(e) ? e : e === "nuke" ? "×" : e === "free" ? "↗" : e === "move" ? "↔" : e === "destroy" ? "×" : "◆"
			});
	}
	return /* @__PURE__ */ d("g", { children: o });
}
function Mt(e) {
	if (e.length === 4) return {
		area: "M0 0H48V48H0Z",
		shore: "",
		rotation: 0
	};
	if (e.length === 3) {
		let t = [
			0,
			1,
			2,
			3
		].find((t) => !e.includes(t)), n = "M0 0C13 0 6 23 24 23S35 0 48 0";
		return {
			area: n + "V48H0Z",
			shore: n,
			rotation: t * 90
		};
	}
	if (e.length === 2 && e.includes((e[0] + 2) % 4)) return {
		area: "M8 0H40C40 14 30 14 34 24S40 35 40 48H8C8 35 10 34 14 24S8 14 8 0Z",
		shore: "M8 0C8 14 18 14 14 24S8 35 8 48M40 0C40 14 30 14 34 24S40 35 40 48",
		rotation: e[0] * 90
	};
	if (e.length === 2) {
		let t = e.find((t) => e.includes((t + 1) % 4)), n = "M48 48C48 35 31 43 28 28S16 20 14 10 0 10 0 0";
		return {
			area: "M0 0H48V48" + n.slice(6) + "Z",
			shore: n,
			rotation: t * 90
		};
	}
	let t = "M0 0C0 12 9 23 24 23S48 12 48 0";
	return {
		area: t + "Z",
		shore: t,
		rotation: (e[0] ?? 0) * 90
	};
}
function Nt(e, t = [24, 24]) {
	return e.length === 2 ? `M${kt[e[0]]}Q24 24 ${kt[e[1]]}` : e.map((e) => `M${kt[e]}L${t}`).join("");
}
function Pt(e, t) {
	if (!t) return [24, 24];
	if (e.length === 1) {
		let [t, n] = kt[e[0].side];
		return [24 + (t - 24) * .55, 24 + (n - 24) * .55];
	}
	if (e.length === 2 && (e[0].side + 2) % 4 !== e[1].side) {
		let [t, n] = e.map((e) => kt[e.side]);
		return [(t[0] + n[0] + 48) / 4, (t[1] + n[1] + 48) / 4];
	}
	return [24, 24];
}
function Ft({ piece: e, onBoard: t = !1, ink: r, surface: i = At }) {
	let a = n().replaceAll(":", "");
	return /* @__PURE__ */ f("g", { children: [
		e.groups.flatMap((t) => [...new Set(t.map((e) => e.kind))].map((n) => ({
			ports: t.filter((e) => e.kind === n),
			center: Pt(t, e.groups.length > 1)
		}))).map(({ ports: n, center: o }, s) => {
			let c = n[0]?.kind, l = Nt(n.map((e) => e.side), o);
			if (!c) return null;
			if (c === "l" || c === "v") {
				let e = Mt(n.map((e) => e.side));
				return /* @__PURE__ */ f("g", {
					transform: `rotate(${e.rotation} 24 24)`,
					children: [
						/* @__PURE__ */ d("defs", { children: /* @__PURE__ */ d("clipPath", {
							id: `${a}-${s}`,
							children: /* @__PURE__ */ d("path", { d: e.area })
						}) }),
						/* @__PURE__ */ d("path", {
							d: e.area,
							fill: t ? c === "l" ? "#9bd6e2" : "#d95731" : r ?? $[c],
							fillOpacity: c === "l" ? .28 : .85
						}),
						/* @__PURE__ */ d("path", {
							d: e.shore,
							fill: "none",
							stroke: r ?? $[c],
							strokeWidth: 1.4
						}),
						/* @__PURE__ */ d("g", {
							clipPath: `url(#${a}-${s})`,
							fill: "none",
							stroke: c === "v" ? t ? "#f4c878" : i : r ?? "#28667b",
							strokeWidth: 1.1,
							children: [
								[7, 8],
								[29, 7],
								[17, 19],
								[37, 25],
								[7, 33],
								[25, 40]
							].map(([e, t], n) => c === "l" ? /* @__PURE__ */ d("path", { d: `M${e} ${t}q3-2 5 0t5 0` }, n) : /* @__PURE__ */ f("g", { children: [/* @__PURE__ */ d("circle", {
								cx: e + 2,
								cy: t,
								r: 1.6
							}), /* @__PURE__ */ d("circle", {
								cx: e + 5,
								cy: t + 2,
								r: .5
							})] }, n))
						})
					]
				}, s);
			}
			if (e.underground) {
				let t = r ?? "#30545b", a = c === "r" && n.length === 2 && (n[0].side + 2) % 4 === n[1].side && e.groups.some((e) => e.length === 2 && e.every((e) => e.kind === "h") && (e[0].side + 2) % 4 === e[1].side);
				return /* @__PURE__ */ d("g", { children: c === "h" ? /* @__PURE__ */ f(u, { children: [
					/* @__PURE__ */ d("path", {
						d: l,
						fill: "none",
						stroke: i,
						strokeWidth: 12
					}),
					/* @__PURE__ */ d("path", {
						d: l,
						fill: "none",
						stroke: t,
						strokeWidth: 9
					}),
					/* @__PURE__ */ d("path", {
						d: l,
						fill: "none",
						stroke: i,
						strokeWidth: 6
					}),
					n.map((e) => /* @__PURE__ */ d("path", {
						d: "M18 0H30V3H18Z",
						transform: `rotate(${e.side * 90} 24 24)`,
						fill: i,
						stroke: t,
						strokeWidth: .8
					}, e.side))
				] }) : /* @__PURE__ */ d("path", {
					d: a ? "M0 24H14M14 12Q20 24 14 36M48 24H34M34 12Q28 24 34 36" : l,
					transform: a ? `rotate(${n[0].side % 2 == 0 ? 90 : 0} 24 24)` : void 0,
					fill: "none",
					stroke: t,
					strokeWidth: 1.5
				}) }, s);
			}
			let p = n.length === 1 && !e.station && !["stationH", "stationR"].includes(e.id) && ![
				"A",
				"B",
				"C",
				"ritual"
			].includes(e.mark ?? "") && e.groups.some((e) => e.length === 1 && e[0].side === n[0].side && e[0].kind === c);
			return c === "h" ? /* @__PURE__ */ f("g", { children: [
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: i,
					strokeWidth: 17,
					strokeLinecap: p ? "round" : void 0
				}),
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: r ?? $.h,
					strokeWidth: 12,
					strokeLinecap: p ? "round" : void 0
				}),
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: i,
					strokeWidth: 8,
					strokeLinecap: p ? "round" : void 0
				}),
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: r ?? $.h,
					strokeWidth: 1.5,
					strokeDasharray: "5 3"
				}),
				p && /* @__PURE__ */ d("circle", {
					cx: o[0],
					cy: o[1],
					r: 1.5,
					fill: r ?? $.h
				})
			] }, s) : c === "r" ? /* @__PURE__ */ f("g", { children: [
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: i,
					strokeWidth: 13
				}),
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: r ?? $.r,
					strokeWidth: 10,
					strokeDasharray: "1.8 4"
				}),
				/* @__PURE__ */ d("path", {
					d: l,
					fill: "none",
					stroke: r ?? $.r,
					strokeWidth: 2.2
				}),
				p && /* @__PURE__ */ d("circle", {
					cx: o[0],
					cy: o[1],
					r: 2,
					fill: r ?? $.r
				})
			] }, s) : /* @__PURE__ */ d("path", {
				d: l,
				fill: "none",
				stroke: r ?? $[c],
				strokeWidth: c === "w" ? 8 : 4,
				strokeDasharray: c === "a" ? "1 5" : void 0,
				strokeLinecap: "round"
			}, s);
		}),
		e.groups.flatMap((t, n) => z(e, n) && (!e.underground || t.some((e) => e.kind === "r")) ? [{
			g: t,
			i: n
		}] : []).map(({ g: t, i: n }) => {
			let [a, o] = Pt(t, e.groups.length > 1), s = !e.underground && e.groups.length > 1, c = s ? 10 : 14;
			return /* @__PURE__ */ d("rect", {
				x: a - c / 2,
				y: o - c / 2,
				width: c,
				height: c,
				rx: e.underground ? 8 : 1,
				fill: e.underground ? i : r ?? "#18313a",
				stroke: r ?? "#18313a",
				strokeWidth: s ? 1 : 2
			}, n);
		}),
		e.groups.flat().filter((e) => e.kind === "s").map((e) => /* @__PURE__ */ d("path", {
			d: "m24 0-6 9h12Z",
			transform: `rotate(${e.side * 90} 24 24)`,
			fill: r ?? "#c18b2c",
			stroke: r ?? "#6c572b",
			strokeWidth: 1
		}, e.side)),
		e.trails?.map((e, t) => {
			let n = e.map((e) => [e === 1 || e === 2 ? 48 : 0, e >= 2 ? 48 : 0]), i;
			if (n.length === 1) {
				let [e, t] = n[0];
				i = `M${e} ${t}L${e === 0 ? 15 : 33} ${t === 0 ? 13 : 35}`;
			} else if (n.length === 2) {
				let [e, t] = n;
				i = `M${e}Q${e.map((e, n) => (e + t[n]) / 2 * .3 + 24 * .7)} ${t}`;
			} else {
				let t = ([
					0,
					1,
					2,
					3
				].find((t) => !e.includes(t)) + 2) % 4, r = [t === 1 || t === 2 ? 36 : 12, t >= 2 ? 36 : 12];
				i = n.map((e) => `M${e}L${r}`).join("");
			}
			return /* @__PURE__ */ d("path", {
				d: i,
				fill: "none",
				stroke: r ?? "#526b35",
				strokeWidth: 1.1
			}, t);
		}),
		e.mark && /* @__PURE__ */ d("g", {
			transform: e.mark === "ritual" && e.ritualGroup !== void 0 ? (() => {
				let [t, n] = Pt(e.groups[e.ritualGroup], !0);
				return `translate(${t - 9.6} ${n - 9.6}) scale(.4)`;
			})() : e.groups.length && e.mark !== "volcano" ? "translate(26 1) scale(.39)" : void 0,
			children: /* @__PURE__ */ d(jt, {
				name: e.mark,
				ink: r,
				amount: e.mark === "clue" ? 1 : e.mark === "tree" ? e.groups.length ? 3 : 5 : e.amount
			})
		}),
		e.mark === "clue" && !t && Array.from({ length: e.amount ?? 1 }, (e, t) => /* @__PURE__ */ d("path", {
			d: Dt.footstep,
			fill: r ?? "#718c3d",
			fillRule: "evenodd",
			transform: `translate(${6 + t * 7} 1) scale(.17)`
		}, t))
	] });
}
function It({ id: e, rotation: t = 0, mirror: n = !1, className: r, ink: i, surface: a, expansion: o }) {
	let s = e.startsWith("tower"), c = s ? Number(e.slice(-1)) * 2 + 1 : 0, l = Dt[`${o}:${e}`];
	return l ? /* @__PURE__ */ d("svg", {
		className: r,
		viewBox: "-4 -4 56 56",
		"aria-hidden": "true",
		children: /* @__PURE__ */ d("path", {
			d: l,
			fill: i ?? "#20313a",
			fillRule: "evenodd"
		})
	}) : /* @__PURE__ */ f("svg", {
		className: r,
		viewBox: "-4 -4 56 56",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ d("g", {
				transform: s ? "translate(0 -2) scale(1 .78)" : void 0,
				children: S[e] ? /* @__PURE__ */ d(Ft, {
					piece: D(S[e], t, n),
					ink: i,
					surface: a
				}) : /* @__PURE__ */ d("g", {
					transform: `rotate(${t * 90} 24 24)${n ? " translate(48 0) scale(-1 1)" : ""}`,
					children: /* @__PURE__ */ d(jt, {
						name: e,
						ink: i,
						surface: a
					})
				})
			}),
			o === "weather" && [
				"cloud",
				"snow",
				"storm"
			].includes(e) && /* @__PURE__ */ f("g", {
				stroke: i ?? "#2b308d",
				fill: "none",
				strokeWidth: 1.2,
				children: [/* @__PURE__ */ d("rect", {
					x: 39,
					y: 39,
					width: 8,
					height: 8
				}), /* @__PURE__ */ d("path", { d: "M43 40v6m-3-3h6" })]
			}),
			s && /* @__PURE__ */ f("g", {
				fill: i ?? "#a65351",
				children: [
					/* @__PURE__ */ d("text", {
						x: 29,
						y: 47,
						fontSize: 13,
						textAnchor: "end",
						fontWeight: 700,
						children: c
					}),
					/* @__PURE__ */ d("circle", {
						cx: 38,
						cy: 42,
						r: 6,
						fill: "none",
						stroke: i ?? "#a65351",
						strokeWidth: 1.2
					}),
					/* @__PURE__ */ d("circle", {
						cx: 38,
						cy: 42,
						r: 2.3
					})
				]
			})
		]
	});
}
function Lt({ board: e, config: t, under: r = !1, preview: i, path: a = [] }) {
	let o = n().replaceAll(":", ""), s = r ? e.under : e.cells, c = (e, t = !1) => [85 + (e % (t ? 8 : 7) + (t ? 0 : .5)) * 90, 265 + (Math.floor(e / (t ? 8 : 7)) + (t ? 0 : .5)) * 90];
	return /* @__PURE__ */ f("g", {
		pointerEvents: "none",
		children: [
			/* @__PURE__ */ f("defs", { children: [
				/* @__PURE__ */ d("clipPath", {
					id: `${o}-edge`,
					children: /* @__PURE__ */ d("path", { d: "M16 10 787 17 782 976 17 987Z" })
				}),
				/* @__PURE__ */ f("filter", {
					id: `${o}-wash`,
					x: "-20%",
					y: "-20%",
					width: "140%",
					height: "140%",
					children: [
						/* @__PURE__ */ d("feTurbulence", {
							type: "fractalNoise",
							baseFrequency: ".023",
							numOctaves: 2,
							seed: 7,
							result: "grain"
						}),
						/* @__PURE__ */ d("feDisplacementMap", {
							in: "SourceGraphic",
							in2: "grain",
							scale: 24,
							xChannelSelector: "R",
							yChannelSelector: "G"
						}),
						/* @__PURE__ */ d("feGaussianBlur", { stdDeviation: 1.5 })
					]
				}),
				s.map((e, t) => e && /* @__PURE__ */ d("mask", {
					id: `${o}-ink-${t}`,
					maskUnits: "userSpaceOnUse",
					x: -8,
					y: -8,
					width: 106,
					height: 106,
					children: /* @__PURE__ */ d("path", {
						className: "ri-ink-stroke",
						d: "M-30-30 120 120",
						pathLength: 1,
						stroke: "white",
						strokeWidth: 150,
						fill: "none"
					})
				}, `${t}:${e.id}:${e.round}:${e.rotation}:${e.mirror}`))
			] }),
			/* @__PURE__ */ d("path", {
				d: "M23 19 796 24 793 984 24 995Z",
				fill: "var(--ri-blue)",
				opacity: .14
			}),
			/* @__PURE__ */ f("g", {
				clipPath: `url(#${o}-edge)`,
				children: [
					/* @__PURE__ */ d("rect", {
						width: 800,
						height: 1e3,
						fill: "var(--ri-paper)"
					}),
					/* @__PURE__ */ d("g", {
						filter: `url(#${o}-wash)`,
						children: Array.from({ length: 38 }, (e, t) => {
							let n = (t * 223 + 71) % 800, r = (t * 317 + 97) % 1e3, i = 100 + t * 37 % 150, a = 55 + t * 53 % 90;
							return /* @__PURE__ */ d("path", {
								d: `M${n - i} ${r}q${i * .2} ${-a * .9} ${i} ${-a}t${i} ${a}q${-i * .1} ${a * .8} ${-i} ${a}t${-i} ${-a}Z`,
								fill: t % 3 == 0 ? "white" : t % 3 == 1 ? "var(--ri-pigment)" : "var(--ri-bloom)",
								opacity: t % 3 == 1 ? .12 : .2
							}, t);
						})
					}),
					/* @__PURE__ */ d("path", {
						d: "M0 80q240 75 450-12t350 30v65q-180-60-420 6T0 143ZM0 700q100-55 220-9t400-9 210 65v220H0Z",
						fill: "var(--ri-bloom)",
						opacity: .2
					})
				]
			}),
			/* @__PURE__ */ d("path", {
				d: "M16 10 787 17 782 976 17 987Z",
				fill: "none",
				stroke: "var(--ri-blue)",
				strokeOpacity: .35
			}),
			/* @__PURE__ */ f("text", {
				x: 85,
				y: 62,
				fontFamily: "Georgia,serif",
				fontSize: 35,
				fontWeight: 800,
				fill: "#20313a",
				children: ["RAILROAD ", /* @__PURE__ */ d("tspan", {
					fill: "var(--ri-red)",
					fontStyle: "italic",
					children: "INK"
				})]
			}),
			/* @__PURE__ */ d("text", {
				x: 714,
				y: 59,
				textAnchor: "end",
				fontSize: 12,
				fill: "var(--ri-blue)",
				letterSpacing: 3,
				children: "7 × 7"
			}),
			/* @__PURE__ */ d("path", {
				d: "M85 178h630",
				stroke: "var(--ri-red)",
				strokeWidth: 2
			}),
			Array.from({ length: 49 }, (e, n) => {
				let i = Q(n);
				return /* @__PURE__ */ f("g", { children: [
					/* @__PURE__ */ d("rect", {
						x: i.x - 3,
						y: i.y - 3,
						width: 90,
						height: 90,
						fill: "white",
						fillOpacity: .045,
						stroke: "#20343b",
						strokeOpacity: .65,
						strokeWidth: 1
					}),
					/* @__PURE__ */ d("rect", {
						x: i.x + 64,
						y: i.y + 2,
						width: 15,
						height: 15,
						rx: 1,
						fill: "#f6f5e8",
						opacity: .85
					}),
					t.challenge && !r && P[n] && /* @__PURE__ */ f("g", {
						transform: `translate(${i.x + 2} ${i.y + 2})`,
						children: [/* @__PURE__ */ d("rect", {
							width: 16,
							height: 16,
							rx: 2,
							fill: P[n] === "factory" ? "#42575b" : P[n] === "university" ? "#aa974f" : "#4b98ab"
						}), /* @__PURE__ */ d("path", {
							d: P[n] === "factory" ? "M3 12V6l3 2V5l3 2V3h3v9Z" : P[n] === "village" ? "m2 7 6-5 6 5h-2v7H4V7Z" : "M2 14V6l6-4 6 4v8h-2V8h-3v6H7V8H4v6Z",
							fill: "#f7f4dd"
						})]
					})
				] }, n);
			}),
			/* @__PURE__ */ d("rect", {
				x: 85,
				y: 265,
				width: 630,
				height: 630,
				fill: "none",
				stroke: "#20343b",
				strokeWidth: 3
			}),
			/* @__PURE__ */ d("rect", {
				x: 265,
				y: 445,
				width: 270,
				height: 270,
				fill: "none",
				stroke: "var(--ri-red)",
				strokeWidth: 2.5
			}),
			N.map((t, n) => {
				let r = Q(t.cell), [i, a] = t.side === 0 ? [r.x + 42, 265] : t.side === 1 ? [715, r.y + 42] : t.side === 2 ? [r.x + 42, 895] : [85, r.y + 42];
				return /* @__PURE__ */ f("g", {
					transform: `translate(${i} ${a}) rotate(${t.side * 90})`,
					children: [
						/* @__PURE__ */ d("path", {
							d: "m0-29 12 15H6V6H-6v-20h-6Z",
							fill: "var(--ri-red)"
						}),
						/* @__PURE__ */ d("g", {
							transform: "translate(-9 -25) scale(.375)",
							children: /* @__PURE__ */ d(Ft, { piece: S[t.kind + "I"] })
						}),
						e.exitMarks[n] && /* @__PURE__ */ d("g", {
							transform: "translate(-18 -56) scale(.7)",
							children: /* @__PURE__ */ d(jt, { name: e.exitMarks[n] })
						})
					]
				}, n);
			}),
			e.enhanced.map((e) => {
				let t = Q(e);
				return /* @__PURE__ */ d("rect", {
					x: t.x + 59,
					y: t.y - 1,
					width: 22,
					height: 22,
					fill: "none",
					stroke: "#9b6a93",
					strokeWidth: 2
				}, e);
			}),
			s.map((e, t) => {
				if (!e) return null;
				let n = Q(t), r = R(e);
				return /* @__PURE__ */ f("g", {
					transform: `translate(${n.x - 3} ${n.y - 3})`,
					className: "ri-placed",
					children: [
						/* @__PURE__ */ d("g", {
							mask: `url(#${o}-ink-${t})`,
							children: /* @__PURE__ */ d("g", {
								transform: "scale(1.875)",
								children: r && /* @__PURE__ */ d(Ft, {
									onBoard: !0,
									piece: e.cacti === 0 && r.mark === "cactus" ? {
										...r,
										mark: void 0
									} : r
								})
							})
						}),
						/* @__PURE__ */ d("text", {
							x: 74,
							y: 15,
							textAnchor: "middle",
							fontSize: 12,
							fill: "#b86959",
							children: e.round || ""
						}),
						e.weather && /* @__PURE__ */ d("g", {
							transform: "translate(60 60) scale(.5)",
							children: /* @__PURE__ */ d(jt, { name: e.weather })
						}),
						e.powered && /* @__PURE__ */ d("path", {
							d: "m12 66-6 12h7l-2 9 12-15h-8l4-6",
							fill: "#bc8d33"
						}),
						e.lit && /* @__PURE__ */ d("circle", {
							cx: 72,
							cy: 12,
							r: 9,
							fill: "#f3d16c",
							opacity: .7
						}),
						e.collected && /* @__PURE__ */ d("circle", {
							cx: 68,
							cy: 18,
							r: 14,
							fill: "none",
							stroke: "#be785c",
							strokeWidth: 2
						}),
						e.hub && /* @__PURE__ */ d("circle", {
							cx: 45,
							cy: 45,
							r: 7,
							fill: "#4e8d8c"
						}),
						e.broken && /* @__PURE__ */ d("path", {
							d: "m13 57 16-8 7 10 14-7 17 11",
							fill: "none",
							stroke: "#d16f58",
							strokeWidth: 3
						})
					]
				}, `${t}:${e.id}:${e.round}:${e.rotation}:${e.mirror}`);
			}),
			e.aliens.map((e) => {
				let t = Q(e.cell);
				return /* @__PURE__ */ f("g", {
					className: "ri-placed",
					transform: `translate(${t.x + 53} ${t.y + 53}) scale(.65)`,
					children: [/* @__PURE__ */ d(jt, { name: "alien" }), e.shield && /* @__PURE__ */ d("circle", {
						cx: 24,
						cy: 24,
						r: 25,
						stroke: "#657f6d",
						strokeWidth: 2,
						fill: "none"
					})]
				}, e.cell + ":" + e.shield);
			}),
			e.ritualPortals.map((e) => {
				let [t, n] = e.split(":").map(Number), r = c(t);
				return /* @__PURE__ */ f("g", {
					transform: `translate(${r}) rotate(${n * 90}) translate(0 -43) scale(.6)`,
					children: [/* @__PURE__ */ d("ellipse", {
						rx: 15,
						ry: 20,
						fill: "#b9a8c6",
						stroke: "#684e7b",
						strokeWidth: 4
					}), /* @__PURE__ */ d("path", {
						d: "M-8 0q8-17 16 0t-16 0",
						fill: "none",
						stroke: "#f2e9e5",
						strokeWidth: 2
					})]
				}, e);
			}),
			e.effects.map((e) => {
				let t = Q(e.cell);
				return /* @__PURE__ */ f("g", {
					transform: `translate(${t.x} ${t.y})`,
					className: e.kind === "erase" ? "ri-erasure" : "ri-mark-feedback",
					children: [/* @__PURE__ */ d("rect", {
						width: t.w,
						height: t.h,
						rx: 5,
						fill: e.kind === "erase" ? "#e8cfb7" : "none",
						stroke: "#b27c55",
						strokeWidth: 3
					}), e.kind === "erase" && /* @__PURE__ */ d("path", {
						d: "m12 20 58 39M12 38l58 18",
						stroke: "#fbf6df",
						strokeWidth: 5
					})]
				}, e.serial + ":" + e.cell);
			}),
			e.tentacles.map((t, n) => {
				let r = c(t[0]), i = Re({
					...e,
					tentacles: e.tentacles.slice(0, n)
				}, t[0]), a = [
					[0, -45],
					[45, 0],
					[0, 45],
					[-45, 0]
				][[
					0,
					1,
					2,
					3
				].find((e) => F(t[0], e) < 0 && !i.includes(e)) ?? 0], o = [[r[0] + a[0], r[1] + a[1]], ...t.map((e) => c(e))];
				return /* @__PURE__ */ f("g", {
					className: "ri-placed",
					children: [
						/* @__PURE__ */ d("path", {
							d: o.map((e, t) => `${t ? "L" : "M"}${e}`).join(""),
							stroke: "#8f7969",
							strokeWidth: 13,
							strokeLinejoin: "round",
							strokeLinecap: "round",
							fill: "none"
						}),
						o.slice(1, -1).map(([e, t], n) => /* @__PURE__ */ d("circle", {
							cx: e + 3,
							cy: t + 2,
							r: 3,
							fill: "#d6b69c"
						}, n)),
						/* @__PURE__ */ d("circle", {
							cx: o.at(-1)[0],
							cy: o.at(-1)[1],
							r: 4,
							fill: "#d6b69c"
						})
					]
				}, n);
			}),
			e.canyons.map((e, t) => /* @__PURE__ */ d("path", {
				d: e.map((e, t) => `${t ? "L" : "M"}${c(e, !0)}`).join(""),
				stroke: "#ae8556",
				strokeWidth: 5,
				strokeDasharray: "6 3",
				fill: "none"
			}, t)),
			e.bridges.map((e) => {
				let [t, n] = e.split(":").map(Number), r = c(t, !0), i = c(n, !0);
				return /* @__PURE__ */ d("path", {
					d: `M${(r[0] + i[0]) / 2 - 7} ${(r[1] + i[1]) / 2 - 7}l14 14m-14 0 14-14`,
					stroke: "#754c35",
					strokeWidth: 3
				}, e);
			}),
			t.expansion === "meteor" && /* @__PURE__ */ d("circle", {
				cx: c(e.meteor)[0] - 31,
				cy: c(e.meteor)[1] - 31,
				r: 4,
				fill: "#c76555"
			}),
			t.expansion === "investigation" && /* @__PURE__ */ f("g", {
				transform: `translate(${e.investigator >= 0 ? c(e.investigator) : c(N[-e.investigator - 1]?.cell ?? 0)})`,
				children: [/* @__PURE__ */ d("circle", {
					cy: -7,
					r: 8,
					fill: "#b89b52",
					stroke: "#635334",
					strokeWidth: 2
				}), /* @__PURE__ */ d("path", {
					d: "M-12 12q0-18 24 0Z",
					fill: "#b89b52",
					stroke: "#635334",
					strokeWidth: 2
				})]
			}),
			i && /* @__PURE__ */ d("g", {
				opacity: .55,
				transform: `translate(${Q(i.cell).x - 3} ${Q(i.cell).y - 3}) scale(1.875)`,
				children: /* @__PURE__ */ d(Ft, {
					onBoard: !0,
					piece: i.piece
				})
			}),
			a.length > 0 && /* @__PURE__ */ d("path", {
				d: a.map((e, n) => `${n ? "L" : "M"}${c(e, t.expansion === "canyon")}`).join(""),
				fill: "none",
				stroke: "#a66c4e",
				strokeWidth: 6,
				strokeLinecap: "round"
			}),
			[
				2,
				3,
				4,
				5,
				6,
				7,
				8,
				9,
				10,
				11,
				12
			].map((e, t) => /* @__PURE__ */ f("g", {
				transform: `translate(${108 + t * 59} 209)`,
				children: [/* @__PURE__ */ d("text", {
					textAnchor: "middle",
					fontSize: 15,
					fill: "#20343b",
					children: e
				}), /* @__PURE__ */ d("text", {
					y: 22,
					textAnchor: "middle",
					fontSize: 18,
					fill: "var(--ri-red)",
					fontWeight: 700,
					fontFamily: "Georgia,serif",
					children: e === 12 ? 45 : 4 * (e - 1)
				})]
			}, e))
		]
	});
}
//#endregion
//#region src/games/railroadink/placement-tools.tsx
function Rt({ anchor: e, avoid: t, children: n }) {
	let a = i(null);
	return r(() => {
		let n = a.current, r = e.current, i = n?.parentElement, o = r?.ownerSVGElement;
		if (!n || !r || !i || !o) return;
		let s = () => {
			let e = r.getBoundingClientRect(), a = i.getBoundingClientRect(), o = r.getScreenCTM();
			if (!o || !e.width || !e.height) return;
			let s = n.offsetWidth, c = n.offsetHeight, l = t.map((e) => {
				let t = new DOMPoint(e.x, e.y).matrixTransform(o), n = new DOMPoint(e.x + e.w, e.y + e.h).matrixTransform(o);
				return {
					x: t.x - a.left,
					y: t.y - a.top,
					w: n.x - t.x,
					h: n.y - t.y
				};
			}), u = {
				x: e.left - a.left,
				y: e.top - a.top,
				w: e.width,
				h: e.height
			}, d = [
				[u.x + u.w / 2 - s / 2, u.y - c - 7],
				[u.x + u.w / 2 - s / 2, u.y + u.h + 7],
				[u.x - s - 7, u.y + u.h / 2 - c / 2],
				[u.x + u.w + 7, u.y + u.h / 2 - c / 2]
			].map(([e, t]) => ({
				x: Math.max(4, Math.min(a.width - s - 4, e)),
				y: Math.max(4, Math.min(a.height - c - 4, t))
			})), f = (e, t) => Math.max(0, Math.min(e.x + s, t.x + t.w) - Math.max(e.x, t.x)) * Math.max(0, Math.min(e.y + c, t.y + t.h) - Math.max(e.y, t.y)), p = (e) => f(e, u) * 1e3 + l.reduce((t, n) => t + f(e, n), 0), m = d.reduce((e, t) => p(t) < p(e) ? t : e);
			n.style.left = `${m.x}px`, n.style.top = `${m.y}px`, n.style.visibility = e.right < a.left || e.left > a.right || e.bottom < a.top || e.top > a.bottom ? "hidden" : "visible";
		};
		s();
		let c = new ResizeObserver(s);
		c.observe(i), c.observe(n);
		let l = new MutationObserver(s);
		return l.observe(o, {
			subtree: !0,
			attributes: !0,
			attributeFilter: [
				"transform",
				"x",
				"y",
				"width",
				"height"
			]
		}), () => {
			c.disconnect(), l.disconnect();
		};
	}, [e, t]), /* @__PURE__ */ d("div", {
		ref: a,
		className: "ri-local-tools",
		role: "group",
		children: n
	});
}
//#endregion
//#region src/games/railroadink/theme.ts
var zt = {
	none: ["#fffefa", "#20313a"],
	river: ["#aedeea", "#166589"],
	lake: ["#9edcea", "#126d94"],
	lava: ["#fffefa", "#20313a"],
	meteor: ["#fffefa", "#20313a"],
	forest: ["#4b9841", "#07150b"],
	trail: ["#9bde78", "#172a12"],
	desert: ["#f4d345", "#40351c"],
	canyon: ["#efc53c", "#64431e"],
	tetromino: ["#70dc5c", "#c728c4"],
	pluckman: ["#e8e86b", "#7740d2"],
	invaders: ["#de8bdb", "#288d2b"],
	rainbow: ["#72cbdf", "#ac307e"],
	lamps: ["#191575", "#f2ad69"],
	power: ["#e69947", "#5031a4"],
	city: ["#686a6d", "#ffb4b1"],
	farmer: ["#686a6d", "#ffb4b1"],
	super: ["#686a6d", "#ffb4b1"],
	ritual: ["#3a247e", "#d5e8c2"],
	portal: ["#4f26f0", "#f5df39"],
	tentacle: ["#667a53", "#eff081"],
	investigation: ["#19220f", "#d0df82"],
	airline: ["#3927c8", "#a6d9f0"],
	weather: ["#a4c7e1", "#2b308d"],
	underground: ["#936e3e", "#a6d9e7"]
};
function Bt(e, t, n, r = !1) {
	let i = t === "engineer" || !r && t === "route" && (n.startsWith("sp") || n.startsWith("sep")), a = i ? "engineer" : t === "expansion" || r ? "expansion" : "route";
	return {
		group: a,
		colors: i ? ["#182126", "#4ec4d3"] : a === "expansion" ? zt[e.expansion] : zt.none
	};
}
function Vt(e) {
	let t = e.expansion === "lava" || e.expansion === "meteor", n = e.expansion === "desert" || e.expansion === "canyon", r = !t && !n && (e.challenge || e.expansion === "forest" || e.expansion === "trail"), i = t ? [
		"#f4c6a4",
		"#df7249",
		"#fbe5bd",
		"#ba5034",
		"#fff0e5"
	] : n ? [
		"#f0dca1",
		"#d3a23b",
		"#fff0ba",
		"#9b701c",
		"#faf4e1"
	] : r ? [
		"#c6ddba",
		"#69a66c",
		"#e5f0cf",
		"#377d55",
		"#edf5e7"
	] : [
		"#bcdcf0",
		"#4b91c4",
		"#e1f2f9",
		"#2387bc",
		"#eaf5fa"
	], a = zt[e.expansion];
	return {
		die: a,
		style: {
			"--ri-paper": i[0],
			"--ri-pigment": i[1],
			"--ri-bloom": i[2],
			"--ri-blue": i[3],
			"--ri-desk": i[4],
			"--ri-red": "#ee6b58",
			"--ri-die": a[0],
			"--ri-die-ink": a[1]
		}
	};
}
//#endregion
//#region src/games/railroadink/actions.ts
var Ht = /* @__PURE__ */ new WeakMap();
function Ut(e, t) {
	let n = Ht.get(e)?.get(t);
	if (n) return n;
	let r = e.boards[t];
	if (!r || r.done || e.phase === "done") return [];
	let i = [], a = e.config.expansion, o = Qe(e), s = o.map((t) => e.dice[t].face), c = (n) => {
		pt(structuredClone(e), n, t) && i.push(n);
	};
	if (r.stage === "start") {
		if (c({ type: "skipStart" }), e.round === 0) {
			if (a === "investigation") for (let e = 0; e < 12; e++) c({
				type: "markExit",
				exit: e
			});
			if (a === "invaders") for (let e = 0; e < 49; e++) c({
				type: "alien",
				cell: e
			});
		} else if (a === "meteor") {
			for (let e = 0; e < 4; e++) c({
				type: "meteor",
				direction: e
			});
			for (let e of w) c({
				type: "meteor",
				direction: 0,
				sacrifice: e
			});
		} else if (a === "rainbow" || a === "desert") {
			for (let e = 0; e < (a === "desert" ? 1 : 49); e++) c({
				type: "startEffect",
				cell: e
			});
			if (a === "desert") for (let e of w) c({
				type: "startEffect",
				cell: 0,
				sacrifice: e
			});
		} else if (a === "tetromino") for (let e of Le(r, s[0])) c({
			type: "path",
			path: e,
			die: o[0]
		});
	} else if (r.pendingLamp) for (let e of ["row", "column"]) for (let t = 0; t < 7; t++) c({
		type: "lamp",
		axis: e,
		index: t
	});
	else if (r.stage === "draw") {
		if (a === "pluckman") for (let e = 0; e < 12; e++) c({
			type: "markExit",
			exit: e
		});
		for (let t = 0; t < e.dice.length; t++) {
			let n = e.dice[t];
			if (!S[n.face] || n.source === "engineer") continue;
			let i = U(r, n.face, r.freePlacement && n.source === "route", e.underRound);
			for (let a of i) r.used.includes(t) || c({
				type: "place",
				die: t,
				...a,
				duplicate: !1
			}), (e.underRound ? !r.underDuplicate && r.duplications < 3 : r.factory > 0 && n.source === "route") && c({
				type: "place",
				die: t,
				...a,
				duplicate: !0
			});
		}
		if (!e.underRound && $e(r)) for (let e of w.filter((e) => !r.specials.includes(e))) {
			for (let t of U(r, e)) c({
				type: "special",
				id: e,
				...t
			});
			if (a === "farmer" || a === "airline") {
				let t = a === "farmer" ? "ufo" : "airport";
				for (let n of U(r, t)) c({
					type: "special",
					id: e,
					as: t,
					...n
				});
			}
		}
		if (a === "canyon") {
			for (let t of o) if (!r.used.includes(t)) for (let n of Ue(r, e.dice[t].face)) c({
				type: "path",
				die: t,
				path: n
			});
		}
		if (a === "lava") for (let e = 0; e < 49; e++) c({
			type: "volcano",
			cell: e
		}), c({
			type: "eraseLava",
			cell: e
		});
		if (e.config.construction && !r.constructionUsed) {
			let t = e.dice.find((e) => e.id === "construction");
			if (t?.face === "free") c({
				type: "construct",
				cell: 0,
				rotation: 0,
				mirror: !1
			});
			else for (let e = 0; e < 49; e++) {
				let n = r.cells[e];
				if (n && ["route", "special"].includes(n.origin ?? "")) {
					if (t?.face === "destroy") c({
						type: "construct",
						cell: e,
						rotation: 0,
						mirror: !1
					});
					else {
						let t = structuredClone(r);
						if (t.cells[e] = null, n.groups) for (let r = 0; r < 49; r++) for (let i = 0; i < 4; i++) for (let a of [!1, !0]) xe(t, R(gt(n, i, a)), r) && c({
							type: "construct",
							cell: e,
							target: r,
							rotation: i,
							mirror: a
						});
						else for (let r of U(t, n.id)) c({
							type: "construct",
							cell: e,
							target: r.cell,
							rotation: r.rotation,
							mirror: r.mirror
						});
					}
				}
			}
		}
		if (e.config.renovation && !r.renovationUsed) for (let e = 0; e < 49; e++) for (let t of Array.from({ length: 8 }, (e, t) => ({
			rotation: t % 4,
			mirror: t >= 4
		}))) c({
			type: "renovate",
			cell: e,
			rotation: t.rotation,
			mirror: t.mirror
		});
		c({ type: "finish" }), c({ type: "declineBonus" });
	} else {
		if (a === "weather") for (let e = 0; e < 2; e++) for (let t = 0; t < 49; t++) c({
			type: "weather",
			die: e,
			cell: t
		});
		if (a === "invaders") for (let e = 0; e < (s[0] === "attack" ? 1 : 49); e++) c({
			type: "alien",
			cell: e
		});
		if (a === "city") for (let e = 0; e < 49; e++) c({
			type: "build",
			cell: e
		});
		if (a === "investigation") for (let e = 0; e < 49; e++) c({
			type: "moveInvestigator",
			cell: e
		});
		if (a === "ritual") for (let e = 0; e < 49; e++) for (let t = 0; t < 4; t++) c({
			type: "ritualPortal",
			cell: e,
			side: t
		});
		if (a === "tentacle" && !r.expUsed.length) for (let e of Be(r, Number(s[0]))) c({
			type: "path",
			path: e,
			die: o[0]
		});
		if (a === "power") {
			for (let t of o) if (!r.expUsed.includes(t)) for (let n of We(r, e.dice[t].face)) c({
				type: "path",
				path: n,
				die: t
			});
		}
		c({ type: "skipEnd" });
	}
	let l = [...new Map(i.map((e) => [JSON.stringify(e), e])).values()], u = Ht.get(e) ?? /* @__PURE__ */ new Map();
	return u.set(t, l), Ht.set(e, u), l;
}
//#endregion
//#region src/games/railroadink/locales/zh.ts
var Wt = {
	name: "千墨交通",
	desc: "共用骰子，绘制独立路网；经典与挑战规则，河湖、森林、街机等多种扩展。",
	rules: "目标:\n在自己的 7 行 7 列的版图上绘制公路与铁路，连接出口并获得最高总分。所有玩家使用同一组骰子，同时规划各自的版图。\n准备:\n选择经典或 Challenge 规则，以及至多一种主题扩展。工程扩展可以叠加。所有可选内容默认关闭。经典基础游戏共 7 回合。\n流程:\n每回合掷出四颗路线骰。你可以任意旋转或镜像骰面，再点选合法格绘制。每颗路线骰每回合使用一次；只要仍有合法位置，就必须使用。每条路线至少一端连接已有同类路线或对应出口；公路和铁路只能经车站互通，立交桥的两条路线互不相连。路线可以通向没有出口的版图边缘。\n每回合可以额外使用一种特殊路线，每种整局只用一次，整局最多使用三种。确认完成绘制后，所有玩家一起结算回合后效果，再进入下一回合。\nChallenge:\n使用两颗普通骰及两颗挑战骰。\n· 工厂：在绘入交通路线时允许额外复制一颗本回合路线骰。\n· 村庄：必须绘入车站才激活，累计 1／2／3／4 次分别获得 1／2／4／6 分。\n· 大学：第三次激活大学可以立即免费使用一种尚未用过的特殊路线，不占普通次数。\n路线被擦除后，建筑可以再次触发，已获得的效果保留。\n可选目标在回合末判定，同回合完成者获得相同分数；先后批次分别获得 4／2／1 分。单人局的三个目标分别在第 3／4／5 回合前完成获得 4 分，否则获得 1 分。\n结算:\n· 交通网络：每个交通网络按相连出口数计分：2 至 11 个出口获得 4、8、12、16、20、24、28、32、36、40 分，12 个获得 45 分。\n· 最长路线：最长公路与最长铁路每格各获得 1 分；经典规则同格不重复，Challenge 允许沿不同路线段再次经过同格。\n· 中央区域：中央九格中每个已绘制格获得 1 分。\n· 错误扣分：每个未接通的路线端口扣 1 分，通往边缘不扣分。\n总分最高者获胜；同分时错误较少者获胜，再同分共同获胜。\n河流与湖泊:\n均为 6 回合，扩展骰可选且可以独立起笔。河流只能连接河流；选一条河每格获得 1 分，两端都到边界额外获得 3 分，未接通河口照常扣分。湖泊按开放水边连接，经码头连接交通网络；最小湖泊每格获得 1 分。空格有至少三侧面向开放湖面时自动填满为水域，湖面开口不扣分。\n熔岩与陨石:\n均为 6 回合。熔岩从中央火山开始，每回合至少绘制一颗熔岩骰，并连接已有熔岩；可以在不邻接熔岩的空格新建火山。没有空格可以延伸时，可以擦除阻挡的路线。最大熔岩湖每格获得 1 分，每座封闭熔岩湖额外获得 5 分，开放熔岩边每侧扣 1 分。\n陨石在回合开始按方向与距离移动，从中央或上次落点起算，碰到边缘反弹，落在旧陨石坑时继续移动。落点改为陨石坑；可以消耗一次可用特殊路线取消本回合陨石。陨石坑可以重新绘入路线，每个通向现存陨石坑的交通端口获得 2 分且不扣分。\n森林、小径与沙漠:\n均为 6 回合。森林和沙漠骰可独立起笔；森林按正交相邻格组成，最大森林每格获得 2 分，第二大每格获得 1 分。小径沿格角连接，需要接上既有路线或小径；格角进入车站便自动连接，按相连车站数获得对应网络分的一半，最多计 12 座车站，小径开口不扣分。\n沙漠每次出现烈日时，先擦去不邻接绿洲的仙人掌，路线保留；可消耗一次可用特殊路线取消。第 6 回合后再掷一次沙漠骰并处理最后的烈日，每棵存活仙人掌获得 1 分。\n峡谷:\n共 7 回合。峡谷沿格边绘制，必须完整使用骰面形状，连接边界或已有峡谷端点，不能分叉。交通路线接触峡谷边时消耗一处桥梁，整局最多 12 处。最长峡谷每段获得 1 分，每条两端都到边界的峡谷额外获得 2 分。\n街机扩展:\n· 方块规划：在每回合画路线之前，可以完整标出骰面形状的四个空格；已标格不能重复，终局已填格每格获得 1 分，空格每格扣 1 分。\n· 吃豆人：每回合必须在尚未接通且未标记的出口旁绘入骰面标记；网络含吃豆人获得 3 分，含幽灵但没有水果时每只幽灵扣 2 分，有水果时每只幽灵改为获得 2 分。\n· 外星入侵：开局在右侧玩家版图放置两只外星人；每回合后按骰面派遣、攻击或清除外星人，攻击使其获得护盾并擦除所在格内容，无护盾外星人可被绘制覆盖，终局每只扣 1 分。\n· 彩虹：共 6 回合，每回合前放置彩虹、三叶草或在左侧玩家版图放置雨云；彩虹不得正交相邻，雨云优先放在彩虹旁。彩虹连接所有朝向它的交通路线，但中断最长公路和铁路；每朵彩虹为每个正交相邻三叶草获得 2 分，朝向雨云与三叶草的端口不扣分。\n电力、未来与天空:\n· 路灯：共 6 回合，绘制特殊路线后选择一行或一列点亮已有路灯，终局每盏点亮路灯获得 1 分。\n· 电网：共 7 回合，中央为蓄电池；回合后从出口或已通电格沿骰面方向为连续交通格通电，也可提前停止。问号可以为任一交通格通电或为蓄电池充电；蓄电池最多充电 3 次。得分为充电次数乘以通过正交通电格连接的出口数。\n· 城市建设：共 7 回合，回合后按收入骰获得硬币，最多保留 12 枚，再建造建筑骰所示建筑；一、二、三座高塔分别花费 3、5、7 枚硬币。终局每座高塔获得 1 分，朝向建筑的端口不扣分。\n· 异星牧场：共 6 回合，扩展骰可独立起笔，特殊路线可改为绘入飞碟；每艘飞碟为同一行或列的每只绵羊获得 2 分，同一只羊可由多艘飞碟计分。\n· 超级连接：共6回合，扩展骰必须使用；路线末端的三角超级车站可以接公路或铁路，超级连接同时计入最长公路与最长铁路。\n· 天气：共 7 回合，每回合必须把两种骰面天气分别标到本回合绘制的两个交通格；终局每种天气的最大正交连续区域每格获得 1 分，接触其他天气区域（包括对角）的区域不计分。\n· 航空：共 6 回合，扩展骰可独立起笔，特殊路线可改为机场；机场连接所有朝向它的路线，最长航空路线必须在边界或机场起止，每格获得 2 分，每个开放航空端口扣 2 分，每座未接航空路线的机场扣 4 分。\n异闻扩展:\n· 仪式：共 6 回合，仪式骰必须绘制且可独立起笔；回合后可在没有出口的边界交通端口放置一扇异界之门。连接仪式或异界之门的网络不再按普通出口计分，改按仪式与门的数量获得网络分。\n· 传送门：共 7 回合，同字母最多两扇，成对连接其所在网络，公路与铁路可以经门互通。\n· 触手：共 7 回合，回合后可绘制骰面长度的完整触手，从不含出口的边界格进入；只能穿过空格、直线或弯道，不能使用已占用的格边，尾端结束。终局每条触手获得 2 分，每个同时含交通路线与触手的格额外获得 1 分；之后不能再向已有触手格绘入交通路线。\n· 调查：共 6 回合，开局选择调查员所在出口；回合后可按骰面脚印数移动，每步沿公路到相邻格，或由车站／铁路出口沿铁路到下一座车站，不得跳过车站。每收集一条线索获得 1 分，全部收集额外获得 4 分。\n地下交通:\n双层模式交替进行地表与地下回合，共 14 回合；独立模式只进行 7 个地下回合。水管对应公路出口，地铁对应铁路出口，两者不能相连。地下每回合最多复制一颗骰，整局最多三次。地表车站与地下车站重叠时形成枢纽；在已有水管上方新建地表车站会损坏水管，反向建造不会损坏。独立模式的新地下车站若同行同列都没有枢纽，立即成为枢纽。地下网络按相连出口计分，地铁枢纽也计为出口；最长水管每格获得 2 分，最长地铁每格获得 1 分，中央格照常计分，未接端口每个扣 1 分，损坏水管每格额外扣 2 分。\n工程扩展:\n特殊骰替换一颗普通路线骰，分离骰替换另一颗普通路线骰，均必须使用且可由工厂复制。施工骰每回合可以使用一次，按骰面擦除、移动一条已有基础路线，或使下一条路线不必连接已有路线。扩展骰结果不受施工影响。改建骰每回合可用一次，只能对已有基础路线增加端口；原有路线必须完全位于骰面虚线约束内，带虚线方框的两面只能给已有车站增加连接，不可改建主题扩展骰结果。",
	tetromino: "方块规划",
	errAction: "当前不能这样操作，请选择高亮位置或可用动作。",
	classic: "经典版",
	challenge: "Challenge",
	variant: "规则版本",
	expansion: "主题扩展",
	engineers: "工程扩展",
	goalsOption: "使用目标卡",
	goalsHint: "回合末判定，同回合完成者获得相同分数。",
	expansions: {
		none: "不使用扩展",
		river: "河流",
		lake: "湖泊",
		lava: "熔岩",
		meteor: "陨石",
		forest: "森林",
		trail: "小径",
		desert: "沙漠",
		canyon: "峡谷",
		tetromino: "方块规划",
		pluckman: "吃豆人",
		invaders: "外星入侵",
		rainbow: "彩虹",
		lamps: "路灯",
		power: "电网",
		city: "城市建设",
		super: "超级连接",
		farmer: "异星牧场",
		ritual: "仪式",
		portal: "传送门",
		tentacle: "触手",
		investigation: "调查",
		airline: "航空",
		weather: "天气",
		underground: "地下交通"
	},
	specialDie: "特殊骰",
	separationDie: "分离骰",
	renovation: "改建骰",
	construction: "施工骰",
	undergroundSolo: "地下独立模式",
	undergroundGoals: "地下独立模式不使用目标卡。",
	pipe: "水管",
	subway: "地铁",
	round: "回合",
	of: "/",
	surface: "地表",
	underground: "地下",
	routes: "路线骰",
	special: "特殊路线",
	remaining: "剩余",
	finish: "完成绘制",
	skipStart: "不使用",
	skipEnd: "结束回合",
	waiting: "等待其他玩家",
	select: "选择骰面，再点版图绘制",
	startPrompt: "处理回合开始效果",
	endPrompt: "处理回合结束效果",
	selectTarget: "点选高亮目标",
	selected: "已选中",
	noPlacement: "当前无合法位置",
	rotate: "旋转",
	mirror: "镜像",
	reset: "回到全景",
	cancel: "取消",
	confirm: "确认路径",
	duplicate: "复制",
	sacrifice: "消耗特殊路线",
	row: "行",
	column: "列",
	empty: "空格",
	sheet: "版图",
	view: "查看版图",
	details: "计分明细",
	total: "总分",
	projected: "当前计分",
	close: "收起结算",
	open: "展开结算",
	ending: "交通规划报告",
	winner: "获胜",
	playAgain: "再来一局",
	lobby: "返回大厅",
	waitHost: "等待主机继续",
	quitConfirm: "确认返回大厅？",
	yes: "确认",
	no: "取消",
	hintCount: "建议次数",
	autopilot: "托管",
	pendingLamp: "选择一行或一列点亮路灯",
	finalHeat: "最后的烈日",
	setup: "开局布置",
	coins: "硬币",
	charge: "充电",
	villages: "村庄",
	universities: "大学",
	bridge: "桥梁",
	movement: "移动点",
	score: {
		network: "连接出口",
		highway: "最长公路",
		railway: "最长铁路",
		center: "中央区域",
		errors: "错误扣分",
		expansion: "扩展得分",
		villages: "村庄得分",
		goals: "目标得分",
		total: "总分"
	},
	actions: {
		place: "绘制路线",
		special: "特殊路线",
		finish: "完成绘制",
		skipStart: "不使用",
		skipEnd: "结束回合",
		meteor: "陨石落点",
		weather: "标记天气",
		lamp: "点亮路灯",
		startEffect: "放置标记",
		path: "绘制路径",
		markExit: "标记出口",
		power: "通电",
		build: "建造建筑",
		moveInvestigator: "移动调查员",
		ritualPortal: "放置异界之门",
		construct: "施工",
		renovate: "改建",
		volcano: "新建火山",
		eraseLava: "擦除阻挡路线",
		alien: "处理外星人",
		declineBonus: "放弃额外机会"
	},
	marks: {
		h: "公路",
		r: "铁路",
		w: "河流",
		l: "湖泊",
		v: "熔岩",
		a: "航空路线",
		s: "超级连接",
		station: "车站",
		tree: "树林",
		cactus: "仙人掌",
		oasis: "绿洲",
		sheep: "绵羊",
		ufo: "飞碟",
		crater: "陨石坑",
		volcano: "火山",
		airport: "机场",
		rainbow: "彩虹",
		rain: "雨云",
		clover: "三叶草",
		battery: "蓄电池",
		tower: "高塔",
		lamp: "路灯",
		ritual: "仪式",
		clue: "线索",
		A: "传送门 A",
		B: "传送门 B",
		C: "传送门 C",
		north: "北",
		east: "东",
		south: "南",
		west: "西",
		any: "任意方向",
		cloud: "云",
		snow: "雪",
		storm: "雷雨",
		arid: "烈日",
		fruit: "水果",
		pluck: "吃豆人",
		ghost: "幽灵",
		alien: "外星人",
		attack: "攻击",
		nuke: "清除",
		adjacent: "相邻建设",
		exits: "出口投资",
		urban: "城市化",
		center: "中央开发",
		destroy: "拆除",
		move: "搬迁",
		free: "自由放置"
	},
	goal: {
		network3: "同一网络连接 3 个出口",
		opposite: "连接相对两侧的出口",
		middle: "连接 2 个边中出口",
		stations4: "同一网络连接 4 座车站",
		highway6: "公路长度达到 6 格",
		railway6: "铁路长度达到 6 格",
		center5: "填入 5 个中央格",
		corners3: "填入 3 个角落格",
		loop: "形成一条闭环",
		row: "填满一行或一列",
		square: "填满一片 3 行 3 列区域",
		villages3: "激活 3 次村庄",
		forest5: "形成 5 片独立森林",
		forestDiagonal: "连续 4 个对角相邻格有树",
		forestExits: "4 个出口邻格有树",
		trailStation: "同一车站连接 3 条小径",
		trailRow: "同一行或列连续 5 格有小径",
		trailCenter: "5 个中央格有小径",
		cactusRow: "同一行或列连续 4 格有仙人掌",
		oasis3: "同一网络连接 3 格绿洲",
		cactusSquare: "2 行 2 列区域每格都有仙人掌",
		bridge6: "使用 6 处桥梁",
		canyonCross3: "同一路径跨过同一峡谷 3 次",
		canyonCenter: "峡谷两端到边界并经过中央区域"
	}
}, Gt = {
	name: "Railroad Ink",
	desc: "Share the dice and draw your own network, with Classic, Challenge and modular expansions.",
	rules: "Goal:\nDraw highways and railways on your own 7×7 board. Connect exits and maximize your final score. All players use the same dice and plan their boards simultaneously.\nSetup:\nChoose Classic or Challenge and at most one themed expansion. Engineer modules may be added. All optional content is off by default. A Classic game lasts 7 rounds.\nPlay:\nEach round rolls four route dice. Rotate or mirror a face, then select a legal board space. Use each route die once whenever a legal placement remains. Every route must connect to a matching exit or existing route. Highways and railways only join at stations; the two routes on an overpass remain separate. Routes may lead to a board edge without an exit.\nYou may also draw one unused special route per round, using at most three during the game. Each special design may only be used once. Finish drawing, resolve the end-of-round effects together, then advance to the next round.\nChallenge:\nUse two ordinary dice and two Challenge dice.\n· Factory: drawing a transport route on a factory grants a copy of a route die rolled this round.\n· Village: a village activates only with a station: 1/2/3/4 activations score 1/2/4/6 points.\n· University: the third university activation immediately grants an unused special route without using the ordinary round or game limit.\nErasing routes allows buildings to activate again; previously earned effects remain.\nOptional goals are checked at the end of a round. Players completing a goal in the same round receive the same reward. Successive groups score 4/2/1 points. Solo goals award 4 points by rounds 3/4/5 respectively, or 1 point later.\nScoring:\n· Networks: each network scores for connected exits: 2 through 11 exits score 4, 8, 12, 16, 20, 24, 28, 32, 36 and 40 points; 12 score 45.\n· Longest routes: the longest highway and longest railway each score 1 per space. Classic counts each space once; Challenge may revisit a space through a different route segment.\n· Central area: each occupied central space scores 1.\n· Errors: each unconnected route end costs 1; ends at board edges cost nothing.\nHighest total wins, then fewer errors; remaining ties share the win.\nRivers and Lakes:\nBoth last 6 rounds. Expansion dice are optional and may start independently. Rivers only connect to rivers: choose one river for 1 point per space and 3 extra if both ends reach the board edge. Open river ends are errors. Lakes join through open water edges and connect transport networks via piers. Score 1 per space of the smallest lake. An empty space with at least three sides facing open water fills automatically. Open lake sides are not errors.\nLava and Meteors:\nBoth last 6 rounds. Lava starts at a central volcano. Draw at least one lava die per round, connected to existing lava. You may create a volcano in an empty space not adjacent to lava. If lava cannot extend into an empty space, you may erase a blocking route. The largest lava lake scores 1 per space, each closed lake scores 5 more, and each open lava side costs 1.\nAt the start of each Meteor round, move from the center or previous impact according to direction and distance. Bounce at edges and continue past old craters. Replace the impact space with a crater. You may spend an available special route to cancel the meteor. Craters may be covered with new routes. Every transport end facing a remaining crater scores 2 instead of an error.\nForests, Trails and Desert:\nAll last 6 rounds. Forest and Desert dice may start independently. Orthogonally adjacent trees form forests: the largest scores 2 per space and the second largest 1 per space. Trails connect through space corners and must connect to existing routes or trails. A trail reaching a station corner automatically joins that station. Connected stations score half the network value, counting at most 12 stations. Open trails are not errors.\nWhen either Desert die shows a sun, first erase cacti not adjacent to an oasis, leaving routes intact. You may spend an available special route to cancel the heat. Roll once more after round 6 for a final heat wave. Each surviving cactus scores 1.\nCanyons:\nPlay 7 rounds. Draw the complete die pattern along space borders. It must connect to a board edge or an existing canyon end, without branching. Any transport route touching a canyon edge requires a bridge; at most 12 bridges may be used. Score 1 per segment of the longest canyon and 2 more for each canyon whose two ends reach the board edge.\nArcade:\n· Tetromino: before drawing routes, optionally enhance four empty spaces in the complete die pattern. Never enhance a space twice. Each enhanced space scores 1 if occupied, or loses 1 if empty.\n· Pluck-Man: each round, mark the die result at an unconnected, unmarked exit if possible. A network with Pluck-Man scores 3. Each connected ghost loses 2 without fruit, or scores 2 with fruit.\n· Galactic Invaders: during setup, place two aliens on the board to your right. After each round, apply the shared die to send, attack or remove aliens. Attacks shield aliens and erase their spaces. Drawing over an unshielded alien removes it. Each remaining alien costs 1.\n· Rainbow lasts 6 rounds: before routes, place a rainbow or clover, or rain on the board to your left. Rainbows may not touch orthogonally. Rain must be placed next to a rainbow if possible. Rainbows connect all transport ends facing them but interrupt longest highways and railways. Each rainbow scores 2 per adjacent clover. Ends facing rain or clovers are not errors.\nElectricity, Futuristic and Sky:\n· Street Lamps lasts 6 rounds. After a special route, select a row or column to activate its existing lamps. Each activated lamp scores 1.\n· Power Grid lasts 7 rounds with an accumulator at the center. After routes, electrify consecutive transport spaces in the indicated direction, starting from an exit or electrified space; you may stop early. A question mark electrifies one arbitrary transport space or charges the accumulator. Charge at most three times. Score charges multiplied by exits joined through orthogonally adjacent electrified spaces.\n· City Builder lasts 7 rounds. After routes, gain income from the Income die, keeping at most 12 coins. Build any number of the indicated buildings: 1/2/3 towers cost 3/5/7 coins. Each tower scores 1 and ends facing buildings are not errors.\n· Alien Farmer lasts 6 rounds. Expansion dice may start independently; a special route may be replaced by a UFO. Each UFO scores 2 per sheep in its row or column; several UFOs may score the same sheep.\n· Superconnection lasts 6 rounds. Its die is mandatory. Triangular Superstations at route ends connect to either highways or railways. Superconnections count toward both longest routes.\n· Weather lasts 7 rounds. Assign both symbols to two transport spaces drawn this round. Score 1 per space in the largest orthogonal area of each weather type. Areas touching another weather type, even diagonally, score nothing.\n· Airline lasts 6 rounds. Expansion dice may start independently and a special may become an airport. Airports join all facing routes. The longest airway must start and end at an edge or airport and scores 2 per space. Each open airway end costs 2; each airport with no airway costs 4.\nEldritch:\n· Ritual lasts 6 rounds. Its die is mandatory and may start independently. After each round you may add a portal to a route end at a board edge without an exit. A network containing rituals or portals ignores ordinary exits and instead scores the network value of its rituals and portals.\n· Portal lasts 7 rounds: at most two portals of each letter may be drawn. Matching pairs join their networks, even across highway and railway types.\n· Tentacles lasts 7 rounds. After routes, optionally draw a complete tentacle of the die's length, entering through a boundary space without an exit. It may cross empty spaces, straights and curves using unoccupied sides, then ends in a tip. Score 2 per tentacle and 1 per space shared by a tentacle and transport route. Later routes cannot be drawn over tentacles.\n· Investigation lasts 6 rounds. Choose an exit for your investigator during setup. After routes, spend the die's footsteps: move one adjacent space by highway, or from a station/railway exit to the next station along railway, never skipping a station. Each collected clue scores 1; collecting all clues scores 4 more.\nUnderground:\nExpansion mode alternates surface and underground for 14 rounds. Standalone uses 7 underground rounds. Water pipes use highway exits and subways use railway exits; the two kinds never join. You may duplicate one underground die per round, at most three per game. Aligned surface and subway stations create hubs. Building a surface station above an existing pipe breaks it; the reverse order does not. In standalone, a new subway station becomes a hub if no hub shares its row or column. Underground networks score connected exits, with hubs also counting as subway exits. Longest pipes score 2 per space, longest subways 1, central spaces 1, open ends lose 1, and each broken pipe loses 2 more.\nEngineer:\nThe Special die replaces one ordinary route die and the Separation die replaces another. Both are mandatory and factories may duplicate them. Once per round, the Construction die may erase or move a basic route, or let the next route start without connecting to existing routes. Construction does not affect non-Engineer expansion results. Once per round, the Renovation die may add connections to an existing basic route. The old route must fit entirely within its dotted constraints; faces with a dotted central square may only extend an existing station. Themed expansion results cannot be renovated.",
	tetromino: "Tetromino",
	errAction: "That action is not available. Select a highlighted space or an available action.",
	classic: "Classic",
	challenge: "Challenge",
	variant: "Rule set",
	expansion: "Themed expansion",
	engineers: "Engineer modules",
	goalsOption: "Use goal cards",
	goalsHint: "Checked at round end; simultaneous achievers receive equal rewards.",
	expansions: {
		none: "No expansion",
		river: "Rivers",
		lake: "Lakes",
		lava: "Lava",
		meteor: "Meteors",
		forest: "Forests",
		trail: "Trails",
		desert: "Desert",
		canyon: "Canyons",
		tetromino: "Tetromino",
		pluckman: "Pluck-Man",
		invaders: "Galactic Invaders",
		rainbow: "Rainbow",
		lamps: "Street Lamps",
		power: "Power Grid",
		city: "City Builder",
		super: "Superconnection",
		farmer: "Alien Farmer",
		ritual: "Ritual",
		portal: "Portal",
		tentacle: "Tentacles",
		investigation: "Investigation",
		airline: "Airline",
		weather: "Weather",
		underground: "Underground"
	},
	specialDie: "Special die",
	separationDie: "Separation die",
	renovation: "Renovation die",
	construction: "Construction die",
	undergroundSolo: "Underground standalone",
	undergroundGoals: "Goal cards are not used in the Underground standalone game.",
	pipe: "Water pipe",
	subway: "Subway",
	round: "Round",
	of: "/",
	surface: "Surface",
	underground: "Underground",
	routes: "Route dice",
	special: "Special routes",
	remaining: "Remaining",
	finish: "Finish drawing",
	skipStart: "Skip",
	skipEnd: "End round",
	waiting: "Waiting for other players",
	select: "Select a die, then draw on the board",
	startPrompt: "Resolve the start of the round",
	endPrompt: "Resolve the end of the round",
	selectTarget: "Select a highlighted target",
	selected: "Selected",
	noPlacement: "No legal placement",
	rotate: "Rotate",
	mirror: "Mirror",
	reset: "Fit board",
	cancel: "Cancel",
	confirm: "Confirm path",
	duplicate: "Duplicate",
	sacrifice: "Spend special",
	row: "Row",
	column: "Column",
	empty: "Empty",
	sheet: "Board",
	view: "View board",
	details: "Score details",
	total: "Total",
	projected: "Current score",
	close: "Hide results",
	open: "Show results",
	ending: "Transport planning report",
	winner: "Winner",
	playAgain: "Play again",
	lobby: "Back to lobby",
	waitHost: "Waiting for the host",
	quitConfirm: "Return to the lobby?",
	yes: "Confirm",
	no: "Cancel",
	hintCount: "Hints used",
	autopilot: "Autopilot",
	pendingLamp: "Select a row or column to activate its lamps",
	finalHeat: "Final heat wave",
	setup: "Setup",
	coins: "Coins",
	charge: "Charges",
	villages: "Villages",
	universities: "Universities",
	bridge: "Bridges",
	movement: "Movement",
	score: {
		network: "Exit networks",
		highway: "Longest highway",
		railway: "Longest railway",
		center: "Central spaces",
		errors: "Errors",
		expansion: "Expansion",
		villages: "Villages",
		goals: "Goals",
		total: "Total"
	},
	actions: {
		place: "Draw route",
		special: "Special route",
		finish: "Finish drawing",
		skipStart: "Skip",
		skipEnd: "End round",
		meteor: "Meteor impact",
		weather: "Assign weather",
		lamp: "Activate lamps",
		startEffect: "Place symbol",
		path: "Draw path",
		markExit: "Mark exit",
		power: "Electrify",
		build: "Build",
		moveInvestigator: "Move investigator",
		ritualPortal: "Open portal",
		construct: "Construction",
		renovate: "Renovation",
		volcano: "Create volcano",
		eraseLava: "Erase blocking route",
		alien: "Resolve aliens",
		declineBonus: "Decline extra action"
	},
	marks: {
		h: "Highway",
		r: "Railway",
		w: "River",
		l: "Lake",
		v: "Lava",
		a: "Airway",
		s: "Superconnection",
		station: "Station",
		tree: "Trees",
		cactus: "Cactus",
		oasis: "Oasis",
		sheep: "Sheep",
		ufo: "UFO",
		crater: "Crater",
		volcano: "Volcano",
		airport: "Airport",
		rainbow: "Rainbow",
		rain: "Rain cloud",
		clover: "Clover",
		battery: "Accumulator",
		tower: "Tower",
		lamp: "Lamp",
		ritual: "Ritual",
		clue: "Clue",
		A: "Portal A",
		B: "Portal B",
		C: "Portal C",
		north: "North",
		east: "East",
		south: "South",
		west: "West",
		any: "Any direction",
		cloud: "Cloud",
		snow: "Snow",
		storm: "Storm",
		arid: "Sun",
		fruit: "Fruit",
		pluck: "Pluck-Man",
		ghost: "Ghost",
		alien: "Alien",
		attack: "Attack",
		nuke: "Remove alien",
		adjacent: "Adjacent construction",
		exits: "Exit investment",
		urban: "Urbanization",
		center: "Central development",
		destroy: "Destroy",
		move: "Move",
		free: "Free placement"
	},
	goal: {
		network3: "Connect 3 exits in one network",
		opposite: "Join exits on opposite sides",
		middle: "Join 2 middle exits",
		stations4: "Join 4 stations in one network",
		highway6: "Make a highway of length 6",
		railway6: "Make a railway of length 6",
		center5: "Occupy 5 central spaces",
		corners3: "Occupy 3 corner spaces",
		loop: "Create a loop",
		row: "Fill a row or column",
		square: "Fill a 3×3 area",
		villages3: "Activate 3 villages",
		forest5: "Create 5 separate Forests",
		forestDiagonal: "Trees in 4 consecutive diagonal spaces",
		forestExits: "Trees beside 4 Exits",
		trailStation: "Connect 3 Trails to one Station",
		trailRow: "Trails in 5 consecutive row or column spaces",
		trailCenter: "Trails in 5 central spaces",
		cactusRow: "Cacti in 4 consecutive row or column spaces",
		oasis3: "Connect 3 Oasis spaces in one Network",
		cactusSquare: "Cacti in every space of a 2×2 area",
		bridge6: "Spend 6 Bridge points",
		canyonCross3: "One path crosses the same Canyon 3 times",
		canyonCenter: "A Canyon links two edges through the center"
	}
};
//#endregion
//#region src/games/railroadink/text.ts
function Kt() {
	return s((e) => e.locale) === "zh" ? Wt : Gt;
}
//#endregion
//#region src/games/railroadink/view-player.tsx
function qt(e) {
	let t = N[e], n = Q(t.cell);
	return {
		x: t.side === 1 ? 716 : t.side === 3 ? 30 : n.x + 22,
		y: t.side === 0 ? 210 : t.side === 2 ? 896 : n.y + 22,
		w: 40,
		h: 40
	};
}
function Jt(e, t) {
	let n = Q(e);
	return {
		x: n.x + (t === 1 ? 64 : t === 3 ? -16 : 27),
		y: n.y + (t === 0 ? -16 : t === 2 ? 64 : 27),
		w: 28,
		h: 28
	};
}
function Yt(e) {
	return /* @__PURE__ */ d(Xt, { ...e });
}
function Xt({ public: e, members: t, myRid: n, send: r, ending: h = !1 }) {
	let g = e, _ = Kt(), v = s((e) => e.locale), y = Vt(g.config), b = i(null), [x, C] = a(null), [re, ie] = a(n), [ae, oe] = a(!1), [se, ce] = a(0), [T, le] = a(""), [E, ue] = a(0), [O, de] = a(!1), [k, A] = a([]), [j, fe] = a(null), [pe, me] = a(!1), he = `${g.round}:${g.boards[n]?.stage}`, [ge, _e] = a(he);
	ge !== he && (_e(he), le(""), A([]), fe(null), C(null), oe(g.underRound));
	let M = g.boards[n], ve = h ? [] : Ut(g, n), ye = Tt(g, ve, _), N = ye.find((e) => e.key === T), P = !!M && !M.done && ve.length > 0 && !h, F = N?.actions[0]?.type === "startEffect" && g.dice.find((e) => e.source === "expansion")?.face === "rain" ? -1 : +(N?.actions[0]?.type === "alien" && (g.round === 0 || g.dice.find((e) => e.source === "expansion")?.face === "alien")), I = F ? g.players[(g.players.indexOf(n) + F + g.players.length) % g.players.length] : g.players.includes(re) ? re : n, L = g.boards[I] ?? g.boards[g.players[0]], z = g.config.expansion === "underground" && ae, B = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? c(n, v) : e;
	}, V = () => {
		A([]), fe(null), C(null);
	}, H = (e) => {
		if (V(), e.immediate) {
			r(e.actions[0]), le("");
			return;
		}
		le(e.key), ie(n), oe(g.underRound);
		let t = e.actions[0];
		"rotation" in t ? (ue(t.rotation), de(t.mirror)) : (ue(0), de(!1));
	}, be = N?.actions.filter((e) => {
		if (e.type === "place") return Et(g.dice[e.die].face, E, O, e.rotation, e.mirror);
		if (e.type === "special") return Et(e.as ?? e.id, E, O, e.rotation, e.mirror);
		if (e.type === "renovate") return e.rotation === E && e.mirror === O;
		if (e.type === "construct" && j !== null && e.target !== void 0) {
			let t = L.cells[j];
			return e.cell === j && (t.groups ? e.rotation === E && e.mirror === O : Et(t.id, E, O, e.rotation, e.mirror));
		}
		return !0;
	}) ?? [], xe = be.filter((e) => e.type === "path"), Se = g.config.expansion === "tetromino", U = xe.filter((e) => Se ? k.every((t) => e.path.includes(t)) : k.every((t, n) => e.path[n] === t)), W = /* @__PURE__ */ new Map();
	if (P && N && (I === n || F) && (g.config.expansion !== "underground" || z === g.underRound) && !h) {
		if (xe.length) for (let e of U) for (let t of Se ? e.path.filter((e) => !k.includes(e)) : e.path.slice(k.length, k.length + 1)) {
			let e = g.config.expansion === "canyon" ? {
				x: 85 + t % 8 * 90 - 13,
				y: 265 + Math.floor(t / 8) * 90 - 13,
				w: 26,
				h: 26
			} : Q(t);
			W.set(String(t), {
				eligible: {
					key: String(t),
					rect: e
				},
				next: t
			});
		}
		else for (let e of be) {
			let t = "", n = null;
			if (e.type === "markExit") t = "exit:" + e.exit, n = qt(e.exit);
			else if (e.type === "ritualPortal") t = `portal:${e.cell}:${e.side}`, n = Jt(e.cell, e.side);
			else if ("cell" in e) {
				let r = e.type === "construct" && j !== null && e.target !== void 0 ? e.target : e.cell;
				t = String(r), n = Q(r);
			}
			n && !W.has(t) && W.set(t, {
				eligible: {
					key: t,
					rect: n
				},
				action: e
			});
		}
	}
	let G = (e) => {
		let t = W.get(e);
		if (!t) return;
		if (t.next !== void 0) {
			A([...k, t.next]);
			return;
		}
		let n = t.action;
		if (n) {
			if (n.type === "construct" && g.dice.find((e) => e.id === "construction")?.face === "move" && j === null) {
				fe(n.cell), ue(n.rotation), de(n.mirror), C(n.target ?? null);
				return;
			}
			if (n.type === "place" || n.type === "special" || n.type === "renovate" || n.type === "construct" && j !== null) {
				C(n.type === "construct" ? n.target ?? null : n.cell);
				return;
			}
			r(n), V();
		}
	}, K = U.find((e) => Se ? e.path.length === k.length && k.every((t) => e.path.includes(t)) : e.path.length === k.length), Ce = N?.actions[0] && ([
		"place",
		"special",
		"renovate"
	].includes(N.actions[0].type) || N.actions[0].type === "construct" && j !== null), we = j === null ? N?.face : L.cells[j]?.id, q = j !== null && L.cells[j] ? R(gt(L.cells[j], E, O)) : null, Te = be.find((e) => "cell" in e && (e.type !== "construct" || j !== null)), J = x ?? (Te && "cell" in Te ? Te.type === "construct" ? Te.target ?? null : Te.cell : null), Ee = J === null ? void 0 : be.find((e) => "cell" in e && (e.type === "construct" ? e.target === J && e.cell === j : e.cell === J)), De = J !== null && N?.actions[0]?.type === "renovate" ? _t(g, L, {
		type: "renovate",
		cell: J,
		rotation: E,
		mirror: O
	}) : null, Oe = N?.actions[0]?.type === "renovate" && J !== null ? R(De ?? L.cells[J]) : q ?? (we && S[we] ? D(S[we], E, O) : null), ke = P && Ce && J !== null && Oe ? {
		cell: J,
		piece: Oe
	} : void 0, Ae = ye.filter((e) => e.immediate), je = ye.filter((e) => !e.immediate && e.actions[0].type !== "place" && e.actions[0].type !== "special" && e.actions[0].type !== "path" && e.actions[0].type !== "construct" && e.actions[0].type !== "renovate"), Me = g.scores[I], Ne = /* @__PURE__ */ d("div", {
		className: "ri-specials ri-sheet-specials",
		children: w.map((e) => {
			let t = ye.find((t) => t.actions[0].type === "special" && t.actions[0].id === e && !t.actions[0].as);
			return /* @__PURE__ */ d("button", {
				type: "button",
				className: "ri-special",
				"aria-label": `${_.special} ${w.indexOf(e) + 1}`,
				"aria-pressed": t?.key === T,
				"data-selected": !!t && t.key === T,
				"data-used": L.specials.includes(e),
				disabled: !t || !P || I !== n,
				onClick: () => t && H(t),
				children: /* @__PURE__ */ d(It, { id: e })
			}, e);
		})
	}), Pe = /* @__PURE__ */ f("div", {
		className: "ri-command",
		children: [
			k.length > 0 && /* @__PURE__ */ d("button", {
				type: "button",
				className: "ri-action",
				onClick: V,
				children: _.cancel
			}),
			K && /* @__PURE__ */ d("button", {
				type: "button",
				className: "ri-primary",
				onClick: () => {
					r(K), V();
				},
				children: _.confirm
			}),
			Ae.map((e) => /* @__PURE__ */ f("button", {
				type: "button",
				className: [
					"finish",
					"skipEnd",
					"skipStart"
				].includes(e.actions[0].type) ? "ri-primary" : "ri-action",
				onClick: () => H(e),
				children: [e.face && /* @__PURE__ */ d(It, {
					id: e.face,
					expansion: g.config.expansion
				}), /* @__PURE__ */ d("span", { children: e.label })]
			}, e.key))
		]
	}), Fe = /* @__PURE__ */ f("div", {
		className: "ri-tools",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ri-dice-groups",
				children: [
					"route",
					"expansion",
					"engineer"
				].map((e) => {
					let t = g.dice.map((e, t) => ({
						die: e,
						i: t
					})).filter((t) => t.die.source === e);
					return t.length > 0 && /* @__PURE__ */ f("section", { children: [/* @__PURE__ */ d("h3", { children: e === "engineer" ? _.engineers : e === "expansion" ? _.expansions[g.config.expansion] : g.underRound ? _.underground : _.routes }), /* @__PURE__ */ d("div", {
						className: "ri-dice-tray",
						style: { gridTemplateColumns: `repeat(${Math.max(1, t.length)},minmax(0,1fr))` },
						children: t.map(({ die: e, i: t }) => {
							let n = ye.filter((n) => (n.actions[0].type === "place" || n.actions[0].type === "path") && n.actions[0].die === t || n.actions[0].type === "construct" && e.id === "construction" || n.actions[0].type === "renovate" && e.id === "renovation"), r = n.find((e) => e.key === T) ?? n.find((e) => e.actions[0].type !== "place" || !e.actions[0].duplicate) ?? n[0], i = M?.used.includes(t) || e.id === "construction" && M?.constructionUsed || e.id === "renovation" && M?.renovationUsed, a = Bt(g.config, e.source, e.face, g.underRound);
							return /* @__PURE__ */ f("div", {
								className: "ri-die-wrap",
								children: [/* @__PURE__ */ f("button", {
									type: "button",
									className: "ri-die",
									"data-source": a.group,
									"data-selected": !!r && r.key === T,
									"data-used": i,
									disabled: !r || !P,
									title: Z(e.face, _),
									"aria-label": `${Z(e.face, _)} ${t + 1}`,
									"aria-pressed": !!r && r.key === T,
									onClick: () => r && H(r),
									children: [/* @__PURE__ */ d(It, {
										id: e.face,
										expansion: g.config.expansion,
										ink: a.colors[1],
										surface: a.colors[0]
									}), i && /* @__PURE__ */ d("span", {
										className: "ri-cross",
										children: "✓"
									})]
								}), n.some((e) => e.actions[0].type === "place" && e.actions[0].duplicate) && /* @__PURE__ */ d("button", {
									type: "button",
									className: "ri-mini",
									onClick: () => H(n.find((e) => e.actions[0].type === "place" && e.actions[0].duplicate)),
									children: _.duplicate
								})]
							}, e.id);
						})
					}, g.round + ":" + t.map((e) => e.die.face).join(","))] }, e);
				})
			}),
			/* @__PURE__ */ f("div", {
				className: "ri-extra",
				children: [ye.filter((e) => e.actions[0].type === "special" && e.actions[0].as).map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "ri-action",
					onClick: () => H(e),
					children: [
						/* @__PURE__ */ d(It, {
							id: e.face,
							expansion: g.config.expansion
						}),
						e.label,
						" · ",
						w.indexOf(e.actions[0].id) + 1
					]
				}, e.key)), je.map((e) => /* @__PURE__ */ f("button", {
					type: "button",
					className: "ri-action",
					"aria-pressed": e.key === T,
					onClick: () => H(e),
					children: [e.face && /* @__PURE__ */ d(It, {
						id: e.face,
						expansion: g.config.expansion
					}), /* @__PURE__ */ d("span", { children: e.label })]
				}, e.key))]
			}),
			/* @__PURE__ */ d("div", {
				className: "ri-instruction",
				"aria-live": "polite",
				children: P ? N ? W.size ? _.selectTarget : k.length ? _.confirm : _.noPlacement : M?.pendingLamp ? _.pendingLamp : M?.stage === "start" ? _.startPrompt : M?.stage === "end" ? _.endPrompt : _.select : _.waiting
			}),
			/* @__PURE__ */ f("div", {
				className: "ri-resources",
				children: [
					g.config.challenge && /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ f("span", { children: [_.villages, /* @__PURE__ */ f("b", { children: [M?.villages ?? 0, " / 4"] })] }), /* @__PURE__ */ f("span", { children: [_.universities, /* @__PURE__ */ f("b", { children: [M?.universities ?? 0, " / 3"] })] })] }),
					g.config.expansion === "city" && /* @__PURE__ */ f("span", { children: [_.coins, /* @__PURE__ */ f("b", { children: [M?.coins ?? 0, " / 12"] })] }),
					g.config.expansion === "power" && /* @__PURE__ */ f("span", { children: [_.charge, /* @__PURE__ */ f("b", { children: [M?.charge ?? 0, " / 3"] })] }),
					g.config.expansion === "canyon" && /* @__PURE__ */ f("span", { children: [_.bridge, /* @__PURE__ */ f("b", { children: [12 - (M?.bridges.length ?? 0), " / 12"] })] }),
					g.config.expansion === "investigation" && /* @__PURE__ */ f("span", { children: [_.movement, /* @__PURE__ */ d("b", { children: M?.movement ?? 0 })] }),
					!!M?.factory && /* @__PURE__ */ f("span", { children: [_.duplicate, /* @__PURE__ */ d("b", { children: M.factory })] }),
					!!M?.freeSpecial && /* @__PURE__ */ f("span", { children: [_.special, /* @__PURE__ */ d("b", { children: M.freeSpecial })] })
				]
			}),
			g.config.goals && /* @__PURE__ */ d("div", {
				className: "ri-goals",
				children: g.goalIds.map((e, t) => /* @__PURE__ */ f("div", {
					"data-done": (M?.goals[t] ?? -1) >= 0,
					children: [/* @__PURE__ */ d("span", { children: _.goal[e] }), /* @__PURE__ */ d("b", { children: (M?.goals[t] ?? -1) < 0 ? "—" : M.goals[t] })]
				}, e))
			})
		]
	});
	return /* @__PURE__ */ d("div", {
		className: "ri-root",
		style: y.style,
		children: /* @__PURE__ */ d(l, {
			adaptive: !0,
			scroll: !1,
			className: "ri-screen",
			banner: /* @__PURE__ */ f("div", {
				className: "ri-top",
				children: [/* @__PURE__ */ f("div", {
					className: "ri-round",
					children: [/* @__PURE__ */ d("strong", { children: g.finalHeat ? _.finalHeat : g.round === 0 ? _.setup : `${_.round} ${Math.ceil(g.round / (g.config.expansion === "underground" && !g.config.undergroundSolo ? 2 : 1))} ${_.of} ${g.config.expansion === "underground" && !g.config.undergroundSolo ? 7 : g.maxRounds}` }), /* @__PURE__ */ f("span", { children: [g.config.challenge ? _.challenge : _.classic, g.config.expansion !== "none" && ` · ${_.expansions[g.config.expansion]}`] })]
				}), /* @__PURE__ */ d("div", {
					className: "ri-players",
					children: g.players.map((e) => /* @__PURE__ */ f("button", {
						type: "button",
						"data-selected": I === e,
						onClick: () => {
							ie(e), le(""), V();
						},
						children: [
							/* @__PURE__ */ d("span", { children: B(e) }),
							/* @__PURE__ */ d("b", { children: g.scores[e]?.total ?? 0 }),
							g.boards[e].done && /* @__PURE__ */ d("span", {
								"aria-label": _.waiting,
								children: "✓"
							})
						]
					}, e))
				})]
			}),
			children: /* @__PURE__ */ f("div", {
				className: "ri-layout",
				children: [/* @__PURE__ */ f("div", {
					className: "ri-paper-area",
					children: [
						/* @__PURE__ */ f("div", {
							className: "ri-paper-heading",
							children: [
								/* @__PURE__ */ d("strong", { children: B(I) }),
								g.config.expansion === "underground" && /* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => oe(!ae),
									children: z ? _.underground : _.surface
								}),
								/* @__PURE__ */ d("button", {
									type: "button",
									onClick: () => ce(se + 1),
									title: _.reset,
									"aria-label": _.reset,
									children: /* @__PURE__ */ d(te, { size: 16 })
								}),
								/* @__PURE__ */ f("button", {
									type: "button",
									onClick: () => me(!pe),
									children: [
										_.details,
										" ",
										/* @__PURE__ */ d("b", { children: Me?.total ?? 0 })
									]
								})
							]
						}),
						/* @__PURE__ */ f("div", {
							className: "ri-sheet",
							children: [/* @__PURE__ */ f(o, {
								sheetW: 800,
								sheetH: Ot,
								clampToSheet: !0,
								eligible: [...W.values()].map((e) => e.eligible),
								onTapEligible: G,
								fitKey: String(se),
								highlight: "inset",
								readOnly: h || !N || I !== n && !F,
								children: [
									/* @__PURE__ */ d(Lt, {
										board: L,
										config: g.config,
										under: z,
										path: k,
										preview: ke
									}),
									/* @__PURE__ */ d("foreignObject", {
										x: 85,
										y: 80,
										width: 630,
										height: 82,
										onPointerDown: (e) => e.stopPropagation(),
										onPointerUp: (e) => e.stopPropagation(),
										children: Ne
									}),
									j !== null && /* @__PURE__ */ d("rect", {
										x: Q(j).x,
										y: Q(j).y,
										width: Q(j).w,
										height: Q(j).h,
										fill: "none",
										stroke: "#aa6749",
										strokeWidth: 4
									}),
									" ",
									ke && /* @__PURE__ */ d("rect", {
										ref: b,
										className: "ri-preview-outline",
										x: Q(ke.cell).x,
										y: Q(ke.cell).y,
										width: Q(ke.cell).w,
										height: Q(ke.cell).h,
										fill: "none",
										stroke: Ee ? "var(--ri-red)" : "#b52837",
										strokeWidth: 3,
										pointerEvents: "none"
									})
								]
							}), ke && /* @__PURE__ */ f(Rt, {
								anchor: b,
								avoid: [
									{
										x: 85,
										y: 70,
										w: 630,
										h: 175
									},
									...(z ? L.under : L.cells).flatMap((e, t) => e ? [Q(t)] : []),
									...[...W.values()].map((e) => e.eligible.rect)
								],
								children: [
									/* @__PURE__ */ d("button", {
										type: "button",
										title: _.rotate,
										"aria-label": _.rotate,
										onClick: () => ue((E + 1) % 4),
										children: /* @__PURE__ */ d(ne, { size: 20 })
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										title: _.mirror,
										"aria-label": _.mirror,
										"aria-pressed": O,
										onClick: () => de(!O),
										children: /* @__PURE__ */ d(ee, { size: 20 })
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										className: "ri-place",
										title: _.actions.place,
										"aria-label": _.actions.place,
										disabled: !Ee,
										onClick: () => {
											Ee && (r(Ee), V());
										},
										children: /* @__PURE__ */ d(p, { size: 20 })
									}),
									/* @__PURE__ */ d("button", {
										type: "button",
										title: _.cancel,
										"aria-label": _.cancel,
										onClick: () => {
											le(""), V();
										},
										children: /* @__PURE__ */ d(m, { size: 18 })
									})
								]
							})]
						}),
						pe && /* @__PURE__ */ f("div", {
							className: "ri-details",
							children: [/* @__PURE__ */ d("button", {
								type: "button",
								onClick: () => me(!1),
								"aria-label": _.close,
								children: "×"
							}), /* @__PURE__ */ d(Zt, {
								s: g,
								rid: I,
								t: _
							})]
						})
					]
				}), !h && /* @__PURE__ */ f("aside", {
					className: "ri-desk",
					children: [Fe, Pe]
				})]
			})
		})
	});
}
function Zt({ s: e, rid: t, t: n }) {
	return /* @__PURE__ */ f("div", {
		className: "ri-score-ledger",
		children: [Object.keys(n.score).filter((t) => t !== "villages" || e.config.challenge).filter((t) => t !== "goals" || e.config.goals).filter((t) => t !== "expansion" || e.config.expansion !== "none").map((r) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", { children: n.score[r] }), /* @__PURE__ */ f("b", { children: [r === "errors" ? "−" : "", e.scores[t][r]] })] }, r)), e.config.goals && e.goalIds.map((r, i) => /* @__PURE__ */ f("p", { children: [
			n.goal[r],
			" ",
			/* @__PURE__ */ d("b", { children: Math.max(0, e.boards[t].goals[i]) })
		] }, r))]
	});
}
//#endregion
//#region src/games/railroadink/bot.ts
var Qt = {
	connection: 3.5,
	exit: 6,
	center: .6,
	error: 1.2,
	branch: .2,
	specialCost: 3
};
function $t(e, t, n) {
	let r = t.underRound ? e.under : e.cells, i = 0;
	return r.forEach((e, t) => {
		let a = R(e);
		if (a) {
			t % 7 >= 2 && t % 7 <= 4 && t >= 14 && t < 35 && (i += n.center);
			for (let e of a.groups.flat()) {
				let a = F(t, e.side);
				if (a < 0) {
					N.some((n) => n.cell === t && n.side === e.side && V(n.kind, e.kind)) && (i += n.exit);
					continue;
				}
				B(R(r[a]), M[e.side]).some((t) => V(t, e.kind)) ? i += n.connection : r[a] ? i -= n.error * 1.8 : i -= n.error;
			}
			i += a.groups.flat().length * n.branch, a.mark === "tree" && (i += 1.3 + I(t).filter((e) => R(r[e])?.mark === "tree").length), e?.cacti && (i += e.cacti + (I(t).some((e) => R(r[e])?.mark === "oasis") ? 2 : -.5)), a.mark === "oasis" && (i += I(t).filter((e) => r[e]?.cacti).length), a.mark === "clover" && (i += I(t).filter((e) => R(r[e])?.mark === "rainbow").length * 2), a.mark === "ufo" && (i += r.reduce((e, n, r) => e + (R(n)?.mark === "sheep" && (t % 7 == r % 7 || Math.floor(t / 7) === Math.floor(r / 7)) ? (R(n)?.amount ?? 0) * 2 : 0), 0));
		}
	}), i + e.villages * 2 + e.universities * 1.5 + e.factory * 2 + e.cluesCollected * 3 + e.charge * 2 + r.filter((e) => e?.lit || e?.powered || e?.weather).length;
}
function en(e = Qt) {
	return (t, n) => {
		let r = t.public, i = r.boards[n.rid], a = Ut(r, n.rid);
		if (!i || !a.length) return null;
		let o = a[0], s = -Infinity;
		for (let t = 0; t < a.length; t++) {
			let i = a[t], c = structuredClone(r);
			pt(c, i, n.rid);
			let l = $t(c.boards[n.rid], r, e);
			i.type === "place" && (l += (r.dice[i.die].mandatory ? 8 : 3) + (i.duplicate ? 3 : 0)), i.type === "special" && (l -= e.specialCost * (1 - Math.min(1, r.round / r.maxRounds))), (i.type === "finish" || i.type === "skipEnd" || i.type === "skipStart") && (l -= 2), (i.type === "volcano" || i.type === "eraseLava") && (l -= 20), (i.type === "startEffect" && i.sacrifice || i.type === "meteor" && i.sacrifice) && (l -= 8), i.type === "path" && (l += i.path.length * .4), i.type === "build" && (l += 2), (i.type === "construct" || i.type === "renovate") && (l -= .1), i.type === "moveInvestigator" && (l += .1), i.type === "declineBonus" && (l -= 3), n.difficulty === "weak" && (l += Math.sin(t * 23.71 + r.serial * 5.37) * 8), l > s && (s = l, o = i);
		}
		return { action: o };
	};
}
var tn = en();
//#endregion
//#region src/games/railroadink/game-over.tsx
function nn(e) {
	let { members: t, myRid: n, onPlayAgain: r, onBackToLobby: i, result: o, hintCount: l } = e, u = e.public, p = Kt(), m = s((e) => e.locale), [ee, te] = a(!0), [ne, h] = a(!1), g = (e) => {
		let n = t.find((t) => t.rid === e);
		return n ? c(n, m) : e;
	}, _ = o.ranking ?? u.players, v = Array.isArray(o.winner) ? o.winner : o.winner ? [o.winner] : [], y = Object.keys(p.score).filter((e) => e !== "villages" || u.config.challenge).filter((e) => e !== "goals" || u.config.goals).filter((e) => e !== "expansion" || u.config.expansion !== "none");
	return /* @__PURE__ */ f("div", {
		className: "ri-root ri-ending",
		style: Vt(u.config).style,
		children: [
			/* @__PURE__ */ d(Xt, {
				public: u,
				members: t,
				myRid: n,
				send: () => {},
				ending: !0
			}),
			ee && /* @__PURE__ */ f("section", {
				className: "ri-report",
				"aria-label": p.ending,
				children: [
					/* @__PURE__ */ d("h2", { children: p.ending }),
					/* @__PURE__ */ f("p", {
						className: "ri-winners",
						children: [
							p.winner,
							" · ",
							v.map(g).join(" · ")
						]
					}),
					/* @__PURE__ */ f("div", {
						className: "ri-report-scroll",
						children: [/* @__PURE__ */ f("table", { children: [/* @__PURE__ */ d("thead", { children: /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", { children: p.details }), _.map((e) => /* @__PURE__ */ d("th", { children: g(e) }, e))] }) }), /* @__PURE__ */ d("tbody", { children: y.map((e) => /* @__PURE__ */ f("tr", { children: [/* @__PURE__ */ d("th", {
							scope: "row",
							children: p.score[e]
						}), _.map((t) => /* @__PURE__ */ f("td", { children: [e === "errors" ? "−" : "", u.scores[t][e]] }, t))] }, e)) })] }), u.config.goals && /* @__PURE__ */ d("div", {
							className: "ri-goals",
							children: u.goalIds.map((e, t) => /* @__PURE__ */ f("div", { children: [/* @__PURE__ */ d("span", { children: p.goal[e] }), /* @__PURE__ */ d("span", { children: _.map((e) => `${g(e)} ${Math.max(0, u.boards[e].goals[t])}`).join(" · ") })] }, e))
						})]
					}),
					l !== void 0 && /* @__PURE__ */ f("p", {
						className: "ri-report-footer",
						children: [
							p.hintCount,
							" · ",
							l
						]
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				className: "ri-ending-actions",
				children: [
					/* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => te(!ee),
						children: ee ? p.close : p.open
					}),
					r && /* @__PURE__ */ d("button", {
						type: "button",
						className: "ri-primary",
						onClick: r,
						children: p.playAgain
					}),
					i ? /* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => h(!0),
						children: p.lobby
					}) : /* @__PURE__ */ d("span", { children: p.waitHost })
				]
			}),
			ne && /* @__PURE__ */ d("div", {
				className: "ri-confirm",
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ f("div", { children: [
					/* @__PURE__ */ d("p", { children: p.quitConfirm }),
					/* @__PURE__ */ d("button", {
						type: "button",
						onClick: i,
						children: p.yes
					}),
					/* @__PURE__ */ d("button", {
						type: "button",
						onClick: () => h(!1),
						children: p.no
					})
				] })
			})
		]
	});
}
//#endregion
//#region src/games/railroadink/options.tsx
function rn({ value: e, onChange: t }) {
	let n = Ee.parse(e), r = Kt(), i = n.expansion === "underground" && n.undergroundSolo, a = (e) => {
		let r = {
			...n,
			...e
		};
		r.expansion === "underground" && r.undergroundSolo && (r.goals = !1), t(r);
	};
	return /* @__PURE__ */ f("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ d(_, {
				title: r.variant,
				children: [!1, !0].map((e) => /* @__PURE__ */ d(g, {
					name: "railroad-version",
					value: String(e),
					label: e ? r.challenge : r.classic,
					checked: n.challenge === e,
					onChange: () => a({ challenge: e })
				}, String(e)))
			}),
			/* @__PURE__ */ d(h, {
				name: "railroad-goals",
				value: "goals",
				label: r.goalsOption,
				hint: i ? r.undergroundGoals : r.goalsHint,
				checked: n.goals && !i,
				disabled: i,
				onChange: () => a({ goals: !n.goals })
			}),
			/* @__PURE__ */ d(_, {
				title: r.expansion,
				children: ae.map((e) => /* @__PURE__ */ d(g, {
					name: "railroad-expansion",
					value: e,
					label: r.expansions[e],
					checked: n.expansion === e,
					onChange: () => a({ expansion: e })
				}, e))
			}),
			n.expansion === "underground" && /* @__PURE__ */ d(h, {
				name: "railroad-underground",
				value: "standalone",
				label: r.undergroundSolo,
				checked: n.undergroundSolo,
				onChange: () => a({ undergroundSolo: !n.undergroundSolo })
			}),
			/* @__PURE__ */ d(_, {
				title: r.engineers,
				children: [
					"specialDie",
					"separationDie",
					"renovation",
					"construction"
				].map((e) => /* @__PURE__ */ d(h, {
					name: "railroad-" + e,
					value: e,
					label: r[e],
					checked: n[e],
					disabled: n.expansion === "underground" && n.undergroundSolo,
					onChange: () => a({ [e]: !n[e] })
				}, e))
			})
		]
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/railroadink/entry.tsx
var an = {
	definition: wt,
	View: Yt,
	bot: tn,
	OverView: nn,
	Options: rn,
	locales: {
		zh: Wt,
		en: Gt
	}
};
//#endregion
export { an as default };
