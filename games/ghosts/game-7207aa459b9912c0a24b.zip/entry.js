import { randomIntAt as e } from "@bgparty/sdk/engine/prng";
import { z as t } from "zod";
import { useCallback as n, useLayoutEffect as r, useRef as i, useState as a } from "react";
import { useFxAnchor as o, useFxAnchorsMaybe as s } from "@bgparty/sdk/fx/anchors";
import { DeltaNumber as c } from "@bgparty/sdk/fx/delta-number";
import { useI18nSettings as l, useT as u } from "@bgparty/sdk/i18n";
import { IconCheck as d, IconClose as f } from "@bgparty/sdk/icons";
import { PLAYER_COLORS as p } from "@bgparty/sdk/player-colors";
import { GameScreen as m } from "@bgparty/sdk/ui/game-screen";
import { seatName as h } from "@bgparty/sdk/ui/player-strip";
import { Fragment as g, jsx as _, jsxs as v } from "react/jsx-runtime";
import { Floater as y, PulseBox as b } from "@bgparty/sdk/fx/primitives";
import { Confetti as x } from "@bgparty/sdk/ui/confetti";
import { OptionRadio as S, OptionSection as C } from "@bgparty/sdk/ui/game-options";
//#region src/games/ghosts/meta.ts
var w = {
	id: "ghosts",
	tier: "released",
	mechanics: ["trick-taking"],
	interactionTags: [],
	nameKey: "games.ghosts.name",
	descKey: "games.ghosts.desc",
	rulesKey: "games.ghosts.rules",
	icon: "👻",
	iconImg: "games/ghosts.webp",
	rulesUrl: { en: "https://cdn.shopify.com/s/files/1/0143/6178/8473/files/GhostsOfChristmas_Rulebook_220126.pdf?v=1644690422" },
	minPlayers: 3,
	maxPlayers: 4,
	bestPlayers: [4],
	accent: "#9f1239",
	releasedAt: "2026-09-15",
	search: {
		py: "sheng dan mei ying",
		init: "sdmy"
	},
	hotseat: "cover"
}, T = t.enum([
	"hearts",
	"candles",
	"notes",
	"scales"
]), E = t.object({
	s: T,
	v: t.int().min(1).max(12)
}), D = t.enum([
	"past",
	"present",
	"future"
]), O = t.object({
	purple: t.int().min(0).max(12),
	red: t.boolean()
}), k = t.discriminatedUnion("type", [
	t.object({
		type: t.literal("bid"),
		purple: t.int().min(0).max(12),
		red: t.boolean()
	}),
	t.object({
		type: t.literal("play"),
		card: E,
		era: D
	}),
	t.object({
		type: t.literal("tick"),
		now: t.number()
	})
]), A = t.object({ variant: t.enum(["standard", "tinytim"]).catch("standard") }).default({ variant: "standard" }), j = t.string(), M = t.object({
	rid: j,
	card: E
}), N = t.object({
	variant: t.enum(["standard", "tinytim"]),
	phase: t.enum([
		"bid",
		"play",
		"resolve",
		"handScore",
		"done"
	]),
	hand: t.int().min(1),
	totalHands: t.int().min(3).max(4),
	round: t.int().min(1).max(4),
	startPlayer: j,
	bidTurn: j.nullable(),
	turn: j.nullable(),
	dials: t.object({
		past: T.nullable(),
		present: T.nullable(),
		future: T.nullable()
	}),
	eras: t.object({
		past: t.array(M),
		present: t.array(M),
		future: t.array(M)
	}),
	players: t.array(t.object({
		rid: j,
		handCount: t.int().nonnegative(),
		tricksWon: t.int().nonnegative(),
		score: t.int(),
		bid: O.nullable(),
		filled: t.int().min(0).max(3)
	})),
	resolved: t.array(t.object({
		era: D,
		winner: j,
		scoringSuit: T
	})),
	lastHand: t.object({ results: t.array(t.object({
		rid: j,
		bid: O.nullable(),
		won: t.int().nonnegative(),
		gained: t.int(),
		hit: t.boolean()
	})) }).nullable()
}), ee = t.object({ hand: t.array(E) }), P = [
	"past",
	"present",
	"future"
], F = [
	"hearts",
	"candles",
	"notes",
	"scales"
], te = 4, I = 12, L = {
	settle: 700,
	trickWin: 1200,
	handScore: 2600
}, R = (e) => ({ code: e }), z = () => ({
	past: {
		dial: null,
		plays: []
	},
	present: {
		dial: null,
		plays: []
	},
	future: {
		dial: null,
		plays: []
	}
}), ne = (e, t) => e.players[(e.players.indexOf(t) + 1) % e.players.length], re = (e, t) => e.s === t.s && e.v === t.v;
function ie(t, n) {
	let r = [...n];
	for (let n = r.length - 1; n > 0; --n) {
		let i = e(t.seed, t.rngCursor, n + 1);
		t.rngCursor += 1, [r[n], r[i]] = [r[i], r[n]];
	}
	return r;
}
function ae(e) {
	let t = e === 3 ? 4 : 1;
	return F.flatMap((e) => Array.from({ length: 12 - t + 1 }, (n, r) => ({
		s: e,
		v: t + r
	})));
}
function oe(e) {
	return e.players.map((t, n) => ({
		kind: "deal",
		rid: t,
		data: { count: e.hands[t].length },
		for: [t],
		secret: { cards: e.hands[t] },
		...n > 0 ? { with: !0 } : {}
	}));
}
function se(e) {
	let t = ie(e, ae(e.players.length));
	return e.players.forEach((n, r) => {
		e.hands[n] = t.slice(r * I, (r + 1) * I);
	}), e.round = 1, e.eras = z(), e.tricksWon = Object.fromEntries(e.players.map((e) => [e, 0])), e.bids = Object.fromEntries(e.players.map((e) => [e, null])), e.resolved = [], e.resolveStep = 0, e.turn = e.startPlayer, e.variant === "standard" ? (e.phase = "bid", e.bidTurn = e.startPlayer) : (e.phase = "play", e.bidTurn = null), oe(e);
}
function ce(e, t) {
	let n = e.find((e) => e.rid === t).card.s, r = e.filter((e) => e.card.s === "hearts");
	return {
		winner: (r.length > 0 ? r : e.filter((e) => e.card.s === n)).reduce((e, t) => t.card.v > e.card.v ? t : e).rid,
		scoringSuit: n
	};
}
function le(e) {
	let t = e.players.length === 3 ? 6 : 5;
	return e.players.map((n) => {
		let r = e.tricksWon[n], i = e.bids[n], a = 0;
		return e.variant === "tinytim" ? a = r === 0 ? 6 : r <= t ? r : 0 : i && (a = r === i.purple || i.red && r === i.purple + 1 ? r * (i.red ? 1 : 2) : 0), e.scores[n] += a, {
			rid: n,
			bid: i,
			won: r,
			gained: a,
			hit: a > 0
		};
	});
}
var ue = (e, t) => P.filter((n) => e.eras[n].plays.some((e) => e.rid === t)).length;
function de(t, n, r) {
	let i = {
		seed: r,
		rngCursor: 0,
		players: [...n],
		variant: t.variant,
		phase: "bid",
		hand: 1,
		round: 1,
		startPlayer: n[0],
		hands: {},
		bids: {},
		bidTurn: null,
		eras: z(),
		turn: n[0],
		tricksWon: {},
		scores: Object.fromEntries(n.map((e) => [e, 0])),
		resolveStep: 0,
		resolved: [],
		lastHand: null,
		beatMs: 0
	};
	return i.startPlayer = n[e(r, i.rngCursor, n.length)], i.rngCursor += 1, i;
}
var fe = {
	saveCompatibility: {
		version: "1",
		migrate: ({ version: e, log: t }) => e === void 0 ? t : null
	},
	meta: w,
	schemas: {
		action: k,
		publicView: N,
		privateView: ee,
		config: A
	},
	setup(e, t, n) {
		let r = de(e, t, n);
		return {
			state: r,
			fx: se(r)
		};
	},
	reduce(e, t, { by: n }) {
		let r = structuredClone(e);
		if (t.type === "tick") {
			if (r.phase === "resolve") {
				let e = P[r.resolveStep], t = r.eras[e].plays, { winner: n, scoringSuit: i } = ce(t, r.startPlayer);
				r.tricksWon[n] += 1, r.startPlayer = n, r.resolved.push({
					era: e,
					winner: n,
					scoringSuit: i
				}), r.eras[e].plays = [], r.resolveStep += 1;
				let a = [{
					kind: "trickWin",
					rid: n,
					data: {
						era: e,
						scoringSuit: i,
						plays: t
					}
				}];
				return r.resolveStep < P.length ? (r.beatMs = L.trickWin, {
					state: r,
					fx: a
				}) : r.round < te ? (r.round += 1, r.eras = z(), r.resolved = [], r.resolveStep = 0, r.phase = "play", r.turn = r.startPlayer, {
					state: r,
					fx: a
				}) : (r.phase = "handScore", r.lastHand = le(r), r.beatMs = L.handScore, a.push({
					kind: "handScore",
					data: { results: r.lastHand }
				}), {
					state: r,
					fx: a
				});
			}
			return r.phase === "handScore" ? r.hand >= r.players.length ? (r.phase = "done", {
				state: r,
				fx: []
			}) : (r.hand += 1, {
				state: r,
				fx: se(r)
			}) : {
				state: r,
				fx: []
			};
		}
		if (t.type === "bid") {
			if (r.phase !== "bid") return R("games.ghosts.errPhase");
			if (r.bidTurn !== n) return R("games.ghosts.errTurn");
			if (t.red && t.purple >= I) return R("games.ghosts.errBid");
			r.bids[n] = {
				purple: t.purple,
				red: t.red
			};
			let e = [{
				kind: "bid",
				rid: n,
				data: {
					purple: t.purple,
					red: t.red
				}
			}];
			return r.players.every((e) => r.bids[e] !== null) ? (r.phase = "play", r.bidTurn = null, r.turn = r.startPlayer) : r.bidTurn = ne(r, n), {
				state: r,
				fx: e
			};
		}
		if (r.phase !== "play") return R("games.ghosts.errPhase");
		if (r.turn !== n) return R("games.ghosts.errTurn");
		let i = r.eras[t.era];
		if (i.plays.some((e) => e.rid === n)) return R("games.ghosts.errEraFull");
		let a = r.hands[n], o = a.findIndex((e) => re(e, t.card));
		if (o < 0) return R("games.ghosts.errCard");
		if (i.dial && t.card.s !== i.dial && a.some((e) => e.s === i.dial)) return R("games.ghosts.errFollow");
		a.splice(o, 1), i.plays.push({
			rid: n,
			card: t.card
		});
		let s = [{
			kind: "play",
			rid: n,
			data: {
				card: t.card,
				era: t.era,
				index: i.plays.length - 1
			}
		}];
		return i.dial || (i.dial = t.card.s, s.push({
			kind: "dial",
			data: {
				era: t.era,
				suit: t.card.s
			},
			with: !0
		})), r.players.every((e) => ue(r, e) === P.length) ? (r.phase = "resolve", r.resolveStep = 0, r.resolved = [], r.beatMs = L.settle) : r.turn = ne(r, n), {
			state: r,
			fx: s
		};
	},
	viewFor(e, t) {
		return {
			public: {
				variant: e.variant,
				phase: e.phase,
				hand: e.hand,
				totalHands: e.players.length,
				round: e.round,
				startPlayer: e.startPlayer,
				bidTurn: e.phase === "bid" ? e.bidTurn : null,
				turn: e.phase === "play" ? e.turn : null,
				dials: {
					past: e.eras.past.dial,
					present: e.eras.present.dial,
					future: e.eras.future.dial
				},
				eras: {
					past: e.eras.past.plays.map((e) => ({ ...e })),
					present: e.eras.present.plays.map((e) => ({ ...e })),
					future: e.eras.future.plays.map((e) => ({ ...e }))
				},
				players: e.players.map((t) => ({
					rid: t,
					handCount: e.hands[t]?.length ?? 0,
					tricksWon: e.tricksWon[t] ?? 0,
					score: e.scores[t],
					bid: e.bids[t] ?? null,
					filled: ue(e, t)
				})),
				resolved: e.resolved.map((e) => ({ ...e })),
				lastHand: e.lastHand ? { results: e.lastHand.map((e) => ({ ...e })) } : null
			},
			private: { hand: [...e.hands[t] ?? []].sort((e, t) => F.indexOf(e.s) - F.indexOf(t.s) || e.v - t.v) }
		};
	},
	status(e) {
		if (e.phase !== "done") return { phase: e.phase };
		let t = [...e.players].sort((t, n) => e.scores[n] - e.scores[t]), n = e.scores[t[0]];
		return {
			phase: "done",
			winner: t.filter((t) => e.scores[t] === n),
			ranking: t,
			scores: { ...e.scores }
		};
	},
	nextTickIn(e) {
		return e.phase === "resolve" || e.phase === "handScore" ? e.beatMs : null;
	}
};
//#endregion
//#region src/games/ghosts/ghost-icon.tsx
function pe({ size: e = 16, color: t = "var(--color-ink)", className: n }) {
	return /* @__PURE__ */ _("svg", {
		width: e,
		height: e,
		viewBox: "0 0 64 64",
		fill: "none",
		"aria-hidden": !0,
		className: n,
		children: /* @__PURE__ */ _("path", {
			fillRule: "evenodd",
			fill: t,
			d: "M32 7 C19 7 12 21 12 33 L12 53 Q17.5 46.5 23 53 Q28 47 32 53 Q36 47 41 53 Q46.5 46.5 52 53 L52 33 C52 21 45 7 32 7 Z\n           M22.3 27 a3.2 4.2 0 1 0 6.4 0 a3.2 4.2 0 1 0 -6.4 0 Z\n           M35.3 27 a3.2 4.2 0 1 0 6.4 0 a3.2 4.2 0 1 0 -6.4 0 Z\n           M29.4 37 a2.6 3.4 0 1 0 5.2 0 a2.6 3.4 0 1 0 -5.2 0 Z"
		})
	});
}
//#endregion
//#region src/games/ghosts/card.tsx
var B = (e) => `${e.s}-${e.v}`, me = {
	hearts: "games.ghosts.suit.hearts",
	candles: "games.ghosts.suit.candles",
	notes: "games.ghosts.suit.notes",
	scales: "games.ghosts.suit.scales"
}, he = {
	hearts: "games.ghosts.suitName.hearts",
	candles: "games.ghosts.suitName.candles",
	notes: "games.ghosts.suitName.notes",
	scales: "games.ghosts.suitName.scales"
}, ge = (e) => me[e], V = (e) => he[e];
function _e({ suit: e, className: t = "" }) {
	let n = {
		className: t,
		viewBox: "0 0 32 32",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0
	};
	return e === "hearts" ? /* @__PURE__ */ _("svg", {
		...n,
		children: /* @__PURE__ */ _("path", {
			d: "M16 27 5.5 16.7C-.2 10.9 8.2 2.9 14.2 8.5L16 10l1.8-1.5c6-5.6 14.4 2.4 8.7 8.2Z",
			fill: "currentColor",
			stroke: "none"
		})
	}) : e === "candles" ? /* @__PURE__ */ _("svg", {
		...n,
		children: /* @__PURE__ */ _("path", { d: "M16 5c1.9 2.3 2.3 4.1 0 6.2-2.3-1.9-1.9-3.9 0-6.2ZM11 13h10v13H11zM9 27h14M16 13v-2" })
	}) : e === "notes" ? /* @__PURE__ */ v("svg", {
		...n,
		children: [
			/* @__PURE__ */ _("path", { d: "M12 23V7l13-3v16M12 9l13-3" }),
			/* @__PURE__ */ _("ellipse", {
				cx: "8",
				cy: "24",
				rx: "4",
				ry: "2.7",
				fill: "currentColor",
				stroke: "none"
			}),
			/* @__PURE__ */ _("ellipse", {
				cx: "21",
				cy: "21",
				rx: "4",
				ry: "2.7",
				fill: "currentColor",
				stroke: "none"
			})
		]
	}) : /* @__PURE__ */ _("svg", {
		...n,
		children: /* @__PURE__ */ _("path", { d: "M16 4v22M5 10h22M10 10l-5 11h10ZM22 10l-5 11h10ZM10 27h12" })
	});
}
function H({ card: e, size: t, dimmed: n, frame: r, adaptive: i }) {
	let a = u();
	return /* @__PURE__ */ v("span", {
		"aria-label": a(ge(e.s), { n: e.v }),
		"data-suit": e.s,
		className: `ghosts-card ghosts-card--${t} ${n ? "ghosts-card--dimmed" : ""} ${r ? "ghosts-card--framed" : ""} ${i ? "ghosts-card--adaptive" : ""}`,
		style: r ? {
			width: r.w,
			height: r.h,
			borderRadius: i ? Math.max(5, Math.min(10, r.w * .09)) : void 0
		} : void 0,
		children: [
			/* @__PURE__ */ _("span", {
				className: "ghosts-card-number font-mono tabular-nums",
				children: e.v
			}),
			/* @__PURE__ */ _("span", { className: "ghosts-card-rule" }),
			/* @__PURE__ */ _(_e, {
				suit: e.s,
				className: "ghosts-card-mark"
			})
		]
	});
}
function ve({ suit: e, active: t }) {
	let n = u();
	return /* @__PURE__ */ _("span", {
		"aria-label": n(V(e)),
		"data-suit": e,
		className: `ghosts-suit-chip ${t ? "ghosts-suit-chip--active" : ""}`,
		children: /* @__PURE__ */ _(_e, {
			suit: e,
			className: "ghosts-suit-chip-mark"
		})
	});
}
function ye({ accent: e, frame: t }) {
	return /* @__PURE__ */ _("span", {
		className: `ghosts-card-back ${t ? "ghosts-card-back--framed" : ""}`,
		style: {
			width: t?.w,
			height: t?.h,
			background: `color-mix(in srgb, ${e} 20%, var(--color-violet-950))`
		},
		children: /* @__PURE__ */ _("span", {
			className: "ghosts-card-back-inner",
			"aria-hidden": !0,
			children: /* @__PURE__ */ _(pe, {
				size: 22,
				color: "var(--color-amber-200)"
			})
		})
	});
}
//#endregion
//#region src/games/ghosts/view-player.tsx
function be(e) {
	let t = e.public, n = e.private;
	return /* @__PURE__ */ _(Ce, {
		pub: t,
		priv: n,
		members: e.members,
		myRid: e.myRid,
		send: e.send
	});
}
var U = [
	"past",
	"present",
	"future"
], W = {
	past: "games.ghosts.era.past",
	present: "games.ghosts.era.present",
	future: "games.ghosts.era.future"
}, xe = {
	past: "games.ghosts.eraLatin.past",
	present: "games.ghosts.eraLatin.present",
	future: "games.ghosts.eraLatin.future"
};
function Se(e) {
	let t = s(), a = i(null), o = i(null), c = i(/* @__PURE__ */ new Map()), l = i(/* @__PURE__ */ new Map()), u = i(/* @__PURE__ */ new Set()), d = i(0), f = n(() => {
		let e = a.current;
		if (!e?.isConnected) return null;
		let t = e.getBoundingClientRect(), n = o.current?.getBoundingClientRect();
		return `${window.innerWidth}:${window.innerHeight}:${t.x}:${t.y}:${t.width}:${t.height}:${n?.x}:${n?.y}:${n?.width}:${n?.height}:${d.current}`;
	}, []), p = n((e, t) => {
		let n = f(), r = t.getBoundingClientRect(), i = (e.startsWith("hand:") ? o.current : a.current)?.getBoundingClientRect();
		n && i && r.width > 0 && r.height > 0 && r.right > i.left && r.left < i.right && r.bottom > i.top && r.top < i.bottom ? l.current.set(e, {
			box: {
				x: r.left,
				y: r.top,
				w: r.width,
				h: r.height
			},
			layout: n
		}) : l.current.delete(e);
	}, [f]), m = n((e) => {
		let t = l.current.get(e);
		return t?.layout === f() ? t.box : null;
	}, [f]), h = n((e, n) => {
		let r = c.current.get(e);
		r?.isConnected && p(e, r), n ? c.current.set(e, n) : c.current.delete(e);
		let i = `ghosts:source:${e}`;
		u.current.has(i) || (u.current.add(i), t?.registerProbe(i, () => m(e)));
	}, [
		t,
		m,
		p
	]), g = n(() => {
		for (let [e, t] of c.current) t.isConnected && p(e, t);
	}, [p]), _ = n(() => {
		d.current += 1, g();
	}, [g]), v = n((e) => {
		a.current = e;
	}, []), y = n((e) => {
		o.current = e;
	}, []);
	return r(() => {
		l.current.clear();
	}, [e]), r(g), r(() => {
		if (!t) return;
		let e = u.current;
		for (let n of e) t.registerProbe(n, () => m(n.slice(14)));
		return t.registerProbe("ghosts:wide", () => {
			let e = a.current;
			if (!e || getComputedStyle(e).getPropertyValue("--ghosts-layout").trim() !== "2") return null;
			let t = e.getBoundingClientRect();
			return {
				x: t.left,
				y: t.top,
				w: t.width,
				h: t.height
			};
		}), t.registerProbe("ghosts:card-frame", () => {
			let e = [...c.current].find(([e, t]) => e.startsWith("hand:") && t.isConnected) ?? [...c.current].find(([, e]) => e.isConnected);
			if (!e) return null;
			let t = e[1].getBoundingClientRect();
			return {
				x: t.left,
				y: t.top,
				w: t.width,
				h: t.height
			};
		}), t.registerProbe("ghosts:hand-clip", () => {
			let e = o.current;
			if (!e?.isConnected) return null;
			let t = e.getBoundingClientRect();
			return {
				x: t.left,
				y: t.top,
				w: t.width,
				h: t.height
			};
		}), () => {
			for (let n of e) t.registerProbe(n, null);
			t.registerProbe("ghosts:wide", null), t.registerProbe("ghosts:card-frame", null), t.registerProbe("ghosts:hand-clip", null);
		};
	}, [t, m]), {
		remember: h,
		capture: g,
		onScroll: _,
		stageRef: v,
		handClipRef: y
	};
}
function Ce({ pub: e, priv: t, members: r, myRid: i, send: s }) {
	let c = u(), d = l((e) => e.locale), f = (e) => {
		let t = r.find((t) => t.rid === e);
		return t ? h(t, d) : e;
	}, { ref: p } = o("table"), { remember: g, capture: y, onScroll: b, stageRef: x, handClipRef: S } = Se(`${i}:${e.hand}`), C = n((e) => {
		p(e), x(e);
	}, [p, x]), w = t?.hand ?? [], T = e.phase === "bid" && e.bidTurn === i, E = e.phase === "play" && e.turn === i, [D, O] = a(null), [k, A] = a(3), [j, M] = a(!1), N = `${e.phase}|${e.hand}|${e.round}|${e.turn}|${e.bidTurn}`, [ee, P] = a(N);
	ee !== N && (P(N), O(null), A(3), M(!1));
	let F = (t, n) => {
		if (e.eras[n].some((e) => e.rid === i)) return !1;
		let r = e.dials[n];
		return r === null || t.s === r || !w.some((e) => e.s === r);
	}, te = (e) => {
		E && U.some((t) => F(e, t)) && O(D && B(D) === B(e) ? null : e);
	}, I = (e) => {
		E && D && F(D, e) && (y(), s({
			type: "play",
			card: D,
			era: e
		}), O(null));
	}, L, R;
	e.phase === "bid" ? (L = T ? c("games.ghosts.bidYou") : c("games.ghosts.bidWait", { name: f(e.bidTurn ?? "") }), R = T && j ? c("games.ghosts.redDoorHint", {
		n: k,
		m: k + 1
	}) : void 0) : e.phase === "play" ? (L = E ? c("games.ghosts.turnYou") : c("games.ghosts.turnWait", { name: f(e.turn ?? "") }), R = c("games.ghosts.roundSub", { n: e.round })) : e.phase === "resolve" ? (L = c("games.ghosts.resolving"), R = c("games.ghosts.roundSub", { n: e.round })) : L = c("games.ghosts.handScoreTitle");
	let z = /* @__PURE__ */ v("div", {
		className: "ghosts-hud",
		children: [
			/* @__PURE__ */ v("div", {
				className: "ghosts-hud-brand",
				children: [
					/* @__PURE__ */ _("span", {
						className: "ghosts-hud-star",
						"aria-hidden": !0,
						children: "◆"
					}),
					/* @__PURE__ */ _("strong", { children: c("games.ghosts.name") }),
					/* @__PURE__ */ _("span", {
						className: "ghosts-hud-round font-mono tabular-nums",
						children: c("games.ghosts.roundSub", { n: e.round })
					})
				]
			}),
			/* @__PURE__ */ v("div", {
				className: "ghosts-hud-status",
				children: [/* @__PURE__ */ _("span", {
					className: "ghosts-hud-hand",
					children: c("games.ghosts.handChip", {
						n: e.hand,
						total: e.totalHands
					})
				}), /* @__PURE__ */ _("span", {
					className: "ghosts-hud-message",
					title: R,
					children: L
				})]
			}),
			/* @__PURE__ */ _("div", {
				className: "ghosts-hud-seats",
				children: e.players.map((t) => /* @__PURE__ */ _(we, {
					player: t,
					name: f(t.rid),
					colorIndex: r.find((e) => e.rid === t.rid)?.colorIndex ?? 0,
					isMe: t.rid === i,
					isActive: t.rid === (e.phase === "bid" ? e.bidTurn : e.turn),
					isStart: t.rid === e.startPlayer,
					cap: e.players.length === 3 ? 6 : 5,
					variant: e.variant
				}, t.rid))
			})
		]
	}), ne = e.phase === "bid" && T ? /* @__PURE__ */ v("div", {
		className: "ghosts-bid-panel pointer-events-auto",
		children: [/* @__PURE__ */ v("div", {
			className: "ghosts-bid-row",
			children: [
				/* @__PURE__ */ _("span", {
					className: "ghosts-bid-label",
					children: c("games.ghosts.bidLabel")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": c("games.ghosts.bidMinus"),
					className: "ghosts-bid-step",
					onClick: () => A(Math.max(0, k - 1)),
					children: "−"
				}),
				/* @__PURE__ */ _("span", {
					className: "ghosts-bid-count font-mono tabular-nums",
					children: k
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					"aria-label": c("games.ghosts.bidPlus"),
					className: "ghosts-bid-step",
					onClick: () => A(Math.min(12, k + 1)),
					children: "+"
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					disabled: k >= 12,
					"aria-pressed": j,
					className: "ghosts-bid-red",
					onClick: () => M(!j),
					children: c("games.ghosts.redDoor")
				}),
				/* @__PURE__ */ _("button", {
					type: "button",
					className: "ghosts-bid-confirm",
					onClick: () => s({
						type: "bid",
						purple: k,
						red: j
					}),
					children: c("games.ghosts.confirmBid")
				})
			]
		}), /* @__PURE__ */ _("span", {
			className: "ghosts-bid-note",
			children: j ? c("games.ghosts.redDoorHint", {
				n: k,
				m: k + 1
			}) : c("games.ghosts.bidYou")
		})]
	}) : null, re = t && e.phase !== "done" ? /* @__PURE__ */ v("div", {
		className: "ghosts-hand-tray",
		children: [/* @__PURE__ */ v("div", {
			className: "ghosts-hand-heading",
			children: [/* @__PURE__ */ _("strong", { children: c("games.ghosts.handCount", { n: w.length }) }), /* @__PURE__ */ _("span", { children: D ? c("games.ghosts.selectedCard", { card: c(ge(D.s), { n: D.v }) }) : c("games.ghosts.handScroll") })]
		}), /* @__PURE__ */ _("div", {
			ref: S,
			className: "ghosts-hand-scroll",
			children: /* @__PURE__ */ _("div", {
				className: "ghosts-hand-cards",
				children: w.map((t) => /* @__PURE__ */ _("button", {
					type: "button",
					disabled: !E || !U.some((e) => F(t, e)),
					"aria-pressed": D !== null && B(D) === B(t),
					onClick: () => te(t),
					className: "ghosts-hand-button",
					children: /* @__PURE__ */ _(De, {
						card: t,
						raised: D !== null && B(D) === B(t),
						dimmed: !E && e.phase === "play",
						remember: g
					})
				}, B(t)))
			})
		})]
	}) : null;
	return /* @__PURE__ */ _("div", {
		className: "ghosts-screen",
		"data-players": e.players.length,
		style: { "--ghosts-players": e.players.length },
		onScrollCapture: b,
		children: /* @__PURE__ */ _(m, {
			adaptive: !0,
			className: "ghosts-adaptive",
			banner: z,
			actionsHeight: "ghosts-actions-height h-32 short:h-24",
			actions: re,
			overlay: ne,
			scroll: !1,
			children: /* @__PURE__ */ _("div", {
				ref: C,
				className: "ghosts-stage",
				children: /* @__PURE__ */ v("div", {
					className: "ghosts-board",
					"data-phase": e.phase,
					style: { "--ghosts-board-image": "url(games/ghosts/time-board.webp)" },
					children: [
						e.phase === "bid" && /* @__PURE__ */ v("div", {
							className: `ghosts-ledger ${e.lastHand ? "ghosts-ledger--with-recap" : ""}`,
							children: [
								/* @__PURE__ */ _("h2", { children: c("games.ghosts.bidLabel") }),
								/* @__PURE__ */ _("ul", {
									className: "ghosts-ledger-list",
									children: e.players.map((t) => /* @__PURE__ */ v("li", { children: [/* @__PURE__ */ _("span", {
										className: "ghosts-ledger-name",
										children: f(t.rid)
									}), /* @__PURE__ */ _("span", {
										className: "font-mono tabular-nums",
										children: t.bid ? /* @__PURE__ */ _(ke, { bid: t.bid }) : t.rid === e.bidTurn ? "…" : "—"
									})] }, t.rid))
								}),
								e.lastHand && /* @__PURE__ */ _(Oe, {
									pub: e,
									nameOf: f,
									title: c("games.ghosts.lastHandTitle")
								})
							]
						}),
						(e.phase === "play" || e.phase === "resolve") && U.map((t) => {
							let n = e.resolved.find((e) => e.era === t), a = E && D !== null && F(D, t), o = e.eras[t].some((e) => e.rid === i), s = E && D !== null && !a;
							return /* @__PURE__ */ v("button", {
								type: "button",
								"data-era": t,
								disabled: !a,
								onClick: () => I(t),
								"aria-label": a ? c("games.ghosts.placeInEra", { era: c(W[t]) }) : c(W[t]),
								className: `ghosts-era ${a ? "ghosts-era--legal" : ""} ${s ? "ghosts-era--blocked" : ""}`,
								children: [
									/* @__PURE__ */ v("span", {
										className: "ghosts-era-head",
										children: [/* @__PURE__ */ v("span", {
											className: "ghosts-era-title",
											children: [c(W[t]), /* @__PURE__ */ _("small", { children: c(xe[t]) })]
										}), /* @__PURE__ */ _("span", {
											className: "ghosts-era-progress font-mono tabular-nums",
											children: n ? c("games.ghosts.wonBy", { name: f(n.winner) }) : c("games.ghosts.cardsPlayed", {
												n: e.eras[t].length,
												total: e.players.length
											})
										})]
									}),
									/* @__PURE__ */ v("span", {
										className: "ghosts-era-dial",
										children: [/* @__PURE__ */ _(Te, {
											era: t,
											suit: e.dials[t]
										}), /* @__PURE__ */ _("span", { children: e.dials[t] ? c(V(e.dials[t])) : c("games.ghosts.dialUnsetShort") })]
									}),
									s && /* @__PURE__ */ _("span", {
										className: "ghosts-era-reason",
										children: c(o ? "games.ghosts.eraUsed" : "games.ghosts.followSuit")
									}),
									n && /* @__PURE__ */ v("span", {
										className: "ghosts-era-winner",
										children: [/* @__PURE__ */ _(ve, {
											suit: n.scoringSuit,
											active: !0
										}), c(V(n.scoringSuit))]
									}),
									/* @__PURE__ */ _("span", {
										className: "ghosts-era-slots",
										children: e.players.map((n) => /* @__PURE__ */ _(Ee, {
											era: t,
											rid: n.rid,
											card: e.eras[t].find((e) => e.rid === n.rid)?.card ?? null,
											members: r,
											nameOf: f,
											myRid: i,
											legal: a,
											remember: g
										}, n.rid))
									})
								]
							}, t);
						}),
						(e.phase === "handScore" || e.phase === "done") && e.lastHand && /* @__PURE__ */ _("div", {
							className: "ghosts-ledger ghosts-ledger--score",
							children: /* @__PURE__ */ _(Oe, {
								pub: e,
								nameOf: f,
								title: c("games.ghosts.handScoreTitle")
							})
						})
					]
				})
			})
		})
	});
}
function we({ player: e, name: t, colorIndex: n, isMe: r, isActive: i, isStart: a, cap: s, variant: l }) {
	let d = u(), { ref: f } = o(`seat:${e.rid}`), m = p[n % p.length].hex, h = e.bid ? e.bid.red ? `${e.bid.purple}–${e.bid.purple + 1}` : `${e.bid.purple}` : l === "tinytim" ? `${s}` : null;
	return /* @__PURE__ */ v("span", {
		ref: f,
		className: "ghosts-seat",
		"data-active": i,
		"data-me": r,
		children: [/* @__PURE__ */ v("span", {
			className: "ghosts-seat-top",
			children: [
				/* @__PURE__ */ _("span", {
					className: "ghosts-seat-dot",
					style: { backgroundColor: m }
				}),
				/* @__PURE__ */ _("span", {
					className: "ghosts-seat-name",
					title: t,
					children: t
				}),
				a && /* @__PURE__ */ _("span", {
					"aria-label": d("games.ghosts.startAria"),
					className: "ghosts-seat-hat",
					children: "🎩"
				}),
				i && /* @__PURE__ */ _("span", {
					className: "ghosts-seat-active",
					"aria-hidden": !0,
					children: "…"
				})
			]
		}), /* @__PURE__ */ v("span", {
			className: "ghosts-seat-stats font-mono tabular-nums",
			children: [/* @__PURE__ */ v("span", {
				"aria-label": `${d("games.ghosts.tricksAria", { n: e.tricksWon })}${e.bid ? `, ${d("games.ghosts.bidAria", { n: e.bid.purple })}` : h ? `, ${d("games.ghosts.capAria", { n: s })}` : ""}`,
				children: [
					"❦",
					e.tricksWon,
					h && `/${h}`
				]
			}), /* @__PURE__ */ v("span", {
				"aria-label": d("games.ghosts.scoreAria", { n: e.score }),
				children: ["✦", /* @__PURE__ */ _(c, { value: e.score })]
			})]
		})]
	});
}
function Te({ era: e, suit: t }) {
	let n = u(), { ref: r, hidden: i } = o(`dial:${e}`);
	return /* @__PURE__ */ _("span", {
		ref: r,
		className: "inline-flex",
		style: { visibility: i ? "hidden" : void 0 },
		children: t ? /* @__PURE__ */ _(ve, {
			suit: t,
			active: !0
		}) : /* @__PURE__ */ _("span", {
			"aria-label": n("games.ghosts.dialUnset"),
			className: "ghosts-dial-unset",
			children: "?"
		})
	});
}
function Ee({ era: e, rid: t, card: r, members: i, nameOf: a, myRid: s, legal: c, remember: l }) {
	let d = u(), { ref: f, hidden: m } = o(`slot:${e}:${t}`), h = n((n) => {
		l(`slot:${e}:${t}`, n), f(n);
	}, [
		e,
		t,
		l,
		f
	]), g = i.find((e) => e.rid === t), y = g ? p[g.colorIndex % p.length].hex : void 0;
	return /* @__PURE__ */ v("span", {
		className: "ghosts-slot",
		children: [/* @__PURE__ */ _("span", {
			ref: h,
			className: "ghosts-slot-card",
			style: { visibility: m ? "hidden" : void 0 },
			children: r ? /* @__PURE__ */ _(H, {
				card: r,
				size: "hand"
			}) : /* @__PURE__ */ v("span", {
				"aria-hidden": !0,
				"data-my-slot": t === s,
				"data-legal": t === s && c,
				className: "ghosts-empty-slot",
				children: [/* @__PURE__ */ _("span", { children: t === s ? "+" : "·" }), t === s && c && /* @__PURE__ */ _("small", { children: d("games.ghosts.dropHere") })]
			})
		}), /* @__PURE__ */ v("span", {
			className: "ghosts-slot-name",
			children: [g && /* @__PURE__ */ _("span", {
				className: "ghosts-slot-dot",
				style: { backgroundColor: y }
			}), /* @__PURE__ */ _("span", {
				title: a(t),
				children: a(t)
			})]
		})]
	});
}
function De({ card: e, raised: t, dimmed: r, remember: i }) {
	let a = `hand:${B(e)}`, { ref: s, hidden: c } = o(a), l = n((e) => {
		i(a, e), s(e);
	}, [
		a,
		i,
		s
	]);
	return /* @__PURE__ */ _("span", {
		ref: l,
		className: `ghosts-hand-anchor inline-flex ${t ? "-translate-y-2" : ""}`,
		style: { visibility: c ? "hidden" : void 0 },
		children: /* @__PURE__ */ _(H, {
			card: e,
			size: "hand",
			dimmed: r
		})
	});
}
function Oe({ pub: e, nameOf: t, title: n }) {
	let r = u(), i = e.lastHand?.results ?? [], a = e.variant === "tinytim", o = e.players.length === 3 ? 6 : 5;
	return /* @__PURE__ */ v("div", {
		className: "ghosts-recap",
		children: [/* @__PURE__ */ _("p", {
			className: "ghosts-recap-title",
			children: n
		}), /* @__PURE__ */ _("ul", {
			className: "ghosts-recap-list",
			children: i.map((e) => /* @__PURE__ */ v("li", { children: [
				/* @__PURE__ */ _("span", {
					className: "ghosts-recap-name min-w-0 flex-1 truncate text-sm",
					title: t(e.rid),
					children: t(e.rid)
				}),
				/* @__PURE__ */ v("span", {
					className: "ghosts-recap-target flex-none font-mono tabular-nums",
					children: [
						e.bid ? /* @__PURE__ */ _(ke, { bid: e.bid }) : a ? /* @__PURE__ */ v("span", {
							"aria-label": r("games.ghosts.capAria", { n: o }),
							children: ["≤", o]
						}) : "—",
						" → 🌿",
						e.won
					]
				}),
				e.hit ? /* @__PURE__ */ _("span", {
					className: "ghosts-recap-hit grid size-5 flex-none place-items-center rounded-full border-2 border-ink bg-emerald-500 text-white",
					"aria-label": r(a ? "games.ghosts.scored" : "games.ghosts.hit"),
					children: /* @__PURE__ */ _(d, {
						size: 12,
						strokeWidth: 3.5,
						"aria-hidden": !0
					})
				}) : /* @__PURE__ */ _("span", {
					className: "ghosts-recap-hit grid size-5 flex-none place-items-center rounded-full border-2 border-ink bg-rose-500 text-white",
					"aria-label": r(a ? "games.ghosts.noScore" : "games.ghosts.miss"),
					children: /* @__PURE__ */ _(f, {
						size: 12,
						strokeWidth: 3.5,
						"aria-hidden": !0
					})
				}),
				/* @__PURE__ */ _("span", {
					className: `ghosts-recap-gain flex-none font-mono tabular-nums ${e.gained > 0 ? "text-emerald-600" : ""}`,
					children: r("games.ghosts.gainPlus", { n: e.gained })
				})
			] }, e.rid))
		})]
	});
}
function ke({ bid: e }) {
	return /* @__PURE__ */ v(g, { children: [
		"🚪",
		e.purple,
		e.red && "🟥"
	] });
}
//#endregion
//#region src/games/ghosts/bot.ts
var Ae = [
	"past",
	"present",
	"future"
], je = [
	"candles",
	"notes",
	"scales"
], G = {
	heartAceW: 1,
	heartHighW: .7,
	heartMidW: .4,
	heartLongW: .2,
	heartLowW: .05,
	voidHeartW: .6,
	voidNoHeartW: .1,
	shortSuitW: .25,
	aceWShort: .85,
	aceWLong: .55,
	kingWShort: .45,
	kingWLong: .2,
	queenWShort: .2,
	queenWLong: .05,
	bidBoost3: 2,
	bidBoost4: 1,
	hungryNeed: 2,
	dialDumpW: .5
};
function Me(e, t, n) {
	return Ae.flatMap((r) => {
		if (e.eras[r].some((e) => e.rid === n)) return [];
		let i = e.dials[r];
		return (i !== null && t.some((e) => e.s === i) ? t.filter((e) => e.s === i) : t).map((e) => ({
			era: r,
			card: e
		}));
	});
}
function Ne(e, t) {
	let n = e.eras[t].find((t) => t.rid === e.startPlayer);
	return n ? n.card.s : null;
}
function K(e, t, n) {
	let r = e.eras[t], i = r.filter((e) => e.card.s === "hearts");
	if (n.s === "hearts") return i.every((e) => e.card.v < n.v);
	if (i.length > 0) return !1;
	let a = Ne(e, t);
	return a === null ? null : n.s === a && r.filter((e) => e.card.s === a).every((e) => e.card.v < n.v);
}
var q = (e) => (e.s === "hearts" ? 100 : 0) + e.v;
function Pe(e, t = G) {
	let n = 0, r = e.filter((e) => e.s === "hearts");
	for (let e of r) n += e.v >= 11 ? t.heartAceW : e.v >= 9 ? t.heartHighW : e.v >= 7 ? t.heartMidW : r.length >= 4 ? t.heartLongW : t.heartLowW;
	for (let i of je) {
		let a = e.filter((e) => e.s === i);
		if (a.length === 0) {
			n += r.length > 0 ? t.voidHeartW : t.voidNoHeartW;
			continue;
		}
		a.length === 1 && (n += t.shortSuitW);
		for (let e of a) n += e.v === 12 ? a.length <= 4 ? t.aceWShort : t.aceWLong : e.v === 11 ? a.length <= 3 ? t.kingWShort : t.kingWLong : e.v === 10 ? a.length <= 2 ? t.queenWShort : t.queenWLong : 0;
	}
	return n;
}
function Fe(e, t, n, r) {
	let i = t.filter((t) => K(e, t.era, t.card) === !0), a = t.filter((t) => t.card.s === "hearts" && K(e, t.era, t.card) !== !1);
	if (r) return a.length > 0 ? a.reduce((e, t) => t.card.v > e.card.v ? t : e) : i.length > 0 ? i.reduce((e, t) => q(e.card) > q(t.card) ? e : t) : null;
	if (i.length > 0) {
		let t = i.filter((t) => e.players.every((r) => r.rid === n || e.eras[t.era].some((e) => e.rid === r.rid)));
		return t.length > 0 ? t.reduce((e, t) => q(e.card) < q(t.card) ? e : t) : i.reduce((e, t) => q(e.card) > q(t.card) ? e : t);
	}
	return a.length > 0 ? a.reduce((e, t) => t.card.v > e.card.v ? t : e) : null;
}
function Ie(e, t, n, r) {
	let i = t.filter((t) => K(e, t.era, t.card) === !1), a = i.length > 0 ? i : t;
	return n ? a.reduce((t, n) => {
		let i = q(t.card) + (e.dials[t.era] === null ? 0 : r.dialDumpW);
		return q(n.card) + (e.dials[n.era] === null ? 0 : r.dialDumpW) > i ? n : t;
	}) : a.reduce((e, t) => q(t.card) < q(e.card) ? t : e);
}
function Le(e = {}) {
	let t = {
		...G,
		...e
	};
	return (e, n) => {
		let r = e.public, i = e.private;
		if (!i) return null;
		let a = n.rid, o = n.difficulty === "weak";
		if (r.phase === "bid") {
			if (r.bidTurn !== a) return null;
			if (o) return { action: {
				type: "bid",
				purple: 2,
				red: !1
			} };
			let e = Pe(i.hand, t), n = r.players.length === 3 ? t.bidBoost3 : t.bidBoost4;
			return { action: {
				type: "bid",
				purple: Math.max(0, Math.min(11, Math.round(e) + n)),
				red: !1
			} };
		}
		if (r.phase !== "play" || r.turn !== a) return null;
		let s = Me(r, i.hand, a);
		if (s.length === 0) return null;
		if (o) return { action: {
			type: "play",
			...s[i.hand.length % s.length]
		} };
		let c = r.players.find((e) => e.rid === a), l = c?.tricksWon ?? 0, u;
		if (r.variant === "tinytim") {
			let e = r.players.length === 3 ? 6 : 5;
			u = l >= 1 && l < e;
		} else {
			let e = c?.bid ?? null, t = e?.purple ?? 0;
			u = e?.red === !0 && l === t + 1 ? !1 : l !== t;
		}
		let d = r.variant === "standard" ? (c?.bid?.purple ?? 0) - l : l === 0 ? 0 : 1, f = u && d >= t.hungryNeed;
		return { action: {
			type: "play",
			...(u ? Fe(r, s, a, f) : null) ?? Ie(r, s, !u, t)
		} };
	};
}
var Re = Le(G), ze = {
	hearts: "games.ghosts.suit.hearts",
	candles: "games.ghosts.suit.candles",
	notes: "games.ghosts.suit.notes",
	scales: "games.ghosts.suit.scales"
}, Be = {
	past: "games.ghosts.era.past",
	present: "games.ghosts.era.present",
	future: "games.ghosts.era.future"
}, Ve = (e, t, n) => e.type === "bid" ? n("games.ghosts.bidAria", { n: e.purple }) : e.type === "play" ? n("games.ghosts.hintPlay", {
	card: n(ze[e.card.s], { n: e.card.v }),
	era: n(Be[e.era])
}) : "", He = {
	hearts: "红心(永远王牌)",
	candles: "蜡烛",
	notes: "音符",
	scales: "天平"
}, J = {
	past: "过去",
	present: "现在",
	future: "未来"
}, Y = [
	"past",
	"present",
	"future"
], Ue = (e) => `${e.s === "hearts" ? "♥" : e.s === "candles" ? "蜡" : e.s === "notes" ? "音" : "秤"}${e.v}`, We = {
	needsAction: (e, t) => e.public.phase === "bid" && e.public.bidTurn === t.rid || e.public.phase === "play" && e.public.turn === t.rid,
	describeView(e, t) {
		let n = e.public, r = [`第 ${n.hand}/${n.totalHands} 手,第 ${n.round}/4 轮。规则:每人每轮往「过去/现在/未来」三个时代各打 1 张牌(分三次轮到你就各出一张)。每个时代本轮第一张牌定下该时代的「跟花色」(dial)——之后你往该时代出牌时,手上有该花色必须跟。墩的赢法:计分花色 = 起始玩家在该时代出的花色(不是 dial);有红心比红心(红心恒王牌),否则比计分花色,点大者赢墩并接任起始玩家(影响下一墩计分花色)。`];
		n.variant === "standard" ? r.push("叫标规则:预测自己整手赢墩数(purple 门),可加开红门(命中范围扩到 purple 或 purple+1,但每墩只值 1 分;不开红门则必须恰中 purple,每墩 2 分)。不命中得 0 分。") : r.push("小蒂姆变体:不叫标。0 墩得 6 分;1~5 墩(3 人局 1~6)按墩数得分;超过帽数得 0 分——墩数拿多反而爆。"), r.push(`各时代 dial: ${Y.map((e) => `${J[e]}=${n.dials[e] ? He[n.dials[e]] : "未定"}`).join(" ")}`, `各时代已出牌: ${Y.map((e) => `${J[e]}:[${n.eras[e].map((e) => `${e.rid === t.rid ? "你" : e.rid}:${Ue(e.card)}`).join(" ")}]`).join(" ")}`, `起始玩家: ${n.startPlayer === t.rid ? "你" : n.startPlayer}`);
		for (let e of n.players) {
			let n = e.rid === t.rid ? "你" : e.rid;
			r.push(`${n}: 手牌 ${e.handCount} 张,已赢墩 ${e.tricksWon},总分 ${e.score},叫标 ${e.bid ? `${e.bid.purple}${e.bid.red ? "+红门" : ""}` : "未叫"},本轮已出 ${e.filled}/3`);
		}
		n.lastHand && r.push(`上一手结果: ${n.lastHand.results.map((e) => `${e.rid === t.rid ? "你" : e.rid} 叫 ${e.bid ? `${e.bid.purple}${e.bid.red ? "+红" : ""}` : "-"} 赢 ${e.won} 得 ${e.gained}`).join("; ")}`);
		let i = e.private?.hand ?? [];
		if (n.phase === "bid" && n.bidTurn === t.rid) r.push(`你的手牌: ${i.map(Ue).join(" ")}`), r.push("轮到你叫标:输出 bid{purple: 预测赢墩数(0-12), red: 是否加开红门}。");
		else if (n.phase === "play" && n.turn === t.rid) {
			r.push(`你的手牌: ${i.map(Ue).join(" ")}`);
			let e = Y.filter((e) => n.eras[e].some((e) => e.rid === t.rid));
			r.push(`你本轮已出时代: ${e.map((e) => J[e]).join("、") || "无"}(不能重复出同一时代)。轮到你:输出 play{card:{s,v}, era}。目标时代 dial 已定且你手上有该花色时必须跟。`);
		}
		return r.join("\n");
	},
	actionJsonSchema: { oneOf: [{
		type: "object",
		properties: {
			type: { const: "bid" },
			purple: {
				type: "integer",
				minimum: 0,
				maximum: 12,
				description: "预测整手赢墩数"
			},
			red: {
				type: "boolean",
				description: "是否加开红门(命中范围 +1,每墩分值减半)"
			}
		},
		required: [
			"type",
			"purple",
			"red"
		],
		additionalProperties: !1
	}, {
		type: "object",
		properties: {
			type: { const: "play" },
			card: {
				type: "object",
				properties: {
					s: { enum: [
						"hearts",
						"candles",
						"notes",
						"scales"
					] },
					v: {
						type: "integer",
						minimum: 1,
						maximum: 12
					}
				},
				required: ["s", "v"],
				additionalProperties: !1
			},
			era: { enum: [
				"past",
				"present",
				"future"
			] }
		},
		required: [
			"type",
			"card",
			"era"
		],
		additionalProperties: !1
	}] },
	parseAction(e, t, n) {
		let r = k.safeParse(e);
		if (!r.success) return null;
		let i = r.data, a = t.public;
		if (i.type === "tick") return null;
		if (i.type === "bid") return a.phase !== "bid" || a.bidTurn !== n.rid || i.red && i.purple >= 12 ? null : i;
		if (a.phase !== "play" || a.turn !== n.rid || a.eras[i.era].some((e) => e.rid === n.rid)) return null;
		let o = t.private?.hand ?? [];
		if (!o.some((e) => e.s === i.card.s && e.v === i.card.v)) return null;
		let s = a.dials[i.era];
		return s && i.card.s !== s && o.some((e) => e.s === s) ? null : i;
	}
};
//#endregion
//#region src/games/ghosts/fx.tsx
function X(e, t) {
	return t ? e.anchor(`seat:${t}`) : null;
}
function Ge(e, t) {
	return e.anchor(t) ?? e.anchor(`ghosts:source:${t}`);
}
function Z(e, t) {
	let n = Math.min(1, e.w / t.w, e.h / t.h), r = t.w * n, i = t.h * n;
	return {
		x: e.x + (e.w - r) / 2,
		y: e.y + (e.h - i) / 2,
		w: r,
		h: i
	};
}
function Ke(e, t) {
	let n = e.anchor("table");
	return n ? Z(n, t) : null;
}
function Q(e, t) {
	return !!(e && t && e.w > 0 && e.h > 0 && t.w > 0 && t.h > 0 && e.x + e.w > t.x && e.x < t.x + t.w && e.y + e.h > t.y && e.y < t.y + t.h);
}
function qe(e, t) {
	return t ? `inset(${Math.max(0, t.y - e.y) / e.h * 100}% ${Math.max(0, e.x + e.w - t.x - t.w) / e.w * 100}% ${Math.max(0, e.y + e.h - t.y - t.h) / e.h * 100}% ${Math.max(0, t.x - e.x) / e.w * 100}%)` : "inset(0% 0% 0% 0%)";
}
function $({ from: e, to: t, card: n, adaptive: a, ms: o, delay: s = 0, fromClip: c, toClip: l }) {
	let u = i(null);
	return r(() => {
		let n = u.current, r = n?.firstElementChild;
		if (!n || !(r instanceof HTMLElement)) return;
		let i = t.x - e.x, a = t.y - e.y, d = t.w / e.w, f = t.h / e.h, p = {
			duration: o,
			delay: s,
			easing: "cubic-bezier(.3,.7,.25,1)",
			fill: "both"
		}, m = n.animate([
			{ transform: "translate(0, 0)" },
			{
				transform: `translate(${i * .55}px, ${a * .55 - 14}px)`,
				offset: .55
			},
			{ transform: `translate(${i}px, ${a}px)` }
		], p), h = r.animate([
			{
				transform: "scale(1, 1)",
				clipPath: qe(e, c)
			},
			{
				transform: `scale(${(1 + d) / 2}, ${(1 + f) / 2})`,
				clipPath: "inset(0% 0% 0% 0%)",
				offset: .55
			},
			{
				transform: `scale(${d}, ${f})`,
				clipPath: qe(t, l)
			}
		], p);
		return () => {
			m.cancel(), h.cancel();
		};
	}, [
		e,
		t,
		o,
		s,
		c,
		l
	]), /* @__PURE__ */ _("div", {
		ref: u,
		className: "ghosts-fx-flight",
		style: {
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h
		},
		children: /* @__PURE__ */ _("div", {
			className: "ghosts-fx-flight__face",
			children: n ? /* @__PURE__ */ _(H, {
				card: n,
				size: "hand",
				frame: e,
				adaptive: a
			}) : /* @__PURE__ */ _(ye, {
				accent: w.accent,
				frame: e
			})
		})
	});
}
function Je({ adaptive: e, children: t }) {
	return /* @__PURE__ */ _("span", {
		className: `ghosts-fx-label ${e ? "ghosts-fx-label--wide" : ""}`,
		children: t
	});
}
function Ye(e) {
	if (typeof e != "object" || !e) return null;
	let t = e;
	return typeof t.s == "string" && typeof t.v == "number" ? t : null;
}
function Xe(e) {
	if (!Array.isArray(e)) return null;
	let t = e.map(Ye);
	return t.every((e) => e !== null) ? t : null;
}
function Ze(e) {
	if (!Array.isArray(e)) return null;
	let t = e.map((e) => {
		if (typeof e != "object" || !e) return null;
		let t = e.rid, n = Ye(e.card);
		return typeof t == "string" && n ? {
			rid: t,
			card: n
		} : null;
	});
	return t.every((e) => e !== null) ? t : null;
}
var Qe = {
	deal(e, t) {
		let n = t.queued > 0, r = n ? 160 : 320, i = n ? 12 : 45, a = t.anchor("ghosts:wide") !== null, o = t.anchor("table"), s = t.anchor("ghosts:hand-clip"), c = e.secret, l = c ? Xe(c.cards) : null;
		if (l) {
			let e = [], c = [];
			for (let u of l) {
				let l = t.anchor(`hand:${B(u)}`);
				if (!Q(l, s)) continue;
				let d = Ke(t, l);
				Q(d, o) && (n || c.push(`hand:${B(u)}`), e.push(/* @__PURE__ */ _($, {
					from: d,
					to: l,
					card: u,
					adaptive: a,
					ms: r,
					delay: e.length * i,
					fromClip: o ?? void 0,
					toClip: s ?? void 0
				}, B(u))));
			}
			return e.length ? {
				ms: r + e.length * i,
				node: e,
				hide: c
			} : null;
		}
		let u = X(t, e.rid), d = t.anchor("ghosts:card-frame") ?? {
			w: 52,
			h: 74
		}, f = Ke(t, d);
		if (!Q(f, o) || !u) return null;
		let p = Z(u, d), m = e.data?.count, h = typeof m == "number" ? m : 12;
		return {
			ms: r + h * i,
			node: Array.from({ length: h }, (e, t) => /* @__PURE__ */ _($, {
				from: f,
				to: p,
				adaptive: a,
				ms: r,
				delay: t * i,
				fromClip: o ?? void 0,
				toClip: u
			}, t))
		};
	},
	bid(e, t) {
		let n = X(t, e.rid);
		if (!n) return null;
		let r = e.data, i = typeof r?.purple == "number" ? r.purple : 0, a = r?.red === !0, o = t.queued > 0;
		return {
			ms: o ? 300 : 900,
			node: /* @__PURE__ */ _(y, {
				at: n,
				ms: o ? 260 : 800,
				delay: o ? 0 : 60,
				children: /* @__PURE__ */ v(Je, {
					adaptive: t.anchor("ghosts:wide") !== null,
					children: [
						"🚪",
						i,
						a ? "🟥" : ""
					]
				})
			})
		};
	},
	play(e, t) {
		let n = e.data, r = Ye(n?.card), i = n?.era;
		if (!r || !i) return null;
		let a = t.anchor(`slot:${i}:${e.rid}`), o = t.anchor("table");
		if (!Q(a, o)) return null;
		let s = X(t, e.rid), c = e.rid === t.myRid, l = c ? Ge(t, `hand:${B(r)}`) : s ? Z(s, a) : null, u = c ? t.anchor("ghosts:hand-clip") : s;
		if (!Q(l, u)) return null;
		let d = t.queued > 0;
		return {
			ms: d ? 200 : Math.min(400, L.settle),
			node: /* @__PURE__ */ _($, {
				from: l,
				to: a,
				card: r,
				adaptive: t.anchor("ghosts:wide") !== null,
				ms: d ? 180 : 380,
				fromClip: u ?? void 0,
				toClip: o ?? void 0
			}),
			hide: d ? [] : [`slot:${i}:${e.rid}`]
		};
	},
	dial(e, t) {
		let n = e.data?.era, r = n ? t.anchor(`dial:${n}`) : null;
		if (!Q(r, t.anchor("table"))) return null;
		let i = t.queued > 0 ? 220 : Math.min(500, L.settle);
		return {
			ms: i,
			node: /* @__PURE__ */ _(b, {
				at: r,
				ms: i
			})
		};
	},
	trickWin(e, t) {
		let n = X(t, e.rid), r = e.data, i = r?.era, a = Ze(r?.plays);
		if (!n || !i || !a) return null;
		let o = t.queued > 0, s = t.anchor("ghosts:wide") !== null, c = t.anchor("table"), l = [];
		for (let [e, r] of a.entries()) {
			let a = Ge(t, `slot:${i}:${r.rid}`);
			if (!Q(a, c)) continue;
			let u = Z(n, a);
			l.push(/* @__PURE__ */ _($, {
				from: a,
				to: u,
				card: r.card,
				adaptive: s,
				ms: o ? 170 : 420,
				delay: e * (o ? 30 : 60),
				fromClip: c ?? void 0,
				toClip: n
			}, r.rid));
		}
		return {
			ms: o ? 450 : L.trickWin,
			node: /* @__PURE__ */ v(g, { children: [l, /* @__PURE__ */ _(y, {
				at: n,
				ms: o ? 200 : 650,
				delay: o ? 220 : 480,
				children: /* @__PURE__ */ _(Je, {
					adaptive: s,
					children: "👑"
				})
			})] })
		};
	},
	handScore(e, t) {
		let n = e.data, r = Array.isArray(n?.results) ? n.results : [], i = t.queued > 0, a = [];
		for (let [e, n] of r.entries()) {
			if (typeof n != "object" || !n) continue;
			let r = n;
			if (typeof r.rid != "string" || typeof r.gained != "number") continue;
			let o = X(t, r.rid);
			o && a.push(/* @__PURE__ */ _(y, {
				at: o,
				ms: i ? 240 : 900,
				delay: e * (i ? 35 : 120),
				children: /* @__PURE__ */ _(Je, {
					adaptive: t.anchor("ghosts:wide") !== null,
					children: r.hit === !0 ? `+${r.gained}` : "✗"
				})
			}, r.rid));
		}
		return a.length ? {
			ms: i ? 380 : L.handScore - L.trickWin,
			node: a
		} : null;
	}
};
//#endregion
//#region src/games/ghosts/game-over.tsx
function $e({ result: e, public: t, members: n, myRid: r, onPlayAgain: i, onBackToLobby: a }) {
	let o = u(), s = l((e) => e.locale), c = t, m = c.variant === "tinytim", g = c.players.length === 3 ? 6 : 5, y = (e) => {
		let t = n.find((t) => t.rid === e);
		return t ? h(t, s) : e;
	}, b = (t) => e.scores?.[t] ?? c.players.find((e) => e.rid === t)?.score ?? 0, S = (e) => p[(n.find((t) => t.rid === e)?.colorIndex ?? 0) % p.length].hex, C = c.lastHand?.results ?? [];
	return /* @__PURE__ */ _("div", {
		className: "ghosts-over",
		style: {
			"--ghosts-result-players": e.ranking.length,
			"--ghosts-board-image": "url(games/ghosts/time-board.webp)"
		},
		children: /* @__PURE__ */ v("div", {
			className: "ghosts-over-layout",
			children: [
				e.winner.length > 0 && /* @__PURE__ */ _(x, {}),
				/* @__PURE__ */ v("header", {
					className: "ghosts-over-heading",
					children: [
						/* @__PURE__ */ _("span", {
							className: "ghosts-over-crest",
							"aria-hidden": !0
						}),
						/* @__PURE__ */ v("div", {
							className: "ghosts-over-title",
							children: [/* @__PURE__ */ _("span", { children: o("games.ghosts.name") }), /* @__PURE__ */ _("h1", { children: o("session.result.title") })]
						}),
						/* @__PURE__ */ v("p", { children: [o(m ? "games.ghosts.variantTinytim" : "games.ghosts.variantStandard"), /* @__PURE__ */ _("span", { children: o("games.ghosts.handChip", {
							n: c.hand,
							total: c.totalHands
						}) })] })
					]
				}),
				/* @__PURE__ */ v("div", {
					className: "ghosts-over-content",
					children: [/* @__PURE__ */ v("section", {
						className: "ghosts-over-section ghosts-over-ranks",
						children: [/* @__PURE__ */ _("h2", { children: o("games.ghosts.totalScore") }), /* @__PURE__ */ _("ol", {
							className: "ghosts-over-rank-list",
							children: e.ranking.map((t) => {
								let n = e.winner.includes(t), i = e.ranking.findIndex((e) => b(e) === b(t)) + 1, a = e.autopilot?.[t];
								return /* @__PURE__ */ v("li", {
									className: `ghosts-over-rank ${n ? "ghosts-over-rank--winner" : ""}`,
									children: [
										/* @__PURE__ */ _("span", {
											className: "ghosts-over-place font-mono tabular-nums",
											style: { backgroundColor: S(t) },
											children: i
										}),
										/* @__PURE__ */ v("div", {
											className: "ghosts-over-identity",
											children: [/* @__PURE__ */ _("strong", {
												className: "ghosts-over-name",
												title: y(t),
												children: y(t)
											}), /* @__PURE__ */ v("div", {
												className: "ghosts-over-tags",
												children: [
													t === r && /* @__PURE__ */ _("span", { children: o("lobby.you") }),
													n && /* @__PURE__ */ v("span", {
														className: "ghosts-over-winner",
														children: ["★ ", o(e.winner.length > 1 ? "games.ghosts.sharedWinner" : "games.ghosts.winner")]
													}),
													a !== void 0 && a > 0 && /* @__PURE__ */ _("span", { children: o("session.autopilot.share", { n: Math.round(a * 100) }) })
												]
											})]
										}),
										/* @__PURE__ */ _("strong", {
											className: "ghosts-over-total font-mono tabular-nums",
											"aria-label": o("games.ghosts.scoreAria", { n: b(t) }),
											children: b(t)
										})
									]
								}, t);
							})
						})]
					}), C.length > 0 && /* @__PURE__ */ v("section", {
						className: "ghosts-over-section ghosts-over-recap",
						children: [/* @__PURE__ */ _("h2", { children: o("games.ghosts.finalHand") }), /* @__PURE__ */ _("ul", {
							className: "ghosts-over-recap-list",
							children: C.map((e) => /* @__PURE__ */ v("li", {
								className: "ghosts-over-hand-result",
								children: [/* @__PURE__ */ v("div", {
									className: "ghosts-over-result-heading",
									children: [/* @__PURE__ */ v("strong", {
										className: "ghosts-over-name",
										title: y(e.rid),
										children: [/* @__PURE__ */ _("span", { style: { backgroundColor: S(e.rid) } }), y(e.rid)]
									}), /* @__PURE__ */ v("span", {
										className: `ghosts-over-hit ${e.hit ? "ghosts-over-hit--yes" : ""}`,
										children: [e.hit ? /* @__PURE__ */ _(d, {
											size: 18,
											strokeWidth: 3,
											"aria-hidden": !0
										}) : /* @__PURE__ */ _(f, {
											size: 18,
											strokeWidth: 3,
											"aria-hidden": !0
										}), o(m ? e.hit ? "games.ghosts.scored" : "games.ghosts.noScore" : e.hit ? "games.ghosts.hit" : "games.ghosts.miss")]
									})]
								}), /* @__PURE__ */ v("dl", {
									className: "ghosts-over-metrics",
									children: [
										/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: o(m ? "games.ghosts.trickLimit" : "games.ghosts.bidTarget") }), /* @__PURE__ */ _("dd", {
											className: "font-mono tabular-nums",
											children: m ? g : e.bid ? /* @__PURE__ */ v("span", {
												"aria-label": e.bid.red ? o("games.ghosts.bidRangeAria", {
													n: e.bid.purple,
													m: e.bid.purple + 1
												}) : o("games.ghosts.bidAria", { n: e.bid.purple }),
												children: [
													e.bid.red && /* @__PURE__ */ _("span", {
														className: "ghosts-over-red-door",
														"aria-label": o("games.ghosts.redDoor"),
														children: "▰"
													}),
													e.bid.purple,
													e.bid.red && `–${e.bid.purple + 1}`
												]
											}) : "—"
										})] }),
										/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: o("games.ghosts.tricksWon") }), /* @__PURE__ */ _("dd", {
											className: "font-mono tabular-nums",
											children: e.won
										})] }),
										/* @__PURE__ */ v("div", { children: [/* @__PURE__ */ _("dt", { children: o("games.ghosts.handGain") }), /* @__PURE__ */ _("dd", {
											className: "ghosts-over-gain font-mono tabular-nums",
											children: o("games.ghosts.gainPlus", { n: e.gained })
										})] })
									]
								})]
							}, e.rid))
						})]
					})]
				}),
				/* @__PURE__ */ v("footer", {
					className: "ghosts-over-actions safe-b",
					children: [
						i && /* @__PURE__ */ _("button", {
							type: "button",
							className: "btn-base text-white",
							style: { backgroundColor: w.accent },
							onClick: i,
							children: o("session.result.playAgain")
						}),
						a && /* @__PURE__ */ _("button", {
							type: "button",
							className: "btn-quiet",
							onClick: a,
							children: o("session.result.backToLobby")
						}),
						!i && !a && /* @__PURE__ */ _("p", { children: o("session.result.waitHost") })
					]
				})
			]
		})
	});
}
//#endregion
//#region src/games/ghosts/options.tsx
function et({ value: e, onChange: t }) {
	let n = u(), r = A.safeParse(e), i = r.success ? r.data : A.parse(void 0);
	return /* @__PURE__ */ _(C, {
		title: n("games.ghosts.optVariant"),
		children: ["standard", "tinytim"].map((e) => /* @__PURE__ */ _(S, {
			name: "ghosts-variant",
			value: e,
			checked: i.variant === e,
			label: n(e === "standard" ? "games.ghosts.variantStandard" : "games.ghosts.variantTinytim"),
			hint: n(e === "standard" ? "games.ghosts.variantStandardHint" : "games.ghosts.variantTinytimHint"),
			accent: w.accent,
			onChange: () => t({ variant: e })
		}, e))
	});
}
//#endregion
//#region .bgparty/cache/pack-entry/ghosts/entry.tsx
var tt = {
	definition: fe,
	View: be,
	bot: Re,
	describe: Ve,
	llm: We,
	fx: Qe,
	OverView: $e,
	Options: et,
	locales: {
		zh: {
			name: "圣诞魅影",
			desc: "穿越时空的叫标吃墩:预估赢墩数,在过去/现在/未来各放一张牌",
			rules: "目标:打满与人数相同的手数,总分最高者胜(并列共享胜利)。\n牌:\n· 四种花色(红心/蜡烛/音符/天平)各 1~12,3 人局移除各花色的 1~3。\n· 红心永远是王牌。\n每手流程:\n· 叫标:从起始玩家开始,预测这一手赢几墩;可再加 1 扇红门。\n· 红门:命中叫标数或比叫标数多 1 墩都算叫中,但每墩只值 1 分(无红门时每墩 2 分)。\n· 没叫中则本手获得 0 分。\n· 出牌:共 4 轮,每轮每人往过去/现在/未来三个时代各放 1 张,顺序任选。\n· 每个时代的花色由本轮该时代第一张牌定,手上有该花色必须跟。\n· 结算:每轮按过去→现在→未来逐墩结算。\n· 计分花色为起始玩家在该时代所出牌的花色(与时代花色无关)。\n· 墩内有红心则比较最大的红心,否则比较计分花色中最大者。\n· 赢家接过起始玩家标记,下一墩改用他的牌定计分花色。\n起始玩家不轮换:下一手由上一手最后一墩的赢家担任。",
			optVariant: "玩法变体",
			variantStandard: "标准(叫标)",
			variantStandardHint: "预测赢墩数,命中才得分",
			variantTinytim: "小蒂姆(免叫标)",
			variantTinytimHint: "0 墩 6 分、每墩 1 分、超帽归零,推荐首局",
			handChip: "第 {{n}}/{{total}} 手",
			roundSub: "第 {{n}}/4 轮",
			cardsPlayed: "{{n}} / {{total}}",
			wonBy: "{{name}} 赢得此墩",
			dialUnsetShort: "花色未定",
			handCount: "我的手牌 · {{n}} 张",
			handScroll: "左右滑动查看",
			selectedCard: "选中 {{card}} · 点亮处可放",
			bidYou: "轮到你叫标:预测这手赢几墩",
			bidWait: "等 {{name}} 叫标…",
			turnYou: "轮到你出牌:选牌后点一个时代",
			turnWait: "等 {{name}} 出牌…",
			resolving: "结算三个时代的墩…",
			handScoreTitle: "本手结算",
			startAria: "起始玩家",
			tricksAria: "已赢 {{n}} 墩",
			scoreAria: "{{n}} 分",
			bidAria: "叫标 {{n}} 墩",
			capAria: "上限 {{n}} 墩",
			dialUnset: "花色未定,可任意领出",
			pickEraHint: "点选一个时代放入这张牌",
			placeInEra: "放入{{era}}",
			dropHere: "放在这里",
			eraUsed: "本轮已放",
			followSuit: "需要跟色",
			cancel: "取消",
			bidLabel: "叫标墩数",
			redDoor: "红门",
			redDoorHint: "红门:命中 {{n}} 或 {{m}} 墩都算,但每墩只值 1 分",
			bidMinus: "减一",
			bidPlus: "加一",
			confirmBid: "确认叫标",
			lastHandTitle: "上一手回顾",
			hit: "命中",
			miss: "未命中",
			gainPlus: "+{{n}}",
			totalScore: "累计得分",
			finalHand: "末手结算",
			bidTarget: "叫标目标",
			bidRangeAria: "叫标 {{n}} 或 {{m}} 墩",
			tricksWon: "赢墩数",
			trickLimit: "赢墩上限",
			handGain: "本手得分",
			scored: "得分",
			noScore: "未得分",
			winner: "获胜",
			sharedWinner: "共同获胜",
			era: {
				past: "过去",
				present: "现在",
				future: "未来"
			},
			eraLatin: {
				past: "PAST",
				present: "PRESENT",
				future: "FUTURE"
			},
			suit: {
				hearts: "红心 {{n}}",
				candles: "蜡烛 {{n}}",
				notes: "音符 {{n}}",
				scales: "天平 {{n}}"
			},
			suitName: {
				hearts: "红心",
				candles: "蜡烛",
				notes: "音符",
				scales: "天平"
			},
			errPhase: "现在不能这么做",
			errTurn: "还没轮到你",
			errCard: "手里没有这张牌",
			errFollow: "手上有该时代花色的牌,必须跟",
			errEraFull: "这个时代本轮已经出过牌了",
			errBid: "叫 12 墩不能再加红门",
			hintPlay: "把{{card}}放进{{era}}"
		},
		en: {
			name: "Ghosts of Christmas",
			desc: "Time-traveling trick-taking with bidding: place one card in each era",
			rules: "Goal: play as many hands as there are players; highest total wins (ties share the victory).\nCards:\n· Four suits (Hearts/Candles/Notes/Scales) ranked 1~12; with 3 players, remove 1~3 of each suit.\n· Hearts are always trump.\nEach hand:\n· Bid: starting from the start player, predict how many tricks you will win; you may add 1 red door.\n· Red door: hitting your bid or one more than your bid both count, but each trick is worth only 1 point (2 without a red door).\n· Missing the bid scores 0 for the hand.\n· Play: 4 rounds; each round everyone places 1 card into each of the three eras (Past/Present/Future) in any order.\n· An era suit is set by its first card of the round; you must follow if you can.\n· Resolve: each round settles Past, then Present, then Future.\n· The scoring suit is the suit of the card the start player played in that era (not the era suit).\n· If the trick contains a Heart, the highest Heart wins; otherwise the highest card of the scoring suit wins.\n· The winner takes the start player marker, and the next trick scores off their card.\nThe start player does not rotate: the winner of the last trick of a hand takes the marker for the next hand.",
			optVariant: "Variant",
			variantStandard: "Standard (bidding)",
			variantStandardHint: "Predict your tricks; score only on a hit",
			variantTinytim: "Tiny Tim (no bidding)",
			variantTinytimHint: "0 tricks = 6 pts, 1 pt per trick, bust = 0; great first game",
			handChip: "Hand {{n}}/{{total}}",
			roundSub: "Round {{n}}/4",
			cardsPlayed: "{{n}} / {{total}}",
			wonBy: "{{name}} wins",
			dialUnsetShort: "Suit unset",
			handCount: "My hand · {{n}} cards",
			handScroll: "Swipe to browse",
			selectedCard: "{{card}} selected · choose a lit era",
			bidYou: "Your bid: how many tricks this hand?",
			bidWait: "Waiting for {{name}} to bid…",
			turnYou: "Your turn: pick a card, then tap an era",
			turnWait: "Waiting for {{name}}…",
			resolving: "Resolving the three eras…",
			handScoreTitle: "Hand scoring",
			startAria: "Start player",
			tricksAria: "{{n}} tricks won",
			scoreAria: "{{n}} points",
			bidAria: "Bid {{n}} tricks",
			capAria: "cap {{n}} tricks",
			dialUnset: "Suit not set yet; anything may lead",
			pickEraHint: "Tap an era to place this card",
			placeInEra: "Play into {{era}}",
			dropHere: "Play here",
			eraUsed: "Already played",
			followSuit: "Follow suit",
			cancel: "Cancel",
			bidLabel: "Bid tricks",
			redDoor: "Red door",
			redDoorHint: "Red door: {{n}} or {{m}} tricks both hit, but only 1 pt per trick",
			bidMinus: "Minus one",
			bidPlus: "Plus one",
			confirmBid: "Confirm bid",
			lastHandTitle: "Last hand recap",
			hit: "Hit",
			miss: "Missed",
			gainPlus: "+{{n}}",
			totalScore: "Total score",
			finalHand: "Final hand",
			bidTarget: "Bid target",
			bidRangeAria: "Bid {{n}} or {{m}} tricks",
			tricksWon: "Tricks won",
			trickLimit: "Trick limit",
			handGain: "Hand score",
			scored: "Scored",
			noScore: "No score",
			winner: "Winner",
			sharedWinner: "Shared victory",
			era: {
				past: "Past",
				present: "Present",
				future: "Future"
			},
			eraLatin: {
				past: "PAST",
				present: "PRESENT",
				future: "FUTURE"
			},
			suit: {
				hearts: "Hearts {{n}}",
				candles: "Candles {{n}}",
				notes: "Notes {{n}}",
				scales: "Scales {{n}}"
			},
			suitName: {
				hearts: "Hearts",
				candles: "Candles",
				notes: "Notes",
				scales: "Scales"
			},
			errPhase: "Not allowed right now",
			errTurn: "Not your turn yet",
			errCard: "That card is not in your hand",
			errFollow: "You have the era's suit — you must follow",
			errEraFull: "You already played in this era this round",
			errBid: "A bid of 12 cannot add a red door",
			hintPlay: "Play {{card}} into {{era}}"
		}
	}
};
//#endregion
export { tt as default };
